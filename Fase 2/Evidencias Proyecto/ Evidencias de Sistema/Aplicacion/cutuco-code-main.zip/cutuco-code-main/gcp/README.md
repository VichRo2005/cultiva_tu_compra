# Preparación de Google Cloud Platform (proyecto `cutuco`)

Estado: **preparado, no desplegado**. Ningún recurso de GCP ha sido creado desde
este repositorio. Todo lo que aquí se define se ejecuta únicamente cuando el
propietario lo corre explícitamente (ver `deploy-backend.sh`) o desde la consola.

- Proyecto GCP esperado: `cutuco` — consola: https://console.cloud.google.com/welcome?project=cutuco
- Región recomendada: `southamerica-west1` (Santiago, Chile). Cambiar `REGION` en los scripts si se elige otra.
- Riesgo vigente: **R10** (agotamiento de créditos gratuitos GCP). Config mínima aplicada aquí: 512 MiB, 0–5 instancias, 1 vCPU.

## Arquitectura de destino (según FL-21, OP-10, R10 y la arquitectura real del repo)

| Componente de Cutuco | Servicio de destino | Notas |
| --- | --- | --- |
| Frontend Vue 3 + Vite | **Vercel** (ya previsto en README/DEPLOY) | No se migra a GCP. `vercel.json` hace rewrite SPA (evita 404 en rutas Vue, CK-0338). |
| Backend FastAPI (pagos Webpay, servicio mensual, correos Brevo, SRE, PDF) | **Cloud Run** | Imagen desde `backend/Dockerfile` (ya compatible: usuario no-root, `$PORT`). |
| Base de datos PostgreSQL + Auth + Storage + RLS | **Supabase (hosted)** | Se mantiene Supabase; no se traslada a Cloud SQL en esta etapa (evita migración destructiva de datos). |
| Imágenes Docker | **Artifact Registry** (`*-docker.pkg.dev`) | Repositorio `cutuco-backend` en `southamerica-west1`. |
| Compilación/CI | **Cloud Build** (`gcp/cloudbuild.yaml`) disparado por GitHub Actions (`.github/workflows/`) o manualmente. |
| Secretos | **Secret Manager** | Un secreto por variable de entorno del backend; **los valores nunca entran a Git ni al chat**. Ver `secrets-map.md`. |
| Observabilidad | **Cloud Logging + Cloud Monitoring** (automáticos en Cloud Run) + alarmas básicas (OP-10/OP-15). |
| Dominio `cutuco.cl` | Se mantiene en el registrador actual; se mapea a Cloud Run con *custom domain* y certificado administrado cuando el propietario lo autorice (no se toca DNS todavía). |
| Notificaciones/correo | Brevo (externo, vía API/SMTP) — sin cambio. |

## Pasos que debe ejecutar el propietario (intervención externa necesaria)

Requisito: tener `gcloud` autenticado con la cuenta propietaria del proyecto
`cutuco` (`gcloud auth login` y `gcloud config set project cutuco`), o usar
**Cloud Shell** desde la consola del proyecto (no hace falta instalar nada local;
en esta máquina `gcloud` no está instalado).

1. **Habilitar APIs** (consola: *APIs y servicios → Biblioteca*, o):
   ```bash
   gcloud services enable run.googleapis.com cloudbuild.googleapis.com \
     artifactregistry.googleapis.com secretmanager.googleapis.com \
     iam.googleapis.com logging.googleapis.com monitoring.googleapis.com \
     --project cutuco
   ```
2. **Crear el repositorio de imágenes** (una vez):
   ```bash
   gcloud artifacts repositories create cutuco-backend \
     --repository-format=docker --location=southamerica-west1 \
     --description="Imágenes del backend FastAPI de CuTuCo" --project cutuco
   ```
3. **Crear los secretos** (valores desde `backend/.env` local, nunca por chat):
   ```bash
   # Ejemplo para UN secreto; repetir para cada fila de gcp/secrets-map.md
   gcloud secrets create SRE_TOKEN_PUBLICO --replication-policy=automatic --project cutuco
   # El valor se carga desde el archivo local del propietario:
   gcloud secrets versions add SRE_TOKEN_PUBLICO --data-file=<(grep '^SRE_TOKEN_PUBLICO=' backend/.env | cut -d= -f2-) --project cutuco
   ```
   Lista completa de nombres de secretos: `gcp/secrets-map.md`.
4. **Dar permisos a la cuenta de servicio de Cloud Run** (mínimos necesarios):
   ```bash
   gcloud projects add-iam-policy-binding cutuco \
     --member="serviceAccount:PROJECT_NUMBER-compute@developer.gserviceaccount.com" \
     --role="roles/secretmanager.secretAccessor"
   ```
   (Sustituir `PROJECT_NUMBER` por el número del proyecto; se ve en la consola:
   *Inicio → Información del proyecto*.)
5. **Primer build + deploy del backend** (sólo cuando se autorice el despliegue):
   ```bash
   bash gcp/deploy-backend.sh        # build en Cloud Build + push a Artifact Registry + deploy a Cloud Run
   ```
6. **Verificación post-deploy (OP-26, humo sin tocar pagos reales)**:
   `GET https://<servicio>-<hash>-<region>.run.app/health` debe responder 200;
   luego mapear dominio personalizado en *Cloud Run → Administrar dominios*
   (requiere verificación de propiedad de `cutuco.cl` en el DNS; **no realizado**).

## Lo que NO se hace desde aquí

- No se crean recursos facturables sin autorización expresa (R10).
- No se cambian DNS ni dominios activos.
- No se despliega a producción sin autorización expresa.
- No se migra la base de datos (Supabase sigue siendo la BD; no hay migración destructiva).
- No se crean claves JSON de cuentas de servicio: se usa la cuenta de servicio
  por defecto de Compute (`PROJECT_NUMBER-compute@developer.gserviceaccount.com`)
  con `roles/secretmanager.secretAccessor` (mínimo necesario).

## Validaciones locales ya ejecutadas (2026-11-04)

- `docker build -f backend/Dockerfile backend` → imagen `cutuco-backend:qa-check`
  construida localmente (ver `work/docker-build.log`): prueba de que el artefacto
  sirve para Cloud Run sin cambios.
- Backend: `pytest` 263 tests sobre PostgreSQL 16 efímero con migraciones reales
  (ver `work/run-checklist-db2.log`).
- El `Dockerfile` expone `$PORT` y corre como usuario no-root (requisito Cloud Run).
