<#
.SYNOPSIS
  Agrega una versión de Secret Manager sin escribir el valor en el historial
  de PowerShell, en un archivo ni en la línea de comandos.

.EXAMPLE
  .\gcp\add-secret-version.ps1 -Name SUPABASE_URL

.EXAMPLE
  .\gcp\add-secret-version.ps1 -Name BANK_ENCRYPTION_KEY -GenerateFernet
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Z0-9_]+$')]
    [string]$Name,

    [string]$ProjectId = 'cutuco-test',

    [switch]$GenerateFernet
)

$secureValue = $null
$randomBytes = $null
$bstr = [IntPtr]::Zero
$plainValue = $null
$process = $null

try {
    # En Windows, `gcloud` suele resolverse a gcloud.ps1. ProcessStartInfo no
    # puede lanzar un script de PowerShell directamente, por eso se usa el
    # lanzador .cmd incluido en el mismo directorio.
    $gcloudCommand = Get-Command gcloud -ErrorAction Stop
    $gcloudPath = $gcloudCommand.Source
    if ($gcloudPath -match '\.ps1$') {
        $gcloudCmd = Join-Path (Split-Path -Parent $gcloudPath) 'gcloud.cmd'
        if (-not (Test-Path -LiteralPath $gcloudCmd)) {
            throw 'No se encontró gcloud.cmd junto a la instalación de Google Cloud CLI.'
        }
        $gcloudPath = $gcloudCmd
    }

    if ($GenerateFernet) {
        # Fernet exige 32 bytes aleatorios en base64 URL-safe. Se genera y se
        # transmite por stdin sin aparecer en pantalla ni en el historial.
        $randomBytes = [byte[]]::new(32)
        # GetBytes es compatible con Windows PowerShell 5/.NET Framework y
        # con PowerShell moderno; Fill sólo existe en runtimes más recientes.
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try {
            $rng.GetBytes($randomBytes)
        }
        finally {
            $rng.Dispose()
        }
        $plainValue = [Convert]::ToBase64String($randomBytes).Replace('+', '-').Replace('/', '_')
    }
    else {
        $secureValue = Read-Host "Pega el valor de $Name (entrada oculta)" -AsSecureString
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
        $plainValue = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    if ([string]::IsNullOrWhiteSpace($plainValue)) {
        throw "El valor de $Name no puede estar vacío."
    }

    $startInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $gcloudPath
    $startInfo.Arguments = "secrets versions add $Name --data-file=- --project $ProjectId"
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true

    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    [void]$process.Start()

    # Escribe bytes UTF-8 directamente: Write-Output agregaría CRLF y rompería
    # secretos que deben ser exactos, como URLs y códigos de comercio.
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($plainValue)
    $process.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length)
    $process.StandardInput.Close()

    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) {
        throw "No se pudo guardar $Name. $stderr"
    }
    # gcloud suele informar la creación exitosa por stderr; ambos mensajes son
    # seguros porque sólo contienen el nombre y la versión, nunca el valor.
    if (-not [string]::IsNullOrWhiteSpace($stdout)) {
        Write-Host $stdout.Trim()
    }
    if (-not [string]::IsNullOrWhiteSpace($stderr)) {
        Write-Host $stderr.Trim()
    }
}
finally {
    if ($bstr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
    $plainValue = $null
    $secureValue = $null
    if ($null -ne $randomBytes) {
        [Array]::Clear($randomBytes, 0, $randomBytes.Length)
    }
    if ($null -ne $process) {
        $process.Dispose()
    }
}
