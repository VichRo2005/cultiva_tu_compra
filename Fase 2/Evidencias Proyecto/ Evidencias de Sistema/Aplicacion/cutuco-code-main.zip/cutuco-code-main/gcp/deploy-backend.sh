#!/usr/bin/env bash
# Build + deploy del backend CuTuCo a Cloud Run (proyecto de pruebas).
# !!! Ejecutar SOLO con autorización explícita de despliegue del propietario.
# !!! Requiere gcloud autenticado: gcloud auth login && gcloud config set project cutuco-test
# Sin argumentos no toca nada fuera de GCP (build en Cloud Build, push a
# Artifact Registry y deploy del servicio). No crea BD ni cambia DNS.
set -euo pipefail

# El valor predeterminado es el entorno académico aislado. Para otro proyecto,
# sólo se permite cambiarlo de forma explícita mediante PROJECT_ID.
PROJECT_ID="${PROJECT_ID:-cutuco-test}"
REGION="${REGION:-southamerica-west1}"
REPO="cutuco-backend"
SERVICE="cutuco-backend"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/cutuco-backend"
# Identidad dedicada del runtime: no usar la cuenta por defecto de Compute con
# permisos amplios. Debe crearse y recibir Secret Accessor antes del deploy.
RUNTIME_SERVICE_ACCOUNT="${RUNTIME_SERVICE_ACCOUNT:-cutuco-backend-runtime@${PROJECT_ID}.iam.gserviceaccount.com}"

echo "== 0/3 Preflight: secretos requeridos y sin valores locales =="
# Evita repetir los fallos de arranque de Cloud Run:
#  - 00001-7kf / 00002-6mm: secretos creados con `echo` (quedan con \r\n) rompían el
#    patrón pydantic ^[0-9]{12}$ y el contenedor moría al importar app.main.
#  - valores locales en DATABASE_URL/SUPABASE_URL tumbaban el pool al arrancar.
# No imprime valores: sólo verifica y reporta el nombre del secreto. Mantener
# esta lista alineada con --set-secrets: así se detectan faltantes antes del
# build y no se despliega una revisión que Cloud Run no podrá iniciar.
REQUIRED_SECRETS=(
  SUPABASE_URL SUPABASE_ANON_KEY SUPABASE_SERVICE_ROLE_KEY DATABASE_URL
  TRANSBANK_COMMERCE_CODE TRANSBANK_FEE_COMMERCE_CODE TRANSBANK_MALL_SELLER_COMMERCE_CODE
  TRANSBANK_API_KEY TRANSBANK_RETURN_URL
  TRANSBANK_SERVICIO_COMMERCE_CODE TRANSBANK_SERVICIO_API_KEY TRANSBANK_SERVICIO_RETURN_URL
  BREVO_API_KEY BREVO_SMTP_LOGIN BREVO_SMTP_KEY FRONTEND_URL BANK_ENCRYPTION_KEY SRE_TOKEN_PUBLICO
)
OPTIONAL_VALUE_SECRETS=(BREVO_SMTP_LOGIN BREVO_SMTP_KEY)
declare -A SECRET_VALUES=()
for s in "${REQUIRED_SECRETS[@]}"; do
  if ! value="$(gcloud secrets versions access latest --secret="${s}" --project "${PROJECT_ID}" 2>/dev/null)"; then
    echo "ERROR: falta una versión accesible del secreto ${s}. Ver gcp/secrets-map.md." >&2
    exit 1
  fi
  optional_value=false
  for optional_secret in "${OPTIONAL_VALUE_SECRETS[@]}"; do
    if [[ "${s}" == "${optional_secret}" ]]; then
      optional_value=true
      break
    fi
  done
  if [[ -z "${value//[[:space:]]/}" && "${optional_value}" != true ]]; then
    echo "ERROR: el secreto ${s} no tiene valor. Ver gcp/secrets-map.md." >&2
    exit 1
  fi
  if [[ "${value}" == *$'\r'* ]]; then
    echo "ERROR: el secreto ${s} contiene CR (créalo con printf '%s', no echo)." >&2
    exit 1
  fi
  if [[ "${value}" =~ localhost|127\.0\.0\.1|\[::1\] ]]; then
    echo "ERROR: el secreto ${s} contiene una dirección local. Actualízalo con el valor de producción." >&2
    exit 1
  fi
  SECRET_VALUES["${s}"]="${value}"
done
if [[ "${SECRET_VALUES[TRANSBANK_MALL_SELLER_COMMERCE_CODE]}" == "${SECRET_VALUES[TRANSBANK_COMMERCE_CODE]}" ]]; then
  echo "ERROR: TRANSBANK_MALL_SELLER_COMMERCE_CODE debe ser un comercio hijo distinto al padre." >&2
  exit 1
fi
unset value

echo "== 1/3 Build en Cloud Build (imagen -> Artifact Registry) =="
gcloud builds submit --config gcp/cloudbuild.yaml \
  --substitutions "_REGION=${REGION}" --project "${PROJECT_ID}" .

echo "== 2/3 Deploy a Cloud Run (config mínima anti-costo R10: 512Mi, 0-5 instancias) =="
# Los secretos deben existir ya (ver gcp/secrets-map.md); aquí sólo se referencian.
# OJO: no putting comentarios entre líneas con '\' de continuación: el '#' corta el
# comando y la línea siguiente queda suelta ("--set-env-vars: command not found").
# TRANSBANK_ENV=integration: fase de PAGOS SIMULADOS (sandbox) decidida por el
# propietario el 2026-11-05. Al tener credenciales Transbank de producción se cambia
# a production (HAL-VEN-025 / CK-0513); la lógica del código no cambia.
gcloud run deploy "${SERVICE}" \
  --image "${IMAGE}:latest" \
  --region "${REGION}" \
  --project "${PROJECT_ID}" \
  --service-account "${RUNTIME_SERVICE_ACCOUNT}" \
  --no-invoker-iam-check \
  --min-instances 0 --max-instances 5 \
  --memory 512Mi --cpu 1 --concurrency 80 --timeout 60 \
  --set-secrets "SUPABASE_URL=SUPABASE_URL:latest,SUPABASE_ANON_KEY=SUPABASE_ANON_KEY:latest,SUPABASE_SERVICE_ROLE_KEY=SUPABASE_SERVICE_ROLE_KEY:latest,DATABASE_URL=DATABASE_URL:latest,TRANSBANK_COMMERCE_CODE=TRANSBANK_COMMERCE_CODE:latest,TRANSBANK_FEE_COMMERCE_CODE=TRANSBANK_FEE_COMMERCE_CODE:latest,TRANSBANK_MALL_SELLER_COMMERCE_CODE=TRANSBANK_MALL_SELLER_COMMERCE_CODE:latest,TRANSBANK_API_KEY=TRANSBANK_API_KEY:latest,TRANSBANK_RETURN_URL=TRANSBANK_RETURN_URL:latest,TRANSBANK_SERVICIO_COMMERCE_CODE=TRANSBANK_SERVICIO_COMMERCE_CODE:latest,TRANSBANK_SERVICIO_API_KEY=TRANSBANK_SERVICIO_API_KEY:latest,TRANSBANK_SERVICIO_RETURN_URL=TRANSBANK_SERVICIO_RETURN_URL:latest,BREVO_API_KEY=BREVO_API_KEY:latest,BREVO_SMTP_LOGIN=BREVO_SMTP_LOGIN:latest,BREVO_SMTP_KEY=BREVO_SMTP_KEY:latest,FRONTEND_URL=FRONTEND_URL:latest,BANK_ENCRYPTION_KEY=BANK_ENCRYPTION_KEY:latest,SRE_TOKEN_PUBLICO=SRE_TOKEN_PUBLICO:latest" \
  --set-env-vars "ENVIRONMENT=production,TRANSBANK_ENV=integration,RESERVA_STOCK_MINUTOS=15,SRE_BASE_URL=https://sre.cl,SRE_TIMEOUT_SEGUNDOS=4,EMAIL_FROM=CuTuCo Soporte <cutucosoporte@gmail.com>"

echo "== 3/3 Humo post-deploy (OP-26, sin pagos reales) =="
URL="$(gcloud run services describe "${SERVICE}" --region "${REGION}" --project "${PROJECT_ID}" --format='value(status.url)')"
echo "URL del servicio: ${URL}"
TOKEN="$(gcloud auth print-identity-token)"
curl -fsS -H "Authorization: Bearer ${TOKEN}" "${URL}/health" && echo "OK: /health responde 200"
unset TOKEN

echo "El backend queda disponible en la URL de Cloud Run; el frontend se publica aparte en Vercel."
