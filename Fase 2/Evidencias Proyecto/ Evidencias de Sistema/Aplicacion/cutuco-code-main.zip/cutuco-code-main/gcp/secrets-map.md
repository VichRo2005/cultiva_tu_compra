# Mapa de secretos backend → Secret Manager (proyecto `cutuco`)

Regla: **los valores nunca van a Git, al chat, a logs ni a este archivo.**
Sólo se declaran los *nombres*. El propietario crea cada secreto con
`gcloud secrets create <nombre>` y carga el valor desde `backend/.env` local:

```bash
gcloud secrets versions add NOMBRE --data-file=<(grep -E '^NOMBRE=' backend/.env | cut -d= -f2-)
```

Cloud Run referencia cada secreto por nombre en `gcp/service.backend.yaml`
(`secretKeyRef`). La cuenta de servicio por defecto de Compute necesita
`roles/secretmanager.secretAccessor` (paso 4 de `gcp/README.md`).

| Secreto (nombre) | Variable de entorno | Origen del valor |
| --- | --- | --- |
| SUPABASE_URL | SUPABASE_URL | URL del proyecto Supabase |
| SUPABASE_ANON_KEY | SUPABASE_ANON_KEY | Supabase → Settings → API Keys → Publishable key (`sb_publishable_...`) |
| SUPABASE_SERVICE_ROLE_KEY | SUPABASE_SERVICE_ROLE_KEY | Supabase → Settings → API Keys → Secret key (`sb_secret_...`, sólo backend) |
| DATABASE_URL | DATABASE_URL | Supabase → Settings → Database → Connection string (URI, modo sesión/transaction pooler) |
| TRANSBANK_COMMERCE_CODE | TRANSBANK_COMMERCE_CODE | Transbank Mall (ambiente producción, cuando se habilite) |
| TRANSBANK_FEE_COMMERCE_CODE | TRANSBANK_FEE_COMMERCE_CODE | Transbank comercio del fee |
| TRANSBANK_MALL_SELLER_COMMERCE_CODE | TRANSBANK_MALL_SELLER_COMMERCE_CODE | Transbank Mall: comercio hijo que el backend asigna automáticamente al aprobar vendedores (nunca el padre) |
| TRANSBANK_API_KEY | TRANSBANK_API_KEY | Transbank (llave secreta) |
| TRANSBANK_RETURN_URL | TRANSBANK_RETURN_URL | URL pública del backend: `https://<cloud-run>/api/webpay/retorno` |
| TRANSBANK_SERVICIO_COMMERCE_CODE | TRANSBANK_SERVICIO_COMMERCE_CODE | Transbank Webpay Plus del servicio mensual (hallazgo HAL-VEN-025: faltaba en producción) |
| TRANSBANK_SERVICIO_API_KEY | TRANSBANK_SERVICIO_API_KEY | Transbank Webpay Plus (llave) |
| TRANSBANK_SERVICIO_RETURN_URL | TRANSBANK_SERVICIO_RETURN_URL | URL pública del backend: `https://<cloud-run>/api/servicio/retorno` |
| BREVO_API_KEY | BREVO_API_KEY | Brevo → SMTP & API |
| BREVO_SMTP_LOGIN | BREVO_SMTP_LOGIN | Brevo SMTP (login; respaldo de la API) |
| BREVO_SMTP_KEY | BREVO_SMTP_KEY | Brevo SMTP (clave; respaldo de la API) |
| FRONTEND_URL | FRONTEND_URL | Dominio Vercel de producción (p. ej. https://cutuco.vercel.app o cutuco.cl) |
| BANK_ENCRYPTION_KEY | BANK_ENCRYPTION_KEY | Clave Fernet rotada por el propietario (datos bancarios) |
| SRE_TOKEN_PUBLICO | SRE_TOKEN_PUBLICO | Token sre.cl del propietario (NUNCA en chat/logs; rotar si se filtró) |

Valores no secretos fijados en `gcp/service.backend.yaml`: `ENVIRONMENT=production`,
`TRANSBANK_ENV=integration` (fase sandbox actual; cambiar junto con credenciales reales), `RESERVA_STOCK_MINUTOS=15`, `SRE_BASE_URL=https://sre.cl`,
`SRE_TIMEOUT_SEGUNDOS=4`, `EMAIL_FROM`.

Rotación: `gcloud secrets versions add NOMBRE --data-file=...` crea una nueva
versión; Cloud Run con `key: latest` la toma en el siguiente arranque/instancia.

## Valores de PRODUCCIÓN obligatorios antes del deploy (2026-11-05)

Los 19 secretos se cargaron inicialmente desde el `backend/.env` **local**, por lo que
algunos apuntan a `localhost` y tumbaron la revisión `cutuco-backend-00001-7kf`
("container failed to start and listen on PORT=8080": `init_pool` abría la conexión al
arrancar y `localhost:54322` no existe dentro del contenedor). Antes de redeployar,
actualiza estos secretos con valores de producción (pega los valores sólo en la
terminal de Cloud Shell, nunca en el chat):

| Secreto | Valor de producción esperado |
| --- | --- |
| SUPABASE_URL | `https://<proyecto>.supabase.co` (proyecto Supabase de producción) |
| SUPABASE_ANON_KEY / SUPABASE_SERVICE_ROLE_KEY | Publishable y secret key del proyecto Supabase (Settings → API Keys) |
| DATABASE_URL | Pooler de Supabase: `postgresql://postgres:<pass>@aws-0-<region>.pooler.supabase.com:6543/postgres` (modo transacción recomendado para Cloud Run) |
| FRONTEND_URL | Origen público del frontend en Vercel: `https://cutuco.online` — se usa para CORS, enlaces de correo y redirecciones post-pago |
| TRANSBANK_RETURN_URL | `https://<cloud-run>/api/webpay/retorno` (Cloud Run recibe el POST de Transbank y redirige al frontend) |
| TRANSBANK_MALL_SELLER_COMMERCE_CODE | Comercio hijo asignado automáticamente al aprobar vendedores; no puede ser igual a `TRANSBANK_COMMERCE_CODE` |
| TRANSBANK_SERVICIO_RETURN_URL | `https://<cloud-run>/api/servicio/retorno` (el backend lo atiende directo y 303 al frontend) |
| TRANSBANK_* / TRANSBANK_SERVICIO_* | Credenciales de producción de Transbank cuando estén habilitadas (HAL-VEN-025 / CK-0513) |
| BREVO_API_KEY / BREVO_SMTP_LOGIN / BREVO_SMTP_KEY | Credenciales Brevo de producción |
| BANK_ENCRYPTION_KEY | Clave Fernet nueva generada para producción (rotar invalida cuentas cifradas antiguas) |
| SRE_TOKEN_PUBLICO | Token sre.cl vigente (ya versión 2); rotar por higiene en el panel de sre.cl |

Comando para actualizar uno (valor desde stdin, no se imprime). **Usa siempre
`printf '%s'` y NUNCA `echo`: `echo` agrega `\r\n` al valor y el patrón pydantic
`^[0-9]{12}$` lo rechaza, tumbando el arranque del contenedor (pasó en la revisión
`cutuco-backend-00002-6mm`):**
```bash
printf '%s' "VALOR" | gcloud secrets versions add NOMBRE --data-file=- --project cutuco
```

`gcp/deploy-backend.sh` incluye un preflight que aborta el deploy si `DATABASE_URL` o
`SUPABASE_URL` contienen `localhost`/`127.0.0.1`.
