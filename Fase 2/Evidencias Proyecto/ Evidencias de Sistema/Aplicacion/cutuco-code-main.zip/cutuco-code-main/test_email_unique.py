import asyncio
import asyncpg

async def test():
    conn = await asyncpg.connect('postgresql://postgres:postgres@127.0.0.1:54322/postgres')
    await conn.execute("SET LOCAL ROLE postgres")
    try:
        await conn.execute("""INSERT INTO auth.users (id, instance_id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at) VALUES (gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'CUTUCO.ADMIN.BASE@EXAMPLE.TEST', 'x', now(), now(), now())""")
        print('Insert succeeded - no unique constraint!')
    except Exception as e:
        print(f'Error: {e}')
    await conn.close()

asyncio.run(test())