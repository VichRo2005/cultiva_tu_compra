# Backend CuTuCo — Webpay Mall Plus

FastAPI procesa el checkout, el servicio mensual, los datos bancarios cifrados y
los correos. Supabase mantiene autenticación, catálogo, pedidos y RLS. Las
migraciones nuevas (`20261101000000` a `20261101020000`) agregan la huella
antiduplicados de cuentas, la preparación real del pedido, el código de entrega
oculto al vendedor y la cancelación con motivo.

`BANK_ENCRYPTION_KEY` es obligatoria: cifra el número de cuenta (Fernet) y
calcula la huella HMAC usada para detectar duplicados. No cambies la clave si
existen cuentas activas guardadas con la anterior.

## Configuración local

### Imágenes del catálogo de prueba

Después de aplicar migraciones y `supabase/seed.sql`, el script convierte los cuatro
JPG de `backend/scripts/assets` a WebP y sube una copia por producto (20 objetos)
al bucket público `product-images`. Actualiza `imagenes_productos` con el tamaño
real y la ruta que espera el frontend. Se puede ejecutar nuevamente sin duplicar
objetos ni registros.

```powershell
cd backend
.venv\Scripts\python.exe -m pip install -e '.[images]'
cd ..
.\backend\.venv\Scripts\python.exe backend\scripts\upload_product_images.py --target local
```

Para local, `backend/.env` o el entorno debe contener `SUPABASE_SERVICE_ROLE_KEY`;
`SUPABASE_URL` tiene por defecto `http://127.0.0.1:54321`. La clave local se puede
consultar con `supabase status`. Para Supabase nube, configurar en el entorno
`SUPABASE_CLOUD_URL=https://<proyecto>.supabase.co` y
`SUPABASE_CLOUD_SERVICE_ROLE_KEY`, y ejecutar el mismo comando con
`--target cloud`. También se puede usar `--env-file <ruta>` para un archivo de
variables distinto. La clave de servicio es privada y nunca debe exponerse en
el frontend.

```powershell
# Desde la raíz, con Supabase local iniciado
.\node_modules\.bin\supabase.cmd migration up --local
cd backend
.venv\Scripts\python.exe -m pip install -e '.[dev]'
# Copiar .env.example a .env solamente si aún no existe y completar los secretos.
.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

`DATABASE_URL` debe apuntar a PostgreSQL directo (local: `localhost:54322/postgres`),
con rol backend `service_role` o postgres para desarrollo. La API key de Supabase
no configura el rol SQL. El backend verifica JWT ES256 contra JWKS de Supabase,
issuer/audiencia/expiración y consulta el rol activo en `perfiles`.

Aplicar todas las migraciones, incluidas las de esta iteración
(`20261101000000_estado_envio_cancelado.sql`,
`20261101010000_correcciones_registro_bancario_direcciones.sql` y
`20261101020000_pedidos_cancelacion_entrega.sql`). La migración
`20261012000000_checkout_mall_backend.sql` crea tablas **privadas** para
checkout/órdenes de compra, agrega snapshot tributario a pedidos y adapta el
comprobante al neto recibido por cada tienda. El código no depende de
`20261006100000_add_gallery_legacy_tables.sql` ni de `seeds/gallery_dev.sql`.
Las pruebas usan el catálogo de `supabase/seed.sql`.
No se modifican esas migraciones históricas ni los seeds salvo el bloque de
estados de preparación necesario para el nuevo flujo.

```dotenv
TRANSBANK_ENV=integration
TRANSBANK_COMMERCE_CODE=597055555535
TRANSBANK_FEE_COMMERCE_CODE=597055555537
# Comercio hijo asignado automáticamente al aprobar una postulación.
TRANSBANK_MALL_SELLER_COMMERCE_CODE=597055555536
TRANSBANK_API_KEY=<clave del entorno>
TRANSBANK_RETURN_URL=http://localhost:5173/cliente/pedidos
```

El padre autentica el Mall; el fee se envía a un **comercio hijo** configurable.
En producción deben configurarse los códigos contratados, incluido un hijo propio
para la comisión. Al aprobar una cuenta, FastAPI toma
`TRANSBANK_MALL_SELLER_COMMERCE_CODE` exclusivamente del entorno del servidor y lo
envía a la RPC; el administrador no lo escribe ni el navegador lo recibe como
credencial. En producción debe ser un comercio hijo distinto al padre. No usar los
códigos compartidos de integración para liquidaciones reales. `BREVO_API_KEY`,
`EMAIL_FROM` y `FRONTEND_URL` configuran los correos. La aplicación no usa
`RESEND_API_KEY`: no la agregues a `.env` ni a Secret Manager.

En producción `TRANSBANK_RETURN_URL` apunta directamente a
`https://<cloud-run>/api/webpay/retorno`; ese endpoint confirma y vuelve por
GET al historial en la SPA. En desarrollo puede mantenerse la ruta de la SPA
con el proxy de Vite. `FRONTEND_URL` debe ser el origen exacto del frontend;
FastAPI lo usa para CORS. En desarrollo también acepta
`localhost`/`127.0.0.1` en los puertos 5173 y 4173 para evitar que el retorno
del checkout quede bloqueado por el navegador.

### Servicio mensual y SRE (2026-11)

```dotenv
# Webpay Plus del servicio mensual. Obligatorias fuera de development.
TRANSBANK_SERVICIO_COMMERCE_CODE=
TRANSBANK_SERVICIO_API_KEY=
TRANSBANK_SERVICIO_RETURN_URL=http://localhost:8000/api/servicio/retorno

# Token público de SRE (no es un secreto; nunca se devuelve al cliente).
SRE_BASE_URL=https://sre.cl
SRE_TOKEN_PUBLICO=token_publico
SRE_TIMEOUT_SEGUNDOS=4
```

Si falta alguna `TRANSBANK_SERVICIO_*`, `POST /api/servicio/iniciar` responde
**503** con un mensaje en español que enumera las variables faltantes. En
`ENVIRONMENT=development` se usa el sandbox público sólo si se omiten. En
producción se rechazan las credenciales de sandbox.

## Contrato de checkout (cambio incompatible con Webpay Plus anterior)

`POST /api/webpay/iniciar` requiere JWT:

```json
{
  "direccion_id": "UUID de dirección activa propia",
  "items": [
    {"producto_id": "UUID producto de tienda 1", "cantidad": 2},
    {"producto_id": "UUID producto de tienda 2", "cantidad": 1}
  ],
  "documento_tributario": {"tipo": "boleta"}
}
```

Para factura, reemplazar `documento_tributario` por:

```json
{
  "tipo": "factura",
  "rut_empresa": "12.345.678-5",
  "razon_social": "Empresa Ejemplo",
  "giro": "Comercio de alimentos",
  "direccion_tributaria": "Calle Ejemplo 123, Santiago"
}
```

La boleta es el valor predeterminado, no solicita RUT y congela `66666666-6`.
Factura exige los cuatro datos, valida módulo 11 y normaliza RUT sin puntos.
Los campos opcionales de destinatario siguen siendo `nombre_destinatario`,
`telefono_destinatario`, `referencia_entrega`.

La respuesta contiene `checkout_id`, `buy_order`, `token_ws`, `url`, `monto`.
**No contiene `pedido_id`**: todavía no existen pedidos ni pagos.
El frontend debe enviar un formulario POST a `url` con `token_ws`.

Cada productor se obtiene del catálogo, junto con `codigo_comercio_mall`. Se validan
actividad, stock, dirección y cobertura. Productos repetidos se suman; códigos de
comercio repetidos se conservan como tiendas separadas con diferentes `buy_order`.
Los precios, dirección, documento y comercios quedan congelados en el checkout.
Las órdenes Mall/tienda/fee tienen prefijos distintos, máximo 26 caracteres e índices
únicos antes de llamar a Transbank.

Se mantiene la regla monetaria del esquema: despacho de **3500 CLP por productor**;
fee del **5% del subtotal de productos**. Se redondea el fee a peso entero con HALF_UP
para enviarlo a Webpay; se conserva el fee contable de dos decimales en pedidos.
La tienda recibe `total - fee_entero` y el hijo de plataforma recibe `fee_entero`.
`pagos.monto_fee_descontado` conserva la separación efectivamente solicitada.
La suma de ambos detalles coincide exactamente con el total del cliente. Se rechazan
subtotales con fracciones de peso; no se truncan. Un fee cero no genera un detalle vacío.

`POST /api/webpay/confirmar` recibe `{"token_ws":"..."}`. El retorno admite también
GET/POST `/api/webpay/retorno` y redirige por 303 al historial del frontend. Confirmar
puede ejecutarse sin JWT mediante el token privado de Transbank; con JWT se exige
comprador dueño o administrador activo. Se validan la orden Mall, sesión y el conjunto
exacto de detalles: orden, comercio, importe, estado y código de autorización.

La confirmación devuelve:

```json
{
  "ok": true,
  "checkout_id": "UUID",
  "estado": "autorizado",
  "pedidos": [
    {"pedido_id": "UUID", "productor_id": "UUID", "estado_pedido": "pagado", "total": "13500.00"}
  ],
  "requiere_conciliacion": false,
  "ya_confirmado": false
}
```

Por cada tienda autorizada se crean pedido, detalles y comprobante en una transacción.
Se pasa internamente por `creado` para respetar los triggers y luego `pagado`, sin
exponer un pedido pendiente. El trigger descuenta stock y crea envío, conservando
`pagado` para los nuevos checkouts. Los pedidos históricos del seed mantienen su flujo.
`pagos` guarda únicamente el detail exitoso de esa tienda; nunca respuestas ajenas ni
intentos rechazados. La respuesta completa, incluido el fee, permanece privada.

`estado` puede ser `autorizado`, `parcial` o `rechazado`. Un rechazo total no genera
pedidos/pagos/correos. En autorización parcial se crean solo las tiendas autorizadas.
Si una tienda y su fee tienen resultados distintos, `requiere_conciliacion=true`:
no se debe presentar ese checkout como íntegramente pagado. No hay devoluciones automáticas.

`GET /api/webpay/estado/{pedido_id}` exige JWT del comprador o admin y devuelve estado,
total, envío, `estado_pago=autorizado` y `monto_productor`. Ya no existen estados de
custodia, `monto_retenido` ni payouts. El frontend debe consumir la lista `pedidos`
recibida al confirmar y consultar cada pedido individual.

## Recuperación y correos

La fila privada del checkout se bloquea antes de confirmar; callbacks concurrentes
no duplican el commit, pedidos, stock ni correos. Una respuesta perdida se recupera
con `status`. Si la autorización fue válida pero falló la persistencia de pedidos
(stock agotado, restricción local), se conserva la respuesta privada y se devuelve 502.
Un reintento usa esa respuesta sin volver a confirmar en Transbank. Consultar
`private.webpay_checkouts` con `respuesta IS NOT NULL AND resultado IS NULL` para
conciliar pendientes; resolver la causa o tramitar el movimiento en Transbank.
Una caída antes de guardar la respuesta todavía requiere recuperación por `status`.

Se envían dos correos por pedido, al comprador y al productor, con el documento
tributario solicitado. Factura incluye todos los datos y el mensaje de solicitar
Factura de Compra si el productor no puede emitirla. Boleta indica el RUT genérico.
HTML escapa contenido del cliente. El vendedor ve el importe neto enviado a su comercio.

Cada correo bloquea el pedido, verifica su timestamp y usa clave de idempotencia en
Brevo. Si falla, el pago permanece guardado y otra confirmación reintenta únicamente
los correos pendientes. BackgroundTasks no es una cola durable: tras reiniciar se
requiere reintento. La idempotencia del proveedor tiene su propia retención limitada.

## Validación

```powershell
cd backend
.venv\Scripts\ruff.exe check .
.venv\Scripts\ruff.exe format --check .
.venv\Scripts\mypy.exe app
.venv\Scripts\python.exe -m pytest -q
# Diagnóstico contra Transbank integración + lectura del seed local; sin autorizar tarjetas
.venv\Scripts\python.exe scripts/probe_webpay_mall.py
```

Las integraciones usan exclusivamente `postgresql://postgres:postgres@localhost:54322/postgres`,
con SDK/Brevo simulados y JWT de prueba. Los fixtures revierten sus cambios. La prueba
de concurrencia usa conexiones reales y limpia únicamente su checkout y pedidos.
No se omiten pruebas si falta Supabase. Cubren cuatro productores con códigos repetidos,
comisiones, autorización parcial, snapshots, permisos, rechazos, respuestas inconsistentes,
recuperación, concurrencia, stock, documentos tributarios y ausencia de rutas retiradas.

Resultado de la prueba real de creación/consulta en integración (11 de octubre de 2026):

| Caso | Resultado |
| --- | --- |
| Cuatro tiendas con `597055555536` y órdenes distintas | Aceptado: 4 details `INITIALIZED` |
| Cuatro tiendas y fee en el padre `597055555535` | API HTTP 500 |
| Una tienda y fee en el padre `597055555535` | API HTTP 500 |
| Cuatro productores del seed y cuatro fees en `597055555537` | Aceptado: 8 details `INITIALIZED` |

El SDK 6.1.0 permite serializar códigos repetidos. Esta prueba verifica creación y
consulta reales; no autoriza una tarjeta ni demuestra la liquidación en producción.
La autorización completa se valida con respuestas simuladas y PostgreSQL real.
Por lo tanto, no se impone un único vendedor en el carrito.

Referencia del contrato: [documentación oficial de Webpay Mall](https://transbankdevelopers.com/documentacion/webpay-plus).

## Reserva temporal de stock del checkout (2026-10-21)

Mientras un checkout Webpay está abierto, las unidades retenidas viven en
`productos.stock_reservado` y el detalle en `private.checkout_reservas`
(migración `20261021000000_reserva_stock_checkout.sql`). El inventario queda
gobernado por la base de datos, no por temporizadores del navegador:

- **Disponible** = `stock - stock_reservado`. `iniciar` valida esta fórmula y
  crea la retención con un `UPDATE` condicional atómico (si otro checkout tomó
  las unidades, responde 409).
- **Liberación**: al confirmar el checkout (autorizado, parcial o rechazado)
  invoca `private.liberar_reservas_checkout`; si el comprador abandona, el
  servidor libera las retenciones vencidas (`private.liberar_reservas_expiradas`)
  al comenzar el siguiente iniciar/confirmar.
- **Plazo**: `RESERVA_STOCK_MINUTOS` (default 15, rango 1-240) en `backend/.env`.
  Cubre con holgura el timeout de formulario de Transbank (10 min).

Esto elimina el "cobro sin pedido": entre `iniciar` y `confirmar` ningún otro
comprador puede comprometer las mismas unidades; la revalidación final sigue en
el trigger `validar_transicion_pedido` bajo lock de fila.

## Correos transaccionales: reintento

`GET /api/webpay/estado/{pedido_id}` re-agenda como BackgroundTask los envíos
cuyo flag (`correo_comprador_enviado_en` / `correo_productor_enviado_en`)
sigue en NULL. `enviar_pendiente` es idempotente (bandera en pedidos +
`idempotency_key` de Brevo), así que revisar el pedido repara envíos caídos
sin duplicar mensajes ni pedidos.

## Diagnóstico de correos (Brevo API / SMTP)

`scripts/diagnostico_email.py` revisa, sin imprimir secretos:

1. Configuración: presencia y formato de `BREVO_API_KEY` y `EMAIL_FROM` (6.1).
2. Envío de prueba real (`--destinatario`): reporta el resultado REAL del
   proveedor (aceptado/rechazado) y nunca afirma que un correo salió si la API
   devolvió un error.
3. Sondeo SMTP (`--solo-smtp`): conectividad TCP a `smtp-relay.brevo.com` en
   el puerto configurado (`BREVO_SMTP_PORT`, por defecto 587). El envío usa la
   API de Brevo como vía principal y SMTP sólo como respaldo, dentro del mismo
   presupuesto de tiempo e identificador de idempotencia.

```powershell
cd backend
.venv\Scripts\python.exe -m scripts.diagnostico_email
.venv\Scripts\python.exe -m scripts.diagnostico_email --destinatario tu@correo.cl
```

Los fallos de envío se registran clasificados (configuración, autenticación 401,
dominio no verificado / rechazo 422, límite 429, proveedor 5xx, red) en el log,
con el texto del proveedor y sin claves ni destinatarios (6.2). Para enviar en
producción desde `duocuc.cl` (o el dominio propio que se defina) falta verificar
el dominio en el panel de Brevo: sin eso, la API sólo acepta envíos al correo
propietario de la cuenta de prueba.

## Migraciones recientes

| Migración | Qué agrega |
| --- | --- |
| `20261026000000_seguridad_envios_y_reinicio_intentos.sql` | Guardias de inmutabilidad de envíos/pedidos con `coalesce` (la GUC opcional ya no anula la protección) y reinicio administrativo auditado del límite de 3 postulaciones (`intentos_extra`, `postulaciones_reinicio_intentos`, RPC `reiniciar_intentos_postulacion`). |
| `20261021000000_reserva_stock_checkout.sql` | `productos.stock_reservado`, `private.checkout_reservas`, funciones de liberación idempotente. |
| `20261022000000_codigo_comercial_productos.sql` | `productos.codigo_producto` (PRD-000001, secuencia, trigger y backfill). |
| `20261023000000_observaciones_apelacion_ban_stock_reclamado.sql` | Límites 10-2500 de observaciones de postulación (CHECK + RPC), reactivación de cuenta al aprobar la apelación de un ban permanente y reposición de stock al cancelar desde `reclamado`. |
| `20261024000000_precio_clp_entero.sql` | `ck_producto_precio_entero`: los precios se registran en CLP entero, como cobra Webpay. |
