"""Diagnostico del sistema de correos (Brevo / SMTP) - encargo 6.1 a 6.4.

Comprueba, sin exponer secretos:
  1. Configuracion del backend: BREVO_API_KEY y EMAIL_FROM presentes y con
     formato valido (6.1).
  2. Envio de prueba real por la API de Brevo (--destinatario correo@dominio):
     reporta el resultado REAL del proveedor (aceptado / rechazado / error) y
     nunca afirma que un correo salio si el proveedor devolvio un error (6.1).
  3. Alcance de SMTP: conexion TCP a los puertos 465/587 (y alternativos 2465/
      2587) de smtp-relay.brevo.com para verificar si el entorno bloquea el trafico
     saliente antes de descartar smtplib (6.3).

Uso:
    python -m scripts.diagnostico_email
    python -m scripts.diagnostico_email --destinatario tu@correo.cl
    python -m scripts.diagnostico_email --solo-smtp
"""

from __future__ import annotations

import argparse
import re
import socket
import sys

from app.core.config import get_settings
from app.integrations.email.client import clasificar_error_correo

SMTP_HOST = "smtp-relay.brevo.com"
SMTP_PUERTOS = [465, 587, 2465, 2587]
FORMATO_BREVO = re.compile(r"^xkeysib_[A-Za-z0-9_\-]{8,}$")


def revisar_configuracion() -> list:
    """Devuelve hallazgos de configuracion (sin imprimir valores secretos)."""
    settings = get_settings()
    hallazgos = []

    api_key = settings.BREVO_API_KEY or ""
    if not api_key:
        hallazgos.append("BREVO_API_KEY: VACIA - la API de Brevo no puede autenticar (6.1).")
    elif not FORMATO_BREVO.match(api_key):
        hallazgos.append(
            "BREVO_API_KEY: formato inesperado - debe partir con xkeysib_ . Revisa el archivo .env (6.1)."
        )
    else:
        print("BREVO_API_KEY: presente (valor no mostrado por seguridad).")

    email_from = settings.EMAIL_FROM or ""
    if not email_from:
        hallazgos.append("EMAIL_FROM: VACIO - Brevo rechazaria el envio sin remitente (6.1).")
    else:
        dominio = email_from.split("@")[-1].rstrip(">").strip()
        print("EMAIL_FROM: presente. Dominio del remitente: " + dominio)
    return hallazgos


def enviar_prueba(destinatario: str) -> int:
    """Envio real con la API de Brevo; reporta el resultado del proveedor."""
    settings = get_settings()
    print("[2] Envio de prueba por la API de Brevo hacia " + destinatario + " ...")
    try:
        from app.integrations.email.client import EmailClient
        import asyncio

        client = EmailClient(
            api_key=settings.BREVO_API_KEY,
            from_email=settings.EMAIL_FROM,
        )
        resultado = asyncio.run(
            client.send(
                to=destinatario,
                subject="CuTuCo - correo de prueba del diagnostico",
                html="<p>Correo de prueba generado por scripts.diagnostico_email.</p>",
                text="Correo de prueba generado por scripts.diagnostico_email.",
            )
        )
        if resultado:
            print("  ACEPTADO por el proveedor Brevo.")
            print("  El proveedor acepto la peticion; la entrega final depende del buzon destino.")
            return 0
        else:
            print("  RECHAZADO o fallido: Brevo retorno False despues de reintentos.")
            return 1
    except Exception as exc:  # noqa: BLE001 - el diagnostico SI quiere clasificar
        print("  RECHAZADO o fallido: " + clasificar_error_correo(exc))
        return 1


def sondear_smtp() -> int:
    """Conexion TCP a los puertos SMTP de Brevo (6.3)."""
    print("[3] Sondeo de puertos SMTP hacia " + SMTP_HOST + " (sin credenciales):")
    bloqueados = 0
    for puerto in SMTP_PUERTOS:
        try:
            with socket.create_connection((SMTP_HOST, puerto), timeout=6):
                print("  " + str(puerto) + ": ALCANZABLE (TLS implicito 465 / STARTTLS 587)")
        except OSError as exc:
            bloqueados += 1
            razon = exc.strerror or exc.__class__.__name__
            print("  " + str(puerto) + ": BLOQUEADO o inalcanzable (" + razon + ")")
    if bloqueados == len(SMTP_PUERTOS):
        print("  Todos los puertos SMTP estan bloqueados: se mantiene la decision de usar la")
        print("  API de Brevo; smtplib no funcionaria en este entorno (6.3/6.4).")
    elif bloqueados:
        print("  Hay puertos SMTP disponibles; el bloqueo solo afecta a algunos puertos (6.3).")
    else:
        print("  Ningun puerto bloqueado: el bloqueo SMTP previo no se reproduce en esta red (6.3).")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destinatario", default=None, help="correo para la prueba de envio real")
    parser.add_argument("--solo-smtp", action="store_true", help="omite la revision de configuracion")
    args = parser.parse_args()

    codigo = 0
    if not args.solo_smtp:
        print("[1] Revision de configuracion del backend (.env):")
        hallazgos = revisar_configuracion()
        for hallazgo in hallazgos:
            print("  PROBLEMA: " + hallazgo)
            codigo = 1
        if not hallazgos:
            print("  Sin problemas de configuracion detectados.")

    if args.destinatario:
        codigo = enviar_prueba(args.destinatario) or codigo
    elif not args.solo_smtp:
        print("[2] Envio de prueba omitido: pasa --destinatario correo@dominio para ejecutarlo.")

    codigo = sondear_smtp() or codigo
    return codigo


if __name__ == "__main__":
    sys.exit(main())
