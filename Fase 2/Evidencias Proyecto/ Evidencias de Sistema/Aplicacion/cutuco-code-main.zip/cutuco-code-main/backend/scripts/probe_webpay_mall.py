"""Probe Supabase local + Transbank integration. No card authorization or live payments."""

import asyncio
import json
from decimal import ROUND_HALF_UP, Decimal
from uuid import uuid4

import asyncpg
from transbank.common.integration_api_keys import IntegrationApiKeys
from transbank.webpay.webpay_plus.mall_transaction import MallTransaction
from transbank.webpay.webpay_plus.request import MallTransactionCreateDetails


async def seed_stores() -> list:
    conn = await asyncpg.connect("postgresql://postgres:postgres@localhost:54322/postgres")
    try:
        return await conn.fetch(
            """SELECT DISTINCT ON (pr.id) pr.id, pr.codigo_comercio_mall, p.precio
            FROM public.productores pr JOIN public.productos p ON p.productor_id=pr.id
            WHERE pr.activo AND p.activo AND p.eliminado_en IS NULL AND p.stock>=2
            ORDER BY pr.id,p.id LIMIT 4"""
        )
    finally:
        await conn.close()


def probe(tx: MallTransaction, name: str, details: list[dict]) -> dict:
    first, *remaining = details
    request = MallTransactionCreateDetails(**first)
    for detail in remaining:
        request.add(**detail)
    try:
        result = tx.create(
            uuid4().hex[:26], uuid4().hex, "http://localhost:8000/api/webpay/retorno", request
        )
        status = tx.status(result["token"])
        outcome = {
            "case": name,
            "created": bool(result.get("token")),
            "details_returned": len(status.get("details", [])),
            "statuses": sorted({d["status"] for d in status.get("details", [])}),
        }
    except Exception as exc:
        outcome = {"case": name, "error": str(exc)}
    return outcome


def main() -> None:
    tx = MallTransaction.build_for_integration("597055555535", IntegrationApiKeys.WEBPAY)
    stores = asyncio.run(seed_stores())
    if len(stores) != 4:
        raise RuntimeError("Supabase local needs four active seeded producers")
    cases = {
        "four_stores_repeated_child": ["597055555536"] * 4,
        "four_stores_and_parent_fee": ["597055555536"] * 4 + ["597055555535"],
        "one_store_and_parent_fee": ["597055555536", "597055555535"],
    }
    for name, codes in cases.items():
        details = [
            {"amount": 1000, "commerce_code": code, "buy_order": uuid4().hex[:26]} for code in codes
        ]
        print(json.dumps(probe(tx, name, details)))  # noqa: T201 - CLI diagnostic
    details = []
    for store in stores:
        subtotal = store["precio"] * 2
        fee = int((subtotal * Decimal("0.05")).quantize(Decimal(1), ROUND_HALF_UP))
        details.extend(
            [
                {
                    "amount": int(subtotal) + 3500 - fee,
                    "commerce_code": store["codigo_comercio_mall"],
                    "buy_order": uuid4().hex[:26],
                },
                {"amount": fee, "commerce_code": "597055555537", "buy_order": uuid4().hex[:26]},
            ]
        )
    print(json.dumps(probe(tx, "four_seed_stores_and_child_fees", details)))  # noqa: T201


if __name__ == "__main__":
    main()
