"""Convierte y publica las imágenes principales declaradas en supabase/seed.sql.

Ejemplos, desde la raíz del repositorio:
  python backend/scripts/upload_product_images.py --target local
  python backend/scripts/upload_product_images.py --target cloud

Instalar antes: pip install -e "./backend[images]". El seed SQL debe estar
aplicado en el proyecto de destino antes de ejecutar este script.
"""

from __future__ import annotations

import argparse
import io
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import httpx
from PIL import Image, UnidentifiedImageError

ROOT = Path(__file__).resolve().parents[2]
ASSETS = Path(__file__).resolve().parent / "assets"
SEED = ROOT / "supabase" / "seed.sql"
BUCKET = "product-images"
LOG = logging.getLogger(__name__)
ROW = re.compile(
    r"\('(?P<image_id>[0-9a-f-]{36})'::uuid,\s*"
    r"'(?P<product_id>[0-9a-f-]{36})'::uuid,\s*"
    r"'(?P<filename>[a-z0-9_-]+\.webp)'\)"
)


@dataclass(frozen=True)
class SeedImage:
    image_id: str
    product_id: str
    filename: str

    @property
    def key(self) -> str:
        return f"{self.product_id}/{self.filename}"


def read_seed_images() -> list[SeedImage]:
    sql = SEED.read_text(encoding="utf-8")
    try:
        block = sql.split("INSERT INTO public.imagenes_productos", 1)[1].split(
            ") AS x(id, producto_id, archivo)", 1
        )[0]
    except IndexError as exc:
        raise ValueError("No se encontró el bloque de imágenes del seed.sql") from exc
    images = [SeedImage(**match.groupdict()) for match in ROW.finditer(block)]
    if not images or len({image.product_id for image in images}) != len(images):
        raise ValueError("El seed no define una imagen única por producto")
    missing = sorted(
        {
            image.filename
            for image in images
            if not (ASSETS / image.filename).with_suffix(".jpg").is_file()
        }
    )
    if missing:
        raise FileNotFoundError(f"Faltan imágenes fuente en {ASSETS}: {', '.join(missing)}")
    return images


def load_env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    values = {}
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        values[name.strip()] = value.strip().strip("\"'")
    return values


def credentials(target: str, env_file: Path) -> tuple[str, str]:
    values = load_env_file(env_file)

    def get(name: str) -> str:
        return os.environ.get(name) or values.get(name, "")

    if target == "local":
        url = get("SUPABASE_URL") or "http://127.0.0.1:54321"
        key = get("SUPABASE_SERVICE_ROLE_KEY")
    else:
        url = get("SUPABASE_CLOUD_URL")
        key = get("SUPABASE_CLOUD_SERVICE_ROLE_KEY")
    parsed = urlparse(url)
    if target == "local" and (
        parsed.scheme != "http" or parsed.hostname not in {"localhost", "127.0.0.1"}
    ):
        raise ValueError("--target local requiere una URL HTTP de localhost")
    if target == "cloud" and (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.hostname in {"localhost", "127.0.0.1"}
    ):
        raise ValueError("--target cloud requiere SUPABASE_CLOUD_URL con HTTPS")
    if not key:
        name = (
            "SUPABASE_SERVICE_ROLE_KEY" if target == "local" else "SUPABASE_CLOUD_SERVICE_ROLE_KEY"
        )
        raise ValueError(f"Falta {name} en el entorno o en {env_file}")
    return url.rstrip("/"), key


def convert_sources(images: list[SeedImage]) -> dict[str, bytes]:
    converted = {}
    for filename in sorted({image.filename for image in images}):
        source = (ASSETS / filename).with_suffix(".jpg")
        try:
            with Image.open(source) as original:
                output = io.BytesIO()
                original.save(output, format="WEBP", quality=82, method=6)
                converted[filename] = output.getvalue()
        except (OSError, UnidentifiedImageError) as exc:
            raise ValueError(f"No se pudo convertir {source}: {exc}") from exc
    return converted


def check_response(response: httpx.Response, action: str) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise RuntimeError(f"{action}: HTTP {response.status_code}: {response.text[:300]}") from exc


def upload(url: str, key: str, images: list[SeedImage], converted: dict[str, bytes]) -> None:
    headers = {"apikey": key, "Authorization": f"Bearer {key}"}
    with httpx.Client(base_url=url, headers=headers, timeout=60.0) as client:
        ids = ",".join(image.image_id for image in images)
        response = client.get(
            "/rest/v1/imagenes_productos",
            params={"select": "id,producto_id,ruta_storage,nombre_archivo", "id": f"in.({ids})"},
        )
        check_response(response, "Consultar metadatos")
        rows = {row["id"]: row for row in response.json()}
        if len(rows) != len(images):
            raise ValueError(
                f"El destino tiene {len(rows)} de {len(images)} imágenes del seed; "
                "aplique primero las migraciones y seed.sql"
            )
        for image in images:
            row = rows[image.image_id]
            if row["producto_id"] != image.product_id or row["nombre_archivo"] != image.filename:
                raise ValueError(f"La imagen {image.image_id} no coincide con seed.sql")
            if row["ruta_storage"] not in {image.key, f"{BUCKET}/{image.key}"}:
                raise ValueError(f"La ruta de {image.image_id} no coincide con seed.sql")

        for index, image in enumerate(images, start=1):
            data = converted[image.filename]
            response = client.post(
                f"/storage/v1/object/{BUCKET}/{image.key}",
                content=data,
                headers={
                    "Content-Type": "image/webp",
                    "cache-control": "3600",
                    "x-upsert": "true",
                },
            )
            check_response(response, f"Subir {image.key}")
            response = client.patch(
                "/rest/v1/imagenes_productos",
                params={"id": f"eq.{image.image_id}"},
                json={
                    "ruta_storage": image.key,
                    "mime_type": "image/webp",
                    "tamano_bytes": len(data),
                },
                headers={"Prefer": "return=representation"},
            )
            check_response(response, f"Actualizar metadatos de {image.key}")
            if len(response.json()) != 1:
                raise RuntimeError(f"No se actualizó el registro de {image.key}")
            LOG.info("[%s/%s] %s (%s bytes)", index, len(images), image.key, len(data))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=("local", "cloud"), required=True)
    parser.add_argument("--env-file", type=Path, default=ROOT / "backend" / ".env")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    try:
        images = read_seed_images()
        converted = convert_sources(images)
        url, key = credentials(args.target, args.env_file)
        LOG.info("Destino: %s; %s productos, %s fuentes WebP", url, len(images), len(converted))
        upload(url, key, images, converted)
    except (ValueError, FileNotFoundError, RuntimeError, httpx.HTTPError):
        LOG.exception("Falló la carga de imágenes")
        return 1
    LOG.info("Carga terminada.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
