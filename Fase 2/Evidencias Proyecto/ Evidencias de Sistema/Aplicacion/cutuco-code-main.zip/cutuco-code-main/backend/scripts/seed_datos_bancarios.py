"""Seed de datos bancarios de prueba (cifrados con Fernet).

Uso (desde backend/):
    .\\.venv\\Scripts\\python.exe -m scripts.seed_datos_bancarios

Idempotente: si el perfil ya tiene una cuenta activa, se omite.
Imprime líneas `creada | perfil=... | ****NNNN` por cada inserción.
"""

import asyncio
from uuid import UUID

import asyncpg

from app.core.config import get_settings
from app.core.encryption import encrypt_text, hash_account, mask_account

# Perfiles reservados del seed: cliente + 5 perfiles de productores.
PERFILES = [
    UUID("a0000000-0000-0000-0000-000000000002"),
    *[UUID(f"a0000000-0000-0000-0000-00000000010{i}") for i in range(1, 6)],
]

CUENTAS = {
    # Titular/RUT coherentes con la postulación sembrada (12345678-5) para que
    # el trigger HAL-REG-014 también se ejerza con datos de prueba realistas.
    "a0000000-0000-0000-0000-000000000002": ("Banco Estado", "cuenta vista", "700000020001", "Cliente Santiago", 12345678),
    "a0000000-0000-0000-0000-000000000101": ("Banco de Chile", "cuenta corriente", "710001010010", "Productor Paine", 12345678),
    "a0000000-0000-0000-0000-000000000102": ("Banco Santander", "cuenta corriente", "720001020020", "Productor Melipilla", 12345678),
    "a0000000-0000-0000-0000-000000000103": ("BCI", "cuenta vista", "730001030030", "Productor Quillota", 12345678),
    "a0000000-0000-0000-0000-000000000104": ("Banco Estado", "cuenta rut", "740001040040", "Productor Pausado", 12345678),
    "a0000000-0000-0000-0000-000000000105": ("Scotiabank", "cuenta corriente", "750001050050", "Productor Cosecha", 12345678),
}


def _dv(body: int) -> str:
    total = sum(int(n) * (i % 6 + 2) for i, n in enumerate(reversed(str(body))))
    resto = 11 - total % 11
    return "0" if resto == 11 else "K" if resto == 10 else str(resto)


async def main() -> None:
    conn = await asyncpg.connect(get_settings().DATABASE_URL)
    try:
        creadas = 0
        for perfil in PERFILES:
            existe = await conn.fetchval(
                "SELECT 1 FROM public.datos_bancarios WHERE perfil_id=$1 AND activo=true",
                perfil,
            )
            banco, tipo, numero, titular, rut_body = CUENTAS[str(perfil)]
            rut = f"{rut_body}-{_dv(rut_body)}"
            if existe:
                print(f"existente | perfil={perfil} | {mask_account(numero)}")
                continue
            await conn.execute(
                """INSERT INTO public.datos_bancarios
                (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado,
                 numero_cuenta_hash, numero_cuenta_digitos, titular_cuenta, rut_titular)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8)""",
                perfil,
                banco,
                tipo,
                encrypt_text(numero),
                hash_account(numero),
                len(numero),
                titular,
                rut,
            )
            creadas += 1
            print(f"creada | perfil={perfil} | {mask_account(numero)}")
        print(f"total_creadas={creadas}")
    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(main())
