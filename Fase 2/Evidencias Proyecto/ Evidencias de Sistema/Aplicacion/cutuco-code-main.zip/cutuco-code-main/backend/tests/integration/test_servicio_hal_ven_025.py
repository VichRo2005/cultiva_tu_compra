"""HAL-VEN-025 / CK-0513 — /api/servicio/iniciar ante configuración faltante.

No debe devolver un 502 crudo: responde 503 con detail en español que nombra las
variables faltantes, y la cuota queda en estado coherente (sin token/buy_order
parciales). También se cubre el fallo de Webpay al crear: 502 con mensaje
controlado y cuota intacta (la transacción revierte).
"""

from uuid import UUID

import pytest

from app.core.config import get_settings
from app.core.exceptions import WebpayError
from app.integrations.webpay.plus_client import WebpayPlusClient

VENDEDOR_ID = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_ID = UUID("20000000-0000-0000-0000-000000000002")


async def _reset_cuota(conn):
    await conn.execute(
        """UPDATE public.pagos_servicio
        SET estado='pendiente', metodo=NULL, token_ws=NULL, buy_order=NULL,
            pagado_en=NULL, referencia=NULL, observaciones=NULL
        WHERE productor_id=$1""",
        PRODUCTOR_ID,
    )


async def _cuota(conn):
    return await conn.fetchrow(
        "SELECT estado, metodo, token_ws, buy_order FROM public.pagos_servicio "
        "WHERE productor_id=$1",
        PRODUCTOR_ID,
    )


@pytest.mark.asyncio
async def test_iniciar_sin_config_servicio_503_controlado_y_cuota_coherente(
    client, conn, mock_jwt, monkeypatch
):
    await _reset_cuota(conn)
    monkeypatch.setenv("TRANSBANK_SERVICIO_COMMERCE_CODE", "")
    monkeypatch.setenv("TRANSBANK_SERVICIO_API_KEY", "")
    monkeypatch.setenv("TRANSBANK_SERVICIO_RETURN_URL", "")
    get_settings.cache_clear()

    headers = {"Authorization": f"Bearer {mock_jwt(VENDEDOR_ID)}"}
    response = await client.post("/api/servicio/iniciar", headers=headers)

    assert response.status_code == 503, response.text
    detail = response.json()["detail"]
    assert "no está configurado" in detail
    assert "TRANSBANK_SERVICIO_COMMERCE_CODE" in detail
    assert "TRANSBANK_SERVICIO_API_KEY" in detail
    assert "TRANSBANK_SERVICIO_RETURN_URL" in detail

    # La cuota queda coherente: pendiente y sin restos de intento de pago.
    cuota = await _cuota(conn)
    assert cuota["estado"] == "pendiente"
    assert cuota["metodo"] is None
    assert cuota["token_ws"] is None
    assert cuota["buy_order"] is None


@pytest.mark.asyncio
async def test_iniciar_fallo_webpay_502_controlado_y_cuota_coherente(
    client, conn, mock_jwt, monkeypatch
):
    await _reset_cuota(conn)

    def _create_falla(self, *args, **kwargs):
        raise WebpayError("Webpay Plus create failed")

    monkeypatch.setattr(WebpayPlusClient, "create", _create_falla)

    headers = {"Authorization": f"Bearer {mock_jwt(VENDEDOR_ID)}"}
    response = await client.post("/api/servicio/iniciar", headers=headers)

    assert response.status_code == 502, response.text
    detail = response.json()["detail"]
    assert detail == "No fue posible iniciar el pago del servicio mensual con Webpay."

    cuota = await _cuota(conn)
    assert cuota["estado"] == "pendiente"
    assert cuota["token_ws"] is None
    assert cuota["buy_order"] is None
    assert cuota["metodo"] is None


@pytest.mark.asyncio
async def test_iniciar_sin_sesion_401(client):
    response = await client.post("/api/servicio/iniciar")
    assert response.status_code == 401
