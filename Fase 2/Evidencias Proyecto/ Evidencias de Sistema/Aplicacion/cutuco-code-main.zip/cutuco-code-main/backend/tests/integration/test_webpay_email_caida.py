"""CK-0028(b) — una caída total de Brevo NO debe impedir completar la operación
principal: el pedido queda pagado y el correo queda pendiente (bandera en NULL)
para reintento, sin romper la confirmación de Webpay.
"""

from uuid import UUID


async def test_brevo_caido_no_impide_pedido_pagado(client, checkout, conn, mock_email):
    # EmailClient.send lanza excepción en TODOS los intentos: enviar_pendiente
    # la atrapa (el pago ya se committeó) y no marca el correo como enviado.
    mock_email.side_effect = RuntimeError("Brevo completamente caído")

    response = await client.post(
        "/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]}
    )

    assert response.status_code == 200, response.text
    result = response.json()
    assert result["ok"] and result["estado"] == "autorizado"
    assert result["pedidos"][0]["estado_pedido"] == "pagado"

    pedido_id = UUID(result["pedidos"][0]["pedido_id"])
    # El pago y el pedido existen y son coherentes pese a la caída del correo.
    assert (
        await conn.fetchval("SELECT estado FROM public.pedidos WHERE id=$1", pedido_id)
        == "pagado"
    )
    assert (
        await conn.fetchval("SELECT count(*) FROM public.pagos WHERE pedido_id=$1", pedido_id) == 1
    )
    # Los envíos de correo NO quedaron marcados: se reintentan en la siguiente
    # consulta de estado (idempotentes por bandera + idempotency key).
    fila = await conn.fetchrow(
        "SELECT correo_comprador_enviado_en, correo_productor_enviado_en "
        "FROM public.pedidos WHERE id=$1",
        pedido_id,
    )
    assert fila["correo_comprador_enviado_en"] is None
    assert fila["correo_productor_enviado_en"] is None
    # Se intentó enviar ambos correos (y fallaron sin propagar la excepción).
    assert mock_email.await_count == 2


async def test_reintento_de_correo_no_duplica_pedido_ni_pago(
    client, checkout, conn, mock_email, mock_transbank
):
    """Tras la caída, re-confirmar devuelve ya_confirmado sin nuevo commit y
    re-agenda el correo pendiente sin duplicar pedido ni pago."""
    mock_email.side_effect = RuntimeError("Brevo caído")
    first = await client.post(
        "/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]}
    )
    assert first.status_code == 200, first.text

    mock_email.side_effect = None  # vuelve a enviar OK (return_value=True)
    second = await client.post(
        "/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]}
    )
    assert second.status_code == 200
    assert second.json()["ya_confirmado"] is True
    assert mock_transbank["commit"].call_count == 1  # commit único

    checkout_id = UUID(checkout["checkout_id"])
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1", checkout_id
        )
        == 1
    )
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
        )
        == 1
    )
    # El correo pendiente se re-agendó (2 intentos previos fallidos + 2 ahora).
    assert mock_email.await_count == 4
    fila = await conn.fetchrow(
        "SELECT correo_comprador_enviado_en, correo_productor_enviado_en "
        "FROM public.pedidos WHERE checkout_id=$1",
        checkout_id,
    )
    assert fila["correo_comprador_enviado_en"] is not None
    assert fila["correo_productor_enviado_en"] is not None
