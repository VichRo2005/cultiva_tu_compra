"""Validate purchasable quantities against the server's product and stock."""

from decimal import Decimal
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest
from fastapi import HTTPException

from app.schemas.webpay import ItemRequest
from app.services import webpay_service as service


@pytest.mark.asyncio
@pytest.mark.parametrize("unidad", ["unidad", "bandeja", "caja", "docena"])
async def test_unidad_discreta_rechaza_fraccion(monkeypatch, unidad):
    producto_id = uuid4()
    monkeypatch.setattr(
        service.productos_repo,
        "get_by_ids_for_update",
        AsyncMock(return_value=[{"id": producto_id, "unidad_medida": unidad}]),
    )
    with pytest.raises(HTTPException, match="cantidad entera") as error:
        await service._items_checkout(
            None, [ItemRequest(producto_id=producto_id, cantidad=Decimal("1.5"))]
        )
    assert error.value.status_code == 400


@pytest.mark.asyncio
async def test_peso_fraccionado_y_lineas_repetidas_respetan_reservas(monkeypatch):
    producto_id, productor_id = uuid4(), uuid4()
    producto = {
        "id": producto_id,
        "productor_id": productor_id,
        "unidad_medida": "kg",
        "nombre": "Tomates",
        "activo": True,
        "eliminado_en": None,
        "stock": Decimal("3"),
        "stock_reservado": Decimal("1"),
        "precio": Decimal("2000"),
    }
    monkeypatch.setattr(
        service.productos_repo, "get_by_ids_for_update", AsyncMock(return_value=[producto])
    )
    item = ItemRequest(producto_id=producto_id, cantidad=Decimal("1.5"))
    grupos = await service._items_checkout(None, [item])
    assert grupos[productor_id][0]["subtotal"] == Decimal("3000")
    with pytest.raises(HTTPException, match="Stock insuficiente"):
        await service._items_checkout(None, [item, item])


@pytest.mark.parametrize(
    "precio,cantidad,esperado",
    [
        ("1", "0.1", "0.10"),
        ("1001", "0.5", "500.50"),
        ("2800", "0.5", "1400.00"),
        ("10", "0.1", "1.00"),
    ],
)
async def test_subtotal_decimal_equivale_a_la_vista(monkeypatch, precio, cantidad, esperado):
    producto_id, productor_id = uuid4(), uuid4()
    producto = {
        "id": producto_id,
        "productor_id": productor_id,
        "unidad_medida": "kg",
        "nombre": "Prueba precisión",
        "activo": True,
        "eliminado_en": None,
        "stock": Decimal("10"),
        "stock_reservado": Decimal("0"),
        "precio": Decimal(precio),
        "incremento_venta": Decimal("0.1"),
        "cantidad_minima_compra": Decimal("0.1"),
    }
    monkeypatch.setattr(
        service.productos_repo, "get_by_ids_for_update", AsyncMock(return_value=[producto])
    )
    grupos = await service._items_checkout(
        None, [ItemRequest(producto_id=producto_id, cantidad=Decimal(cantidad))]
    )
    assert grupos[productor_id][0]["subtotal"] == Decimal(esperado)


@pytest.mark.asyncio
async def test_checkout_respeta_minimo_e_incremento_definidos_por_vendedor(monkeypatch):
    producto_id, productor_id = uuid4(), uuid4()
    producto = {
        "id": producto_id,
        "productor_id": productor_id,
        "unidad_medida": "kg",
        "nombre": "Papas",
        "activo": True,
        "eliminado_en": None,
        "stock": Decimal("10"),
        "stock_reservado": Decimal("0"),
        "precio": Decimal("1000"),
        "incremento_venta": Decimal("0.5"),
        "cantidad_minima_compra": Decimal("2"),
    }
    monkeypatch.setattr(
        service.productos_repo, "get_by_ids_for_update", AsyncMock(return_value=[producto])
    )

    with pytest.raises(HTTPException, match="compra mínima") as minimo:
        await service._items_checkout(
            None, [ItemRequest(producto_id=producto_id, cantidad=Decimal("1.5"))]
        )
    assert minimo.value.status_code == 400

    with pytest.raises(HTTPException, match="incrementos") as incremento:
        await service._items_checkout(
            None, [ItemRequest(producto_id=producto_id, cantidad=Decimal("2.2"))]
        )
    assert incremento.value.status_code == 400

    grupos = await service._items_checkout(
        None, [ItemRequest(producto_id=producto_id, cantidad=Decimal("2.5"))]
    )
    assert grupos[productor_id][0]["cantidad"] == Decimal("2.5")
