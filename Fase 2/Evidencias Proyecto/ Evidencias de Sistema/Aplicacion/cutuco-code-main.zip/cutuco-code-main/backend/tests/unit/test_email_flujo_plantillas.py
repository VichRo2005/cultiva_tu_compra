"""CK-0282(d) — las plantillas compra_comprador y nuevo_pedido_* se invocan
en el flujo de envío (email_service), no sólo existen en disco.

El vendedor del dominio se modela como "productor", así que la plantilla del
vendedor es nuevo_pedido_productor.{html,txt}.
"""

from pathlib import Path

from app.integrations.email import client as email_client
from app.services import email_service


class _ClienteFalso:
    def __init__(self):
        self.rendered: list[str] = []
        self.sent: list[dict] = []

    def render(self, template_name, context):
        self.rendered.append(template_name)
        return f"rendered:{template_name}"

    async def send(self, to, subject, html, text=None, attachment=None):
        self.sent.append(
            {"to": to, "subject": subject, "html": html, "text": text, "attachment": attachment}
        )
        return True


PEDIDO = {"id": "pedido-1", "codigo_pedido": "CTC-20261114-ABC123", "total": 8500}


def _patch_client(monkeypatch, fake):
    monkeypatch.setattr(email_service, "_client", lambda pedido, tipo: fake)


async def test_flujo_comprador_usa_plantilla_compra_comprador(monkeypatch):
    fake = _ClienteFalso()
    _patch_client(monkeypatch, fake)

    ok = await email_service.enviar_correo_compra_comprador(
        "comprador@example.com", PEDIDO, PEDIDO, [], "http://localhost:3000/"
    )

    assert ok is True
    assert fake.rendered == ["compra_comprador.html", "compra_comprador.txt"]
    assert len(fake.sent) == 1
    envio = fake.sent[0]
    assert envio["to"] == "comprador@example.com"
    assert "CTC-20261114-ABC123" in envio["subject"]
    assert envio["html"] == "rendered:compra_comprador.html"
    assert envio["text"] == "rendered:compra_comprador.txt"


async def test_flujo_vendedor_usa_plantilla_nuevo_pedido_productor(monkeypatch):
    fake = _ClienteFalso()
    _patch_client(monkeypatch, fake)

    ok = await email_service.enviar_correo_nuevo_pedido_productor(
        "productor@example.com",
        PEDIDO,
        {"cliente_nombre": "Ana"},
        PEDIDO,
        [],
        8000,
    )

    assert ok is True
    assert fake.rendered == ["nuevo_pedido_productor.html", "nuevo_pedido_productor.txt"]
    assert len(fake.sent) == 1
    envio = fake.sent[0]
    assert envio["to"] == "productor@example.com"
    assert envio["subject"] == "Nuevo pedido CTC-20261114-ABC123"
    assert envio["html"] == "rendered:nuevo_pedido_productor.html"
    assert envio["text"] == "rendered:nuevo_pedido_productor.txt"


async def test_resolucion_aprobada_usa_plantilla_y_mensaje_automatico(monkeypatch):
    fake = _ClienteFalso()
    monkeypatch.setattr(email_service, "_client_notificacion_postulacion", lambda _: fake)

    ok = await email_service.enviar_correo_resolucion_postulacion(
        "vendedor@example.com",
        {
            "id": "post-1",
            "intento": 1,
            "estado": "aprobada",
            "observaciones_admin": None,
            "nombre_comercial_solicitado": "Huerto Norte",
        },
        "Ana",
    )

    assert ok is True
    assert fake.rendered == ["postulacion_resuelta.html", "postulacion_resuelta.txt"]
    assert fake.sent[0]["to"] == "vendedor@example.com"
    assert fake.sent[0]["subject"] == "Tu postulación fue aprobada · CuTuCo"


async def test_resolucion_rechazada_informa_observacion_admin(monkeypatch):
    fake = _ClienteFalso()
    monkeypatch.setattr(email_service, "_client_notificacion_postulacion", lambda _: fake)

    ok = await email_service.enviar_correo_resolucion_postulacion(
        "vendedor@example.com",
        {
            "id": "post-2",
            "intento": 2,
            "estado": "rechazada",
            "observaciones_admin": "Falta adjuntar el certificado tributario.",
            "nombre_comercial_solicitado": "Huerto Norte",
        },
        "Ana",
    )

    assert ok is True
    assert fake.sent[0]["subject"] == "Tu postulación fue rechazada · CuTuCo"


async def test_recuperacion_usa_brevo_y_plantillas_propias(monkeypatch):
    fake = _ClienteFalso()
    monkeypatch.setattr(email_service, "EmailClient", lambda *args, **kwargs: fake)

    ok = await email_service.enviar_correo_recuperacion_contrasena(
        "cliente@example.com", "https://auth.example.test/recovery?token=seguro"
    )

    assert ok is True
    assert fake.rendered == ["recuperacion_contrasena.html", "recuperacion_contrasena.txt"]
    assert fake.sent[0]["to"] == "cliente@example.com"
    assert fake.sent[0]["subject"] == "Recupera tu contraseña de CuTuCo"


async def test_plantillas_existen_en_disco():
    plantillas = Path(email_client.__file__).parent / "templates"
    for nombre in (
        "compra_comprador.html",
        "compra_comprador.txt",
        "nuevo_pedido_productor.html",
        "nuevo_pedido_productor.txt",
        "postulacion_resuelta.html",
        "postulacion_resuelta.txt",
        "recuperacion_contrasena.html",
        "recuperacion_contrasena.txt",
    ):
        assert (plantillas / nombre).is_file(), nombre
