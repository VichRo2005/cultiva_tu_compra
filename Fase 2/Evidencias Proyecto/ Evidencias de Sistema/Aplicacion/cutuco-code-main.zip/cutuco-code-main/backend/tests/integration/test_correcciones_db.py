"""Pruebas de las constraints/RPC nuevas contra Supabase local.

Cubren HAL-CLI-010/021/022, HAL-REG-001/004/006/010/013/014/019 y
HAL-VEN-005/014/016/018/026/028/029.
"""

import json
from datetime import timedelta

import asyncpg
import pytest

from app.core.encryption import hash_account

CLIENTE_ID = "a0000000-0000-0000-0000-000000000002"


async def _set_auth(conn, user_id):
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE authenticated")
    await conn.execute(
        "SELECT set_config('request.jwt.claims', $1, true)",
        json.dumps({"sub": str(user_id), "role": "authenticated"}),
    )


async def _reset_auth(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims', '', true)")


async def test_bucket_documentos_10_mib(conn):
    row = await conn.fetchrow(
        "SELECT file_size_limit FROM storage.buckets WHERE id='vendedor-documentos'"
    )
    assert row["file_size_limit"] == 10_485_760


async def test_pago_deja_pedido_pagado_y_preparado_en_null(conn, paid_checkout):
    pedido = await conn.fetchrow(
        "SELECT estado FROM public.pedidos WHERE id=$1", paid_checkout["pedido_id"]
    )
    envio = await conn.fetchrow(
        "SELECT estado, preparado_en FROM public.envios WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    assert pedido["estado"] == "pagado"
    assert envio["estado"] == "preparacion"
    assert envio["preparado_en"] is None


async def test_marcar_preparacion_rpc_es_idempotente(conn, paid_checkout):
    row = await conn.fetchrow(
        """SELECT e.id AS envio_id, pr.perfil_id AS seller_id
        FROM public.envios e
        JOIN public.pedidos p ON p.id=e.pedido_id
        JOIN public.productores pr ON pr.id=p.productor_id
        WHERE p.id=$1""",
        paid_checkout["pedido_id"],
    )
    await _set_auth(conn, row["seller_id"])

    first = json.loads(
        await conn.fetchval(
            "SELECT public.marcar_pedido_en_preparacion($1)", paid_checkout["pedido_id"]
        )
    )
    second = json.loads(
        await conn.fetchval(
            "SELECT public.marcar_pedido_en_preparacion($1)", paid_checkout["pedido_id"]
        )
    )
    assert first["estado"] == second["estado"] == "en_preparacion"
    assert first["preparado_en"] is not None
    assert second["preparado_en"] == first["preparado_en"]

    pedido = await conn.fetchrow(
        "SELECT estado FROM public.pedidos WHERE id=$1", paid_checkout["pedido_id"]
    )
    assert pedido["estado"] == "en_preparacion"


async def test_codigo_cliente_y_confirmacion_vendedor(conn, paid_checkout):
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    row = await conn.fetchrow(
        """SELECT e.id AS envio_id, e.codigo_verificacion, pr.perfil_id AS seller_id
        FROM public.envios e
        JOIN public.pedidos p ON p.id=e.pedido_id
        JOIN public.productores pr ON pr.id=p.productor_id
        WHERE p.id=$1""",
        paid_checkout["pedido_id"],
    )
    assert row["codigo_verificacion"]

    # El cliente sí puede obtenerlo.
    await _set_auth(conn, CLIENTE_ID)
    codigo = await conn.fetchval(
        "SELECT public.obtener_codigo_entrega($1)", row["envio_id"]
    )
    assert codigo == row["codigo_verificacion"]

    # El vendedor no puede leer la columna ni obtenerlo por RPC.
    await _set_auth(conn, row["seller_id"])
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.fetchval(
                "SELECT codigo_verificacion FROM public.envios WHERE id=$1",
                row["envio_id"],
            )
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.fetchval(
                "SELECT public.obtener_codigo_entrega($1)", row["envio_id"]
            )

    # Confirmación idempotente y con error genérico si el código es incorrecto.
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.fetchval(
                "SELECT public.verificar_codigo_entrega_vendedor($1, $2)",
                row["envio_id"],
                "CODIGO-MALO",
            )
    assert "invalido" in str(exc.value).lower()

    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)",
        row["envio_id"],
        codigo,
    )
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)",
        row["envio_id"],
        codigo,
    )


async def test_cancelacion_vendedor_propaga_cancelado_y_motivo(conn, paid_checkout):
    row = await conn.fetchrow(
        """SELECT e.id AS envio_id, pr.perfil_id AS seller_id
        FROM public.envios e
        JOIN public.pedidos p ON p.id=e.pedido_id
        JOIN public.productores pr ON pr.id=p.productor_id
        WHERE p.id=$1""",
        paid_checkout["pedido_id"],
    )
    await _set_auth(conn, row["seller_id"])
    first = json.loads(
        await conn.fetchval(
            "SELECT public.cancelar_pedido_vendedor($1, $2)",
            paid_checkout["pedido_id"],
            "Cancelado por el vendedor: producto agotado",
        )
    )
    assert first["estado"] == "cancelado" and first["ya_cancelado"] is False

    second = json.loads(
        await conn.fetchval(
            "SELECT public.cancelar_pedido_vendedor($1, $2)",
            paid_checkout["pedido_id"],
            "Otro motivo",
        )
    )
    assert second["ya_cancelado"] is True

    await _reset_auth(conn)
    pedido = await conn.fetchrow(
        "SELECT estado, motivo_cancelacion FROM public.pedidos WHERE id=$1",
        paid_checkout["pedido_id"],
    )
    envio = await conn.fetchrow(
        "SELECT estado, motivo_cancelacion, cancelado_en FROM public.envios WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    assert pedido["estado"] == "cancelado"
    assert pedido["motivo_cancelacion"].startswith("Cancelado por el vendedor")
    assert envio["estado"] == "cancelado"
    assert envio["motivo_cancelacion"].startswith("Cancelado por el vendedor")
    assert envio["cancelado_en"] is not None


async def test_editar_producto_ajeno_devuelve_403_funcional(conn):
    row = await conn.fetchrow(
        """SELECT p.id AS producto_id, pr.perfil_id AS owner_id
        FROM public.productos p JOIN public.productores pr ON pr.id=p.productor_id
            WHERE pr.activo AND p.activo AND p.eliminado_en IS NULL
        ORDER BY p.id LIMIT 1"""
    )
    otro = await conn.fetchval(
        """SELECT pr.perfil_id FROM public.productores pr
        WHERE pr.activo AND pr.perfil_id <> $1 LIMIT 1""",
        row["owner_id"],
    )
    await _set_auth(conn, otro)
    with pytest.raises(asyncpg.InsufficientPrivilegeError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.productos SET precio=precio+1 WHERE id=$1",
                row["producto_id"],
            )
    assert "no te pertenece" in str(exc.value)


async def test_slug_productor_simbolos_y_colisiones(conn):
    # Fixture independiente del seed opcional de galería.
    # Usa UUIDs únicos que no colisionan con gallery_dev.sql
    await conn.execute(
        "INSERT INTO auth.users (id, email, raw_user_meta_data) "
        "VALUES ('f0000000-0000-0000-0000-000000000001', "
        "'slug-checklist-1@example.test', '{\"nombre\":\"Prueba\",\"apellido\":\"Slug\"}')"
    )
    await conn.execute(
        "INSERT INTO public.productores (perfil_id, nombre_comercial) "
        "VALUES ('f0000000-0000-0000-0000-000000000001', '***')"
    )
    primero = await conn.fetchrow(
        "SELECT slug FROM public.productores WHERE perfil_id='f0000000-0000-0000-0000-000000000001'"
    )
    assert primero["slug"] == "productor"

    await conn.execute(
        "INSERT INTO auth.users (id, email, raw_user_meta_data) "
        "VALUES ('f0000000-0000-0000-0000-000000000002', "
        "'slug-checklist-2@example.test', '{\"nombre\":\"Prueba2\",\"apellido\":\"Slug\"}')"
    )
    await conn.execute(
        "INSERT INTO public.productores (perfil_id, nombre_comercial) "
        "VALUES ('f0000000-0000-0000-0000-000000000002', '###')"
    )
    segundo = await conn.fetchrow(
        "SELECT slug FROM public.productores WHERE perfil_id='f0000000-0000-0000-0000-000000000002'"
    )
    assert segundo["slug"] == "productor-2"
    for fila in (primero, segundo):
        assert fila["slug"] and fila["slug"] == fila["slug"].lower()
        assert " " not in fila["slug"]


async def test_telefono_no_se_puede_quitar_desde_api(conn):
    await _set_auth(conn, CLIENTE_ID)
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.perfiles SET telefono=NULL WHERE id=$1", CLIENTE_ID
            )
    assert "teléfono" in str(exc.value).lower()


async def test_motivo_fallo_maximo_1000(conn, paid_checkout):
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.envios SET estado='fallido', motivo_fallo=$2 WHERE pedido_id=$1",
                paid_checkout["pedido_id"],
                "x" * 1001,
            )
    assert "1000" in str(exc.value)


async def test_pausa_productor_sin_motivo_usa_justificacion_funcional(conn):
    row = await conn.fetchrow(
        """SELECT p.id AS producto_id, pr.perfil_id AS owner_id
        FROM public.productos p
        JOIN public.productores pr ON pr.id=p.productor_id
        JOIN public.perfiles pf ON pf.id=pr.perfil_id
        WHERE pr.activo AND pf.activo AND pf.rol='vendedor'
          AND p.activo AND p.eliminado_en IS NULL
        LIMIT 1"""
    )
    await _set_auth(conn, row["owner_id"])
    await conn.execute(
        "UPDATE public.productos SET activo=false WHERE id=$1", row["producto_id"]
    )
    pausado = await conn.fetchrow(
        "SELECT motivo_pausa FROM public.productos WHERE id=$1", row["producto_id"]
    )
    assert pausado["motivo_pausa"] == "Pausado manualmente por el productor"


async def test_limites_numericos_producto(conn):
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.productos
                (productor_id, nombre, precio, stock, unidad_medida)
                VALUES ((SELECT id FROM public.productores LIMIT 1), 'Precio negativo',
                        -1, 1, 'unidad')"""
            )
    assert "precio" in str(exc.value).lower()

    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.productos
                (productor_id, nombre, precio, stock, unidad_medida)
                VALUES ((SELECT id FROM public.productores LIMIT 1), 'Stock negativo',
                        1000, -1, 'unidad')"""
            )
    assert "stock" in str(exc.value).lower()


async def test_direccion_numero_opcional_alfanumerico(conn):
    comuna = await conn.fetchval("SELECT id FROM public.comunas LIMIT 1")
    fila = await conn.fetchrow(
        """INSERT INTO public.direcciones
        (perfil_id, comuna_id, calle, numero, depto_oficina, referencia, es_principal)
        VALUES ($1,$2,'Calle Rural','S/N','Depto 4',NULL,false) RETURNING id""",
        CLIENTE_ID,
        comuna,
    )
    assert fila["id"]

    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.direcciones SET numero='###' WHERE id=$1", fila["id"]
            )
    assert "letras o números" in str(exc.value)

    # El trigger responde en español cuando la columna es text; en bases que
    # aún tengan varchar(50) PostgreSQL corta antes. Ambos casos son un error
    # controlado de longitud, nunca un 500 técnico expuesto.
    with pytest.raises(asyncpg.PostgresError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.direcciones SET depto_oficina=$2 WHERE id=$1",
                fila["id"],
                "x" * 51,
            )
    assert "50" in str(exc.value)


async def test_datos_bancarios_duplicados_en_bd(conn):
    numero = "9876543210"
    row_user = await conn.fetchrow(
        "SELECT id FROM public.perfiles WHERE id=$1", "a0000000-0000-0000-0000-000000000101"
    )
    other = await conn.fetchval(
        "SELECT id FROM public.perfiles WHERE id=$1", "a0000000-0000-0000-0000-000000000102"
    )
    await conn.execute(
        "DELETE FROM public.datos_bancarios WHERE perfil_id IN ($1,$2)", row_user["id"], other
    )
    hash_cuenta = hash_account(numero)
    await conn.execute(
        """INSERT INTO public.datos_bancarios
        (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, numero_cuenta_hash,
         numero_cuenta_digitos, titular_cuenta, rut_titular)
        VALUES ($1,'Banco Test','cuenta_corriente',decode('00','hex'),$2,10,
                'Productor Paine','12345678-5')""",
        row_user["id"],
        hash_cuenta,
    )
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.datos_bancarios
                (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, numero_cuenta_hash,
                 numero_cuenta_digitos, titular_cuenta, rut_titular)
                VALUES ($1,'Banco Test','cuenta_corriente',decode('00','hex'),$2,10,
                        'Productor Melipilla','12345678-5')""",
                other,
                hash_cuenta,
            )
    assert "Ya existe una cuenta bancaria" in str(exc.value)


async def test_servicio_fechas_coherentes(conn):
    row = await conn.fetchrow(
        """SELECT emitido_en, vence_en FROM public.pagos_servicio
        ORDER BY periodo DESC LIMIT 1"""
    )
    assert row["emitido_en"] is not None
    assert row["vence_en"] == row["emitido_en"] + timedelta(days=10)

    # La emisión de una cuota nueva es idempotente por período.
    productor = await conn.fetchval("SELECT id FROM public.productores LIMIT 1")
    await conn.execute("SELECT private.crear_cuota_servicio($1)", productor)
    await conn.execute("SELECT private.crear_cuota_servicio($1)", productor)
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos_servicio WHERE productor_id=$1", productor
        )
        == 1
    )


async def test_categorias_mascotas_y_duplicados_ocultos(conn):
    assert (
        await conn.fetchval(
            """SELECT count(*) FROM public.categorias
            WHERE eliminado_en IS NULL
              AND (lower(btrim(nombre))='alimentos para mascotas'
                   OR lower(btrim(slug)) LIKE '%mascota%')"""
        )
        == 0
    )
    assert (
        await conn.fetchval(
            """SELECT count(*) FROM (
              SELECT lower(btrim(nombre)) FROM public.categorias
              WHERE eliminado_en IS NULL
              GROUP BY 1 HAVING count(*) > 1
            ) d"""
        )
        == 0
    )
    assert (
        await conn.fetchval(
            """SELECT count(*) FROM public.categorias
            WHERE id='00000000-0000-0000-0000-000000000001' AND eliminado_en IS NULL"""
        )
        == 1
    )


async def test_evidencias_sin_acceso_api(conn):
    assert await conn.fetchval(
        "SELECT NOT has_table_privilege('authenticated', 'public.evidencias_envio', 'SELECT')"
    )
    assert not await conn.fetchval(
        "SELECT EXISTS (SELECT 1 FROM pg_policy WHERE polrelid='public.evidencias_envio'::regclass)"
    )
