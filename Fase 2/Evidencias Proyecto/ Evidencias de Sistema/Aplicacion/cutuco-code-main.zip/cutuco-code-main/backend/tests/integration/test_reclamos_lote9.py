"""Lote 9 — Reclamos: aislamiento, flujo admin y protección del original,
ejecutado contra PG16 real (CK-0178/0182/0183/0185/0187/0189/0193/0194/0197/0198).
CK-0192 (p95) queda fuera: medición en staging.
"""

import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
OTRO_CLIENTE = UUID("a0000000-0000-0000-0000-000000000103")  # otro perfil (productor Quillota), no dueño del pedido
ADMIN = UUID("a0000000-0000-0000-0000-000000000001")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def crear_reclamo(conn, pedido_id, cliente=CLIENTE):
    return await conn.fetchval(
        """INSERT INTO public.reclamos (pedido_id, cliente_id, motivo, descripcion)
           VALUES ($1,$2,'Producto dañado','Llegó dañado.') RETURNING id""",
        pedido_id,
        cliente,
    )


async def test_ck_0178_reclamo_de_pedido_ajeno_rechazado(conn, paid_checkout):
    await autenticar(conn, OTRO_CLIENTE)
    with pytest.raises(asyncpg.PostgresError):
        async with conn.transaction():
            await crear_reclamo(conn, paid_checkout["pedido_id"], cliente=OTRO_CLIENTE)
    await reset(conn)
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.reclamos WHERE pedido_id=$1",
            paid_checkout["pedido_id"],
        )
        == 0
    )


async def test_ck_0182_otro_vendedor_no_responde(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    otro_vendedor = await conn.fetchval(
        """SELECT pr.perfil_id FROM public.productores pr
           WHERE pr.perfil_id <> (SELECT pr2.perfil_id FROM public.pedidos p
             JOIN public.productores pr2 ON pr2.id=p.productor_id WHERE p.id=$1)
           LIMIT 1""",
        paid_checkout["pedido_id"],
    )
    await autenticar(conn, otro_vendedor)
    # la RLS no le da acceso al reclamo: el UPDATE afecta 0 filas (silencioso, sin revelar nada)
    status = await conn.execute(
        "UPDATE public.reclamos SET respuesta_productor='intento' WHERE id=$1", reclamo
    )
    assert status == "UPDATE 0"
    await reset(conn)
    assert (
        await conn.fetchval(
            "SELECT respuesta_productor IS NULL FROM public.reclamos WHERE id=$1", reclamo
        )
        is True
    )


async def test_ck_0183_0185_0187_admin_revisa_rechaza_y_vendedor_ve(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    vendedor = await conn.fetchval(
        """SELECT pr.perfil_id FROM public.pedidos p
           JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1""",
        paid_checkout["pedido_id"],
    )
    # otro cliente no ve el reclamo
    await autenticar(conn, OTRO_CLIENTE)
    assert (
        await conn.fetchval("SELECT count(*) FROM public.reclamos WHERE id=$1", reclamo) == 0
    )
    # admin lo ve, pasa a revisión y luego lo rechaza con responsable y fecha
    await autenticar(conn, ADMIN)
    assert (
        await conn.fetchval("SELECT count(*) FROM public.reclamos WHERE id=$1", reclamo) == 1
    )
    await conn.execute(
        "UPDATE public.reclamos SET estado='en_revision' WHERE id=$1", reclamo
    )
    await conn.execute(
        "UPDATE public.reclamos SET estado='rechazado', resuelto_por=$2, resuelto_en=now() WHERE id=$1",
        reclamo,
        ADMIN,
    )
    # el vendedor del pedido ve la decisión (CK-0187)
    await autenticar(conn, vendedor)
    fila = await conn.fetchrow("SELECT estado, resuelto_por, resuelto_en FROM public.reclamos WHERE id=$1", reclamo)
    assert fila["estado"] == "rechazado" and fila["resuelto_por"] == ADMIN and fila["resuelto_en"]


async def test_ck_0189_doble_resolucion_no_duplica_efectos(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.reclamos SET estado='resuelto', resuelto_por=$2, resuelto_en=now() WHERE id=$1",
        reclamo, ADMIN,
    )
    primera = await conn.fetchrow(
        "SELECT resuelto_por, resuelto_en FROM public.reclamos WHERE id=$1", reclamo
    )
    # segunda confirmación de la misma resolución: un único registro final trazable
    await conn.execute(
        "UPDATE public.reclamos SET estado='resuelto' WHERE id=$1 AND estado='resuelto'", reclamo
    )
    segunda = await conn.fetchrow(
        "SELECT resuelto_por, resuelto_en, actualizado_en FROM public.reclamos WHERE id=$1", reclamo
    )
    assert segunda["resuelto_por"] == primera["resuelto_por"] == ADMIN
    assert segunda["resuelto_en"] == primera["resuelto_en"]
    assert (
        await conn.fetchval("SELECT count(*) FROM public.reclamos WHERE id=$1", reclamo) == 1
    )


async def test_ck_0193_reclamo_original_inmutable(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    # la RLS no permite al cliente actualizar reclamos: 0 filas, sin error que revele datos
    status = await conn.execute(
        "UPDATE public.reclamos SET motivo='cambiado', descripcion='cambiada' WHERE id=$1",
        reclamo,
    )
    assert status == "UPDATE 0"
    await reset(conn)
    fila = await conn.fetchrow(
        "SELECT motivo, descripcion FROM public.reclamos WHERE id=$1", reclamo
    )
    assert fila["motivo"] == "Producto dañado" and fila["descripcion"] == "Llegó dañado."


async def test_ck_0194_reclamo_disponible_en_estados_dc07(conn, paid_checkout):
    # DC-07: el reclamo nace abierto sobre cualquier pedido propio (incluye
    # pagado/en preparación, en tránsito y entrega fallida: ningún estado queda sin canal)
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])  # pedido 'pagado'
    assert reclamo
    fila = await conn.fetchval("SELECT estado FROM public.reclamos WHERE id=$1", reclamo)
    assert fila == "abierto"
    with pytest.raises(asyncpg.RaiseError, match="abierto"):
        async with conn.transaction():
            await conn.execute(
                "INSERT INTO public.reclamos (pedido_id, cliente_id, estado, motivo, descripcion) "
                "VALUES ($1,$2,'resuelto','x','y')",
                paid_checkout["pedido_id"], CLIENTE,
            )


async def test_ck_0197_respuesta_bloqueada_tras_cierre(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    vendedor = await conn.fetchval(
        """SELECT pr.perfil_id FROM public.pedidos p
           JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1""",
        paid_checkout["pedido_id"],
    )
    await autenticar(conn, vendedor)
    await conn.execute(
        "UPDATE public.reclamos SET respuesta_productor='respuesta inicial' WHERE id=$1", reclamo
    )
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.reclamos SET estado='resuelto', resuelto_por=$2, resuelto_en=now() WHERE id=$1",
        reclamo, ADMIN,
    )
    await autenticar(conn, vendedor)
    with pytest.raises(asyncpg.RaiseError, match="cerrado"):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.reclamos SET respuesta_productor='cambio tardío' WHERE id=$1",
                reclamo,
            )


async def test_ck_0198_admin_conserva_canal_con_vendedor_sancionado(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    reclamo = await crear_reclamo(conn, paid_checkout["pedido_id"])
    # simula vendedor sancionado: suspensión activa impuesta por el admin
    await autenticar(conn, ADMIN)
    await conn.execute(
        """INSERT INTO public.sanciones (productor_id, tipo, accion, motivo, duracion_dias, impuesta_por)
           SELECT p.productor_id, 'suspension'::public.tipo_sancion, 'suspender'::public.accion_sancion,
                  'Suspensión derivada del reclamo ' || $2, 30, $3
           FROM public.pedidos p WHERE p.id=$1""",
        paid_checkout["pedido_id"],
        str(reclamo),
        ADMIN,
    )
    fila = await conn.fetchrow(
        "SELECT estado, motivo FROM public.reclamos WHERE id=$1", reclamo
    )
    assert fila and fila["estado"] == "abierto"
    await conn.execute(
        "UPDATE public.reclamos SET estado='en_revision' WHERE id=$1", reclamo
    )
    assert (
        await conn.fetchval("SELECT estado FROM public.reclamos WHERE id=$1", reclamo)
        == "en_revision"
    )
