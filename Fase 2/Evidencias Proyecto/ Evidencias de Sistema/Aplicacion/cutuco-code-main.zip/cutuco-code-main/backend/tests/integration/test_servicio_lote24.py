"""Lote 24 — Servicio mensual: CK-0258 (transferencia de monto distinto).

La resolución administrativa de una transferencia no marca la cuota como
pagada sin constancia registrada del monto recibido y el beneficiario
(migración 20261106120000). Corre contra PG16 real (QA efímero).
"""

import json
from uuid import UUID

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
PERFIL_P3 = UUID("a0000000-0000-0000-0000-000000000103")
PRODUCTOR_P3 = UUID("20000000-0000-0000-0000-000000000003")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def falla(conn, match, sql, *args):
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(sql, *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


async def _cuota_pendiente_revision(conn):
    """Deja a P3 con una transferencia pendiente de revisión y devuelve el pago."""
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute("SELECT private.crear_cuota_servicio($1)", PRODUCTOR_P3)
    await autenticar(conn, PERFIL_P3)
    await conn.execute(
        "SELECT public.registrar_transferencia_servicio($1,$2)",
        "REF-LOTE24-001",
        "Transferencia recibida lote 24",
    )
    return await conn.fetchval(
        "SELECT id FROM public.pagos_servicio WHERE referencia=$1", "REF-LOTE24-001"
    )


async def test_ck_0258_pagado_exige_monto_y_beneficiario_registrados(conn):
    pago_id = await _cuota_pendiente_revision(conn)

    # sin constancia del monto/beneficiario no se marca pagada
    await autenticar(conn, ADMIN)
    await falla(
        conn, "monto recibido y el beneficiario",
        "SELECT public.resolver_pago_servicio($1,'pagado',$2)", pago_id, "   ",
    )
    await falla(
        conn, "monto recibido y el beneficiario",
        "SELECT public.resolver_pago_servicio($1,'pagado',NULL)", pago_id,
    )
    estado = await conn.fetchval(
        "SELECT estado FROM public.pagos_servicio WHERE id=$1", pago_id
    )
    assert estado == "pendiente_revision"

    # con la resolución registrada se marca pagada con trazabilidad
    await conn.execute(
        "SELECT public.resolver_pago_servicio($1,'pagado',$2)",
        pago_id,
        "Monto 2990 CLP verificado en cuenta CUTUCO; beneficiario confirmado. Lote 24.",
    )
    fila = await conn.fetchrow(
        "SELECT estado, pagado_en, revisado_por, revisado_en, observaciones "
        "FROM public.pagos_servicio WHERE id=$1",
        pago_id,
    )
    assert fila["estado"] == "pagado"
    assert fila["pagado_en"] is not None
    assert fila["revisado_por"] == ADMIN
    assert fila["revisado_en"] is not None
    assert "2990" in fila["observaciones"]

    # no se puede re-resolver (historial conservado, sin borrar evidencia)
    await falla(
        conn, "ya fue revisado",
        "SELECT public.resolver_pago_servicio($1,'rechazado',$2)", pago_id, "Intento extra",
    )


async def test_ck_0258_solo_admin_resuelve(conn):
    pago_id = await _cuota_pendiente_revision(conn)
    await autenticar(conn, PERFIL_P3)
    await falla(
        conn, "Solo un administrador",
        "SELECT public.resolver_pago_servicio($1,'pagado',$2)", pago_id, "intento productor",
    )
    await reset(conn)
