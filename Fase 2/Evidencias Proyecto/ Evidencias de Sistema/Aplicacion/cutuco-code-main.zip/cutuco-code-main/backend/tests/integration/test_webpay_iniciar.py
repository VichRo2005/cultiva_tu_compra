import json
from decimal import ROUND_HALF_UP, Decimal
from uuid import UUID

import pytest

from app.core.exceptions import WebpayError


async def test_sin_stock_400(client, headers, checkout_body, mock_transbank):
    checkout_body["items"][0]["cantidad"] = 100000
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400 and "Stock" in response.text
    mock_transbank["create"].assert_not_called()


@pytest.mark.parametrize("campo,valor", [
    ("precio", 1), ("subtotal", 1), ("total", 1), ("monto_fee_plataforma", 0),
])
async def test_importes_inyectados_no_llegan_a_pasarela(
    client, headers, checkout_body, mock_transbank, campo, valor
):
    cuerpo = {**checkout_body, campo: valor}
    response = await client.post("/api/webpay/iniciar", json=cuerpo, headers=headers)
    assert response.status_code == 422, response.text
    mock_transbank["create"].assert_not_called()


@pytest.mark.parametrize("caso", ["producto", "productor", "perfil"])
async def test_revalida_habilitacion_antes_de_create(
    client, headers, checkout_body, conn, mock_transbank, caso
):
    producto = UUID(checkout_body["items"][0]["producto_id"])
    productor = await conn.fetchval(
        "SELECT productor_id FROM public.productos WHERE id=$1", producto
    )
    perfil = await conn.fetchval(
        "SELECT perfil_id FROM public.productores WHERE id=$1", productor
    )
    if caso == "producto":
        await conn.execute(
            "UPDATE public.productos SET activo=false, motivo_pausa='Pausa de prueba QA' "
            "WHERE id=$1", producto
        )
    elif caso == "productor":
        await conn.execute("UPDATE public.productores SET activo=false WHERE id=$1", productor)
    elif caso == "perfil":
        await conn.execute("UPDATE public.perfiles SET activo=false WHERE id=$1", perfil)
    antes = await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts")
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400, response.text
    assert await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts") == antes
    mock_transbank["create"].assert_not_called()


@pytest.mark.parametrize("diferencia", [-1, 1])
async def test_total_cambio_no_crea_transaccion(
    client, headers, checkout_body, conn, mock_transbank, diferencia
):
    precio = await conn.fetchval(
        "SELECT precio FROM public.productos WHERE id=$1",
        UUID(checkout_body["items"][0]["producto_id"]),
    )
    cantidad = Decimal(str(checkout_body["items"][0]["cantidad"]))
    base = Decimal(str(precio)) * cantidad + Decimal("3500")
    esperado = int((base * Decimal("1.19")).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    antes = await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts")
    reservado = await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1",
        UUID(checkout_body["items"][0]["producto_id"]),
    )
    response = await client.post(
        "/api/webpay/iniciar", headers=headers,
        json={**checkout_body, "monto_esperado": esperado + diferencia},
    )
    assert response.status_code == 409, response.text
    assert "total cambió" in response.text
    mock_transbank["create"].assert_not_called()
    assert await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts") == antes
    assert await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1",
        UUID(checkout_body["items"][0]["producto_id"]),
    ) == reservado

    vigente = await client.post(
        "/api/webpay/iniciar", headers=headers,
        json={**checkout_body, "monto_esperado": esperado},
    )
    assert vigente.status_code == 200, vigente.text
    assert vigente.json()["monto"] == esperado


async def test_cobertura_falla_400(client, headers, checkout_body, conn, mock_transbank):
    checkout_body["items"][0]["producto_id"] = str(
        await conn.fetchval(
            """SELECT p.id FROM public.productos p
        JOIN public.productores pr ON pr.id=p.productor_id
        JOIN public.direcciones d ON d.perfil_id=pr.perfil_id AND d.activo
        JOIN public.comunas c ON c.id=d.comuna_id WHERE pr.activo AND p.activo
        AND c.region_id<>(SELECT c2.region_id FROM public.direcciones d2
        JOIN public.comunas c2 ON c2.id=d2.comuna_id WHERE d2.id=$1) LIMIT 1""",
            UUID(checkout_body["direccion_id"]),
        )
    )
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400 and "cobertura" in response.text


async def test_sin_auth_401(client, checkout_body, mock_transbank):
    response = await client.post("/api/webpay/iniciar", json=checkout_body)
    assert response.status_code == 401


async def test_telefono_faltante_400(client, headers, checkout_body, conn, mock_transbank):
    await conn.execute(
        "UPDATE public.perfiles SET telefono=NULL WHERE id='a0000000-0000-0000-0000-000000000002'"
    )
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400 and "teléfono" in response.text


@pytest.mark.parametrize(
    "overrides,expected",
    [
        ({}, "Referencia dirección"),
        ({"referencia_entrega": None}, None),
        ({"referencia_entrega": "Del body"}, "Del body"),
    ],
)
async def test_snapshot_referencia(
    client, headers, checkout_body, conn, mock_transbank, overrides, expected
):
    await conn.execute(
        "UPDATE public.direcciones SET referencia=$2 WHERE id=$1",
        UUID(checkout_body["direccion_id"]),
        "Referencia dirección",
    )
    response = await client.post(
        "/api/webpay/iniciar", json=checkout_body | overrides, headers=headers
    )
    assert response.status_code == 200, response.text
    assert (
        await conn.fetchval(
            "SELECT snapshot->'direccion'->>'referencia_entrega' "
            "FROM private.webpay_checkouts WHERE id=$1",
            UUID(response.json()["checkout_id"]),
        )
        == expected
    )


async def test_create_falla_rollback(client, headers, checkout_body, conn, mock_transbank):
    before = await conn.fetchval("SELECT count(*) FROM public.pedidos")
    mock_transbank["create"].side_effect = WebpayError("Unavailable")
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 502
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos") == before


async def test_direccion_ajena_400(client, headers, checkout_body, conn, mock_transbank):
    checkout_body["direccion_id"] = str(
        await conn.fetchval(
            "SELECT id FROM public.direcciones "
            "WHERE perfil_id='a0000000-0000-0000-0000-000000000101' AND activo LIMIT 1"
        )
    )
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400
    mock_transbank["create"].assert_not_called()


async def test_destinatario_body_suple_telefono_null(
    client, headers, checkout_body, conn, mock_transbank
):
    await conn.execute(
        "UPDATE public.perfiles SET telefono=NULL "
        "WHERE id='a0000000-0000-0000-0000-000000000002'"
    )
    checkout_body.update(
        nombre_destinatario="Otro destinatario", telefono_destinatario="+56912345678"
    )
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 200, response.text
    pedido = await conn.fetchrow(
        "SELECT snapshot FROM private.webpay_checkouts WHERE id=$1",
        UUID(response.json()["checkout_id"]),
    )
    pedido = json.loads(pedido["snapshot"])["direccion"]
    assert pedido["nombre_destinatario"] == "Otro destinatario"
    assert pedido["telefono_destinatario"] == "+56912345678"


async def test_sin_codigo_mall(client, headers, checkout_body, conn, mock_transbank):
    await conn.execute("UPDATE public.productores SET codigo_comercio_mall=NULL")
    result = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert result.status_code == 400 and "código" in result.text
    mock_transbank["create"].assert_not_called()


async def test_productos_repetidos_y_fee_redondeado(
    client, headers, checkout_body, conn, mock_transbank
):
    await conn.execute(
        "UPDATE public.productos SET precio=101 WHERE id='30000000-0000-0000-0000-000000000201'"
    )
    checkout_body["items"] *= 2
    result = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert result.status_code == 200, result.text
    assert result.json()["monto"] == 4646
    details = mock_transbank["create"].call_args.args[2]
    assert details[0]["amount"] == 4626 and details[1]["amount"] == 20
    snapshot = await conn.fetchval(
        "SELECT snapshot FROM private.webpay_checkouts WHERE id=$1",
        UUID(result.json()["checkout_id"]),
    )
    assert len(json.loads(snapshot)["tiendas"][0]["items"]) == 1


async def test_checkout_privado_inaccesible_desde_authenticated(conn):
    assert not await conn.fetchval(
        "SELECT has_table_privilege('authenticated', 'private.webpay_checkouts', 'SELECT')"
    )
    assert not await conn.fetchval(
        "SELECT has_table_privilege('anon', 'private.webpay_checkouts', 'SELECT')"
    )
