"""CK-0247/0249/0260/0405: no paid debt without matching provider receipt."""

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from fastapi import HTTPException

from app.core.exceptions import WebpayError
from app.services import servicio_service as service


@pytest.fixture
def pago(monkeypatch):
    perfil = uuid4()
    cuota = {
        "id": uuid4(),
        "productor_id": uuid4(),
        "monto": 2990,
        "buy_order": "SERV-TEST",
        "token_ws": "test-token",
        "estado": "pendiente",
    }
    response = {
        "status": "AUTHORIZED",
        "response_code": 0,
        "authorization_code": "123456",
        "amount": 2990,
        "buy_order": cuota["buy_order"],
        "session_id": str(perfil),
    }
    lock = []

    @asynccontextmanager
    async def transaction():
        lock.append(True)
        try:
            yield
        finally:
            lock.pop()

    conn = MagicMock()
    conn.transaction = transaction
    conn.fetchrow = AsyncMock(return_value={"perfil_id": perfil})
    monkeypatch.setattr(service.servicio_repo, "get_by_token", AsyncMock(return_value=cuota))
    paid = AsyncMock()
    monkeypatch.setattr(service.servicio_repo, "mark_paid", paid)
    monkeypatch.setattr(service.servicio_repo, "save_webpay_response", AsyncMock())
    client = MagicMock()
    client.commit.side_effect = lambda _: response if lock else pytest.fail("No row lock")
    client.status.return_value = response
    monkeypatch.setattr(service, "WebpayPlusClient", lambda: client)
    return conn, cuota, response, paid, client


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "field,value",
    [
        ("amount", 2989),
        ("amount", 2990.5),
        ("buy_order", "OTHER"),
        ("session_id", "OTHER"),
        ("authorization_code", ""),
    ],
)
async def test_rechaza_recibo_ajeno_o_inconsistente(pago, field, value):
    conn, _, response, paid, _ = pago
    response[field] = value
    with pytest.raises(HTTPException, match="conciliación"):
        await service.confirmar_pago(conn, "test-token")
    paid.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize("amount", [2990, 9900])
async def test_cobra_monto_emitido_incluyendo_cuotas_historicas(pago, amount):
    conn, cuota, response, paid, _ = pago
    cuota["monto"] = response["amount"] = amount
    assert (await service.confirmar_pago(conn, "test-token"))["ok"]
    paid.assert_awaited_once()


@pytest.mark.asyncio
async def test_recupera_commit_incierto_por_status(pago):
    conn, _, _, paid, client = pago
    client.commit.side_effect = WebpayError("timeout")
    assert (await service.confirmar_pago(conn, "test-token"))["ok"]
    client.status.assert_called_once_with("test-token")
    paid.assert_awaited_once()


@pytest.mark.asyncio
async def test_retorno_repetido_no_repite_pasarela(pago):
    conn, cuota, _, paid, client = pago
    cuota["estado"] = "pagado"
    assert (await service.confirmar_pago(conn, "test-token"))["ok"]
    client.commit.assert_not_called()
    paid.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize('status,code', [('FAILED', 400), ('INITIALIZED', 409)])
async def test_respuesta_no_autorizada_se_conserva_sin_rollback(pago, status, code):
    conn, cuota, response, paid, _ = pago
    response['status'] = status
    rollback = []
    original_transaction = conn.transaction

    @asynccontextmanager
    async def transaction():
        try:
            async with original_transaction():
                yield
        except Exception:
            rollback.append(True)
            raise

    conn.transaction = transaction
    with pytest.raises(HTTPException) as error:
        await service.confirmar_pago(conn, 'test-token')
    assert error.value.status_code == code
    assert rollback == []
    service.servicio_repo.save_webpay_response.assert_awaited_once_with(conn, cuota['id'], response)
    paid.assert_not_awaited()
