"""HAL-VEN-025: configuración explícita del servicio mensual."""

import pytest
from fastapi import HTTPException

from app.core.config import get_settings
from app.services import servicio_service


def _reload_settings(monkeypatch, **values):
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    get_settings.cache_clear()
    return get_settings()


def test_configuracion_faltante_503_explicito(monkeypatch):
    _reload_settings(
        monkeypatch,
        ENVIRONMENT="production",
        TRANSBANK_SERVICIO_COMMERCE_CODE="",
        TRANSBANK_SERVICIO_API_KEY="",
        TRANSBANK_SERVICIO_RETURN_URL="",
    )
    with pytest.raises(HTTPException) as exc:
        servicio_service._validar_configuracion()
    assert exc.value.status_code == 503
    assert "TRANSBANK_SERVICIO_COMMERCE_CODE" in exc.value.detail
    assert "TRANSBANK_SERVICIO_API_KEY" in exc.value.detail
    assert "TRANSBANK_SERVICIO_RETURN_URL" in exc.value.detail


def test_produccion_rechaza_sandbox(monkeypatch):
    from app.core.config import SERVICIO_SANDBOX_API_KEY, SERVICIO_SANDBOX_COMMERCE_CODE

    _reload_settings(
        monkeypatch,
        ENVIRONMENT="production",
        TRANSBANK_ENV="production",
        TRANSBANK_SERVICIO_COMMERCE_CODE=SERVICIO_SANDBOX_COMMERCE_CODE,
        TRANSBANK_SERVICIO_API_KEY=SERVICIO_SANDBOX_API_KEY,
        TRANSBANK_SERVICIO_RETURN_URL="https://cutuco.cl/api/servicio/retorno",
    )
    with pytest.raises(HTTPException) as exc:
        servicio_service._validar_configuracion()
    assert exc.value.status_code == 503
    assert "sandbox" in exc.value.detail


def test_integracion_permite_sandbox_con_entorno_produccion(monkeypatch):
    """Fase de pagos simulados: ENVIRONMENT=production + TRANSBANK_ENV=integration
    con credenciales sandbox no debe dar 503 (la lógica de producción no cambia:
    al pasar TRANSBANK_ENV a production el sandbox vuelve a rechazarse)."""
    from app.core.config import SERVICIO_SANDBOX_API_KEY, SERVICIO_SANDBOX_COMMERCE_CODE

    _reload_settings(
        monkeypatch,
        ENVIRONMENT="production",
        TRANSBANK_ENV="integration",
        TRANSBANK_SERVICIO_COMMERCE_CODE=SERVICIO_SANDBOX_COMMERCE_CODE,
        TRANSBANK_SERVICIO_API_KEY=SERVICIO_SANDBOX_API_KEY,
        TRANSBANK_SERVICIO_RETURN_URL="https://cutuco-backend-401565815773.southamerica-west1.run.app/api/servicio/retorno",
    )
    servicio_service._validar_configuracion()  # no lanza


def test_development_completa_sandbox(monkeypatch):
    settings = _reload_settings(
        monkeypatch,
        ENVIRONMENT="development",
        TRANSBANK_SERVICIO_COMMERCE_CODE="",
        TRANSBANK_SERVICIO_API_KEY="",
        TRANSBANK_SERVICIO_RETURN_URL="",
    )
    assert settings.TRANSBANK_SERVICIO_COMMERCE_CODE == "597055555532"
    assert settings.TRANSBANK_SERVICIO_API_KEY
    servicio_service._validar_configuracion()
