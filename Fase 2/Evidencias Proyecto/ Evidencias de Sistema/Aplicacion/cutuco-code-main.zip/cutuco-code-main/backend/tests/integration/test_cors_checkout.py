"""El retorno de Webpay debe poder confirmar desde la SPA local."""

import pytest


@pytest.mark.parametrize("origin", ["http://localhost:5173", "http://127.0.0.1:5173"])
async def test_checkout_preflight_acepta_frontend_local(client, origin):
    response = await client.options(
        "/api/webpay/confirmar",
        headers={
            "Origin": origin,
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type",
        },
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == origin
    assert "POST" in response.headers["access-control-allow-methods"]


async def test_checkout_error_tambien_conserva_cors(client):
    """Un error de token no puede quedar oculto tras un falso error CORS."""
    response = await client.post(
        "/api/webpay/confirmar",
        json={"token_ws": "token-prueba"},
        headers={"Origin": "http://localhost:5173"},
    )

    assert response.status_code == 404
    assert response.headers["access-control-allow-origin"] == "http://localhost:5173"
