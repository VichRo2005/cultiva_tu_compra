import json
from decimal import Decimal
from uuid import UUID

import pytest

from app.core.exceptions import WebpayError


async def confirm(client, checkout):
    return await client.post("/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]})


async def test_autorizado_crea_pedido_pagado_comprobante_envio_correos(
    client, checkout, conn, mock_email
):
    # The checkout fixture uses PRODUCT_ID = 30000000-0000-0000-0000-000000000201
    product_id = "30000000-0000-0000-0000-000000000201"
    stock = await conn.fetchval(
        f"SELECT stock FROM public.productos WHERE id='{product_id}'"
    )
    response = await confirm(client, checkout)
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["ok"] and result["estado"] == "autorizado"
    assert result["pedidos"][0]["estado_pedido"] == "pagado"
    assert result["pedidos"][0]["codigo_pedido"].startswith("CTC-")
    producto_confirmado = result["pedidos"][0]["productos"][0]
    assert producto_confirmado["producto_id"] == product_id
    assert producto_confirmado["producto_nombre"] == "Tomates de Melipilla"
    assert producto_confirmado["codigo_producto"]
    pedido_id = UUID(result["pedidos"][0]["pedido_id"])
    pago = await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido_id)
    assert pago["monto"] + pago["monto_fee_descontado"] == checkout["monto"]
    detail = json.loads(pago["respuesta_webpay"])
    assert detail["status"] == "AUTHORIZED" and "details" not in detail
    assert detail["buy_order"] == pago["buy_order"]
    assert (
        await conn.fetchval("SELECT count(*) FROM public.envios WHERE pedido_id=$1", pedido_id) == 1
    )
    assert (
        await conn.fetchval(
            f"SELECT stock FROM public.productos WHERE id='{product_id}'"
        )
        == stock - 2
    )
    assert mock_email.await_count == 2
    assert all("El cliente necesita boleta" in call.args[2] for call in mock_email.call_args_list)
    assert all("66.666.666-6" in call.args[3] for call in mock_email.call_args_list)


async def test_idempotencia_y_reintento_correo(client, checkout, conn, mock_email, mock_transbank):
    mock_email.side_effect = [False, True]
    first = await confirm(client, checkout)
    assert first.status_code == 200, first.text
    mock_email.side_effect = None
    second = await confirm(client, checkout)
    assert second.json()["ya_confirmado"]
    assert mock_email.await_count == 3
    assert mock_transbank["commit"].call_count == 1
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1",
            UUID(checkout["checkout_id"]),
        )
        == 1
    )


async def test_rechazo_sin_pedidos_ni_pagos(client, checkout, conn, mock_transbank, mock_email):
    for d in mock_transbank["transactions"][checkout["token_ws"]]["details"]:
        d.update(status="FAILED", response_code=-1)
    response = await confirm(client, checkout)
    assert response.status_code == 200, response.text
    assert response.json()["estado"] == "rechazado" and response.json()["pedidos"] == []
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
        )
        == 0
    )
    assert (await confirm(client, checkout)).json()["ya_confirmado"]
    mock_email.assert_not_awaited()


async def test_token_invalido(client, mock_transbank):
    assert (await confirm(client, {"token_ws": "unknown"})).status_code == 404
    mock_transbank["commit"].assert_not_called()


@pytest.mark.parametrize(
    "field,value",
    [
        ("amount", 1),
        ("commerce_code", "597055555500"),
        ("buy_order", "wrong"),
        ("status", "INITIALIZED"),
        ("authorization_code", ""),
        ("response_code", -1),
    ],
)
async def test_detail_invalido_no_persiste(client, checkout, conn, mock_transbank, field, value):
    mock_transbank["transactions"][checkout["token_ws"]]["details"][0][field] = value
    response = await confirm(client, checkout)
    assert response.status_code == 502, response.text
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1",
            UUID(checkout["checkout_id"]),
        )
        == 0
    )


@pytest.mark.parametrize("mutation", ["session_id", "buy_order", "missing", "duplicate", "extra"])
async def test_respuesta_mall_invalida(client, checkout, mock_transbank, mutation):
    response = mock_transbank["transactions"][checkout["token_ws"]]
    if mutation in ("session_id", "buy_order"):
        response[mutation] = "wrong"
    elif mutation == "missing":
        response["details"].pop()
    elif mutation == "duplicate":
        response["details"][1] = response["details"][0]
    else:
        response["details"].append(response["details"][0])
    assert (await confirm(client, checkout)).status_code == 502


async def test_commit_respuesta_perdida_recupera_status(client, checkout, mock_transbank):
    mock_transbank["commit"].side_effect = WebpayError("Timeout")
    response = await confirm(client, checkout)
    assert response.status_code == 200 and response.json()["ok"], response.text
    assert mock_transbank["status"].call_count == 1


async def test_confirmar_ajeno_no_cobra(client, checkout, mock_jwt, mock_transbank):
    response = await client.post(
        "/api/webpay/confirmar",
        json={"token_ws": checkout["token_ws"]},
        headers={"Authorization": f"Bearer {mock_jwt('a0000000-0000-0000-0000-000000000101')}"},
    )
    assert response.status_code == 403
    mock_transbank["commit"].assert_not_called()


@pytest.mark.parametrize("failed_index", [0, 1])
async def test_autorizacion_parcial_requiere_conciliacion(
    client, checkout, conn, mock_transbank, failed_index
):
    mock_transbank["transactions"][checkout["token_ws"]]["details"][failed_index].update(
        status="FAILED", response_code=-1
    )
    response = await confirm(client, checkout)
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["estado"] == "parcial" and result["requiere_conciliacion"] and not result["ok"]
    assert len(result["pedidos"]) == failed_index
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
        )
        == failed_index
    )


async def test_factura_snapshot_y_ambos_correos(
    client, headers, checkout_body, conn, mock_transbank, mock_email
):
    checkout_body["documento_tributario"] = {
        "tipo": "factura",
        "rut_empresa": "76.123.456-0",
        "razon_social": "Empresa <script>",
        "giro": "Alimentos",
        "direccion_tributaria": "Calle Tributaria 123",
    }
    # Valid RUT with modulo 11.
    checkout_body["documento_tributario"]["rut_empresa"] = "12.345.678-5"
    started = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert started.status_code == 200, started.text
    response = await confirm(client, started.json())
    assert response.status_code == 200, response.text
    assert mock_email.await_count == 2
    for call in mock_email.call_args_list:
        html, plain = call.args[2:4]
        assert "Factura de Compra" in html and "Factura de Compra" in plain
        assert "12345678-5" in html and "Calle Tributaria 123" in plain
        assert "Empresa &lt;script&gt;" in html and "Empresa <script>" in plain


async def test_snapshot_precio_no_cambia_despues_de_iniciar(client, checkout, conn):
    await conn.execute(
        "UPDATE public.productos SET precio=precio+100 "
        "WHERE id='30000000-0000-0000-0000-000000000101'"
    )
    response = await confirm(client, checkout)
    assert response.status_code == 200, response.text
    assert Decimal(response.json()["pedidos"][0]["total"]) == checkout["monto"]


async def test_backend_service_role_permisos(
    client, headers, checkout_body, conn, mock_transbank, mock_email
):
    await conn.execute("SET LOCAL ROLE service_role")
    started = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert started.status_code == 200, started.text
    response = await confirm(client, started.json())
    assert response.status_code == 200 and response.json()["ok"], response.text


async def test_producto_agotado_al_confirmar_no_deja_datos_parciales(
    client, checkout, conn, mock_email, mock_transbank
):
    # The checkout fixture uses PRODUCT_ID = 30000000-0000-0000-0000-000000000201
    product_id = "30000000-0000-0000-0000-000000000201"
    await conn.execute(
        f"UPDATE public.productos SET stock=0 WHERE id='{product_id}'"
    )
    response = await confirm(client, checkout)
    assert response.status_code == 502, response.text
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
        )
        == 0
    )
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1",
            UUID(checkout["checkout_id"]),
        )
        == 0
    )
    mock_email.assert_not_awaited()

    row = await conn.fetchrow(
        "SELECT respuesta,resultado FROM private.webpay_checkouts WHERE id=$1",
        UUID(checkout["checkout_id"]),
    )
    assert row["respuesta"] is not None and row["resultado"] is None
    await conn.execute(
        f"UPDATE public.productos SET stock=10 WHERE id='{product_id}'"
    )
    retried = await confirm(client, checkout)
    assert retried.status_code == 200 and retried.json()["ok"], retried.text
    mock_transbank["commit"].assert_called_once()
