"""Lote 17 (Servicio mensual), lado unidad backend.

CK-0246: iniciar pago Webpay Plus crea la transacción por el monto EXACTO de la
cuota (sin comisión operativa extra, CK-0252) con buy_order SERV-* y session_id
del perfil. CK-0245: el inicio no se bloquea por suspensión (la cuota sigue
pendiente y pagable).
"""

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from app.services import servicio_service as service


@pytest.fixture
def entorno(monkeypatch):
    perfil = uuid4()
    productor = {"id": uuid4(), "nombre_comercial": "Tienda P2"}
    cuota = {
        "id": uuid4(),
        "productor_id": productor["id"],
        "monto": 2990,
        "estado": "pendiente",
        "token_ws": None,
    }

    @asynccontextmanager
    async def transaction():
        yield

    conn = MagicMock()
    conn.transaction = transaction
    monkeypatch.setattr(service.servicio_repo, "get_productor_por_perfil", AsyncMock(return_value=productor))
    monkeypatch.setattr(service.servicio_repo, "asegurar_cuota", AsyncMock())
    monkeypatch.setattr(service.servicio_repo, "get_cuota_pendiente", AsyncMock(return_value=cuota))
    set_webpay = AsyncMock()
    monkeypatch.setattr(service.servicio_repo, "set_webpay", set_webpay)
    monkeypatch.setattr(service, "_validar_configuracion", lambda: None)
    monkeypatch.setattr(
        service, "get_settings", lambda: MagicMock(TRANSBANK_SERVICIO_RETURN_URL="https://app.test/retorno")
    )
    client = MagicMock()
    client.create.return_value = {"url": "https://webpay.test/init", "token": "tok123"}
    monkeypatch.setattr(service, "WebpayPlusClient", lambda: client)
    return conn, perfil, cuota, client, set_webpay


@pytest.mark.asyncio
async def test_ck_0246_0252_inicia_plus_por_monto_exacto_de_la_cuota(entorno):
    conn, perfil, cuota, client, set_webpay = entorno
    resultado = await service.iniciar_pago(conn, perfil)

    args, _ = client.create.call_args
    buy_order, session_id, amount, return_url = args
    assert buy_order.startswith("SERV-")
    assert session_id == str(perfil)  # session_id = perfil del vendedor
    assert amount == cuota["monto"] == 2990  # CK-0252: sin comisión adicional
    assert return_url == "https://app.test/retorno"
    assert resultado["monto"] == 2990 and resultado["token_ws"] == "tok123"
    set_webpay.assert_awaited_once()
    args_set, _ = set_webpay.call_args
    assert args_set[1] == cuota["id"] and args_set[2] == buy_order and args_set[3] == "tok123"


@pytest.mark.asyncio
async def test_ck_0245_inicio_permitido_aunque_la_tienda_este_suspendida(entorno, monkeypatch):
    # El repo no filtra por suspensión: la cuota pendiente sigue pagable (CK-0245).
    conn, perfil, cuota, client, _ = entorno
    productor = await service.servicio_repo.get_productor_por_perfil(conn, perfil)
    assert productor is not None  # no se exige servicio_suspendido=false para iniciar
    resultado = await service.iniciar_pago(conn, perfil)
    assert resultado["monto"] == 2990
    client.create.assert_called_once()


@pytest.mark.asyncio
@pytest.mark.parametrize("status", ["NULLIFIED", "REVERSED", "FAILED", "INITIALIZED"])
async def test_reintenta_con_token_viejo_no_autorizado(entorno, status):
    """Si el pago anterior no quedó AUTORIZADO, iniciar crea una transacción nueva:
    sin commit Transbank anula la transacción vieja, así que no hay doble cobro y
    el vendedor no queda bloqueado (reporte: 'pago en curso' permanente)."""
    conn, perfil, cuota, client, set_webpay = entorno
    cuota["token_ws"] = "tok-viejo"
    cuota["buy_order"] = "SERV-VIEJO"
    client.status.return_value = {"status": status}
    client.create.return_value = {"url": "https://webpay.test/init2", "token": "tok-nuevo"}

    resultado = await service.iniciar_pago(conn, perfil)

    assert resultado["token_ws"] == "tok-nuevo"
    assert resultado.get("estado") is None
    client.create.assert_called_once()
    args_set, _ = set_webpay.call_args
    assert args_set[3] == "tok-nuevo"  # token_ws sobrescrito


@pytest.mark.asyncio
async def test_reintenta_si_transbank_ya_no_conoce_el_token(entorno):
    """Si status falla (token expirado/desconocido), tampoco se bloquea."""
    from app.core.exceptions import WebpayError

    conn, perfil, cuota, client, set_webpay = entorno
    cuota["token_ws"] = "tok-viejo"
    client.status.side_effect = WebpayError("transaction not found")
    client.create.return_value = {"url": "https://webpay.test/init3", "token": "tok-nuevo"}

    resultado = await service.iniciar_pago(conn, perfil)

    assert resultado["token_ws"] == "tok-nuevo"
    client.create.assert_called_once()


@pytest.mark.asyncio
async def test_recupera_pago_autorizado_sin_commit_al_iniciar(entorno, monkeypatch):
    """Token viejo con status AUTHORIZED: se confirma (commit) en lugar de 409."""
    conn, perfil, cuota, client, set_webpay = entorno
    cuota["token_ws"] = "tok-viejo"
    cuota["buy_order"] = "SERV-VIEJO"
    autorizado = {
        "status": "AUTHORIZED",
        "response_code": 0,
        "authorization_code": "123456",
        "amount": 2990,
        "buy_order": "SERV-VIEJO",
        "session_id": str(perfil),
    }
    client.status.return_value = autorizado
    client.commit.return_value = dict(autorizado)
    monkeypatch.setattr(service.servicio_repo, "get_by_token", AsyncMock(return_value=cuota))
    paid = AsyncMock()
    monkeypatch.setattr(service.servicio_repo, "mark_paid", paid)
    monkeypatch.setattr(service.servicio_repo, "save_webpay_response", AsyncMock())
    conn.fetchrow = AsyncMock(return_value={"perfil_id": perfil})

    resultado = await service.iniciar_pago(conn, perfil)

    assert resultado["estado"] == "pagado"
    assert resultado["url"] == ""
    client.commit.assert_called_once_with("tok-viejo")
    paid.assert_awaited_once()
    client.create.assert_not_called()
