import asyncio
from uuid import UUID

from httpx import ASGITransport, AsyncClient

from app.main import create_app


async def test_tres_callbacks_concurrentes(db_pool, headers, mock_transbank, mock_email):
    checkout_id = None
    async with db_pool.acquire() as conn:
        address = await conn.fetchval(
            "SELECT id FROM public.direcciones "
            "WHERE perfil_id='a0000000-0000-0000-0000-000000000002' AND activo "
            "ORDER BY es_principal DESC LIMIT 1"
        )
    try:
        async with AsyncClient(
            transport=ASGITransport(app=create_app()), base_url="http://test"
        ) as client:
            started = await client.post(
                "/api/webpay/iniciar",
                headers=headers,
                json={
                    "direccion_id": str(address),
                    "items": [
                        {"producto_id": "30000000-0000-0000-0000-000000000201", "cantidad": 2}
                    ],
                },
            )
            assert started.status_code == 200, started.text
            checkout_id = UUID(started.json()["checkout_id"])
            responses = await asyncio.gather(
                *[
                    client.post(
                        "/api/webpay/confirmar", json={"token_ws": started.json()["token_ws"]}
                    )
                    for _ in range(3)
                ]
            )
            assert all(r.status_code == 200 for r in responses), [r.text for r in responses]
            assert sum(r.json()["ya_confirmado"] for r in responses) == 2
        assert mock_transbank["commit"].call_count == 1
        assert mock_email.await_count == 2
        async with db_pool.acquire() as conn:
            assert (
                await conn.fetchval(
                    "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1", checkout_id
                )
                == 1
            )
    finally:
        if checkout_id is not None:
            async with db_pool.acquire() as conn, conn.transaction():
                # Restore inventory through the real cancellation trigger first.
                await conn.execute(
                    "UPDATE public.pedidos SET estado='cancelado' WHERE checkout_id=$1", checkout_id
                )
                # Local-test-only cleanup of immutable receipts, scoped to this checkout.
                # Replica mode disables cascades, so remove each dependent row explicitly.
                await conn.execute("SET LOCAL session_replication_role = replica")
                for table in ("pagos", "envios", "detalles_pedido"):
                    await conn.execute(
                        f"DELETE FROM public.{table} WHERE pedido_id IN "
                        "(SELECT id FROM public.pedidos WHERE checkout_id=$1)",
                        checkout_id,
                    )
                await conn.execute("DELETE FROM public.pedidos WHERE checkout_id=$1", checkout_id)
                await conn.execute(
                    "DELETE FROM private.webpay_ordenes WHERE checkout_id=$1", checkout_id
                )
                await conn.execute("DELETE FROM private.webpay_checkouts WHERE id=$1", checkout_id)
