"""Unitarios del cliente SRE con httpx mockeado (contrato vigente 2026-11)."""

import httpx
import pytest

from app.core.config import get_settings
from app.integrations.sre import client as sre_client


class _Response:
    def __init__(self, status_code, payload=None):
        self.status_code = status_code
        self._payload = payload

    def json(self):
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def _mock_client(monkeypatch, response=None, raises=None):
    calls = []

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def get(self, url, params=None):
            calls.append({"url": url, "params": params})
            if raises is not None:
                raise raises
            return response

    monkeypatch.setattr(httpx, "AsyncClient", FakeAsyncClient)
    return calls


async def test_get_empresa_ok_contrato_company_info(monkeypatch):
    calls = _mock_client(
        monkeypatch,
        response=_Response(
            200,
            {
                "result": True,
                "rut": "76123456-0",
                "razon_social": "Empresa SpA",
                "glosa_giro": "Comercio",
                "consultas_restantes": 190,
            },
        ),
    )
    datos = await sre_client.get_empresa("76123456-0")
    assert datos == {"razon_social": "Empresa SpA", "giro": "Comercio", "actecos": []}
    assert calls[0]["url"].endswith("/api/company_info")
    assert calls[0]["params"] == {
        "token": "token_publico",
        "rut": "76123456-0",
        "actualizado": "False",
    }


# ---------------------------------------------------------------------
# HAL-CLI-028 / CK-0487: el giro sale de `actecos` cuando el SII no
# publica la glosa. Tabla local en app/integrations/sre/actecos.py.
# ---------------------------------------------------------------------


async def test_actecos_mapea_a_giro(monkeypatch):
    _mock_client(
        monkeypatch,
        response=_Response(
            200,
            {
                "result": True,
                "rut": "76123456-0",
                "razon_social": "Huerto del Valle SpA",
                "actecos": ["011306"],
                "consultas_restantes": 190,
            },
        ),
    )
    datos = await sre_client.get_empresa("76123456-0")
    assert datos is not None
    assert datos["giro"] == "Cultivo de hortalizas y melones"
    assert datos["actecos"] == ["011306"]


async def test_glosa_publicada_manda_sobre_actecos(monkeypatch):
    _mock_client(
        monkeypatch,
        response=_Response(
            200,
            {
                "result": True,
                "razon_social": "Empresa SpA",
                "glosa_giro": "Comercio al por menor",
                "actecos": ["013000"],
            },
        ),
    )
    datos = await sre_client.get_empresa("76123456-0")
    assert datos == {
        "razon_social": "Empresa SpA",
        "giro": "Comercio al por menor",
        "actecos": ["013000"],
    }


async def test_actecos_codigo_desconocido_deja_giro_vacio(monkeypatch):
    _mock_client(
        monkeypatch,
        response=_Response(
            200,
            {"result": True, "razon_social": "Empresa Nueva SpA", "actecos": ["999999"]},
        ),
    )
    datos = await sre_client.get_empresa("76123456-0")
    # La razón social sigue disponible: el comprador sólo escribe el giro a mano.
    assert datos["razon_social"] == "Empresa Nueva SpA"
    assert datos["giro"] == ""
    assert datos["actecos"] == ["999999"]


async def test_actecos_enteros_y_objetos_se_normalizan(monkeypatch):
    async def codigos(valor):
        return sre_client._codigos_actecos(valor)

    assert await codigos([11101]) == ["011101"]
    assert await codigos("620200") == ["620200"]
    assert await codigos([{"codigo": "62.0200"}]) == ["620200"]
    assert await codigos(None) == []
    assert await codigos("no-es-codigo") == []
    assert await codigos([11101, "011101"]) == ["011101"]


async def test_primer_codigo_conocido_es_la_actividad_principal(monkeypatch):
    _mock_client(
        monkeypatch,
        response=_Response(
            200,
            {
                "result": True,
                "razon_social": "Vivero Sur Ltda",
                "actecos": ["999999", "013000", "011306"],
            },
        ),
    )
    datos = await sre_client.get_empresa("76123456-0")
    assert datos["giro"] == (
        "Cultivo de plantas vivas incluida la producción en viveros "
        "(excepto viveros forestales)"
    )


def test_tabla_actecos_completa_y_coherente():
    from app.integrations.sre.actecos import ACTECOS_GIROS

    assert ACTECOS_GIROS, "la tabla local de actecos no puede estar vacía"
    for codigo, glosa in ACTECOS_GIROS.items():
        assert len(codigo) == 6 and codigo.isdigit(), codigo
        assert glosa.strip(), codigo
    # Códigos documentados por la API de SRE en su propio ejemplo.
    assert ACTECOS_GIROS["620200"].startswith("Actividades de consultoría de informática")
    assert ACTECOS_GIROS["011306"] == "Cultivo de hortalizas y melones"


async def test_get_empresa_404_devuelve_none(monkeypatch):
    _mock_client(monkeypatch, response=_Response(404, {}))
    assert await sre_client.get_empresa("76123456-0") is None


async def test_get_empresa_result_false_es_no_encontrada(monkeypatch):
    _mock_client(
        monkeypatch,
        response=_Response(200, {"result": False, "error": "RUT no registrado"}),
    )
    assert await sre_client.get_empresa("76123456-0") is None


async def test_get_empresa_500_lanza_sre_error(monkeypatch):
    _mock_client(monkeypatch, response=_Response(500, {}))
    with pytest.raises(sre_client.SreError):
        await sre_client.get_empresa("76123456-0")


async def test_get_empresa_429_lanza_sre_error(monkeypatch):
    _mock_client(monkeypatch, response=_Response(429, {}))
    with pytest.raises(sre_client.SreError):
        await sre_client.get_empresa("76123456-0")


async def test_get_empresa_timeout_lanza_sre_error(monkeypatch):
    _mock_client(monkeypatch, raises=httpx.ConnectTimeout("timeout"))
    with pytest.raises(sre_client.SreError):
        await sre_client.get_empresa("76123456-0")


async def test_get_empresa_json_invalido(monkeypatch):
    _mock_client(monkeypatch, response=_Response(200, ValueError("no json")))
    with pytest.raises(sre_client.SreError):
        await sre_client.get_empresa("76123456-0")


async def test_get_empresa_sin_razon_social_es_none(monkeypatch):
    _mock_client(monkeypatch, response=_Response(200, {"result": True, "otra": "cosa"}))
    assert await sre_client.get_empresa("76123456-0") is None


async def test_get_empresa_sin_token_configurado(monkeypatch):
    monkeypatch.setenv("SRE_TOKEN_PUBLICO", "")
    get_settings.cache_clear()
    with pytest.raises(sre_client.SreConfigError):
        await sre_client.get_empresa("76123456-0")


# Los tests del endpoint /api/tributario viven en
# tests/integration/test_tributario_api.py (requieren Supabase local).
