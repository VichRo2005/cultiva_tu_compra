"""CK-0028 / CK-0281 / CK-0282 — presupuesto total de envío <= 10 s.

El módulo expone un reloj inyectable (`_ahora`); estas pruebas lo sustituyen
por uno determinista que avanza solo cuando el código "duerme" o cuando un
intento agota su tope, para comprobar que:

* el plazo TOTAL (EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS = 10 s) manda sobre los
  reintentos: nunca se duerme lo que no cabe antes del plazo;
* cada intento HTTP se acota a min(8 s, restante);
* un timeout del proveedor se clasifica como TimeoutError en la auditoría;
* el respaldo SMTP sólo corre con presupuesto restante y con su propio tope
  <= restante;
* con idempotency_key NO se cambia de transporte (SMTP no comparte la
  idempotencia de la API) → los reintentos no se duplican por otro canal.
"""

import httpx
import pytest

from app.integrations.email import client as email_client
from app.integrations.email.client import (
    EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS,
    EMAIL_SMTP_TIMEOUT_SEGUNDOS,
    EmailClient,
)

REMITE = "CuTuCo <no-reply@cutuco.cl>"
CLAVE = "xkeysib-clave-de-prueba"


class Reloj:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t

    def avanzar(self, segundos):
        self.t += segundos


@pytest.fixture
def reloj(monkeypatch):
    r = Reloj()
    monkeypatch.setattr(email_client, "_ahora", r)
    return r


@pytest.fixture
def auditorias(monkeypatch):
    registros = []
    monkeypatch.setattr(
        email_client, "_guardar_auditoria", lambda *a, **k: registros.append(k)
    )
    return registros


class _ClienteTimeoutCap:
    """Finge un intento que siempre agota exactamente su tope de timeout."""

    llamadas = 0
    timeouts = []

    def __init__(self, *args, **kwargs):
        self.timeout = kwargs.get("timeout")
        type(self).timeouts.append(self.timeout)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    async def post(self, *args, **kwargs):
        type(self).llamadas += 1
        raise httpx.ConnectTimeout("timed out")


async def test_presupuesto_total_manda_sobre_los_reintentos(reloj, monkeypatch, auditorias):
    """Con intentos que agotan su tope, el envío se corta antes de 10 s y
    nunca llega al tercer intento si no cabe en el presupuesto."""
    _ClienteTimeoutCap.llamadas = 0
    _ClienteTimeoutCap.timeouts = []

    reloj_local = reloj
    llamadas = []

    class _Cliente(_ClienteTimeoutCap):
        async def post(self, *args, **kwargs):
            _ClienteTimeoutCap.llamadas += 1
            llamadas.append(self.timeout)
            reloj_local.avanzar(self.timeout)  # el intento dura su tope y falla
            raise httpx.ConnectTimeout("timed out")

    monkeypatch.setattr(email_client.httpx, "AsyncClient", _Cliente)

    async def _dormir(segundos, *args, **kwargs):
        reloj.avanzar(segundos)

    monkeypatch.setattr(email_client.asyncio, "sleep", _dormir)

    resultado = await EmailClient(CLAVE, REMITE).send(
        "to@example.com", "asunto", "<p>h</p>", "h"
    )

    assert resultado is False
    # intento 1: tope 8 s; espera 0.25 s; intento 2: tope restante ~1.75 s;
    # al agotarse el presupuesto total ya no hay tercer intento.
    assert _ClienteTimeoutCap.llamadas == 2
    assert reloj.t <= EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS + 1e-9
    assert _ClienteTimeoutCap.timeouts[0] == 8.0
    assert _ClienteTimeoutCap.timeouts[1] <= EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS - 8.0 - 0.25 + 1e-9
    assert auditorias and "timeout" in auditorias[-1]["error"].lower()
    assert auditorias[-1]["enviado"] is False


async def test_timeout_se_clasifica_como_timeout_error(reloj, monkeypatch, auditorias):
    class _Cliente:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def post(self, *args, **kwargs):
            reloj.avanzar(0.1)
            raise httpx.ReadTimeout("timed out xkeysib-OCULTAR123")

    monkeypatch.setattr(email_client.httpx, "AsyncClient", _Cliente)

    async def _dormir(*args, **kwargs):
        reloj.avanzar(args[0])

    monkeypatch.setattr(email_client.asyncio, "sleep", _dormir)

    resultado = await EmailClient(CLAVE, REMITE).send("to@example.com", "a", "<p>h</p>", "h")
    assert resultado is False
    error = auditorias[-1]["error"]
    assert "timeout" in error.lower()
    assert "TimeoutError" in error
    assert "xkeysib" not in error  # sin secretos en la auditoría


async def test_smtp_respaldo_dentro_del_presupuesto(reloj, monkeypatch, auditorias):
    """Si la API falla rápido, el respaldo SMTP corre con tope <= restante."""
    smtp_llamadas = []

    def _smtp_falso(*args, **kwargs):
        timeout = args[-1] if args else kwargs.get("timeout")
        smtp_llamadas.append(timeout)
        reloj.avanzar(min(timeout, 1.0))
        # envío OK por el transporte de respaldo

    class _Cliente:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def post(self, *args, **kwargs):
            reloj.avanzar(0.5)  # falla rápida (no agota el tope)
            raise httpx.ConnectError("connection refused")

    monkeypatch.setattr(email_client.httpx, "AsyncClient", _Cliente)

    async def _dormir(*args, **kwargs):
        reloj.avanzar(args[0])

    monkeypatch.setattr(email_client.asyncio, "sleep", _dormir)
    monkeypatch.setattr(email_client, "_enviar_por_smtp", _smtp_falso)

    cliente = EmailClient(
        CLAVE, REMITE, smtp_host="smtp-relay.brevo.com", smtp_login="login", smtp_key="key"
    )
    resultado = await cliente.send("to@example.com", "a", "<p>h</p>", "h")

    assert resultado is True
    assert len(smtp_llamadas) == 1
    restante = EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS - reloj.t + min(smtp_llamadas[0], 1.0)
    assert 0 < smtp_llamadas[0] <= min(EMAIL_SMTP_TIMEOUT_SEGUNDOS, restante)
    assert auditorias[-1]["enviado"] is True and auditorias[-1]["canal"] == "smtp"


async def test_con_idempotency_key_no_hay_duplicacion_por_smtp(reloj, monkeypatch, auditorias):
    """Con idempotency_key el respaldo SMTP no se usa: no comparte la clave de
    idempotencia de la API y podría duplicar el mensaje. Los 3 reintentos HTTP
    llevan SIEMPRE la misma clave (sin duplicación entre reintentos)."""
    smtp_llamadas = []

    def _smtp_falso(*args, **kwargs):
        smtp_llamadas.append(args)

    class _Cliente:
        claves = []

        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def post(self, url, headers=None, json=None):
            _Cliente.claves.append((json or {}).get("headers", {}).get("X-Mailin-custom"))
            reloj.avanzar(0.1)
            raise httpx.ConnectError("down")

    monkeypatch.setattr(email_client.httpx, "AsyncClient", _Cliente)

    async def _dormir(*args, **kwargs):
        reloj.avanzar(args[0])

    monkeypatch.setattr(email_client.asyncio, "sleep", _dormir)
    monkeypatch.setattr(email_client, "_enviar_por_smtp", _smtp_falso)

    cliente = EmailClient(
        CLAVE,
        REMITE,
        "pedido/123/comprador",
        smtp_host="smtp-relay.brevo.com",
        smtp_login="login",
        smtp_key="key",
    )
    resultado = await cliente.send("to@example.com", "a", "<p>h</p>", "h")

    assert resultado is True  # H-03: SMTP respaldo ahora entrega cuando la API cae
    assert len(_Cliente.claves) == 3
    assert _Cliente.claves == ["pedido/123/comprador"] * 3
    # Con la corrección H-03, cuando la API de Brevo cae se intenta el respaldo
    # SMTP incluso con idempotency_key, porque el riesgo de duplicado queda
    # controlado por la bandera en BD + IdempotencyKey determinista.
    assert len(smtp_llamadas) == 1  # Se intentó el respaldo SMTP una vez
