"""Checklist: notas extremas, autorización y unicidad sobre pedidos reales de QA."""

import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def entregar(conn, pedido):
    row = await conn.fetchrow(
        """SELECT e.id, e.codigo_verificacion, pr.perfil_id
        FROM public.envios e JOIN public.pedidos p ON p.id=e.pedido_id
        JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1""",
        pedido,
    )
    await conn.execute("UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["id"])
    codigo = await conn.fetchval(
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row["id"]
    )
    await autenticar(conn, row["perfil_id"])
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1,$2)",
        row["id"],
        codigo,
    )
    await conn.execute("UPDATE public.envios SET estado='entregado' WHERE id=$1", row["id"])
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def evaluar(conn, pedido, cliente, nota):
    return await conn.fetchval(
        """INSERT INTO public.evaluaciones_reputacion
        (pedido_id,productor_id,cliente_id,puntaje)
        SELECT id,productor_id,$2,$3 FROM public.pedidos WHERE id=$1 RETURNING id""",
        pedido,
        cliente,
        nota,
    )


@pytest.mark.parametrize("nota", [1, 5])
async def test_nota_extrema_unica_sin_sancion(conn, paid_checkout, nota):
    pedido = paid_checkout["pedido_id"]
    await entregar(conn, pedido)
    productor = await conn.fetchval("SELECT productor_id FROM public.pedidos WHERE id=$1", pedido)
    antes = await conn.fetchrow(
        "SELECT activo, servicio_suspendido FROM public.productores WHERE id=$1", productor
    )
    sanciones = await conn.fetchval(
        "SELECT count(*) FROM public.sanciones WHERE productor_id=$1", productor
    )
    await autenticar(conn, CLIENTE)
    assert await evaluar(conn, pedido, CLIENTE, nota)
    with pytest.raises(asyncpg.UniqueViolationError):
        async with conn.transaction():
            await evaluar(conn, pedido, CLIENTE, nota)
    await conn.execute("RESET ROLE")
    despues = await conn.fetchrow(
        "SELECT activo, servicio_suspendido FROM public.productores WHERE id=$1", productor
    )
    assert antes == despues
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.sanciones WHERE productor_id=$1", productor
        )
        == sanciones
    )
    assert await conn.fetchval(
        """SELECT p.puntaje_reputacion=round(avg(e.puntaje),2)
        AND p.cantidad_evaluaciones=count(*) FROM public.productores p
        JOIN public.evaluaciones_reputacion e ON e.productor_id=p.id
        WHERE p.id=$1 GROUP BY p.id""",
        productor,
    )


@pytest.mark.parametrize("nota", [0, 6])
async def test_nota_fuera_rango(conn, paid_checkout, nota):
    pedido = paid_checkout["pedido_id"]
    await entregar(conn, pedido)
    await autenticar(conn, CLIENTE)
    with pytest.raises(asyncpg.CheckViolationError):
        async with conn.transaction():
            await evaluar(conn, pedido, CLIENTE, nota)
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.evaluaciones_reputacion WHERE pedido_id=$1", pedido
        )
        == 0
    )


async def test_nota_anticipada(conn, paid_checkout):
    await autenticar(conn, CLIENTE)
    with pytest.raises(asyncpg.RaiseError, match="completado"):
        async with conn.transaction():
            await evaluar(conn, paid_checkout["pedido_id"], CLIENTE, 5)
