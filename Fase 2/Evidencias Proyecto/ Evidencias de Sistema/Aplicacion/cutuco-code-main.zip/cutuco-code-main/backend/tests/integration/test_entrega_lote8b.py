"""Lote 8 — Entrega y seguimiento: máquina de estados del envío (CK-0147..0167,
CK-0392/0393/0395, CK-0516) ejecutada contra PG16 real con migraciones aplicadas.
"""

import json
import re

import asyncpg
import pytest


async def _set_auth(conn, user_id):
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE authenticated")
    await conn.execute(
        "SELECT set_config('request.jwt.claims', $1, true)",
        json.dumps({"sub": str(user_id), "role": "authenticated"}),
    )


async def _reset_auth(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims', '', true)")


async def _envio(conn, pedido_id):
    return await conn.fetchrow(
        """SELECT e.id AS envio_id, e.estado, e.codigo_verificacion, e.codigo_verificado_en,
                  e.entregado_en, pr.perfil_id AS seller_id
           FROM public.envios e
           JOIN public.pedidos p ON p.id = e.pedido_id
           JOIN public.productores pr ON pr.id = p.productor_id
           WHERE p.id = $1""",
        pedido_id,
    )


async def _clonar_pedido_pagado(conn, pedido_id):
    """Crea un segundo pedido pagado del mismo vendedor (vía SQL, rol servicio)."""
    nuevo = await conn.fetchval(
        """INSERT INTO public.pedidos
           (id, codigo_pedido, cliente_id, productor_id, region_entrega_id, comuna_entrega_id,
            direccion_entrega, nombre_destinatario, telefono_destinatario, estado,
            subtotal_productos, tarifa_delivery, porcentaje_fee_plataforma,
            monto_fee_plataforma, total)
           SELECT gen_random_uuid(), 'TEST-L8-' || substr(md5(random()::text), 1, 8),
                  cliente_id, productor_id, region_entrega_id, comuna_entrega_id,
                  direccion_entrega, nombre_destinatario, telefono_destinatario,
                  'pagado'::public.estado_pedido,
                  1000, 3500, 0.05, 50, 4500
           FROM public.pedidos WHERE id = $1
           RETURNING id""",
        pedido_id,
    )
    await conn.execute(
        """INSERT INTO public.envios (pedido_id, repartidor_id, estado, tarifa_fija)
           SELECT $1, pr.perfil_id, 'preparacion'::public.estado_envio, 3500
           FROM public.pedidos p JOIN public.productores pr ON pr.id = p.productor_id
           WHERE p.id = $1""",
        nuevo,
    )
    return nuevo


async def test_ck_0151_codigo_6_digitos_generado_al_transitar(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    # al pagar el envío nace en 'preparacion' sin código (CK-0147/CK-0470)
    assert row["estado"] == "preparacion"
    assert row["codigo_verificacion"] is None
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
    )
    codigo = await conn.fetchval(
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row["envio_id"]
    )
    assert re.fullmatch(r"[0-9]{6}", codigo), codigo


async def test_ck_0161_salto_preparacion_a_entregado_rechazado(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.envios SET estado='entregado' WHERE id=$1",
                row["envio_id"],
            )
    assert "Transicion de envio no permitida" in str(exc.value)
    estado = await conn.fetchval(
        "SELECT estado FROM public.envios WHERE id=$1", row["envio_id"]
    )
    assert estado == "preparacion"


async def test_ck_0162_retroceso_entregado_a_preparacion_rechazado(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
    )
    codigo = await conn.fetchval(  # lectura como rol servicio (RLS la oculta al vendedor)
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row["envio_id"]
    )
    await _set_auth(conn, row["seller_id"])
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)", row["envio_id"], codigo
    )
    await _reset_auth(conn)
    await conn.execute(
        "UPDATE public.envios SET estado='entregado' WHERE id=$1", row["envio_id"]
    )
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.envios SET estado='preparacion' WHERE id=$1",
                row["envio_id"],
            )
    assert "Transicion de envio no permitida" in str(exc.value)


async def test_ck_0164_codigo_de_otro_pedido_rechazado(conn, paid_checkout):
    row1 = await _envio(conn, paid_checkout["pedido_id"])
    otro_id = await _clonar_pedido_pagado(conn, paid_checkout["pedido_id"])
    row2 = await _envio(conn, otro_id)
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id IN ($1, $2)",
        row1["envio_id"],
        row2["envio_id"],
    )
    codigo2 = await conn.fetchval(
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row2["envio_id"]
    )
    await _set_auth(conn, row1["seller_id"])
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.fetchval(
                "SELECT public.verificar_codigo_entrega_vendedor($1, $2)",
                row1["envio_id"],
                codigo2,
            )
    assert "invalido" in str(exc.value).lower()
    await _reset_auth(conn)
    estado1, ver1 = await conn.fetchrow(
        "SELECT estado, codigo_verificado_en FROM public.envios WHERE id=$1",
        row1["envio_id"],
    )
    assert estado1 == "en_transito" and ver1 is None
    assert await conn.fetchval(
        "SELECT codigo_verificado_en IS NULL FROM public.envios WHERE id=$1",
        row2["envio_id"],
    )


async def test_ck_0165_doble_verificacion_es_idempotente(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
    )
    codigo = await conn.fetchval(
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row["envio_id"]
    )
    await _set_auth(conn, row["seller_id"])
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)", row["envio_id"], codigo
    )
    await _reset_auth(conn)
    primera = await conn.fetchval(
        "SELECT codigo_verificado_en FROM public.envios WHERE id=$1", row["envio_id"]
    )
    await _set_auth(conn, row["seller_id"])
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)", row["envio_id"], codigo
    )
    await _reset_auth(conn)
    segunda = await conn.fetchval(
        "SELECT codigo_verificado_en FROM public.envios WHERE id=$1", row["envio_id"]
    )
    assert primera is not None and primera == segunda


async def test_ck_0154_codigo_ya_usado_no_genera_nueva_entrega_ni_liquidacion(
    conn, paid_checkout
):
    row = await _envio(conn, paid_checkout["pedido_id"])
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
    )
    codigo = await conn.fetchval(
        "SELECT codigo_verificacion FROM public.envios WHERE id=$1", row["envio_id"]
    )
    await _set_auth(conn, row["seller_id"])
    await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)", row["envio_id"], codigo
    )
    await _reset_auth(conn)
    await conn.execute(
        "UPDATE public.envios SET estado='entregado' WHERE id=$1", row["envio_id"]
    )
    entregado_en = await conn.fetchval(
        "SELECT entregado_en FROM public.envios WHERE id=$1", row["envio_id"]
    )
    # con Webpay Mall el cobro ya se dispersó en el commit: no hay payout que duplicar
    pagos_antes = await conn.fetchval(
        "SELECT count(*) FROM public.pagos WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    await _set_auth(conn, row["seller_id"])
    assert await conn.fetchval(
        "SELECT public.verificar_codigo_entrega_vendedor($1, $2)", row["envio_id"], codigo
    )
    await _reset_auth(conn)
    assert (
        await conn.fetchval(
            "SELECT entregado_en FROM public.envios WHERE id=$1", row["envio_id"]
        )
        == entregado_en
    )
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE pedido_id=$1",
            paid_checkout["pedido_id"],
        )
        == pagos_antes
    )


async def test_ck_0167_pedido_cancelado_no_admite_transiciones(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    await _set_auth(conn, row["seller_id"])
    resultado = json.loads(
        await conn.fetchval(
            "SELECT public.cancelar_pedido_vendedor($1, $2)",
            paid_checkout["pedido_id"],
            "Producto agotado",
        )
    )
    await _reset_auth(conn)
    assert resultado["estado"] == "cancelado"
    with pytest.raises(asyncpg.RaiseError):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.envios SET estado='en_transito' WHERE id=$1",
                row["envio_id"],
            )
    with pytest.raises(asyncpg.RaiseError):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.pedidos SET estado='pagado' WHERE id=$1",
                paid_checkout["pedido_id"],
            )


async def test_ck_0393_no_se_verifica_codigo_por_update_directo(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    await conn.execute(
        "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
    )
    # UPDATE directo como rol autenticado: el trigger bloquea la trazabilidad
    await _set_auth(conn, row["seller_id"])
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.envios SET codigo_verificado_en=now() WHERE id=$1",
                row["envio_id"],
            )
    assert "RPC autorizada" in str(exc.value)
    with pytest.raises(asyncpg.RaiseError) as exc:
        async with conn.transaction():
            await conn.fetchval(
                "SELECT public.verificar_codigo_entrega_vendedor($1, $2)",
                row["envio_id"],
                "000000",
            )
    assert "invalido" in str(exc.value).lower()
    await _reset_auth(conn)
    assert await conn.fetchval(
        "SELECT codigo_verificado_en IS NULL FROM public.envios WHERE id=$1",
        row["envio_id"],
    )


async def test_ck_0395_motivo_fallo_obligatorio(conn, paid_checkout):
    row = await _envio(conn, paid_checkout["pedido_id"])
    for vacio in ("", "   "):
        with pytest.raises(asyncpg.RaiseError) as exc:
            async with conn.transaction():
                await conn.execute(
                    "UPDATE public.envios SET estado='fallido', motivo_fallo=$2 WHERE id=$1",
                    row["envio_id"],
                    vacio,
                )
        assert "justificacion" in str(exc.value).lower()
    estado = await conn.fetchval(
        "SELECT estado FROM public.envios WHERE id=$1", row["envio_id"]
    )
    assert estado == "preparacion"


async def test_ck_0516_motivo_fallo_limites_999_1000_1001(conn, paid_checkout):
    # cada caso usa su propio envío (la máquina de estados no permite fallido -> en_transito)
    for longitud, debe_fallar in ((999, False), (1000, False), (1001, True)):
        otro_id = await _clonar_pedido_pagado(conn, paid_checkout["pedido_id"])
        row = await _envio(conn, otro_id)
        await conn.execute(
            "UPDATE public.envios SET estado='en_transito' WHERE id=$1", row["envio_id"]
        )
        if debe_fallar:
            with pytest.raises(asyncpg.RaiseError) as exc:
                async with conn.transaction():
                    await conn.execute(
                        "UPDATE public.envios SET estado='fallido', motivo_fallo=$2 WHERE id=$1",
                        row["envio_id"],
                        "x" * longitud,
                    )
            assert "1000" in str(exc.value)
        else:
            await conn.execute(
                "UPDATE public.envios SET estado='fallido', motivo_fallo=$2 WHERE id=$1",
                row["envio_id"],
                "x" * longitud,
            )
            assert await conn.fetchval(
                "SELECT estado FROM public.envios WHERE id=$1", row["envio_id"]
            ) == "fallido"
