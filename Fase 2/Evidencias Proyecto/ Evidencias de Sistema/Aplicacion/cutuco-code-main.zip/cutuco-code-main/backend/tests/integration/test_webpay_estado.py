async def test_dueno_ok(client, paid_checkout, headers):
    response = await client.get(f"/api/webpay/estado/{paid_checkout['pedido_id']}", headers=headers)
    assert response.status_code == 200
    assert response.json()["estado_pago"] == "autorizado"
    assert response.json()["envio"]["estado"] == "preparacion"


async def test_otro_cliente_403(client, paid_checkout, mock_jwt):
    token = mock_jwt("a0000000-0000-0000-0000-000000000101")
    response = await client.get(
        f"/api/webpay/estado/{paid_checkout['pedido_id']}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403


async def test_admin_activo_ok(client, paid_checkout, mock_jwt):
    token = mock_jwt("a0000000-0000-0000-0000-000000000001")
    response = await client.get(
        f"/api/webpay/estado/{paid_checkout['pedido_id']}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
