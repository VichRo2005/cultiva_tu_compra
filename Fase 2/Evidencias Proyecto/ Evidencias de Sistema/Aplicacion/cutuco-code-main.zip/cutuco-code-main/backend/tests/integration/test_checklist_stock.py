"""CK-0128: ajuste manual con reservas existentes, bajo el rol real del vendedor."""

import json
from uuid import UUID

import asyncpg
import pytest

# Use product 201 (Tomates de Melipilla) from producer 002 which is active
PRODUCTO = UUID('30000000-0000-0000-0000-000000000201')
VENDEDOR = 'a0000000-0000-0000-0000-000000000102'


async def test_stock_manual_no_consumo_reserva(conn, checkout):
    reserva = await conn.fetchval('SELECT stock_reservado FROM public.productos WHERE id=$1',
                                  PRODUCTO)
    assert reserva == 2
    original = await conn.fetchval('SELECT stock FROM public.productos WHERE id=$1', PRODUCTO)
    await conn.execute("SELECT set_config('request.jwt.claims',$1,true)",
                       json.dumps({'sub': VENDEDOR, 'role': 'authenticated'}))
    await conn.execute('SET LOCAL ROLE authenticated')
    with pytest.raises(asyncpg.RaiseError, match='unidades reservadas'):
        async with conn.transaction():
            await conn.execute('UPDATE public.productos SET stock=1 WHERE id=$1', PRODUCTO)
    assert (
        await conn.fetchval('SELECT stock FROM public.productos WHERE id=$1', PRODUCTO) == original
    )
    await conn.execute('UPDATE public.productos SET stock=2 WHERE id=$1', PRODUCTO)
    assert (
        await conn.fetchval('SELECT stock FROM public.productos WHERE id=$1', PRODUCTO) == reserva
    )
