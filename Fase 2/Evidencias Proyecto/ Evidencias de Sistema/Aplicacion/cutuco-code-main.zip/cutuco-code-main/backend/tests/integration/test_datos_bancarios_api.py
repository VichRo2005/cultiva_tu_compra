"""Integración del API de datos bancarios contra Supabase local."""

import re
from uuid import UUID

import pytest_asyncio

CLIENTE_ID = "a0000000-0000-0000-0000-000000000002"
VENDEDOR_ID = "a0000000-0000-0000-0000-000000000101"
ADMIN_ID = "a0000000-0000-0000-0000-000000000001"

BODY = {
    "banco": "Banco de Pruebas",
    "tipo_cuenta": "cuenta corriente",
    "numero_cuenta": "001122334455",
    "titular_cuenta": "Titular Prueba",
    "rut_titular": "12345678-5",
}


@pytest_asyncio.fixture(autouse=True)
async def datos_bancarios_cliente_aislados(conn):
    """Aísla las pruebas de la semilla local cifrada con otra clave Fernet.

    `conn` vive dentro de una transacción que pytest revierte al final de cada
    prueba, por lo que la cuenta bancaria real de la semilla nunca se altera.
    """
    await conn.execute(
        "DELETE FROM public.datos_bancarios WHERE perfil_id=$1",
        UUID(CLIENTE_ID),
    )


async def _crear(client, headers, numero="001122334455"):
    response = await client.post(
        "/datos-bancarios", json={**BODY, "numero_cuenta": numero}, headers=headers
    )
    assert response.status_code == 201, response.text
    return response.json()


def _numero_enmascarado(item):
    return item["numero_cuenta_enmascarado"]


async def test_post_crea_y_devuelve_numero_para_el_propietario(client, headers, conn):
    data = await _crear(client, headers)
    assert _numero_enmascarado(data) == "****4455"
    assert not re.search(r"\d{5,}", _numero_enmascarado(data).replace("****", ""))
    for campo in ("banco", "tipo_cuenta", "titular_cuenta", "rut_titular", "activo", "id"):
        assert campo in data
    assert "numero_cuenta_cifrado" not in data
    assert data["numero_cuenta"] == BODY["numero_cuenta"]
    fila = await conn.fetchrow(
        "SELECT numero_cuenta_digitos, octet_length(numero_cuenta_hash) AS hash_largo "
        "FROM public.datos_bancarios WHERE id=$1",
        UUID(data["id"]),
    )
    assert fila["numero_cuenta_digitos"] == 12
    assert fila["hash_largo"] == 32


async def test_post_reemplaza_la_activa_anterior(client, headers, conn):
    primera = await _crear(client, headers, numero="111122223333")
    segunda = await _crear(client, headers, numero="555566667777")
    assert primera["id"] != segunda["id"]
    activas = await conn.fetchval(
        "SELECT count(*) FROM public.datos_bancarios WHERE perfil_id=$1 AND activo=true",
        UUID(CLIENTE_ID),
    )
    assert activas == 1
    vieja = await conn.fetchval(
        "SELECT activo FROM public.datos_bancarios WHERE id=$1", UUID(primera["id"])
    )
    assert vieja is False


async def test_get_me_solo_propias(client, headers):
    await _crear(client, headers)
    response = await client.get("/datos-bancarios/me", headers=headers)
    assert response.status_code == 200
    lista = response.json()
    assert len(lista) >= 1
    activa = next(item for item in lista if item["activo"])
    assert activa["perfil_id"] == CLIENTE_ID
    assert _numero_enmascarado(activa).startswith("****")


async def test_patch_propietario_ok(client, headers):
    creada = await _crear(client, headers)
    response = await client.patch(
        f"/datos-bancarios/{creada['id']}",
        json={"banco": "Banco Nuevo"},
        headers=headers,
    )
    assert response.status_code == 200, response.text
    assert response.json()["banco"] == "Banco Nuevo"
    assert _numero_enmascarado(response.json()) == "****4455"


async def test_patch_cambia_numero_en_sitio(client, headers):
    creada = await _crear(client, headers)
    response = await client.patch(
        f"/datos-bancarios/{creada['id']}",
        json={"numero_cuenta": "999988887766"},
        headers=headers,
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["id"] == creada["id"]  # PATCH actualiza en sitio, sin nueva versión
    assert _numero_enmascarado(data) == "****7766"


async def test_patch_otro_usuario_403(client, headers, mock_jwt):
    creada = await _crear(client, headers)
    token = mock_jwt(VENDEDOR_ID)
    response = await client.patch(
        f"/datos-bancarios/{creada['id']}",
        json={"banco": "X"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403


async def test_patch_admin_ok(client, headers, mock_jwt):
    creada = await _crear(client, headers)
    token = mock_jwt(ADMIN_ID)
    response = await client.patch(
        f"/datos-bancarios/{creada['id']}",
        json={"banco": "Banco Admin"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200


async def test_patch_inexistente_404(client, headers):
    response = await client.patch(
        "/datos-bancarios/b0000000-0000-0000-0000-000000000000",
        json={"banco": "X"},
        headers=headers,
    )
    assert response.status_code == 404


async def test_admin_ve_numero_completo_para_revisar_postulacion(client, mock_jwt, headers):
    await _crear(client, headers)
    token = mock_jwt(ADMIN_ID)
    response = await client.get(
        f"/datos-bancarios/admin/{CLIENTE_ID}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    lista = response.json()
    assert lista
    for item in lista:
        assert item["numero_cuenta_enmascarado"].startswith("****")
        assert item["numero_cuenta"] == BODY["numero_cuenta"]
        assert "numero_cuenta_cifrado" not in item


async def test_admin_endpoint_prohibido_para_no_admin(client, headers):
    response = await client.get(f"/datos-bancarios/admin/{CLIENTE_ID}", headers=headers)
    assert response.status_code == 403


async def test_requiere_jwt(client):
    assert (await client.get("/datos-bancarios/me")).status_code == 401
    assert (await client.post("/datos-bancarios", json=BODY)).status_code == 401


async def test_post_valida_rut(client, headers):
    response = await client.post(
        "/datos-bancarios", json={**BODY, "rut_titular": "12345678-9"}, headers=headers
    )
    assert response.status_code == 422


async def test_post_rechaza_numero_de_13_digitos(client, headers):
    response = await client.post(
        "/datos-bancarios", json={**BODY, "numero_cuenta": "1234567890123"}, headers=headers
    )
    assert response.status_code == 422
    assert "7" in response.text and "12" in response.text


VENDEDOR_1 = "a0000000-0000-0000-0000-000000000101"
VENDEDOR_2 = "a0000000-0000-0000-0000-000000000102"
CUENTA_VENDEDOR = {
    "banco": "Banco Único",
    "tipo_cuenta": "cuenta_corriente",
    "numero_cuenta": "1234567890",
    "titular_cuenta": "Productor Paine",
    "rut_titular": "12345678-5",
}


async def test_vendedor_guarda_cuenta_propia(client, mock_jwt):
    token = mock_jwt(VENDEDOR_1)
    response = await client.post(
        "/datos-bancarios",
        json=CUENTA_VENDEDOR,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 201, response.text
    assert response.json()["numero_cuenta_enmascarado"] == "****7890"


async def test_vendedor_no_puede_usar_titular_de_tercero(client, mock_jwt):
    token = mock_jwt(VENDEDOR_1)
    response = await client.post(
        "/datos-bancarios",
        json={**CUENTA_VENDEDOR, "titular_cuenta": "Juan Soto"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422
    assert "titular no coincide" in response.text


async def test_vendedor_no_puede_usar_rut_de_tercero(client, mock_jwt):
    token = mock_jwt(VENDEDOR_1)
    response = await client.post(
        "/datos-bancarios",
        json={**CUENTA_VENDEDOR, "rut_titular": "11111111-1"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422
    assert "RUT del titular" in response.text


async def test_cuenta_duplicada_entre_vendedores_409(client, mock_jwt):
    first = await client.post(
        "/datos-bancarios",
        json=CUENTA_VENDEDOR,
        headers={"Authorization": f"Bearer {mock_jwt(VENDEDOR_1)}"},
    )
    assert first.status_code == 201, first.text
    second = await client.post(
        "/datos-bancarios",
        json={**CUENTA_VENDEDOR, "titular_cuenta": "Productor Melipilla"},
        headers={"Authorization": f"Bearer {mock_jwt(VENDEDOR_2)}"},
    )
    assert second.status_code == 409, second.text
    assert "Ya existe una cuenta bancaria" in second.text
