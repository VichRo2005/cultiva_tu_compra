"""Matriz CK-0408..0443: PostgreSQL real, sin pasarelas ni correos reales."""
import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = 'a0000000-0000-0000-0000-000000000002'
# Vendedor cuyo producto se usa en checkout (product 201 = Tomates de Melipilla, producer 002)
VENDEDOR_PEDIDO = 'a0000000-0000-0000-0000-000000000102'
# Otro vendedor distinto del del pedido (producer 003 = Quillota)
OTRO_VENDEDOR = 'a0000000-0000-0000-0000-000000000103'
OTRO_CLIENTE = 'a0000000-0000-0000-0000-000000009999'
# Productor original Paine (producer 001) - ahora "Huerta del Desarrollador"
PRODUCTOR_PAINE = '20000000-0000-0000-0000-000000000001'
PERFIL_PAINE = 'e0000000-0000-0000-0000-000000000002'


async def actor(conn, perfil):
    if perfil == OTRO_CLIENTE:
        await conn.execute('''INSERT INTO auth.users (id,raw_user_meta_data)
            VALUES ($1,'{"nombre":"Cliente QA","tipo_registro":"cliente"}'::jsonb)''',
            UUID(OTRO_CLIENTE))
        assert await conn.fetchval('SELECT rol FROM public.perfiles WHERE id=$1',
                                   UUID(OTRO_CLIENTE)) == 'cliente'
    await conn.execute('SET LOCAL ROLE ' + ('authenticated' if perfil else 'anon'))
    await conn.execute("SELECT set_config('request.jwt.claims', $1, true)",
                       json.dumps({'sub': perfil, 'role': 'authenticated'} if perfil else {}))


@pytest.mark.parametrize('perfil', [None, OTRO_CLIENTE, OTRO_VENDEDOR])
@pytest.mark.parametrize('table,field,value', [
    ('perfiles', 'id', CLIENTE),
    ('pagos_servicio', 'productor_id', PRODUCTOR_PAINE),
    ('datos_bancarios', 'perfil_id', VENDEDOR_PEDIDO),
])
async def test_no_lee_recurso_ajeno(conn, perfil, table, field, value):
    if table == 'datos_bancarios':
        existe = await conn.fetchval(
            'SELECT 1 FROM public.datos_bancarios WHERE perfil_id=$1 AND activo=true',
            UUID(value),
        )
        if not existe:
            await conn.execute('''INSERT INTO public.datos_bancarios
                (perfil_id,banco,tipo_cuenta,numero_cuenta_cifrado,numero_cuenta_hash,
                 numero_cuenta_digitos,titular_cuenta,rut_titular)
                VALUES ($1,'Banco QA','cuenta_corriente',decode('00','hex'),
                        decode(repeat('01',32),'hex'),10,'Titular QA','12345678-5')''', UUID(value))
    # Nombres definidos por la prueba, nunca por entrada de usuario.
    query = f'SELECT count(*) FROM public.{table} WHERE {field}=$1'
    assert await conn.fetchval(query, UUID(value)) > 0, 'Fixture debe existir'
    await actor(conn, perfil)
    try:
        async with conn.transaction():
            assert await conn.fetchval(query, UUID(value)) == 0
    except asyncpg.InsufficientPrivilegeError:
        pass
    cambios = {'perfiles': "nombre='Cambio no autorizado'",
               'pagos_servicio': "estado='pagado'",
               'datos_bancarios': "banco='Cambio no autorizado'"}
    try:
        async with conn.transaction():
            assert await conn.fetch(
                f'UPDATE public.{table} SET {cambios[table]} WHERE {field}=$1 RETURNING id',
                UUID(value)) == []
    except asyncpg.InsufficientPrivilegeError:
        pass


@pytest.mark.parametrize('perfil', [None, OTRO_CLIENTE, OTRO_VENDEDOR])
async def test_no_lee_pedido_pago_ni_codigo_ajeno(conn, paid_checkout, perfil):
    """
    Verifica que usuarios ajenos al pedido no pueden leerlo ni modificarlo.
    OTRO_VENDEDOR es un vendedor DISTINTO del que creó el pedido (producer 003 vs 002).
    """
    pedido_id = UUID(str(paid_checkout['pedido_id']))
    envio_id = await conn.fetchval('SELECT id FROM public.envios WHERE pedido_id=$1', pedido_id)
    assert envio_id is not None
    await actor(conn, perfil)
    for query, key in [
        ('SELECT id FROM public.pedidos WHERE id=$1', pedido_id),
        ('SELECT id FROM public.pagos WHERE pedido_id=$1', pedido_id),
        ('SELECT codigo_verificacion FROM public.envios WHERE id=$1', envio_id),
        ("UPDATE public.pedidos SET estado='cancelado' WHERE id=$1 RETURNING id", pedido_id),
        ('UPDATE public.pagos SET monto=monto+1 WHERE pedido_id=$1 RETURNING id', pedido_id),
    ]:
        try:
            async with conn.transaction():
                assert await conn.fetch(query, key) == []
        except asyncpg.InsufficientPrivilegeError:
            pass


@pytest.mark.parametrize('perfil', [None, CLIENTE, OTRO_VENDEDOR])
async def test_no_modifica_producto_ajeno_ni_geografia(conn, perfil):
    producto_id = UUID('30000000-0000-0000-0000-000000000101')
    precio = await conn.fetchval('SELECT precio FROM public.productos WHERE id=$1', producto_id)
    assert precio is not None
    await actor(conn, perfil)
    for query, args in [
        ('UPDATE public.productos SET precio=1 WHERE id=$1 RETURNING id', [producto_id]),
        ("UPDATE public.regiones SET nombre='Alterado' RETURNING id", []),
        ("UPDATE public.comunas SET nombre='Alterado' RETURNING id", []),
    ]:
        try:
            async with conn.transaction():
                assert await conn.fetch(query, *args) == []
        except asyncpg.InsufficientPrivilegeError:
            pass


@pytest.mark.parametrize('caso', ['productor_inactivo', 'servicio_suspendido', 'perfil_inactivo'])
async def test_catalogo_publico_oculta_tienda_no_operable(conn, caso):
    producto = UUID('30000000-0000-0000-0000-000000000101')
    productor = UUID(PRODUCTOR_PAINE)
    perfil = UUID(PERFIL_PAINE)
    assert await conn.fetchval('SELECT count(*) FROM public.productos WHERE id=$1', producto) == 1
    if caso == 'productor_inactivo':
        await conn.execute('UPDATE public.productores SET activo=false WHERE id=$1', productor)
    elif caso == 'servicio_suspendido':
        await conn.execute(
            'UPDATE public.productores SET servicio_suspendido=true WHERE id=$1', productor
        )
    else:
        await conn.execute('UPDATE public.perfiles SET activo=false WHERE id=$1', perfil)
    await actor(conn, None)
    assert await conn.fetchval('SELECT count(*) FROM public.productos WHERE id=$1', producto) == 0
    assert await conn.fetchval(
        'SELECT count(*) FROM public.imagenes_productos WHERE producto_id=$1', producto
    ) == 0


async def test_dueno_conserva_producto_pausado_para_gestion(conn):
    producto = UUID('30000000-0000-0000-0000-000000000101')
    await conn.execute(
        "UPDATE public.productos SET activo=false,motivo_pausa='Pausa de gestión QA' WHERE id=$1",
        producto,
    )
    await actor(conn, PERFIL_PAINE)
    assert await conn.fetchval('SELECT count(*) FROM public.productos WHERE id=$1', producto) == 1
    assert await conn.fetchval(
        'SELECT count(*) FROM public.imagenes_productos WHERE producto_id=$1', producto
    ) > 0


async def test_comuna_publica_real_sin_direccion(conn):
    esperado = await conn.fetchrow('''SELECT d.comuna_id, c.nombre FROM public.direcciones d
        JOIN public.comunas c ON c.id=d.comuna_id
        WHERE d.perfil_id=$1 AND d.activo ORDER BY d.es_principal DESC, d.id LIMIT 1''',
        UUID(PERFIL_PAINE))
    assert esperado is not None
    await actor(conn, None)
    rows = await conn.fetch('SELECT * FROM public.ubicaciones_publicas_productores($1::uuid[])',
                            [UUID(PERFIL_PAINE)])
    assert len(rows) == 1
    assert set(rows[0].keys()) == {'perfil_id', 'comuna_id', 'nombre', 'region_id'}
    assert rows[0]['comuna_id'] == esperado['comuna_id']
    assert rows[0]['nombre'] == esperado['nombre']
