"""Lote 23 — CK-0286: el envío de correo respeta el presupuesto ERS (<10 s).

El cliente HTTP y el respaldo SMTP quedan con tope propio <= 10 s (constantes
del módulo), un timeout del proveedor se clasifica como TimeoutError sin
secretos, y agotados los reintentos el envío retorna False sin bloquear más.
"""

import httpx
import pytest

from app.integrations.email import client as email_client
from app.integrations.email.client import (
    EMAIL_HTTP_TIMEOUT_SEGUNDOS,
    EMAIL_SMTP_TIMEOUT_SEGUNDOS,
    EmailClient,
    clasificar_error_correo,
)

REMITE = "CuTuCo <no-reply@cutuco.cl>"
CLAVE = "xkeysib-clave-de-prueba"


def test_ck_0286_topes_de_envio_bajo_10_segundos():
    assert EMAIL_HTTP_TIMEOUT_SEGUNDOS <= 10
    assert EMAIL_SMTP_TIMEOUT_SEGUNDOS <= 10


def test_ck_0286_timeout_se_clasifica_sin_secretos():
    mensaje = clasificar_error_correo(httpx.ReadTimeout("timed out xkeysib-aaaaBBBB1234"))
    assert "timeout" in mensaje.lower()
    assert "xkeysib" not in mensaje


class _ClienteTimeout:
    """httpx.AsyncClient falso que siempre agota el tiempo de espera."""

    llamadas = 0

    def __init__(self, *args, **kwargs) -> None:
        self.timeout = kwargs.get("timeout")

    async def __aenter__(self) -> "_ClienteTimeout":
        return self

    async def __aexit__(self, *args) -> bool:
        return False

    async def post(self, *args, **kwargs):
        type(self).llamadas += 1
        raise httpx.ConnectTimeout("timed out")


async def test_ck_0286_timeout_agota_reintentos_y_retorna_false(monkeypatch):
    _ClienteTimeout.llamadas = 0
    monkeypatch.setattr(email_client.httpx, "AsyncClient", _ClienteTimeout)

    async def _sin_espera(*args, **kwargs) -> None:
        return None

    monkeypatch.setattr(email_client.asyncio, "sleep", _sin_espera)
    auditorias: list[dict] = []
    monkeypatch.setattr(email_client, "_guardar_auditoria", lambda *a, **k: auditorias.append(k))

    resultado = await EmailClient(CLAVE, REMITE).send(
        "to@example.com", "asunto", "<p>hola</p>", "hola"
    )

    assert resultado is False
    assert _ClienteTimeout.llamadas == 3  # 3 intentos, sin bucle infinito
    assert auditorias and "timeout" in auditorias[-1]["error"].lower()
