"""CK-0319: funciones privilegiadas con search_path y EXECUTE mínimos."""


async def test_security_definer_tiene_search_path_fijo(conn):
    inseguras = await conn.fetch(
        """SELECT n.nspname,p.proname
        FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
        WHERE n.nspname IN ('public','private') AND p.prosecdef
          AND NOT EXISTS (
            SELECT 1 FROM unnest(coalesce(p.proconfig,ARRAY[]::text[])) c
            WHERE c LIKE 'search_path=%'
          )"""
    )
    assert inseguras == []


async def test_funciones_internas_no_son_rpc_autenticadas(conn):
    for firma in (
        'private.crear_cuota_servicio(uuid)',
        'private.sincronizar_morosidad_productor(uuid)',
        'private.liberar_reservas_expiradas()',
        'private.liberar_reservas_checkout(uuid)',
    ):
        assert not await conn.fetchval(
            "SELECT has_function_privilege('anon',$1,'EXECUTE')", firma
        )
        assert not await conn.fetchval(
            "SELECT has_function_privilege('authenticated',$1,'EXECUTE')", firma
        )


async def test_rpc_publicas_tienen_roles_explicitos(conn):
    assert not await conn.fetchval(
        "SELECT has_function_privilege('anon','public.admin_servicio_resumen()','EXECUTE')"
    )
    assert await conn.fetchval(
        "SELECT has_function_privilege('authenticated','public.admin_servicio_resumen()','EXECUTE')"
    )
    assert not await conn.fetchval(
        "SELECT has_function_privilege("
        "'anon','public.resolver_pago_servicio(uuid,text,text)','EXECUTE')"
    )
    assert await conn.fetchval(
        "SELECT has_function_privilege('anon','public.perfil_publico_productor(uuid)','EXECUTE')"
    )
