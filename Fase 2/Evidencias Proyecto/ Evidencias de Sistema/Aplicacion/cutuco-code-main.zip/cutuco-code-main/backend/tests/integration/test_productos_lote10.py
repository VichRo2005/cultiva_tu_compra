"""Lote 10 — Tienda y productos (lado BD), ejecutado contra PG16 real.

CK-0138 aislamiento de pedidos por vendedor; CK-0139 gestión bloqueada sin
habilitación; CK-0141 snapshot del detalle ante edición posterior;
CK-0142 política de última escritura sin corrupción de stock; CK-0145 unidad
autorizada; CK-0146 pedidos trazables con tienda suspendida; CK-0383 precio
negativo/decimal rechazado en BD; CK-0389 categoría inexistente rechazada;
CK-0494 jerarquía de categorías sin duplicados; CK-0514 (BD) topes del tipo
numeric(12,2)/numeric(12,3).
"""

import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
VENDEDOR_PAUSADO = UUID("a0000000-0000-0000-0000-000000000104")  # productor 20000000-...-0004 NOT activo
OTRO_VENDEDOR = UUID("a0000000-0000-0000-0000-000000000103")      # productor Quillota


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def mi_productor(conn, perfil):
    return await conn.fetchval(
        "SELECT id FROM public.productores WHERE perfil_id=$1", perfil
    )


_CONTADOR = [0]


async def insertar_producto(conn, productor_id, **over):
    _CONTADOR[0] += 1
    datos = {
        "productor_id": productor_id,
        "codigo_producto": f"PRD-T{_CONTADOR[0]:06d}",
        "nombre": "Producto lote10",
        "precio": 1000,
        "stock": 5,
        "unidad_medida": "unidad",
    }
    datos.update(over)
    cols = ",".join(datos)
    vals = ",".join(f"${i+1}" for i in range(len(datos)))
    return await conn.fetchval(
        f"INSERT INTO public.productos ({cols}) VALUES ({vals}) RETURNING id",
        *datos.values(),
    )


async def test_ck_0138_vendedor_solo_ve_sus_pedidos(conn, paid_checkout):
    pedido = paid_checkout["pedido_id"]
    vendedor = await conn.fetchval(  # como superuser: la RLS ocultaría la fila
        "SELECT pr.perfil_id FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        pedido,
    )
    await autenticar(conn, OTRO_VENDEDOR)
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos WHERE id=$1", pedido) == 0
    await autenticar(conn, vendedor)
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos WHERE id=$1", pedido) == 1
    await autenticar(conn, CLIENTE)
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos WHERE id=$1", pedido) == 1


async def test_ck_0139_sin_habilitacion_no_gestiona(conn):
    productor = await mi_productor(conn, VENDEDOR_PAUSADO)
    await reset(conn)
    activo = await conn.fetchval("SELECT activo FROM public.productores WHERE id=$1", productor)
    assert activo is False
    await autenticar(conn, VENDEDOR_PAUSADO)
    with pytest.raises(asyncpg.PostgresError):
        async with conn.transaction():
            await insertar_producto(conn, productor)
    # tampoco puede actualizar productos propios estando desactivado (RLS filtra en silencio)
    status = await conn.execute(
        "UPDATE public.productos SET stock=stock+1 WHERE productor_id=$1", productor
    )
    assert status == "UPDATE 0"
    await reset(conn)
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.productos WHERE productor_id=$1 AND nombre='Producto lote10'",
            productor,
        )
        == 0
    )


async def test_ck_0141_detalle_conserva_snapshot(conn, paid_checkout):
    pedido = paid_checkout["pedido_id"]
    detalle = await conn.fetchrow(
        "SELECT producto_id, producto_nombre, precio_unitario, cantidad, subtotal "
        "FROM public.detalles_pedido WHERE pedido_id=$1",
        pedido,
    )
    assert detalle["producto_nombre"] and detalle["precio_unitario"] > 0
    await reset(conn)
    await conn.execute(
        "UPDATE public.productos SET nombre='Cambiado', precio=99999 WHERE id=$1",
        detalle["producto_id"],
    )
    despues = await conn.fetchrow(
        "SELECT producto_nombre, precio_unitario, cantidad, subtotal "
        "FROM public.detalles_pedido WHERE pedido_id=$1",
        pedido,
    )
    for campo in ("producto_nombre", "precio_unitario", "cantidad", "subtotal"):
        assert despues[campo] == detalle[campo]  # el histórico no se altera


async def test_ck_0142_ultima_escritura_explicita_sin_corromper_stock(conn, paid_checkout):
    await reset(conn)
    producto = await conn.fetchval(
        "SELECT producto_id FROM public.detalles_pedido WHERE pedido_id=$1",
        paid_checkout["pedido_id"],
    )
    vendedor = await conn.fetchval(
        "SELECT pr.perfil_id FROM public.productos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        producto,
    )
    await autenticar(conn, vendedor)
    # dos "pestañas": última escritura gana de forma explícita y consistente
    await conn.execute("UPDATE public.productos SET precio=2000, stock=10 WHERE id=$1", producto)
    await conn.execute("UPDATE public.productos SET precio=3000 WHERE id=$1", producto)
    fila = await conn.fetchrow(
        "SELECT precio, stock, activo FROM public.productos WHERE id=$1", producto
    )
    assert fila["precio"] == 3000 and fila["stock"] == 10 and fila["activo"]
    # stock negativo sigue bloqueado (CHECK + trigger de reservados) aunque haya carreras
    with pytest.raises(asyncpg.PostgresError):
        async with conn.transaction():
            await conn.execute("UPDATE public.productos SET stock=-1 WHERE id=$1", producto)
    assert (
        await conn.fetchval("SELECT stock FROM public.productos WHERE id=$1", producto) == 10
    )


async def test_ck_0145_unidad_autorizada(conn, paid_checkout):
    await reset(conn)
    vendedor = await conn.fetchval(
        "SELECT pr.perfil_id FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        paid_checkout["pedido_id"],
    )
    productor = await mi_productor(conn, vendedor)
    await autenticar(conn, vendedor)
    pid = await insertar_producto(conn, productor, nombre="Por kilo", unidad_medida="kg", precio=2500)
    unidad = await conn.fetchval("SELECT unidad_medida FROM public.productos WHERE id=$1", pid)
    assert unidad == "kg"
    with pytest.raises(asyncpg.InvalidTextRepresentationError):
        async with conn.transaction():
            await insertar_producto(conn, productor, nombre="Mala unidad", unidad_medida="tonelada")


async def test_ck_0146_pedidos_trazables_con_tienda_suspendida(conn, paid_checkout):
    pedido = paid_checkout["pedido_id"]
    # suspende el servicio del productor (solo superuser puede tocar el flag)
    await reset(conn)
    await conn.execute(
        "UPDATE public.productores SET servicio_suspendido=true WHERE id="
        "(SELECT productor_id FROM public.pedidos WHERE id=$1)",
        pedido,
    )
    # el pedido sigue visible para el cliente y el reclamo sigue habilitado
    await autenticar(conn, CLIENTE)
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos WHERE id=$1", pedido) == 1
    reclamo = await conn.fetchval(
        "INSERT INTO public.reclamos (pedido_id, cliente_id, motivo, descripcion) "
        "VALUES ($1,$2,'Producto dañado','Llegó dañado.') RETURNING id",
        pedido, CLIENTE,
    )
    assert reclamo
    # pero el producto ya no es público
    await reset(conn)
    publico = await conn.fetchval(
        "SELECT count(*) FROM public.productos p JOIN public.pedidos pd ON pd.productor_id=p.productor_id "
        "WHERE pd.id=$1 AND p.activo AND p.eliminado_en IS NULL AND (SELECT private.productor_operable(p.productor_id))",
        pedido,
    )
    assert publico == 0


async def test_ck_0383_precio_invalido_rechazado_en_bd(conn, paid_checkout):
    await reset(conn)
    vendedor = await conn.fetchval(
        "SELECT pr.perfil_id FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        paid_checkout["pedido_id"],
    )
    productor = await mi_productor(conn, vendedor)
    await autenticar(conn, vendedor)
    # trigger de rango + CHECK ck_producto_precio_no_negativo
    with pytest.raises(asyncpg.PostgresError, match="precio"):
        async with conn.transaction():
            await insertar_producto(conn, productor, nombre="Negativo", precio=-5)
    # CHECK ck_producto_precio_entero (CLP sin centavos)
    with pytest.raises(asyncpg.PostgresError):
        async with conn.transaction():
            await insertar_producto(conn, productor, nombre="Decimal", precio=1500.5)


async def test_ck_0389_categoria_inexistente_rechazada(conn, paid_checkout):
    await reset(conn)
    vendedor = await conn.fetchval(
        "SELECT pr.perfil_id FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        paid_checkout["pedido_id"],
    )
    productor = await mi_productor(conn, vendedor)
    await autenticar(conn, vendedor)
    with pytest.raises(asyncpg.ForeignKeyViolationError):
        async with conn.transaction():
            await insertar_producto(
                conn, productor, nombre="Sin cat", categoria_id=UUID("c0000000-0000-0000-0000-000000000001")
            )


async def test_ck_0494_categorias_jerarquicas_sin_duplicados(conn):
    await reset(conn)
    duplicados = await conn.fetchval(
        "SELECT count(*) FROM (SELECT lower(nombre) n FROM public.categorias "
        "WHERE eliminado_en IS NULL GROUP BY lower(nombre) HAVING count(*)>1) d"
    )
    assert duplicados == 0
    huerfanas = await conn.fetchval(
        "SELECT count(*) FROM public.categorias c WHERE c.eliminado_en IS NULL "
        "AND c.categoria_padre_id IS NOT NULL AND NOT EXISTS ("
        "SELECT 1 FROM public.categorias p WHERE p.id=c.categoria_padre_id AND p.eliminado_en IS NULL)"
    )
    assert huerfanas == 0
    # 'Sin Categoría' es de sistema y no se ofrece como opción de publicación
    sistema = await conn.fetchval(
        "SELECT es_sistema FROM public.categorias WHERE slug='sin-categoria'"
    )
    assert sistema is True


async def test_ck_0514_bd_topes_tipo_numerico(conn, paid_checkout):
    await reset(conn)
    vendedor = await conn.fetchval(
        "SELECT pr.perfil_id FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1",
        paid_checkout["pedido_id"],
    )
    productor = await mi_productor(conn, vendedor)
    await autenticar(conn, vendedor)
    # El límite comercial de precio se aplica incluso cuando el tipo numérico
    # todavía podría representarlo.
    with pytest.raises(asyncpg.RaiseError, match="999.999"):
        async with conn.transaction():
            await insertar_producto(conn, productor, nombre="Precio enorme", precio=1_000_000)
    # numeric(12,3): máximo 999.999.999,999 -> 1e9+ desborda
    with pytest.raises(asyncpg.NumericValueOutOfRangeError):
        async with conn.transaction():
            await insertar_producto(conn, productor, nombre="Stock enorme", stock=10**9)
    # dentro de ambos topes comerciales sí se acepta.
    pid = await insertar_producto(conn, productor, nombre="Topes", precio=999999, stock=999999)
    assert pid
