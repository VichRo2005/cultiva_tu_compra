"""CK-0078/0082/0083 — contrato de IniciarRequest: vacío, boleta y factura B2B."""

import pytest
from pydantic import ValidationError

from app.schemas.webpay import Boleta, Factura, IniciarRequest

ITEM = {
    "producto_id": "00000000-0000-0000-0000-000000000002",
    "cantidad": 1,
}
DIRECCION = "00000000-0000-0000-0000-000000000001"


def test_carrito_vacio_rechazado_antes_de_la_pasarela():
    # min_length=1: una lista vacía nunca llega a Webpay (422 de validación)
    with pytest.raises(ValidationError):
        IniciarRequest(direccion_id=DIRECCION, items=[])


def test_boleta_es_el_documento_por_defecto_y_usa_rut_generico():
    req = IniciarRequest(direccion_id=DIRECCION, items=[ITEM])
    assert isinstance(req.documento_tributario, Boleta)
    # el servicio congela el RUT genérico 66.666.666-6 (webpay_service.iniciar_checkout)
    assert req.documento_tributario.model_dump()["tipo"] == "boleta"


def test_factura_b2b_exige_rut_empresa_razon_social_giro_y_direccion():
    with pytest.raises(ValidationError):
        Factura()  # type: ignore[call-arg]
    valida = Factura(
        tipo="factura",
        rut_empresa="12345678-5",  # DV válido (módulo 11)
        razon_social="Agrícola Ejemplo SpA",
        giro="Comercialización de productos agrícolas",
        direccion_tributaria="Av. Siempre Viva 123, Santiago",
    )
    assert valida.rut_empresa == "12345678-5"


def test_factura_rechaza_rut_invalido():
    with pytest.raises(ValidationError):
        Factura(
            tipo="factura",
            rut_empresa="12345678-0",  # dígito verificador incorrecto
            razon_social="X",
            giro="Y",
            direccion_tributaria="Z 1",
        )


def test_monto_esperado_es_entero_estricto():
    with pytest.raises(ValidationError):
        IniciarRequest(direccion_id=DIRECCION, items=[ITEM], monto_esperado=10.5)  # type: ignore[arg-type]
    ok = IniciarRequest(direccion_id=DIRECCION, items=[ITEM], monto_esperado=1000)
    assert ok.monto_esperado == 1000
