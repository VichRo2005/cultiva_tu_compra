"""El reintento de correos normaliza registros asyncpg antes de usar plantillas."""

from contextlib import asynccontextmanager
from decimal import Decimal
from uuid import uuid4

from app.services import email_service


class _Record:
    """Doble mínimo de asyncpg.Record: no expone `.get()`."""

    def __init__(self, **values):
        self._values = values

    def keys(self):
        return self._values.keys()

    def __getitem__(self, key):
        return self._values[key]


class _Transaction:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False


class _Connection:
    def __init__(self, pedido_id):
        self.pedido_id = pedido_id
        self.updates = []

    def transaction(self):
        return _Transaction()

    async def fetchrow(self, query, *_):
        if "FROM public.pedidos" in query:
            return _Record(
                id=self.pedido_id,
                codigo_pedido="CTC-20261119-MAIL01",
                total=7000,
                tarifa_delivery=3500,
                cliente_id=uuid4(),
                documento_tributario={"tipo": "boleta"},
                correo_comprador_enviado_en=None,
                correo_productor_enviado_en=None,
            )
        if query.startswith("UPDATE public.pedidos"):
            self.updates.append(query)
            return _Record(id=self.pedido_id)
        if "FROM public.pagos" in query:
            return _Record(codigo_comercio="597055555536", codigo_autorizacion="123456")
        raise AssertionError(query)

    async def fetch(self, query, *_):
        assert "codigo_producto" in query
        return [_Record(id="producto-1", codigo_producto="CTC-PROD-01")]

    async def fetchval(self, query, *_):
        assert "SELECT monto" in query
        return Decimal("6650")

    async def execute(self, query, *_):
        self.updates.append(query)


async def test_reintento_compra_acepta_records_de_asyncpg(monkeypatch):
    pedido_id = uuid4()
    conn = _Connection(pedido_id)

    @asynccontextmanager
    async def scope():
        yield conn

    contexto = _Record(
        comprador_email="cliente@example.com",
        productor_email="vendedor@example.com",
        productor_perfil_id=uuid4(),
        nombre_comercial="Huerto Norte",
    )
    item = _Record(producto_id="producto-1", producto_nombre="Tomates", cantidad=2, subtotal=3500)
    enviados = []

    async def enviar_comprador(*args, **kwargs):
        enviados.append((args, kwargs))
        return True

    monkeypatch.setattr(email_service, "connection_scope", scope)
    monkeypatch.setattr(
        email_service.pedidos_repo, "get_email_context", lambda *_: _async(contexto)
    )
    monkeypatch.setattr(
        email_service.detalles_pedido_repo, "get_by_pedido", lambda *_: _async([item])
    )
    monkeypatch.setattr(email_service, "_generar_pdf_adjunto", lambda **_: _async(None))
    monkeypatch.setattr(email_service, "enviar_correo_compra_comprador", enviar_comprador)
    monkeypatch.setattr(
        email_service.preferencias_notificacion_repo, "recibe_correo", lambda *_: _async(True)
    )

    await email_service.enviar_pendiente(pedido_id, "comprador")

    assert len(enviados) == 1
    assert enviados[0][0][0] == "cliente@example.com"
    assert enviados[0][0][3][0]["codigo_producto"] == "CTC-PROD-01"
    assert conn.updates


async def test_preferencia_desactivada_omite_el_correo_de_compra(monkeypatch):
    pedido_id = uuid4()
    conn = _Connection(pedido_id)

    @asynccontextmanager
    async def scope():
        yield conn

    contexto = _Record(
        comprador_email="cliente@example.com",
        productor_email="vendedor@example.com",
        productor_perfil_id=uuid4(),
        nombre_comercial="Huerto Norte",
    )
    enviados = []

    async def enviar_comprador(*args, **kwargs):
        enviados.append((args, kwargs))
        return True

    monkeypatch.setattr(email_service, "connection_scope", scope)
    monkeypatch.setattr(
        email_service.pedidos_repo, "get_email_context", lambda *_: _async(contexto)
    )
    monkeypatch.setattr(email_service, "enviar_correo_compra_comprador", enviar_comprador)
    monkeypatch.setattr(
        email_service.preferencias_notificacion_repo, "recibe_correo", lambda *_: _async(False)
    )

    await email_service.enviar_pendiente(pedido_id, "comprador")

    assert enviados == []
    assert any("correo_comprador_omitido_en" in query for query in conn.updates)


async def _async(value):
    return value
