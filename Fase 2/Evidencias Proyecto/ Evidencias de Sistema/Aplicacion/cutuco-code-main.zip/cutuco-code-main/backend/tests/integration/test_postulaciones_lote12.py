"""Lote 12 — Postulación y KYB (lado BD), PG16 real con rollback por test.

CK-0217/0219 borrador con datos de tienda; CK-0221/0222 los 4 documentos+KYB
obligatorios para enviar; CK-0224 aislamiento (sólo dueño/admin) y sin venta;
CK-0227/0229/0230 aprobación exige código Mall y promueve a vendedor;
CK-0228/0237 rechazo con motivo archivado y reenvío; CK-0231/0232 límite 3 +
reinicio auditado; CK-0236 código Mall inmutable para el vendedor;
CK-0240 doble aprobación rechazada; CK-0223 RLS del bucket vendedor-documentos;
CK-0220 datos bancarios propios (RLS).
"""

import json
from uuid import UUID, uuid4

import asyncpg
import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
OTRO = UUID("a0000000-0000-0000-0000-000000000002")
COMUNA_SEED = UUID("12000000-0000-0000-0000-000000000004")
CODIGO_MALL = "597055555532"  # 12 dígitos, sandbox integration


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def alta_cliente(conn, email):
    await conn.execute("RESET ROLE")
    uid = uuid4()
    await conn.execute(
        """INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at,
             raw_user_meta_data, aud, role, created_at, updated_at)
           VALUES ($1,$2,'x',now(),$3,'authenticated','authenticated',now(),now())""",
        uid,
        email,
        json.dumps({"nombre": "Postulante", "apellido": "Lote12"}),
    )
    return uid


async def crear_direccion(conn, uid):
    await autenticar(conn, uid)
    await conn.execute(
        """INSERT INTO public.direcciones (perfil_id, comuna_id, calle, numero, es_principal, activo)
           VALUES ($1,$2,'Calle Postulante','10',true,true)""",
        uid,
        COMUNA_SEED,
    )


async def crear_borrador(conn, uid, nombre="Tienda Lote12"):
    await autenticar(conn, uid)
    pid = await conn.fetchval(
        """INSERT INTO public.postulaciones_vendedores
             (perfil_id, nombre_comercial_solicitado, descripcion, estado, intento, intentos_extra)
           VALUES ($1,$2,'Descripcion de prueba', 'borrador', 1, 0) RETURNING id""",
        uid,
        nombre,
    )
    return pid


DOCS = {
    "rut_solicitante": "12345678-5",
    "tipo_de_persona": "natural",
    "documento_identidad": None,  # se rellena con el uid
    "certificado_inicio_actividades_o_carnet_representante": None,
    "certificado_titularidad_bancaria": None,
    "comprobante_domicilio": None,
}


def rutas_docs(uid):
    base = f"vendedor-documentos/{uid}/"
    return {
        "documento_identidad": base + "cedula.pdf",
        "certificado_inicio_actividades_o_carnet_representante": base + "inicio.pdf",
        "certificado_titularidad_bancaria": base + "titularidad.pdf",
        "comprobante_domicilio": base + "domicilio.pdf",
    }


async def enviar(conn, uid, pid, con_docs=True):
    await autenticar(conn, uid)
    if con_docs:
        docs = rutas_docs(uid)
        await conn.execute(
            """UPDATE public.postulaciones_vendedores
               SET estado='en_revision', rut_solicitante=$2, tipo_de_persona=$3,
                   documento_identidad=$4, certificado_inicio_actividades_o_carnet_representante=$5,
                   certificado_titularidad_bancaria=$6, comprobante_domicilio=$7
               WHERE id=$1""",
            pid,
            DOCS["rut_solicitante"],
            DOCS["tipo_de_persona"],
            docs["documento_identidad"],
            docs["certificado_inicio_actividades_o_carnet_representante"],
            docs["certificado_titularidad_bancaria"],
            docs["comprobante_domicilio"],
        )
    else:
        await conn.execute(
            "UPDATE public.postulaciones_vendedores SET estado='en_revision' WHERE id=$1", pid
        )


async def test_ck_0217_0219_0221_borrador_y_envio_exige_kyb(conn):
    uid = await alta_cliente(conn, "lote12-a@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    fila = await conn.fetchrow(
        "SELECT estado, intento, nombre_comercial_solicitado FROM public.postulaciones_vendedores WHERE id=$1",
        pid,
    )
    assert fila["estado"] == "borrador" and fila["intento"] == 1
    # CK-0221/0222: enviar sin los 4 documentos + RUT -> rechazado
    with pytest.raises(asyncpg.RaiseError, match="cuatro documentos"):
        async with conn.transaction():
            await enviar(conn, uid, pid, con_docs=False)
    # con KYB completo -> en_revision
    await enviar(conn, uid, pid, con_docs=True)
    estado = await conn.fetchval(
        "SELECT estado FROM public.postulaciones_vendedores WHERE id=$1", pid
    )
    assert estado == "en_revision"
    # documento fuera de la carpeta del solicitante -> rechazado
    uid2 = await alta_cliente(conn, "lote12-b@example.test")
    await crear_direccion(conn, uid2)
    pid2 = await crear_borrador(conn, uid2, nombre="Tienda Lote12 B")
    await autenticar(conn, uid2)
    with pytest.raises(asyncpg.RaiseError, match="carpeta del solicitante"):
        async with conn.transaction():
            await conn.execute(
                """UPDATE public.postulaciones_vendedores
                   SET estado='en_revision', rut_solicitante='12345678-5', tipo_de_persona='natural',
                       documento_identidad=$2, certificado_inicio_actividades_o_carnet_representante=$3,
                       certificado_titularidad_bancaria=$4, comprobante_domicilio=$5
                   WHERE id=$1""",
                pid2,
                f"vendedor-documentos/{uid}/cedula.pdf",
                f"vendedor-documentos/{uid}/inicio.pdf",
                f"vendedor-documentos/{uid}/titularidad.pdf",
                f"vendedor-documentos/{uid}/domicilio.pdf",
            )


async def test_ck_0224_aislamiento_y_sin_venta(conn):
    uid = await alta_cliente(conn, "lote12-c@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    await enviar(conn, uid, pid)
    # otro usuario no ve la postulación (RLS)
    await autenticar(conn, OTRO)
    n = await conn.fetchval(
        "SELECT count(*) FROM public.postulaciones_vendedores WHERE id=$1", pid
    )
    assert n == 0
    # el dueño sí la ve y sigue pendiente: no puede vender
    await autenticar(conn, uid)
    n = await conn.fetchval(
        "SELECT count(*) FROM public.postulaciones_vendedores WHERE id=$1 AND estado='en_revision'",
        pid,
    )
    assert n == 1
    vende = await conn.fetchval("SELECT private.es_productor_actual($1)", uid)
    assert not vende
    # admin sí la ve
    await autenticar(conn, ADMIN)
    n = await conn.fetchval(
        "SELECT count(*) FROM public.postulaciones_vendedores WHERE id=$1", pid
    )
    assert n == 1


async def test_ck_0227_0229_0230_aprobar_exige_mall_y_promueve(conn):
    uid = await alta_cliente(conn, "lote12-d@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    await enviar(conn, uid, pid)
    await autenticar(conn, ADMIN)
    # CK-0229/0230: aprobar sin código Mall -> rechazado (no opera sin comercio)
    with pytest.raises(asyncpg.RaiseError, match="codigo de comercio Mall"):
        async with conn.transaction():
            await conn.execute(
                "SELECT public.resolver_postulacion_vendedor($1,'aprobada',null,null)", pid
            )
    # CK-0227: con código válido se aprueba, se registra actor/fecha y se crea el productor
    await conn.execute(
        "SELECT public.resolver_postulacion_vendedor($1,'aprobada','KYB aprobado por administracion',$2)",
        pid,
        CODIGO_MALL,
    )
    fila = await conn.fetchrow(
        "SELECT estado, revisado_por, codigo_comercio_mall FROM public.postulaciones_vendedores WHERE id=$1",
        pid,
    )
    assert fila["estado"] == "aprobada" and fila["revisado_por"] == ADMIN
    assert fila["codigo_comercio_mall"] == CODIGO_MALL
    prod = await conn.fetchrow(
        "SELECT codigo_comercio_mall, activo FROM public.productores WHERE perfil_id=$1", uid
    )
    assert prod["codigo_comercio_mall"] == CODIGO_MALL and prod["activo"]
    rol = await conn.fetchval("SELECT rol FROM public.perfiles WHERE id=$1", uid)
    assert rol == "vendedor"
    # CK-0240: segunda aprobación -> no hay postulación en revisión
    with pytest.raises(asyncpg.RaiseError, match="No existe una postulacion en revision"):
        async with conn.transaction():
            await conn.execute(
                "SELECT public.resolver_postulacion_vendedor($1,'aprobada','Intento duplicado de aprobacion',$2)",
                pid,
                CODIGO_MALL,
            )


async def test_api_admin_asigna_comercio_mall_desde_configuracion(conn, client, mock_jwt):
    """El contrato HTTP no acepta código Mall: sólo estado y observaciones.

    FastAPI aporta el código hijo configurado y conserva al administrador
    autenticado como actor de la revisión dentro de la RPC.
    """
    uid = await alta_cliente(conn, "lote12-api-mall@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid, nombre="Tienda API Mall")
    await enviar(conn, uid, pid)
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")

    con_codigo_cliente = await client.post(
        f"/api/admin/postulaciones/{pid}/resolver",
        json={"estado": "aprobada", "codigo_comercio_mall": "111111111111"},
        headers={"Authorization": f"Bearer {mock_jwt(ADMIN)}"},
    )
    assert con_codigo_cliente.status_code == 422

    response = await client.post(
        f"/api/admin/postulaciones/{pid}/resolver",
        json={"estado": "aprobada", "observaciones": "Antecedentes completos y validados."},
        headers={"Authorization": f"Bearer {mock_jwt(ADMIN)}"},
    )

    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["estado"] == "aprobada"
    assert payload["codigo_comercio_mall"] == "597055555536"
    fila = await conn.fetchrow(
        """SELECT revisado_por, codigo_comercio_mall
           FROM public.postulaciones_vendedores WHERE id=$1""",
        pid,
    )
    assert fila["revisado_por"] == ADMIN
    assert fila["codigo_comercio_mall"] == "597055555536"


async def test_ck_0228_0237_rechazo_sin_motivo_y_con_historial(conn):
    uid = await alta_cliente(conn, "lote12-e@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    await enviar(conn, uid, pid)
    await autenticar(conn, ADMIN)
    # El administrador puede dejar el motivo vacío: el correo informa la
    # respuesta automática correspondiente, sin impedir el reenvío posterior.
    await conn.execute(
        "SELECT public.resolver_postulacion_vendedor($1,'rechazada',null,null)", pid
    )
    # CK-0237: el rechazo queda archivado en postulaciones_revisiones (historial)
    rev = await conn.fetchrow(
        """SELECT estado, observaciones_admin, revisado_por, intento
           FROM public.postulaciones_revisiones WHERE postulacion_id=$1 ORDER BY intento""",
        pid,
    )
    assert rev["estado"] == "rechazada" and rev["observaciones_admin"] is None
    assert rev["revisado_por"] == ADMIN
    # el postulante puede reenviar (intento 2)
    await enviar(conn, uid, pid)
    fila = await conn.fetchrow(
        "SELECT estado, intento, observaciones_admin FROM public.postulaciones_vendedores WHERE id=$1",
        pid,
    )
    assert fila["estado"] == "en_revision" and fila["intento"] == 2
    assert fila["observaciones_admin"] is None


async def test_ck_0231_0232_limite_3_y_reinicio_auditado(conn):
    uid = await alta_cliente(conn, "lote12-f@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    await enviar(conn, uid, pid)  # intento 1
    await autenticar(conn, ADMIN)
    for i in range(3):  # rechazos -> intentos 2 y 3 permitidos, 4 bloqueado
        await autenticar(conn, ADMIN)
        await conn.execute(
            "SELECT public.resolver_postulacion_vendedor($1,'rechazada','Motivo de prueba suficiente',null)",
            pid,
        )
        if i < 2:
            await enviar(conn, uid, pid)  # reenvío como postulante
    # cuarto envío (intento 4) bloqueado
    with pytest.raises(asyncpg.RaiseError, match="maximo de 3"):
        async with conn.transaction():
            await enviar(conn, uid, pid)
    # CK-0232: admin autoriza 3 intentos extra con motivo auditado
    await autenticar(conn, ADMIN)
    with pytest.raises(asyncpg.RaiseError, match="motivo"):
        async with conn.transaction():
            await conn.execute(
                "SELECT public.reiniciar_intentos_postulacion($1,'corto')", pid
            )
    await conn.execute(
        "SELECT public.reiniciar_intentos_postulacion($1,'Revisión manual aprobada por dirección')",
        pid,
    )
    fila = await conn.fetchrow(
        "SELECT intentos_extra FROM public.postulaciones_vendedores WHERE id=$1", pid
    )
    assert fila["intentos_extra"] == 3
    audit = await conn.fetchrow(
        """SELECT admin_id, intentos_extra_anteriores, intentos_extra_nuevos, motivo
           FROM public.postulaciones_reinicio_intentos WHERE postulacion_id=$1""",
        pid,
    )
    assert audit["admin_id"] == ADMIN and audit["intentos_extra_nuevos"] == 3
    assert "dirección" in audit["motivo"]
    # ahora el cuarto envío sí se permite (3 + 3 extra)
    await enviar(conn, uid, pid)
    intento = await conn.fetchval(
        "SELECT intento FROM public.postulaciones_vendedores WHERE id=$1", pid
    )
    assert intento == 4


async def test_ck_0236_vendedor_no_cambia_codigo_mall(conn):
    uid = await alta_cliente(conn, "lote12-g@example.test")
    await crear_direccion(conn, uid)
    pid = await crear_borrador(conn, uid)
    await enviar(conn, uid, pid)
    await autenticar(conn, ADMIN)
    await conn.execute(
        "SELECT public.resolver_postulacion_vendedor($1,'aprobada','KYB aprobado por administracion',$2)",
        pid,
        CODIGO_MALL,
    )
    # CK-0236: el vendedor (con JWT) no puede cambiar el código por tabla directa
    await autenticar(conn, uid)
    with pytest.raises(asyncpg.RaiseError, match="Solo administracion/backend"):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.productores SET codigo_comercio_mall='111111111111' WHERE perfil_id=$1",
                uid,
            )


async def test_ck_0223_bucket_documentos_solo_dueno_y_admin(conn):
    uid = await alta_cliente(conn, "lote12-h@example.test")
    ruta = f"{uid}/cedula.pdf"  # objeto dentro del bucket vendedor-documentos
    # el dueño puede subir a su carpeta
    await autenticar(conn, uid)
    await conn.execute(
        "INSERT INTO storage.objects (bucket_id, name, owner_id) VALUES ('vendedor-documentos',$1,$2)",
        ruta,
        str(uid),
    )
    # otro usuario no puede escribir en la carpeta ajena
    await autenticar(conn, OTRO)
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.execute(
                "INSERT INTO storage.objects (bucket_id, name, owner_id) VALUES ('vendedor-documentos',$1,$2)",
                f"{uid}/otro.pdf",
                str(OTRO),
            )
    n = await conn.fetchval(
        "SELECT count(*) FROM storage.objects WHERE bucket_id='vendedor-documentos' AND name=$1", ruta
    )
    assert n == 0  # RLS: no la ve
    # admin sí la ve
    await autenticar(conn, ADMIN)
    n = await conn.fetchval(
        "SELECT count(*) FROM storage.objects WHERE bucket_id='vendedor-documentos' AND name=$1", ruta
    )
    assert n == 1


async def test_ck_0220_datos_bancarios_protegidos(conn):
    uid = await alta_cliente(conn, "lote12-i@example.test")
    # la API directa (authenticated) NO puede escribir datos bancarios: solo el backend
    await autenticar(conn, uid)
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.datos_bancarios
                     (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, numero_cuenta_hash, numero_cuenta_digitos, titular_cuenta, rut_titular)
                   VALUES ($1,'Banco Estado','cuenta_corriente',decode('0102030405','hex'),decode('0102030405060708090a0b0c0d0e0f100102030405060708090a0b0c0d0e0f10','hex'),9,'Postulante Lote12','12345678-5')""",
                uid,
            )
    # el backend (service_role) sí inserta; otro usuario no lo ve (RLS) y el dueño sí
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute(
        """INSERT INTO public.datos_bancarios
             (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, numero_cuenta_hash, numero_cuenta_digitos, titular_cuenta, rut_titular)
           VALUES ($1,'Banco Estado','cuenta_corriente',decode('0102030405','hex'),decode('0102030405060708090a0b0c0d0e0f100102030405060708090a0b0c0d0e0f10','hex'),9,'Postulante Lote12','12345678-5')""",
        uid,
    )
    # ni el dueño ni otro usuario pueden leer datos bancarios desde la API: sólo el backend
    await autenticar(conn, OTRO)
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.fetchval("SELECT count(*) FROM public.datos_bancarios WHERE perfil_id=$1", uid)
    await autenticar(conn, uid)
    with pytest.raises(asyncpg.InsufficientPrivilegeError):
        async with conn.transaction():
            await conn.fetchval("SELECT count(*) FROM public.datos_bancarios WHERE perfil_id=$1", uid)
    # el vínculo con la postulación/perfil queda en la fila (service_role)
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    fila = await conn.fetchrow(
        "SELECT perfil_id, banco, activo FROM public.datos_bancarios WHERE perfil_id=$1", uid
    )
    assert fila["perfil_id"] == uid and fila["activo"]
