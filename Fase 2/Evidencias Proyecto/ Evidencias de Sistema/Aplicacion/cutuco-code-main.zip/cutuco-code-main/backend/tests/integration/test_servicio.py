from uuid import UUID, uuid4

import pytest

from app.integrations.webpay.plus_client import WebpayPlusClient

VENDEDOR_ID = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_ID = UUID("20000000-0000-0000-0000-000000000002")


@pytest.mark.asyncio
async def test_servicio_iniciar_y_retorno_webpay(client, conn, mock_jwt, monkeypatch):
    await conn.execute(
        """UPDATE public.pagos_servicio
        SET estado='pendiente', metodo=NULL, token_ws=NULL, buy_order=NULL,
            pagado_en=NULL, referencia=NULL
        WHERE productor_id=$1""",
        PRODUCTOR_ID,
    )
    token = uuid4().hex
    creado = {}

    def create(self, buy_order, session_id, amount, return_url):
        creado.update(buy_order=buy_order, session_id=session_id, amount=amount)
        return {"token": token, "url": "https://webpay.example.test/pay"}

    def commit(self, _token):
        return {
            **creado,
            "status": "AUTHORIZED",
            "response_code": 0,
            "authorization_code": "SERV-AUTH-1",
        }

    monkeypatch.setattr(WebpayPlusClient, "create", create)
    monkeypatch.setattr(WebpayPlusClient, "commit", commit)
    headers = {"Authorization": f"Bearer {mock_jwt(VENDEDOR_ID)}"}

    response = await client.post("/api/servicio/iniciar", headers=headers)
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["monto"] == 2990
    assert data["token_ws"] == token

    retorno = await client.get(
        "/api/servicio/retorno", params={"token_ws": token}, follow_redirects=False
    )
    assert retorno.status_code == 303
    assert "pago=pagado" in retorno.headers["location"]

    row = await conn.fetchrow(
        "SELECT estado, metodo, pagado_en FROM public.pagos_servicio WHERE productor_id=$1",
        PRODUCTOR_ID,
    )
    assert row["estado"] == "pagado"
    assert row["metodo"] == "webpay"
    assert row["pagado_en"] is not None


@pytest.mark.asyncio
async def test_servicio_rechaza_iniciar_sin_productor(client, mock_jwt):
    headers = {"Authorization": f"Bearer {mock_jwt(UUID('a0000000-0000-0000-0000-000000000001'))}"}
    response = await client.post("/api/servicio/iniciar", headers=headers)
    assert response.status_code == 403


@pytest.mark.asyncio
async def test_checkout_bloquea_productor_con_servicio_vencido(
    client, conn, headers, checkout_body
):
    # The checkout_body uses PRODUCT_ID (201 = Tomates de Melipilla) from producer 002
    productor_id = UUID("20000000-0000-0000-0000-000000000002")
    await conn.execute(
        """UPDATE public.pagos_servicio
        SET emitido_en=current_date-20, vence_en=current_date-10
        WHERE productor_id=$1""",
        productor_id,
    )
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", productor_id)
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 400, response.text
    assert "servicio" in response.text.lower()
