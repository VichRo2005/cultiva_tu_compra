from decimal import Decimal
from unittest.mock import patch

from reportlab import rl_config

from app.services.pdf_service import _clp, _direccion_vendedor, generar_pdf_pedido


def test_clp_sin_float_y_separador_chileno():
    assert _clp(Decimal("1234567")) == "$1.234.567 CLP"
    assert _clp(Decimal("2990")) == "$2.990 CLP"
    assert _clp(Decimal("1000.5")) == "$1.001 CLP"


def test_direccion_vendedor_compone_via_depto_comuna_y_region():
    productor = {
        "vendedor_calle": "Camino Rural",
        "vendedor_numero": "10",
        "vendedor_depto": "Portón verde",
        "vendedor_comuna": "Paine",
        "region_nombre": "Región Metropolitana de Santiago",
    }
    assert _direccion_vendedor(productor) == (
        "Camino Rural 10, Depto/Oficina Portón verde, Paine, Región Metropolitana de Santiago"
    )
    assert _direccion_vendedor({}) == "—"
    assert _direccion_vendedor(None) == "—"
    assert _direccion_vendedor({"direccion": "Dirección ya compuesta"}) == "Dirección ya compuesta"


def comprobante_prueba():
    return generar_pdf_pedido(
        pedido={"codigo_pedido": "QA-001", "estado": "pagado"},
        cliente={
            "nombre": 'María <img src="https://example.invalid/no-leer"/>',
            "apellido": "Prueba & QA",
            "email": "qa@example.invalid",
        },
        productor={
            "nombre_comercial": "Agrícola de prueba & asociados",
            "rut_oficial": "12345678-5",
            "productor_email": "vendedor@example.invalid",
            "vendedor_calle": "Camino Rural",
            "vendedor_numero": "10",
            "vendedor_comuna": "Paine",
            "region_nombre": "Región Metropolitana de Santiago",
        },
        direccion={"direccion_entrega": "Dirección ficticia 123, Buin"},
        items=[
            {
                "producto_nombre": "Tomates <b>de prueba</b> & hortalizas",
                "codigo_producto": "QA-P1",
                "cantidad": Decimal("1.5"),
                "precio_unitario": 2000,
                "subtotal": 3000,
            }
        ],
        total=Decimal("6500"),
        tarifa_delivery=Decimal("3500"),
        tipo_documento="factura",
        datos_tributarios={
            "razon_social": "Empresa ficticia & pruebas",
            "giro": "Prueba <sin emisión tributaria>",
        },
    )


def _solo_recursos_locales(nombre, *args, **kwargs):
    """Bloquea lecturas remotas (datos del pedido nunca son URL) y permite el logo local."""
    if str(nombre).startswith(("http://", "https://", "//")):
        raise AssertionError("No leer URL")
    return open(nombre, "rb")


def test_datos_del_usuario_no_se_interpretan_como_imagen_remota():
    with patch("reportlab.lib.utils.open_for_read", side_effect=_solo_recursos_locales):
        pdf = comprobante_prueba()
    assert pdf.startswith(b"%PDF-")
    assert len(pdf) > 1000


def test_comprobante_incluye_isologo_de_cutuco():
    # El isologo local se incrusta como XObject de imagen en el PDF.
    with patch("reportlab.lib.utils.open_for_read", side_effect=_solo_recursos_locales):
        pdf = comprobante_prueba()
    assert b"/Subtype /Image" in pdf or b"/Subtype/Image" in pdf


def test_comprobante_tiene_cabecera_de_respaldo_y_pie_paginado():
    """La presentación mantiene contexto documental incluso si el detalle ocupa más páginas."""
    rl_config.pageCompression = 0
    try:
        with patch("reportlab.lib.utils.open_for_read", side_effect=_solo_recursos_locales):
            pdf = comprobante_prueba()
    finally:
        rl_config.pageCompression = 1

    texto = pdf.decode("latin-1")
    assert "COMPROBANTE" in texto
    assert "RESUMEN DE COMPRA" in texto
    assert "CuTuCo - Respaldo de compra" in texto
    assert "Pagina 1" in texto


def test_pdf_adjunto_correo_muestra_vendedor_desde_contexto():
    """La copia PDF que se adjunta al correo usa la fila de get_email_context
    (claves cliente_nombre/comprador_email y vendedor_*): el vendedor no debe
    aparecer vacío en el comprobante enviado por email."""
    rl_config.pageCompression = 0
    try:
        with patch("reportlab.lib.utils.open_for_read", side_effect=_solo_recursos_locales):
            pdf = generar_pdf_pedido(
                pedido={
                    "codigo_pedido": "CTC-1",
                    "estado": "pagado",
                    "direccion_entrega": "Huechuraba 123",
                },
                cliente={
                    "cliente_nombre": "Camila",
                    "cliente_apellido": "Rojas",
                    "comprador_email": "camila@example.cl",
                },
                productor={
                    "nombre_comercial": "Fondo de comida",
                    "rut_oficial": "76543210-9",
                    "productor_email": "fondo@example.cl",
                    "vendedor_calle": "Camino Rural",
                    "vendedor_numero": "10",
                    "vendedor_comuna": "Paine",
                    "region_nombre": "Región Metropolitana de Santiago",
                },
                direccion={"direccion_entrega": "Huechuraba 123"},
                items=[
                    {
                        "producto_nombre": "Cebolla",
                        "codigo_producto": "PRD-00002",
                        "cantidad": Decimal("4"),
                        "precio_unitario": 1000,
                        "subtotal": 4000,
                    }
                ],
                total=Decimal("7500"),
                tarifa_delivery=Decimal("3500"),
                tipo_documento="boleta",
            )
    finally:
        rl_config.pageCompression = 1
    texto = pdf.decode("latin-1")
    for needle in [
        "Datos del vendedor",
        "Fondo de comida",
        "76543210-9",
        "fondo@example.cl",
        "Camino Rural 10",
        "Paine",
        "Datos del comprador",
        "Camila",
        "camila@example.cl",
        "Huechuraba 123",
        "Cebolla",
        "PRD-00002",
    ]:
        assert needle in texto, needle
    assert b"/Subtype /Image" in pdf or b"/Subtype/Image" in pdf
