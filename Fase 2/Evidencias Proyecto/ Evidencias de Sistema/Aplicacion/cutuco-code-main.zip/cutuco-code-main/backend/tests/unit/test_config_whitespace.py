"""Secret Manager inyecta el valor byte a byte: un secreto creado con `echo`
queda con `\\r\\n` al final y rompía el arranque en Cloud Run (pydantic
`^[0-9]{12}$` rechazaba '597055555535\\r\\n' en la revisión 00002-6mm).
Settings recorta espacios de todos los strings antes de validar."""

from app.core.config import get_settings


def test_recorta_crlf_de_variables_de_entorno(monkeypatch):
    monkeypatch.setenv("TRANSBANK_COMMERCE_CODE", "597055555535\r\n")
    monkeypatch.setenv("TRANSBANK_FEE_COMMERCE_CODE", " 597055555537\r\n")
    get_settings.cache_clear()
    try:
        settings = get_settings()
        assert settings.TRANSBANK_COMMERCE_CODE == "597055555535"
        assert settings.TRANSBANK_FEE_COMMERCE_CODE == "597055555537"
    finally:
        get_settings.cache_clear()
