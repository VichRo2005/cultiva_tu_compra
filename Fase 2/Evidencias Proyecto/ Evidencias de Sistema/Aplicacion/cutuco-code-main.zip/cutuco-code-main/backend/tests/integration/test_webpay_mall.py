import json
from uuid import UUID

import pytest


@pytest.fixture
async def four_stores(conn, checkout_body):
    # The seed has four active producers; align their coverage only inside the rolled-back test.
    await conn.execute(
        """UPDATE public.direcciones SET comuna_id=
        (SELECT comuna_id FROM public.direcciones WHERE id=$1)
        WHERE perfil_id IN (SELECT perfil_id FROM public.productores WHERE activo)""",
        UUID(checkout_body["direccion_id"]),
    )
    seeded_stores = await conn.fetch(
        "SELECT codigo_comercio_mall FROM public.productores WHERE id::text LIKE '20000000-%'"
    )
    assert len(seeded_stores) == 5, "Faltan productores del seed"
    assert all(
        store["codigo_comercio_mall"] == "597055555536" for store in seeded_stores
    ), "Supabase local debe tener el seed actualizado con un solo comercio hijo para productores"
    products = await conn.fetch(
        """SELECT DISTINCT ON (p.productor_id) p.id FROM public.productos p
        JOIN public.productores pr ON pr.id=p.productor_id
        WHERE pr.activo AND p.activo AND p.eliminado_en IS NULL AND p.stock>2
        ORDER BY p.productor_id,p.id"""
    )
    assert len(products) >= 4
    return checkout_body | {
        "items": [{"producto_id": str(p["id"]), "cantidad": 2} for p in products[:4]]
    }


async def test_cuatro_tiendas_codigo_repetido_separadas(
    client, headers, four_stores, conn, mock_transbank, mock_email
):
    before = await conn.fetchval("SELECT count(*) FROM public.pedidos")
    started = await client.post("/api/webpay/iniciar", json=four_stores, headers=headers)
    assert started.status_code == 200, started.text
    checkout = started.json()
    assert await conn.fetchval("SELECT count(*) FROM public.pedidos") == before
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
        )
        == 0
    )
    sent = mock_transbank["create"].call_args.args[2]
    assert len(sent) == 8  # Four sellers and their four commissions, all orders unique.
    assert len({d["buy_order"] for d in sent}) == 8
    assert sum(d["amount"] for d in sent) == checkout["monto"]
    assert all(d["commerce_code"] == "597055555536" for d in sent[::2])
    assert all(d["commerce_code"] == "597055555537" for d in sent[1::2])
    result = await client.post("/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]})
    assert result.status_code == 200, result.text
    assert len(result.json()["pedidos"]) == 4
    assert all(p["estado_pedido"] == "pagado" for p in result.json()["pedidos"])
    receipts = await conn.fetch(
        "SELECT * FROM public.pagos WHERE token_ws=$1", checkout["token_ws"]
    )
    assert len(receipts) == 4
    assert sum(p["monto"] + p["monto_fee_descontado"] for p in receipts) == checkout["monto"]
    for receipt in receipts:
        assert "details" not in json.loads(receipt["respuesta_webpay"])
        assert (
            await conn.fetchval(
                "SELECT count(*) FROM public.detalles_pedido WHERE pedido_id=$1",
                receipt["pedido_id"],
            )
            == 1
        )
    assert mock_email.await_count == 8
    repeated = await client.post("/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]})
    assert repeated.json()["ya_confirmado"]
    assert mock_email.await_count == 8
    assert mock_transbank["commit"].call_count == 1


async def test_mall_parcial_solo_crea_tiendas_autorizadas(
    client, headers, four_stores, conn, mock_transbank, mock_email
):
    started = await client.post("/api/webpay/iniciar", json=four_stores, headers=headers)
    assert started.status_code == 200, started.text
    checkout = started.json()
    for detail in mock_transbank["transactions"][checkout["token_ws"]]["details"][:2]:
        detail.update(status="FAILED", response_code=-1)
    result = await client.post("/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]})
    assert result.status_code == 200, result.text
    assert result.json()["estado"] == "parcial" and len(result.json()["pedidos"]) == 3
    assert not result.json()["requiere_conciliacion"]
    assert mock_email.await_count == 6
