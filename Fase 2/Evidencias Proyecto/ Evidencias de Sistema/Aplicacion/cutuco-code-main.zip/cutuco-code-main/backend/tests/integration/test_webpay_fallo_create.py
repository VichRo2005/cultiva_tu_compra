"""FL-07 — fallo de Webpay Mall al CREAR la transacción.

Si `WebpayClient.create` falla (red/pasarela caída) después de comprometer la
reserva de stock, la retención debe liberarse de inmediato: no tiene sentido
mantener unidades retenidas de un checkout que jamás tendrá token_ws (el stock
quedaría bloqueado hasta la expiración del plazo por nada).
"""

from uuid import UUID

from app.core.exceptions import WebpayError

PRODUCT_ID = "30000000-0000-0000-0000-000000000201"


async def test_create_falla_libera_reserva_de_stock(
    client, headers, checkout_body, conn, mock_transbank
):
    producto = UUID(checkout_body["items"][0]["producto_id"])
    reservado_antes = await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", producto
    )
    reservas_antes = await conn.fetchval("SELECT count(*) FROM private.checkout_reservas")

    create_original = mock_transbank["create"].side_effect
    mock_transbank["create"].side_effect = WebpayError("Webpay create failed")
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)

    assert response.status_code == 502, response.text
    assert (
        await conn.fetchval("SELECT stock_reservado FROM public.productos WHERE id=$1", producto)
        == reservado_antes
    )
    assert (
        await conn.fetchval("SELECT count(*) FROM private.checkout_reservas") == reservas_antes
    )
    # Y el stock sigue disponible para otro comprador inmediatamente.
    mock_transbank["create"].side_effect = create_original  # la pasarela se recupera
    segundo = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert segundo.status_code == 200, segundo.text
