from app.integrations.sre import client as sre_client

ADMIN_ID = "a0000000-0000-0000-0000-000000000001"
CLIENTE_ID = "a0000000-0000-0000-0000-000000000002"


async def test_contrato_ok(client, headers, monkeypatch):
    async def ok(rut):
        return {"razon_social": "Frutas del Sur SpA", "giro": "Venta de frutas"}

    monkeypatch.setattr(sre_client, "get_empresa", ok)
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 200
    assert response.json() == {
        "existe": True,
        "rut": "76123456-0",
        "razon_social": "Frutas del Sur SpA",
        "giro": "Venta de frutas",
    }


async def test_503_sin_filtrar_detalles(client, headers, monkeypatch):
    async def fail(rut):
        raise sre_client.SreError("detalle interno")

    monkeypatch.setattr(sre_client, "get_empresa", fail)
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 503
    assert "No fue posible consultar" in response.json()["detail"]
    assert "detalle interno" not in response.text


async def test_503_si_falta_token_publico(client, headers, monkeypatch):
    async def fail(rut):
        raise sre_client.SreConfigError("SRE_TOKEN_PUBLICO no está configurado")

    monkeypatch.setattr(sre_client, "get_empresa", fail)
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 503
    assert "no está configurado" in response.json()["detail"]
    assert "token_publico" not in response.text


async def test_normaliza_rut_con_y_sin_puntos(client, headers, monkeypatch):
    vistos = []

    async def ok(rut):
        vistos.append(rut)
        return {"razon_social": "Frutas del Sur SpA", "giro": "Venta de frutas"}

    monkeypatch.setattr(sre_client, "get_empresa", ok)
    for rut in ("76.123.456-0", "76123456-0"):
        response = await client.get(f"/api/tributario/empresa/{rut}", headers=headers)
        assert response.status_code == 200, response.text
        assert response.json()["rut"] == "76123456-0"
    assert vistos == ["76123456-0", "76123456-0"]


async def test_422_rut_invalido(client, headers):
    response = await client.get("/api/tributario/empresa/123", headers=headers)
    assert response.status_code == 422


async def test_404_no_encontrada(client, headers, monkeypatch):
    async def none(rut):
        return None

    monkeypatch.setattr(sre_client, "get_empresa", none)
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 404


async def test_requiere_jwt(client):
    response = await client.get("/api/tributario/empresa/76123456-0")
    assert response.status_code == 401
