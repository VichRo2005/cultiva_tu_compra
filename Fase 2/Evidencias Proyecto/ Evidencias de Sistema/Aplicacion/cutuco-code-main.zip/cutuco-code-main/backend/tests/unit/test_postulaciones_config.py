"""La asignación automática usa sólo un comercio hijo configurado."""

import pytest
from fastapi import HTTPException

from app.core.config import get_settings
from app.services.postulaciones_service import codigo_comercio_vendedor_configurado


def _reload_settings(monkeypatch, **values):
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    get_settings.cache_clear()
    return get_settings()


def test_integracion_usa_comercio_hijo_sandbox_si_no_hay_override(monkeypatch):
    _reload_settings(
        monkeypatch,
        TRANSBANK_ENV="integration",
        TRANSBANK_MALL_SELLER_COMMERCE_CODE="",
    )
    assert codigo_comercio_vendedor_configurado() == "597055555536"


def test_produccion_exige_comercio_hijo_configurado(monkeypatch):
    _reload_settings(
        monkeypatch,
        TRANSBANK_ENV="production",
        TRANSBANK_MALL_SELLER_COMMERCE_CODE="",
    )
    with pytest.raises(HTTPException) as exc:
        codigo_comercio_vendedor_configurado()
    assert exc.value.status_code == 503
    assert "TRANSBANK_MALL_SELLER_COMMERCE_CODE" in exc.value.detail


def test_produccion_rechaza_comercio_padre_como_destino_de_vendedor(monkeypatch):
    _reload_settings(
        monkeypatch,
        TRANSBANK_ENV="production",
        TRANSBANK_COMMERCE_CODE="123456789012",
        TRANSBANK_MALL_SELLER_COMMERCE_CODE="123456789012",
    )
    with pytest.raises(HTTPException) as exc:
        codigo_comercio_vendedor_configurado()
    assert exc.value.status_code == 503
    assert "comercio hijo" in exc.value.detail
