"""Retorno del navegador desde Webpay Plus (`POST /api/webpay/retorno`).

`TRANSBANK_RETURN_URL` apunta a `FRONTEND_URL/cliente/pedidos`, una ruta de la
SPA, así que el POST del formulario de Transbank se desvía a este endpoint: aquí
se confirma el pago y se devuelve al navegador a la misma ruta por GET (303).

Se cubren los cuatro escenarios que documenta Transbank:

1. Sólo `token_ws`                      -> commit.
2. `TBK_ID_SESION` + `TBK_ORDEN_COMPRA` -> sesión expirada, sin commit.
3. Sólo `TBK_TOKEN`                     -> pago anulado, sin commit.
4. `token_ws` **y** `TBK_TOKEN`          -> transacción inválida, sin commit.
"""

from uuid import UUID

RETORNO = "/api/webpay/retorno"
DESTINO = "http://localhost:3000/cliente/pedidos"


async def test_pago_normal_confirma_y_vuelve_al_historial(
    client, checkout, conn, mock_transbank, mock_email
):
    token = checkout["token_ws"]
    # Sin cabecera Authorization: lo invoca el navegador que viene de Transbank.
    response = await client.post(RETORNO, data={"token_ws": token})

    assert response.status_code == 303
    assert response.headers["location"] == f"{DESTINO}?token_ws={token}"
    pedido_id = await conn.fetchval(
        "SELECT id FROM public.pedidos WHERE checkout_id=$1", UUID(checkout["checkout_id"])
    )
    assert (
        await conn.fetchval(
            "SELECT codigo_respuesta FROM public.pagos WHERE pedido_id=$1", pedido_id
        )
        == "0"
    )
    assert (
        await conn.fetchval("SELECT estado FROM public.pedidos WHERE id=$1", pedido_id) == "pagado"
    )
    assert (
        await conn.fetchval("SELECT count(*) FROM public.envios WHERE pedido_id=$1", pedido_id) == 1
    )
    assert mock_email.await_count == 2


async def test_token_ws_y_tbk_token_no_confirman(client, checkout, conn, mock_transbank):
    token = checkout["token_ws"]
    response = await client.post(RETORNO, data={"token_ws": token, "TBK_TOKEN": "anulado"})

    assert response.status_code == 303
    assert "token_ws=" in response.headers["location"]
    assert "TBK_TOKEN=anulado" in response.headers["location"]
    mock_transbank["commit"].assert_not_called()
    assert (
        await conn.fetchval(
            "SELECT resultado FROM private.webpay_checkouts WHERE id=$1",
            UUID(checkout["checkout_id"]),
        )
        is None
    )


async def test_pago_anulado_por_el_usuario(client, checkout, mock_transbank):
    response = await client.post(
        RETORNO, data={"TBK_TOKEN": "anulado", "TBK_ORDEN_COMPRA": "ORD-1"}
    )

    assert response.status_code == 303
    assert response.headers["location"] == f"{DESTINO}?TBK_TOKEN=anulado&TBK_ORDEN_COMPRA=ORD-1"
    mock_transbank["commit"].assert_not_called()


async def test_sesion_de_pago_expirada(client, checkout, mock_transbank):
    response = await client.post(
        RETORNO, data={"TBK_ID_SESION": "SES-1", "TBK_ORDEN_COMPRA": "ORD-2"}
    )

    assert response.status_code == 303
    assert response.headers["location"] == f"{DESTINO}?TBK_ORDEN_COMPRA=ORD-2&TBK_ID_SESION=SES-1"
    mock_transbank["commit"].assert_not_called()


async def test_token_desconocido_redirige_en_lugar_de_devolver_json(
    client, mock_transbank, mock_email
):
    response = await client.post(RETORNO, data={"token_ws": "token_inexistente"})

    # El 404 del commit se registra y el navegador vuelve igual a la SPA, que
    # muestra el error en lugar de un JSON.
    assert response.status_code == 303
    assert response.headers["location"] == f"{DESTINO}?token_ws=token_inexistente"
    mock_transbank["commit"].assert_not_called()
    mock_email.assert_not_awaited()


async def test_retorno_sin_parametros(client, mock_transbank):
    response = await client.post(RETORNO, data={})

    assert response.status_code == 303
    assert response.headers["location"] == DESTINO
    mock_transbank["commit"].assert_not_called()


async def test_retorno_get_confirma(client, checkout, mock_transbank):
    response = await client.get(RETORNO, params={"token_ws": checkout["token_ws"]})
    assert response.status_code == 303
    mock_transbank["commit"].assert_called_once()
