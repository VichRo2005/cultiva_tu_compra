"""CK-0014 / CK-0009 / CK-0011 (bloqueo de cuenta inactiva).

El rol efectivo sale SIEMPRE del perfil en base de datos (`perfiles.rol`),
nunca de los claims del JWT: un token firmado con `role: "admin"` forjado no
eleva privilegios. Sin token Bearer, con token inválido/expirado (cubierto en
test_security_es256) o con perfil inactivo/baneado, la respuesta es 401.
"""

from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.routers import deps


def _request(token: str | None) -> SimpleNamespace:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    return SimpleNamespace(headers=headers)


class _ConnPerfil:
    def __init__(self, fila):
        self._fila = fila

    async def fetchrow(self, *_args, **_kwargs):
        return self._fila


async def test_rol_falsificado_en_el_jwt_no_eleva_privilegios(mock_jwt):
    """CK-0014: claim `role: admin` en el JWT firmado pero perfil cliente en BD."""
    token = mock_jwt(role="admin", app_metadata={"rol": "admin"})
    conn = _ConnPerfil({"rol": "cliente", "activo": True})
    user = await deps.get_current_user(_request(token), conn)
    assert user["role"] == "cliente"
    assert user["rol"] == "cliente"


async def test_require_role_rechaza_segun_rol_de_bd(mock_jwt):
    """CK-0014: aunque el JWT diga admin, require_role usa el rol del perfil."""
    token = mock_jwt(role="admin")
    conn = _ConnPerfil({"rol": "cliente", "activo": True})
    user = await deps.get_current_user(_request(token), conn)
    with pytest.raises(HTTPException) as exc:
        await deps.require_role("admin")(user=user)
    assert exc.value.status_code == 403


async def test_sin_token_bearer_es_401():
    """CK-0009: recurso privado sin credenciales -> 401, sin datos."""
    with pytest.raises(HTTPException) as exc:
        await deps.get_current_user(_request(None), _ConnPerfil(None))
    assert exc.value.status_code == 401


async def test_perfil_inactivo_o_baneado_es_401(mock_jwt):
    """CK-0011: cuenta desactivada/baneada (activo=false) no obtiene sesión."""
    conn = _ConnPerfil({"rol": "vendedor", "activo": False})
    with pytest.raises(HTTPException) as exc:
        await deps.get_current_user(_request(mock_jwt()), conn)
    assert exc.value.status_code == 401
