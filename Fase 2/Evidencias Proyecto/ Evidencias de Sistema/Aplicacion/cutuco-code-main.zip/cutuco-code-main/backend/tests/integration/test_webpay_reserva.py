"""Reserva temporal de stock del checkout (migracion 20261021000000).

Modelo: disponible = stock - stock_reservado. La retencion se crea al iniciar
el checkout, se libera al confirmarlo (pagado/parcial/rechazado) o al vencer
el plazo RESERVA_STOCK_MINUTOS via private.liberar_reservas_expiradas().
"""

import asyncio
from decimal import Decimal
from uuid import UUID, uuid4

from httpx import ASGITransport, AsyncClient

from app.main import create_app

CLIENT_ID = "a0000000-0000-0000-0000-000000000002"
PRODUCT_ID = "30000000-0000-0000-0000-000000000201"


async def _iniciar(client, headers, body):
    return await client.post("/api/webpay/iniciar", json=body, headers=headers)


async def test_reserva_bloquea_segundo_intento_mayor(
    client, headers, checkout_body, mock_transbank
):
    """Un checkout activo reduce la disponibilidad para pedidos posteriores."""
    primera = await _iniciar(client, headers, checkout_body)
    assert primera.status_code == 200, primera.text
    body_mayor = {**checkout_body, "items": [{"producto_id": PRODUCT_ID, "cantidad": 100000}]}
    segunda = await _iniciar(client, headers, body_mayor)
    assert segunda.status_code == 400
    assert "Stock insuficiente" in segunda.text


async def test_reserva_se_registra_y_libera_al_confirmar(
    client, headers, checkout_body, mock_transbank, mock_email, conn
):
    stock_antes = await conn.fetchval(
        "SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )
    reservado_antes = await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )
    primera = await _iniciar(client, headers, checkout_body)
    assert primera.status_code == 200, primera.text
    checkout_id = UUID(primera.json()["checkout_id"])

    fila = await conn.fetchrow(
        "SELECT r.cantidad, c.reservas_expiran_en, c.reservas_liberadas_en "
        "FROM private.checkout_reservas r JOIN private.webpay_checkouts c ON c.id=r.checkout_id "
        "WHERE r.checkout_id=$1",
        checkout_id,
    )
    assert fila is not None and fila["cantidad"] == Decimal("2")
    assert fila["reservas_expiran_en"] is not None
    assert fila["reservas_liberadas_en"] is None
    reservado = await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )
    assert reservado == reservado_antes + Decimal("2")

    confirmada = await client.post(
        "/api/webpay/confirmar", json={"token_ws": primera.json()["token_ws"]}
    )
    assert confirmada.status_code == 200, confirmada.text
    assert confirmada.json()["estado"] == "autorizado"

    # La venta desconto el stock real y libero la retencion (idempotente).
    assert await conn.fetchval(
        "SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    ) == stock_antes - Decimal("2")
    assert (
        await conn.fetchval(
            "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
        )
        == reservado_antes
    )
    liberada = await conn.fetchval(
        "SELECT reservas_liberadas_en FROM private.webpay_checkouts WHERE id=$1", checkout_id
    )
    assert liberada is not None
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM private.checkout_reservas WHERE checkout_id=$1", checkout_id
        )
        == 0
    )
    repetida = await client.post(
        "/api/webpay/confirmar", json={"token_ws": primera.json()["token_ws"]}
    )
    assert repetida.status_code == 200 and repetida.json()["ya_confirmado"]
    assert mock_transbank["commit"].call_count == 1
    assert await conn.fetchval(
        "SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    ) == stock_antes - Decimal("2")
    assert await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    ) == reservado_antes


async def test_reserva_se_libera_al_rechazar_pago(
    client, headers, checkout_body, mock_transbank, mock_email, conn
):
    primera = await _iniciar(client, headers, checkout_body)
    assert primera.status_code == 200, primera.text
    token = primera.json()["token_ws"]
    checkout_id = UUID(primera.json()["checkout_id"])
    stock_antes = await conn.fetchval(
        "SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )

    # Rechazo definitivo: todos los details FAILED.
    transaccion = mock_transbank["transactions"][token]
    transaccion["details"] = [
        {**d, "status": "FAILED", "response_code": -1, "authorization_code": ""}
        for d in transaccion["details"]
    ]
    respuesta = await client.post("/api/webpay/confirmar", json={"token_ws": token})
    assert respuesta.status_code == 200, respuesta.text
    assert respuesta.json()["estado"] == "rechazado"

    assert (
        await conn.fetchval("SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID))
        == stock_antes
    )
    assert await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    ) == Decimal("0")

    assert (
        await conn.fetchval("SELECT count(*) FROM public.pedidos WHERE checkout_id=$1", checkout_id)
        == 0
    )
    assert await conn.fetchval(
        "SELECT reservas_liberadas_en IS NOT NULL FROM private.webpay_checkouts WHERE id=$1",
        checkout_id,
    )


async def test_reserva_expira_y_se_libera_en_siguiente_iniciar(
    client, headers, checkout_body, mock_transbank, conn
):
    primera = await _iniciar(client, headers, checkout_body)
    assert primera.status_code == 200, primera.text
    checkout_id = UUID(primera.json()["checkout_id"])

    # Fuerza el vencimiento del plazo de retencion.
    await conn.execute(
        "UPDATE private.webpay_checkouts SET reservas_expiran_en = now() - interval '1 minute' "
        "WHERE id=$1",
        checkout_id,
    )
    liberados = await conn.fetchval("SELECT private.liberar_reservas_expiradas()")
    assert liberados >= 1
    assert await conn.fetchval(
        "SELECT stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    ) == Decimal("0")

    assert await conn.fetchval("SELECT private.liberar_reservas_expiradas()") == 0
    assert await conn.fetchval(
        "SELECT reservas_liberadas_en IS NOT NULL FROM private.webpay_checkouts WHERE id=$1",
        checkout_id,
    )
    # Un nuevo checkout recupera la disponibilidad completa.
    create_antes = mock_transbank["create"].call_count
    segunda = await _iniciar(client, headers, checkout_body)
    assert segunda.status_code == 200, segunda.text
    assert mock_transbank["create"].call_count == create_antes + 1


async def test_reserva_condicional_falla_si_otro_checkout_tomo_el_stock(
    conn, headers, checkout_body, mock_transbank
):
    # Reserva directa de todo el stock disponible con otro checkout.
    otro_id = uuid4()
    await conn.execute(
        """INSERT INTO private.webpay_checkouts (id, cliente_id, buy_order, session_id, snapshot)
        VALUES ($1,$2,$3,$4,'{}'::jsonb)""",
        otro_id,
        UUID(CLIENT_ID),
        "M" + uuid4().hex[:25],
        uuid4().hex,
    )
    stock = await conn.fetchval("SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID))
    from app.repositories import checkouts_repo

    assert await checkouts_repo.reservar(conn, otro_id, UUID(PRODUCT_ID), stock)
    # Ya no queda disponibilidad para un checkout nuevo.
    assert not await checkouts_repo.reservar(conn, uuid4(), UUID(PRODUCT_ID), Decimal("1"))


async def test_ultima_unidad_dos_compradores_concurrentes(
    db_pool, headers, mock_jwt, mock_transbank, mock_email
):
    """Dos compradores simultaneos sobre la ultima unidad: exactamente uno gana."""
    checkout_ids = []
    stock_original = None
    try:
        async with db_pool.acquire() as conn:
            stock_original = await conn.fetchval(
                "SELECT stock FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
            )
            await conn.execute(
                "UPDATE public.productos SET stock=1, stock_reservado=0 WHERE id=$1",
                UUID(PRODUCT_ID),
            )
            address = await conn.fetchval(
                "SELECT id FROM public.direcciones "
                "WHERE perfil_id=$1 AND activo ORDER BY es_principal DESC LIMIT 1",
                UUID(CLIENT_ID),
            )
        body = {"direccion_id": str(address), "items": [{"producto_id": PRODUCT_ID, "cantidad": 1}]}
        # Segunda identidad real del seed QA, con dirección propia en la misma región.
        segundo_cliente = UUID("a0000000-0000-0000-0000-000000000102")
        async with db_pool.acquire() as conn:
            segunda_direccion = await conn.fetchval(
                "SELECT id FROM public.direcciones WHERE perfil_id=$1 AND activo "
                "ORDER BY es_principal DESC LIMIT 1", segundo_cliente
            )
        segundo_body = {**body, "direccion_id": str(segunda_direccion)}
        segundo_headers = {"Authorization": f"Bearer {mock_jwt(segundo_cliente)}"}
        app = create_app()
        async with (
            AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ca,
            AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as cb,
        ):
            resultados = await asyncio.gather(
                ca.post("/api/webpay/iniciar", json=body, headers=headers),
                cb.post("/api/webpay/iniciar", json=segundo_body, headers=segundo_headers),
            )
        estados = [r.status_code for r in resultados]
        assert estados.count(200) == 1, [r.text for r in resultados]
        assert estados.count(400) + estados.count(409) == 1, [r.text for r in resultados]
        exitosa = next(r for r in resultados if r.status_code == 200)
        checkout_ids.append(UUID(exitosa.json()["checkout_id"]))
        async with db_pool.acquire() as conn:
            fila = await conn.fetchrow(
                "SELECT stock, stock_reservado FROM public.productos WHERE id=$1",
                UUID(PRODUCT_ID),
            )
            assert fila["stock"] == fila["stock_reservado"] == 1
        assert mock_transbank["create"].call_count == 1
    finally:
        async with db_pool.acquire() as conn, conn.transaction():
            for checkout_id in checkout_ids:
                # Libera retenciones antes de borrar para restaurar stock_reservado.
                await conn.execute("SELECT private.liberar_reservas_checkout($1)", checkout_id)
                await conn.execute("SET LOCAL session_replication_role = replica")
                await conn.execute(
                    "DELETE FROM public.pagos WHERE pedido_id IN "
                    "(SELECT id FROM public.pedidos WHERE checkout_id=$1)",
                    checkout_id,
                )
                await conn.execute(
                    "DELETE FROM public.envios WHERE pedido_id IN "
                    "(SELECT id FROM public.pedidos WHERE checkout_id=$1)",
                    checkout_id,
                )
                await conn.execute("DELETE FROM public.pedidos WHERE checkout_id=$1", checkout_id)
                await conn.execute(
                    "DELETE FROM private.webpay_ordenes WHERE checkout_id=$1", checkout_id
                )
                await conn.execute("DELETE FROM private.webpay_checkouts WHERE id=$1", checkout_id)
            if stock_original is not None:
                await conn.execute(
                    "UPDATE public.productos SET stock=$2 WHERE id=$1",
                    UUID(PRODUCT_ID),
                    stock_original,
                )


async def test_pago_tardio_no_consume_reserva_ajena(
    client, headers, checkout_body, conn, mock_transbank, mock_email
):
    """CK-0127: guardar autorización tardía sin vender la reserva de otro checkout."""
    await conn.execute("UPDATE public.productos SET stock=2 WHERE id=$1", UUID(PRODUCT_ID))
    primero = await _iniciar(client, headers, checkout_body)
    assert primero.status_code == 200, primero.text
    anterior = primero.json()
    await conn.execute(
        "UPDATE private.webpay_checkouts SET reservas_expiran_en=now()-interval '1 second' "
        "WHERE id=$1",
        UUID(anterior["checkout_id"]),
    )
    segundo = await _iniciar(client, headers, checkout_body)
    assert segundo.status_code == 200, segundo.text
    vigente = segundo.json()
    tardia = await client.post("/api/webpay/confirmar", json={"token_ws": anterior["token_ws"]})
    assert tardia.status_code == 502, tardia.text
    producto = await conn.fetchrow(
        "SELECT stock,stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )
    assert producto["stock"] == producto["stock_reservado"] == 2
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.pedidos WHERE checkout_id=$1",
            UUID(anterior["checkout_id"]),
        )
        == 0
    )
    recibo = await conn.fetchrow(
        "SELECT respuesta,resultado FROM private.webpay_checkouts WHERE id=$1",
        UUID(anterior["checkout_id"]),
    )
    assert recibo["respuesta"] is not None and recibo["resultado"] is None
    mock_email.assert_not_awaited()
    confirmada = await client.post("/api/webpay/confirmar", json={"token_ws": vigente["token_ws"]})
    assert confirmada.status_code == 200, confirmada.text
    repetida = await client.post("/api/webpay/confirmar", json={"token_ws": anterior["token_ws"]})
    assert repetida.status_code == 502, repetida.text
    assert mock_transbank["commit"].call_count == 2
    producto = await conn.fetchrow(
        "SELECT stock,stock_reservado FROM public.productos WHERE id=$1", UUID(PRODUCT_ID)
    )
    assert producto["stock"] == producto["stock_reservado"] == 0


async def test_checkout_multitienda_rechazo_libera_todas_reservas_una_vez(
    client, headers, checkout_body, conn, mock_transbank, mock_email
):
    # Use two different products from different producers in the same region (RM)
    # PRODUCT_ID = 30000000-0000-0000-0000-000000000201 (producer 002, RM)
    # Product 501 = 30000000-0000-0000-0000-000000000501 (producer 005, RM)
    segundo = "30000000-0000-0000-0000-000000000501"
    productos = [UUID(PRODUCT_ID), UUID(segundo)]
    antes = await conn.fetch(
        "SELECT id,stock,stock_reservado FROM public.productos WHERE id=ANY($1::uuid[]) "
        "ORDER BY id", productos,
    )
    respuesta = await _iniciar(client, headers, {
        **checkout_body,
        "items": [{"producto_id": str(p), "cantidad": 2} for p in productos],
    })
    assert respuesta.status_code == 200, respuesta.text
    checkout = respuesta.json()
    identificador = UUID(checkout["checkout_id"])
    assert await conn.fetchval(
        "SELECT count(*) FROM private.checkout_reservas WHERE checkout_id=$1", identificador
    ) == 2
    for detalle in mock_transbank["transactions"][checkout["token_ws"]]["details"]:
        detalle.update(status="FAILED", response_code=-1)
    for _ in range(2):
        confirmacion = await client.post(
            "/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]}
        )
        assert confirmacion.status_code == 200, confirmacion.text
        assert confirmacion.json()["estado"] == "rechazado"
        assert await conn.fetch(
            "SELECT id,stock,stock_reservado FROM public.productos WHERE id=ANY($1::uuid[]) "
            "ORDER BY id", productos,
        ) == antes
        assert await conn.fetchval(
            "SELECT count(*) FROM private.checkout_reservas WHERE checkout_id=$1", identificador
        ) == 0
    assert mock_transbank["commit"].call_count == 1
    mock_email.assert_not_awaited()


async def test_fallo_segunda_reserva_revierte_primera(
    client, headers, checkout_body, conn, mock_transbank, monkeypatch
):
    from app.repositories import checkouts_repo

    # Use two products from different producers (both in RM region)
    # PRODUCT_ID = 30000000-0000-0000-0000-000000000201 (producer 002)
    # Product 501 = 30000000-0000-0000-0000-000000000501 (producer 005)
    productos = [UUID(PRODUCT_ID), UUID("30000000-0000-0000-0000-000000000501")]
    antes = await conn.fetch(
        "SELECT id,stock,stock_reservado FROM public.productos WHERE id=ANY($1::uuid[]) "
        "ORDER BY id", productos,
    )
    checkouts_antes = await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts")
    reservas_antes = await conn.fetchval("SELECT count(*) FROM private.checkout_reservas")
    reservar = checkouts_repo.reservar
    llamadas = 0

    async def segunda_falla(connection, checkout_id, producto_id, cantidad):
        nonlocal llamadas
        llamadas += 1
        if llamadas == 2:
            return False
        return await reservar(connection, checkout_id, producto_id, cantidad)

    monkeypatch.setattr(checkouts_repo, "reservar", segunda_falla)
    respuesta = await _iniciar(client, headers, {
        **checkout_body,
        "items": [{"producto_id": str(p), "cantidad": 2} for p in productos],
    })
    assert respuesta.status_code == 409, respuesta.text
    assert llamadas == 2
    mock_transbank["create"].assert_not_called()
    assert await conn.fetchval("SELECT count(*) FROM private.webpay_checkouts") == checkouts_antes
    assert await conn.fetchval("SELECT count(*) FROM private.checkout_reservas") == reservas_antes
    assert await conn.fetch(
        "SELECT id,stock,stock_reservado FROM public.productos WHERE id=ANY($1::uuid[]) "
        "ORDER BY id", productos,
    ) == antes
