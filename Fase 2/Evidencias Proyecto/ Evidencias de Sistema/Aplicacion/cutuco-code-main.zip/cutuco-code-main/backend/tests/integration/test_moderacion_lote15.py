"""Lote 15 — Moderación y sanciones (lado BD), ejecutado contra PG16 real.

CK-0199/0213 trigger BEFORE INSERT/UPDATE rechaza texto prohibido en productos;
CK-0200 idem en productores (tienda); CK-0201 texto válido permitido;
CK-0202 contiene_palabra_prohibida detecta coincidencias en catálogo existente
(consulta del admin); CK-0203 descarte desactivando la palabra sin sancionar;
CK-0206 ban permanente desactiva perfil (login bloqueado, deps.py:18-19) y
productor (no vende); CK-0210 rol no admin no puede operar sanciones;
CK-0212 normalización case-insensitive con separaciones (tildes documentadas);
CK-0215 suspensión vencida -> expirada -> reactiva sólo ese efecto;
CK-0401 motivo vacío/solo espacios rechazado en servidor (migración lote 15).

Cada aserción de error corre dentro de un SAVEPOINT porque el fixture `conn`
envuelve el test en una transacción: tras un error PostgreSQL aborta la tx.
"""

import json
from uuid import UUID

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
# Productor 002 = Valle Melipilla (active)
PERFIL_P1 = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_P1 = UUID("20000000-0000-0000-0000-000000000002")
# Productor 003 = Valle Quillota (active)
PRODUCTOR_P2 = UUID("20000000-0000-0000-0000-000000000003")
# Productor 004 = Huerta Pausada (inactive)
PRODUCTOR_P3 = UUID("20000000-0000-0000-0000-000000000004")
CATEGORIA = UUID("13000000-0000-0000-0000-000000000001")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def falla(conn, match, sql, *args):
    """Ejecuta un statement que debe fallar y restaura la tx con savepoint."""
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(sql, *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


_CONTADOR = [0]


async def insertar_producto(conn, **over):
    _CONTADOR[0] += 1
    datos = {
        "productor_id": PRODUCTOR_P1,
        "categoria_id": CATEGORIA,
        "codigo_producto": f"PRD-M{_CONTADOR[0]:06d}",
        "nombre": "Producto lote15",
        "descripcion": "Descripcion valida lote15",
        "precio": 1000,
        "stock": 5,
        "unidad_medida": "unidad",
    }
    datos.update(over)
    cols = ",".join(datos)
    vals = ",".join(f"${i+1}" for i in range(len(datos)))
    return await conn.fetchval(
        f"INSERT INTO public.productos ({cols}) VALUES ({vals}) RETURNING id",
        *datos.values(),
    )


async def agregar_palabra(conn, palabra):
    await autenticar(conn, ADMIN)
    await conn.execute(
        'INSERT INTO public.palabras_prohibidas (palabra, activo) VALUES ($1, true) '
        "ON CONFLICT DO NOTHING",
        palabra,
    )
    await reset(conn)


async def test_ck_0199_producto_con_palabra_prohibida_rechazado(conn):
    await agregar_palabra(conn, "ladron")
    await autenticar(conn, PERFIL_P1)
    base = (
        "INSERT INTO public.productos (productor_id, categoria_id, codigo_producto, nombre,"
        " descripcion, precio, stock, unidad_medida) VALUES ($1,$2,$3,$4,$5,1000,5,'unidad')"
    )
    _CONTADOR[0] += 1
    await falla(conn, "palabra prohibida", base,
                PRODUCTOR_P1, CATEGORIA, f"PRD-M{_CONTADOR[0]:06d}", "ladron al inicio", "ok")
    _CONTADOR[0] += 1
    await falla(conn, "palabra prohibida", base,
                PRODUCTOR_P1, CATEGORIA, f"PRD-M{_CONTADOR[0]:06d}", "texto con ladron al final", "ok")
    _CONTADOR[0] += 1
    await falla(conn, "palabra prohibida", base,
                PRODUCTOR_P1, CATEGORIA, f"PRD-M{_CONTADOR[0]:06d}", "Producto", "Descripcion con LADRON en medio")


async def test_ck_0213_edicion_a_texto_prohibido_rechazada(conn):
    await agregar_palabra(conn, "estafa")
    await autenticar(conn, PERFIL_P1)
    pid = await insertar_producto(conn, nombre="Producto honesto lote15")
    await falla(
        conn, "palabra prohibida",
        "UPDATE public.productos SET nombre=$1 WHERE id=$2", "Esto es una estafa", pid,
    )
    nombre = await conn.fetchval("SELECT nombre FROM public.productos WHERE id=$1", pid)
    assert nombre == "Producto honesto lote15"  # el dato anterior se conserva


async def test_ck_0200_tienda_con_palabra_prohibida_rechazada(conn):
    await agregar_palabra(conn, "ladron")
    await autenticar(conn, ADMIN)
    await falla(
        conn, "palabra prohibida",
        "UPDATE public.productores SET nombre_comercial=$1 WHERE id=$2",
        "Tienda de ladron", PRODUCTOR_P1,
    )


async def test_ck_0201_texto_valido_permitido(conn):
    await autenticar(conn, PERFIL_P1)
    pid = await insertar_producto(conn, nombre="Tomates frescos de Paine")
    assert pid is not None


async def test_ck_0202_detecta_coincidencias_en_catalogo_existente(conn):
    await agregar_palabra(conn, "tomate")
    await autenticar(conn, ADMIN)
    coincidencias = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE public.contiene_palabra_prohibida(nombre)"
    )
    assert coincidencias >= 1  # 'Tomates Roma de Paine' etc. del seed


async def test_ck_0203_descarte_sin_sancion(conn):
    await agregar_palabra(conn, "paine")
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.palabras_prohibidas SET activo=false WHERE lower(palabra)='paine'"
    )
    saldo = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE public.contiene_palabra_prohibida(nombre)"
    )
    assert saldo == 0
    sanciones = await conn.fetchval(
        "SELECT count(*) FROM public.sanciones WHERE productor_id=$1", PRODUCTOR_P1
    )
    assert sanciones == 0  # falso positivo no genera sanción


async def test_ck_0212_normalizacion_case_insensitive_y_separaciones(conn):
    await agregar_palabra(conn, "ladron")
    await autenticar(conn, ADMIN)
    f = "SELECT public.contiene_palabra_prohibida($1)"
    assert await conn.fetchval(f, "LADRON grande") is True        # mayúsculas
    assert await conn.fetchval(f, "un xxladronxx aparte") is True  # separación/subcadena
    assert await conn.fetchval(f, "texto limpio") is False
    # Comportamiento documentado: lower() no quita tildes (consistente y revisable por admin)
    assert await conn.fetchval(f, "ladrón con tilde") is False


async def test_ck_0206_ban_permanente_bloquea_login_y_venta(conn):
    await autenticar(conn, ADMIN)
    await conn.execute(
        "INSERT INTO public.sanciones (productor_id, tipo, accion, motivo) "
        "VALUES ($1,'suspension','ban_permanente',$2)",
        PRODUCTOR_P1,
        "Ban permanente de prueba por fraude confirmado en conciliacion.",
    )
    await reset(conn)
    perfil_activo = await conn.fetchval(
        "SELECT activo FROM public.perfiles WHERE id=$1", PERFIL_P1
    )
    productor_activo = await conn.fetchval(
        "SELECT activo FROM public.productores WHERE id=$1", PRODUCTOR_P1
    )
    assert perfil_activo is False     # deps.py:18-19 rechaza el login (401)
    assert productor_activo is False   # no puede vender


async def test_ck_0210_rol_no_admin_no_puede_operar_sanciones(conn):
    await autenticar(conn, CLIENTE)
    await falla(
        conn, "administrador|row-level security",
        "INSERT INTO public.sanciones (productor_id, tipo, accion, motivo) "
        "VALUES ($1,'suspension','suspender',$2)",
        PRODUCTOR_P1,
        "Intento de sancion por un cliente, debe ser rechazado.",
    )
    filas = await conn.fetchval(
        "SELECT count(*) FROM public.sanciones WHERE productor_id=$1", PRODUCTOR_P1
    )
    assert filas == 0  # RLS: un cliente no ve sanciones de terceros


async def test_ck_0215_suspension_vencida_se_expira_y_reactiva_solo_ese_efecto(conn):
    await autenticar(conn, ADMIN)
    await conn.execute(
        "INSERT INTO public.sanciones (productor_id, tipo, accion, duracion_dias, motivo) "
        "VALUES ($1,'suspension','suspender',30,$2)",
        PRODUCTOR_P2,
        "Suspension temporal de prueba para verificar la expiracion automatica.",
    )
    await reset(conn)
    assert await conn.fetchval(
        "SELECT activo FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is False
    # Se fuerza el vencimiento manteniendo los claims de admin (el trigger exige admin)
    await autenticar(conn, ADMIN)
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute(
        "UPDATE public.sanciones SET inicio_en = now() - interval '2 days', "
        "fin_en = now() - interval '1 minute' "
        "WHERE productor_id=$1 AND accion='suspender' AND estado='activa'",
        PRODUCTOR_P2,
    )
    expiradas = await conn.fetchval("SELECT private.expirar_suspensiones_vencidas()")
    assert expiradas >= 1
    estado = await conn.fetchval(
        "SELECT estado FROM public.sanciones WHERE productor_id=$1 AND accion='suspender' "
        "ORDER BY creado_en DESC LIMIT 1",
        PRODUCTOR_P2,
    )
    assert estado == "expirada"
    assert await conn.fetchval(
        "SELECT activo FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is True  # sólo se retiró el efecto vencido


async def test_ck_0401_motivo_vacio_o_solo_espacios_rechazado_en_servidor(conn):
    await autenticar(conn, ADMIN)
    sql = (
        "INSERT INTO public.sanciones (productor_id, tipo, accion, motivo) "
        "VALUES ($1,'amonestacion','ninguna',$2)"
    )
    for motivo in ("", "   ", "\t\n "):
        await falla(conn, "motivo", sql, PRODUCTOR_P3, motivo)
    # motivo válido sí entra y queda recortado (btrim en el trigger)
    await conn.execute(sql, PRODUCTOR_P3, "  Amonestacion de prueba con motivo valido.  ")
    motivo = await conn.fetchval(
        "SELECT motivo FROM public.sanciones WHERE productor_id=$1 ORDER BY creado_en DESC LIMIT 1",
        PRODUCTOR_P3,
    )
    assert motivo == "Amonestacion de prueba con motivo valido."
