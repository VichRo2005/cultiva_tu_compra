"""CK-0204/0216: efectos independientes de amonestación, sanción y deuda."""

import json
from uuid import UUID

import pytest

from app.repositories import servicio_repo

PRODUCTOR = UUID('20000000-0000-0000-0000-000000000003')
PERFIL = UUID('a0000000-0000-0000-0000-000000000103')
ADMIN = 'a0000000-0000-0000-0000-000000000001'


async def sancion(conn, accion):
    await conn.execute("SELECT set_config('request.jwt.claims', $1, true)",
                       json.dumps({'sub': ADMIN, 'role': 'authenticated'}))
    return await conn.fetchrow('''INSERT INTO public.sanciones
        (productor_id,tipo,accion,motivo,duracion_dias)
        VALUES ($1,$2::public.tipo_sancion,$3::public.accion_sancion,
                'Prueba aislada Checklist',$4) RETURNING *''',
        PRODUCTOR, 'amonestacion' if accion == 'ninguna' else 'suspension',
        accion, 2 if accion == 'suspender' else None)


async def productor(conn):
    return await conn.fetchrow('SELECT * FROM public.productores WHERE id=$1', PRODUCTOR)


@pytest.mark.asyncio
async def test_amonestacion_no_bloquea_ni_reactiva(conn):
    aviso = await sancion(conn, 'ninguna')
    assert aviso['impuesta_por'] == UUID(ADMIN)
    assert aviso['inicio_en'] is not None
    assert aviso['numero_amonestacion'] == 1
    assert (await productor(conn))['activo']
    suspension = await sancion(conn, 'suspender')
    assert not (await productor(conn))['activo']
    await conn.execute("UPDATE public.sanciones SET estado='cancelada' WHERE id=$1",
                       suspension['id'])
    assert (await productor(conn))['activo'], 'La amonestación no mantiene la suspensión'
    await conn.execute('UPDATE public.productores SET activo=false WHERE id=$1', PRODUCTOR)
    await conn.execute("UPDATE public.sanciones SET estado='cancelada' WHERE id=$1", aviso['id'])
    assert not (await productor(conn))['activo'], 'Cerrar un aviso no reactiva la cuenta'


@pytest.mark.asyncio
@pytest.mark.parametrize('accion', ['suspender', 'ban_permanente'])
async def test_pago_deuda_no_levanta_sancion(conn, accion):
    await sancion(conn, accion)
    await conn.execute('SELECT private.crear_cuota_servicio($1)', PRODUCTOR)
    await conn.execute('''UPDATE public.pagos_servicio
        SET emitido_en=current_date-20, vence_en=current_date-10, estado='pendiente'
        WHERE productor_id=$1''', PRODUCTOR)
    await conn.execute('SELECT private.sincronizar_morosidad_productor($1)', PRODUCTOR)
    assert (await productor(conn))['servicio_suspendido']
    cuotas = await conn.fetch(
        'SELECT id FROM public.pagos_servicio WHERE productor_id=$1', PRODUCTOR
    )
    for cuota in cuotas:
        await servicio_repo.mark_paid(conn, cuota['id'], PRODUCTOR, 'QA-SIN-COBRO')
    actual = await productor(conn)
    assert not actual['servicio_suspendido']
    assert not actual['activo']
    perfil_activo = await conn.fetchval('SELECT activo FROM public.perfiles WHERE id=$1', PERFIL)
    assert perfil_activo is (accion != 'ban_permanente')
