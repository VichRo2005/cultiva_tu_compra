"""Unitarios del servicio de datos bancarios: enmascarado y validaciones.

No requieren base de datos.
"""

import pytest
from cryptography.fernet import Fernet
from fastapi import HTTPException

from app.core.encryption import decrypt_text, encrypt_text, hash_account, mask_account
from app.schemas.datos_bancarios import DatosBancariosCreate, DatosBancariosUpdate
from app.services.datos_bancarios_service import validar_titularidad


def test_mask_account_ultimos_4():
    assert mask_account("123456789001") == "****9001"


def test_mask_account_ignora_espacios_y_guiones():
    assert mask_account("12-345 678") == "****5678"


def test_mask_account_corta():
    assert mask_account("123") == "****123"


def test_mask_account_vacia():
    assert mask_account("") == "****"


def test_cifrado_fernet_roundtrip(monkeypatch):
    monkeypatch.setenv("BANK_ENCRYPTION_KEY", Fernet.generate_key().decode())
    from app.core.config import get_settings

    get_settings.cache_clear()
    cifrado = encrypt_text("987654321")
    assert isinstance(cifrado, bytes)
    assert b"987654321" not in cifrado
    assert decrypt_text(cifrado) == "987654321"


def test_create_valida_rut_con_formato_flexible():
    body = DatosBancariosCreate(
        banco="Banco Estado",
        tipo_cuenta="cuenta rut",
        numero_cuenta="12345678",
        titular_cuenta="Nombre Apellido",
        rut_titular="12.345.678-5",
    )
    assert body.rut_titular == "12345678-5"


def test_create_rechaza_rut_invalido():
    with pytest.raises(ValueError):
        DatosBancariosCreate(
            banco="Banco Estado",
            tipo_cuenta="cuenta rut",
            numero_cuenta="12345678",
            titular_cuenta="Nombre Apellido",
            rut_titular="12345678-9",
        )


def test_create_rechaza_numero_corto():
    with pytest.raises(ValueError):
        DatosBancariosCreate(
            banco="Banco Estado",
            tipo_cuenta="cuenta rut",
            numero_cuenta="12",
            titular_cuenta="Nombre Apellido",
            rut_titular="12345678-5",
        )


@pytest.mark.parametrize("numero", ["1234567", "001234567890"])
def test_create_acepta_7_y_12_digitos(numero):
    body = DatosBancariosCreate(
        banco="Banco Estado",
        tipo_cuenta="cuenta_corriente",
        numero_cuenta=numero,
        titular_cuenta="Nombre Apellido",
        rut_titular="12345678-5",
    )
    # HAL-REG-012: se conserva como texto, con ceros iniciales.
    assert body.numero_cuenta == numero
    assert isinstance(body.numero_cuenta, str)


@pytest.mark.parametrize("numero", ["123456", "1234567890123", "12-3456", "１２３４５６７"])
def test_create_rechaza_fuera_de_rango_o_no_ascii(numero):
    with pytest.raises(ValueError):
        DatosBancariosCreate(
            banco="Banco Estado",
            tipo_cuenta="cuenta_corriente",
            numero_cuenta=numero,
            titular_cuenta="Nombre Apellido",
            rut_titular="12345678-5",
        )


def test_update_valida_largo_sin_tipo():
    with pytest.raises(ValueError):
        DatosBancariosUpdate(numero_cuenta="1234567890123")


def test_hash_cuenta_determinista_y_distinto_por_numero(test_settings):
    assert hash_account("001234567890") == hash_account("001234567890")
    assert hash_account("001234567890") != hash_account("001234567891")
    assert len(hash_account("001234567890")) == 32
    assert b"001234567890" not in hash_account("001234567890")


def _postulacion(**overrides):
    data = {
        "estado": "aprobada",
        "rut_solicitante": "12345678-5",
        "tipo_de_persona": "natural",
        "nombre_comercial_solicitado": "Huerta Norte",
        "certificado_titularidad_bancaria": "vendedor-documentos/x/banco.pdf",
    }
    data.update(overrides)
    return data


def _perfil():
    return {"nombre": "Ana", "apellido": "Pérez"}


def test_titularidad_natural_ok():
    validar_titularidad(
        _perfil(),
        _postulacion(),
        {"rut_titular": "12345678-5", "titular_cuenta": "Pérez Ana"},
    )


def test_titularidad_natural_rechaza_rut():
    with pytest.raises(HTTPException) as exc:
        validar_titularidad(
            _perfil(),
            _postulacion(),
            {"rut_titular": "11111111-1", "titular_cuenta": "Ana Pérez"},
        )
    assert exc.value.status_code == 422
    assert "RUT del titular" in exc.value.detail


def test_titularidad_natural_rechaza_titular_de_tercero():
    with pytest.raises(HTTPException) as exc:
        validar_titularidad(
            _perfil(),
            _postulacion(),
            {"rut_titular": "12345678-5", "titular_cuenta": "Juan Soto"},
        )
    assert exc.value.status_code == 422
    assert "titular no coincide" in exc.value.detail


def test_titularidad_juridica_exige_razon_social_y_certificado():
    with pytest.raises(HTTPException):
        validar_titularidad(
            _perfil(),
            _postulacion(tipo_de_persona="juridica"),
            {"rut_titular": "12345678-5", "titular_cuenta": "Otra Empresa SpA"},
        )
    with pytest.raises(HTTPException) as exc:
        validar_titularidad(
            _perfil(),
            _postulacion(tipo_de_persona="juridica", certificado_titularidad_bancaria=None),
            {"rut_titular": "12345678-5", "titular_cuenta": "Huerta Norte"},
        )
    assert "certificado" in exc.value.detail


def test_titularidad_sin_postulacion_no_inventa_regla():
    validar_titularidad(_perfil(), None, {"rut_titular": "99999999-9", "titular_cuenta": "X"})


def test_update_campos_opcionales_none_no_valida():
    body = DatosBancariosUpdate(banco="Nuevo Banco")
    assert body.rut_titular is None
    assert body.numero_cuenta is None


def test_update_normaliza_rut():
    body = DatosBancariosUpdate(rut_titular="12345678-5")
    assert body.rut_titular == "12345678-5"
