"""Reclamos: validación real al omitir navegador y aislamiento de la respuesta."""

import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def crear(conn, pedido, motivo="Producto dañado", descripcion="El producto llegó dañado."):
    return await conn.fetchval(
        """INSERT INTO public.reclamos
        (pedido_id,cliente_id,motivo,descripcion) VALUES($1,$2,$3,$4) RETURNING id""",
        pedido,
        CLIENTE,
        motivo,
        descripcion,
    )


@pytest.mark.parametrize(
    "motivo,descripcion",
    [("", "Descripción"), ("   ", "Descripción"), ("Motivo", ""), ("Motivo", "   ")],
)
async def test_reclamo_no_acepta_textos_vacios(conn, paid_checkout, motivo, descripcion):
    await autenticar(conn, CLIENTE)
    with pytest.raises(asyncpg.RaiseError):
        async with conn.transaction():
            await crear(conn, paid_checkout["pedido_id"], motivo, descripcion)
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.reclamos WHERE pedido_id=$1", paid_checkout["pedido_id"]
        )
        == 0
    )


async def test_reclamo_respuesta_y_duplicado(conn, paid_checkout):
    pedido = paid_checkout["pedido_id"]
    vendedor = await conn.fetchval(
        """SELECT pr.perfil_id FROM public.pedidos p
        JOIN public.productores pr ON pr.id=p.productor_id WHERE p.id=$1""",
        pedido,
    )
    pago = await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido)
    await autenticar(conn, CLIENTE)
    reclamo = await crear(conn, pedido)
    with pytest.raises(asyncpg.UniqueViolationError):
        async with conn.transaction():
            await crear(conn, pedido)
    await autenticar(conn, vendedor)
    with pytest.raises(asyncpg.RaiseError):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.reclamos SET respuesta_productor=$2 WHERE id=$1", reclamo, "   "
            )
    await conn.execute(
        "UPDATE public.reclamos SET respuesta_productor=$2 WHERE id=$1",
        reclamo,
        "Solicito antecedentes para resolver el caso.",
    )
    await autenticar(conn, CLIENTE)
    respuesta = await conn.fetchval(
        "SELECT respuesta_productor FROM public.reclamos WHERE id=$1", reclamo
    )
    assert respuesta == "Solicito antecedentes para resolver el caso."
    admin = UUID("a0000000-0000-0000-0000-000000000001")
    await autenticar(conn, admin)
    await conn.execute(
        "UPDATE public.reclamos SET estado='resuelto', resuelto_por=$2, resuelto_en=now() "
        "WHERE id=$1",
        reclamo,
        admin,
    )
    await autenticar(conn, vendedor)
    with pytest.raises(asyncpg.RaiseError, match="cerrado"):
        async with conn.transaction():
            await conn.execute(
                "UPDATE public.reclamos SET respuesta_productor=$2 WHERE id=$1",
                reclamo,
                "Cambio posterior",
            )
    await autenticar(conn, CLIENTE)
    cerrado = await conn.fetchrow("SELECT * FROM public.reclamos WHERE id=$1", reclamo)
    assert cerrado["estado"] == "resuelto"
    assert cerrado["resuelto_por"] == admin
    assert cerrado["resuelto_en"] is not None
    assert cerrado["respuesta_productor"] == respuesta
    await conn.execute("RESET ROLE")
    assert await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido) == pago
