"""Lote 11 — Registro cliente (lado BD), ejecutado contra PG16 real.

CK-0020 perfil nace como cliente vía trigger en auth.users;
CK-0029/0368 un correo = una identidad (unique en auth.users);
CK-0025/0377 comuna con FK existente (y regla de número de domicilio);
CK-0026 dirección de entrega persistida con depto_oficina.
"""

import json
from uuid import UUID, uuid4

import asyncpg
import pytest

CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
COMUNA_SEED = UUID("12000000-0000-0000-0000-000000000001")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def alta_auth(conn, email, metadata=None):
    uid = uuid4()
    meta = json.dumps(metadata or {"nombre": "Ana", "apellido": "Paz"})
    await conn.execute(
        """INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at,
             raw_user_meta_data, aud, role, created_at, updated_at)
           VALUES ($1,$2,'x',null,$3,'authenticated','authenticated',now(),now())""",
        uid,
        email,
        meta,
    )
    return uid


async def test_ck_0020_alta_crea_perfil_cliente(conn):
    uid = await alta_auth(conn, "lote11-a@example.test", {"nombre": "Ana", "apellido": "Paz"})
    perfil = await conn.fetchrow("SELECT rol, activo, nombre, apellido FROM public.perfiles WHERE id=$1", uid)
    assert perfil["rol"] == "cliente" and perfil["activo"] and perfil["nombre"] == "Ana"


async def test_ck_0029_doble_envio_controlado(conn):
    # doble clic / envío simultáneo: la identidad es la PK de auth.users y el
    # trigger de perfil es idempotente (on conflict do nothing)
    uid = await alta_auth(conn, "lote11-dup@example.test")
    with pytest.raises(asyncpg.UniqueViolationError):
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO auth.users (id, email, encrypted_password, raw_user_meta_data, aud, role, created_at, updated_at)
                   VALUES ($1,$2,'x','{}','authenticated','authenticated',now(),now())""",
                uid,
                "lote11-dup@example.test",
            )
    n = await conn.fetchval("SELECT count(*) FROM public.perfiles WHERE id=$1", uid)
    assert n == 1
    # la unicidad por correo la aplica la API de GoTrue (signup rechaza
    # "User already registered"); el frontend traduce ese error (registro-politicas.spec.js)


async def test_ck_0025_0377_comuna_inexistente_rechazada(conn):
    await autenticar(conn, CLIENTE)
    with pytest.raises(asyncpg.ForeignKeyViolationError):
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.direcciones (perfil_id, comuna_id, calle, numero)
                   VALUES ($1,$2,'Calle Falsa','123')""",
                CLIENTE,
                UUID("c0000000-0000-0000-0000-000000000001"),
            )


async def test_ck_0026_0377_direccion_valida_y_reglas(conn):
    await autenticar(conn, CLIENTE)
    # comuna seed válida: se guarda con depto_oficina
    did = await conn.fetchval(
        """INSERT INTO public.direcciones (perfil_id, comuna_id, calle, numero, depto_oficina, referencia, es_principal)
           VALUES ($1,$2,'Av. Siempre Viva','742','Depto 5','Frente al parque',false) RETURNING id""",
        CLIENTE,
        COMUNA_SEED,
    )
    fila = await conn.fetchrow("SELECT comuna_id, depto_oficina FROM public.direcciones WHERE id=$1", did)
    assert fila["comuna_id"] == COMUNA_SEED and fila["depto_oficina"] == "Depto 5"
    # regla de BD vigente (20261101010000): número opcional pero máximo 20 caracteres
    with pytest.raises(asyncpg.RaiseError, match="20 caracteres"):
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.direcciones (perfil_id, comuna_id, calle, numero)
                   VALUES ($1,$2,'Calle Rota',$3)""",
                CLIENTE,
                COMUNA_SEED,
                "9" * 21,
            )
    # comuna existe pero el perfil no es dueño: RLS/trigger rechaza ajeno
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")
    await autenticar(conn, UUID("a0000000-0000-0000-0000-000000000103"))
    with pytest.raises(asyncpg.PostgresError):
        async with conn.transaction():
            await conn.execute(
                """INSERT INTO public.direcciones (perfil_id, comuna_id, calle, numero)
                   VALUES ($1,$2,'Calle X','1')""",
                CLIENTE,
                COMUNA_SEED,
            )
