import json
from unittest.mock import MagicMock
from uuid import uuid4

import pytest
from pydantic import ValidationError
from transbank.webpay.webpay_plus.mall_transaction import MallTransaction

from app.core.exceptions import WebpayError
from app.integrations.webpay.client import WebpayClient
from app.schemas.webpay import Boleta, Factura


def test_sdk_serializa_cuatro_tiendas_repetidas_y_fee(monkeypatch):
    post = MagicMock(return_value={"token": "token", "url": "https://test.test/pay"})
    monkeypatch.setattr("transbank.webpay.webpay_plus.mall_transaction.RequestService.post", post)
    details = []
    for _ in range(4):
        details.extend(
            [
                {"amount": 950, "commerce_code": "597055555536", "buy_order": uuid4().hex[:26]},
                {"amount": 50, "commerce_code": "597055555537", "buy_order": uuid4().hex[:26]},
            ]
        )
    client = WebpayClient()
    assert isinstance(client.tx, MallTransaction)
    client.create("order", "session", details, "http://localhost/return")
    payload = json.loads(post.call_args.args[1])
    assert payload["details"] == [dict(d, amount=str(d["amount"])) for d in details]
    assert len({d["buy_order"] for d in payload["details"]}) == 8


def test_sdk_rechaza_buy_orders_repetidos():
    detail = {"amount": 100, "commerce_code": "597055555536", "buy_order": "same"}
    with pytest.raises(WebpayError):
        WebpayClient().create("order", "session", [detail, detail], "http://localhost/return")


@pytest.mark.parametrize("field", ["rut_empresa", "razon_social", "giro", "direccion_tributaria"])
def test_factura_exige_todos_los_datos(field):
    data = {
        "tipo": "factura",
        "rut_empresa": "12.345.678-5",
        "razon_social": "Empresa",
        "giro": "Alimentos",
        "direccion_tributaria": "Calle 1",
    }
    del data[field]
    with pytest.raises(ValidationError):
        Factura(**data)


def test_factura_valida_rut_y_boleta_no_lo_pide():
    assert Boleta().model_dump() == {"tipo": "boleta"}
    with pytest.raises(ValidationError):
        Factura(
            tipo="factura",
            rut_empresa="12345678-0",
            razon_social="Empresa",
            giro="Alimentos",
            direccion_tributaria="Calle 1",
        )


def test_rutas_retiradas_no_aparecen_en_openapi(sync_client):
    paths = sync_client.app.openapi()["paths"]
    assert not any("payout" in path for path in paths)
    assert any("datos-bancarios" in path for path in paths)
