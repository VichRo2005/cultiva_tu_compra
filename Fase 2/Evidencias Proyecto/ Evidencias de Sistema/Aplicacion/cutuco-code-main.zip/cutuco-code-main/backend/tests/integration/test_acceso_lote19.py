"""Lote 19 — Acceso y sesión / Contraseña y correo (lado BD), PG16 real.

CK-0002 vendedor aprobado accede a funciones de vendedor (rol + productor
         activo + código Mall + sin sanciones ni deuda de servicio);
CK-0003 admin accede a módulos administrativos (es_admin_actual + RLS admin);
CK-0010 vendedor con postulación pendiente no puede publicar (RLS 42501);
CK-0407 (servidor) auth.users impone unicidad de correo (GoTrue case-insensitive).
"""

import json
from uuid import UUID, uuid4

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
PERFIL_P1 = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_P1 = UUID("20000000-0000-0000-0000-000000000002")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def test_ck_0002_vendedor_aprobado_accede(conn):
    await autenticar(conn, PERFIL_P1)
    perfil = await conn.fetchrow(
        "SELECT rol, activo FROM public.perfiles WHERE id=$1", PERFIL_P1
    )
    assert perfil["rol"] == "vendedor" and perfil["activo"] is True
    productor = await conn.fetchrow(
        "SELECT activo, codigo_comercio_mall FROM public.productores WHERE id=$1", PRODUCTOR_P1
    )
    assert productor["activo"] is True
    assert productor["codigo_comercio_mall"]
    assert await conn.fetchval(
        "SELECT private.es_productor_actual($1)", PRODUCTOR_P1
    ) is True
    # sin sanciones vigentes ni deuda de servicio vencida (vista admin vía postgres)
    await reset(conn)
    await conn.execute("SET LOCAL ROLE postgres")
    assert await conn.fetchval(
        "SELECT count(*) FROM public.sanciones WHERE productor_id=$1 AND estado='activa'", PRODUCTOR_P1
    ) == 0
    assert await conn.fetchval(
        "SELECT count(*) FROM public.pagos_servicio ps JOIN public.productores p ON p.id=ps.productor_id "
        "WHERE p.perfil_id=$1 AND ps.estado IN ('pendiente','pendiente_revision','rechazado') "
        "AND ps.vence_en < (now() at time zone 'America/Santiago')::date",
        PERFIL_P1,
    ) == 0


async def test_ck_0003_admin_accede_a_modulos_admin(conn):
    await autenticar(conn, ADMIN)
    assert await conn.fetchval("SELECT private.es_admin_actual()") is True
    # RLS admin: puede listar perfiles (módulo administrativo)
    filas = await conn.fetchval("SELECT count(*) FROM public.perfiles")
    assert filas >= 7


async def test_ck_0010_vendedor_pendiente_no_publica(conn):
    # cuenta nueva con postulación en revisión (rol aún 'cliente')
    await reset(conn)
    await conn.execute("SET LOCAL ROLE postgres")
    nuevo = uuid4()
    # el trigger de Supabase crea public.perfiles automáticamente al insertar auth.users
    await conn.execute(
        "INSERT INTO auth.users (id, instance_id, aud, role, email, encrypted_password, "
        "email_confirmed_at, created_at, updated_at) VALUES ($1, "
        "'00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', $2, 'x', now(), now(), now())",
        nuevo,
        f"pendiente-{nuevo}@example.test",
    )
    await conn.execute(
        "INSERT INTO public.postulaciones_vendedores (perfil_id, nombre_comercial_solicitado, "
        "descripcion, estado) VALUES ($1,'Tienda Pendiente Lote19','Postulacion lote 19.','borrador')",
        nuevo,
    )
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.postulaciones_vendedores SET estado='en_revision' WHERE perfil_id=$1", nuevo
    )
    await autenticar(conn, nuevo)
    # no es productor actual: no puede publicar ni gestionar pedidos
    assert await conn.fetchval(
        "SELECT count(*) FROM public.productores WHERE perfil_id=$1", nuevo
    ) == 0
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match="row-level security|42501|permiso"):
        await conn.execute(
            "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
            "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'kg',$7)",
            PRODUCTOR_P1,
            UUID("13000000-0000-0000-0000-000000000001"),
            "Producto pendiente lote19", "pendiente-lote-19", 1000, 5, "L19PND1",
        )
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


@pytest.mark.skip(
    reason=(
        "CK-0407: unicidad case-insensitive de correo se valida en GoTrue (capa auth), "
        "no en índice de base de datos. En Supabase local, auth.users pertenece a "
        "supabase_auth_admin y las migraciones no pueden crear el índice uq_auth_users_email. "
        "La validación real se prueba en frontend (acceso-lote19.spec.js) vía signInWithPassword."
    )
)
async def test_ck_0407_servidor_impone_correo_unico_skipped():
    """Test omitido: ver documentación del skip reason."""
    pass
