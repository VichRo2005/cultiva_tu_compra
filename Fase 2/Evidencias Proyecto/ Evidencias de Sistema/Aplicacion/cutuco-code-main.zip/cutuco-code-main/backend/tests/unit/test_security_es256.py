import time
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import HTTPException

from app.core import security


async def test_jwt_valido_es256_extrae_sub(mock_jwt):
    claims = await security.validate_token(mock_jwt())
    assert claims["sub"] == "a0000000-0000-0000-0000-000000000002"


async def test_jwt_expirado_401(mock_jwt):
    with pytest.raises(HTTPException) as error:
        await security.validate_token(mock_jwt(exp=int(time.time()) - 1))
    assert error.value.status_code == 401


@pytest.mark.parametrize(
    "claims", [{"iss": "https://evil.supabase.co/auth/v1"}, {"aud": "anon"}, {"sub": "invalid"}]
)
async def test_jwt_claims_invalidos(mock_jwt, claims):
    with pytest.raises(HTTPException) as error:
        await security.validate_token(mock_jwt(**claims))
    assert error.value.status_code == 401


async def test_firma_invalida_401(mock_jwt):
    token = mock_jwt()
    header, payload, signature = token.split(".")
    signature = ("A" if signature[0] != "A" else "B") + signature[1:]
    with pytest.raises(HTTPException):
        await security.validate_token(f"{header}.{payload}.{signature}")


async def test_jwks_cache_10min(monkeypatch, test_settings):
    response = httpx.Response(
        200, json={"keys": []}, request=httpx.Request("GET", test_settings.jwks_url)
    )
    get = AsyncMock(return_value=response)
    monkeypatch.setattr(httpx.AsyncClient, "get", get)
    await security.get_jwks()
    await security.get_jwks()
    assert get.await_count == 1
    stamp, data = security._jwks_cache[test_settings.jwks_url]
    security._jwks_cache[test_settings.jwks_url] = (stamp - 601, data)
    await security.get_jwks()
    assert get.await_count == 2


async def test_unknown_kid_401(mock_jwt):
    import jwt

    token = mock_jwt()
    claims = jwt.decode(token, options={"verify_signature": False})
    from cryptography.hazmat.primitives.asymmetric import ec

    private = ec.generate_private_key(ec.SECP256R1())
    unknown = jwt.encode(claims, private, algorithm="ES256", headers={"kid": "unknown"})
    with pytest.raises(HTTPException) as error:
        await security.validate_token(unknown)
    assert error.value.status_code == 401


async def test_alg_hs256_401(mock_jwt):
    import jwt

    claims = jwt.decode(mock_jwt(), options={"verify_signature": False})
    token = jwt.encode(
        claims,
        "invalid-test-secret-with-32-bytes-minimum",
        algorithm="HS256",
        headers={"kid": "test-key"},
    )
    with pytest.raises(HTTPException) as error:
        await security.validate_token(token)
    assert error.value.status_code == 401


async def test_kid_index_and_rotation_before_ttl(monkeypatch, test_settings):
    import json

    import jwt
    from cryptography.hazmat.primitives.asymmetric import ec

    old = ec.generate_private_key(ec.SECP256R1())
    new = ec.generate_private_key(ec.SECP256R1())

    def public(key, kid):
        value = json.loads(jwt.algorithms.ECAlgorithm.to_jwk(key.public_key()))
        return value | {"kid": kid, "alg": "ES256", "use": "sig"}

    responses = [
        httpx.Response(
            200,
            json={"keys": [public(old, "old")]},
            request=httpx.Request("GET", test_settings.jwks_url),
        ),
        httpx.Response(
            200,
            json={"keys": [public(new, "new")]},
            request=httpx.Request("GET", test_settings.jwks_url),
        ),
    ]
    get = AsyncMock(side_effect=responses)
    monkeypatch.setattr(httpx.AsyncClient, "get", get)
    await security.get_jwks()
    stamp, data = security._jwks_cache[test_settings.jwks_url]
    assert "old" in data["keys_by_kid"]
    security._jwks_cache[test_settings.jwks_url] = (stamp - 6, data)
    claims = {
        "sub": "a0000000-0000-0000-0000-000000000002",
        "iss": test_settings.issuer,
        "aud": "authenticated",
        "exp": int(time.time()) + 60,
    }
    token = jwt.encode(claims, new, algorithm="ES256", headers={"kid": "new"})
    assert (await security.validate_token(token))["sub"] == claims["sub"]
    await security.validate_token(token)
    assert get.await_count == 2
