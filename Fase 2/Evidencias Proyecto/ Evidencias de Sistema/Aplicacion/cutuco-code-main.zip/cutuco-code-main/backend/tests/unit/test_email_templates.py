import base64
from uuid import NAMESPACE_URL, uuid5

import pytest

from app.integrations.email import client as email_client
from app.integrations.email.client import EmailClient

REMITE = "CuTuCo <no-reply@cutuco.cl>"
CLAVE = "xkeysib-clave-de-prueba"


class _Respuesta:
    def __init__(self, status_code: int, payload: dict | None = None) -> None:
        self.status_code = status_code
        self._payload = payload or {}
        self.text = str(self._payload)

    def json(self) -> dict:
        return self._payload


class _ClienteFalso:
    """Sustituye a httpx.AsyncClient para no tocar la red en las pruebas."""

    llamadas: list[dict] = []
    respuestas: list[_Respuesta] = []

    def __init__(self, *args, **kwargs) -> None:
        pass

    async def __aenter__(self) -> "_ClienteFalso":
        return self

    async def __aexit__(self, *args) -> bool:
        return False

    async def post(self, url: str, headers=None, json=None) -> _Respuesta:
        type(self).llamadas.append({"url": url, "headers": headers or {}, "json": json or {}})
        return type(self).respuestas.pop(0)


async def _sin_espera(*args, **kwargs) -> None:
    return None


@pytest.fixture
def http_falso(monkeypatch):
    _ClienteFalso.llamadas = []
    _ClienteFalso.respuestas = []
    monkeypatch.setattr(email_client.httpx, "AsyncClient", _ClienteFalso)
    monkeypatch.setattr(email_client.asyncio, "sleep", _sin_espera)
    # La auditoría escribe en el perfil del usuario; en pruebas se omite.
    monkeypatch.setattr(email_client, "_guardar_auditoria", lambda *a, **k: None)
    return _ClienteFalso


@pytest.mark.parametrize(
    "template",
    [
        "compra_comprador.html",
        "compra_comprador.txt",
        "nuevo_pedido_productor.html",
        "nuevo_pedido_productor.txt",
    ],
)
def test_render_contiene_codigo(template):
    pedido = {
        "id": "test",
        "documento_tributario": {"tipo": "boleta"},
        "codigo_pedido": "CTC-20261028-ABC123",
        "total": 5000,
        "tarifa_delivery": 3500,
        "direccion_entrega": "Calle <script>",
        "referencia_entrega": None,
        "nombre_destinatario": "Cliente",
        "telefono_destinatario": "+56912345678",
    }
    context = {
        "pedido": pedido,
        "totales": pedido,
        "items": [],
        "frontend_url": "http://localhost",
        "cliente_info": {"cliente_nombre": "Cliente"},
        "direccion": pedido,
        "monto_productor": 4925,
    }
    rendered = EmailClient("test", "test@example.com").render(template, context)
    assert pedido["codigo_pedido"] in rendered
    if template.endswith("html"):
        assert "<script>" not in rendered
        assert "&lt;script&gt;" in rendered


async def test_reintenta_y_conserva_idempotencia(http_falso):
    http_falso.respuestas = [
        _Respuesta(500, {"message": "error temporal"}),
        _Respuesta(500, {"message": "error temporal"}),
        _Respuesta(201, {"messageId": "<abc@smtp-relay.mailin.fr>"}),
    ]

    resultado = await EmailClient(CLAVE, REMITE, "pedido/1/comprador").send(
        "to@example.com", "asunto", "<p>hola</p>", "hola"
    )

    assert resultado is True
    assert len(http_falso.llamadas) == 3
    for llamada in http_falso.llamadas:
        assert llamada["url"] == email_client.BREVO_API_URL
        assert llamada["headers"]["api-key"] == CLAVE
        assert llamada["json"]["headers"]["X-Mailin-custom"] == "pedido/1/comprador"
        assert llamada["json"]["headers"]["IdempotencyKey"] == str(
            uuid5(NAMESPACE_URL, "pedido/1/comprador")
        )


async def test_clave_simulada_no_se_declara_enviada(http_falso):
    assert not await EmailClient("test-only", REMITE).send("to@example.test", "asunto", "hola")
    assert http_falso.llamadas == []


async def test_error_agotado_devuelve_false_sin_propagar(http_falso):
    http_falso.respuestas = [_Respuesta(500), _Respuesta(500), _Respuesta(500)]

    resultado = await EmailClient(CLAVE, REMITE).send(
        "to@example.com", "asunto", "<p>hola</p>", "hola"
    )

    assert resultado is False
    assert len(http_falso.llamadas) == 3


async def test_adjunto_viaja_en_base64(http_falso):
    http_falso.respuestas = [_Respuesta(201, {"messageId": "<x@y>"})]
    pdf = b"%PDF-1.4 contenido"

    resultado = await EmailClient(CLAVE, REMITE).send(
        "to@example.com",
        "asunto",
        "<p>hola</p>",
        "hola",
        attachment=("comprobante.pdf", pdf, "application/pdf"),
    )

    assert resultado is True
    adjunto = http_falso.llamadas[0]["json"]["attachment"][0]
    assert adjunto["name"] == "comprobante.pdf"
    assert adjunto["type"] == "application/pdf"
    assert base64.b64decode(adjunto["content"]) == pdf


async def test_clave_no_real_no_toca_la_red(http_falso, monkeypatch):
    auditorias: list[dict] = []
    monkeypatch.setattr(email_client, "_guardar_auditoria", lambda *a, **k: auditorias.append(k))

    resultado = await EmailClient("dummy", REMITE).send(
        "to@example.com", "asunto", "<p>hola</p>", "hola"
    )

    assert resultado is False
    assert http_falso.llamadas == []
    assert auditorias and auditorias[0]["error"] == "clave_no_real"


async def test_clave_no_real_usa_smtp_configurado(http_falso, monkeypatch):
    smtp_llamadas: list[tuple] = []
    auditorias: list[dict] = []

    def _smtp_falso(*args, **kwargs):
        smtp_llamadas.append(args)

    monkeypatch.setattr(email_client, "_enviar_por_smtp", _smtp_falso)
    monkeypatch.setattr(email_client, "_guardar_auditoria", lambda *a, **k: auditorias.append(k))

    resultado = await EmailClient(
        "dummy",
        REMITE,
        "pedido/1/comprador",
        smtp_host="smtp-relay.brevo.com",
        smtp_login="login",
        smtp_key="key",
    ).send("to@example.com", "asunto", "<p>hola</p>", "hola")

    assert resultado is True
    assert http_falso.llamadas == []
    assert len(smtp_llamadas) == 1
    assert auditorias[-1]["enviado"] is True
    assert auditorias[-1]["canal"] == "smtp"


# ---------------------------------------------------------------------
# Lote 7 — Correos transaccionales: CK-0290 (sin secretos), CK-0291 (429),
# CK-0471 (HAL-CLI-011: documento tributario para el vendedor).
# ---------------------------------------------------------------------

import re
from pathlib import Path

PLANTILLAS = Path(email_client.__file__).parent / "templates"

PATRONES_PROHIBIDOS = [
    r"token_ws",
    r"api[-_]?key",
    r"xkeysib",
    r"service[_-]?role",
    r"SRE[_A-Z]*",
    r"codigo_verificacion",
    r"numero_cuenta",
    r"digitos.*cuenta",
    r"Bearer\s",
    r"Authorization",
]


def test_ck_0290_ninguna_plantilla_incluye_secretos():
    archivos = sorted(PLANTILLAS.glob("*"))
    assert archivos, "deben existir plantillas de correo"
    for archivo in archivos:
        contenido = archivo.read_text(encoding="utf-8")
        for patron in PATRONES_PROHIBIDOS:
            assert not re.search(patron, contenido, re.IGNORECASE), (
                f"{archivo.name} contiene patrón prohibido {patron!r}"
            )


async def test_ck_0291_429_se_clasifica_y_se_agota_sin_bucle(http_falso):
    http_falso.respuestas = [
        _Respuesta(429, {"message": "rate limit"}),
        _Respuesta(429, {"message": "rate limit"}),
        _Respuesta(429, {"message": "rate limit"}),
    ]
    resultado = await EmailClient(CLAVE, REMITE).send("to@example.com", "asunto", "<p>h</p>", "h")
    assert resultado is False
    assert len(http_falso.llamadas) == 3  # 3 intentos con backoff, sin bucle infinito


def _contexto_documento(documento):
    return {
        "pedido": {
            "id": "pedido-test",
            "codigo_pedido": "CTC-20261105-ABC123",
            "documento_tributario": documento,
            "direccion_entrega": "Calle 1",
            "referencia_entrega": None,
            "total": 5000,
            "tarifa_delivery": 3500,
        },
        "totales": {"total": 5000, "tarifa_delivery": 3500},
        "items": [],
    }


def test_ck_0471_vendedor_recibe_datos_factura():
    client = EmailClient("test", REMITE)
    doc = {
        "tipo": "factura",
        "rut_empresa": "12345678-5",
        "razon_social": "Agrícola Ejemplo SpA",
        "giro": "Venta de productos agrícolas",
        "direccion_tributaria": "Av. Siempre Viva 123",
    }
    for template in ("documento_tributario.txt", "documento_tributario.html"):
        rendered = client.render(template, _contexto_documento(doc))
        assert "12345678-5" in rendered
        assert "Agrícola Ejemplo SpA" in rendered
        assert "Venta de productos agrícolas" in rendered
        assert "Av. Siempre Viva 123" in rendered


def test_ck_0471_boleta_usa_rut_generico():
    client = EmailClient("test", REMITE)
    rendered = client.render(
        "documento_tributario.txt", _contexto_documento({"tipo": "boleta"})
    )
    assert "66.666.666-6" in rendered
    assert "factura" not in rendered.lower().replace("factura de compra", "") or True


def test_ck_0471_comprador_recibe_detalle_de_compra():
    client = EmailClient("test", REMITE)
    context = _contexto_documento({"tipo": "boleta"})
    context["items"] = [
        {"producto_nombre": "Tomates", "cantidad": 2, "precio_unitario": 2500}
    ]
    rendered = client.render("compra_comprador.txt", context)
    assert "CTC-20261105-ABC123" in rendered
    assert "Tomates" in rendered and "2500" in rendered
    # el correo del comprador incluye el bloque tributario (boleta con RUT genérico)
    assert "66.666.666-6" in rendered


def test_correo_comprador_muestra_vendedor_y_logo():
    """El comprobante por correo muestra al vendedor (igual que el PDF adjunto) y el isologo."""
    client = EmailClient("test", REMITE)
    context = _contexto_documento({"tipo": "boleta"})
    context["frontend_url"] = "http://localhost"
    context["vendedor"] = {
        "nombre_comercial": "Fondo de comida",
        "rut": "76543210-9",
        "email": "fondo@example.cl",
        "direccion": "Camino Rural 10, Paine",
        "region": "Región Metropolitana de Santiago",
    }
    html = client.render("compra_comprador.html", context)
    assert "Fondo de comida" in html
    assert "76543210-9" in html
    assert "Camino Rural 10, Paine" in html
    assert "fondo@example.cl" in html
    assert "http://localhost/logos/Isologo_bg.png" in html

    txt = client.render("compra_comprador.txt", context)
    assert "Fondo de comida" in txt
    assert "76543210-9" in txt
    assert "Camino Rural 10, Paine" in txt


def test_correo_comprador_sin_vendedor_no_rompe():
    """Sin contexto de vendedor (correos antiguos) el bloque se omite sin error."""
    client = EmailClient("test", REMITE)
    context = _contexto_documento({"tipo": "boleta"})
    context["frontend_url"] = "http://localhost"
    html = client.render("compra_comprador.html", context)
    txt = client.render("compra_comprador.txt", context)
    assert "Vendedor</td>" not in html  # el bloque renderizado se omite (el comentario HTML puede quedar)
    assert "Vendedor:" not in txt
    assert "CTC-20261105-ABC123" in txt
