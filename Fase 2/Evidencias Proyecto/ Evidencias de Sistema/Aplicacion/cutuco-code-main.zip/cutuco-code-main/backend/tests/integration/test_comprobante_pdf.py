"""Comprobante de compra: la descarga debe usar los datos completos del vendedor."""

import reportlab.rl_config as rl_config

from app.repositories import pedidos_repo


async def test_comprobante_pdf_muestra_vendedor_y_logo(client, conn, paid_checkout, headers):
    """La ruta de descarga y el adjunto comparten el contexto del pedido.

    Evita una regresión en que se pasaba sólo el comercio y la dirección del
    comprador al bloque ``Datos del vendedor``.
    """
    contexto = await pedidos_repo.get_email_context(conn, paid_checkout["pedido_id"])
    assert contexto is not None
    contexto = dict(contexto)

    anterior = rl_config.pageCompression
    rl_config.pageCompression = 0
    try:
        respuesta = await client.get(
            f"/api/webpay/comprobante/{paid_checkout['pedido_id']}/pdf",
            headers=headers,
        )
    finally:
        rl_config.pageCompression = anterior

    assert respuesta.status_code == 200, respuesta.text
    assert respuesta.headers["content-type"].startswith("application/pdf")
    contenido = respuesta.content.decode("latin-1")
    for valor in (
        "Datos del vendedor",
        contexto["nombre_comercial"],
        contexto["rut_oficial"],
        contexto["productor_email"],
        contexto["vendedor_calle"],
        contexto["vendedor_numero"],
        contexto["vendedor_comuna"],
    ):
        assert str(valor) in contenido
    assert b"/Subtype /Image" in respuesta.content or b"/Subtype/Image" in respuesta.content
