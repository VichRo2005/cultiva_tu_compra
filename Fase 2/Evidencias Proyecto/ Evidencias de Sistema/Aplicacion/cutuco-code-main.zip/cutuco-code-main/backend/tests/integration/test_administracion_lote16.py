"""Lote 16 — Administración y cobros (lado BD), ejecutado contra PG16 real.

CK-0265 baja lógica del producto por admin (conserva historial, fuera del
catálogo público, con motivo obligatorio); CK-0266 el admin NO puede editar la
información comercial (migración 20261105210000) pero sí el estado con motivo;
CK-0270 bandeja de cobros (periodo/monto/referencia/estado visibles para admin);
CK-0271 aprobar transferencia marca pagado + revisado_por/en + reactiva servicio;
CK-0272 rechazar exige observación, deuda queda y permite reintento;
CK-0274 bandeja restringida (RLS + verificación admin en RPC);
CK-0279 el servidor verifica actor y estado aunque no exista el botón;
CK-0276 medición local de consultas administrativas (< 5 s).

Cada aserción de error corre dentro de un SAVEPOINT (el fixture `conn` usa una
transacción externa).
"""

import json
import time
from uuid import UUID

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
PERFIL_P1 = UUID("a0000000-0000-0000-0000-000000000102")  # Productor Paine / Valle Melipilla
PERFIL_P2 = UUID("a0000000-0000-0000-0000-000000000103")  # Productor Quillota
PRODUCTOR_P1 = UUID("20000000-0000-0000-0000-000000000002")  # Valle Melipilla Test
PRODUCTOR_P2 = UUID("20000000-0000-0000-0000-000000000003")  # Valle Quillota Test
PRODUCTO_P1 = UUID("30000000-0000-0000-0000-000000000201")  # Tomates de Melipilla (P1)


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def falla(conn, match, sql, *args):
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(sql, *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


async def rpc_falla(conn, match, nombre, args):
    placeholders = ",".join(f"${i+1}" for i in range(len(args)))
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(f"SELECT public.{nombre}({placeholders})", *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


async def test_ck_0265_baja_logica_admin_conserva_historial(conn):
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.productos SET activo=false, eliminado_en=now(), motivo_pausa=null, "
        "motivo_eliminacion=$1 WHERE id=$2",
        "Baja administrativa de prueba con motivo valido lote 16.",
        PRODUCTO_P1,
    )
    # fuera del catálogo público (RLS anon/authenticated ven sólo activos)
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE anon")
    visibles = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE id=$1", PRODUCTO_P1
    )
    assert visibles == 0
    await reset(conn)
    # el registro histórico sigue existiendo
    existe = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE id=$1 AND eliminado_en IS NOT NULL AND activo=false",
        PRODUCTO_P1,
    )
    assert existe == 1
    # motivo de eliminación obligatorio (>= 10 caracteres)
    await autenticar(conn, ADMIN)
    await falla(
        conn, "justificación|justificacion",
        "UPDATE public.productos SET activo=false, eliminado_en=now(), motivo_pausa=null, "
        "motivo_eliminacion=$1 WHERE id=$2",
        "corto", PRODUCTO_P1,
    )


async def test_ck_0266_admin_no_edita_informacion_comercial(conn):
    await autenticar(conn, ADMIN)
    await falla(
        conn, "información comercial|informacion comercial",
        "UPDATE public.productos SET nombre=$1 WHERE id=$2", "Nombre editado por admin", PRODUCTO_P1,
    )
    await falla(
        conn, "información comercial|informacion comercial",
        "UPDATE public.productos SET precio=$1 WHERE id=$2", 9999, PRODUCTO_P1,
    )
    # el admin SÍ puede operar el estado con motivo
    await conn.execute(
        "UPDATE public.productos SET activo=false, motivo_pausa=$1 WHERE id=$2",
        "Pausa administrativa lote 16 con motivo valido.",
        PRODUCTO_P1,
    )
    # el vendedor dueño SÍ puede editar lo comercial
    await autenticar(conn, PERFIL_P1)
    await conn.execute(
        "UPDATE public.productos SET nombre=$1 WHERE id=$2 AND productor_id=$3",
        "Tomates Roma de Paine (edicion vendedor)", PRODUCTO_P1, PRODUCTOR_P1,
    )
    nombre = await conn.fetchval("SELECT nombre FROM public.productos WHERE id=$1", PRODUCTO_P1)
    assert nombre == "Tomates Roma de Paine (edicion vendedor)"


async def _crear_cuota_y_transferencia(conn, referencia):
    """Crea una cuota para P2 (como backend) y registra la transferencia (como vendedor)."""
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute("SELECT private.crear_cuota_servicio($1)", PRODUCTOR_P2)
    await autenticar(conn, PERFIL_P2)
    await conn.execute(
        "SELECT public.registrar_transferencia_servicio($1,$2)", referencia, "Transferencia de prueba lote 16"
    )
    await reset(conn)
    return await conn.fetchval(
        "SELECT id FROM public.pagos_servicio WHERE productor_id=$1 AND estado='pendiente_revision' "
        "ORDER BY creado_en DESC LIMIT 1",
        PRODUCTOR_P2,
    )


async def test_ck_0270_0271_bandeja_cobros_y_aprobacion_reactivan_servicio(conn):
    pago_id = await _crear_cuota_y_transferencia(conn, "REF-LOTE16-APROBAR-001")
    # fuerza morosidad para verificar la reactivación al aprobar
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute(
        "UPDATE public.pagos_servicio SET periodo = (now() at time zone 'America/Santiago')::date - 40, "
        "emitido_en = (now() at time zone 'America/Santiago')::date - 20, "
        "vence_en = (now() at time zone 'America/Santiago')::date - 10 WHERE id=$1",
        pago_id,
    )
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", PRODUCTOR_P2)
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is True
    # CK-0270: el admin ve período, monto, referencia, fecha y estado
    await autenticar(conn, ADMIN)
    fila = await conn.fetchrow(
        "SELECT periodo, monto, referencia, estado, creado_en, vence_en FROM public.pagos_servicio WHERE id=$1",
        pago_id,
    )
    assert fila["referencia"] == "REF-LOTE16-APROBAR-001"
    assert fila["estado"] == "pendiente_revision"
    assert fila["periodo"] is not None and fila["monto"] is not None
    # CK-0271: aprobar marca pagado con revisado_por/revisado_en y reactiva
    await conn.execute(
        "SELECT public.resolver_pago_servicio($1,'pagado',$2)",
        pago_id,
        "Transferencia verificada contra el banco lote 16.",
    )
    await reset(conn)
    res = await conn.fetchrow(
        "SELECT estado, revisado_por, revisado_en, pagado_en FROM public.pagos_servicio WHERE id=$1",
        pago_id,
    )
    assert res["estado"] == "pagado"
    assert res["revisado_por"] == ADMIN
    assert res["revisado_en"] is not None and res["pagado_en"] is not None
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is False


async def test_ck_0272_rechazo_exige_observacion_y_permite_reintento(conn):
    pago_id = await _crear_cuota_y_transferencia(conn, "REF-LOTE16-RECHAZAR-002")
    await autenticar(conn, ADMIN)
    await rpc_falla(conn, "monto recibido y el beneficiario", "resolver_pago_servicio", (pago_id, "rechazado", "   "))
    await conn.execute(
        "SELECT public.resolver_pago_servicio($1,'rechazado',$2)",
        pago_id,
        "Referencia no coincide con abono bancario observado.",
    )
    await reset(conn)
    estado = await conn.fetchval("SELECT estado FROM public.pagos_servicio WHERE id=$1", pago_id)
    assert estado == "rechazado"  # la deuda se mantiene
    # reintento por transferencia permitido tras el rechazo
    await autenticar(conn, PERFIL_P2)
    await conn.execute(
        "SELECT public.registrar_transferencia_servicio($1,$2)",
        "REF-LOTE16-REINTENTO-003",
        "Nueva transferencia tras rechazo lote 16",
    )
    nuevo = await conn.fetchval(
        "SELECT estado FROM public.pagos_servicio WHERE id=$1", pago_id
    )
    assert nuevo == "pendiente_revision"


async def test_ck_0274_0279_bandeja_restringida_y_servidor_verifica_actor_estado(conn):
    pago_id = await _crear_cuota_y_transferencia(conn, "REF-LOTE16-RLS-004")
    # CK-0274: cliente no ve pagos de servicio de terceros (RLS) ni puede usar el resumen admin
    await autenticar(conn, CLIENTE)
    filas = await conn.fetchval("SELECT count(*) FROM public.pagos_servicio")
    assert filas == 0
    await rpc_falla(conn, "administrador", "admin_servicio_resumen", ())
    # CK-0279: el vendedor no puede resolver aunque invoque la RPC directamente
    await autenticar(conn, PERFIL_P2)
    await rpc_falla(conn, "Solo un administrador", "resolver_pago_servicio", (pago_id, "pagado", "x"))
    # y el admin no puede re-resolver un pago ya revisado (verificación de estado)
    await autenticar(conn, ADMIN)
    await conn.execute(
        "SELECT public.resolver_pago_servicio($1,'pagado',$2)", pago_id, "Aprobado en lote 16."
    )
    await rpc_falla(conn, "ya fue revisado", "resolver_pago_servicio", (pago_id, "rechazado", "Intento extra"))


async def test_ck_0276_consultas_administrativas_en_menos_de_5s(conn):
    await autenticar(conn, ADMIN)
    muestras = {}
    t0 = time.perf_counter()
    await conn.fetch(
        "SELECT * FROM public.postulaciones_vendedores WHERE estado IN ('en_revision') ORDER BY creado_en"
    )
    muestras["pendientes_postulaciones"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    await conn.fetch(
        "SELECT * FROM public.sanciones WHERE estado IN ('activa','apelada') ORDER BY inicio_en DESC"
    )
    muestras["sanciones_activas"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    await conn.fetchval("SELECT public.admin_servicio_resumen()")
    muestras["admin_servicio_resumen"] = time.perf_counter() - t0
    t0 = time.perf_counter()
    await conn.fetch("SELECT * FROM public.pagos ORDER BY creado_en DESC LIMIT 200")
    muestras["pagos"] = time.perf_counter() - t0
    print("\nTIMING admin (QA local PG16):", {k: round(v, 4) for k, v in muestras.items()})
    for nombre, segundos in muestras.items():
        assert segundos < 5, f"{nombre} tardó {segundos:.2f}s"
