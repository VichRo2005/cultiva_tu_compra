"""Entradas inválidas no reemplazan los datos persistidos del marketplace."""

import json
from uuid import UUID

import asyncpg
import pytest

CLIENTE = UUID('a0000000-0000-0000-0000-000000000002')
# Use product 201 (Tomates de Melipilla) from producer 002 which is active
PRODUCTO = UUID('30000000-0000-0000-0000-000000000201')
VENDEDOR_PRODUCTO = 'a0000000-0000-0000-0000-000000000102'


@pytest.mark.parametrize('tabla,campo,identificador,valor', [
    ('perfiles', 'nombre', CLIENTE, ''),
    ('perfiles', 'apellido', CLIENTE, '   '),
    ('perfiles', 'telefono', CLIENTE, '123'),
    ('productos', 'nombre', PRODUCTO, ''),
    ('productos', 'precio', PRODUCTO, -1),
    ('productos', 'stock', PRODUCTO, -1),
    ('productos', 'categoria_id', PRODUCTO, UUID('99999999-9999-9999-9999-999999999999')),
])
async def test_rechaza_dato_invalido_y_conserva_anterior(conn, tabla, campo, identificador, valor):
    # Identificadores SQL estáticos definidos por esta prueba.
    consulta = f'SELECT {campo} FROM public.{tabla} WHERE id=$1'
    anterior = await conn.fetchval(consulta, identificador)
    assert anterior is not None
    propietario = str(CLIENTE) if tabla == 'perfiles' else VENDEDOR_PRODUCTO
    await conn.execute("SELECT set_config('request.jwt.claims',$1,true)",
                       json.dumps({'sub': propietario, 'role': 'authenticated'}))
    await conn.execute('SET LOCAL ROLE authenticated')
    with pytest.raises(asyncpg.PostgresError) as error:
        async with conn.transaction():
            await conn.execute(f'UPDATE public.{tabla} SET {campo}=$2 WHERE id=$1',
                               identificador, valor)
    assert error.value.sqlstate in {'23514', '23503', '22023', 'P0001'}
    assert await conn.fetchval(consulta, identificador) == anterior


@pytest.mark.parametrize('entrada,esperado', [
    ('9 1234 5678', '+56912345678'),
    ('+56 2 2345 6789', '+56223456789'),
    ('32 234 5678', '+56322345678'),
])
async def test_telefono_valido_se_normaliza_sin_cambiar_identidad(conn, entrada, esperado):
    await conn.execute("SELECT set_config('request.jwt.claims',$1,true)",
                       json.dumps({'sub': str(CLIENTE), 'role': 'authenticated'}))
    await conn.execute('SET LOCAL ROLE authenticated')
    await conn.execute('UPDATE public.perfiles SET telefono=$2 WHERE id=$1', CLIENTE, entrada)
    assert (
        await conn.fetchval('SELECT telefono FROM public.perfiles WHERE id=$1', CLIENTE) == esperado
    )
