import json

import pytest
from fastapi import Request
from fastapi.exceptions import RequestValidationError

from app.core.exceptions import validation_error


def _request(path: str) -> Request:
    return Request(
        {
            "type": "http",
            "method": "POST",
            "path": path,
            "headers": [],
            "query_string": b"",
            "scheme": "http",
            "server": ("test", 80),
        }
    )


@pytest.mark.asyncio
async def test_los_errores_de_datos_bancarios_no_devuelven_el_input() -> None:
    exc = RequestValidationError(
        [
            {
                "loc": ("body", "numero_cuenta"),
                "msg": "String should have at least 4 characters",
                "type": "string_too_short",
                "input": "0011223344556677",
            }
        ]
    )
    # Ruta real del router (app/routers/datos_bancarios.py: prefix="/datos-bancarios").
    response = await validation_error(_request("/datos-bancarios"), exc)
    body = json.loads(response.body)
    assert body["detail"] == [
        {
            "loc": ["body", "numero_cuenta"],
            "msg": "String should have at least 4 characters",
            "type": "string_too_short",
        }
    ]
    assert "0011223344556677" not in response.body.decode()
