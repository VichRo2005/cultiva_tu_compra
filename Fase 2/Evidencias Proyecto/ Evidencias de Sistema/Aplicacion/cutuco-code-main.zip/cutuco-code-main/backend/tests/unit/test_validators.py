import pytest
from pydantic import TypeAdapter, ValidationError

from app.schemas.validators import (
    MAX_DOCUMENTO_BYTES,
    PrecioCLP,
    Stock,
    validar_documento_postulacion,
)
from app.schemas.webpay import DireccionSnapshot, IniciarRequest


@pytest.mark.parametrize("cantidad", [0, -1, "NaN", "Infinity", "0.0001", "0.11"])
def test_cantidad_invalida(cantidad):
    with pytest.raises(ValidationError):
        IniciarRequest(
            direccion_id="00000000-0000-0000-0000-000000000001",
            items=[{"producto_id": "00000000-0000-0000-0000-000000000002", "cantidad": cantidad}],
        )


def test_calle_no_vacia():
    with pytest.raises(ValidationError):
        DireccionSnapshot(direccion_entrega="   ")
    assert DireccionSnapshot(direccion_entrega=" Calle 1 ").direccion_entrega == "Calle 1"


def test_referencia_null_explicita_vs_ausente():
    body = {
        "direccion_id": "00000000-0000-0000-0000-000000000001",
        "items": [{"producto_id": "00000000-0000-0000-0000-000000000002", "cantidad": 1}],
    }
    assert "referencia_entrega" not in IniciarRequest(**body).model_fields_set
    assert "referencia_entrega" in IniciarRequest(**body, referencia_entrega=None).model_fields_set


def test_precio_y_stock_limites_comerciales():
    precio = TypeAdapter(PrecioCLP)
    stock = TypeAdapter(Stock)
    assert precio.validate_python("999999") is not None
    with pytest.raises(ValidationError):
        precio.validate_python("1000000")
    assert stock.validate_python("999999999.9") is not None
    with pytest.raises(ValidationError):
        stock.validate_python("1.01")
    with pytest.raises(ValidationError):
        stock.validate_python("1000000000")


def test_documento_10_mib():
    assert MAX_DOCUMENTO_BYTES == 10_485_760
    assert validar_documento_postulacion(MAX_DOCUMENTO_BYTES, "application/pdf") is None
    assert "10 MB" in validar_documento_postulacion(MAX_DOCUMENTO_BYTES + 1, "application/pdf")
    assert "PDF" in validar_documento_postulacion(1024, "text/plain")
