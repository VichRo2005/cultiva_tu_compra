"""HAL-CLI-028 / CK-0487 — integración del endpoint tributario con `actecos`.

A diferencia de test_tributario_api.py (que monkeypatchea get_empresa), aquí se
ejerce el cliente SRE real con httpx falsificado: se verifica que
/api/tributario/empresa/{rut} devuelve razon_social + giro resuelto desde los
códigos `actecos` cuando el SII no publica glosa, y que un código desconocido
deja el giro vacío de forma controlada (el comprador lo escribe a mano).
"""

import httpx

from app.integrations.sre import client as sre_client


class _Respuesta:
    def __init__(self, status_code, payload):
        self.status_code = status_code
        self._payload = payload

    def json(self):
        return self._payload


def _mock_sre(monkeypatch, payload):
    class _ClienteFalso:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def get(self, url, params=None):
            assert url.endswith("/api/company_info")
            return _Respuesta(200, payload)

    monkeypatch.setattr(sre_client.httpx, "AsyncClient", _ClienteFalso)


async def test_endpoint_devuelve_giro_desde_actecos(client, headers, monkeypatch):
    _mock_sre(
        monkeypatch,
        {
            "result": True,
            "rut": "76123456-0",
            "razon_social": "Huerto del Valle SpA",
            "actecos": ["011306"],
            "consultas_restantes": 190,
        },
    )
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 200, response.text
    datos = response.json()
    assert datos["existe"] is True
    assert datos["rut"] == "76123456-0"
    assert datos["razon_social"] == "Huerto del Valle SpA"
    assert datos["giro"] == "Cultivo de hortalizas y melones"
    assert datos["actecos"] == ["011306"]


async def test_endpoint_giro_vacio_con_codigo_desconocido(client, headers, monkeypatch):
    _mock_sre(
        monkeypatch,
        {"result": True, "razon_social": "Empresa Nueva SpA", "actecos": ["999999"]},
    )
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 200, response.text
    datos = response.json()
    assert datos["razon_social"] == "Empresa Nueva SpA"
    assert datos["giro"] == ""
    assert datos["actecos"] == ["999999"]


async def test_endpoint_glosa_publicada_manda_sobre_actecos(client, headers, monkeypatch):
    _mock_sre(
        monkeypatch,
        {
            "result": True,
            "razon_social": "Empresa SpA",
            "glosa_giro": "Comercio al por menor",
            "actecos": ["013000"],
        },
    )
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 200, response.text
    assert response.json()["giro"] == "Comercio al por menor"


async def test_endpoint_fallo_sre_503_sin_detalle_interno(client, headers, monkeypatch):
    class _ClienteRoto:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def get(self, url, params=None):
            raise httpx.ConnectTimeout("timed out")

    monkeypatch.setattr(sre_client.httpx, "AsyncClient", _ClienteRoto)
    response = await client.get("/api/tributario/empresa/76123456-0", headers=headers)
    assert response.status_code == 503
    assert "No fue posible consultar" in response.json()["detail"]
