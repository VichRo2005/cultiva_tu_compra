"""Lote 18 — Datos y privacidad (lado BD), contra PG16 real.

CK-0292 soft delete conserva historial (producto eliminado y cuenta
         desactivada no borran pedidos, detalles ni pagos);
CK-0293 las FK rechazan IDs inexistentes (categoría, comuna);
CK-0295 constraints/triggers rechazan datos inválidos sin navegador
        (precio/stock negativos, slug inválido, comuna inexistente en dirección).
"""

import json
from uuid import UUID, uuid4

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
PERFIL_P2 = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_P2 = UUID("20000000-0000-0000-0000-000000000002")
PRODUCTO_P2 = UUID("30000000-0000-0000-0000-000000000201")
PEDIDO_CLIENTE = UUID("40000000-0000-0000-0000-000000000002")


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def falla(conn, match, sql, *args):
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(sql, *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


async def test_ck_0292_soft_delete_conserva_historial(conn):
    # admin da de baja lógica el producto del pedido del cliente
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.productos SET activo=false, eliminado_en=now(), motivo_pausa=null, "
        "motivo_eliminacion=$1 WHERE id=$2",
        "Baja administrativa con motivo valido lote 18.",
        PRODUCTO_P2,
    )
    # y el sistema desactiva la cuenta del vendedor (p. ej. por sanción)
    await reset(conn)
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute(
        "UPDATE public.productores SET activo=false WHERE id=$1", PRODUCTOR_P2
    )
    # el cliente sigue viendo su pedido, sus detalles y el pago (historial)
    await autenticar(conn, CLIENTE)
    pedido = await conn.fetchrow(
        "SELECT id, estado, total FROM public.pedidos WHERE id=$1", PEDIDO_CLIENTE
    )
    assert pedido is not None
    detalle = await conn.fetchval(
        "SELECT count(*) FROM public.detalles_pedido WHERE pedido_id=$1 AND producto_id=$2",
        PEDIDO_CLIENTE,
        PRODUCTO_P2,
    )
    assert detalle == 1
    pago = await conn.fetchval(
        "SELECT count(*) FROM public.pagos WHERE pedido_id=$1", PEDIDO_CLIENTE
    )
    assert pago == 1
    # nada se borró físicamente
    await reset(conn)
    assert await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE id=$1 AND eliminado_en IS NOT NULL", PRODUCTO_P2
    ) == 1


async def test_ck_0293_fk_rechazan_ids_inexistentes(conn):
    await autenticar(conn, PERFIL_P2)
    inexistente = uuid4()
    # producto con categoría inexistente
    await falla(
        conn, "foreign key|violates",
        "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
        "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'kg',$7)",
        PRODUCTOR_P2, inexistente, "Producto FK invalida", "fk-invalida-lote-18", 1000, 5, "L18FK01",
    )
    # comuna inexistente en un pedido: el trigger de cobertura la rechaza antes
    # que la FK (20261004021917:1462) — solo se aceptan relaciones existentes
    await reset(conn)
    await conn.execute("SET LOCAL ROLE postgres")
    await falla(
        conn, "no pertenece|foreign key|violates",
        "INSERT INTO public.pedidos (codigo_pedido, cliente_id, productor_id, region_entrega_id, "
        "comuna_entrega_id, direccion_entrega, nombre_destinatario, telefono_destinatario, estado) "
        "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'creado')",
        "CUTUCO-FK-018",
        CLIENTE,
        PRODUCTOR_P2,
        UUID("11000000-0000-0000-0000-000000000001"),
        inexistente,
        "Calle Falsa 123 lote 18",
        "Contacto Prueba",
        "+56900000018",
    )


async def test_ck_0295_constraints_rechazan_sin_navegador(conn):
    await autenticar(conn, PERFIL_P2)
    # precio negativo
    await falla(
        conn, "precio|check",
        "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
        "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'kg',$7)",
        PRODUCTOR_P2, UUID("13000000-0000-0000-0000-000000000001"),
        "Producto precio negativo", "precio-negativo-lote-18", -1, 5, "L18NEG1",
    )
    # stock negativo
    await falla(
        conn, "stock|check",
        "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
        "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'kg',$7)",
        PRODUCTOR_P2, UUID("13000000-0000-0000-0000-000000000001"),
        "Producto stock negativo", "stock-negativo-lote-18", 1000, -5, "L18NEG2",
    )
    # unidad de medida fuera del enum permitido
    await falla(
        conn, "enum|invalid input",
        "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
        "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'tonelada',$7)",
        PRODUCTOR_P2, UUID("13000000-0000-0000-0000-000000000001"),
        "Producto unidad invalida", "unidad-invalida-lote-18", 1000, 5, "L18UNI1",
    )
