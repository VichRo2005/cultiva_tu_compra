from uuid import uuid4

from app.repositories import preferencias_notificacion_repo


class _Connection:
    def __init__(self, row):
        self.row = row
        self.calls = []

    async def fetchrow(self, query, perfil_id):
        self.calls.append((query, perfil_id))
        return self.row


async def test_correo_activo_por_defecto_cuando_no_hay_preferencia():
    conn = _Connection(None)

    assert await preferencias_notificacion_repo.recibe_correo(conn, uuid4()) is True
    assert len(conn.calls) == 1


async def test_correo_desactivado_se_respeta():
    conn = _Connection({"recibir_correo": False})

    assert await preferencias_notificacion_repo.recibe_correo(conn, uuid4()) is False
