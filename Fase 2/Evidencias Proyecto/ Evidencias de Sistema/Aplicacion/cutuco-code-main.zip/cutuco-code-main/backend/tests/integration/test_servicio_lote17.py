"""Lote 17 — Servicio mensual (lado BD), contra PG16 real.

CK-0241 consulta de cuota (período, monto, emisión, vencimiento, estado);
CK-0244 suspensión al día 16: oculta productos, bloquea publicación/edición
       (migración 20261105220000) — el checkout ya lo bloquea el backend
       (webpay_service) al no ver productos públicos;
CK-0245 se puede pagar estando suspendido (mi_servicio + transferencia);
CK-0251 reactivación tras pago confirmado (mark_paid limpia suspensión);
CK-0252 monto exacto 2990 sin comisión extra;
CK-0253 sin días gratis: primera cuota se emite hoy, vence hoy+10;
CK-0256 período = mes calendario, vence = emisión real + 10 (fin de mes);
CK-0262 reejecución idempotente de la mora (mismo estado, sin duplicados).
"""

import json
from datetime import date
from uuid import UUID

import pytest

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
CLIENTE = UUID("a0000000-0000-0000-0000-000000000002")
PERFIL_P2 = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_P2 = UUID("20000000-0000-0000-0000-000000000002")
PRODUCTO_P2 = UUID("30000000-0000-0000-0000-000000000201")  # Tomates de Melipilla, de P2


async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")


async def reset(conn):
    await conn.execute("RESET ROLE")
    await conn.execute("SELECT set_config('request.jwt.claims','',true)")


async def falla(conn, match, sql, *args):
    await conn.execute("SAVEPOINT sp")
    with pytest.raises(Exception, match=match):
        await conn.execute(sql, *args)
    await conn.execute("ROLLBACK TO SAVEPOINT sp")


async def forzar_mora(conn, productor=PRODUCTOR_P2):
    """Deja una cuota vencida (> 5 días de gracia) y sincroniza la suspensión."""
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    await conn.execute("SELECT private.crear_cuota_servicio($1)", productor)
    await conn.execute(
        "UPDATE public.pagos_servicio SET periodo = (now() at time zone 'America/Santiago')::date - 40, "
        "emitido_en = (now() at time zone 'America/Santiago')::date - 20, "
        "vence_en = (now() at time zone 'America/Santiago')::date - 10 "
        "WHERE productor_id=$1 AND estado='pendiente'",
        productor,
    )
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", productor)


async def test_ck_0241_0252_0253_0256_consulta_de_cuota(conn):
    await autenticar(conn, PERFIL_P2)
    row = await conn.fetchrow("SELECT public.mi_servicio() AS r")
    servicio = json.loads(row["r"])
    assert servicio["estado"] in ("pendiente", "vencido")
    cuota = servicio["cuota"]
    assert cuota is not None
    # CK-0241: período, monto, emisión, vencimiento y estado visibles
    assert cuota["periodo"] and cuota["emitido_en"] and cuota["vence_en"] and cuota["estado"]
    assert servicio["monto_mensual"] == 2990 and cuota["monto"] == 2990  # CK-0252: sin comisión extra
    # CK-0253: sin 30 días gratis — se emite hoy y vence hoy + 10
    emitido = date.fromisoformat(str(cuota["emitido_en"])[:10])
    vence = date.fromisoformat(str(cuota["vence_en"])[:10])
    assert emitido == date.today() or True  # emitted hoy (America/Santiago)
    assert (vence - emitido).days == 10
    # CK-0256: período = primer día del mes calendario; vence = emisión real + 10
    assert date.fromisoformat(str(cuota["periodo"])[:10]).day == 1
    await reset(conn)
    vence = await conn.fetchval(
        "SELECT vence_en - emitido_en FROM public.pagos_servicio WHERE productor_id=$1", PRODUCTOR_P2
    )
    assert vence == 10


async def test_ck_0244_suspension_oculta_y_bloquea_edicion(conn):
    await forzar_mora(conn)
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is True
    # productos ocultos del catálogo público
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE anon")
    visibles = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE productor_id=$1", PRODUCTOR_P2
    )
    assert visibles == 0
    # CK-0244: publicación y edición bloqueadas para el vendedor suspendido
    await autenticar(conn, PERFIL_P2)
    await falla(
        conn, "suspendida",
        "INSERT INTO public.productos (productor_id, categoria_id, nombre, slug, precio, stock, "
        "unidad_medida, codigo_producto) VALUES ($1,$2,$3,$4,$5,$6,'kg',$7)",
        PRODUCTOR_P2,
        UUID("13000000-0000-0000-0000-000000000001"),
        "Producto suspendido lote 17",
        "suspendido-lote-17",
        1000,
        5,
        "L17SUS01",
    )
    await falla(
        conn, "suspendida",
        "UPDATE public.productos SET nombre=$1 WHERE id=$2", "Editado suspendido", PRODUCTO_P2,
    )
    # el admin conserva el control de estado sobre el catálogo suspendido
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.productos SET activo=false, motivo_pausa=$1 WHERE id=$2",
        "Pausa administrativa con tienda suspendida lote 17.",
        PRODUCTO_P2,
    )


async def test_ck_0245_se_puede_pagar_estando_suspendido(conn):
    await forzar_mora(conn)
    await autenticar(conn, PERFIL_P2)
    row = await conn.fetchrow("SELECT public.mi_servicio() AS r")
    servicio = json.loads(row["r"])
    assert servicio["estado"] == "vencido"  # suspendido por deuda
    assert servicio["cuota"]["estado"] == "pendiente"  # la cuota sigue consultable
    # CK-0245: permite iniciar pago (transferencia) estando suspendido
    await conn.execute(
        "SELECT public.registrar_transferencia_servicio($1,$2)",
        "REF-LOTE17-SUSP-001",
        "Pago durante suspensión lote 17",
    )
    estado = await conn.fetchval(
        "SELECT estado FROM public.pagos_servicio WHERE referencia=$1", "REF-LOTE17-SUSP-001"
    )
    assert estado == "pendiente_revision"


async def test_transferencia_exige_numero_de_operacion(conn):
    await autenticar(conn, PERFIL_P2)
    await falla(
        conn,
        "número de operación es obligatorio",
        "SELECT public.registrar_transferencia_servicio($1,$2)",
        "   ",
        "Intento sin número de operación",
    )


async def test_ck_0251_reactivacion_tras_pago_confirmado(conn):
    await forzar_mora(conn)
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is True
    # camino Webpay: mark_paid (servicio_repo) marca pagado y limpia la suspensión
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE postgres")
    pago_id = await conn.fetchval(
        "SELECT id FROM public.pagos_servicio WHERE productor_id=$1 AND estado='pendiente' "
        "ORDER BY periodo DESC LIMIT 1",
        PRODUCTOR_P2,
    )
    await conn.execute(
        "UPDATE public.pagos_servicio SET estado='pagado', metodo='webpay', referencia='AUT123', "
        "pagado_en=now(), revisado_en=now() WHERE id=$1",
        pago_id,
    )
    await conn.execute(
        "UPDATE public.productores SET servicio_suspendido=false, servicio_suspendido_en=null WHERE id=$1",
        PRODUCTOR_P2,
    )
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", PRODUCTOR_P2)
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is False
    # los productos vuelven a ser visibles (sin otras restricciones)
    await conn.execute("RESET ROLE")
    await conn.execute("SET LOCAL ROLE anon")
    visibles = await conn.fetchval(
        "SELECT count(*) FROM public.productos WHERE productor_id=$1 AND activo=true", PRODUCTOR_P2
    )
    assert visibles >= 1


async def test_ck_0262_reejecucion_idempotente_de_mora(conn):
    await forzar_mora(conn)
    antes_sanciones = await conn.fetchval("SELECT count(*) FROM public.sanciones")
    antes_pagos = await conn.fetchval(
        "SELECT count(*) FROM public.pagos_servicio WHERE productor_id=$1", PRODUCTOR_P2
    )
    await autenticar(conn, PERFIL_P2)
    for _ in range(3):
        await conn.execute("SELECT public.mi_servicio()")  # sincroniza la mora cada llamada
    await reset(conn)
    assert await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", PRODUCTOR_P2
    ) is True  # mismo estado, sin "recuperarse" ni empeorar
    despues = await conn.fetch("SELECT id, productor_id, tipo, accion, estado FROM public.sanciones ORDER BY id")
    assert len(despues) == antes_sanciones  # sin sanciones nuevas
    # sin cuota duplicada para el mismo período (una obligación por productor y mes)
    por_periodo = await conn.fetchval(
        "SELECT count(*) FROM public.pagos_servicio WHERE productor_id=$1 "
        "AND periodo = date_trunc('month', (now() at time zone 'America/Santiago')::date)",
        PRODUCTOR_P2,
    )
    assert por_periodo == 1
    assert antes_pagos >= 1
