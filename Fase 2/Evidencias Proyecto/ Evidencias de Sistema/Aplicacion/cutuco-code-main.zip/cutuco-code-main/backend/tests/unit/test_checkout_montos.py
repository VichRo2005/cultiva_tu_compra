"""CK-0103/0104/0117: reparto e IVA vigentes, sin sumar el fee al comprador."""

from decimal import Decimal
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from app.services import webpay_service as service


@pytest.mark.asyncio
@pytest.mark.parametrize('subtotal,fee,iva,neto', [
    ('10000', 500, 2565, 15565),
    ('404', 20, 742, 4626),
    ('10', 1, 667, 4176),
    ('9', 0, 667, 4176),
])
async def test_reparto_clp_conserva_total_con_iva(monkeypatch, subtotal, fee, iva, neto):
    region = uuid4()
    conn = AsyncMock()
    conn.fetchval.side_effect = [False, 'COMERCIO-QA']
    monkeypatch.setattr(service.direcciones_repo, 'get_activa_productor',
                        AsyncMock(return_value={'region_id': region}))
    tienda = await service._store(conn, uuid4(), [{'subtotal': Decimal(subtotal)}], region)
    assert tienda['subtotal_productos'] == Decimal(subtotal)
    assert tienda['tarifa_delivery'] == Decimal('3500.00')
    assert tienda['tasa_iva'] == Decimal('0.19')
    assert tienda['monto_iva'] == iva
    assert tienda['total'] == int(subtotal) + 3500 + iva
    assert tienda['fee'] == fee
    assert tienda['detail']['amount'] == neto
    detalle_fee = tienda['fee_detail']
    assert (detalle_fee['amount'] if detalle_fee else 0) == fee
    assert neto + fee == tienda['total']
