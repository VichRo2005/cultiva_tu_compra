"""REG-CLI-017/REG-CONF-001: alta tolerante desde metadata de auth.signUp."""

import json
from uuid import uuid4

COMUNA = "12000000-0000-0000-0000-000000000004"


async def _signup(conn, metadata):
    user_id = uuid4()
    await conn.execute(
        "INSERT INTO auth.users (id, raw_user_meta_data) VALUES ($1, $2::jsonb)",
        user_id,
        json.dumps(metadata),
    )
    return user_id


async def test_alta_cliente_crea_perfil_y_direccion(conn):
    user_id = await _signup(
        conn,
        {
            "nombre": "Ana",
            "apellido": "Pérez",
            "telefono": "+56911112222",
            "tipo_registro": "cliente",
            "region_id": "11000000-0000-0000-0000-000000000001",
            "comuna_id": COMUNA,
            "calle": "Calle Falsa",
            "numero": "123 B",
            "depto_oficina": "Depto 5",
            "referencia": "Portón verde",
        },
    )
    perfil = await conn.fetchrow(
        "SELECT nombre, apellido, telefono, rol FROM public.perfiles WHERE id=$1", user_id
    )
    assert perfil["nombre"] == "Ana"
    assert perfil["telefono"] == "+56911112222"
    assert perfil["rol"] == "cliente"

    direccion = await conn.fetchrow(
        "SELECT calle, numero, depto_oficina, referencia, es_principal, activo "
        "FROM public.direcciones WHERE perfil_id=$1",
        user_id,
    )
    assert direccion["calle"] == "Calle Falsa"
    assert direccion["numero"] == "123 B"
    assert direccion["depto_oficina"] == "Depto 5"
    assert direccion["es_principal"] is True and direccion["activo"] is True

    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.postulaciones_vendedores WHERE perfil_id=$1", user_id
        )
        == 0
    )


async def test_alta_vendedor_crea_borrador_de_postulacion(conn):
    user_id = await _signup(
        conn,
        {
            "nombre": "Beto",
            "apellido": "Soto",
            "telefono": "+56922223333",
            "tipo_registro": "vendedor",
            "comuna_id": COMUNA,
            "calle": "Camino Rural",
            "numero": "S/N",
            "nombre_comercial": "Huerta de Beto",
            "descripcion": "Verduras de la zona",
            "rut_solicitante": "12345678-5",
            "tipo_persona": "natural",
        },
    )
    postulacion = await conn.fetchrow(
        """SELECT estado, nombre_comercial_solicitado, rut_solicitante, tipo_de_persona,
                  documento_identidad, certificado_titularidad_bancaria
        FROM public.postulaciones_vendedores WHERE perfil_id=$1""",
        user_id,
    )
    assert postulacion["estado"] == "borrador"
    assert postulacion["nombre_comercial_solicitado"] == "Huerta de Beto"
    assert postulacion["rut_solicitante"] == "12345678-5"
    assert postulacion["tipo_de_persona"] == "natural"
    # Los documentos se suben después de confirmar/iniciar sesión.
    assert postulacion["documento_identidad"] is None
    assert postulacion["certificado_titularidad_bancaria"] is None


async def test_alta_incompleta_no_rompe_auth(conn):
    user_id = await _signup(
        conn,
        {
            "nombre": "Sin Datos",
            "tipo_registro": "vendedor",
            # sin teléfono, comuna, calle, nombre_comercial ni documentos
        },
    )
    assert await conn.fetchval("SELECT count(*) FROM public.perfiles WHERE id=$1", user_id) == 1
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.direcciones WHERE perfil_id=$1", user_id
        )
        == 0
    )
    assert (
        await conn.fetchval(
            "SELECT count(*) FROM public.postulaciones_vendedores WHERE perfil_id=$1", user_id
        )
        == 0
    )
