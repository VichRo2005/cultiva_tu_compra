import json
import time
from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4

import jwt
import pytest
import pytest_asyncio
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.asymmetric import ec
from fastapi.testclient import TestClient
from httpx import ASGITransport, AsyncClient

from app.core import security
from app.core.config import get_settings
from app.db import session
from app.integrations.email.client import EmailClient
from app.integrations.webpay.client import WebpayClient
from app.services import email_service

CLIENT_ID = UUID("a0000000-0000-0000-0000-000000000002")
# Product 101 (Tomates Roma de Paine) is inactive in current seed.
# Use product 201 (Tomates de Melipilla) from producer 002 (RM) which is active.
PRODUCT_ID = "30000000-0000-0000-0000-000000000201"


@pytest.fixture(autouse=True)
def test_settings(monkeypatch):
    values = {
        "SUPABASE_URL": "https://test.supabase.co",
        "SUPABASE_ANON_KEY": "test-anon",
        "SUPABASE_SERVICE_ROLE_KEY": "test-service",
        "BREVO_API_KEY": "test-brevo",
        "DATABASE_URL": "postgresql://postgres:postgres@localhost:54322/postgres",
        "TRANSBANK_RETURN_URL": "http://localhost:3000/webpay/retorno",
        "TRANSBANK_ENV": "integration",
        "TRANSBANK_COMMERCE_CODE": "597055555535",
        "TRANSBANK_FEE_COMMERCE_CODE": "597055555537",
        "TRANSBANK_MALL_SELLER_COMMERCE_CODE": "597055555536",
        "TRANSBANK_API_KEY": "test-only-not-a-real-key",
        "TRANSBANK_SERVICIO_COMMERCE_CODE": "597055555532",
        "TRANSBANK_SERVICIO_API_KEY": "test-service-only-not-a-real-key",
        "TRANSBANK_SERVICIO_RETURN_URL": "http://localhost:8000/api/servicio/retorno",
        "FRONTEND_URL": "http://localhost:3000",
        "ENVIRONMENT": "test",
        "AUTH_DEV_FALLBACK": "false",
        "SUPABASE_JWKS_URL": "",
        "SRE_BASE_URL": "https://sre.test",
        "SRE_TOKEN_PUBLICO": "token_publico",
        # Clave efímera exclusiva de fixtures revertidos; nunca lee ni cambia .env.
        "BANK_ENCRYPTION_KEY": Fernet.generate_key().decode(),
    }
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    get_settings.cache_clear()
    security._jwks_cache.clear()
    yield get_settings()
    get_settings.cache_clear()
    security._jwks_cache.clear()


@pytest.fixture
def mock_jwt(monkeypatch, test_settings):
    private = ec.generate_private_key(ec.SECP256R1())
    key = json.loads(jwt.algorithms.ECAlgorithm.to_jwk(private.public_key()))
    key.update(kid="test-key", alg="ES256", use="sig")
    monkeypatch.setattr(security, "get_jwks", AsyncMock(return_value={"keys": [key]}))

    def sign(user_id=CLIENT_ID, **overrides):
        claims = {
            "sub": str(user_id),
            "aud": "authenticated",
            "iss": test_settings.issuer,
            "exp": int(time.time()) + 300,
            "email": "cliente@example.com",
        }
        claims.update(overrides)
        return jwt.encode(claims, private, algorithm="ES256", headers={"kid": "test-key"})

    return sign


@pytest.fixture
def headers(mock_jwt):
    return {"Authorization": f"Bearer {mock_jwt()}"}


@pytest.fixture
def mock_transbank(monkeypatch):
    transactions = {}

    def create(buy_order, session_id, details, return_url):
        token = uuid4().hex
        transactions[token] = {
            "buy_order": buy_order,
            "session_id": session_id,
            "details": [
                dict(d, status="AUTHORIZED", response_code=0, authorization_code="123456")
                for d in details
            ],
        }
        return {"token": token, "url": "https://webpay.example.test/pay"}

    create_mock = MagicMock(side_effect=create)
    commit_mock = MagicMock(side_effect=lambda token: transactions[token].copy())
    status_mock = MagicMock(side_effect=lambda token: transactions[token].copy())
    monkeypatch.setattr(WebpayClient, "create", create_mock)
    monkeypatch.setattr(WebpayClient, "commit", commit_mock)
    monkeypatch.setattr(WebpayClient, "status", status_mock)
    return {
        "create": create_mock,
        "commit": commit_mock,
        "status": status_mock,
        "transactions": transactions,
    }


@pytest.fixture
def mock_email(monkeypatch):
    send = AsyncMock(return_value=True)
    monkeypatch.setattr(EmailClient, "send", send)
    return send


@pytest_asyncio.fixture
async def db_pool(test_settings):
    # Supabase local: migrations and seed are managed by supabase db reset.
    # Keep the target fixed so test environment variables cannot redirect writes.
    pool = await session.init_pool()
    try:
        yield pool
    finally:
        await session.close_pool()


@pytest_asyncio.fixture
async def conn(db_pool, monkeypatch):
    async with db_pool.acquire() as connection:
        tx = connection.transaction()
        await tx.start()

        @asynccontextmanager
        async def scope():
            yield connection

        monkeypatch.setattr(email_service, "connection_scope", scope)
        try:
            yield connection
        finally:
            await tx.rollback()


@pytest_asyncio.fixture
async def client(conn, test_settings):
    from app.main import create_app

    application = create_app()

    async def dependency():
        yield conn

    application.dependency_overrides[session.get_connection] = dependency
    async with AsyncClient(
        transport=ASGITransport(app=application), base_url="http://test"
    ) as http:
        yield http


@pytest.fixture
def sync_client(test_settings):
    from app.main import create_app

    return TestClient(create_app())


@pytest_asyncio.fixture
async def checkout_body(conn):
    address = await conn.fetchval(
        """SELECT d.id FROM public.direcciones d JOIN public.comunas c ON c.id=d.comuna_id
        WHERE d.perfil_id=$1 AND d.activo AND c.region_id=(
        SELECT c2.region_id FROM public.productos p
        JOIN public.productores pr ON pr.id=p.productor_id
        JOIN public.direcciones d2 ON d2.perfil_id=pr.perfil_id AND d2.activo
        JOIN public.comunas c2 ON c2.id=d2.comuna_id WHERE p.id=$2)
        ORDER BY d.es_principal DESC LIMIT 1""",
        CLIENT_ID,
        UUID(PRODUCT_ID),
    )
    assert address is not None, "Seed address missing"
    return {"direccion_id": str(address), "items": [{"producto_id": PRODUCT_ID, "cantidad": 2}]}


@pytest_asyncio.fixture
async def checkout(client, headers, checkout_body, mock_transbank, mock_email):
    response = await client.post("/api/webpay/iniciar", json=checkout_body, headers=headers)
    assert response.status_code == 200, response.text
    return response.json()


@pytest_asyncio.fixture
async def paid_checkout(client, checkout, mock_email):
    response = await client.post("/api/webpay/confirmar", json={"token_ws": checkout["token_ws"]})
    assert response.status_code == 200, response.text
    return response.json()["pedidos"][0]
