from fastapi.testclient import TestClient

from app.main import create_app


def test_cors_permite_frontend_local():
    client = TestClient(create_app())
    r = client.options(
        "/datos-bancarios/me",
        headers={
            "Origin": "http://127.0.0.1:5173",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "authorization",
        },
    )
    assert r.status_code == 200
    assert r.headers["access-control-allow-origin"] == "http://127.0.0.1:5173"


def test_cors_permite_localhost():
    client = TestClient(create_app())
    r = client.options(
        "/datos-bancarios/me",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "GET",
        },
    )
    assert r.status_code == 200
