"""CK-0299/0317: diagnostics do not expose email records to public users."""

from unittest.mock import AsyncMock

import pytest
from httpx import ASGITransport, AsyncClient

from app.db.session import get_connection
from app.main import create_app


@pytest.mark.parametrize("role,expected", [("cliente", 403), ("vendedor", 403)])
async def test_diagnostico_correo_exige_admin(mock_jwt, role, expected):
    app = create_app()
    conn = AsyncMock()
    conn.fetchrow.return_value = {"rol": role, "activo": True}
    app.dependency_overrides[get_connection] = lambda: conn
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(
            "/api/webpay/emails", headers={"Authorization": f"Bearer {mock_jwt()}"}
        )
    assert response.status_code == expected
    assert "emails" not in response.json()
    assert response.headers["Cache-Control"] == "no-store"


async def test_diagnostico_correo_anonimo_401():
    app = create_app()
    app.dependency_overrides[get_connection] = lambda: AsyncMock()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/api/webpay/emails")
    assert response.status_code == 401
    assert response.headers["Referrer-Policy"] == "no-referrer"
