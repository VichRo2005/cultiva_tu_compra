"""
Servicio de generación de comprobantes de compra PDF para pedidos.

Utiliza reportlab para producir un documento con el diseño de la plataforma
CuTuCo, apto para descarga y para adjuntar al correo de confirmación de compra.
"""

import io
import logging
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from html import escape
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Flowable,
    HRFlowable,
    Image,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Colores de la plataforma CuTuCo
# ---------------------------------------------------------------------------
PRIMARY = colors.HexColor("#4caf50")
PRIMARY_DARK = colors.HexColor("#2e7d32")
LIGHT = colors.HexColor("#f3f3f5")
BORDER = colors.HexColor("#e6e7e9")
TEXT = colors.HexColor("#1a1a1a")
TEXT_SOFT = colors.HexColor("#4b4c4f")
TEXT_MUTED = colors.HexColor("#64666c")
SUCCESS = colors.HexColor("#2e7d32")

PAGE_WIDTH, PAGE_HEIGHT = letter
MARGEN = 20 * mm

# Isologo de CuTuCo para la cabecera del comprobante (activo local del backend;
# nunca se lee desde una URL: el contenido del pedido no puede inyectar imágenes).
LOGO_RUTA = Path(__file__).resolve().parent.parent / "assets" / "logos" / "Isologo_bg.png"
LOGO_ALTO = 13 * mm


def _pick(datos: Any, *claves: str) -> Any:
    """Devuelve el primer valor presente entre varias claves posibles."""
    if not datos:
        return None
    for clave in claves:
        valor = datos.get(clave)
        if valor not in (None, ""):
            return valor
    return None


def _logo_plataforma() -> Image | None:
    """Carga el isologo local manteniendo la proporción; None si no está disponible."""
    try:
        if not LOGO_RUTA.exists():
            return None
        ancho, alto = ImageReader(str(LOGO_RUTA)).getSize()
        escala = LOGO_ALTO / alto
        return Image(str(LOGO_RUTA), width=ancho * escala, height=LOGO_ALTO)
    except Exception:  # noqa: BLE001 - el comprobante nunca debe romperse por el logo
        logger.warning("No se pudo cargar el isologo de CuTuCo para el PDF", exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Estilos
# ---------------------------------------------------------------------------
def _texto(value: Any) -> str:
    return escape(str(value if value is not None else "—"))


def _clp(value: Any) -> str:
    monto = Decimal(str(value)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return f"${monto:,.0f} CLP".replace(",", ".")


def _estilo_titulo() -> ParagraphStyle:
    return ParagraphStyle(
        "titulo",
        fontName="Helvetica-Bold",
        fontSize=20,
        textColor=PRIMARY_DARK,
        spaceAfter=4,
    )


def _estilo_subtitulo() -> ParagraphStyle:
    return ParagraphStyle(
        "subtitulo",
        fontName="Helvetica",
        fontSize=10,
        textColor=TEXT_MUTED,
        spaceAfter=2,
    )


def _estilo_encabezado() -> ParagraphStyle:
    return ParagraphStyle(
        "encabezado",
        fontName="Helvetica-Bold",
        fontSize=13,
        textColor=TEXT,
        spaceBefore=10,
        spaceAfter=6,
    )


def _estilo_cuerpo() -> ParagraphStyle:
    return ParagraphStyle(
        "cuerpo",
        fontName="Helvetica",
        fontSize=10,
        textColor=TEXT,
        leading=14,
        spaceAfter=4,
    )


def _estilo_celda() -> ParagraphStyle:
    return ParagraphStyle(
        "celda",
        fontName="Helvetica",
        fontSize=9,
        textColor=TEXT,
        leading=12,
    )


def _estilo_celda_bold() -> ParagraphStyle:
    return ParagraphStyle(
        "celda_bold",
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=TEXT,
        leading=12,
    )


def _estilo_celda_derecha() -> ParagraphStyle:
    return ParagraphStyle(
        "celda_derecha",
        fontName="Helvetica",
        fontSize=9,
        textColor=TEXT,
        leading=12,
        alignment=2,  # TA_RIGHT
    )


def _estilo_celda_derecha_bold() -> ParagraphStyle:
    return ParagraphStyle(
        "celda_derecha_bold",
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=TEXT,
        leading=12,
        alignment=2,
    )


def _estilo_pie() -> ParagraphStyle:
    return ParagraphStyle(
        "pie",
        fontName="Helvetica",
        fontSize=8,
        textColor=TEXT_MUTED,
        leading=11,
    )


# ---------------------------------------------------------------------------
# Cabecera de la plataforma
# ---------------------------------------------------------------------------
def _cabecera_plataforma() -> list[Flowable]:
    """Compone la cabecera compacta del comprobante.

    Mantiene la distinción legal: es un respaldo de compra, no reemplaza el
    documento tributario del vendedor. La jerarquía visual replica una boleta:
    marca, tipo de comprobante y separación clara de la información transaccional.
    """
    elementos: list[Flowable] = []
    marca = Paragraph(
        '<font color="#2e7d32" size="18"><b>CuTuCo</b></font><br/>'
        '<font color="#64666c" size="9">Plataforma de Comercio Local</font>',
        _estilo_titulo(),
    )
    tipo = Paragraph(
        '<para alignment="right"><font color="#2e7d32" size="11"><b>COMPROBANTE</b></font><br/>'
        '<font color="#64666c" size="9">RESUMEN DE COMPRA</font></para>',
        _estilo_cuerpo(),
    )
    logo = _logo_plataforma()
    if logo is not None:
        cabecera = Table(
            [[logo, marca, tipo]],
            colWidths=[LOGO_ALTO + 4 * mm, 75 * mm, PAGE_WIDTH - 2 * MARGEN - LOGO_ALTO - 79 * mm],
            hAlign="LEFT",
        )
        cabecera.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("RIGHTPADDING", (0, 0), (0, 0), 6),
                    ("RIGHTPADDING", (1, 0), (1, 0), 4),
                    ("RIGHTPADDING", (2, 0), (2, 0), 0),
                    ("TOPPADDING", (0, 0), (-1, -1), 0),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                ]
            )
        )
        elementos.append(cabecera)
    else:
        cabecera = Table(
            [[marca, tipo]],
            colWidths=[105 * mm, PAGE_WIDTH - 2 * MARGEN - 105 * mm],
            hAlign="LEFT",
        )
        cabecera.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                    ("TOPPADDING", (0, 0), (-1, -1), 0),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                ]
            )
        )
        elementos.append(cabecera)
    elementos.append(Spacer(1, 8))
    elementos.append(HRFlowable(width="100%", thickness=1.5, color=PRIMARY_DARK))
    elementos.append(Spacer(1, 8))
    return elementos


def _pie_pagina(canvas: Any, doc: Any) -> None:
    """Dibuja un pie sobrio en todas las páginas, incluso en comprobantes largos."""
    canvas.saveState()
    y = 11 * mm
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(doc.leftMargin, y + 5 * mm, PAGE_WIDTH - doc.rightMargin, y + 5 * mm)
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(TEXT_MUTED)
    canvas.drawString(doc.leftMargin, y, "CuTuCo - Respaldo de compra")
    canvas.drawRightString(
        PAGE_WIDTH - doc.rightMargin,
        y,
        f"Pagina {canvas.getPageNumber()}",
    )
    canvas.restoreState()


def _direccion_vendedor(productor: Any) -> str:
    """Compone la dirección activa del vendedor (vía, depto, comuna, región)."""
    if not productor:
        return "—"
    calle = str(_pick(productor, "vendedor_calle") or "").strip()
    numero = str(_pick(productor, "vendedor_numero") or "").strip()
    depto = str(_pick(productor, "vendedor_depto", "vendedor_depto_oficina") or "").strip()
    comuna = str(_pick(productor, "vendedor_comuna") or "").strip()
    region = str(_pick(productor, "region_nombre") or "").strip()
    partes: list[str] = []
    via = " ".join(parte for parte in (calle, numero) if parte)
    if via:
        partes.append(via)
    if depto:
        partes.append(f"Depto/Oficina {depto}")
    if comuna:
        partes.append(comuna)
    if region:
        partes.append(region)
    if partes:
        return ", ".join(partes)
    return str(_pick(productor, "direccion") or "—")


# ---------------------------------------------------------------------------
# Generador de PDF
# ---------------------------------------------------------------------------
def generar_pdf_pedido(  # noqa: PLR0913, PLR0915 - contrato y composición secuencial del PDF
    pedido: dict[str, Any],
    cliente: dict[str, Any] | None,
    productor: dict[str, Any] | None,
    direccion: dict[str, Any] | None,
    items: list[dict[str, Any]],
    total: Decimal,
    tarifa_delivery: Decimal,
    tipo_documento: str = "boleta",
    datos_tributarios: dict[str, str] | None = None,
    codigo_comercio: str | None = None,
    codigo_autorizacion: str | None = None,
    fecha_pago: str | None = None,
) -> bytes:
    """
    Genera un comprobante de compra PDF para un pedido en formato carta (Letter),
    con un layout ordenado que evita que el texto se superponga.

    Devuelve los bytes del PDF listos para adjuntar a un correo o descargar.
    """
    buffer = io.BytesIO()
    # Ancho útil dentro de los márgenes (en mm)
    doc_width = PAGE_WIDTH - 2 * MARGEN

    from reportlab.platypus import SimpleDocTemplate

    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=MARGEN,
        rightMargin=MARGEN,
        topMargin=MARGEN,
        bottomMargin=MARGEN + 8 * mm,
        title=f"CuTuCo - Comprobante de compra {pedido.get('codigo_pedido', '')}",
        author="CuTuCo",
    )

    estilos = {
        "titulo": _estilo_titulo(),
        "subtitulo": _estilo_subtitulo(),
        "encabezado": _estilo_encabezado(),
        "cuerpo": _estilo_cuerpo(),
        "celda": _estilo_celda(),
        "celda_bold": _estilo_celda_bold(),
        "celda_derecha": _estilo_celda_derecha(),
        "celda_derecha_bold": _estilo_celda_derecha_bold(),
        "cabecera": ParagraphStyle("cabecera", parent=_estilo_celda_bold(), textColor=colors.white),
    }

    elementos: list[Flowable] = []
    elementos.extend(_cabecera_plataforma())

    # --- Datos del documento ------------------------------------------------
    # Cada celda es un Paragraph para que el texto haga wrap automático
    # y nunca se solape con otra celda.
    datos_doc = [
        [
            Paragraph("<b>Tipo de documento</b>", estilos["celda_bold"]),
            Paragraph(
                _texto(f"{tipo_documento.capitalize()} solicitada al vendedor"),
                estilos["celda"],
            ),
            Paragraph("<b>Número</b>", estilos["celda_bold"]),
            Paragraph(
                _texto(str(pedido.get("codigo_pedido", "—"))),
                estilos["celda"],
            ),
        ],
        [
            Paragraph("<b>Fecha</b>", estilos["celda_bold"]),
            Paragraph(
                _texto(datetime.now(ZoneInfo("America/Santiago")).strftime("%d/%m/%Y %H:%M")),
                estilos["celda"],
            ),
            Paragraph("<b>Estado</b>", estilos["celda_bold"]),
            Paragraph(
                _texto(str(pedido.get("estado", "—")).capitalize()),
                estilos["celda"],
            ),
        ],
    ]
    if codigo_comercio:
        datos_doc.append(
            [
                Paragraph("<b>Código de comercio</b>", estilos["celda_bold"]),
                Paragraph(_texto(codigo_comercio), estilos["celda"]),
                Paragraph("<b>Autorización</b>", estilos["celda_bold"]),
                Paragraph(_texto(codigo_autorizacion or "—"), estilos["celda"]),
            ]
        )
    if fecha_pago:
        datos_doc.append(
            [
                Paragraph("<b>Fecha de pago</b>", estilos["celda_bold"]),
                Paragraph(_texto(fecha_pago), estilos["celda"]),
                Paragraph("<b>Método de pago</b>", estilos["celda_bold"]),
                Paragraph("Webpay (Transbank)", estilos["celda"]),
            ]
        )

    # Anchos en mm: etiqueta, valor, etiqueta, valor (resto)
    tabla_datos = Table(
        datos_doc,
        colWidths=[30 * mm, 45 * mm, 30 * mm, doc_width - 105 * mm],
        hAlign="LEFT",
    )
    tabla_datos.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eaf5ea")),
                ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#eaf5ea")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elementos.append(tabla_datos)
    elementos.append(Spacer(1, 6))

    # --- Datos del comprador ------------------------------------------------
    elementos.append(Paragraph("Datos del comprador", estilos["encabezado"]))
    nombre_cliente = (
        (
            f"{_pick(cliente, 'nombre', 'cliente_nombre') or ''} "
            f"{_pick(cliente, 'apellido', 'cliente_apellido') or ''}"
        ).strip()
        if cliente
        else "—"
    )
    email_cliente = _pick(cliente, "email", "comprador_email") or "—" if cliente else "—"
    datos_comprador = [
        [
            Paragraph("<b>Nombre</b>", estilos["celda_bold"]),
            Paragraph(_texto(nombre_cliente), estilos["celda"]),
        ],
        [
            Paragraph("<b>Correo</b>", estilos["celda_bold"]),
            Paragraph(_texto(email_cliente), estilos["celda"]),
        ],
    ]
    # La dirección de entrega es del comprador: vive en su bloque, no en el del vendedor.
    if direccion and direccion.get("direccion_entrega"):
        datos_comprador.append(
            [
                Paragraph("<b>Dirección de entrega</b>", estilos["celda_bold"]),
                Paragraph(_texto(direccion.get("direccion_entrega")), estilos["celda"]),
            ]
        )
    tabla_comprador = Table(
        datos_comprador,
        colWidths=[35 * mm, doc_width - 35 * mm],
        hAlign="LEFT",
    )
    tabla_comprador.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
                ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elementos.append(tabla_comprador)
    elementos.append(Spacer(1, 6))

    # --- Datos del vendedor -------------------------------------------------
    # Completo: comercio, RUT oficial, correo, dirección activa y región del
    # productor (vienen de get_email_context); antes sólo se mostraba el nombre
    # comercial y el resto quedaba vacío.
    elementos.append(Paragraph("Datos del vendedor", estilos["encabezado"]))
    nombre_vendedor = _pick(productor, "nombre_comercial") or "—" if productor else "—"
    rut_vendedor = _pick(productor, "rut_oficial", "rut") or "—" if productor else "—"
    email_vendedor = _pick(productor, "productor_email", "email") or "—" if productor else "—"
    region_vendedor = _pick(productor, "region_nombre") or "—" if productor else "—"
    datos_vendedor = [
        [
            Paragraph("<b>Comercio</b>", estilos["celda_bold"]),
            Paragraph(_texto(nombre_vendedor), estilos["celda"]),
        ],
        [
            Paragraph("<b>RUT</b>", estilos["celda_bold"]),
            Paragraph(_texto(rut_vendedor), estilos["celda"]),
        ],
        [
            Paragraph("<b>Correo</b>", estilos["celda_bold"]),
            Paragraph(_texto(email_vendedor), estilos["celda"]),
        ],
        [
            Paragraph("<b>Dirección</b>", estilos["celda_bold"]),
            Paragraph(_texto(_direccion_vendedor(productor)), estilos["celda"]),
        ],
        [
            Paragraph("<b>Región</b>", estilos["celda_bold"]),
            Paragraph(_texto(region_vendedor), estilos["celda"]),
        ],
    ]
    tabla_vendedor = Table(
        datos_vendedor,
        colWidths=[35 * mm, doc_width - 35 * mm],
        hAlign="LEFT",
    )
    tabla_vendedor.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
                ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elementos.append(tabla_vendedor)
    elementos.append(Spacer(1, 6))

    # --- Tabla de ítems -----------------------------------------------------
    elementos.append(Paragraph("Detalle de productos", estilos["encabezado"]))

    cabecera_items = [
        Paragraph("Producto", estilos["cabecera"]),
        Paragraph("Código", estilos["cabecera"]),
        Paragraph("Cant.", estilos["cabecera"]),
        Paragraph("Precio unit.", estilos["cabecera"]),
        Paragraph("Subtotal", estilos["cabecera"]),
    ]
    filas_items = [cabecera_items]
    for item in items:
        filas_items.append(
            [
                Paragraph(_texto(str(item.get("producto_nombre", "—"))), estilos["celda"]),
                Paragraph(
                    _texto(str(item.get("codigo_producto", "—"))),
                    estilos["celda"],
                ),
                Paragraph(_texto(str(item.get("cantidad", 0)).replace(".", ",")), estilos["celda"]),
                Paragraph(
                    _texto(_clp(item.get("precio_unitario", 0))),
                    estilos["celda_derecha"],
                ),
                Paragraph(
                    _texto(_clp(item.get("subtotal", 0))),
                    estilos["celda_derecha"],
                ),
            ]
        )

    tabla_items = Table(
        filas_items,
        colWidths=[
            doc_width * 0.36,
            doc_width * 0.12,
            doc_width * 0.08,
            doc_width * 0.22,
            doc_width * 0.22,
        ],
        repeatRows=1,
        hAlign="LEFT",
    )
    estilo_tabla_items: list[Any] = [
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY_DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("ALIGN", (2, 0), (2, -1), "CENTER"),
        ("ALIGN", (3, 0), (-1, -1), "RIGHT"),
    ]
    tabla_items.setStyle(TableStyle(estilo_tabla_items))
    elementos.append(tabla_items)
    elementos.append(Spacer(1, 6))

    # --- Totales ------------------------------------------------------------
    totales_data = [
        [
            Paragraph("<b>Subtotal productos</b>", estilos["celda_bold"]),
            Paragraph(_texto(_clp(total - tarifa_delivery)), estilos["celda_derecha"]),
        ],
        [
            Paragraph("<b>Despacho</b>", estilos["celda_bold"]),
            Paragraph(_texto(_clp(tarifa_delivery)), estilos["celda_derecha"]),
        ],
        [
            Paragraph("<b>TOTAL</b>", estilos["celda_derecha_bold"]),
            Paragraph(_texto(_clp(total)), estilos["celda_derecha_bold"]),
        ],
    ]
    tabla_totales = Table(
        totales_data,
        colWidths=[48 * mm, 42 * mm],
        hAlign="RIGHT",
    )
    tabla_totales.setStyle(
        TableStyle(
            [
                ("LINEABOVE", (0, 0), (-1, 0), 0.5, BORDER),
                ("LINEBELOW", (0, 1), (-1, 1), 0.5, BORDER),
                ("BACKGROUND", (0, -1), (-1, -1), PRIMARY_DARK),
                ("TEXTCOLOR", (0, -1), (-1, -1), colors.white),
                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
                ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    elementos.append(tabla_totales)
    elementos.append(Spacer(1, 16))

    # --- Datos tributarios (factura) ---------------------------------------
    if tipo_documento == "factura" and datos_tributarios:
        elementos.append(Paragraph("Datos tributarios", estilos["encabezado"]))
        filas_trib = [
            [
                Paragraph("<b>RUT Empresa</b>", estilos["celda_bold"]),
                Paragraph(_texto(datos_tributarios.get("rut_empresa", "—")), estilos["celda"]),
            ],
            [
                Paragraph("<b>Razón Social</b>", estilos["celda_bold"]),
                Paragraph(_texto(datos_tributarios.get("razon_social", "—")), estilos["celda"]),
            ],
            [
                Paragraph("<b>Giro</b>", estilos["celda_bold"]),
                Paragraph(_texto(datos_tributarios.get("giro", "—")), estilos["celda"]),
            ],
            [
                Paragraph("<b>Dirección Tributaria</b>", estilos["celda_bold"]),
                Paragraph(
                    _texto(datos_tributarios.get("direccion_tributaria", "—")), estilos["celda"]
                ),
            ],
        ]
        tabla_trib = Table(filas_trib, colWidths=[35 * mm, doc_width - 35 * mm], hAlign="LEFT")
        tabla_trib.setStyle(
            TableStyle(
                [
                    ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
                    ("BACKGROUND", (0, 0), (0, -1), LIGHT),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ]
            )
        )
        elementos.append(tabla_trib)
        elementos.append(Spacer(1, 6))

    # --- Pie de página ------------------------------------------------------
    elementos.append(Spacer(1, 8))
    elementos.append(HRFlowable(width="100%", thickness=0.5, color=BORDER))
    elementos.append(Spacer(1, 8))
    elementos.append(
        Paragraph(
            "CuTuCo — Plataforma de Comercio Local<br/>"
            "Este comprobante es generado por la plataforma y tiene carácter "
            "de respaldo de compra.<br/>"
            "No es una boleta ni una factura electrónica. "
            "El documento tributario lo emite el vendedor.<br/>"
            "Para consultas, contáctanos a cutucosoporte@gmail.com",
            _estilo_pie(),
        )
    )

    doc.build(elementos, onFirstPage=_pie_pagina, onLaterPages=_pie_pagina)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
