"""Cifrado simétrico (Fernet) para datos sensibles en reposo (números de cuenta).

La clave sale de settings.BANK_ENCRYPTION_KEY (Fernet URL-safe base64 de 32 bytes).
"""

import hashlib
import hmac

from cryptography.fernet import Fernet

from app.core.config import get_settings


def _fernet() -> Fernet:
    return Fernet(get_settings().BANK_ENCRYPTION_KEY.encode("utf-8"))


def encrypt_text(value: str) -> bytes:
    return _fernet().encrypt(value.encode("utf-8"))


def decrypt_text(data: bytes | memoryview) -> str:
    return _fernet().decrypt(bytes(data)).decode("utf-8")


def hash_account(value: str) -> bytes:
    """HMAC-SHA256 determinista para detectar cuentas duplicadas (HAL-REG-013).

    No es un hash de contraseña: la clave es BANK_ENCRYPTION_KEY y el resultado
    sólo sirve para comparar dentro de la base, nunca para reconstruir el número.
    """
    key = get_settings().BANK_ENCRYPTION_KEY.encode("utf-8")
    return hmac.new(key, value.encode("utf-8"), hashlib.sha256).digest()


def mask_account(numero_cuenta: str) -> str:
    digits = "".join(ch for ch in numero_cuenta if ch.isdigit())
    return f"****{digits[-4:]}" if digits else "****"
