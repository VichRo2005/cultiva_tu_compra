from typing import Any

from transbank.common.integration_type import IntegrationType
from transbank.common.options import WebpayOptions
from transbank.webpay.webpay_plus.mall_transaction import MallTransaction
from transbank.webpay.webpay_plus.request import MallTransactionCreateDetails

from app.core.config import get_settings
from app.core.exceptions import WebpayError


class WebpayClient:
    def __init__(self) -> None:
        settings = get_settings()
        environment = (
            IntegrationType.LIVE if settings.TRANSBANK_ENV == "production" else IntegrationType.TEST
        )
        self.tx = MallTransaction(
            WebpayOptions(settings.TRANSBANK_COMMERCE_CODE, settings.TRANSBANK_API_KEY, environment)
        )

    def create(
        self, buy_order: str, session_id: str, details: list[dict[str, Any]], return_url: str
    ) -> dict[str, Any]:
        if not details or len({d["buy_order"] for d in details}) != len(details):
            raise WebpayError("Mall requiere órdenes de detalle únicas", status_code=400)
        try:
            first, *others = details
            mall_details = MallTransactionCreateDetails(**first)
            for detail in others:
                mall_details.add(**detail)
            result: dict[str, Any] = self.tx.create(buy_order, session_id, return_url, mall_details)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay al crear transacción", status_code=502) from exc
        if not result.get("token") or not result.get("url"):
            raise WebpayError("Respuesta inválida de Webpay al crear", status_code=502)
        return result

    def commit(self, token_ws: str) -> dict[str, Any]:
        try:
            result: dict[str, Any] = self.tx.commit(token_ws)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay al confirmar transacción", status_code=502) from exc
        return result

    def status(self, token_ws: str) -> dict[str, Any]:
        # Recover an authorization if commit succeeded remotely but its response was lost.
        try:
            result: dict[str, Any] = self.tx.status(token_ws)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay al consultar estado", status_code=502) from exc
        return result
