"""Cliente para la API pública SRE (https://sre.cl).

Contrato vigente (HAL-CLI-028):
    GET /api/company_info?token=<token_publico>&rut=<rut>&actualizado=False

El token público no es un secreto, pero nunca se devuelve al cliente ni se
registra en logs. Cualquier fallo del proveedor se traduce a SreError y el
router responde con un error funcional en español (nunca un 404 técnico de SRE).

La respuesta trae la razón social y, cuando el SII la publica, la glosa de
giro. Cuando NO la publica, el proveedor entrega las actividades económicas en
`actecos` (códigos de seis dígitos del SII) y el giro se resuelve con la tabla
local de `app.integrations.sre.actecos` (CK-0487).
"""

import re
from typing import Any

import httpx

from app.core.config import get_settings
from app.integrations.sre.actecos import ACTECOS_GIROS


class SreError(Exception):
    """Fallo al consultar el proveedor SRE (red, timeout, 5xx, JSON inválido)."""


class SreConfigError(SreError):
    """Falta configuración local de SRE (token público)."""


def _codigos_actecos(valor: Any) -> list[str]:
    """Normaliza el campo `actecos` de SRE a códigos de seis dígitos.

    El contrato documentado es una lista de cadenas (`["620200", "721000"]`),
    pero se aceptan también enteros (un código como `11101` perdió el cero
    inicial) y objetos con la glosa ya resuelta, por si el proveedor cambia de
    formato sin aviso.
    """
    if valor is None:
        return []
    entradas = valor if isinstance(valor, list) else [valor]
    codigos: list[str] = []
    for entrada in entradas:
        bruto = entrada
        if isinstance(entrada, dict):
            bruto = entrada.get("codigo") or entrada.get("code") or entrada.get("acteco")
        digitos = re.sub(r"\D", "", str(bruto or ""))
        if not digitos or len(digitos) > 6:
            continue
        codigo = digitos.zfill(6)
        if codigo not in codigos:
            codigos.append(codigo)
    return codigos


def giro_desde_actecos(actecos: Any) -> str:
    """Glosa SII del primer código de actividad conocido (actividad principal).

    Devuelve "" cuando el proveedor no envía actividades o cuando ningún código
    está en la tabla: en ese caso el autocompletado deja el giro vacío y el
    comprador lo escribe a mano, igual que antes de este mapeo.
    """
    for codigo in _codigos_actecos(actecos):
        glosa = (ACTECOS_GIROS.get(codigo) or "").strip()
        if glosa:
            return glosa
    return ""


def _extraer(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    if payload.get("result") is False or payload.get("error"):
        return None
    razon = (
        payload.get("razon_social")
        or payload.get("razonSocial")
        or payload.get("nombre")
    )
    if not razon:
        return None
    actecos = _codigos_actecos(
        payload.get("actecos") or payload.get("actividades") or payload.get("actividad_economica")
    )
    # La glosa publicada por el SII manda; `actecos` es el respaldo local.
    giro = str(
        payload.get("glosa_giro") or payload.get("giro") or payload.get("giro_comercial") or ""
    ).strip()
    if not giro:
        giro = giro_desde_actecos(actecos)
    return {"razon_social": str(razon).strip(), "giro": giro, "actecos": actecos}


async def get_empresa(rut: str) -> dict[str, str] | None:
    """Consulta la empresa por RUT normalizado.

    Devuelve None cuando la empresa no existe. Lanza SreConfigError si falta
    SRE_TOKEN_PUBLICO y SreError ante cualquier fallo del proveedor.
    """
    settings = get_settings()
    base = settings.SRE_BASE_URL.rstrip("/")
    token = (settings.SRE_TOKEN_PUBLICO or "").strip()
    if not token:
        raise SreConfigError("SRE_TOKEN_PUBLICO no está configurado")

    try:
        async with httpx.AsyncClient(timeout=settings.SRE_TIMEOUT_SEGUNDOS) as client:
            response = await client.get(
                f"{base}/api/company_info",
                params={
                    "token": token,
                    "rut": rut,
                    "actualizado": "False",
                },
            )
    except httpx.HTTPError as exc:
        raise SreError("Proveedor SRE no disponible") from exc

    if response.status_code == 404:
        return None
    if response.status_code == 429:
        raise SreError("SRE limitó temporalmente las consultas")
    if response.status_code != 200:
        raise SreError(f"SRE respondió {response.status_code}")

    try:
        datos = _extraer(response.json())
    except ValueError as exc:
        raise SreError("Respuesta SRE inválida") from exc
    return datos
