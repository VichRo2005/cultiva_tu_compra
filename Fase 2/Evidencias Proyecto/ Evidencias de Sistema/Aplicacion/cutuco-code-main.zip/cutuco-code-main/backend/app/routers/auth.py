"""Operaciones públicas de autenticación que usan el transportador Brevo."""

import logging

import httpx
from fastapi import APIRouter, HTTPException

from app.core.config import get_settings
from app.schemas.auth import PasswordRecoveryRequest
from app.services.email_service import enviar_correo_recuperacion_contrasena

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/auth", tags=["autenticación"])


async def _enviar_recuperacion(email: str, response: httpx.Response) -> None:
    """Valida la respuesta de GoTrue y delega el mensaje al proveedor Brevo."""
    action_link = response.json().get("action_link")
    if not isinstance(action_link, str) or not action_link.startswith(("https://", "http://")):
        raise ValueError("Supabase no devolvió un enlace de recuperación válido")
    enviado = await enviar_correo_recuperacion_contrasena(email, action_link)
    if not enviado:
        raise RuntimeError("Brevo no aceptó el correo de recuperación")


@router.post("/password-recovery", status_code=204)
async def password_recovery(body: PasswordRecoveryRequest) -> None:
    """Genera un enlace GoTrue y lo envía mediante Brevo sin enumerar cuentas."""
    settings = get_settings()
    redirect_to = f"{settings.FRONTEND_URL.rstrip('/')}/recuperar-clave?recuperacion=1"
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            response = await client.post(
                f"{settings.SUPABASE_URL.rstrip('/')}/auth/v1/admin/generate_link",
                headers={
                    "apikey": settings.SUPABASE_SERVICE_ROLE_KEY,
                    "Authorization": f"Bearer {settings.SUPABASE_SERVICE_ROLE_KEY}",
                    "Content-Type": "application/json",
                },
                json={"type": "recovery", "email": str(body.email), "redirect_to": redirect_to},
            )
        # Para una cuenta inexistente se conserva exactamente la respuesta
        # genérica que da Supabase: no se revela si la dirección está registrada.
        if response.status_code in {400, 404, 422}:
            return
        response.raise_for_status()
        await _enviar_recuperacion(body.email, response)
    except (httpx.TimeoutException, httpx.TransportError):
        logger.exception("No se pudo contactar el servicio de recuperación")
        raise HTTPException(503, "No se pudo enviar el enlace. Intenta nuevamente.") from None
    except httpx.HTTPStatusError:
        logger.exception("Supabase rechazó la recuperación de contraseña")
        raise HTTPException(503, "No se pudo enviar el enlace. Intenta nuevamente.") from None
    except Exception:
        logger.exception("No se pudo enviar recuperación por Brevo")
        raise HTTPException(503, "No se pudo enviar el enlace. Intenta nuevamente.") from None
