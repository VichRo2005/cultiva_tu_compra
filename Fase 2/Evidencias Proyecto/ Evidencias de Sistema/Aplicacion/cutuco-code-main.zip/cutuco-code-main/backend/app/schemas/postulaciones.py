from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ESTADO_RESOLUCION = Literal["aprobada", "rechazada"]
MIN_OBSERVACIONES = 10
MAX_OBSERVACIONES = 2500


class ResolverPostulacionRequest(BaseModel):
    """Decisión administrativa sin datos de credenciales de Transbank.

    El código Mall no pertenece al contrato del navegador: lo selecciona el
    backend desde la configuración privada al aprobar.
    """

    model_config = ConfigDict(extra="forbid")

    estado: ESTADO_RESOLUCION
    observaciones: str | None = Field(default=None, max_length=MAX_OBSERVACIONES)

    @field_validator("observaciones")
    @classmethod
    def _limpiar_observaciones(cls, value: str | None) -> str | None:
        return value.strip() if value and value.strip() else None

    @model_validator(mode="after")
    def _validar_observaciones(self) -> "ResolverPostulacionRequest":
        if self.observaciones and len(self.observaciones) < MIN_OBSERVACIONES:
            raise ValueError(
                f"Las observaciones deben tener entre {MIN_OBSERVACIONES} y "
                f"{MAX_OBSERVACIONES} caracteres"
            )
        return self


class PostulacionResueltaResponse(BaseModel):
    id: UUID
    estado: ESTADO_RESOLUCION
    observaciones_admin: str | None
    codigo_comercio_mall: str | None
    revisado_en: datetime | None
