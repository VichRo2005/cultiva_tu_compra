from decimal import Decimal
from typing import Any, Literal
from uuid import UUID


async def create_pedido(  # noqa: PLR0913, PLR0917 - explicit SQL snapshot fields
    conn: Any,
    codigo: str,
    cliente_id: UUID,
    productor_id: UUID,
    region_id: UUID,
    comuna_id: UUID,
    direccion: str,
    tarifa: Decimal,
    fee_porcentaje: Decimal,
    nombre_destinatario: str,
    telefono_destinatario: str,
    referencia_entrega: str | None = None,
    checkout_id: UUID | None = None,
    documento_tributario: str = '{"tipo":"boleta","rut":"66666666-6"}',
    subtotal_productos: Decimal = Decimal("0"),
    tasa_iva: Decimal = Decimal("0"),
    monto_iva: Decimal = Decimal("0"),
) -> Any:
    total = subtotal_productos + tarifa + monto_iva
    monto_fee_plataforma = round(subtotal_productos * fee_porcentaje, 2)
    return await conn.fetchrow(
        """INSERT INTO public.pedidos
        (codigo_pedido, cliente_id, productor_id, region_entrega_id, comuna_entrega_id,
         direccion_entrega, tarifa_delivery, porcentaje_fee_plataforma,
         nombre_destinatario, telefono_destinatario, referencia_entrega,
         subtotal_productos, tasa_iva, monto_iva, monto_fee_plataforma, total,
         checkout_id, documento_tributario)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18::jsonb)
        RETURNING *""",
        codigo,
        cliente_id,
        productor_id,
        region_id,
        comuna_id,
        direccion,
        tarifa,
        fee_porcentaje,
        nombre_destinatario,
        telefono_destinatario,
        referencia_entrega,
        subtotal_productos,
        tasa_iva,
        monto_iva,
        monto_fee_plataforma,
        total,
        checkout_id,
        documento_tributario,
    )


async def update_estado(conn: Any, pedido_id: UUID, nuevo: str) -> Any:
    await conn.execute("UPDATE public.pedidos SET estado=$2 WHERE id=$1", pedido_id, nuevo)
    # Read back after shipment triggers.
    return await get_by_id(conn, pedido_id)


async def update_correo_enviado(
    conn: Any, pedido_id: UUID, tipo: Literal["comprador", "productor"]
) -> Any:
    column = {
        "comprador": "correo_comprador_enviado_en",
        "productor": "correo_productor_enviado_en",
    }[tipo]
    return await conn.fetchrow(
        f"UPDATE public.pedidos SET {column}=now() WHERE id=$1 RETURNING *", pedido_id
    )


async def update_correo_omitido(
    conn: Any, pedido_id: UUID, tipo: Literal["comprador", "productor"]
) -> Any:
    column = {
        "comprador": "correo_comprador_omitido_en",
        "productor": "correo_productor_omitido_en",
    }[tipo]
    return await conn.fetchrow(
        f"UPDATE public.pedidos SET {column}=now() WHERE id=$1 RETURNING *", pedido_id
    )


async def get_by_id(conn: Any, pedido_id: UUID) -> Any:
    return await conn.fetchrow("SELECT * FROM public.pedidos WHERE id=$1", pedido_id)


async def get_by_cliente(conn: Any, cliente_id: UUID) -> Any:
    return await conn.fetch(
        "SELECT * FROM public.pedidos WHERE cliente_id=$1 ORDER BY creado_en DESC", cliente_id
    )


async def get_email_context(conn: Any, pedido_id: UUID) -> Any:
    # Además del contexto de correo, trae los datos del vendedor que el
    # comprobante de compra PDF necesita (RUT oficial, región y dirección
    # activa del productor) para que la sección "Datos del vendedor" no
    # aparezca vacía.
    return await conn.fetchrow(
        """SELECT p.*, comprador.email AS comprador_email, vendedor.email AS productor_email,
        pr.nombre_comercial, pr.rut_oficial, pr.perfil_id AS productor_perfil_id,
        pf.nombre AS cliente_nombre, pf.apellido AS cliente_apellido,
        rg.nombre AS region_nombre,
        d.calle AS vendedor_calle, d.numero AS vendedor_numero, d.depto_oficina AS vendedor_depto,
        c.nombre AS vendedor_comuna
        FROM public.pedidos p JOIN public.productores pr ON pr.id=p.productor_id
        JOIN public.perfiles pf ON pf.id=p.cliente_id
        JOIN auth.users comprador ON comprador.id=p.cliente_id
        JOIN auth.users vendedor ON vendedor.id=pr.perfil_id
        LEFT JOIN public.regiones rg ON rg.id=pr.region_id
        LEFT JOIN LATERAL (
          SELECT d.* FROM public.direcciones d
          WHERE d.perfil_id=pr.perfil_id AND d.activo
          ORDER BY d.es_principal DESC, d.creado_en ASC LIMIT 1
        ) d ON true
        LEFT JOIN public.comunas c ON c.id=d.comuna_id
        WHERE p.id=$1""",
        pedido_id,
    )
