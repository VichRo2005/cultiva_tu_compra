"""Lógica de datos bancarios: cifrado Fernet, hash de duplicados y presentación.

Reglas HAL-REG-012/013/014:
   * número numérico de 7 a 12 dígitos, conservado como texto;
  * huella HMAC determinista para que PostgreSQL detecte duplicados
    (banco + tipo + número normalizado + RUT normalizado del titular);
   * para postulantes, el titular/RUT deben coincidir con la postulación.

El número de cuenta jamás se registra en logs. Sólo se descifra en las rutas
autenticadas del dueño y del administrador, para que ambos puedan revisar los
datos previamente ingresados sin obligar al vendedor a reescribirlos.
"""

import re
import unicodedata
from collections.abc import Mapping
from typing import Any
from uuid import UUID

from fastapi import HTTPException

from app.core.encryption import decrypt_text, encrypt_text, hash_account, mask_account
from app.repositories import datos_bancarios_repo as repo
from app.schemas.datos_bancarios import (
    DatosBancariosCreate,
    DatosBancariosResponse,
    DatosBancariosUpdate,
    validate_numero_cuenta,
)

POSTULACION_COLUMNS = (
    "estado, rut_solicitante, tipo_de_persona, nombre_comercial_solicitado, "
    "certificado_titularidad_bancaria"
)


def _normalizar_nombre(value: str | None) -> tuple[str, ...]:
    """Minúsculas, sin tildes y en conjunto de palabras (orden indiferente)."""
    texto = unicodedata.normalize("NFKD", (value or "").lower())
    texto = "".join(ch for ch in texto if not unicodedata.combining(ch))
    return tuple(sorted(set(re.findall(r"[a-z0-9]+", texto))))


def validar_titularidad(
    perfil: Mapping[str, Any] | None,
    postulacion: Mapping[str, Any] | None,
    datos: Mapping[str, Any],
) -> None:
    """Prohíbe cuentas de terceros (HAL-REG-014).

    Lanza HTTPException 422 con un mensaje funcional. Si no hay postulación o
    todavía no declaró tipo de persona, no inventa una regla: deja el control
    para la revisión administrativa.
    """
    if not postulacion or not postulacion.get("tipo_de_persona"):
        return

    tipo = postulacion["tipo_de_persona"]
    rut_postulante = (postulacion.get("rut_solicitante") or "").upper()
    rut_titular = (datos.get("rut_titular") or "").upper()
    titular = datos.get("titular_cuenta") or ""

    if not rut_postulante:
        return

    if tipo == "natural":
        if rut_titular != rut_postulante:
            raise HTTPException(
                422,
                "La cuenta debe estar a nombre del postulante: el RUT del titular no coincide.",
            )
        nombre_postulante = " ".join(
            filter(None, [(perfil or {}).get("nombre"), (perfil or {}).get("apellido")])
        )
        if _normalizar_nombre(nombre_postulante) != _normalizar_nombre(titular):
            raise HTTPException(
                422,
                "La cuenta debe estar a nombre del postulante: el titular no coincide "
                "con tu nombre completo.",
            )
        return

    if tipo == "juridica":
        if rut_titular != rut_postulante:
            raise HTTPException(
                422,
                "La cuenta debe estar a nombre de la empresa: el RUT del titular no "
                "coincide con el RUT de la empresa postulante.",
            )
        if _normalizar_nombre(titular) != _normalizar_nombre(
            postulacion.get("nombre_comercial_solicitado")
        ):
            raise HTTPException(
                422,
                "La cuenta debe estar a nombre de la empresa postulante: el titular no "
                "coincide con la razón social registrada.",
            )
        if (
            postulacion.get("estado") == "aprobada"
            and not postulacion.get("certificado_titularidad_bancaria")
        ):
            raise HTTPException(
                422,
                "Falta el certificado de titularidad bancaria de la empresa.",
            )


async def _contexto_titularidad(conn: Any, perfil_id: UUID) -> tuple[Any, Any]:
    perfil = await conn.fetchrow(
        "SELECT id, nombre, apellido FROM public.perfiles WHERE id=$1", perfil_id
    )
    postulacion = await conn.fetchrow(
        f"""SELECT {POSTULACION_COLUMNS}
        FROM public.postulaciones_vendedores
        WHERE perfil_id=$1
        ORDER BY (estado='aprobada') DESC, creado_en DESC
        LIMIT 1""",
        perfil_id,
    )
    return perfil, postulacion


def _numero_digitos(numero: str) -> str:
    numero = (numero or "").strip()
    if not numero.isascii() or not numero.isdigit():
        raise HTTPException(422, "El número de cuenta debe contener solo dígitos")
    return numero


def to_response(row: Any) -> DatosBancariosResponse:
    numero = decrypt_text(row["numero_cuenta_cifrado"])
    return DatosBancariosResponse(
        id=row["id"],
        perfil_id=row["perfil_id"],
        banco=row["banco"],
        tipo_cuenta=row["tipo_cuenta"],
        numero_cuenta=numero,
        numero_cuenta_enmascarado=mask_account(numero),
        titular_cuenta=row["titular_cuenta"],
        rut_titular=row["rut_titular"],
        activo=row["activo"],
        creado_en=row["creado_en"],
        actualizado_en=row["actualizado_en"],
    )


async def listar_propias(conn: Any, perfil_id: UUID) -> list[DatosBancariosResponse]:
    rows = await repo.list_by_perfil(conn, perfil_id)
    return [to_response(row) for row in rows]


async def crear_o_reemplazar(
    conn: Any, perfil_id: UUID, body: DatosBancariosCreate
) -> DatosBancariosResponse:
    numero = _numero_digitos(body.numero_cuenta)
    validate_numero_cuenta(numero, body.tipo_cuenta)
    perfil, postulacion = await _contexto_titularidad(conn, perfil_id)
    validar_titularidad(
        perfil,
        postulacion,
        {"rut_titular": body.rut_titular, "titular_cuenta": body.titular_cuenta},
    )

    async with conn.transaction():
        # La GUC hace que el trigger de PostgreSQL aplique también la regla de
        # terceros dentro de la misma transacción, no sólo en Python.
        await conn.execute(
            "SELECT set_config('cutuco.validar_titular_bancario', 'true', true)"
        )
        await repo.desactivar_activas(conn, perfil_id)
        row = await repo.insert(
            conn,
            perfil_id,
            banco=body.banco,
            tipo_cuenta=body.tipo_cuenta,
            numero_cuenta_cifrado=encrypt_text(numero),
            numero_cuenta_hash=hash_account(numero),
            numero_cuenta_digitos=len(numero),
            titular_cuenta=body.titular_cuenta,
            rut_titular=body.rut_titular,
        )
    return to_response(row)


async def actualizar(
    conn: Any, dato_id: UUID, user: dict[str, Any], body: DatosBancariosUpdate
) -> DatosBancariosResponse:
    async with conn.transaction():
        row = await repo.get_by_id(conn, dato_id)
        if row is None:
            raise HTTPException(404, "Datos bancarios no encontrados")
        if row["perfil_id"] != user["id"] and user["role"] != "admin":
            raise HTTPException(403, "No puedes modificar estos datos bancarios")

        perfil, postulacion = await _contexto_titularidad(conn, row["perfil_id"])
        validar_titularidad(
            perfil,
            postulacion,
            {
                "rut_titular": body.rut_titular or row["rut_titular"],
                "titular_cuenta": body.titular_cuenta or row["titular_cuenta"],
            },
        )

        fields: dict[str, Any] = {}
        for name in ("banco", "tipo_cuenta", "titular_cuenta", "rut_titular"):
            value = getattr(body, name)
            if value is not None:
                fields[name] = value
        if body.numero_cuenta is not None:
            numero = _numero_digitos(body.numero_cuenta)
            validate_numero_cuenta(numero, body.tipo_cuenta or row["tipo_cuenta"])
            fields["numero_cuenta_cifrado"] = encrypt_text(numero)
            fields["numero_cuenta_hash"] = hash_account(numero)
            fields["numero_cuenta_digitos"] = len(numero)

        if not fields:
            return to_response(row)

        await conn.execute(
            "SELECT set_config('cutuco.validar_titular_bancario', 'true', true)"
        )
        updated = await repo.update_fields(conn, dato_id, fields)
        return to_response(updated)


async def admin_por_perfil(conn: Any, perfil_id: UUID) -> list[DatosBancariosResponse]:
    rows = await repo.list_by_perfil(conn, perfil_id)
    return [to_response(row) for row in rows]
