from typing import Any
from uuid import UUID


async def bulk_create(conn: Any, pedido_id: UUID, items: list[dict[str, Any]]) -> list[Any]:
    rows = []
    for item in items:
        rows.append(
            await conn.fetchrow(
                """INSERT INTO public.detalles_pedido
            (pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal,
             codigo_producto, unidad)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *""",
                pedido_id,
                item["producto_id"],
                item["producto_nombre"],
                item["precio_unitario"],
                item["cantidad"],
                item["subtotal"],
                item.get("codigo_producto"),
                item.get("unidad"),
            )
        )
    return rows


async def get_by_pedido(conn: Any, pedido_id: UUID) -> Any:
    return await conn.fetch(
        "SELECT * FROM public.detalles_pedido WHERE pedido_id=$1 ORDER BY id", pedido_id
    )
