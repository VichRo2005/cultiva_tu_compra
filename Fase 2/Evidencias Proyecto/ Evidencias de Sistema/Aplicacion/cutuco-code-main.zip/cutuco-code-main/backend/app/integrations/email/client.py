import asyncio
import base64
import json
import logging
import os
import re
import smtplib
import time
from datetime import UTC, datetime
from email.message import EmailMessage
from email.utils import formataddr
from pathlib import Path
from typing import Any
from uuid import NAMESPACE_URL, uuid5

import httpx
from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

logger = logging.getLogger(__name__)

BREVO_API_URL = "https://api.brevo.com/v3/smtp/email"

# CK-0286 (ERS): el envío de correo debe aceptar en menos de 10 s. Cada intento
# se acota a 8 s y el PRESUPUESTO TOTAL cubre los tres reintentos y su espera:
# 3 x 8 s encadenados romperían el requisito (24 s), así que el plazo total
# manda sobre el de cada intento y sobre el respaldo SMTP.
EMAIL_HTTP_TIMEOUT_SEGUNDOS = 8.0
EMAIL_SMTP_TIMEOUT_SEGUNDOS = 8
EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS = 10.0

# Reloj inyectable: las pruebas sustituyen `_ahora` por uno determinista sin
# dormir de verdad para comprobar el presupuesto total.
_ahora = time.monotonic

# Directorio del respaldo local (auditoría sin credenciales reales).
AUDIT_DIR = os.environ.get(
    "CUTUCO_EMAIL_AUDIT_DIR",
    str(Path.home() / "cutuco_emails"),
)

# La API key (xkeysib-...) y los Bearer jamas se registran en el log.
_REDACTAR = re.compile(r"xkeysib[-_][A-Za-z0-9_\-]{6,}|Bearer\s+\S+", re.IGNORECASE)


def _parse_from_email(from_email: str) -> dict[str, str]:
    """Separa 'Nombre <email@dominio.com>' en {'name': 'Nombre', 'email': '...'}."""
    match = re.match(r"^(.*?)\s*<([^>]+)>$", from_email.strip())
    if match:
        return {"name": match.group(1).strip(), "email": match.group(2).strip()}
    return {"email": from_email.strip()}


def es_clave_brevo_real(api_key: str | None) -> bool:
    """True sólo para claves con forma de producción (xkeysib-...).

    Los valores de ejemplo (`dummy`, `test-brevo`) no intentan red: se registran
    en el respaldo local para poder inspeccionar el correo sin enviarlo.
    """
    return isinstance(api_key, str) and api_key.startswith("xkeysib-")


def clasificar_error_correo(exc: Exception) -> str:  # noqa: PLR0911 - explicit provider branches
    """Describe el fallo de envio para el log, sin secretos ni datos personales.

    Distingue configuracion faltante, autenticacion con el proveedor,
    verificacion de dominio / rechazo de la peticion, limite de envio y fallos
    de red.
    """
    texto = _REDACTAR.sub("[REDACTADO]", str(exc)).replace("\n", " ").strip()

    mensaje_exc = str(exc).lower()
    if "401" in texto or "403" in texto or "auth" in mensaje_exc:
        return "autenticacion con Brevo: revisa BREVO_API_KEY [tipo=ApiError]"
    if "422" in texto or "400" in texto:
        return (
            "rechazo del proveedor: revisa EMAIL_FROM y la "
            "direccion de remitente verificada en Brevo [tipo=ApiError]"
        )
    if "429" in texto:
        return "limite de envio alcanzado (429) [tipo=ApiError]"
    if "timed out" in mensaje_exc or "timeout" in mensaje_exc:
        return "tiempo de espera agotado con el proveedor de correo (timeout) [tipo=TimeoutError]"
    if "500" in texto or "502" in texto or "503" in texto:
        return "error del proveedor Brevo [tipo=ApiError]"
    return "error de Brevo [tipo=ApiError]"


def _guardar_auditoria(  # noqa: PLR0913 - conserva contrato de auditoría
    payload: dict[str, Any],
    attachment: tuple[str, bytes, str] | None,
    *,
    enviado: bool,
    message_id: str | None = None,
    error: str | None = None,
    canal: str | None = None,
) -> None:
    """Deja una copia local del correo (con su PDF) para verificación.

    No reemplaza al envío: es el registro auditable de qué se generó y cuál fue
    el resultado del proveedor.
    """
    try:
        Path(AUDIT_DIR).mkdir(parents=True, exist_ok=True)
    except Exception as exc:  # pragma: no cover - disco lleno / permisos
        logger.warning("No se pudo crear el directorio de auditoría de correo: %s", exc)
        return

    marca = datetime.now(UTC).strftime("%Y%m%d_%H%M%S_%f")
    registro = {
        "para": payload.get("to"),
        "remitente": payload.get("sender"),
        "asunto": payload.get("subject"),
        "html": payload.get("htmlContent"),
        "texto": payload.get("textContent"),
        "enviado": enviado,
        "message_id": message_id,
        "error": error,
        "canal": canal,
        "timestamp": datetime.now(UTC).isoformat(),
    }

    adjuntos = []
    if attachment is not None:
        nombre, contenido, mime = attachment
        ruta = os.path.join(AUDIT_DIR, f"{marca}_{nombre}")
        try:
            with open(ruta, "wb") as fh:
                fh.write(contenido)
            adjuntos.append(
                {"name": nombre, "type": mime, "size_bytes": len(contenido), "archivo": ruta}
            )
        except Exception as exc:  # pragma: no cover
            logger.warning("No se pudo guardar el adjunto de auditoría: %s", exc)
            adjuntos.append({"name": nombre, "type": mime, "size_bytes": len(contenido)})
    else:
        adjuntos = []
    registro["attachment"] = adjuntos

    try:
        with open(os.path.join(AUDIT_DIR, f"email_{marca}.json"), "w", encoding="utf-8") as fh:
            json.dump(registro, fh, indent=2, ensure_ascii=False, default=str)
    except Exception as exc:  # pragma: no cover
        logger.warning("No se pudo guardar la auditoría del correo: %s", exc)


def _enviar_por_smtp(  # noqa: PLR0913 - transporte de respaldo explícito
    sender: dict[str, str],
    to: str,
    subject: str,
    html: str,
    text: str | None,
    attachment: tuple[str, bytes, str] | None,
    host: str,
    port: int,
    login: str,
    password: str,
    idempotency_key: str | None,
    timeout: float = EMAIL_SMTP_TIMEOUT_SEGUNDOS,
) -> None:
    """Envía por smtp-relay.brevo.com (STARTTLS). Bloqueante: usar to_thread."""
    mensaje = EmailMessage()
    nombre = sender.get("name")
    mensaje["From"] = formataddr((nombre, sender["email"])) if nombre else sender["email"]
    mensaje["To"] = to
    mensaje["Subject"] = subject
    if idempotency_key:
        mensaje["X-Mailin-custom"] = idempotency_key
    mensaje.set_content(text or " ")
    if html:
        mensaje.add_alternative(html, subtype="html")
    if attachment is not None:
        nombre_archivo, contenido, mime = attachment
        maintype, _, subtype = mime.partition("/")
        mensaje.add_attachment(
            contenido,
            maintype=maintype or "application",
            subtype=subtype or "octet-stream",
            filename=nombre_archivo,
        )

    with smtplib.SMTP(host, port, timeout=timeout) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.ehlo()
        smtp.login(login, password)
        smtp.send_message(mensaje)


def _message_id(response: httpx.Response) -> str | None:
    try:
        value = response.json().get("messageId")
        return value if isinstance(value, str) else None
    except (ValueError, AttributeError):
        return None


class EmailClient:
    def __init__(  # noqa: PLR0913 - configuración de los transportes existentes
        self,
        api_key: str,
        from_email: str,
        idempotency_key: str | None = None,
        *,
        smtp_host: str | None = None,
        smtp_port: int = 587,
        smtp_login: str | None = None,
        smtp_key: str | None = None,
    ) -> None:
        self.api_key = api_key
        self.from_email = from_email
        self.idempotency_key = idempotency_key
        # Respaldo SMTP del mismo proveedor (smtp-relay.brevo.com).
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.smtp_login = smtp_login
        self.smtp_key = smtp_key
        self.jinja = Environment(
            loader=FileSystemLoader(Path(__file__).parent / "templates"),
            autoescape=select_autoescape(["html"]),
            undefined=StrictUndefined,
        )

    def render(self, template_name: str, context: dict[str, Any]) -> str:
        return self.jinja.get_template(template_name).render(context)

    async def send(  # noqa: PLR0915, PLR0912 - presupuesto total + reintentos + respaldo SMTP
        self,
        to: str,
        subject: str,
        html: str,
        text: str | None = None,
        attachment: tuple[str, bytes, str] | None = None,
    ) -> bool:
        """Envia el correo con la API de Brevo. Devuelve True SOLO si el
        proveedor acepto la peticion; un False queda registrado con la causa.

        `attachment` es una tupla (nombre_archivo, bytes_contenido, mime_type).
        """
        sender = _parse_from_email(self.from_email)
        headers = (
            {
                "X-Mailin-custom": self.idempotency_key,
                "IdempotencyKey": str(uuid5(NAMESPACE_URL, self.idempotency_key)),
            }
            if self.idempotency_key
            else None
        )

        payload: dict[str, Any] = {
            "sender": sender,
            "to": [{"email": to}],
            "subject": subject,
            "htmlContent": html,
        }
        if text:
            payload["textContent"] = text
        if headers:
            payload["headers"] = headers
        if attachment is not None:
            nombre, contenido, mime = attachment
            payload["attachment"] = [
                {
                    "content": base64.b64encode(contenido).decode("ascii"),
                    "name": nombre,
                    "type": mime,
                }
            ]

        ultimo_error: str | None = None
        inicio = _ahora()
        if not self.api_key:
            ultimo_error = "sin_api_key"
            logger.error("BREVO_API_KEY no está configurada; se intentará SMTP si existe")
        elif not es_clave_brevo_real(self.api_key):
            # Una clave de ejemplo nunca sale por HTTP, pero en producción el
            # SMTP ya configurado de Brevo puede entregar el correo de forma
            # segura. Sin SMTP se conserva el comportamiento local de auditoría.
            ultimo_error = "clave_no_real"
            logger.warning("BREVO_API_KEY no es una clave real; se omite la API de Brevo")
        else:
            for attempt in range(3):
                restante = EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS - (_ahora() - inicio)
                if restante <= 0:
                    logger.warning(
                        "Brevo: sin presupuesto restante (%s s), se abandona el envío",
                        EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS,
                    )
                    break
                try:
                    async with httpx.AsyncClient(
                        timeout=min(EMAIL_HTTP_TIMEOUT_SEGUNDOS, restante)
                    ) as client:
                        response = await client.post(
                            BREVO_API_URL,
                            headers={
                                "api-key": self.api_key,
                                "accept": "application/json",
                                "content-type": "application/json",
                            },
                            json=payload,
                        )
                    if 200 <= response.status_code < 300:
                        message_id = _message_id(response)
                        _guardar_auditoria(
                            payload, attachment, enviado=True, message_id=message_id, canal="api"
                        )
                        logger.info("Correo aceptado por Brevo (messageId=%s)", message_id)
                        return True
                    response.raise_for_status()
                except Exception as exc:
                    ultimo_error = clasificar_error_correo(exc)
                    logger.warning("Brevo fallo en intento %s/3: %s", attempt + 1, ultimo_error)
                    if attempt < 2:
                        espera = 0.25 * (2**attempt)
                        # La espera entra en el mismo presupuesto: no se duerme lo
                        # que no cabe antes del plazo total.
                        if _ahora() - inicio + espera >= EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS:
                            break
                        await asyncio.sleep(espera)

        # Respaldo SMTP: se utiliza tras un fallo de API o directamente cuando
        # ésta no tiene una clave utilizable. En ambos casos no hubo aceptación
        # previa del proveedor y no existe riesgo de duplicar el mensaje.
        restante = EMAIL_PRESUPUESTO_TOTAL_SEGUNDOS - (_ahora() - inicio)
        if (
            self.smtp_host
            and self.smtp_login
            and self.smtp_key
            and restante > 0
        ):
            try:
                await asyncio.to_thread(
                    _enviar_por_smtp,
                    sender,
                    to,
                    subject,
                    html,
                    text,
                    attachment,
                    self.smtp_host,
                    self.smtp_port,
                    self.smtp_login,
                    self.smtp_key,
                    self.idempotency_key,
                    min(EMAIL_SMTP_TIMEOUT_SEGUNDOS, restante),
                )
                _guardar_auditoria(payload, attachment, enviado=True, canal="smtp")
                logger.info("Correo aceptado por SMTP de respaldo")
            except Exception as exc:
                ultimo_error = f"{ultimo_error} | smtp: {clasificar_error_correo(exc)}"
                logger.warning("SMTP de respaldo fallo: %s", clasificar_error_correo(exc))
            else:
                return True

        _guardar_auditoria(payload, attachment, enviado=False, error=ultimo_error)
        logger.error("Correo pendiente: se agotaron los reintentos de Brevo")
        return False
