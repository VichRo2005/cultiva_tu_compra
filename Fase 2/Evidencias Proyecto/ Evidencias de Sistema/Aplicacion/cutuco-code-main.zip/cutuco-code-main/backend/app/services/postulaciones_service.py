"""Resolución administrativa de postulaciones de vendedor.

La regla de negocio de PostgreSQL permanece como autoridad: esta capa sólo
aporta el comercio hijo configurado al invocar la RPC protegida. Así el
navegador no ve ni puede elegir credenciales de Transbank.
"""

import json
from typing import Any
from uuid import UUID

from fastapi import HTTPException

from app.core.config import MALL_SANDBOX_SELLER_COMMERCE_CODE, get_settings
from app.schemas.postulaciones import ResolverPostulacionRequest


def codigo_comercio_vendedor_configurado() -> str:
    """Devuelve el comercio hijo para aprobar una cuenta.

    En integración Transbank ofrece un hijo compartido. En producción la
    variable privada es obligatoria y debe ser distinta al comercio padre;
    reutilizar éste enviaría pagos Mall al destino equivocado.
    """

    settings = get_settings()
    codigo = (settings.TRANSBANK_MALL_SELLER_COMMERCE_CODE or "").strip()
    if not codigo and settings.TRANSBANK_ENV == "integration":
        return MALL_SANDBOX_SELLER_COMMERCE_CODE
    if not codigo:
        raise HTTPException(
            503,
            "La aprobación automática no está configurada. "
            "Falta TRANSBANK_MALL_SELLER_COMMERCE_CODE en el backend.",
        )
    if codigo == settings.TRANSBANK_COMMERCE_CODE:
        raise HTTPException(
            503,
            "TRANSBANK_MALL_SELLER_COMMERCE_CODE debe ser un comercio hijo distinto "
            "del comercio padre de Webpay Mall.",
        )
    return codigo


async def resolver_postulacion(
    conn: Any,
    administrador_id: UUID,
    postulacion_id: UUID,
    decision: ResolverPostulacionRequest,
) -> dict[str, Any]:
    """Resuelve con la identidad del admin autenticado y código sólo de servidor."""

    codigo = codigo_comercio_vendedor_configurado() if decision.estado == "aprobada" else None
    async with conn.transaction():
        # La conexión de backend puede haber heredado un rol de una operación
        # anterior. La RPC exige ejecutarse como backend, pero auth.uid() debe
        # continuar representando al administrador que tomó la decisión.
        await conn.execute("RESET ROLE")
        await conn.execute(
            "SELECT set_config('request.jwt.claims', $1, true)",
            json.dumps({"sub": str(administrador_id), "role": "authenticated"}),
        )
        row = await conn.fetchrow(
            """SELECT * FROM public.resolver_postulacion_vendedor(
                 $1, $2::public.estado_postulacion_vendedor, $3, $4
               )""",
            postulacion_id,
            decision.estado,
            decision.observaciones,
            codigo,
        )
    return dict(row) if row else {}
