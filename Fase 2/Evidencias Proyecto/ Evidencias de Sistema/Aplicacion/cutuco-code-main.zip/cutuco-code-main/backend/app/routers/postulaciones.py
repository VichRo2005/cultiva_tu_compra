from typing import Any
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends

from app.db.session import get_connection
from app.routers.deps import require_role
from app.schemas.postulaciones import PostulacionResueltaResponse, ResolverPostulacionRequest
from app.services import email_service, postulaciones_service

router = APIRouter(prefix="/api/admin/postulaciones", tags=["administración"])


@router.post("/{postulacion_id}/resolver", response_model=PostulacionResueltaResponse)
async def resolver(
    postulacion_id: UUID,
    body: ResolverPostulacionRequest,
    background_tasks: BackgroundTasks,
    user: dict[str, Any] = Depends(require_role("admin")),
    conn: Any = Depends(get_connection),
) -> dict[str, Any]:
    resultado = await postulaciones_service.resolver_postulacion(
        conn, user["id"], postulacion_id, body
    )
    background_tasks.add_task(
        email_service.enviar_notificacion_resolucion_postulacion, postulacion_id
    )
    return resultado
