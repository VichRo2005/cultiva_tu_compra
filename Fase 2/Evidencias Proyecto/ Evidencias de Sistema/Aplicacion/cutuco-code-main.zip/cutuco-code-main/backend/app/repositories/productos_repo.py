from typing import Any
from uuid import UUID


async def get_by_ids_for_update(conn: Any, ids: list[UUID]) -> Any:
    return await conn.fetch(
        "SELECT * FROM public.productos WHERE id=ANY($1::uuid[]) ORDER BY id FOR UPDATE", ids
    )


async def get_productor_id(conn: Any, producto_id: UUID) -> Any:
    return await conn.fetchval("SELECT productor_id FROM public.productos WHERE id=$1", producto_id)
