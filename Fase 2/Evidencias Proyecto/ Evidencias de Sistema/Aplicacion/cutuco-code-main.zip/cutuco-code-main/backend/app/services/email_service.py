import json
import logging
from decimal import Decimal
from typing import Any, Literal
from uuid import UUID

from app.core.config import get_settings
from app.db.session import connection_scope
from app.integrations.email.client import EmailClient
from app.repositories import (
    detalles_pedido_repo,
    pedidos_repo,
    preferencias_notificacion_repo,
)
from app.services.pdf_service import _direccion_vendedor, generar_pdf_pedido

logger = logging.getLogger(__name__)


def _client(pedido: Any, tipo: str) -> EmailClient:
    settings = get_settings()
    return EmailClient(
        settings.BREVO_API_KEY,
        settings.EMAIL_FROM,
        idempotency_key=f"pedido/{pedido['id']}/{tipo}",
        smtp_host=settings.BREVO_SMTP_HOST,
        smtp_port=settings.BREVO_SMTP_PORT,
        smtp_login=settings.BREVO_SMTP_LOGIN,
        smtp_key=settings.BREVO_SMTP_KEY,
    )


def _client_notificacion_postulacion(postulacion: dict[str, Any]) -> EmailClient:
    """Cliente Brevo idempotente para la decisión de una postulación.

    El intento forma parte de la llave: una postulación rechazada puede volver a
    enviarse a revisión y debe recibir una nueva notificación al resolverse.
    """
    settings = get_settings()
    return EmailClient(
        settings.BREVO_API_KEY,
        settings.EMAIL_FROM,
        idempotency_key=(
            f"postulacion/{postulacion['id']}/intento/{postulacion['intento']}/"
            f"{postulacion['estado']}"
        ),
        smtp_host=settings.BREVO_SMTP_HOST,
        smtp_port=settings.BREVO_SMTP_PORT,
        smtp_login=settings.BREVO_SMTP_LOGIN,
        smtp_key=settings.BREVO_SMTP_KEY,
    )


async def _generar_pdf_adjunto(  # noqa: PLR0913, PLR0917 - snapshot existente del pedido
    conn: Any,
    pedido: dict[str, Any],
    cliente: dict[str, Any] | None,
    productor: dict[str, Any] | None,
    direccion: dict[str, Any] | None,
    items: list[dict[str, Any]],
    pago: dict[str, Any] | None,
) -> tuple[str, bytes, str] | None:
    """Genera el comprobante de compra PDF y devuelve (nombre, bytes, mime) o None."""
    try:
        documento = pedido.get("documento_tributario")
        if isinstance(documento, str):
            documento = json.loads(documento)
        tipo_doc = (documento or {}).get("tipo", "boleta")
        datos_trib = documento if tipo_doc == "factura" else None

        fecha_pago = None
        if pago and pago.get("autorizado_en"):
            fecha_pago = str(pago["autorizado_en"])

        pdf_bytes = generar_pdf_pedido(
            pedido=pedido,
            cliente=cliente,
            productor=productor,
            direccion=direccion,
            items=items,
            total=Decimal(str(pedido.get("total", 0))),
            tarifa_delivery=Decimal(str(pedido.get("tarifa_delivery", 0))),
            tipo_documento=tipo_doc,
            datos_tributarios=datos_trib,
            codigo_comercio=pago.get("codigo_comercio") if pago else None,
            codigo_autorizacion=pago.get("codigo_autorizacion") if pago else None,
            fecha_pago=fecha_pago,
        )
        nombre_archivo = f"comprobante-{pedido.get('codigo_pedido', 'pedido')}.pdf"
    except Exception:
        logger.exception("No se pudo generar el PDF adjunto del pedido %s", pedido.get("id"))
        return None
    else:
        return (nombre_archivo, pdf_bytes, "application/pdf")


def _vendedor_para_correo(contexto: Any) -> dict[str, Any] | None:
    """Datos del vendedor para el cuerpo del correo del comprador.

    Mismo origen que el PDF adjunto (`get_email_context`): comercio, RUT oficial,
    correo y dirección activa del productor, para que el comprobante por correo
    muestre al vendedor igual que el PDF.
    """
    if contexto is None:
        return None
    return {
        "nombre_comercial": contexto.get("nombre_comercial"),
        "rut": contexto.get("rut_oficial"),
        "email": contexto.get("productor_email"),
        "direccion": _direccion_vendedor(contexto),
        "region": contexto.get("region_nombre"),
    }


async def enviar_correo_compra_comprador(  # noqa: PLR0913, PLR0917 - contexto de plantilla
    to_email: str,
    pedido: Any,
    totales: Any,
    items: Any,
    frontend_url: str,
    attachment: tuple[str, bytes, str] | None = None,
    vendedor: dict[str, Any] | None = None,
) -> bool:
    client = _client(pedido, "comprador")
    context = {
        "pedido": pedido,
        "totales": totales,
        "items": items,
        "frontend_url": frontend_url.rstrip("/"),
        "vendedor": vendedor,
    }
    return await client.send(
        to_email,
        f"Compra confirmada {pedido['codigo_pedido']}",
        client.render("compra_comprador.html", context),
        client.render("compra_comprador.txt", context),
        attachment=attachment,
    )


async def enviar_correo_nuevo_pedido_productor(  # noqa: PLR0913, PLR0917 - template context
    to_email: str,
    pedido: Any,
    cliente_info: Any,
    direccion: Any,
    items: Any,
    monto_productor: Any,
    attachment: tuple[str, bytes, str] | None = None,
) -> bool:
    client = _client(pedido, "productor")
    context = {
        "pedido": pedido,
        "cliente_info": cliente_info,
        "direccion": direccion,
        "items": items,
        "monto_productor": monto_productor,
    }
    return await client.send(
        to_email,
        f"Nuevo pedido {pedido['codigo_pedido']}",
        client.render("nuevo_pedido_productor.html", context),
        client.render("nuevo_pedido_productor.txt", context),
        attachment=attachment,
    )


async def enviar_correo_resolucion_postulacion(
    to_email: str,
    postulacion: dict[str, Any],
    nombre: str | None,
) -> bool:
    """Envía al solicitante la decisión tomada por el administrador."""
    client = _client_notificacion_postulacion(postulacion)
    aprobada = postulacion["estado"] == "aprobada"
    observaciones = str(postulacion.get("observaciones_admin") or "").strip()
    mensaje_automatico = (
        "Tu postulación fue aprobada. Ya puedes ingresar a tu panel de vendedor "
        "y publicar productos."
        if aprobada
        else (
            "Tu postulación no fue aprobada en esta oportunidad. Puedes revisar "
            "los datos y volver a enviarla."
        )
    )
    context = {
        "nombre": (nombre or "Hola").strip() or "Hola",
        "postulacion": postulacion,
        "aprobada": aprobada,
        "mensaje": observaciones or mensaje_automatico,
        "frontend_url": get_settings().FRONTEND_URL.rstrip("/"),
    }
    asunto = (
        "Tu postulación fue aprobada · CuTuCo"
        if aprobada
        else "Tu postulación fue rechazada · CuTuCo"
    )
    return await client.send(
        to_email,
        asunto,
        client.render("postulacion_resuelta.html", context),
        client.render("postulacion_resuelta.txt", context),
    )


async def enviar_correo_recuperacion_contrasena(to_email: str, reset_url: str) -> bool:
    """Entrega por Brevo un enlace de recuperación emitido por Supabase Auth.

    El token sigue siendo de GoTrue y la SPA conserva el evento
    ``PASSWORD_RECOVERY`` como requisito para cambiar la contraseña. Brevo sólo
    transporta el enlace, igual que en las confirmaciones de compra.
    """
    settings = get_settings()
    client = EmailClient(
        settings.BREVO_API_KEY,
        settings.EMAIL_FROM,
        smtp_host=settings.BREVO_SMTP_HOST,
        smtp_port=settings.BREVO_SMTP_PORT,
        smtp_login=settings.BREVO_SMTP_LOGIN,
        smtp_key=settings.BREVO_SMTP_KEY,
    )
    context = {
        "reset_url": reset_url,
        "frontend_url": settings.FRONTEND_URL.rstrip("/"),
    }
    return await client.send(
        to_email,
        "Recupera tu contraseña de CuTuCo",
        client.render("recuperacion_contrasena.html", context),
        client.render("recuperacion_contrasena.txt", context),
    )


async def enviar_notificacion_resolucion_postulacion(postulacion_id: UUID) -> None:
    """Entrega una vez por intento la resolución ya confirmada en la BD.

    Corre fuera de la transacción HTTP de aprobación: una caída de Brevo nunca
    revierte la decisión administrativa. La revisión se bloquea mientras se
    envía y sólo se marca al recibir aceptación del proveedor.
    """
    try:
        async with connection_scope() as conn, conn.transaction():
            row = await conn.fetchrow(
                """
                SELECT
                  r.id AS revision_id,
                  r.intento,
                  r.estado,
                  r.observaciones_admin,
                  p.id AS postulacion_id,
                  p.perfil_id,
                  p.nombre_comercial_solicitado,
                  nullif(btrim(pf.nombre), '') AS nombre,
                  au.email
                FROM public.postulaciones_revisiones r
                JOIN public.postulaciones_vendedores p ON p.id = r.postulacion_id
                JOIN public.perfiles pf ON pf.id = p.perfil_id
                JOIN auth.users au ON au.id = p.perfil_id
                WHERE r.postulacion_id = $1
                  AND r.intento = p.intento
                  AND r.estado = p.estado
                  AND p.estado IN ('aprobada', 'rechazada')
                  AND r.correo_resolucion_enviado_en IS NULL
                  AND r.correo_resolucion_omitido_en IS NULL
                FOR UPDATE OF r
                """,
                postulacion_id,
            )
            if not row or not row["email"]:
                return
            if not await preferencias_notificacion_repo.recibe_correo(conn, row["perfil_id"]):
                await conn.execute(
                    """
                    UPDATE public.postulaciones_revisiones
                    SET correo_resolucion_omitido_en = now()
                    WHERE id = $1
                    """,
                    row["revision_id"],
                )
                return

            postulacion = {
                "id": row["postulacion_id"],
                "intento": row["intento"],
                "estado": row["estado"],
                "observaciones_admin": row["observaciones_admin"],
                "nombre_comercial_solicitado": row["nombre_comercial_solicitado"],
            }
            enviado = await enviar_correo_resolucion_postulacion(
                row["email"], postulacion, row["nombre"]
            )
            if enviado:
                await conn.execute(
                    """
                    UPDATE public.postulaciones_revisiones
                    SET correo_resolucion_enviado_en = now()
                    WHERE id = $1
                    """,
                    row["revision_id"],
                )
    except Exception:
        # La decisión ya fue persistida; el envío se puede reintentar sin
        # exponer la dirección de correo ni deshacer la resolución.
        logger.exception(
            "No se pudo enviar el correo de resolución de la postulación %s", postulacion_id
        )




def _schedule_emails(pedido: Any, background_tasks: Any) -> None:
    """Programa envío de emails de confirmación (comprador + vendedor)."""
    background_tasks.add_task(enviar_pendiente, pedido["id"], "comprador")
    background_tasks.add_task(enviar_pendiente, pedido["id"], "productor")


async def enviar_pendiente(  # noqa: PLR0912 - flujo transaccional de entrega existente
    pedido_id: UUID, tipo: Literal["comprador", "productor"]
) -> None:
    # A fresh pool connection: request dependencies may already have been closed.
    # Serialize checks + delivery + flag across workers and duplicate confirmations.
    try:
        async with connection_scope() as conn, conn.transaction():
            pedido = await conn.fetchrow(
                "SELECT * FROM public.pedidos WHERE id=$1 FOR UPDATE", pedido_id
            )
            if not pedido:
                return
            pedido = dict(pedido)
            if (
                pedido[f"correo_{tipo}_enviado_en"] is not None
                or pedido.get(f"correo_{tipo}_omitido_en") is not None
            ):
                return
            # jsonb puede llegar como str o como dict según el codec de asyncpg.
            if isinstance(pedido.get("documento_tributario"), str):
                pedido["documento_tributario"] = json.loads(pedido["documento_tributario"])
            context_row = await pedidos_repo.get_email_context(conn, pedido_id)
            if context_row is None:
                logger.error("Pedido %s sin contexto para correo de %s", pedido_id, tipo)
                return
            # asyncpg devuelve Record, que admite índice pero no `.get()`. Las
            # plantillas, el PDF y el enriquecimiento de ítems usan el contrato
            # de diccionario; normalizar aquí evita que el correo quede
            # pendiente antes de alcanzar Brevo.
            context = dict(context_row)
            email = context[f"{tipo}_email"]
            if not email:
                logger.error("Pedido %s sin email de %s", pedido_id, tipo)
                return
            perfil_id = (
                pedido["cliente_id"] if tipo == "comprador" else context["productor_perfil_id"]
            )
            if not await preferencias_notificacion_repo.recibe_correo(conn, perfil_id):
                # Se registra la omisión para no reintentar retrospectivamente un
                # mensaje que la persona decidió no recibir.
                await pedidos_repo.update_correo_omitido(conn, pedido_id, tipo)
                return

            raw_items = await detalles_pedido_repo.get_by_pedido(conn, pedido_id)
            items = [dict(item) for item in raw_items]

            # Enriquecer items con codigo_producto para el PDF
            items_enriquecidos = []
            producto_ids = [
                item.get("producto_id") for item in items if item.get("producto_id")
            ]
            productos_por_id: dict[Any, Any] = {}
            if producto_ids:
                rows = await conn.fetch(
                    "SELECT id, codigo_producto FROM public.productos WHERE id=ANY($1)",
                    producto_ids,
                )
                productos_por_id = {row["id"]: row for row in rows}
            for item in items:
                item_dict = dict(item)
                prod_id = item.get("producto_id")
                if prod_id and prod_id in productos_por_id:
                    item_dict["codigo_producto"] = productos_por_id[prod_id][
                        "codigo_producto"
                    ]
                items_enriquecidos.append(item_dict)

            # Pago para datos de autorización
            pago = await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido_id)

            # Generar PDF adjunto (mismo para comprador y vendedor)
            adjunto = await _generar_pdf_adjunto(
                conn=conn,
                pedido=pedido,
                cliente=context,
                productor=context,
                direccion=pedido,
                items=items_enriquecidos,
                pago=dict(pago) if pago else None,
            )

            if tipo == "comprador":
                sent = await enviar_correo_compra_comprador(
                    email,
                    pedido,
                    pedido,
                    items_enriquecidos,
                    get_settings().FRONTEND_URL,
                    attachment=adjunto,
                    vendedor=_vendedor_para_correo(context),
                )
            else:
                sent = await enviar_correo_nuevo_pedido_productor(
                    email,
                    pedido,
                    context,
                    pedido,
                    items_enriquecidos,
                    await conn.fetchval(
                        "SELECT monto FROM public.pagos WHERE pedido_id=$1", pedido_id
                    ),
                    attachment=adjunto,
                )
            if sent:
                await pedidos_repo.update_correo_enviado(conn, pedido_id, tipo)
    except Exception:
        # Payment transaction is already committed; delivery must never roll it back.
        logger.exception(  # noqa: TRY400 - provider exceptions can contain secrets
            "No se pudo enviar o registrar correo %s del pedido %s", tipo, pedido_id
        )
