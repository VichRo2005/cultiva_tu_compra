from decimal import Decimal
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

from app.schemas.common import EstadoEnvio, EstadoPedido
from app.schemas.validators import Calle, Cantidad, validate_rut


class ItemRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    producto_id: UUID
    cantidad: Cantidad


class Boleta(BaseModel):
    model_config = ConfigDict(extra="forbid")
    tipo: Literal["boleta"] = "boleta"


class Factura(BaseModel):
    model_config = ConfigDict(extra="forbid")
    tipo: Literal["factura"]
    rut_empresa: str
    razon_social: Annotated[
        str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)
    ]
    giro: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)]
    direccion_tributaria: Calle

    _rut = field_validator("rut_empresa")(validate_rut)


class IniciarRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    documento_tributario: Annotated[Boleta | Factura, Field(discriminator="tipo")] = Field(
        default_factory=Boleta
    )
    direccion_id: UUID
    items: list[ItemRequest] = Field(min_length=1, max_length=100)
    # Consentimiento del navegador; el servidor siempre calcula el monto real.
    monto_esperado: int | None = Field(default=None, ge=0, strict=True)
    nombre_destinatario: (
        Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=160)]
        | None
    ) = None
    telefono_destinatario: (
        Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=30)] | None
    ) = None
    referencia_entrega: str | None = Field(default=None, max_length=500)


class IniciarResponse(BaseModel):
    checkout_id: UUID
    buy_order: str
    token_ws: str
    url: str
    monto: int


class ConfirmarRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    token_ws: str = Field(min_length=1, max_length=255, pattern=r"^\S+$")


class PedidoConfirmado(BaseModel):
    pedido_id: UUID
    # Resultados Webpay ya guardados antes de este campo deben poder volver a
    # consultarse idempotentemente después de desplegar esta versión.
    codigo_pedido: str | None = None
    productor_id: UUID
    estado_pedido: EstadoPedido
    total: Decimal
    productos: list["ProductoPedidoConfirmado"] = Field(default_factory=list)


class ProductoPedidoConfirmado(BaseModel):
    """Identificador comercial que se muestra al cerrar una compra."""

    producto_id: UUID
    codigo_producto: str | None = None
    producto_nombre: str


class ConfirmarResponse(BaseModel):
    ok: bool
    checkout_id: UUID
    estado: Literal["autorizado", "parcial", "rechazado"]
    pedidos: list[PedidoConfirmado]
    requiere_conciliacion: bool = False
    ya_confirmado: bool = False


class EnvioResponse(BaseModel):
    id: UUID
    estado: EstadoEnvio
    tarifa_fija: Decimal


class EstadoResponse(BaseModel):
    pedido_id: UUID
    codigo_pedido: str
    estado_pedido: EstadoPedido
    estado_pago: Literal["autorizado"] | None
    monto_productor: Decimal | None
    total: Decimal
    envio: EnvioResponse | None


class DireccionSnapshot(BaseModel):
    direccion_entrega: Calle
