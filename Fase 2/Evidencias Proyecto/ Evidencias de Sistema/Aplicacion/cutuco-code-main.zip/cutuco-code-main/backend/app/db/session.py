from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import asyncpg

from app.core.config import get_settings

_pool: Any = None


async def init_pool() -> Any:
    global _pool
    if _pool is None:
        # min_size=0: el pool NO abre conexiones al arrancar. En Cloud Run el
        # contenedor debe escuchar en $PORT aunque la BD esté momentáneamente
        # inalcanzable; con min_size=1 un DATABASE_URL inalcanzable tumba el
        # arranque ("container failed to start") en vez de fallar por petición.
        _pool = await asyncpg.create_pool(
            get_settings().DATABASE_URL,
            min_size=0,
            # Cloud Run escala por instancias; un pool pequeño mantiene el uso
            # total acotado en el pooler compartido de Supabase.
            max_size=5,
            command_timeout=30,
            # El pooler de Supabase en modo transaccional (puerto 6543) no
            # admite sentencias preparadas. asyncpg las guarda en caché por
            # defecto, por lo que deben deshabilitarse para el runtime cloud.
            statement_cache_size=0,
        )
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


async def get_connection() -> AsyncIterator[Any]:
    if _pool is None:
        raise RuntimeError("Database pool not initialized")
    async with _pool.acquire() as conn:
        yield conn


connection_scope = asynccontextmanager(get_connection)
