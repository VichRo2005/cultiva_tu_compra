from typing import Any
from uuid import UUID


async def get_by_pedido(conn: Any, pedido_id: UUID) -> Any:
    return await conn.fetchrow("SELECT * FROM public.envios WHERE pedido_id=$1", pedido_id)
