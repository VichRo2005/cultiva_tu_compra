import json
from typing import Any
from uuid import UUID


async def create_pago(
    conn: Any, pedido_id: UUID, checkout: Any, detail: dict[str, Any], fee: int
) -> Any:
    return await conn.fetchrow(
        """INSERT INTO public.pagos
        (pedido_id, buy_order, buy_order_mall, token_ws, codigo_comercio, session_id,
         monto, monto_fee_descontado, codigo_autorizacion, codigo_respuesta,
         autorizado_en, respuesta_webpay)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),$11::jsonb) RETURNING *""",
        pedido_id,
        detail["buy_order"],
        checkout["buy_order"],
        checkout["token_ws"],
        detail["commerce_code"],
        checkout["session_id"],
        detail["amount"],
        fee,
        detail["authorization_code"],
        # PostgreSQL stores the response code as varchar, while Webpay returns
        # it as an integer (0 on an authorized transaction).
        str(detail["response_code"]) if detail.get("response_code") is not None else None,
        json.dumps(detail),
    )


async def get_by_pedido(conn: Any, pedido_id: UUID) -> Any:
    return await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido_id)
