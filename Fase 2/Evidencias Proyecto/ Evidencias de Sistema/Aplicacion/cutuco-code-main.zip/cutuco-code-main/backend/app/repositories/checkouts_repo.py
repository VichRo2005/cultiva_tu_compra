import json
from typing import Any
from uuid import UUID


async def create(conn: Any, checkout: dict[str, Any]) -> None:
    await conn.execute(
        """INSERT INTO private.webpay_checkouts
        (id, cliente_id, buy_order, session_id, snapshot, reservas_expiran_en)
        VALUES ($1,$2,$3,$4,$5::jsonb,$6)""",
        checkout["id"],
        checkout["cliente_id"],
        checkout["buy_order"],
        checkout["session_id"],
        json.dumps(checkout["snapshot"], default=str),
        checkout.get("reservas_expiran_en"),
    )
    for store in checkout["snapshot"]["tiendas"]:
        for detail in (store["detail"], store["fee_detail"]):
            if detail:
                await conn.execute(
                    "INSERT INTO private.webpay_ordenes (buy_order,checkout_id) VALUES ($1,$2)",
                    detail["buy_order"],
                    checkout["id"],
                )


async def set_token(conn: Any, checkout_id: UUID, token: str) -> None:
    await conn.execute(
        "UPDATE private.webpay_checkouts SET token_ws=$2 WHERE id=$1", checkout_id, token
    )


async def lock(conn: Any, token: str) -> Any:
    return await conn.fetchrow(
        "SELECT * FROM private.webpay_checkouts WHERE token_ws=$1 FOR UPDATE", token
    )


async def save_response(conn: Any, checkout_id: UUID, response: dict[str, Any]) -> None:
    await conn.execute(
        "UPDATE private.webpay_checkouts SET respuesta=$2::jsonb WHERE id=$1",
        checkout_id,
        json.dumps(response),
    )


async def finish(
    conn: Any, checkout_id: UUID, response: dict[str, Any], result: dict[str, Any]
) -> None:
    await conn.execute(
        """UPDATE private.webpay_checkouts
        SET respuesta=$2::jsonb, resultado=$3::jsonb, confirmado_en=now() WHERE id=$1""",
        checkout_id,
        json.dumps(response),
        json.dumps(result, default=str),
    )


# ------------------------------------------------------------------
# Reserva temporal de stock (disponible = stock - stock_reservado).
# La consistencia vive en la base de datos (migración
# 20261021000000_reserva_stock_checkout.sql); estos helpers solo la invocan.
# ------------------------------------------------------------------


async def reservar(
    conn: Any, checkout_id: UUID, producto_id: UUID, cantidad: Any
) -> bool:
    """Retiene unidades de un producto para este checkout.

    El UPDATE condicional es atómico: si otro checkout ya tomó las unidades,
    no actualiza ninguna fila y devuelve False (el caller responde 409/400).
    """
    actualizada = await conn.execute(
        """UPDATE public.productos SET stock_reservado = stock_reservado + $2
        WHERE id = $1 AND stock - stock_reservado >= $2""",
        producto_id,
        cantidad,
    )
    if actualizada == "UPDATE 0":
        return False
    await conn.execute(
        """INSERT INTO private.checkout_reservas (checkout_id, producto_id, cantidad)
        VALUES ($1,$2,$3)""",
        checkout_id,
        producto_id,
        cantidad,
    )
    return True


async def liberar(conn: Any, checkout_id: UUID) -> None:
    """Libera todas las retenciones del checkout (idempotente en la BD)."""
    await conn.execute("SELECT private.liberar_reservas_checkout($1)", checkout_id)


async def liberar_expiradas(conn: Any) -> int:
    """Libera las retenciones cuyo plazo (reservas_expiran_en) ya venció."""
    return int(await conn.fetchval("SELECT private.liberar_reservas_expiradas()"))
