from pydantic import BaseModel


class IniciarServicioResponse(BaseModel):
    url: str
    token_ws: str
    buy_order: str
    monto: int
    # Presente sólo cuando un pago anterior quedó AUTORIZADO sin commit y se
    # confirmó al iniciar ("pagado") o requiere conciliación manual.
    # Cuando es "pagado", url va vacío: no hay que redirigir a Webpay.
    estado: str | None = None


class RetornoServicioResponse(BaseModel):
    ok: bool
    estado: str
    pago_id: str
