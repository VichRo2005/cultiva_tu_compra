import re
from decimal import Decimal
from typing import Annotated

from pydantic import Field, StringConstraints

CALLE_PATTERN = r"\S"
Calle = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=500, pattern=CALLE_PATTERN),
]

# Límites del marketplace. El precio por unidad se acota a 999.999 CLP tanto
# en el formulario como en la API para impedir que rutas alternativas superen
# la regla comercial.
PRECIO_MAXIMO = Decimal("999999")
STOCK_MAXIMO = Decimal("999999999.9")
PrecioCLP = Annotated[
    Decimal,
    Field(ge=0, le=PRECIO_MAXIMO, max_digits=12, decimal_places=2, allow_inf_nan=False),
]
Stock = Annotated[
    Decimal,
    Field(ge=0, le=STOCK_MAXIMO, max_digits=12, decimal_places=1, allow_inf_nan=False),
]
Cantidad = Annotated[
    Decimal,
    Field(gt=0, le=STOCK_MAXIMO, max_digits=12, decimal_places=1, allow_inf_nan=False),
]

# HAL-REG-010: 10 MiB exactos (10 * 1024 * 1024), criterio compartido con el
# bucket privado vendedor-documentos y con la validación del frontend.
MAX_DOCUMENTO_BYTES = 10_485_760
MIME_DOCUMENTOS_PERMITIDOS = frozenset({"application/pdf", "image/jpeg", "image/png"})

# Límites funcionales acordados para textos de moderación/entrega.
MAX_JUSTIFICACION = 1000
MAX_DEPTO_OFICINA = 50
MAX_TELEFONO = 30


def validar_documento_postulacion(tamano_bytes: int, mime_type: str) -> str | None:
    """Devuelve un mensaje funcional o None. El bucket impone el mismo límite."""
    if tamano_bytes <= 0:
        return "El documento está vacío"
    if tamano_bytes > MAX_DOCUMENTO_BYTES:
        return "El documento supera el tamaño máximo permitido (10 MB)"
    if mime_type not in MIME_DOCUMENTOS_PERMITIDOS:
        return "El documento debe ser PDF, JPG o PNG"
    return None


def validate_rut(value: str) -> str:
    normalized = value.strip().replace(".", "").upper()
    if not re.fullmatch(r"[0-9]{1,8}-[0-9K]", normalized):
        raise ValueError("RUT inválido")
    body, digit = normalized.split("-")
    if int(body) == 0:
        raise ValueError("RUT inválido")
    total = sum(int(number) * (index % 6 + 2) for index, number in enumerate(reversed(body)))
    remainder = 11 - total % 11
    expected = "0" if remainder == 11 else "K" if remainder == 10 else str(remainder)
    if digit != expected:
        raise ValueError("Dígito verificador del RUT inválido")
    return f"{int(body)}-{digit}"
