import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from app.integrations.sre import client as sre_client
from app.routers.deps import get_current_user
from app.schemas.validators import validate_rut

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/tributario", tags=["tributario"])


@router.get("/empresa/{rut}")
async def empresa_por_rut(
    rut: str, user: dict[str, Any] = Depends(get_current_user)
) -> dict[str, Any]:
    try:
        rut_normalizado = validate_rut(rut)
    except ValueError:
        raise HTTPException(422, "RUT inválido")
    try:
        datos = await sre_client.get_empresa(rut_normalizado)
    except sre_client.SreConfigError:
        logger.warning("SRE sin token público configurado")
        raise HTTPException(
            503,
            "El autocompletado tributario no está configurado. Ingresa los datos manualmente.",
        )
    except sre_client.SreError:
        logger.warning("Fallo consultando SRE")
        raise HTTPException(
            503,
            "No fue posible consultar el servicio tributario en este momento. "
            "Ingresa los datos manualmente o reintenta más tarde.",
        )
    if datos is None:
        raise HTTPException(404, "Empresa no encontrada en el registro tributario")
    return {"existe": True, "rut": rut_normalizado, **datos}
