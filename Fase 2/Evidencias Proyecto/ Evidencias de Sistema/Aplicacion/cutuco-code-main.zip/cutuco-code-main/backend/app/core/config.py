from functools import lru_cache
from typing import Any, Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Credenciales públicas del sandbox de Transbank. Nunca se usan en producción:
# el servicio mensual falla con 503 si falta configuración explícita.
SERVICIO_SANDBOX_COMMERCE_CODE = "597055555532"
SERVICIO_SANDBOX_API_KEY = (
    "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C"
)
SERVICIO_SANDBOX_RETURN_URL = "http://127.0.0.1:8000/api/servicio/retorno"
# Comercio hijo de integración de Webpay Mall. En el sandbox Transbank permite
# compartirlo; en producción cada comercio hijo debe ser provisto por Transbank.
MALL_SANDBOX_SELLER_COMMERCE_CODE = "597055555536"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    SUPABASE_URL: str
    SUPABASE_ANON_KEY: str
    SUPABASE_SERVICE_ROLE_KEY: str
    SUPABASE_JWT_SECRET: str | None = None
    SUPABASE_JWKS_URL: str = ""
    DATABASE_URL: str
    TRANSBANK_COMMERCE_CODE: str = Field(default="597055555535", pattern=r"^[0-9]{12}$")
    TRANSBANK_FEE_COMMERCE_CODE: str = Field(default="597055555537", pattern=r"^[0-9]{12}$")
    # Comercio hijo que se asigna automáticamente al aprobar una postulación.
    # No usar el comercio padre: Webpay Mall requiere que la venta se dirija a
    # un hijo. En integración se usa el código público de sandbox si se omite.
    TRANSBANK_MALL_SELLER_COMMERCE_CODE: str | None = Field(default=None, pattern=r"^[0-9]{12}$")
    TRANSBANK_API_KEY: str
    TRANSBANK_RETURN_URL: str
    TRANSBANK_ENV: Literal["integration", "production"] = "integration"
    # Webpay Plus para el servicio mensual (comercio propio de CuTuCo).
    # HAL-VEN-025: son obligatorias en producción. En development se completan
    # con el sandbox público para no romper el arranque local; en test/production
    # faltar cualquiera produce un 503 explícito y en español.
    TRANSBANK_SERVICIO_COMMERCE_CODE: str | None = None
    TRANSBANK_SERVICIO_API_KEY: str | None = None
    TRANSBANK_SERVICIO_RETURN_URL: str | None = None
    BREVO_API_KEY: str
    EMAIL_FROM: str = "CuTuCo <no-reply@cutuco.cl>"
    # Respaldo SMTP del mismo proveedor. Si la API HTTP falla, la confirmación
    # de compra se reintenta por smtp-relay.brevo.com para no perder el correo.
    BREVO_SMTP_HOST: str = "smtp-relay.brevo.com"
    BREVO_SMTP_PORT: int = 587
    BREVO_SMTP_LOGIN: str | None = None
    BREVO_SMTP_KEY: str | None = None
    FRONTEND_URL: str
    ENVIRONMENT: Literal["development", "production", "test"] = "production"
    AUTH_DEV_FALLBACK: bool = False
    # Plazo de retencion de stock durante el checkout Webpay (minutos).
    # Documentado en README y GUIA: disponible = stock - stock_reservado hasta
    # que el checkout se confirme, se rechace o expire este plazo.
    RESERVA_STOCK_MINUTOS: int = Field(default=15, ge=1, le=240)
    # Clave Fernet (url-safe base64, 32 bytes) para cifrar numero_cuenta_cifrado.
    BANK_ENCRYPTION_KEY: str
    # API pública SRE para autocompletar datos tributarios B2B (HAL-CLI-028).
    # El token público de SRE es "token_publico"; es un identificador público,
    # no un secreto. Nunca se devuelve al cliente.
    SRE_BASE_URL: str = "https://sre.cl"
    SRE_TOKEN_PUBLICO: str = "token_publico"
    SRE_TIMEOUT_SEGUNDOS: float = Field(default=4.0, ge=1, le=15)

    @model_validator(mode="before")
    @classmethod
    def _recortar_espacios(cls, data: Any) -> Any:
        """Secret Manager inyecta el valor byte a byte: si un secreto se creó con
        `echo` en vez de `printf '%s'`, llega con `\\r\\n` al final y rompe los
        patrones (pydantic `^[0-9]{12}$`) y el arranque del contenedor en Cloud Run.
        Se recortan todos los strings antes de validar."""
        if isinstance(data, dict):
            cleaned = {k: (v.strip() if isinstance(v, str) else v) for k, v in data.items()}
            # Un secreto opcional vacío equivale a no configurarlo. Esto permite
            # el fallback público sólo cuando TRANSBANK_ENV=integration.
            if cleaned.get("TRANSBANK_MALL_SELLER_COMMERCE_CODE") == "":
                cleaned["TRANSBANK_MALL_SELLER_COMMERCE_CODE"] = None
            return cleaned
        return data

    @model_validator(mode="after")
    def _aplicar_sandbox_desarrollo(self) -> "Settings":
        """Sólo development usa el sandbox público del servicio mensual."""
        if self.ENVIRONMENT != "development":
            return self
        if not self.TRANSBANK_SERVICIO_COMMERCE_CODE:
            self.TRANSBANK_SERVICIO_COMMERCE_CODE = SERVICIO_SANDBOX_COMMERCE_CODE
        if not self.TRANSBANK_SERVICIO_API_KEY:
            self.TRANSBANK_SERVICIO_API_KEY = SERVICIO_SANDBOX_API_KEY
        if not self.TRANSBANK_SERVICIO_RETURN_URL:
            self.TRANSBANK_SERVICIO_RETURN_URL = SERVICIO_SANDBOX_RETURN_URL
        return self

    @property
    def jwks_url(self) -> str:
        return self.SUPABASE_JWKS_URL or f"{self.issuer}/.well-known/jwks.json"

    @property
    def issuer(self) -> str:
        return f"{self.SUPABASE_URL.rstrip('/')}/auth/v1"


@lru_cache
def get_settings() -> Settings:
    return Settings()
