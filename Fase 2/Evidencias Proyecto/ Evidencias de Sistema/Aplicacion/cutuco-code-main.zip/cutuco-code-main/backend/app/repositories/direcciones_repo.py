from typing import Any
from uuid import UUID


async def get_by_id_and_perfil(conn: Any, direccion_id: UUID, perfil_id: UUID) -> Any:
    return await conn.fetchrow(
        """SELECT d.*, c.region_id FROM public.direcciones d
        JOIN public.comunas c ON c.id=d.comuna_id
        WHERE d.id=$1 AND d.perfil_id=$2 AND d.activo=true""",
        direccion_id,
        perfil_id,
    )


async def get_activa_productor(conn: Any, productor_id: UUID) -> Any:
    return await conn.fetchrow(
        """SELECT d.*, c.region_id, c.nombre AS comuna, r.nombre AS region
        FROM public.productores pr JOIN public.perfiles pf ON pf.id=pr.perfil_id
        JOIN public.direcciones d ON d.perfil_id=pr.perfil_id AND d.activo=true
        JOIN public.comunas c ON c.id=d.comuna_id JOIN public.regiones r ON r.id=c.region_id
        WHERE pr.id=$1 AND pr.activo=true AND pf.activo=true
        ORDER BY d.es_principal DESC, d.id LIMIT 1""",
        productor_id,
    )
