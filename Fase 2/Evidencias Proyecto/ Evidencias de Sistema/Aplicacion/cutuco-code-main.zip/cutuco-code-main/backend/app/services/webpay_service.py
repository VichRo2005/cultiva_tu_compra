import asyncio
import json
import logging
from datetime import UTC, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Literal
from uuid import UUID, uuid4

import asyncpg
from fastapi import BackgroundTasks, HTTPException

from app.core.config import get_settings
from app.core.exceptions import WebpayError
from app.integrations.webpay.client import WebpayClient
from app.repositories import (
    checkouts_repo,
    detalles_pedido_repo,
    direcciones_repo,
    envios_repo,
    pagos_repo,
    pedidos_repo,
    productos_repo,
)
from app.routers.deps import puede_acceder_pedido
from app.schemas.webpay import DireccionSnapshot, IniciarRequest
from app.services.email_service import enviar_pendiente

TARIFA = Decimal("3500.00")
FEE = Decimal("0.05")
IVA = Decimal("0.19")
CENT = Decimal("0.01")
logger = logging.getLogger(__name__)
UNIDADES_FRACCIONABLES = {"kg", "g", "litro", "ml"}


def _reglas_cantidad_producto(product: Any) -> tuple[Decimal, Decimal]:
    """Obtiene mínimo e incremento y conserva el fallback de publicaciones antiguas."""
    unidad = str(product.get("unidad_medida") or "unidad")
    paso_historico = Decimal("0.1") if unidad in UNIDADES_FRACCIONABLES else Decimal("1")
    incremento = Decimal(str(product.get("incremento_venta") or paso_historico))
    minimo = Decimal(str(product.get("cantidad_minima_compra") or incremento))
    return incremento, minimo


def _cantidad_legible(cantidad: Decimal) -> str:
    return format(cantidad.normalize(), "f")


async def _items_checkout(conn: Any, items: Any) -> dict[UUID, list[dict[str, Any]]]:
    quantities: dict[UUID, Decimal] = {}
    for item in items:
        quantities[item.producto_id] = quantities.get(item.producto_id, Decimal(0)) + item.cantidad
    products = await productos_repo.get_by_ids_for_update(conn, list(quantities))
    if len(products) != len(quantities):
        raise HTTPException(400, "Producto no encontrado")
    result: dict[UUID, list[dict[str, Any]]] = {}
    for product in products:
        cantidad = quantities[product["id"]]
        unidad = str(product.get("unidad_medida") or "unidad")
        incremento, minimo = _reglas_cantidad_producto(product)
        if product.get("unidad_medida") in {"unidad", "bandeja", "caja", "docena"} and (
            cantidad != cantidad.to_integral_value()
        ):
            raise HTTPException(400, "Este producto requiere una cantidad entera")
        if cantidad < minimo:
            raise HTTPException(
                400,
                f"La compra mínima de este producto es {_cantidad_legible(minimo)} {unidad}",
            )
        if cantidad % incremento != 0:
            mensaje_incremento = (
                f"Este producto se vende en incrementos de {_cantidad_legible(incremento)} {unidad}"
            )
            raise HTTPException(
                400,
                mensaje_incremento,
            )
        if not product["activo"] or product["eliminado_en"] is not None:
            raise HTTPException(400, "Producto inactivo")
        # Disponible considera las retenciones de otros checkouts en curso.
        disponible = max(product["stock"] - product["stock_reservado"], Decimal(0))
        if disponible < cantidad:
            raise HTTPException(
                400, f"Stock insuficiente: sólo hay {disponible.normalize()} unidades disponibles"
            )
        result.setdefault(product["productor_id"], []).append(
            {
                "producto_id": product["id"],
                "producto_nombre": product["nombre"],
                "codigo_producto": product.get("codigo_producto"),
                # Se congela la unidad en el detalle para que el pedido no
                # dependa del producto actual ni muestre "undefined".
                "unidad": (str(product["unidad_medida"]) if product.get("unidad_medida") else None),
                "precio_unitario": product["precio"],
                "cantidad": cantidad,
                "subtotal": (product["precio"] * cantidad).quantize(CENT, ROUND_HALF_UP),
            }
        )
    return result


async def _reservar_stock(
    conn: Any, checkout_id: UUID, groups: dict[UUID, list[dict[str, Any]]]
) -> None:
    """Retiene temporalmente las unidades del checkout (RF-002 y RF-005).

    disponible = stock - stock_reservado. El UPDATE condicional del repo es
    atómico: si otro checkout comprometió ya las unidades, la reserva falla y
    el comprador recibe 409. La retención vive en private.checkout_reservas y
    se libera al confirmar (autorizado, parcial o rechazado) o al vencer el
    plazo RESERVA_STOCK_MINUTOS vía private.liberar_reservas_expiradas().
    """
    for items in groups.values():
        for item in items:
            if not await checkouts_repo.reservar(
                conn, checkout_id, item["producto_id"], item["cantidad"]
            ):
                raise HTTPException(
                    409,
                    "El stock fue reservado por otro comprador mientras se procesaba "
                    "tu pedido. Reduce la cantidad o reintenta en unos minutos.",
                )


async def _snapshot(conn: Any, user_id: UUID, req: IniciarRequest) -> dict[str, Any]:
    address = await direcciones_repo.get_by_id_and_perfil(conn, req.direccion_id, user_id)
    if address is None:
        raise HTTPException(400, "Dirección inválida, inactiva o ajena")
    profile = await conn.fetchrow(
        "SELECT nombre, apellido, telefono FROM public.perfiles WHERE id=$1", user_id
    )
    nombre = req.nombre_destinatario or " ".join(
        filter(None, [profile["nombre"], profile["apellido"]])
    )
    telefono = req.telefono_destinatario or profile["telefono"]
    if not telefono or not telefono.strip():
        raise HTTPException(400, "El destinatario debe tener teléfono")
    direccion = " ".join(
        filter(None, [address["calle"], address["numero"], address["depto_oficina"]])
    )
    if not direccion.strip() or len(direccion) > 500:
        raise HTTPException(400, "Dirección inválida")
    direccion = DireccionSnapshot(direccion_entrega=direccion).direccion_entrega
    referencia = (
        req.referencia_entrega
        if "referencia_entrega" in req.model_fields_set
        else address["referencia"]
    )
    return {
        "region_id": address["region_id"],
        "comuna_id": address["comuna_id"],
        "direccion": direccion,
        "nombre_destinatario": nombre,
        "telefono_destinatario": telefono.strip(),
        "referencia_entrega": referencia,
    }


def _order(prefix: str) -> str:
    return prefix + uuid4().hex[:25]


def _detail(amount: int, commerce_code: str, prefix: str) -> dict[str, Any]:
    return {"amount": amount, "commerce_code": commerce_code, "buy_order": _order(prefix)}


async def _store(
    conn: Any,
    productor_id: UUID,
    items: list[dict[str, Any]],
    region: UUID,
    tasa_iva: Decimal = IVA,
) -> dict[str, Any]:
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", productor_id)
    productor = await direcciones_repo.get_activa_productor(conn, productor_id)
    if not productor or productor["region_id"] != region:
        raise HTTPException(400, "La dirección está fuera de la cobertura del productor")
    suspendido = await conn.fetchval(
        "SELECT servicio_suspendido FROM public.productores WHERE id=$1", productor_id
    )
    if suspendido:
        raise HTTPException(
            400,
            "La tienda del productor está suspendida por el servicio mensual impago",
        )
    code = await conn.fetchval(
        "SELECT codigo_comercio_mall FROM public.productores WHERE id=$1", productor_id
    )
    if not code:
        raise HTTPException(400, "El productor no tiene código de comercio Mall configurado")
    subtotal = sum((item["subtotal"] for item in items), Decimal(0))
    base_imponible = subtotal + TARIFA
    iva = (base_imponible * tasa_iva).quantize(Decimal(1), ROUND_HALF_UP)
    total = base_imponible + iva
    if total != total.to_integral_value():
        raise HTTPException(400, "Webpay requiere un total en pesos CLP enteros")
    fee = int((subtotal * FEE).quantize(Decimal(1), ROUND_HALF_UP))
    return {
        "productor_id": productor_id,
        "items": items,
        "subtotal_productos": subtotal,
        "tarifa_delivery": TARIFA,
        "tasa_iva": tasa_iva,
        "monto_iva": iva,
        "total": int(total),
        "fee": fee,
        "detail": _detail(int(total) - fee, code, "S"),
        "fee_detail": _detail(fee, get_settings().TRANSBANK_FEE_COMMERCE_CODE, "F")
        if fee
        else None,
    }


def _details(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        detail
        for store in snapshot["tiendas"]
        for detail in (store["detail"], store["fee_detail"])
        if detail
    ]


async def _tasa_iva_checkout(conn: Any) -> Decimal:
    """Obtiene la tasa para nuevos pagos desde el interruptor administrativo.

    Cada pedido guarda su propio snapshot (`tasa_iva`, `monto_iva`), por lo que
    activar o desactivar el IVA no altera ninguna compra ya iniciada o pagada.
    Si una instalación aún no aplicó la migración, se mantiene 19% por
    seguridad tributaria en vez de omitir el impuesto silenciosamente.
    """
    try:
        configuracion = await conn.fetchrow(
            "SELECT iva_habilitado, tasa_iva FROM public.configuracion_logistica WHERE id = 1"
        )
    except Exception:  # pragma: no cover - protección para despliegue escalonado
        logger.exception("No se pudo leer la configuración de IVA; se conserva 19%%")
        return IVA
    if not configuracion or not configuracion["iva_habilitado"]:
        return Decimal("0")
    tasa = Decimal(str(configuracion["tasa_iva"] if configuracion["tasa_iva"] is not None else IVA))
    return tasa if Decimal("0") <= tasa <= Decimal("1") else IVA


async def iniciar_checkout(conn: Any, user_id: UUID, req: IniciarRequest) -> dict[str, Any]:
    # Validar items y generar snapshot dentro de la transacción para bloquear
    # stock de forma atómica. La llamada HTTP a Transbank se hace FUERA de la
    # transacción para no mantener abierta una conexión de BD mientras se
    # espera la respuesta de la pasarela.
    async with conn.transaction():
        liberadas = await checkouts_repo.liberar_expiradas(conn)
        if liberadas:
            logger.info("Reservas de stock expiradas liberadas al iniciar: %s", liberadas)
        address = await _snapshot(conn, user_id, req)
        groups = await _items_checkout(conn, req.items)
        tasa_iva = await _tasa_iva_checkout(conn)
        stores = [
            await _store(conn, producer, items, address["region_id"], tasa_iva)
            for producer, items in groups.items()
        ]
        total = sum(store["total"] for store in stores)
        if req.monto_esperado is not None and req.monto_esperado != total:
            raise HTTPException(
                409, "El total cambió. Revisa y acepta el monto actualizado antes de pagar."
            )
        document = req.documento_tributario.model_dump()
        if document["tipo"] == "boleta":
            document["rut"] = "66666666-6"
        checkout: dict[str, Any] = {
            "id": uuid4(),
            "cliente_id": user_id,
            "buy_order": _order("M"),
            "session_id": uuid4().hex,
            "snapshot": {"direccion": address, "documento_tributario": document, "tiendas": stores},
            "reservas_expiran_en": datetime.now(UTC)
            + timedelta(minutes=get_settings().RESERVA_STOCK_MINUTOS),
        }
        await checkouts_repo.create(conn, checkout)
        await _reservar_stock(conn, checkout["id"], groups)

    # Llamada HTTP a Webpay fuera de la transacción de BD.
    try:
        result = await asyncio.to_thread(
            WebpayClient().create,
            checkout["buy_order"],
            checkout["session_id"],
            _details(checkout["snapshot"]),
            get_settings().TRANSBANK_RETURN_URL,
        )
    except WebpayError:
        # FL-07: la pasarela falló después de comprometer la reserva. El
        # checkout jamás tendrá token_ws, así que la retención se libera ya:
        # no tiene sentido bloquear stock hasta la expiración del plazo.
        async with conn.transaction():
            await checkouts_repo.liberar(conn, checkout["id"])
        raise
    if not result.get("token") or not result.get("url"):
        # Webpay no devolvió token válido: liberar reservas y marcar checkout fallido.
        async with conn.transaction():
            await checkouts_repo.liberar(conn, checkout["id"])
        raise WebpayError("Respuesta inválida de Webpay al crear transacción", status_code=502)

    async with conn.transaction():
        await checkouts_repo.set_token(conn, checkout["id"], result["token"])

    return {
        "checkout_id": checkout["id"],
        "buy_order": checkout["buy_order"],
        "token_ws": result["token"],
        "url": result["url"],
        "monto": total,
    }


def _schedule_emails(pedido: Any, tasks: BackgroundTasks) -> None:
    recipients: tuple[Literal["comprador", "productor"], ...] = ("comprador", "productor")
    for recipient in recipients:
        if pedido[f"correo_{recipient}_enviado_en"] is None:
            tasks.add_task(enviar_pendiente, pedido["id"], recipient)


async def _commit(token: str) -> dict[str, Any]:
    client = WebpayClient()
    try:
        return await asyncio.to_thread(client.commit, token)
    except WebpayError:
        return await asyncio.to_thread(client.status, token)


def _authorized(detail: dict[str, Any]) -> bool:
    return detail.get("status") == "AUTHORIZED" and detail.get("response_code") == 0


def _match_response(
    checkout: Any, snapshot: dict[str, Any], response: dict[str, Any]
) -> dict[str, dict[str, Any]]:
    if (
        response["buy_order"] != checkout["buy_order"]
        or response["session_id"] != checkout["session_id"]
    ):
        raise ValueError("Mall identity mismatch")
    expected = {d["buy_order"]: d for d in _details(snapshot)}
    details = response["details"]
    if not isinstance(details, list) or len(details) != len(expected):
        raise ValueError("Mall detail count mismatch")
    received = {}
    for detail in details:
        order = detail["buy_order"]
        item = expected[order]
        if (
            order in received
            or detail["commerce_code"] != item["commerce_code"]
            or Decimal(str(detail["amount"])) != Decimal(item["amount"])
        ):
            raise ValueError("Mall detail mismatch")
        if _authorized(detail):
            if not detail.get("authorization_code"):
                raise ValueError("Missing authorization")
        elif detail.get("status") not in ("FAILED", "REVERSED"):
            raise ValueError("Unresolved Mall detail")
        received[order] = detail
    return received


def _validate_response(
    checkout: Any, snapshot: dict[str, Any], response: dict[str, Any]
) -> dict[str, dict[str, Any]]:
    try:
        received = _match_response(checkout, snapshot, response)
    except (KeyError, TypeError, ValueError, ArithmeticError) as exc:
        # La petición del cliente es válida; lo que no se puede confiar es la
        # respuesta de la pasarela. Se informa como error de integración para
        # que el checkout quede disponible para conciliación/reintento.
        raise WebpayError("Respuesta de Webpay inválida o sin resolver", status_code=502) from exc
    return received


async def _save_order(
    conn: Any,
    checkout: Any,
    snapshot: dict[str, Any],
    store: dict[str, Any],
    detail: dict[str, Any],
) -> Any:
    address = dict(snapshot["direccion"])
    for key in ("region_id", "comuna_id"):
        address[key] = UUID(address[key])
    # `snapshot` se persiste como JSONB: al recargarlo los importes llegan como
    # strings, aunque en memoria fueran Decimal. Normalizarlos aquí evita que
    # el commit caiga con Decimal + str después de una autorización Webpay.
    subtotal_productos = Decimal(str(store["subtotal_productos"]))
    pedido = await pedidos_repo.create_pedido(
        conn,
        f"CTC-{datetime.now(UTC):%Y%m%d}-{uuid4().hex[:6].upper()}",
        checkout["cliente_id"],
        UUID(store["productor_id"]),
        tarifa=Decimal(str(store["tarifa_delivery"])),
        fee_porcentaje=FEE,
        checkout_id=checkout["id"],
        documento_tributario=json.dumps(snapshot["documento_tributario"]),
        subtotal_productos=subtotal_productos,
        tasa_iva=Decimal(str(store["tasa_iva"])),
        monto_iva=Decimal(str(store["monto_iva"])),
        **address,
    )
    items = []
    for original in store["items"]:
        item = dict(original)
        item["producto_id"] = UUID(item["producto_id"])
        for key in ("precio_unitario", "cantidad", "subtotal"):
            item[key] = Decimal(str(item[key]))
        items.append(item)
    await detalles_pedido_repo.bulk_create(conn, pedido["id"], items)
    await pagos_repo.create_pago(conn, pedido["id"], checkout, detail, store["fee"])
    return await pedidos_repo.update_estado(conn, pedido["id"], "pagado")


class StockReservationConflict(Exception):
    """La autorización tardía no puede consumir reservas de otro checkout."""


async def _check_confirmation_stock(
    conn: Any, checkout_id: UUID, snapshot: dict[str, Any], details: dict[str, dict[str, Any]]
) -> None:
    quantities: dict[UUID, Decimal] = {}
    for store in snapshot["tiendas"]:
        if not _authorized(details[store["detail"]["buy_order"]]):
            continue
        for item in store["items"]:
            product_id = UUID(item["producto_id"])
            quantities[product_id] = quantities.get(product_id, Decimal(0)) + Decimal(
                item["cantidad"]
            )
    products = await productos_repo.get_by_ids_for_update(conn, list(quantities))
    own_rows = await conn.fetch(
        "SELECT producto_id,cantidad FROM private.checkout_reservas WHERE checkout_id=$1",
        checkout_id,
    )
    own = {row["producto_id"]: row["cantidad"] for row in own_rows}
    if len(products) != len(quantities):
        raise StockReservationConflict("Missing product for authorized checkout")
    for product in products:
        available = (
            product["stock"] - product["stock_reservado"] + own.get(product["id"], Decimal(0))
        )
        if quantities[product["id"]] > available:
            raise StockReservationConflict("Authorized checkout conflicts with another reservation")


async def _finalize(conn: Any, checkout: Any, response: dict[str, Any]) -> dict[str, Any]:
    snapshot = json.loads(checkout["snapshot"])
    details = _validate_response(checkout, snapshot, response)
    # Considerar sólo reservas propias, conservando el bloqueo hasta guardar pedidos.
    await _check_confirmation_stock(conn, checkout["id"], snapshot, details)
    pedidos = []
    reconciliation = False
    for store in snapshot["tiendas"]:
        detail = details[store["detail"]["buy_order"]]
        paid = _authorized(detail)
        fee_paid = (
            _authorized(details[store["fee_detail"]["buy_order"]]) if store["fee_detail"] else paid
        )
        reconciliation |= paid != fee_paid
        if paid:
            pedido = await _save_order(conn, checkout, snapshot, store, detail)
            pedidos.append(
                {
                    "pedido_id": pedido["id"],
                    "codigo_pedido": pedido["codigo_pedido"],
                    "productor_id": pedido["productor_id"],
                    "estado_pedido": pedido["estado"],
                    "total": pedido["total"],
                    # El retorno de Webpay puede ocurrir antes de que el SDK
                    # restaure la sesión. El resumen de compra debe poder
                    # identificarse igualmente, sin una segunda consulta RLS.
                    "productos": [
                        {
                            "producto_id": item["producto_id"],
                            "codigo_producto": item.get("codigo_producto"),
                            "producto_nombre": item["producto_nombre"],
                        }
                        for item in store["items"]
                    ],
                }
            )
    all_paid = all(_authorized(d) for d in details.values())
    any_paid = any(_authorized(d) for d in details.values())
    result = {
        "ok": all_paid,
        "checkout_id": checkout["id"],
        "pedidos": pedidos,
        "estado": "autorizado" if all_paid else "parcial" if any_paid else "rechazado",
        "requiere_conciliacion": reconciliation,
        "ya_confirmado": False,
    }
    await checkouts_repo.finish(conn, checkout["id"], response, result)
    return result


async def confirmar_checkout(
    conn: Any, token_ws: str, background_tasks: BackgroundTasks, user: dict[str, Any] | None = None
) -> dict[str, Any]:
    persistence_failed = False
    result: dict[str, Any] | None = None
    async with conn.transaction():
        # Segunda pasada de limpieza: el plazo puede haber vencido entre el
        # inicio del checkout y su retorno desde Webpay.
        liberadas = await checkouts_repo.liberar_expiradas(conn)
        if liberadas:
            logger.info("Reservas de stock expiradas liberadas al confirmar: %s", liberadas)
        checkout = await checkouts_repo.lock(conn, token_ws)
        if checkout is None:
            raise HTTPException(404, "Token no encontrado")
        if user is not None and checkout["cliente_id"] != user["id"] and user["role"] != "admin":
            raise HTTPException(403, "No puedes acceder a este checkout")
        if checkout["resultado"] is not None:
            result = json.loads(checkout["resultado"])
            result["ya_confirmado"] = True
        else:
            response = (
                json.loads(checkout["respuesta"])
                if checkout["respuesta"]
                else await _commit(token_ws)
            )
            _validate_response(checkout, json.loads(checkout["snapshot"]), response)
            await checkouts_repo.save_response(conn, checkout["id"], response)
            try:
                # Keep the remote receipt even if stock or another local constraint fails.
                async with conn.transaction():
                    result = await _finalize(conn, checkout, response)
                # El checkout terminó de manera definitiva (pagado, parcial o
                # rechazado): libera las retenciones del snapshot. Idempotente
                # en la base de datos; en persistencia fallida quedan retenidas
                # hasta su expiración para no perder la retención al conciliar.
                await checkouts_repo.liberar(conn, checkout["id"])
            except (asyncpg.PostgresError, StockReservationConflict):
                persistence_failed = True
                # NO se escribe `resultado` aquí: la respuesta de Webpay ya quedó
                # persistida por save_response, y eso es lo que impide llamar dos
                # veces al commit en un reintento. Dejar resultado en NULL permite
                # que el reintento re-ejecute _finalize con la respuesta guardada
                # (CK-0127: autorización tardía que no puede consumir reservas
                # ajenas se reintenta cuando el stock vuelve a estar disponible).
                # "pendiente_reconciliacion" tampoco es un estado válido de
                # ConfirmarResponse, por lo que marcarlo provocaría un 500 en el
                # replay. Las reservas quedan retenidas hasta su expiración.
                logger.exception(  # noqa: TRY400 - no SQL parameters or customer data in logs
                    "Checkout %s pendiente de conciliación/persistencia", checkout["id"]
                )
        orders = await conn.fetch(
            "SELECT * FROM public.pedidos WHERE checkout_id=$1", checkout["id"]
        )
    if persistence_failed:
        raise WebpayError(
            "Autorización de Webpay guardada; los pedidos locales requieren reconciliación",
            status_code=502,
        )
    if result is None:
        raise WebpayError("Resultado de checkout no disponible", status_code=500)
    for order in orders:
        _schedule_emails(order, background_tasks)
    return result


async def get_estado(
    conn: Any,
    pedido_id: UUID,
    user: dict[str, Any],
    background_tasks: BackgroundTasks | None = None,
) -> dict[str, Any]:
    pedido = await puede_acceder_pedido(pedido_id, user, conn)
    pago = await pagos_repo.get_by_pedido(conn, pedido_id)
    envio = await envios_repo.get_by_pedido(conn, pedido_id)
    if background_tasks is not None:
        # Reintento liviano de correos: cada consulta de estado re-agenda
        # los envios cuyo flag siga en NULL. enviar_pendiente es idempotente
        # (bandera + clave de idempotencia de Brevo), no duplica mensajes.
        _schedule_emails(pedido, background_tasks)
    return {
        "pedido_id": pedido_id,
        "codigo_pedido": pedido["codigo_pedido"],
        "estado_pedido": pedido["estado"],
        "estado_pago": "autorizado" if pago else None,
        "monto_productor": pago["monto"] if pago else None,
        "total": pedido["total"],
        "envio": dict(envio) if envio else None,
    }
