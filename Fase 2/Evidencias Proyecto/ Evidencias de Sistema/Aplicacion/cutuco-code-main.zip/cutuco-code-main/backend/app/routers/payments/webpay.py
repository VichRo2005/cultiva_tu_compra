import json
import logging
from decimal import Decimal
from pathlib import Path
from typing import Any
from urllib.parse import urlencode
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse, StreamingResponse

from app.core.config import get_settings
from app.core.exceptions import WebpayError
from app.db.session import get_connection
from app.integrations.email.client import AUDIT_DIR
from app.repositories import detalles_pedido_repo, pedidos_repo
from app.routers.deps import get_current_user, get_current_user_optional, require_role
from app.schemas.webpay import (
    ConfirmarRequest,
    ConfirmarResponse,
    EstadoResponse,
    IniciarRequest,
    IniciarResponse,
)
from app.services import webpay_service
from app.services.pdf_service import generar_pdf_pedido

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/webpay", tags=["webpay"])


@router.post("/iniciar", response_model=IniciarResponse)
async def iniciar(
    req: IniciarRequest,
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> Any:
    return await webpay_service.iniciar_checkout(conn, user["id"], req)


@router.post("/confirmar", response_model=ConfirmarResponse)
async def confirmar(
    req: ConfirmarRequest,
    background_tasks: BackgroundTasks,
    conn: Any = Depends(get_connection),
    # Tras volver desde la pasarela el navegador puede llegar antes de que el
    # SDK de Supabase restaure la sesión. El token Webpay es opaco y se valida
    # contra el checkout; si hay JWT, el servicio igualmente verifica que sea
    # su dueño (o un admin).
    user: dict[str, Any] | None = Depends(get_current_user_optional),
) -> Any:
    return await webpay_service.confirmar_checkout(conn, req.token_ws, background_tasks, user)


@router.get("/estado/{pedido_id}", response_model=EstadoResponse)
async def estado(
    pedido_id: UUID,
    background_tasks: BackgroundTasks,
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> Any:
    return await webpay_service.get_estado(conn, pedido_id, user, background_tasks)


@router.get("/comprobante/{pedido_id}/pdf")
async def comprobante_pdf(
    pedido_id: UUID,
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> StreamingResponse:
    """Devuelve el comprobante de compra; no sustituye un documento tributario."""
    pedido = await pedidos_repo.get_by_id(conn, pedido_id)
    if not pedido:
        raise HTTPException(404, "Pedido no encontrado")
    if pedido["cliente_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(403, "No puedes acceder a este comprobante")

    pedido = dict(pedido)
    if isinstance(pedido.get("documento_tributario"), str):
        pedido["documento_tributario"] = json.loads(pedido["documento_tributario"])

    items = await detalles_pedido_repo.get_by_pedido(conn, pedido_id)
    pago = await conn.fetchrow("SELECT * FROM public.pagos WHERE pedido_id=$1", pedido_id)

    # Datos reales del comprador y del vendedor para el comprobante (los items
    # ya traen codigo_producto y unidad congelados desde detalles_pedido).
    # El contexto trae también RUT oficial, región y dirección activa del
    # productor, que el PDF muestra en "Datos del vendedor" (antes vacío).
    contexto = await pedidos_repo.get_email_context(conn, pedido_id)
    cliente = dict(contexto) if contexto is not None else None
    productor = dict(contexto) if contexto is not None else None

    pdf_bytes = generar_pdf_pedido(
        pedido=pedido,
        cliente=cliente,
        productor=productor,
        direccion=pedido,
        items=[dict(item) for item in items],
        total=Decimal(str(pedido.get("total", 0))),
        tarifa_delivery=Decimal(str(pedido.get("tarifa_delivery", 0))),
        tipo_documento=(pedido.get("documento_tributario") or {}).get("tipo", "boleta"),
        datos_tributarios=(pedido.get("documento_tributario") or {})
        if (pedido.get("documento_tributario") or {}).get("tipo") == "factura"
        else None,
        codigo_comercio=pago.get("codigo_comercio") if pago else None,
        codigo_autorizacion=pago.get("codigo_autorizacion") if pago else None,
        fecha_pago=str(pago.get("autorizado_en")) if pago and pago.get("autorizado_en") else None,
    )

    nombre = f"comprobante-{pedido.get('codigo_pedido', pedido_id)}.pdf"
    return StreamingResponse(
        iter([pdf_bytes]),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{nombre}"'},
    )


@router.get("/emails")
def listar_emails_generados(
    user: dict[str, Any] = Depends(require_role("admin")),
) -> dict[str, Any]:
    """Lista los emails generados por el stub de Brevo (solo desarrollo/local).

    Devuelve el nombre del archivo, destinatario, asunto y si tiene adjunto PDF,
    para verificar que el correo de confirmación de compra se está generando.
    """
    if get_settings().ENVIRONMENT not in {"development", "test"}:
        raise HTTPException(404, "Recurso no disponible")
    # El mismo directorio que usa EmailClient (respeta CUTUCO_EMAIL_AUDIT_DIR).
    emails_dir = Path(AUDIT_DIR)
    if not emails_dir.is_dir():
        return {"emails": [], "directorio": str(emails_dir), "existe": False}

    emails = []
    for path in sorted(emails_dir.glob("*.json"), reverse=True):
        try:
            with path.open(encoding="utf-8") as f:
                data = json.load(f)
            attachment = data.get("attachment") or []
            destinatarios = data.get("para") or data.get("to") or []
            if isinstance(destinatarios, list):
                destinatario = destinatarios[0].get("email") if destinatarios else None
            else:
                destinatario = destinatarios
            emails.append(
                {
                    "archivo": path.name,
                    "para": destinatario,
                    "asunto": data.get("asunto") or data.get("subject"),
                    "enviado": data.get("enviado"),
                    "message_id": data.get("message_id"),
                    "error": data.get("error"),
                    "tiene_pdf": any(att.get("type") == "application/pdf" for att in attachment),
                    # Sólo metadatos: nunca la ruta del archivo en el servidor.
                    "adjuntos": [
                        {
                            "name": att.get("name"),
                            "type": att.get("type"),
                            "size_bytes": att.get("size_bytes"),
                        }
                        for att in attachment
                    ],
                    "timestamp": data.get("timestamp") or data.get("_stub_timestamp"),
                }
            )
        except Exception:
            emails.append({"archivo": path.name, "error": "no se pudo leer"})
    return {"emails": emails, "directorio": str(emails_dir), "existe": True}


@router.get("/retorno")
@router.post("/retorno")
async def retorno_transbank(
    request: Request,
    background_tasks: BackgroundTasks,
    conn: Any = Depends(get_connection),
) -> RedirectResponse:
    """Retorno del navegador desde Webpay Mall Plus (`TRANSBANK_RETURN_URL`).

    Transbank devuelve el control al navegador con un **POST** del formulario (la
    especificación admite además GET) a la URL configurada en
    `TRANSBANK_RETURN_URL`. En producción esa URL debe apuntar directamente a
    este endpoint público de Cloud Run. El endpoint confirma el pago y devuelve
    al navegador a la ruta del historial del cliente en el frontend por GET.
    En desarrollo Vite puede conservar un proxy hacia este mismo endpoint.

    Escenarios de parámetros (los cuatro documentados por Transbank):

    1. Sólo `token_ws` — pago normal: se ejecuta el commit.
    2. `TBK_ID_SESION` + `TBK_ORDEN_COMPRA`, sin token — la sesión de pago expiró
       (más de 10 minutos) y la transacción se revierte sola: no se confirma.
    3. Sólo `TBK_TOKEN` + `TBK_ORDEN_COMPRA` — el usuario anuló el pago.
    4. `token_ws` **y** `TBK_TOKEN` a la vez — transacción inválida: NO se confirma.

    No exige JWT: lo invoca el navegador redirigido por Transbank, sin cabecera
    `Authorization`. La autorización real vive en `confirmar_checkout`
    (checkout privado bloqueado y validación de cada subtransacción de Transbank).
    """
    form = request.query_params if request.method == "GET" else await request.form()
    token = str(form.get("token_ws") or "").strip()
    token_anulado = str(form.get("TBK_TOKEN") or "").strip()

    if token and not token_anulado:
        try:
            await webpay_service.confirmar_checkout(conn, token, background_tasks, None)
        except HTTPException as exc:
            # El navegador ya salió de la pasarela: el aviso se muestra en la SPA
            # en lugar de devolver un JSON de error a una navegación de formulario.
            logger.warning("Retorno Webpay sin confirmar: %s", exc.detail)
        except WebpayError:
            logger.warning("Retorno Webpay sin confirmar: fallo del commit")
    elif token and token_anulado:
        logger.warning("Retorno Webpay inválido: token_ws y TBK_TOKEN simultáneos")

    destino = f"{get_settings().FRONTEND_URL.rstrip('/')}/cliente/pedidos"
    parametros = {
        clave: valor
        for clave, valor in (
            ("token_ws", token),
            ("TBK_TOKEN", token_anulado),
            ("TBK_ORDEN_COMPRA", str(form.get("TBK_ORDEN_COMPRA") or "").strip()),
            ("TBK_ID_SESION", str(form.get("TBK_ID_SESION") or "").strip()),
        )
        if valor
    }
    if parametros:
        destino = f"{destino}?{urlencode(parametros)}"
    return RedirectResponse(destino, status_code=303)
