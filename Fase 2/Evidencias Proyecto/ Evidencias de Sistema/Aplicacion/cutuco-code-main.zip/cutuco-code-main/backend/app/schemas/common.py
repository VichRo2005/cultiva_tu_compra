from enum import Enum


class EstadoPedido(str, Enum):
    creado = "creado"
    pagado = "pagado"
    en_preparacion = "en_preparacion"
    completado = "completado"
    reclamado = "reclamado"
    cancelado = "cancelado"


class EstadoEnvio(str, Enum):
    preparacion = "preparacion"
    en_transito = "en_transito"
    entregado = "entregado"
    fallido = "fallido"
