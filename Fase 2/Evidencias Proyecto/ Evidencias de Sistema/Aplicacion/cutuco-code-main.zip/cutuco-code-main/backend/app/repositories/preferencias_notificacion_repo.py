"""Consulta de preferencias de entrega para los correos operativos."""

from typing import Any
from uuid import UUID


async def recibe_correo(conn: Any, perfil_id: UUID | None) -> bool:
    """Devuelve el canal de correo elegido; una fila ausente mantiene el default activo."""
    if perfil_id is None:
        return True
    row = await conn.fetchrow(
        """
        SELECT recibir_correo
        FROM public.preferencias_notificacion
        WHERE perfil_id = $1
        """,
        perfil_id,
    )
    return row is None or bool(row["recibir_correo"])
