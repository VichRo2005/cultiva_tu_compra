from typing import Any

from transbank.common.integration_type import IntegrationType
from transbank.common.options import WebpayOptions
from transbank.webpay.webpay_plus.transaction import Transaction

from app.core.config import get_settings
from app.core.exceptions import WebpayError


class WebpayPlusClient:
    """Webpay Plus simple para el cobro mensual del servicio de CuTuCo."""

    def __init__(self) -> None:
        settings = get_settings()
        environment = (
            IntegrationType.LIVE if settings.TRANSBANK_ENV == "production" else IntegrationType.TEST
        )
        self.tx = Transaction(
            WebpayOptions(
                settings.TRANSBANK_SERVICIO_COMMERCE_CODE,
                settings.TRANSBANK_SERVICIO_API_KEY,
                environment,
            )
        )

    def create(
        self, buy_order: str, session_id: str, amount: int, return_url: str
    ) -> dict[str, Any]:
        try:
            result: dict[str, Any] = self.tx.create(buy_order, session_id, amount, return_url)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay Plus al crear transacción", status_code=502) from exc
        if not result.get("token") or not result.get("url"):
            raise WebpayError("Respuesta inválida de Webpay Plus al crear", status_code=502)
        return result

    def status(self, token_ws: str) -> dict[str, Any]:
        try:
            result: dict[str, Any] = self.tx.status(token_ws)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay Plus al consultar estado", status_code=502) from exc
        return result

    def commit(self, token_ws: str) -> dict[str, Any]:
        try:
            result: dict[str, Any] = self.tx.commit(token_ws)
        except Exception as exc:
            raise WebpayError("Fallo de Webpay Plus al confirmar transacción", status_code=502) from exc
        return result
