import asyncio
import time
from typing import Any
from uuid import UUID

import httpx
import jwt
from fastapi import HTTPException

from app.core.config import get_settings

JWKS_TTL = 600
_jwks_cache: dict[str, tuple[float, dict[str, Any]]] = {}
_jwks_lock = asyncio.Lock()


def unauthorized() -> HTTPException:
    return HTTPException(401, "Token inválido o expirado", headers={"WWW-Authenticate": "Bearer"})


async def get_jwks(*, force_refresh: bool = False) -> dict[str, Any]:
    url = get_settings().jwks_url
    async with _jwks_lock:
        cached = _jwks_cache.get(url)
        age = time.monotonic() - cached[0] if cached else JWKS_TTL
        # Bound requests for unknown kids while allowing rotation before TTL expiry.
        if cached and age < JWKS_TTL and (not force_refresh or age < 5):
            return cached[1]
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.get(url)
            response.raise_for_status()
            data: dict[str, Any] = response.json()
        if not isinstance(data, dict) or not isinstance(data.get("keys"), list):
            raise TypeError("Invalid JWKS")
        data["keys_by_kid"] = {
            key["kid"]: key
            for key in data["keys"]
            if isinstance(key, dict) and isinstance(key.get("kid"), str)
        }
        _jwks_cache[url] = (time.monotonic(), data)
        return data


def signing_key(jwks: dict[str, Any], kid: str) -> dict[str, Any] | None:
    if "keys_by_kid" not in jwks:
        jwks["keys_by_kid"] = {
            key["kid"]: key
            for key in jwks["keys"]
            if isinstance(key, dict) and isinstance(key.get("kid"), str)
        }
    keys: dict[str, dict[str, Any]] = jwks["keys_by_kid"]
    return keys.get(kid)


async def validate_token(token: str) -> dict[str, Any]:
    settings = get_settings()
    try:
        header = jwt.get_unverified_header(token)
        if header.get("alg") != "ES256" or not header.get("kid"):
            raise jwt.InvalidTokenError("Expected ES256 and kid")
        jwks = await get_jwks()
        key = signing_key(jwks, header["kid"])
        if key is None:
            jwks = await get_jwks(force_refresh=True)
            key = signing_key(jwks, header["kid"])
        if key is None or key.get("kty") != "EC" or key.get("crv") != "P-256":
            raise jwt.InvalidTokenError("Unknown signing key")
        if key.get("use", "sig") != "sig" or key.get("alg", "ES256") != "ES256":
            raise jwt.InvalidTokenError("Invalid key use")
        claims: dict[str, Any] = jwt.decode(
            token,
            jwt.PyJWK.from_dict(key).key,
            algorithms=["ES256"],
            audience="authenticated",
            issuer=settings.issuer,
            options={"require": ["sub", "exp", "iss", "aud"]},
        )
        UUID(claims["sub"])
    except (jwt.PyJWTError, httpx.HTTPError, ValueError, TypeError, KeyError):
        if settings.ENVIRONMENT == "development" and settings.AUTH_DEV_FALLBACK:
            return await _gotrue_user(token)
        raise unauthorized()
    else:
        return claims


async def _gotrue_user(token: str) -> dict[str, Any]:
    # GoTrue GET /user is the HTTP equivalent of supabase.auth.get_user(token).
    settings = get_settings()
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.get(
                f"{settings.issuer}/user",
                headers={"apikey": settings.SUPABASE_ANON_KEY, "Authorization": f"Bearer {token}"},
            )
            response.raise_for_status()
            user = response.json()
        return {"sub": str(UUID(user["id"])), "email": user.get("email", "")}
    except (httpx.HTTPError, ValueError, TypeError, KeyError):
        raise unauthorized()
