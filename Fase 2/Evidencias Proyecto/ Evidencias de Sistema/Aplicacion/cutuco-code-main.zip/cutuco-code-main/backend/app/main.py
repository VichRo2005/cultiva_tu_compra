from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import RequestResponseEndpoint

from app.core.config import get_settings
from app.core.exceptions import register_exception_handlers
from app.db.session import close_pool, init_pool
from app.routers.auth import router as auth_router
from app.routers.datos_bancarios import router as datos_bancarios_router
from app.routers.payments.webpay import router
from app.routers.postulaciones import router as postulaciones_router
from app.routers.servicio import router as servicio_router
from app.routers.tributario import router as tributario_router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    await init_pool()
    try:
        yield
    finally:
        await close_pool()


def create_app() -> FastAPI:
    application = FastAPI(title="CuTuCo Webpay", lifespan=lifespan)

    @application.middleware("http")
    async def private_cache(request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        if request.url.path.startswith(("/api/", "/datos-bancarios")):
            response.headers["Cache-Control"] = "no-store"
            response.headers["Referrer-Policy"] = "no-referrer"
        return response

    settings = get_settings()
    # CORS explícito. En desarrollo se aceptan tanto localhost como 127.0.0.1:
    # el navegador distingue ambos orígenes y el frontend puede abrirse desde
    # cualquiera de los dos (la API y el sitio se sirven en puertos distintos).
    origins = {settings.FRONTEND_URL.rstrip("/")}
    if settings.ENVIRONMENT in {"development", "test"}:
        origins.update(
            {
                "http://localhost:5173",
                "http://127.0.0.1:5173",
                "http://localhost:4173",
                "http://127.0.0.1:4173",
            }
        )
    application.add_middleware(
        CORSMiddleware,
        allow_origins=sorted(origins),
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )
    application.include_router(router)
    application.include_router(auth_router)
    application.include_router(servicio_router)
    application.include_router(datos_bancarios_router)
    application.include_router(tributario_router)
    application.include_router(postulaciones_router)
    register_exception_handlers(application)
    return application


app = create_app()


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}
