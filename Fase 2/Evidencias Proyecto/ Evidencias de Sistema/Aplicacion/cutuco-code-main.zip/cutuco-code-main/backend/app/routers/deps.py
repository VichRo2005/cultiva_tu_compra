from collections.abc import Awaitable, Callable
from typing import Any
from uuid import UUID

from fastapi import Depends, HTTPException, Request

from app.core.security import unauthorized, validate_token
from app.db.session import get_connection
from app.repositories import pedidos_repo


async def get_current_user(request: Request, conn: Any = Depends(get_connection)) -> dict[str, Any]:
    scheme, _, token = request.headers.get("Authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        raise unauthorized()
    claims = await validate_token(token.strip())
    user_id = UUID(claims["sub"])
    profile = await conn.fetchrow("SELECT rol, activo FROM public.perfiles WHERE id=$1", user_id)
    if not profile or not profile["activo"]:
        raise unauthorized()
    return {
        "id": user_id,
        "perfil_id": user_id,
        "role": profile["rol"],
        "rol": profile["rol"],
        "email": claims.get("email", ""),
        "token": token.strip(),
    }


async def get_current_user_optional(
    request: Request, conn: Any = Depends(get_connection)
) -> dict[str, Any] | None:
    if "Authorization" not in request.headers:
        return None
    return await get_current_user(request, conn)


def require_role(*roles: str) -> Callable[..., Awaitable[dict[str, Any]]]:
    async def dependency(user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
        if user["role"] not in roles:
            raise HTTPException(403, "Rol no autorizado")
        return user

    return dependency


require_rol = require_role


async def puede_acceder_pedido(pedido_id: UUID, user: dict[str, Any], conn: Any) -> Any:
    pedido = await pedidos_repo.get_by_id(conn, pedido_id)
    if pedido is None:
        raise HTTPException(404, "Pedido no encontrado")
    if pedido["cliente_id"] != user["id"]:
        admin = await conn.fetchval(
            "SELECT rol FROM public.perfiles WHERE id=$1 AND rol='admin' AND activo=true",
            user["id"],
        )
        if admin is None:
            raise HTTPException(403, "No puedes acceder a este pedido")
    return pedido
