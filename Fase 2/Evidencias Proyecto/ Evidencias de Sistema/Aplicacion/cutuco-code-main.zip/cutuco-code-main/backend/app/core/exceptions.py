import logging

import asyncpg
from fastapi import FastAPI, Request
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException

logger = logging.getLogger(__name__)

# Mensajes funcionales por CHECK de PostgreSQL. Nunca se devuelve el SQL ni el
# nombre interno de la restricción al cliente.
CHECK_DETAILS: dict[str, tuple[int, str]] = {
    "ck_producto_precio_maximo": (
        422,
        "El precio supera el máximo permitido (999.999 CLP)",
    ),
    "ck_producto_stock_maximo": (
        422,
        "El stock supera el máximo permitido (999.999.999,999 unidades)",
    ),
    "ck_producto_stock_reservado_maximo": (
        422,
        "El stock reservado supera el máximo permitido",
    ),
    "ck_envio_fallo_motivo_largo": (
        422,
        "La justificación de la entrega fallida no puede superar 1000 caracteres",
    ),
    "ck_pedido_cancelacion_largo": (
        422,
        "La justificación de cancelación no puede superar 1000 caracteres",
    ),
    "ck_dato_bancario_digitos": (
        422,
        "El número de cuenta debe tener entre 7 y 12 dígitos",
    ),
    "ck_dato_bancario_hash_largo": (
        400,
        "La huella del número de cuenta no es válida",
    ),
    "ck_dato_bancario_hash_coherente": (
        422,
        "No se pudo validar el número de cuenta bancaria",
    ),
    "ck_dato_bancario_cuenta_largo": (
        422,
        "El número de cuenta debe tener entre 7 y 12 dígitos",
    ),
}


class WebpayError(Exception):
    """Error de Transbank Webpay.

    Lleva un código de estado funcional y un motivo legible para distinguir
    rechazos del proveedor (400) de fallos de pasarela/red (502).
    """

    def __init__(
        self,
        message: str = "No fue posible completar la operación con Webpay",
        status_code: int = 502,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


async def validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
    # No devolver `input` en endpoints que reciben datos financieros: el cuerpo
    # del error podría acabar en logs/proxies con el número de cuenta completo.
    # Ojo: el router de datos bancarios se monta en "/datos-bancarios" (sin
    # prefijo /api), no en "/api/datos-bancarios".
    if request.url.path.startswith(("/api/webpay", "/datos-bancarios", "/api/datos-bancarios")):
        errors = [{name: error[name] for name in ("loc", "msg", "type")} for error in exc.errors()]
        return JSONResponse({"detail": errors}, status_code=422)
    return await request_validation_exception_handler(request, exc)


async def http_error(request: Request, exc: HTTPException) -> JSONResponse:
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)


def _unique_detail(exc: asyncpg.UniqueViolationError) -> tuple[int, str]:
    constraint = (exc.constraint_name or "").lower()
    if "datos_bancarios" in constraint:
        return 409, "Ya existe una cuenta bancaria registrada con los mismos datos"
    if "slug" in constraint:
        return 409, (
            "Ya existe una tienda o producto con una dirección similar. "
            "Ajusta el nombre e inténtalo de nuevo."
        )
    if "nombre_comercial" in constraint:
        return 409, "Ya existe una tienda con ese nombre comercial. Elige otro nombre."
    return 409, "Ya existe un registro con esos datos"


def _database_detail(exc: Exception) -> tuple[int, str]:  # noqa: PLR0911, PLR0912
    message = (getattr(exc, "message", None) or str(exc) or "").lower()
    sqlstate = getattr(exc, "sqlstate", None)

    if sqlstate == "42501":
        # Los triggers propios usan 42501 para autorización funcional.
        return 403, getattr(exc, "message", None) or "No tienes permiso para realizar esta acción"
    if sqlstate == "23505" and isinstance(exc, asyncpg.UniqueViolationError):
        return _unique_detail(exc)
    if sqlstate == "23503":
        return 400, "La operación hace referencia a un registro que no existe"
    if sqlstate == "23502":
        return 400, "Falta un campo obligatorio"
    if sqlstate == "22003":
        return 422, "El valor numérico excede el máximo permitido"
    if sqlstate == "22001":
        return 422, "Uno de los campos de texto supera la longitud máxima permitida"
    if sqlstate == "23514" or isinstance(exc, asyncpg.CheckViolationError):
        constraint = (getattr(exc, "constraint_name", None) or "").lower()
        if constraint in CHECK_DETAILS:
            return CHECK_DETAILS[constraint]
        if "stock" in message:
            return 400, "Stock insuficiente"
        if "region" in message or "comuna" in message or "direccion activa" in message:
            return 400, "La dirección está fuera de la cobertura del productor"
        return 400, "La operación incumple una restricción de datos"
    if sqlstate == "P0001":
        msg = getattr(exc, "message", None) or "La operación no es válida"
        if "ya existe una cuenta bancaria" in msg.lower():
            return 409, msg
        return 422, msg

    # Fallback histórico: mensajes que ya se traducían en la aplicación.
    if "stock" in message:
        return 400, "Stock insuficiente"
    if "region" in message or "comuna" in message or "direccion activa" in message:
        return 400, "La dirección está fuera de la cobertura del productor"
    return 400, "La operación incumple una restricción de datos"


async def database_error(request: Request, exc: Exception) -> JSONResponse:
    status, detail = _database_detail(exc)
    return JSONResponse({"detail": detail}, status_code=status)


async def webpay_error(request: Request, exc: WebpayError) -> JSONResponse:
    return JSONResponse({"detail": exc.message}, status_code=exc.status_code)


async def unhandled_error(request: Request, exc: Exception) -> JSONResponse:
    """Handler global para errores no controlados (500).

    Nunca devuelve el traceback ni detalles internos al cliente, solo un
    mensaje genérico en español. El error completo queda en los logs del
    servidor para diagnóstico del operador.
    """
    logger.exception("Error no controlado en %s %s", request.method, request.url.path)
    return JSONResponse(
        {
            "detail": "Error interno del servidor. Intente nuevamente o contacte soporte."
        },
        status_code=500,
    )


def register_exception_handlers(app: FastAPI) -> None:
    app.add_exception_handler(RequestValidationError, validation_error)  # type: ignore[arg-type]
    app.add_exception_handler(HTTPException, http_error)  # type: ignore[arg-type]
    app.add_exception_handler(asyncpg.UniqueViolationError, database_error)
    app.add_exception_handler(asyncpg.CheckViolationError, database_error)
    app.add_exception_handler(asyncpg.RaiseError, database_error)
    app.add_exception_handler(asyncpg.PostgresError, database_error)
    app.add_exception_handler(WebpayError, webpay_error)  # type: ignore[arg-type]
    app.add_exception_handler(Exception, unhandled_error)
