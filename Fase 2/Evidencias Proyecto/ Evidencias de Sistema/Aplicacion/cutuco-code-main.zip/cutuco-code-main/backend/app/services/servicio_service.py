import asyncio
import logging
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

from fastapi import HTTPException

from app.core.config import (
    SERVICIO_SANDBOX_API_KEY,
    SERVICIO_SANDBOX_COMMERCE_CODE,
    get_settings,
)
from app.core.exceptions import WebpayError
from app.integrations.webpay.plus_client import WebpayPlusClient
from app.repositories import servicio_repo

logger = logging.getLogger(__name__)

MONTO_SERVICIO = 2990
VARIABLES_SERVICIO = (
    "TRANSBANK_SERVICIO_COMMERCE_CODE",
    "TRANSBANK_SERVICIO_API_KEY",
    "TRANSBANK_SERVICIO_RETURN_URL",
)


def _configuracion_faltante() -> list[str]:
    settings = get_settings()
    valores = {
        "TRANSBANK_SERVICIO_COMMERCE_CODE": settings.TRANSBANK_SERVICIO_COMMERCE_CODE,
        "TRANSBANK_SERVICIO_API_KEY": settings.TRANSBANK_SERVICIO_API_KEY,
        "TRANSBANK_SERVICIO_RETURN_URL": settings.TRANSBANK_SERVICIO_RETURN_URL,
    }
    return [name for name in VARIABLES_SERVICIO if not (valores[name] or "").strip()]


def _validar_configuracion() -> None:
    """HAL-VEN-025: falla explícito y en español, nunca con un 502 genérico."""
    faltantes = _configuracion_faltante()
    if faltantes:
        raise HTTPException(
            503,
            "El pago del servicio mensual no está configurado. "
            f"Faltan las variables: {', '.join(faltantes)}.",
        )

    settings = get_settings()
    # El eje de "pagos reales vs simulados" es TRANSBANK_ENV, no ENVIRONMENT:
    # permite ENVIRONMENT=production con TRANSBANK_ENV=integration (sandbox)
    # durante la fase de pagos simulados sin tocar la lógica de producción.
    if settings.TRANSBANK_ENV == "production":
        if (
            settings.TRANSBANK_SERVICIO_COMMERCE_CODE == SERVICIO_SANDBOX_COMMERCE_CODE
            or settings.TRANSBANK_SERVICIO_API_KEY == SERVICIO_SANDBOX_API_KEY
        ):
            raise HTTPException(
                503,
                "El pago del servicio mensual no puede usar credenciales de sandbox en producción.",
            )
        if not (settings.TRANSBANK_SERVICIO_RETURN_URL or "").startswith(("https://", "http://")):
            raise HTTPException(
                503,
                "TRANSBANK_SERVICIO_RETURN_URL no es una URL válida.",
            )


async def iniciar_pago(conn: Any, perfil_id: UUID) -> dict[str, Any]:
    async with conn.transaction():
        return await _iniciar_pago(conn, perfil_id)


async def _iniciar_pago(conn: Any, perfil_id: UUID) -> dict[str, Any]:
    _validar_configuracion()
    productor = await servicio_repo.get_productor_por_perfil(conn, perfil_id)
    if not productor:
        raise HTTPException(403, "Solo un vendedor con tienda puede pagar el servicio")

    await servicio_repo.asegurar_cuota(conn, productor["id"])
    cuota = await servicio_repo.get_cuota_pendiente(conn, productor["id"])
    if not cuota:
        raise HTTPException(400, "No hay una cuota pendiente del servicio")
    if cuota["estado"] == "pendiente_revision":
        raise HTTPException(400, "La cuota ya está pendiente de revisión")

    if cuota["token_ws"]:
        try:
            estado = await asyncio.to_thread(WebpayPlusClient().status, cuota["token_ws"])
        except WebpayError:
            # Token desconocido o expirado para Transbank (p. ej. se cerró el
            # formulario y caducó la sesión). Sin commit Transbank nunca captura
            # el dinero: la anula automáticamente. Se puede reintentar.
            estado = None
        estado_status = (estado or {}).get("status")
        if estado_status == "AUTHORIZED":
            # El pago anterior quedó AUTORIZADO pero sin commit (se cerró la
            # ventana después de autorizar). Se confirma ahora en lugar de dejar
            # al vendedor bloqueado: el commit de Transbank es idempotente por
            # token y, al sobrescribir token_ws abajo, el retorno con el token
            # viejo ya no encontrará la cuota (no hay doble cobro posible).
            resultado = await _confirmar_pago(conn, cuota["token_ws"])
            return {
                "url": "",
                "token_ws": cuota["token_ws"],
                "buy_order": cuota["buy_order"],
                "monto": int(cuota["monto"]),
                "estado": "pagado" if resultado.get("ok") else "pendiente_conciliacion",
            }
        # FAILED / REVERSED / NULLIFIED / INITIALIZED / token desconocido: la
        # transacción vieja no puede cobrar sin commit, así que se inicia una
        # nueva (set_webpay sobrescribe token_ws al crearla).

    buy_order = f"SERV-{uuid4().hex[:20].upper()}"
    settings = get_settings()
    client = WebpayPlusClient()
    try:
        result = await asyncio.to_thread(
            client.create,
            buy_order,
            str(perfil_id),
            int(cuota["monto"]),
            settings.TRANSBANK_SERVICIO_RETURN_URL or "",
        )
    except WebpayError as exc:
        logger.warning("Webpay servicio no disponible al iniciar: %s", exc)
        raise HTTPException(
            502,
            "No fue posible iniciar el pago del servicio mensual con Webpay.",
        ) from exc

    await servicio_repo.set_webpay(conn, cuota["id"], buy_order, result["token"])
    return {
        "url": result["url"],
        "token_ws": result["token"],
        "buy_order": buy_order,
        "monto": int(cuota["monto"]),
    }


async def confirmar_pago(conn: Any, token_ws: str) -> dict[str, Any]:
    async with conn.transaction():
        result = await _confirmar_pago(conn, token_ws)
    # La respuesta del proveedor debe persistir antes de devolver el error HTTP.
    if result.get("ok") is False:
        raise HTTPException(result["http_status"], result["motivo"])
    return result


async def _confirmar_pago(conn: Any, token_ws: str) -> dict[str, Any]:
    _validar_configuracion()
    cuota = await servicio_repo.get_by_token(conn, token_ws)
    if not cuota:
        raise HTTPException(400, "Pago de servicio no encontrado")
    if cuota["estado"] == "pagado":
        return {"ok": True, "estado": "pagado", "pago_id": cuota["id"]}

    try:
        response = await asyncio.to_thread(WebpayPlusClient().commit, token_ws)
    except WebpayError as exc:
        logger.warning("Webpay servicio commit incierto; consultando estado")
        try:
            response = await asyncio.to_thread(WebpayPlusClient().status, token_ws)
        except WebpayError:
            raise HTTPException(
                502, "No se pudo confirmar el pago del servicio. Requiere conciliación."
            ) from exc

    if response.get("status") != "AUTHORIZED" or response.get("response_code") != 0:
        await servicio_repo.save_webpay_response(conn, cuota["id"], response)
        rechazado = response.get("status") in {"FAILED", "REVERSED", "NULLIFIED"}
        return {
            "ok": False,
            "http_status": 400 if rechazado else 409,
            "motivo": "El pago del servicio fue rechazado"
            if rechazado
            else "El pago aún no está confirmado. Requiere conciliación antes de reintentar.",
        }

    productor = await conn.fetchrow(
        "SELECT perfil_id FROM public.productores WHERE id=$1", cuota["productor_id"]
    )
    monto_cuota = Decimal(str(cuota["monto"]))
    monto_respuesta = Decimal(str(response.get("amount", 0)))
    if (
        monto_respuesta != monto_cuota
        or response.get("buy_order") != cuota["buy_order"]
        or not productor
        or response.get("session_id") != str(productor["perfil_id"])
        or not str(response.get("authorization_code") or "").strip()
    ):
        raise HTTPException(502, "El pago no coincide con la cuota. Requiere conciliación.")

    await servicio_repo.mark_paid(
        conn,
        cuota["id"],
        cuota["productor_id"],
        str(response.get("authorization_code") or "")[:80],
    )
    return {"ok": True, "estado": "pagado", "pago_id": cuota["id"]}
