from datetime import datetime
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, StringConstraints, field_validator, model_validator

from app.schemas.validators import validate_rut

Banco = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=120)]
TipoCuenta = Literal[
    "cuenta_corriente",
    "cuenta_vista",
    "cuenta_ahorro",
    "cuenta_rut",
    "chequera_electronica",
]
TitularCuenta = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=3, max_length=160)
]

NumeroCuenta = Annotated[str, StringConstraints(strip_whitespace=True, pattern=r"^[0-9]+$")]

# HAL-REG-012: el número de cuenta es numérico y tiene entre 7 y 12 dígitos en
# todos los tipos. Se conserva como texto para no perder ceros iniciales.
LARGO_MINIMO_CUENTA = 7
LARGO_MAXIMO_CUENTA = 12


def normalizar_tipo_cuenta(value: object) -> object:
    """Acepta la etiqueta histórica («cuenta corriente») y el valor del enum."""
    if isinstance(value, str):
        return value.strip().lower().replace(" ", "_").replace("-", "_")
    return value


def validate_numero_cuenta(numero: str, _tipo_cuenta: str | None = None) -> str:
    """Valida 7..12 dígitos. No incluye el número en el mensaje (evita logs)."""
    if not numero.isdigit() or not LARGO_MINIMO_CUENTA <= len(numero) <= LARGO_MAXIMO_CUENTA:
        raise ValueError(
            f"El número de cuenta debe tener entre {LARGO_MINIMO_CUENTA} "
            f"y {LARGO_MAXIMO_CUENTA} dígitos"
        )
    return numero


class DatosBancariosBase(BaseModel):
    banco: Banco
    tipo_cuenta: TipoCuenta
    titular_cuenta: TitularCuenta
    rut_titular: str

    @field_validator("tipo_cuenta", mode="before")
    @classmethod
    def _tipo_cuenta(cls, value: object) -> object:
        return normalizar_tipo_cuenta(value)

    @field_validator("rut_titular")
    @classmethod
    def _rut(cls, value: str) -> str:
        return validate_rut(value)


class DatosBancariosCreate(DatosBancariosBase):
    numero_cuenta: NumeroCuenta

    @model_validator(mode="after")
    def _numero_cuenta(self) -> "DatosBancariosCreate":
        validate_numero_cuenta(self.numero_cuenta, self.tipo_cuenta)
        return self


class DatosBancariosUpdate(BaseModel):
    banco: Banco | None = None
    tipo_cuenta: TipoCuenta | None = None
    titular_cuenta: TitularCuenta | None = None
    rut_titular: str | None = None
    numero_cuenta: NumeroCuenta | None = None

    @field_validator("tipo_cuenta", mode="before")
    @classmethod
    def _tipo_cuenta(cls, value: object) -> object:
        return normalizar_tipo_cuenta(value) if value is not None else None

    @field_validator("rut_titular")
    @classmethod
    def _rut(cls, value: str | None) -> str | None:
        return validate_rut(value) if value is not None else None

    @model_validator(mode="after")
    def _numero_cuenta(self) -> "DatosBancariosUpdate":
        if self.numero_cuenta is not None:
            # HAL-REG-012: 7..12 dígitos sin importar el tipo. La coherencia
            # banco/tipo/número/RUT se completa en el servicio y en PostgreSQL.
            validate_numero_cuenta(self.numero_cuenta, self.tipo_cuenta)
        return self


class DatosBancariosResponse(BaseModel):
    """Cuenta bancaria descifrada sólo para su dueño o un administrador autorizado.

    El router exige una sesión válida y el backend añade ``Cache-Control:
    no-store`` a estas respuestas. El número no se persiste ni se escribe en
    logs: se descifra exclusivamente para precargar el formulario del
    postulante y para la revisión administrativa solicitada.
    """

    id: UUID
    perfil_id: UUID
    banco: str
    tipo_cuenta: str
    numero_cuenta: str
    numero_cuenta_enmascarado: str
    titular_cuenta: str
    rut_titular: str
    activo: bool
    creado_en: datetime
    actualizado_en: datetime
