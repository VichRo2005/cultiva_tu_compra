from typing import Any, cast
from uuid import UUID

COLUMNS = (
    "id, perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, "
    "numero_cuenta_hash, numero_cuenta_digitos, "
    "titular_cuenta, rut_titular, activo, creado_en, actualizado_en"
)


async def list_by_perfil(conn: Any, perfil_id: UUID) -> list[Any]:
    return cast(
        list[Any],
        await conn.fetch(
            f"SELECT {COLUMNS} FROM public.datos_bancarios "
            "WHERE perfil_id=$1 ORDER BY activo DESC, creado_en DESC",
            perfil_id,
        ),
    )


async def get_activa_by_perfil(conn: Any, perfil_id: UUID) -> Any:
    return await conn.fetchrow(
        f"SELECT {COLUMNS} FROM public.datos_bancarios "
        "WHERE perfil_id=$1 AND activo=true",
        perfil_id,
    )


async def get_by_id(conn: Any, dato_id: UUID) -> Any:
    return await conn.fetchrow(
        f"SELECT {COLUMNS} FROM public.datos_bancarios WHERE id=$1", dato_id
    )


async def desactivar_activas(conn: Any, perfil_id: UUID) -> None:
    await conn.execute(
        "UPDATE public.datos_bancarios SET activo=false, actualizado_en=now() "
        "WHERE perfil_id=$1 AND activo=true",
        perfil_id,
    )


async def insert(  # noqa: PLR0913 - explicit banking fields
    conn: Any,
    perfil_id: UUID,
    *,
    banco: str,
    tipo_cuenta: str,
    numero_cuenta_cifrado: bytes,
    numero_cuenta_hash: bytes,
    numero_cuenta_digitos: int,
    titular_cuenta: str,
    rut_titular: str,
) -> Any:
    return await conn.fetchrow(
        f"""INSERT INTO public.datos_bancarios
        (perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado, numero_cuenta_hash,
         numero_cuenta_digitos, titular_cuenta, rut_titular)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING {COLUMNS}""",
        perfil_id,
        banco,
        tipo_cuenta,
        numero_cuenta_cifrado,
        numero_cuenta_hash,
        numero_cuenta_digitos,
        titular_cuenta,
        rut_titular,
    )


async def update_fields(conn: Any, dato_id: UUID, fields: dict[str, Any]) -> Any:
    assignments = ", ".join(f"{name}=${index + 2}" for index, name in enumerate(fields))
    values = list(fields.values())
    return await conn.fetchrow(
        f"""UPDATE public.datos_bancarios SET {assignments}, actualizado_en=now()
        WHERE id=$1 RETURNING {COLUMNS}""",
        dato_id,
        *values,
    )
