import logging
from typing import Any
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse

from app.core.config import get_settings
from app.core.exceptions import WebpayError
from app.db.session import get_connection
from app.routers.deps import get_current_user
from app.schemas.servicio import IniciarServicioResponse
from app.services import servicio_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/servicio", tags=["servicio"])


@router.post("/iniciar", response_model=IniciarServicioResponse)
async def iniciar(
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> Any:
    return await servicio_service.iniciar_pago(conn, user["id"])


@router.get("/retorno")
@router.post("/retorno")
async def retorno(request: Request, conn: Any = Depends(get_connection)) -> RedirectResponse:
    """Retorno del navegador desde Webpay Plus para el servicio mensual."""
    form = request.query_params if request.method == "GET" else await request.form()
    token = str(form.get("token_ws") or "").strip()
    anulado = str(form.get("TBK_TOKEN") or "").strip()
    destino = f"{get_settings().FRONTEND_URL.rstrip('/')}/vendedor/servicio"

    if token and not anulado:
        try:
            result = await servicio_service.confirmar_pago(conn, token)
            destino = f"{destino}?{urlencode({'pago': result['estado']})}"
        except HTTPException as exc:
            logger.warning("Retorno Webpay servicio rechazado: %s", exc.detail)
            destino = f"{destino}?{urlencode({'pago': 'error'})}"
        except WebpayError:
            logger.warning("Retorno Webpay servicio sin confirmar: fallo del commit")
            destino = f"{destino}?{urlencode({'pago': 'error'})}"
    else:
        logger.warning("Retorno Webpay servicio anulado o sin token")
        destino = f"{destino}?{urlencode({'pago': 'cancelado'})}"

    return RedirectResponse(destino, status_code=303)
