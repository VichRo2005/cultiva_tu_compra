import json
from typing import Any
from uuid import UUID


async def get_productor_por_perfil(conn: Any, perfil_id: UUID) -> Any:
    return await conn.fetchrow(
        "SELECT id, nombre_comercial FROM public.productores WHERE perfil_id=$1", perfil_id
    )


async def asegurar_cuota(conn: Any, productor_id: UUID) -> None:
    await conn.execute("SELECT private.crear_cuota_servicio($1)", productor_id)


async def get_cuota_pendiente(conn: Any, productor_id: UUID) -> Any:
    return await conn.fetchrow(
        """SELECT * FROM public.pagos_servicio
        WHERE productor_id=$1 AND estado IN ('pendiente','rechazado')
        ORDER BY periodo ASC LIMIT 1 FOR UPDATE""",
        productor_id,
    )


async def get_cuota_actual(conn: Any, productor_id: UUID) -> Any:
    return await conn.fetchrow(
        """SELECT * FROM public.pagos_servicio
        WHERE productor_id=$1 ORDER BY periodo DESC LIMIT 1""",
        productor_id,
    )


async def set_webpay(
    conn: Any, pago_id: UUID, buy_order: str, token_ws: str
) -> None:
    await conn.execute(
        """UPDATE public.pagos_servicio
        SET metodo='webpay', buy_order=$2, token_ws=$3, estado='pendiente'
        WHERE id=$1""",
        pago_id,
        buy_order,
        token_ws,
    )


async def get_by_token(conn: Any, token_ws: str) -> Any:
    return await conn.fetchrow(
        "SELECT * FROM public.pagos_servicio WHERE token_ws=$1 FOR UPDATE", token_ws
    )


async def mark_paid(conn: Any, pago_id: UUID, productor_id: UUID, referencia: str) -> None:
    await conn.execute(
        """UPDATE public.pagos_servicio
        SET estado='pagado', metodo=COALESCE(metodo,'webpay'), referencia=$2,
            pagado_en=now(), revisado_en=now()
        WHERE id=$1""",
        pago_id,
        referencia,
    )
    await conn.execute(
        """UPDATE public.productores
        SET servicio_suspendido=false, servicio_suspendido_en=NULL
        WHERE id=$1""",
        productor_id,
    )
    await conn.execute("SELECT private.sincronizar_morosidad_productor($1)", productor_id)


async def save_webpay_response(conn: Any, pago_id: UUID, response: dict[str, Any]) -> None:
    await conn.execute(
        "UPDATE public.pagos_servicio SET observaciones=$2 WHERE id=$1",
        pago_id,
        json.dumps(response, default=str)[:1000],
    )
