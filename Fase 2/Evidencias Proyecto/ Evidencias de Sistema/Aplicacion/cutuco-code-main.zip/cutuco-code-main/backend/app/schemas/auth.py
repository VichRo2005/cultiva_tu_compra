from typing import Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints


class PasswordRecoveryRequest(BaseModel):
    """Solicitud pública: no revela si el correo corresponde a una cuenta."""

    model_config = ConfigDict(extra="forbid")
    # Se evita EmailStr para no cargar una dependencia adicional en el
    # contenedor. Esta validación cubre el formato que necesita GoTrue y no
    # pretende verificar la existencia del buzón (eso nunca se revela aquí).
    email: Annotated[
        str,
        StringConstraints(
            strip_whitespace=True,
            to_lower=True,
            max_length=254,
            pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$",
        ),
    ]
