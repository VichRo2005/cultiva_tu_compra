from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends

from app.db.session import get_connection
from app.routers.deps import get_current_user, require_role
from app.schemas.datos_bancarios import (
    DatosBancariosCreate,
    DatosBancariosResponse,
    DatosBancariosUpdate,
)
from app.services import datos_bancarios_service as service

router = APIRouter(prefix="/datos-bancarios", tags=["datos-bancarios"])


@router.get("/me", response_model=list[DatosBancariosResponse])
async def mis_datos(
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> list[DatosBancariosResponse]:
    return await service.listar_propias(conn, user["id"])


@router.post("", response_model=DatosBancariosResponse, status_code=201)
async def crear(
    body: DatosBancariosCreate,
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> DatosBancariosResponse:
    return await service.crear_o_reemplazar(conn, user["id"], body)


@router.patch("/{dato_id}", response_model=DatosBancariosResponse)
async def actualizar(
    dato_id: UUID,
    body: DatosBancariosUpdate,
    user: dict[str, Any] = Depends(get_current_user),
    conn: Any = Depends(get_connection),
) -> DatosBancariosResponse:
    return await service.actualizar(conn, dato_id, user, body)


@router.get("/admin/{perfil_id}", response_model=list[DatosBancariosResponse])
async def admin_datos(
    perfil_id: UUID,
    user: dict[str, Any] = Depends(require_role("admin")),
    conn: Any = Depends(get_connection),
) -> list[DatosBancariosResponse]:
    return await service.admin_por_perfil(conn, perfil_id)
