import asyncio
import asyncpg

async def test():
    conn = await asyncpg.connect('postgresql://postgres:postgres@127.0.0.1:54322/postgres')
    await conn.execute('DROP INDEX IF EXISTS auth.users_email_partial_key')
    await conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS uq_auth_users_email ON auth.users (lower(email::text))')
    await conn.execute("COMMENT ON INDEX auth.uq_auth_users_email IS 'CK-0407: un correo solo puede pertenecer a una cuenta (insensible a mayusculas).'")
    print('Index created')
    await conn.close()

asyncio.run(test())