# Documentación de Ejecución - CuTuCo MVP

## Requisitos Previos

- Docker Desktop instalado y ejecutándose
- Supabase CLI instalado (`npm install -g supabase` o descarga binaria)
- Python 3.11+ instalado
- Node.js 22+ instalado
- pnpm instalado (`npm install -g pnpm`)

## Instalación y Configuración

### 1. Clonar y Preparar

```bash
cd C:\Users\ignac\OneDrive\Escritorio\cutuco-code
```

### 2. Iniciar Supabase Local

```bash
supabase start
```

Esto levanta:
- PostgreSQL en `localhost:54322`
- Supabase API (PostgREST) en `localhost:54321`
- Supabase Studio en `localhost:54323`
- Auth (GoTrue) en `localhost:54321/auth/v1`
- Storage en `localhost:54321/storage/v1`

Verificar que todo está sano:
```bash
supabase status
```

### 3. Configurar Backend

```bash
cd backend
# Las variables de entorno ya están en .env (copiadas de .env.example)
# Verificar que DATABASE_URL apunta a postgres:54322
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Backend disponible en: `http://127.0.0.1:8000`
- Health check: `http://127.0.0.1:8000/health`
- Docs API: `http://127.0.0.1:8000/docs`

### 4. Configurar Frontend

```bash
cd frontend
# Copiar .env.local.example a .env.local si no existe
# Verificar VITE_SUPABASE_URL=http://127.0.0.1:54321
# Verificar VITE_API_BASE_URL=http://127.0.0.1:8000
npm install --legacy-peer-deps
npm run dev
```

Frontend disponible en: `http://127.0.0.1:5173`

## Usuarios de Prueba

### Cuentas de Desarrollo (Galeria - VITE_DEV_GALLERY=true)

| Usuario | Email | Password | Rol | Notas |
|---------|-------|----------|-----|-------|
| Admin | admin@cutuco.dev | CutucoDev2026! | admin | Acceso completo |
| Vendedor | vendedor@cutuco.dev | CutucoDev2026! | vendedor | Producer 002 activo |
| Cliente | cliente@cutuco.dev | CutucoDev2026! | cliente | Con direcciones |
| Pendiente | pendiente@cutuco.dev | CutucoDev2026! | cliente | Postulación en revisión |

### Cuentas de Seed (Supabase Local)

| Usuario | Email | Password | Rol | Productor |
|---------|-------|----------|-----|-----------|
| Admin Base | cutuco.admin.base@example.test | CutucoTest!2026 | admin | - |
| Cliente | cutuco.cliente.santiago@example.test | CutucoTest!2026 | cliente | - |
| Productor Paine | cutuco.productor.paine@example.test | CutucoTest!2026 | vendedor | 001 (inactivo) |
| Productor Melipilla | cutuco.productor.melipilla@example.test | CutucoTest!2026 | vendedor | **002 (activo)** |
| Productor Quillota | cutuco.productor.quillota@example.test | CutucoTest!2026 | vendedor | 003 (RM→Valparaíso) |
| Productor Pausado | cutuco.productor.pausado@example.test | CutucoTest!2026 | vendedor | 004 (inactivo) |
| Productor Cosecha | cutuco.productor.cosecha@example.test | CutucoTest!2026 | vendedor | 005 (activo) |

**Para tests: usar cuentas de galería (VITE_DEV_GALLERY=true) o Melipilla (productor 002)**

## Flujos de Prueba Principales

### 1. Cliente Completo
1. Registro → Login → Catálogo → Agregar al carrito → Checkout → Webpay (sandbox) → Confirmación → Seguimiento

### 2. Vendedor Completo
1. Login (vendedor@cutuco.dev) → Dashboard → Productos (CRUD) → Pedidos → Preparar/Despachar → Servicio mensual

### 3. Admin Completo
1. Login (admin@cutuco.dev) → Usuarios (activar/desactivar) → Productos (moderar) → Pagos Webpay → Sanciones → Cobros servicio

### 4. Postulación Vendedor
1. Registro como cliente → "Quiero vender" → Completar formulario → Subir docs → Enviar a revisión
2. Admin → Moderación → Aprobar/Rechazar → Se crea productor + código Mall

## Ejecución de Tests

### Backend (pytest)
```bash
cd backend
python -m pytest                    # Todos los tests
python -m pytest -x                 # Parar en primer fallo
python -m pytest -v                 # Verbose
python -m pytest tests/integration/test_acceso_lote19.py  # Suite específica
python -m pytest -k "webpay"        # Tests con "webpay" en nombre
```

### Frontend (vitest)
```bash
cd frontend
npm run test:unit                   # Tests unitarios
npm run test:unit -- --reporter=verbose
npm run test:e2e                    # E2E Playwright (requiere navegador)
npm run lint                        # oxlint + eslint
npm run build                       # Build producción
```

## Variables de Entorno Críticas

### Backend (.env)
```env
# Base de datos
SUPABASE_URL=http://127.0.0.1:54321
SUPABASE_ANON_KEY=sb_publishable_...
SUPABASE_SERVICE_ROLE_KEY=sb_secret_...
DATABASE_URL=postgresql://postgres:postgres@localhost:54322/postgres

# Webpay Mall (catálogo/pedidos)
TRANSBANK_COMMERCE_CODE=597055555535
TRANSBANK_API_KEY=579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C
TRANSBANK_RETURN_URL=http://localhost:5173/cliente/pedidos

# Webpay Plus (servicio mensual) - SANDBOX
TRANSBANK_SERVICIO_COMMERCE_CODE=597055555532
TRANSBANK_SERVICIO_API_KEY=579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C
TRANSBANK_SERVICIO_RETURN_URL=http://localhost:8000/api/servicio/retorno
TRANSBANK_ENV=integration

# Email
BREVO_API_KEY=xkeysib-...
EMAIL_FROM=CuTuCo Soporte <cutucosoporte@gmail.com>

# Seguridad
BANK_ENCRYPTION_KEY=DDU2hl923UJt3Mycgexz3kfp2qKjnKjK6jfC1x_dO-E=
JWT_SECRET=... (generado por Supabase)

# SRE
SRE_TOKEN_PUBLICO=7317025a-29a6-4327-80f5-56f1cb085c8c
```

### Frontend (.env.local)
```env
VITE_SUPABASE_URL=http://127.0.0.1:54321
VITE_SUPABASE_ANON_KEY=sb_publishable_ACJWlzQHlZjBrEguHvfOxg_3BJgxAaH
VITE_API_BASE_URL=http://127.0.0.1:8000
VITE_DEV_GALLERY=false
VITE_DEV_PASSWORD=CutucoDev2026!
```

## Troubleshooting Común

### Supabase no inicia
```bash
supabase stop
docker system prune -f
supabase start
```

### Tests fallan por conexión BD
```bash
# Verificar que Supabase está corriendo
supabase status
# Verificar DATABASE_URL en backend/.env
# Debe ser: postgresql://postgres:postgres@localhost:54322/postgres
```

### Webpay responde 502
```bash
# Verificar que backend está corriendo en puerto 8000
# Verificar TRANSBANK_* variables en backend/.env
# Verificar que VITE_API_BASE_URL en frontend apunta a http://127.0.0.1:8000
```

### Frontend no conecta a Supabase
```bash
# Verificar VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY en .env.local
# Verificar que supabase start muestra las mismas credenciales
```

## Estructura de Proyecto

```
cutuco-code/
├── backend/                 # FastAPI
│   ├── app/
│   │   ├── core/           # Config, security, exceptions
│   │   ├── db/             # Session pool
│   │   ├── integrations/   # Webpay, SRE, Email
│   │   ├── repositories/   # DB queries
│   │   ├── routers/        # API endpoints
│   │   ├── schemas/        # Pydantic models
│   │   └── services/       # Business logic
│   ├── tests/
│   │   ├── integration/    # Tests contra PG16 real
│   │   └── unit/           # Tests unitarios
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env
├── frontend/               # Vue 3 + Vite
│   ├── src/
│   │   ├── components/     # Base + Domain
│   │   ├── views/          # Pages por rol
│   │   ├── stores/         # Pinia (auth, cart, geo, ui)
│   │   ├── services/       # API calls
│   │   ├── router/         # Vue Router + guards
│   │   └── lib/            # Supabase client, utils
│   ├── tests/
│   ├── package.json
│   ├── vite.config.js
│   └── .env.local
├── supabase/               # PostgreSQL + Auth + Storage
│   ├── migrations/         # DDL + RLS + Functions
│   ├── seeds/              # Datos de prueba
│   ├── config.toml
│   └── .env
├── docs/
├── Checklist_MVP_CuTuCo.xlsx
├── INFORME_TECNICO_FINAL.md
├── ACTUALIZACION_EXCEL.md
└── DOCUMENTACION_EJECUCION.md
```

## Próximos Pasos para Producción

1. **Rotar todas las credenciales** (Webpay, Brevo, Supabase, JWT)
2. **Configurar dominio real** en Supabase Auth (`site_url`, `redirect_urls`)
3. **Configurar Webpay producción** (códigos de comercio reales, certificados)
4. **Configurar SRE token real** (plan pagado)
5. **Configurar Brevo dominio verificado** (DKIM/SPF)
6. **Deploy backend**: Google Cloud Run (Dockerfile incluido)
7. **Deploy frontend**: Vercel (build estático)
8. **Configurar monitoreo**: Logs, métricas, alertas
9. **Ejecutar tests E2E** en pipeline CI/CD
10. **Revisar RLS policies** en producción con datos reales

## Contacto y Soporte

- **Repositorio**: C:\Users\ignac\OneDrive\Escritorio\cutuco-code
- **Checklist MVP**: C:\Users\ignac\Downloads\WEB Cutuco\Checklist MVP - CuTuCo.xlsx
- **Informe Técnico**: INFORME_TECNICO_FINAL.md
- **Actualización Excel**: ACTUALIZACION_EXCEL.md

---

*Documentación generada: 14/11/2026*  
*Versión: Post-auditoría completa - Todos los tests pasando*