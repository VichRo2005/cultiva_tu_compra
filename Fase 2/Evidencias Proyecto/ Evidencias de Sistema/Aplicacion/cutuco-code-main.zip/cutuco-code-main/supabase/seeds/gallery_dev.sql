-- ============================================================
-- CuTuCo — Cuentas y datos de la GALERÍA DE DESARROLLO
-- ============================================================
-- HERRAMIENTA DE DESARROLLO: crea las cuentas con las que se recorre y gestiona
-- el sistema desde la vista de desarrollador (`VITE_DEV_GALLERY=true`) y carga
-- los registros que necesitan las ventanas del prototipo anterior.
-- Nada de esto forma parte del alcance vigente del ERS.
--
-- ORDEN DE CARGA: después de `supabase/seed.sql` (ver `[db.seed] sql_paths` en
-- `supabase/config.toml`), porque reutiliza su catálogo.
--
-- CUENTAS (contraseña común `CutucoDev2026!`, definida en `DEV_PASSWORD`):
--   admin@cutuco.dev      Administrador          → permisos completos: usuarios,
--                                                  productos, aprobaciones,
--                                                  sanciones y revisiones
--   vendedor@cutuco.dev   Vendedor               → inventario, pedidos, entrega
--                                                  con código y perfil de tienda
--   cliente@cutuco.dev    Cliente                → compra, seguimiento y calificación
--   pendiente@cutuco.dev  Vendedor en revisión   → muestra los bloqueos de RF-021
--
-- El archivo es idempotente: cada carga verifica antes de insertar. Las políticas
-- RLS de las tablas del prototipo anterior no definen INSERT público, así que la
-- carga corre dentro de una transacción con el contexto del Administrador Base.
-- ============================================================

begin;

-- Igual que seed.sql: pgcrypto puede estar instalado en extensions.
set local search_path = public, extensions, pg_catalog;

select set_config(
  'request.jwt.claims',
  json_build_object(
    'sub', 'a0000000-0000-0000-0000-000000000001',
    'role', 'authenticated'
  )::text,
  true
);

-- ============================================================
-- 1. Cuentas de autenticación (auth.users) y sus identidades
-- ============================================================
-- La contraseña se guarda con el mismo hash bcrypt que usa GoTrue
-- (`crypt(..., gen_salt('bf', 10))`), así que el login funciona tal cual.
-- El trigger `manejar_nuevo_usuario` crea el perfil base (rol cliente).
-- ============================================================

insert into auth.users (
  instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
  raw_app_meta_data, raw_user_meta_data, is_super_admin, is_sso_user,
  is_anonymous, recovery_sent_at, confirmation_sent_at, last_sign_in_at,
  phone, phone_change, phone_change_token, email_change_confirm_status,
  confirmation_token, recovery_token, email_change_token_new, email_change,
  email_change_token_current, reauthentication_token, created_at, updated_at
)
select
  '00000000-0000-0000-0000-000000000000'::uuid,
  v.id,
  'authenticated',
  'authenticated',
  v.email,
  crypt('CutucoDev2026!', gen_salt('bf', 10)),
  now(),
  '{"provider":"email","providers":["email"]}'::jsonb,
  v.meta::jsonb,
  false, false, false, now(), now(), now(),
  null, '', '', 0, '', '', '', '', '', '', now(), now()
from (
  values
    ('e0000000-0000-0000-0000-000000000001'::uuid, 'admin@cutuco.dev',
     '{"nombre":"Administrador","apellido":"CuTuCo"}'),
    ('e0000000-0000-0000-0000-000000000002'::uuid, 'vendedor@cutuco.dev',
     '{"nombre":"Verónica","apellido":"Del Campo"}'),
    ('e0000000-0000-0000-0000-000000000003'::uuid, 'cliente@cutuco.dev',
     '{"nombre":"Camila","apellido":"Rojas"}'),
    ('e0000000-0000-0000-0000-000000000004'::uuid, 'pendiente@cutuco.dev',
     '{"nombre":"Pedro","apellido":"En Revisión"}')
) as v(id, email, meta)
where not exists (select 1 from auth.users u where u.email = v.email);

insert into auth.identities (
  id, user_id, provider_id, identity_data, provider,
  last_sign_in_at, created_at, updated_at
)
select
  gen_random_uuid(),
  v.id,
  v.id::text,
  json_build_object('sub', v.id::text, 'email', v.email, 'email_verified', true),
  'email',
  now(), now(), now()
from (
  values
    ('e0000000-0000-0000-0000-000000000001'::uuid, 'admin@cutuco.dev'),
    ('e0000000-0000-0000-0000-000000000002'::uuid, 'vendedor@cutuco.dev'),
    ('e0000000-0000-0000-0000-000000000003'::uuid, 'cliente@cutuco.dev'),
    ('e0000000-0000-0000-0000-000000000004'::uuid, 'pendiente@cutuco.dev')
) as v(id, email)
where not exists (
  select 1 from auth.identities i where i.provider_id = v.id::text and i.provider = 'email'
);

-- ============================================================
-- 2. Perfiles con su rol (el trigger los crea como cliente)
-- ============================================================

update public."perfiles" p
   set "rol" = v.rol::public."rol_usuario",
       "activo" = true,
       "nombre" = v.nombre,
       "apellido" = v.apellido,
       "telefono" = v.telefono
from (
  values
    ('e0000000-0000-0000-0000-000000000001'::uuid, 'admin', 'Administrador', 'CuTuCo', '+56900000001'),
    ('e0000000-0000-0000-0000-000000000002'::uuid, 'vendedor', 'Verónica', 'Del Campo', '+56900000002'),
    ('e0000000-0000-0000-0000-000000000003'::uuid, 'cliente', 'Camila', 'Rojas', '+56900000003'),
    ('e0000000-0000-0000-0000-000000000004'::uuid, 'cliente', 'Pedro', 'En Revisión', '+56900000004')
) as v(id, rol, nombre, apellido, telefono)
where p."id" = v.id;

-- ============================================================
-- 3. Productor del vendedor de la galería y direcciones
-- ============================================================
-- Reutiliza el productor y la dirección del seed original (Paine, RM) para que el
-- panel del vendedor tenga catálogo, pedidos y región de cobertura (RF-009).
-- ============================================================

update public."productores" pr
   set "perfil_id" = 'e0000000-0000-0000-0000-000000000002'::uuid,
       "nombre_comercial" = 'Huerta del Desarrollador',
       "descripcion" = 'Tienda de ejemplo de la galería de desarrollo (HERRAMIENTA DE DESARROLLO).'
 where pr."id" = '20000000-0000-0000-0000-000000000001'::uuid;

-- El trigger `validar_direccion` exige que las direcciones se creen con la
-- identidad de su dueño, así que se cambia el contexto al perfil del vendedor y
-- se restaura el del administrador al terminar.
select set_config(
  'request.jwt.claims',
  json_build_object('sub', 'e0000000-0000-0000-0000-000000000002', 'role', 'authenticated')::text,
  true
);

insert into public."direcciones" (
  "id", "perfil_id", "etiqueta", "comuna_id", "calle", "numero",
  "referencia", "es_principal", "activo"
)
select
  'e1000000-0000-0000-0000-000000000002'::uuid,
  'e0000000-0000-0000-0000-000000000002'::uuid,
  'Predio',
  '12000000-0000-0000-0000-000000000001'::uuid,
  'Camino a Paine km 4',
  'Parcela 12',
  'Portón verde',
  true,
  true
where not exists (
  select 1 from public."direcciones" d
   where d."perfil_id" = 'e0000000-0000-0000-0000-000000000002'::uuid
);

select set_config(
  'request.jwt.claims',
  json_build_object('sub', 'e0000000-0000-0000-0000-000000000003', 'role', 'authenticated')::text,
  true
);

insert into public."direcciones" (
  "id", "perfil_id", "etiqueta", "comuna_id", "calle", "numero",
  "referencia", "es_principal", "activo"
)
select
  'e1000000-0000-0000-0000-000000000003'::uuid,
  'e0000000-0000-0000-0000-000000000003'::uuid,
  'Casa',
  '12000000-0000-0000-0000-000000000004'::uuid,
  'Calle Compañía',
  '1200',
  'Depto 402',
  true,
  true
where not exists (
  select 1 from public."direcciones" d
   where d."perfil_id" = 'e0000000-0000-0000-0000-000000000003'::uuid
);

-- Se restaura el contexto del Administrador Base para el resto de la carga.
select set_config(
  'request.jwt.claims',
  json_build_object('sub', 'a0000000-0000-0000-0000-000000000001', 'role', 'authenticated')::text,
  true
);

-- ============================================================
-- 4. Solicitud pendiente del cuarto usuario (RF-021)
-- ============================================================

insert into public."postulaciones_vendedores" (
  "id", "perfil_id", "nombre_comercial_solicitado", "descripcion",
  "estado", "comuna_origen_id"
)
select
  'e2000000-0000-0000-0000-000000000004'::uuid,
  'e0000000-0000-0000-0000-000000000004'::uuid,
  'Vega del Maipo',
  'Solicitud de ejemplo de la galería: el administrador revisa los antecedentes antes de activar la cuenta.',
  'borrador'::public."estado_postulacion_vendedor",
  '12000000-0000-0000-0000-000000000003'::uuid
where not exists (
  select 1 from public."postulaciones_vendedores" p
   where p."id" = 'e2000000-0000-0000-0000-000000000004'::uuid
);

-- Seguir el flujo vigente: crear borrador y completar antecedentes antes de
-- enviarlo. Solo son rutas de ejemplo; este seed no sube archivos a Storage.
-- En una segunda carga no se modifica una solicitud ya enviada o resuelta.
update public.postulaciones_vendedores
set rut_solicitante = '12345678-5',
    tipo_de_persona = 'natural',
    documento_identidad = 'vendedor-documentos/' || perfil_id || '/cedula.pdf',
    certificado_inicio_actividades_o_carnet_representante =
      'vendedor-documentos/' || perfil_id || '/inicio-actividades.pdf',
    certificado_titularidad_bancaria = 'vendedor-documentos/' || perfil_id || '/titularidad.pdf',
    comprobante_domicilio = 'vendedor-documentos/' || perfil_id || '/domicilio.pdf',
    estado = 'en_revision'
where id = 'e2000000-0000-0000-0000-000000000004'::uuid
  and estado = 'borrador';

insert into public."documentos_identidad" (
  "id", "postulacion_id", "perfil_id", "tipo", "ruta_storage",
  "nombre_archivo", "mime_type", "tamano_bytes", "subido_en", "expira_en"
)
select
  x."id",
  'e2000000-0000-0000-0000-000000000004'::uuid,
  'e0000000-0000-0000-0000-000000000004'::uuid,
  x."tipo",
  'identidad-vendedores/frente-dorso.svg',
  x."tipo" || '.svg',
  'image/svg+xml',
  12000,
  now(),
  now() + interval '7 days'
from (
  values
    ('e3000000-0000-0000-0000-000000000001'::uuid, 'frente'),
    ('e3000000-0000-0000-0000-000000000002'::uuid, 'dorso')
) as x("id", "tipo")
where not exists (
  select 1 from public."documentos_identidad" d
   where d."postulacion_id" = 'e2000000-0000-0000-0000-000000000004'::uuid
);

-- ============================================================
-- 5. Coberturas del resto de los vendedores del seed (ventana heredada)
-- ============================================================

insert into public."coberturas_productor" ("productor_id", "tipo_cobertura", "region_id", "activo")
select pr."id", 'region', pr."region_id", true
  from public."productores" pr
 where pr."region_id" is not null
   and not exists (
     select 1 from public."coberturas_productor" c
      where c."productor_id" = pr."id"
        and c."tipo_cobertura" = 'region'
   );

-- ============================================================
-- 6. Alertas de stock del prototipo anterior (RF-010, fuera de alcance)
-- ============================================================

update public."productos"
   set "umbral_bajo" = 30
 where "id" in (
   select "id" from public."productos"
    where "activo" = true and "eliminado_en" is null
    order by "stock" asc, "nombre" asc
    limit 5
 );

insert into public."alertas_stock" ("producto_id", "umbral_configurado", "stock_al_generar", "notificada")
select p."id", p."umbral_bajo", p."stock", true
  from public."productos" p
 where p."activo" = true
   and p."eliminado_en" is null
   and p."stock" <= p."umbral_bajo"
   and not exists (select 1 from public."alertas_stock" a where a."producto_id" = p."id");

-- ============================================================
-- 7. Criterios del score 40/40/20 (RF-006 v1) e historial de precios (RF-008)
-- ============================================================

update public."evaluaciones_reputacion"
   set "entrega_a_tiempo" = case when "puntaje" >= 4 then 1 else 0 end,
       "calidad" = "puntaje",
       "respuesta_reclamos" = greatest("puntaje" - 1, 1)
 where "entrega_a_tiempo" is null;

insert into public."historial_precios" ("producto_id", "region_id", "precio_anterior", "precio_nuevo", "fuente", "registrado_en")
select p."id",
       pr."region_id",
       round(p."precio" * 0.9, 2),
       round(p."precio" * 0.95, 2),
       'marketplace',
       now() - interval '30 days'
  from public."productos" p
  join public."productores" pr on pr."id" = p."productor_id"
 where p."activo" = true
   and p."eliminado_en" is null
   and pr."region_id" is not null
   and not exists (select 1 from public."historial_precios" h where h."producto_id" = p."id");

insert into public."historial_precios" ("producto_id", "region_id", "precio_anterior", "precio_nuevo", "fuente", "registrado_en")
select p."id",
       pr."region_id",
       round(p."precio" * 0.95, 2),
       p."precio",
       'marketplace',
       now()
  from public."productos" p
  join public."productores" pr on pr."id" = p."productor_id"
 where p."activo" = true
   and p."eliminado_en" is null
   and pr."region_id" is not null
   and not exists (
     select 1 from public."historial_precios" h
      where h."producto_id" = p."id"
        and h."precio_nuevo" = p."precio"
   );

commit;

