-- CuTuCo - seed.sql del alcance MVP vigente
-- PostgreSQL 16 / Supabase local. Destino: supabase/seed.sql.
-- Ejecutar como postgres/propietario de las tablas, despues del DDL.
-- Segunda ejecucion: excepcion antes de insertar; no duplica datos.
-- UUIDs y escenarios deterministas; fechas relativas al dia de ejecucion.
-- La clave bcrypt y los codigos de entrega conservan su generacion aleatoria.
-- Password de las siete cuentas: CutucoTest!2026.
-- Las rutas de imagen son metadatos; este SQL no sube archivos a Storage.
-- Los bytea bancarios son placeholders de prueba, no cifrado utilizable.
-- Una sola transaccion: cualquier error impide el COMMIT final.
BEGIN;

-- ============================================================
-- BLOQUE 0 - CONTEXTO Y PROTECCION CONTRA SEGUNDA EJECUCION
-- ============================================================

SET LOCAL TIME ZONE 'America/Santiago';
SET LOCAL row_security = off;
-- pgcrypto puede estar instalado en public o extensions en Supabase.
SET LOCAL search_path = public, extensions, pg_catalog;
SELECT set_config('request.jwt.claim.sub', NULL, true);
SELECT set_config('request.jwt.claim.role', NULL, true);
SELECT set_config('request.jwt.claims', NULL, true);
SELECT set_config('cutuco.operacion_interna', 'false', true);
-- Serializa ejecuciones concurrentes del mismo seed.
SELECT pg_advisory_xact_lock(20261004, 21917);

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM auth.users WHERE id IN (
    'a0000000-0000-0000-0000-000000000001'::uuid,
    'a0000000-0000-0000-0000-000000000002'::uuid,
    'a0000000-0000-0000-0000-000000000101'::uuid,
    'a0000000-0000-0000-0000-000000000102'::uuid,
    'a0000000-0000-0000-0000-000000000103'::uuid,
    'a0000000-0000-0000-0000-000000000104'::uuid,
    'a0000000-0000-0000-0000-000000000105'::uuid
  )) THEN
    RAISE EXCEPTION 'El seed CuTuCo ya existe (UUIDs reservados). Abortar para evitar duplicados.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.categorias
    WHERE id = '00000000-0000-0000-0000-000000000001' AND es_sistema
      AND slug = 'sin-categoria') THEN
    RAISE EXCEPTION 'Falta la categoria de sistema del DDL final de CuTuCo.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.configuracion_logistica
    WHERE id = 1 AND tarifa_delivery_defecto = 3500.00) THEN
    RAISE EXCEPTION 'El DDL debe contener la tarifa de delivery MVP de 3500 CLP.';
  END IF;
END;
$$;

-- ============================================================
-- BLOQUE 1 - REGIONES Y COMUNAS
-- ============================================================

INSERT INTO public.regiones (id, codigo, nombre)
VALUES
  ('11000000-0000-0000-0000-000000000001'::uuid, 'RM13', 'Región Metropolitana de Santiago'),
  ('11000000-0000-0000-0000-000000000002'::uuid, 'V05', 'Región de Valparaíso')
  on conflict (id) do nothing;

INSERT INTO public.comunas (id, region_id, codigo, nombre)
VALUES
  ('12000000-0000-0000-0000-000000000001'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMPAI', 'Paine'),
  ('12000000-0000-0000-0000-000000000002'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMBUI', 'Buin'),
  ('12000000-0000-0000-0000-000000000003'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMSBE', 'San Bernardo'),
  ('12000000-0000-0000-0000-000000000004'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMSAN', 'Santiago'),
  ('12000000-0000-0000-0000-000000000005'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMPRO', 'Providencia'),
  ('12000000-0000-0000-0000-000000000006'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, 'RMMEL', 'Melipilla'),
  ('12000000-0000-0000-0000-000000000007'::uuid, '11000000-0000-0000-0000-000000000002'::uuid, 'V05QUI', 'Quillota')
  on conflict (id) do nothing;

-- ============================================================
-- BLOQUE 2 - CATEGORIAS
-- ============================================================

-- Sin Categoría ya existe en el DDL.
INSERT INTO public.categorias (id, nombre, slug, es_sistema)
VALUES
  ('13000000-0000-0000-0000-000000000001'::uuid, 'Hortalizas', 'hortalizas', false),
  ('13000000-0000-0000-0000-000000000002'::uuid, 'Frutas', 'frutas', false),
  ('13000000-0000-0000-0000-000000000003'::uuid, 'Tubérculos', 'tuberculos', false),
  ('13000000-0000-0000-0000-000000000004'::uuid, 'Hierbas', 'hierbas', false),
  ('13000000-0000-0000-0000-000000000005'::uuid, 'Conservas', 'conservas', false)
  on conflict (id) do nothing;

-- ============================================================
-- BLOQUE 3 - AUTH.USERS Y AUTH.IDENTITIES
-- ============================================================

-- phone debe ser NULL: una cadena vacia colisionaria con su UNIQUE.

INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  is_sso_user,
  is_anonymous,
  recovery_sent_at,
  confirmation_sent_at,
  last_sign_in_at,
  phone,
  phone_change,
  phone_change_token,
  email_change_confirm_status,
  confirmation_token,
  recovery_token,
  email_change_token_new,
  email_change,
  email_change_token_current,
  reauthentication_token,
  created_at,
  updated_at
)
VALUES
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000001'::uuid,
    'authenticated', 'authenticated', 'cutuco.admin.base@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Administrador","apellido":"Base"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000002'::uuid,
    'authenticated', 'authenticated', 'cutuco.cliente.santiago@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Cliente","apellido":"Santiago"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000101'::uuid,
    'authenticated', 'authenticated', 'cutuco.productor.paine@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Productor","apellido":"Paine"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000102'::uuid,
    'authenticated', 'authenticated', 'cutuco.productor.melipilla@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Productor","apellido":"Melipilla"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000103'::uuid,
    'authenticated', 'authenticated', 'cutuco.productor.quillota@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Productor","apellido":"Quillota"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000104'::uuid,
    'authenticated', 'authenticated', 'cutuco.productor.pausado@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Productor","apellido":"Pausado"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  ),
  (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'a0000000-0000-0000-0000-000000000105'::uuid,
    'authenticated', 'authenticated', 'cutuco.productor.cosecha@example.test',
    crypt('CutucoTest!2026', gen_salt('bf', 10)), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"nombre":"Productor","apellido":"Cosecha"}'::jsonb,
    false, false, false, now(), now(), now(), NULL, '', '', 0, '', '', '', '', '', '', now(), now()
  );

-- Supabase Auth requiere la identidad email asociada para que estas filas
-- puedan comportarse como cuentas de autenticacion en un entorno de prueba.
INSERT INTO auth.identities (
  id, user_id, provider_id, identity_data, provider,
  last_sign_in_at, created_at, updated_at
)
SELECT
  x.identity_id,
  x.user_id,
  x.user_id::text,
  jsonb_build_object(
    'sub', x.user_id::text,
    'email', x.email,
    'email_verified', true,
    'phone_verified', false
  ),
  'email',
  now(), now(), now()
FROM (
  VALUES
    ('a2000000-0000-0000-0000-000000000001'::uuid, 'a0000000-0000-0000-0000-000000000001'::uuid, 'cutuco.admin.base@example.test'),
    ('a2000000-0000-0000-0000-000000000002'::uuid, 'a0000000-0000-0000-0000-000000000002'::uuid, 'cutuco.cliente.santiago@example.test'),
    ('a2000000-0000-0000-0000-000000000101'::uuid, 'a0000000-0000-0000-0000-000000000101'::uuid, 'cutuco.productor.paine@example.test'),
    ('a2000000-0000-0000-0000-000000000102'::uuid, 'a0000000-0000-0000-0000-000000000102'::uuid, 'cutuco.productor.melipilla@example.test'),
    ('a2000000-0000-0000-0000-000000000103'::uuid, 'a0000000-0000-0000-0000-000000000103'::uuid, 'cutuco.productor.quillota@example.test'),
    ('a2000000-0000-0000-0000-000000000104'::uuid, 'a0000000-0000-0000-0000-000000000104'::uuid, 'cutuco.productor.pausado@example.test'),
    ('a2000000-0000-0000-0000-000000000105'::uuid, 'a0000000-0000-0000-0000-000000000105'::uuid, 'cutuco.productor.cosecha@example.test')
) AS x(identity_id, user_id, email);

-- ============================================================
-- BLOQUE 4 - BOOTSTRAP PRIVILEGIADO DE PERFILES
-- ============================================================

ALTER TABLE public.perfiles DISABLE TRIGGER trg_validar_seguridad_perfil;
UPDATE public.perfiles
SET rol = 'admin', es_super_admin = true, es_protegido = true,
    telefono = '+56900000001'
WHERE id = 'a0000000-0000-0000-0000-000000000001'::uuid;
UPDATE public.perfiles SET rol = 'cliente', telefono = '+56900000002'
WHERE id = 'a0000000-0000-0000-0000-000000000002'::uuid;
UPDATE public.perfiles p
SET rol = 'cliente', telefono = x.telefono
FROM (VALUES
  ('a0000000-0000-0000-0000-000000000101'::uuid, '+56900000101'),
  ('a0000000-0000-0000-0000-000000000102'::uuid, '+56900000102'),
  ('a0000000-0000-0000-0000-000000000103'::uuid, '+56900000103'),
  ('a0000000-0000-0000-0000-000000000104'::uuid, '+56900000104'),
  ('a0000000-0000-0000-0000-000000000105'::uuid, '+56900000105')
) AS x(id, telefono)
WHERE p.id = x.id;
ALTER TABLE public.perfiles ENABLE TRIGGER trg_validar_seguridad_perfil;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_trigger
    WHERE tgrelid = 'public.perfiles'::regclass
      AND tgname = 'trg_validar_seguridad_perfil'
      AND tgenabled = 'O' AND NOT tgisinternal) THEN
    RAISE EXCEPTION 'El trigger de seguridad de perfiles no quedo habilitado.';
  END IF;
END;
$$;

-- ============================================================
-- BLOQUE 5 - DIRECCIONES CON JWT SIN IDENTIDAD
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.direcciones
  (id, perfil_id, comuna_id, etiqueta, calle, numero, es_principal, activo)
VALUES
  ('15000000-0000-0000-0000-000000000002'::uuid, 'a0000000-0000-0000-0000-000000000002'::uuid, '12000000-0000-0000-0000-000000000004'::uuid, 'Casa cliente', 'Calle Compañía', '200', true, true),
  ('15000000-0000-0000-0000-000000000101'::uuid, 'a0000000-0000-0000-0000-000000000101'::uuid, '12000000-0000-0000-0000-000000000001'::uuid, 'Predio Paine', 'Camino Huerta Paine', '101', true, true),
  ('15000000-0000-0000-0000-000000000102'::uuid, 'a0000000-0000-0000-0000-000000000102'::uuid, '12000000-0000-0000-0000-000000000006'::uuid, 'Predio Melipilla', 'Camino Valle Melipilla', '102', true, true),
  ('15000000-0000-0000-0000-000000000103'::uuid, 'a0000000-0000-0000-0000-000000000103'::uuid, '12000000-0000-0000-0000-000000000007'::uuid, 'Predio Quillota', 'Camino Valle Quillota', '103', true, true),
  ('15000000-0000-0000-0000-000000000104'::uuid, 'a0000000-0000-0000-0000-000000000104'::uuid, '12000000-0000-0000-0000-000000000005'::uuid, 'Predio Providencia', 'Calle Huerta de Prueba', '104', true, true),
  ('15000000-0000-0000-0000-000000000105'::uuid, 'a0000000-0000-0000-0000-000000000105'::uuid, '12000000-0000-0000-0000-000000000002'::uuid, 'Predio Buin', 'Camino Cosecha de Prueba', '105', true, true);

-- ============================================================
-- BLOQUE 6 - POSTULACIONES Y CREACION DE PRODUCTORES MEDIANTE APROBACION
-- ============================================================

SELECT set_config('request.jwt.claims',
  json_build_object('sub', 'a0000000-0000-0000-0000-000000000001', 'role', 'authenticated')::text, true);

INSERT INTO public.postulaciones_vendedores
  (id, perfil_id, nombre_comercial_solicitado, descripcion, estado)
VALUES
  ('14000000-0000-0000-0000-000000000001'::uuid, 'a0000000-0000-0000-0000-000000000101'::uuid, 'Huerta Paine Test', 'Postulacion de prueba del productor P1.', 'borrador'),
  ('14000000-0000-0000-0000-000000000002'::uuid, 'a0000000-0000-0000-0000-000000000102'::uuid, 'Valle Melipilla Test', 'Postulacion de prueba del productor P2.', 'borrador'),
  ('14000000-0000-0000-0000-000000000003'::uuid, 'a0000000-0000-0000-0000-000000000103'::uuid, 'Valle Quillota Test', 'Postulacion de prueba del productor P3.', 'borrador'),
  ('14000000-0000-0000-0000-000000000004'::uuid, 'a0000000-0000-0000-0000-000000000104'::uuid, 'Huerta Pausada Test', 'Postulacion de prueba del productor P4.', 'borrador'),
  ('14000000-0000-0000-0000-000000000005'::uuid, 'a0000000-0000-0000-0000-000000000105'::uuid, 'Cosecha del Dia Test', 'Postulacion de prueba del productor P5.', 'borrador');

-- Rutas de ejemplo: el seed no sube archivos reales al bucket privado.
UPDATE public.postulaciones_vendedores
SET rut_solicitante = '12345678-5', tipo_de_persona = 'natural',
    documento_identidad = 'vendedor-documentos/' || perfil_id || '/cedula.pdf',
    certificado_inicio_actividades_o_carnet_representante = 'vendedor-documentos/' || perfil_id || '/inicio-actividades.pdf',
    certificado_titularidad_bancaria = 'vendedor-documentos/' || perfil_id || '/titularidad.pdf',
    comprobante_domicilio = 'vendedor-documentos/' || perfil_id || '/domicilio.pdf',
    estado = 'en_revision'
WHERE id::text like '14000000-%';

SELECT public.resolver_postulacion_vendedor(id, 'aprobada', 'Documentos de prueba revisados', '597055555536')
FROM public.postulaciones_vendedores WHERE id::text like '14000000-%';

-- El trigger crea productores con UUID aleatorios. Se reservan sus UUID
-- antes de crear catalogo, sanciones o pedidos que los referencien.

UPDATE public.productores pr
SET id = x.productor_id
FROM (VALUES
  ('a0000000-0000-0000-0000-000000000101'::uuid, '20000000-0000-0000-0000-000000000001'::uuid),
  ('a0000000-0000-0000-0000-000000000102'::uuid, '20000000-0000-0000-0000-000000000002'::uuid),
  ('a0000000-0000-0000-0000-000000000103'::uuid, '20000000-0000-0000-0000-000000000003'::uuid),
  ('a0000000-0000-0000-0000-000000000104'::uuid, '20000000-0000-0000-0000-000000000004'::uuid),
  ('a0000000-0000-0000-0000-000000000105'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)
) AS x(perfil_id, productor_id)
WHERE pr.perfil_id = x.perfil_id;

-- Un comercio hijo de integracion compartido entre cinco vendedores.
-- El hijo 597055555537 queda reservado para el fee de la plataforma.
UPDATE public.productores
SET codigo_comercio_mall = '597055555536'
WHERE id::text like '20000000-%';

-- ============================================================
-- BLOQUE 7 - DATOS BANCARIOS
-- La informacion bancaria se administra exclusivamente mediante el backend.

-- ============================================================
-- BLOQUE 8 - SUSPENSION MANUAL DEL PRODUCTOR P4
-- ============================================================

SELECT set_config('request.jwt.claims',
  json_build_object('sub', 'a0000000-0000-0000-0000-000000000001', 'role', 'authenticated')::text, true);

INSERT INTO public.sanciones
  (id, productor_id, tipo, accion, estado, duracion_dias, motivo)
VALUES ('a1000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000004'::uuid,
  'suspension', 'suspender', 'activa', 30,
  'Suspension manual de prueba por incumplimiento de las condiciones del marketplace.');
-- Los triggers calculan fin_en/impuesta_por y desactivan a P4.
-- No se crea apelacion: queda disponible para pruebas manuales del frontend.

-- ============================================================
-- BLOQUE 9 - CATALOGO: CUATRO PRODUCTOS POR PRODUCTOR
-- ============================================================

INSERT INTO public.productos
  (id, productor_id, categoria_id, nombre, slug, descripcion,
   precio, stock, unidad_medida, fecha_cosecha, activo)
VALUES
  ('30000000-0000-0000-0000-000000000101'::uuid, '20000000-0000-0000-0000-000000000001'::uuid, '13000000-0000-0000-0000-000000000001'::uuid, 'Tomates Roma de Paine', '', 'Producto agricola de prueba P1-1.', 2800.00, 50, 'kg', NULL, true),
  ('30000000-0000-0000-0000-000000000102'::uuid, '20000000-0000-0000-0000-000000000001'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, 'Papas Nuevas de Paine', '', 'Producto agricola de prueba P1-2.', 1600.00, 20, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000103'::uuid, '20000000-0000-0000-0000-000000000001'::uuid, '13000000-0000-0000-0000-000000000005'::uuid, 'Conserva de Tomates de Paine', '', 'Producto agricola de prueba P1-3.', 4100.00, 25, 'unidad', CURRENT_DATE - 3, true),
  ('30000000-0000-0000-0000-000000000104'::uuid, '20000000-0000-0000-0000-000000000001'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, 'Orégano Seco de Paine', '', 'Producto agricola de prueba P1-4.', 1150.00, 30, 'g', CURRENT_DATE - 10, true),
  ('30000000-0000-0000-0000-000000000201'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '13000000-0000-0000-0000-000000000001'::uuid, 'Tomates de Melipilla', '', 'Producto agricola de prueba P2-1.', 2900.00, 50, 'kg', NULL, true),
  ('30000000-0000-0000-0000-000000000202'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, 'Papas Nuevas de Melipilla', '', 'Producto agricola de prueba P2-2.', 1650.00, 20, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000203'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '13000000-0000-0000-0000-000000000005'::uuid, 'Conserva de Tomates de Melipilla', '', 'Producto agricola de prueba P2-3.', 4200.00, 25, 'unidad', CURRENT_DATE - 3, true),
  ('30000000-0000-0000-0000-000000000204'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, 'Orégano Seco de Melipilla', '', 'Producto agricola de prueba P2-4.', 1200.00, 30, 'g', CURRENT_DATE - 10, true),
  ('30000000-0000-0000-0000-000000000301'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '13000000-0000-0000-0000-000000000001'::uuid, 'Tomates de Quillota', '', 'Producto agricola de prueba P3-1.', 3000.00, 50, 'kg', NULL, true),
  ('30000000-0000-0000-0000-000000000302'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, 'Papas Nuevas de Quillota', '', 'Producto agricola de prueba P3-2.', 1700.00, 20, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000303'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '13000000-0000-0000-0000-000000000005'::uuid, 'Conserva de Tomates de Quillota', '', 'Producto agricola de prueba P3-3.', 4300.00, 25, 'unidad', CURRENT_DATE - 3, true),
  ('30000000-0000-0000-0000-000000000304'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, 'Orégano Seco de Quillota', '', 'Producto agricola de prueba P3-4.', 1250.00, 30, 'g', CURRENT_DATE - 10, true),
  ('30000000-0000-0000-0000-000000000401'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '13000000-0000-0000-0000-000000000001'::uuid, 'Tomates de Productor Pausado', '', 'Producto agricola de prueba P4-1.', 3100.00, 50, 'kg', NULL, true),
  ('30000000-0000-0000-0000-000000000402'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, 'Papas Nuevas de Productor Pausado', '', 'Producto agricola de prueba P4-2.', 1750.00, 20, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000403'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '13000000-0000-0000-0000-000000000005'::uuid, 'Conserva de Tomates de Productor Pausado', '', 'Producto agricola de prueba P4-3.', 4400.00, 25, 'unidad', CURRENT_DATE - 3, true),
  ('30000000-0000-0000-0000-000000000404'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, 'Orégano Seco de Productor Pausado', '', 'Producto agricola de prueba P4-4.', 1300.00, 30, 'g', CURRENT_DATE - 10, true),
  ('30000000-0000-0000-0000-000000000501'::uuid, '20000000-0000-0000-0000-000000000005'::uuid, '13000000-0000-0000-0000-000000000001'::uuid, 'Tomates de Cosecha del Dia', '', 'Producto agricola de prueba P5-1.', 3200.00, 50, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000502'::uuid, '20000000-0000-0000-0000-000000000005'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, 'Papas Nuevas de Cosecha del Dia', '', 'Producto agricola de prueba P5-2.', 1800.00, 20, 'kg', CURRENT_DATE, true),
  ('30000000-0000-0000-0000-000000000503'::uuid, '20000000-0000-0000-0000-000000000005'::uuid, '13000000-0000-0000-0000-000000000005'::uuid, 'Conserva de Tomates de Cosecha del Dia', '', 'Producto agricola de prueba P5-3.', 4500.00, 25, 'unidad', CURRENT_DATE - 3, true),
  ('30000000-0000-0000-0000-000000000504'::uuid, '20000000-0000-0000-0000-000000000005'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, 'Orégano Seco de Cosecha del Dia', '', 'Producto agricola de prueba P5-4.', 1350.00, 30, 'g', CURRENT_DATE - 10, true);

-- ============================================================
-- BLOQUE 10 - UNA IMAGEN PRINCIPAL POR PRODUCTO
-- ============================================================

-- ruta_storage incluye el bucket, como referencia del seed solicitado.
-- Al subir a Storage, bucket='product-images' y object key='<uuid>/<archivo>'.
INSERT INTO public.imagenes_productos
  (id, producto_id, ruta_storage, nombre_archivo, mime_type, tamano_bytes,
   texto_alternativo, es_principal, posicion)
SELECT x.id, p.id, 'product-images/' || p.id::text || '/' || x.archivo,
       x.archivo, 'image/webp', 102400, p.nombre, true, 1
FROM (VALUES
  ('50000000-0000-0000-0000-000000000101'::uuid, '30000000-0000-0000-0000-000000000101'::uuid, 'tomates.webp'),
  ('50000000-0000-0000-0000-000000000102'::uuid, '30000000-0000-0000-0000-000000000102'::uuid, 'papas.webp'),
  ('50000000-0000-0000-0000-000000000103'::uuid, '30000000-0000-0000-0000-000000000103'::uuid, 'conserva.webp'),
  ('50000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000104'::uuid, 'oregano.webp'),
  ('50000000-0000-0000-0000-000000000201'::uuid, '30000000-0000-0000-0000-000000000201'::uuid, 'tomates.webp'),
  ('50000000-0000-0000-0000-000000000202'::uuid, '30000000-0000-0000-0000-000000000202'::uuid, 'papas.webp'),
  ('50000000-0000-0000-0000-000000000203'::uuid, '30000000-0000-0000-0000-000000000203'::uuid, 'conserva.webp'),
  ('50000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, 'oregano.webp'),
  ('50000000-0000-0000-0000-000000000301'::uuid, '30000000-0000-0000-0000-000000000301'::uuid, 'tomates.webp'),
  ('50000000-0000-0000-0000-000000000302'::uuid, '30000000-0000-0000-0000-000000000302'::uuid, 'papas.webp'),
  ('50000000-0000-0000-0000-000000000303'::uuid, '30000000-0000-0000-0000-000000000303'::uuid, 'conserva.webp'),
  ('50000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, 'oregano.webp'),
  ('50000000-0000-0000-0000-000000000401'::uuid, '30000000-0000-0000-0000-000000000401'::uuid, 'tomates.webp'),
  ('50000000-0000-0000-0000-000000000402'::uuid, '30000000-0000-0000-0000-000000000402'::uuid, 'papas.webp'),
  ('50000000-0000-0000-0000-000000000403'::uuid, '30000000-0000-0000-0000-000000000403'::uuid, 'conserva.webp'),
  ('50000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, 'oregano.webp'),
  ('50000000-0000-0000-0000-000000000501'::uuid, '30000000-0000-0000-0000-000000000501'::uuid, 'tomates.webp'),
  ('50000000-0000-0000-0000-000000000502'::uuid, '30000000-0000-0000-0000-000000000502'::uuid, 'papas.webp'),
  ('50000000-0000-0000-0000-000000000503'::uuid, '30000000-0000-0000-0000-000000000503'::uuid, 'conserva.webp'),
  ('50000000-0000-0000-0000-000000000504'::uuid, '30000000-0000-0000-0000-000000000504'::uuid, 'oregano.webp')
) AS x(id, producto_id, archivo)
JOIN public.productos p ON p.id = x.producto_id;

-- ============================================================
-- BLOQUE 11 - PALABRAS PROHIBIDAS
-- ============================================================

INSERT INTO public.palabras_prohibidas (id, palabra, activo)
VALUES
  ('17000000-0000-0000-0000-000000000001'::uuid, 'estafa', true),
  ('17000000-0000-0000-0000-000000000002'::uuid, 'falso', true),
  ('17000000-0000-0000-0000-000000000003'::uuid, 'inutil', true),
  ('17000000-0000-0000-0000-000000000004'::uuid, 'basura', true),
  ('17000000-0000-0000-0000-000000000005'::uuid, 'malo', true);

-- ============================================================
-- BLOQUE 12 - CICLO 1: PEDIDO CREADO, SIN PAGO NI ENVIO
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.pedidos
  (id, codigo_pedido, cliente_id, productor_id, region_entrega_id,
   comuna_entrega_id, direccion_entrega, referencia_entrega,
   nombre_destinatario, telefono_destinatario, estado)
VALUES ('40000000-0000-0000-0000-000000000001'::uuid, 'CUTUCO-E2E-001', 'a0000000-0000-0000-0000-000000000002'::uuid,
  '20000000-0000-0000-0000-000000000001'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, '12000000-0000-0000-0000-000000000001'::uuid,
  'Calle Test 100, direccion ficticia de entrega', NULL,
  'Cliente Santiago', '+56900000002', 'creado');
INSERT INTO public.detalles_pedido
  (id, pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal)
SELECT '41000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000001'::uuid,
       p.id, p.nombre, p.precio, 2.000, round(p.precio * 2, 2)
FROM public.productos p
WHERE p.id = '30000000-0000-0000-0000-000000000101'::uuid;

-- ============================================================
-- BLOQUE 13 - CICLO 2: PEDIDO EN PREPARACION Y ENVIO EN PREPARACION
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.pedidos
  (id, codigo_pedido, cliente_id, productor_id, region_entrega_id,
   comuna_entrega_id, direccion_entrega, referencia_entrega,
   nombre_destinatario, telefono_destinatario, estado)
VALUES ('40000000-0000-0000-0000-000000000002'::uuid, 'CUTUCO-E2E-002', 'a0000000-0000-0000-0000-000000000002'::uuid,
  '20000000-0000-0000-0000-000000000002'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, '12000000-0000-0000-0000-000000000004'::uuid,
  'Calle Test 200, direccion ficticia de entrega', NULL,
  'Cliente Santiago', '+56900000002', 'creado');
INSERT INTO public.detalles_pedido
  (id, pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal)
SELECT '41000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000002'::uuid,
       p.id, p.nombre, p.precio, 1.000, round(p.precio * 1, 2)
FROM public.productos p
WHERE p.id = '30000000-0000-0000-0000-000000000201'::uuid;

INSERT INTO public.pagos
  (id, pedido_id, buy_order, buy_order_mall, token_ws, session_id, codigo_comercio,
   monto, codigo_autorizacion, codigo_respuesta, autorizado_en, respuesta_webpay)
SELECT '60000000-0000-0000-0000-000000000002'::uuid, p.id, 'CUTUCO-WP-E2E-002',
       'CUTUCO-MALL-E2E-002', 'token_ws_cutuco_e2e_002_unico', 'sesion-e2e-002',
       pr.codigo_comercio_mall, p.total, 'AUTH-E2E-002', '0', now(),
       jsonb_build_object('status', 'AUTHORIZED', 'response_code', 0,
         'commerce_code', pr.codigo_comercio_mall, 'buy_order', 'CUTUCO-WP-E2E-002',
         'amount', p.total, 'authorization_code', 'AUTH-E2E-002',
         'payment_type_code', 'VD', 'installments_number', 0)
FROM public.pedidos p JOIN public.productores pr ON pr.id = p.productor_id
WHERE p.id = '40000000-0000-0000-0000-000000000002'::uuid;
UPDATE public.pedidos SET estado = 'pagado'
WHERE id = '40000000-0000-0000-0000-000000000002'::uuid;
-- El trigger crea el envio en 'preparacion' y deja el pedido 'pagado'.
UPDATE public.envios SET id = '70000000-0000-0000-0000-000000000002'::uuid
WHERE pedido_id = '40000000-0000-0000-0000-000000000002'::uuid;
-- Acción real del vendedor (HAL-CLI-010): preparación explícita.
UPDATE public.pedidos SET estado = 'en_preparacion'
WHERE id = '40000000-0000-0000-0000-000000000002'::uuid;
UPDATE public.envios SET preparado_en = coalesce(preparado_en, now())
WHERE pedido_id = '40000000-0000-0000-0000-000000000002'::uuid;

-- ============================================================
-- BLOQUE 14 - CICLO 3: ENVIO EN TRANSITO
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.pedidos
  (id, codigo_pedido, cliente_id, productor_id, region_entrega_id,
   comuna_entrega_id, direccion_entrega, referencia_entrega,
   nombre_destinatario, telefono_destinatario, estado)
VALUES ('40000000-0000-0000-0000-000000000003'::uuid, 'CUTUCO-E2E-003', 'a0000000-0000-0000-0000-000000000002'::uuid,
  '20000000-0000-0000-0000-000000000002'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, '12000000-0000-0000-0000-000000000005'::uuid,
  'Calle Test 300, direccion ficticia de entrega', NULL,
  'Cliente Santiago', '+56900000002', 'creado');
INSERT INTO public.detalles_pedido
  (id, pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal)
SELECT '41000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000003'::uuid,
       p.id, p.nombre, p.precio, 2.000, round(p.precio * 2, 2)
FROM public.productos p
WHERE p.id = '30000000-0000-0000-0000-000000000201'::uuid;

INSERT INTO public.pagos
  (id, pedido_id, buy_order, buy_order_mall, token_ws, session_id, codigo_comercio,
   monto, codigo_autorizacion, codigo_respuesta, autorizado_en, respuesta_webpay)
SELECT '60000000-0000-0000-0000-000000000003'::uuid, p.id, 'CUTUCO-WP-E2E-003',
       'CUTUCO-MALL-E2E-003', 'token_ws_cutuco_e2e_003_unico', 'sesion-e2e-003',
       pr.codigo_comercio_mall, p.total, 'AUTH-E2E-003', '0', now(),
       jsonb_build_object('status', 'AUTHORIZED', 'response_code', 0,
         'commerce_code', pr.codigo_comercio_mall, 'buy_order', 'CUTUCO-WP-E2E-003',
         'amount', p.total, 'authorization_code', 'AUTH-E2E-003',
         'payment_type_code', 'VD', 'installments_number', 0)
FROM public.pedidos p JOIN public.productores pr ON pr.id = p.productor_id
WHERE p.id = '40000000-0000-0000-0000-000000000003'::uuid;
UPDATE public.pedidos SET estado = 'pagado'
WHERE id = '40000000-0000-0000-0000-000000000003'::uuid;
-- El trigger crea el envio en 'preparacion' y deja el pedido 'pagado'.
UPDATE public.envios SET id = '70000000-0000-0000-0000-000000000003'::uuid
WHERE pedido_id = '40000000-0000-0000-0000-000000000003'::uuid;
-- Acción real del vendedor (HAL-CLI-010): preparación explícita.
UPDATE public.pedidos SET estado = 'en_preparacion'
WHERE id = '40000000-0000-0000-0000-000000000003'::uuid;
UPDATE public.envios SET preparado_en = coalesce(preparado_en, now())
WHERE pedido_id = '40000000-0000-0000-0000-000000000003'::uuid;

UPDATE public.envios SET estado = 'en_transito'
WHERE id = '70000000-0000-0000-0000-000000000003'::uuid;

-- ============================================================
-- BLOQUE 15 - CICLO 4: ENTREGA, PAGO AUTORIZADO Y EVALUACION
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.pedidos
  (id, codigo_pedido, cliente_id, productor_id, region_entrega_id,
   comuna_entrega_id, direccion_entrega, referencia_entrega,
   nombre_destinatario, telefono_destinatario, estado)
VALUES ('40000000-0000-0000-0000-000000000004'::uuid, 'CUTUCO-E2E-004', 'a0000000-0000-0000-0000-000000000002'::uuid,
  '20000000-0000-0000-0000-000000000005'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, '12000000-0000-0000-0000-000000000003'::uuid,
  'Calle Test 400, direccion ficticia de entrega', NULL,
  'Cliente Santiago', '+56900000002', 'creado');
INSERT INTO public.detalles_pedido
  (id, pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal)
SELECT '41000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000004'::uuid,
       p.id, p.nombre, p.precio, 1.000, round(p.precio * 1, 2)
FROM public.productos p
WHERE p.id = '30000000-0000-0000-0000-000000000501'::uuid;

INSERT INTO public.pagos
  (id, pedido_id, buy_order, buy_order_mall, token_ws, session_id, codigo_comercio,
   monto, codigo_autorizacion, codigo_respuesta, autorizado_en, respuesta_webpay)
SELECT '60000000-0000-0000-0000-000000000004'::uuid, p.id, 'CUTUCO-WP-E2E-004',
       'CUTUCO-MALL-E2E-004', 'token_ws_cutuco_e2e_004_unico', 'sesion-e2e-004',
       pr.codigo_comercio_mall, p.total, 'AUTH-E2E-004', '0', now(),
       jsonb_build_object('status', 'AUTHORIZED', 'response_code', 0,
         'commerce_code', pr.codigo_comercio_mall, 'buy_order', 'CUTUCO-WP-E2E-004',
         'amount', p.total, 'authorization_code', 'AUTH-E2E-004',
         'payment_type_code', 'VD', 'installments_number', 0)
FROM public.pedidos p JOIN public.productores pr ON pr.id = p.productor_id
WHERE p.id = '40000000-0000-0000-0000-000000000004'::uuid;
UPDATE public.pedidos SET estado = 'pagado'
WHERE id = '40000000-0000-0000-0000-000000000004'::uuid;
-- El trigger crea el envio en 'preparacion' y deja el pedido 'pagado'.
UPDATE public.envios SET id = '70000000-0000-0000-0000-000000000004'::uuid
WHERE pedido_id = '40000000-0000-0000-0000-000000000004'::uuid;
UPDATE public.pedidos SET estado = 'en_preparacion'
WHERE id = '40000000-0000-0000-0000-000000000004'::uuid;
UPDATE public.envios SET preparado_en = coalesce(preparado_en, now())
WHERE pedido_id = '40000000-0000-0000-0000-000000000004'::uuid;

UPDATE public.envios SET estado = 'en_transito'
WHERE id = '70000000-0000-0000-0000-000000000004'::uuid;

-- PostgreSQL materializa el reset de una GUC personalizada como ''.
-- auth.uid() sigue siendo NULL, pero v_jwt IS NULL del trigger no se cumple.
-- Por eso se usa la via interna ya prevista por el DDL, solo para esta
-- simulacion de codigo verificado, sin deshabilitar triggers.
SELECT set_config('cutuco.operacion_interna', 'true', true);
UPDATE public.envios SET codigo_verificado_en = now()
WHERE id = '70000000-0000-0000-0000-000000000004'::uuid;
SELECT set_config('cutuco.operacion_interna', 'false', true);
UPDATE public.envios SET estado = 'entregado'
WHERE id = '70000000-0000-0000-0000-000000000004'::uuid;
-- La entrega completa el pedido.

SELECT set_config('request.jwt.claims',
  json_build_object('sub', 'a0000000-0000-0000-0000-000000000001', 'role', 'authenticated')::text, true);

-- JWT admin: el trigger de reputacion puede actualizar al productor.
INSERT INTO public.evaluaciones_reputacion
  (id, pedido_id, productor_id, cliente_id, puntaje, comentario)
VALUES ('90000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000004'::uuid,
  '20000000-0000-0000-0000-000000000005'::uuid, 'a0000000-0000-0000-0000-000000000002'::uuid, 5,
  'Entrega de prueba exitosa y calidad excelente.');

-- ============================================================
-- BLOQUE 16 - CICLO 5: COMPLETADO Y RECLAMO ABIERTO
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

INSERT INTO public.pedidos
  (id, codigo_pedido, cliente_id, productor_id, region_entrega_id,
   comuna_entrega_id, direccion_entrega, referencia_entrega,
   nombre_destinatario, telefono_destinatario, estado)
VALUES ('40000000-0000-0000-0000-000000000005'::uuid, 'CUTUCO-E2E-005', 'a0000000-0000-0000-0000-000000000002'::uuid,
  '20000000-0000-0000-0000-000000000002'::uuid, '11000000-0000-0000-0000-000000000001'::uuid, '12000000-0000-0000-0000-000000000004'::uuid,
  'Calle Test 500, direccion ficticia de entrega', NULL,
  'Cliente Santiago', '+56900000002', 'creado');
INSERT INTO public.detalles_pedido
  (id, pedido_id, producto_id, producto_nombre, precio_unitario, cantidad, subtotal)
SELECT '41000000-0000-0000-0000-000000000005'::uuid, '40000000-0000-0000-0000-000000000005'::uuid,
       p.id, p.nombre, p.precio, 1.000, round(p.precio * 1, 2)
FROM public.productos p
WHERE p.id = '30000000-0000-0000-0000-000000000201'::uuid;

INSERT INTO public.pagos
  (id, pedido_id, buy_order, buy_order_mall, token_ws, session_id, codigo_comercio,
   monto, codigo_autorizacion, codigo_respuesta, autorizado_en, respuesta_webpay)
SELECT '60000000-0000-0000-0000-000000000005'::uuid, p.id, 'CUTUCO-WP-E2E-005',
       'CUTUCO-MALL-E2E-005', 'token_ws_cutuco_e2e_005_unico', 'sesion-e2e-005',
       pr.codigo_comercio_mall, p.total, 'AUTH-E2E-005', '0', now(),
       jsonb_build_object('status', 'AUTHORIZED', 'response_code', 0,
         'commerce_code', pr.codigo_comercio_mall, 'buy_order', 'CUTUCO-WP-E2E-005',
         'amount', p.total, 'authorization_code', 'AUTH-E2E-005',
         'payment_type_code', 'VD', 'installments_number', 0)
FROM public.pedidos p JOIN public.productores pr ON pr.id = p.productor_id
WHERE p.id = '40000000-0000-0000-0000-000000000005'::uuid;
UPDATE public.pedidos SET estado = 'pagado'
WHERE id = '40000000-0000-0000-0000-000000000005'::uuid;
-- El trigger crea el envio en 'preparacion' y deja el pedido 'pagado'.
UPDATE public.envios SET id = '70000000-0000-0000-0000-000000000005'::uuid
WHERE pedido_id = '40000000-0000-0000-0000-000000000005'::uuid;
UPDATE public.pedidos SET estado = 'en_preparacion'
WHERE id = '40000000-0000-0000-0000-000000000005'::uuid;
UPDATE public.envios SET preparado_en = coalesce(preparado_en, now())
WHERE pedido_id = '40000000-0000-0000-0000-000000000005'::uuid;

UPDATE public.envios SET estado = 'en_transito'
WHERE id = '70000000-0000-0000-0000-000000000005'::uuid;

-- PostgreSQL materializa el reset de una GUC personalizada como ''.
-- auth.uid() sigue siendo NULL, pero v_jwt IS NULL del trigger no se cumple.
-- Por eso se usa la via interna ya prevista por el DDL, solo para esta
-- simulacion de codigo verificado, sin deshabilitar triggers.
SELECT set_config('cutuco.operacion_interna', 'true', true);
UPDATE public.envios SET codigo_verificado_en = now()
WHERE id = '70000000-0000-0000-0000-000000000005'::uuid;
SELECT set_config('cutuco.operacion_interna', 'false', true);
UPDATE public.envios SET estado = 'entregado'
WHERE id = '70000000-0000-0000-0000-000000000005'::uuid;
-- La entrega completa el pedido.

SELECT set_config('request.jwt.claims',
  json_build_object('sub', 'a0000000-0000-0000-0000-000000000002', 'role', 'authenticated')::text, true);

INSERT INTO public.reclamos
  (id, pedido_id, cliente_id, motivo, descripcion, estado)
VALUES ('b0000000-0000-0000-0000-000000000005'::uuid, '40000000-0000-0000-0000-000000000005'::uuid, 'a0000000-0000-0000-0000-000000000002'::uuid,
  'Incidencia de calidad en producto de prueba',
  'Reclamo de prueba pendiente de resolucion administrativa.',
  'abierto');
-- El reclamo no cambia el pedido: permanece completado y conserva su comprobante autorizado.

-- ============================================================
-- BLOQUE 17 - VALIDACION ATOMICA: CINCO PEDIDOS Y CUATRO ENVIOS
-- ============================================================

SELECT set_config('request.jwt.claims', NULL, true);

DO $$
BEGIN
  IF (SELECT count(*) FROM auth.users WHERE id IN ('a0000000-0000-0000-0000-000000000001'::uuid,
    'a0000000-0000-0000-0000-000000000002'::uuid,
    'a0000000-0000-0000-0000-000000000101'::uuid,
    'a0000000-0000-0000-0000-000000000102'::uuid,
    'a0000000-0000-0000-0000-000000000103'::uuid,
    'a0000000-0000-0000-0000-000000000104'::uuid,
    'a0000000-0000-0000-0000-000000000105'::uuid)) <> 7 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir los siete usuarios reservados.';
  END IF;

  IF (SELECT count(*) FROM public.perfiles WHERE id IN ('a0000000-0000-0000-0000-000000000001'::uuid,
    'a0000000-0000-0000-0000-000000000002'::uuid,
    'a0000000-0000-0000-0000-000000000101'::uuid,
    'a0000000-0000-0000-0000-000000000102'::uuid,
    'a0000000-0000-0000-0000-000000000103'::uuid,
    'a0000000-0000-0000-0000-000000000104'::uuid,
    'a0000000-0000-0000-0000-000000000105'::uuid)) <> 7 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir los siete perfiles reservados.';
  END IF;

  IF (SELECT count(*) FROM auth.identities WHERE provider = 'email' AND user_id IN ('a0000000-0000-0000-0000-000000000001'::uuid,
    'a0000000-0000-0000-0000-000000000002'::uuid,
    'a0000000-0000-0000-0000-000000000101'::uuid,
    'a0000000-0000-0000-0000-000000000102'::uuid,
    'a0000000-0000-0000-0000-000000000103'::uuid,
    'a0000000-0000-0000-0000-000000000104'::uuid,
    'a0000000-0000-0000-0000-000000000105'::uuid)) <> 7 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir siete identidades email.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.perfiles WHERE id = 'a0000000-0000-0000-0000-000000000001'::uuid
    AND rol = 'admin' AND es_super_admin AND es_protegido AND activo) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: Administrador Base incorrecto.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.perfiles WHERE id = 'a0000000-0000-0000-0000-000000000002'::uuid
    AND rol = 'cliente' AND activo) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: perfil cliente incorrecto.';
  END IF;

  IF (SELECT count(*) FROM public.productores pr JOIN public.perfiles p ON p.id = pr.perfil_id
    WHERE pr.id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)
      AND pr.perfil_id::text = 'a0000000-0000-0000-0000-' || lpad((100 + right(pr.id::text,12)::integer)::text,12,'0')
      AND p.rol = 'vendedor') <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir los cinco productores con sus perfiles vendedores.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.productores pr WHERE pr.id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)
    AND (SELECT count(*) FROM public.direcciones d WHERE d.perfil_id = pr.perfil_id AND d.activo) <> 1) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: cada productor debe tener exactamente una direccion activa.';
  END IF;

  IF (SELECT count(*) FROM public.direcciones WHERE perfil_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND activo AND es_principal) <> 1 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: el cliente debe tener una direccion principal activa.';
  END IF;

  IF (SELECT count(*) FROM public.postulaciones_vendedores WHERE id IN ('14000000-0000-0000-0000-000000000001'::uuid, '14000000-0000-0000-0000-000000000002'::uuid, '14000000-0000-0000-0000-000000000003'::uuid, '14000000-0000-0000-0000-000000000004'::uuid, '14000000-0000-0000-0000-000000000005'::uuid)
    AND estado = 'aprobada' AND revisado_por = 'a0000000-0000-0000-0000-000000000001'::uuid AND revisado_en IS NOT NULL) <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: las cinco postulaciones deben estar aprobadas por admin.';
  END IF;
/*
  IF (SELECT count(*) FROM public.datos_bancarios WHERE perfil_id IN ('a0000000-0000-0000-0000-000000000002'::uuid, 'a0000000-0000-0000-0000-000000000101'::uuid, 'a0000000-0000-0000-0000-000000000102'::uuid, 'a0000000-0000-0000-0000-000000000103'::uuid, 'a0000000-0000-0000-0000-000000000104'::uuid, 'a0000000-0000-0000-0000-000000000105'::uuid)) <> 6
    OR EXISTS (SELECT 1 FROM public.perfiles p WHERE p.id IN ('a0000000-0000-0000-0000-000000000002'::uuid, 'a0000000-0000-0000-0000-000000000101'::uuid, 'a0000000-0000-0000-0000-000000000102'::uuid, 'a0000000-0000-0000-0000-000000000103'::uuid, 'a0000000-0000-0000-0000-000000000104'::uuid, 'a0000000-0000-0000-0000-000000000105'::uuid)
      AND (SELECT count(*) FROM public.datos_bancarios b WHERE b.perfil_id = p.id AND b.activo) <> 1) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir seis filas bancarias y una activa por titular.';
  END IF;
*/
  IF NOT EXISTS (SELECT 1 FROM public.productores WHERE id = '20000000-0000-0000-0000-000000000004'::uuid AND NOT activo)
    OR NOT EXISTS (SELECT 1 FROM public.sanciones WHERE id = 'a1000000-0000-0000-0000-000000000004'::uuid
      AND productor_id = '20000000-0000-0000-0000-000000000004'::uuid AND tipo = 'suspension' AND accion = 'suspender'
      AND estado IN ('activa','apelada') AND duracion_dias = 30
      AND fin_en = inicio_en + interval '30 days' AND impuesta_por = 'a0000000-0000-0000-0000-000000000001'::uuid) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: P4 debe estar inactivo y tener suspension vigente de 30 dias.';
  END IF;

  IF (SELECT count(*) FROM public.productores WHERE id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000005'::uuid) AND activo) <> 4 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: los otros cuatro productores deben estar activos.';
  END IF;

  IF (SELECT count(*) FROM public.categorias WHERE id IN ('13000000-0000-0000-0000-000000000001'::uuid, '13000000-0000-0000-0000-000000000002'::uuid, '13000000-0000-0000-0000-000000000003'::uuid, '13000000-0000-0000-0000-000000000004'::uuid, '13000000-0000-0000-0000-000000000005'::uuid)
    AND NOT es_sistema AND eliminado_en IS NULL) <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir cinco categorias propias ademas de Sin Categoria.';
  END IF;

  IF (SELECT count(*) FROM public.productos WHERE productor_id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)) <> 20
    OR (SELECT count(*) FROM public.productos WHERE id IN ('30000000-0000-0000-0000-000000000101'::uuid, '30000000-0000-0000-0000-000000000102'::uuid, '30000000-0000-0000-0000-000000000103'::uuid, '30000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000201'::uuid, '30000000-0000-0000-0000-000000000202'::uuid, '30000000-0000-0000-0000-000000000203'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000301'::uuid, '30000000-0000-0000-0000-000000000302'::uuid, '30000000-0000-0000-0000-000000000303'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000401'::uuid, '30000000-0000-0000-0000-000000000402'::uuid, '30000000-0000-0000-0000-000000000403'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000501'::uuid, '30000000-0000-0000-0000-000000000502'::uuid, '30000000-0000-0000-0000-000000000503'::uuid, '30000000-0000-0000-0000-000000000504'::uuid)) <> 20
    OR EXISTS (SELECT 1 FROM public.productores pr WHERE pr.id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)
      AND (SELECT count(*) FROM public.productos p WHERE p.productor_id = pr.id) <> 4) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir veinte productos, cuatro por productor.';
  END IF;

  IF (SELECT count(*) FROM public.productos WHERE id IN ('30000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000504'::uuid)
    AND fecha_cosecha = CURRENT_DATE - 10) <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: el cuarto producto de cada productor debe tener cosecha de hace diez dias.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.productos WHERE id IN ('30000000-0000-0000-0000-000000000101'::uuid, '30000000-0000-0000-0000-000000000102'::uuid, '30000000-0000-0000-0000-000000000103'::uuid, '30000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000201'::uuid, '30000000-0000-0000-0000-000000000202'::uuid, '30000000-0000-0000-0000-000000000203'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000301'::uuid, '30000000-0000-0000-0000-000000000302'::uuid, '30000000-0000-0000-0000-000000000303'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000401'::uuid, '30000000-0000-0000-0000-000000000402'::uuid, '30000000-0000-0000-0000-000000000403'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000501'::uuid, '30000000-0000-0000-0000-000000000502'::uuid, '30000000-0000-0000-0000-000000000503'::uuid, '30000000-0000-0000-0000-000000000504'::uuid)
    AND (slug IS NULL OR slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'))
    OR EXISTS (SELECT 1 FROM public.productores WHERE id IN ('20000000-0000-0000-0000-000000000001'::uuid, '20000000-0000-0000-0000-000000000002'::uuid, '20000000-0000-0000-0000-000000000003'::uuid, '20000000-0000-0000-0000-000000000004'::uuid, '20000000-0000-0000-0000-000000000005'::uuid)
      AND (slug IS NULL OR slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$')) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: los slugs deben ser generados y validos.';
  END IF;

  IF (SELECT count(*) FROM public.imagenes_productos WHERE producto_id IN ('30000000-0000-0000-0000-000000000101'::uuid, '30000000-0000-0000-0000-000000000102'::uuid, '30000000-0000-0000-0000-000000000103'::uuid, '30000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000201'::uuid, '30000000-0000-0000-0000-000000000202'::uuid, '30000000-0000-0000-0000-000000000203'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000301'::uuid, '30000000-0000-0000-0000-000000000302'::uuid, '30000000-0000-0000-0000-000000000303'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000401'::uuid, '30000000-0000-0000-0000-000000000402'::uuid, '30000000-0000-0000-0000-000000000403'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000501'::uuid, '30000000-0000-0000-0000-000000000502'::uuid, '30000000-0000-0000-0000-000000000503'::uuid, '30000000-0000-0000-0000-000000000504'::uuid)) <> 20
    OR EXISTS (SELECT 1 FROM public.productos p WHERE p.id IN ('30000000-0000-0000-0000-000000000101'::uuid, '30000000-0000-0000-0000-000000000102'::uuid, '30000000-0000-0000-0000-000000000103'::uuid, '30000000-0000-0000-0000-000000000104'::uuid, '30000000-0000-0000-0000-000000000201'::uuid, '30000000-0000-0000-0000-000000000202'::uuid, '30000000-0000-0000-0000-000000000203'::uuid, '30000000-0000-0000-0000-000000000204'::uuid, '30000000-0000-0000-0000-000000000301'::uuid, '30000000-0000-0000-0000-000000000302'::uuid, '30000000-0000-0000-0000-000000000303'::uuid, '30000000-0000-0000-0000-000000000304'::uuid, '30000000-0000-0000-0000-000000000401'::uuid, '30000000-0000-0000-0000-000000000402'::uuid, '30000000-0000-0000-0000-000000000403'::uuid, '30000000-0000-0000-0000-000000000404'::uuid, '30000000-0000-0000-0000-000000000501'::uuid, '30000000-0000-0000-0000-000000000502'::uuid, '30000000-0000-0000-0000-000000000503'::uuid, '30000000-0000-0000-0000-000000000504'::uuid)
      AND (SELECT count(*) FROM public.imagenes_productos im WHERE im.producto_id = p.id
        AND im.es_principal AND im.posicion = 1 AND im.mime_type = 'image/webp'
        AND im.tamano_bytes = 102400
        AND im.ruta_storage = 'product-images/' || p.id::text || '/' || im.nombre_archivo) <> 1) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir veinte imagenes, una principal valida por producto.';
  END IF;

  IF (SELECT count(*) FROM public.pedidos WHERE cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid) <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir cinco pedidos del cliente.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.pedidos WHERE id = '40000000-0000-0000-0000-000000000001'::uuid
    AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'creado') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del pedido del ciclo 1.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.pedidos WHERE id = '40000000-0000-0000-0000-000000000002'::uuid
    AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'en_preparacion') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del pedido del ciclo 2.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.pedidos WHERE id = '40000000-0000-0000-0000-000000000003'::uuid
    AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'en_preparacion') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del pedido del ciclo 3.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.pedidos WHERE id = '40000000-0000-0000-0000-000000000004'::uuid
    AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'completado') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del pedido del ciclo 4.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.pedidos WHERE id = '40000000-0000-0000-0000-000000000005'::uuid
    AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'completado') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del pedido del ciclo 5.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.pagos WHERE pedido_id = '40000000-0000-0000-0000-000000000001'::uuid)
    OR EXISTS (SELECT 1 FROM public.envios WHERE pedido_id = '40000000-0000-0000-0000-000000000001'::uuid) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: el ciclo 1 no debe tener pago ni envio.';
  END IF;

  IF (SELECT count(*) FROM public.detalles_pedido WHERE pedido_id IN ('40000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)) <> 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: debe existir un detalle en cada pedido.';
  END IF;

  IF (SELECT count(*) FROM public.envios WHERE pedido_id IN ('40000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)) <> 4 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben existir exactamente cuatro envios, correspondientes a ciclos 2 a 5.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.envios WHERE id = '70000000-0000-0000-0000-000000000002'::uuid
    AND pedido_id = '40000000-0000-0000-0000-000000000002'::uuid AND estado = 'preparacion') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del envio del ciclo 2.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.envios WHERE id = '70000000-0000-0000-0000-000000000003'::uuid
    AND pedido_id = '40000000-0000-0000-0000-000000000003'::uuid AND estado = 'en_transito') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del envio del ciclo 3.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.envios WHERE id = '70000000-0000-0000-0000-000000000004'::uuid
    AND pedido_id = '40000000-0000-0000-0000-000000000004'::uuid AND estado = 'entregado') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del envio del ciclo 4.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.envios WHERE id = '70000000-0000-0000-0000-000000000005'::uuid
    AND pedido_id = '40000000-0000-0000-0000-000000000005'::uuid AND estado = 'entregado') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: estado incorrecto del envio del ciclo 5.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.envios e JOIN public.pedidos p ON p.id = e.pedido_id
    JOIN public.productores pr ON pr.id = p.productor_id
    WHERE p.id IN ('40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid) AND e.repartidor_id <> pr.perfil_id) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: cada repartidor debe ser el perfil del productor del pedido.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.envios WHERE pedido_id IN ('40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)
    AND estado IN ('en_transito','entregado')
    AND (length(btrim(coalesce(codigo_verificacion,''))) = 0 OR despachado_en IS NULL)) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: los envios en transito o entregados deben tener codigo y fecha de despacho.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.envios WHERE pedido_id IN ('40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)
    AND (codigo_verificado_en IS NULL OR entregado_en IS NULL)) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: los dos envios entregados deben tener codigo verificado y fecha de entrega.';
  END IF;

  IF (SELECT count(*) FROM public.pagos WHERE pedido_id::text like '40000000-%') <> 4
    OR EXISTS (SELECT 1 FROM public.pagos WHERE pedido_id::text like '40000000-%'
      AND (codigo_respuesta <> '0' OR autorizado_en IS NULL
        OR respuesta_webpay->>'status' <> 'AUTHORIZED' OR codigo_comercio IS NULL)) THEN
    RAISE EXCEPTION 'Validacion seed: deben existir cuatro comprobantes Webpay Mall autorizados.';
  END IF;
  IF (SELECT count(*) FROM public.productores WHERE id::text like '20000000-%'
      AND codigo_comercio_mall = '597055555536') <> 5
    OR EXISTS (SELECT 1 FROM public.productores WHERE id::text like '20000000-%'
      AND codigo_comercio_mall IS DISTINCT FROM '597055555536')
    OR EXISTS (SELECT 1 FROM public.productores WHERE id::text like '20000000-%' AND rut_oficial IS NULL)
    OR (SELECT count(*) FROM public.postulaciones_revisiones WHERE postulacion_id::text like '14000000-%') <> 5 THEN
    RAISE EXCEPTION 'Validacion seed: se requieren cinco productores con comercio 597055555536, RUT e historial de aprobaciones.';
  END IF;

  IF (SELECT count(*) FROM public.reclamos WHERE pedido_id IN ('40000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)) <> 1
    OR NOT EXISTS (SELECT 1 FROM public.reclamos WHERE id = 'b0000000-0000-0000-0000-000000000005'::uuid
      AND pedido_id = '40000000-0000-0000-0000-000000000005'::uuid AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND estado = 'abierto') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: debe existir exactamente un reclamo abierto del ciclo 5.';
  END IF;

  IF (SELECT count(*) FROM public.evaluaciones_reputacion WHERE pedido_id IN ('40000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)) <> 1
    OR NOT EXISTS (SELECT 1 FROM public.evaluaciones_reputacion WHERE id = '90000000-0000-0000-0000-000000000004'::uuid
      AND pedido_id = '40000000-0000-0000-0000-000000000004'::uuid AND productor_id = '20000000-0000-0000-0000-000000000005'::uuid
      AND cliente_id = 'a0000000-0000-0000-0000-000000000002'::uuid AND puntaje = 5)
    OR NOT EXISTS (SELECT 1 FROM public.productores WHERE id = '20000000-0000-0000-0000-000000000005'::uuid
      AND cantidad_evaluaciones = 1 AND puntaje_reputacion = 5.00) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: evaluacion de cinco puntos o reputacion acumulada incorrecta.';
  END IF;

  IF (SELECT count(*) FROM public.palabras_prohibidas WHERE activo
    AND palabra IN ('estafa','falso','inutil','basura','malo')) < 5 THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: deben estar activas las cinco palabras prohibidas.';
  END IF;

  IF EXISTS (SELECT 1 FROM public.pedidos p WHERE p.id IN ('40000000-0000-0000-0000-000000000001'::uuid, '40000000-0000-0000-0000-000000000002'::uuid, '40000000-0000-0000-0000-000000000003'::uuid, '40000000-0000-0000-0000-000000000004'::uuid, '40000000-0000-0000-0000-000000000005'::uuid)
    AND (p.subtotal_productos <> (SELECT sum(d.subtotal) FROM public.detalles_pedido d WHERE d.pedido_id = p.id)
      OR p.total <> p.subtotal_productos + 3500.00
      OR p.monto_fee_plataforma <> round(p.subtotal_productos * 0.0500,2))) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: los totales y el fee deben coincidir con los detalles y la tarifa MVP.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = '30000000-0000-0000-0000-000000000101'::uuid AND stock = 50)
    OR NOT EXISTS (SELECT 1 FROM public.productos WHERE id = '30000000-0000-0000-0000-000000000201'::uuid AND stock = 46)
    OR NOT EXISTS (SELECT 1 FROM public.productos WHERE id = '30000000-0000-0000-0000-000000000501'::uuid AND stock = 49) THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: el stock debe descontarse solo para los cuatro pedidos pagados.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_trigger WHERE tgrelid = 'public.perfiles'::regclass
    AND tgname = 'trg_validar_seguridad_perfil' AND tgenabled = 'O') THEN
    RAISE EXCEPTION 'Validacion seed CuTuCo: el trigger de seguridad debe seguir habilitado al finalizar.';
  END IF;
  RAISE NOTICE 'Seed CuTuCo validado: 7 usuarios, 5 productores, 20 productos, 5 pedidos y 4 envios.';
END;
$$;

-- Restablecer contextos transaccionales antes del unico COMMIT.
SELECT set_config('cutuco.operacion_interna', 'false', true);
SELECT set_config('request.jwt.claims', NULL, true);
COMMIT;


