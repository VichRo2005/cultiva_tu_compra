-- Verificación local transaccional de RLS/triggers: ROLLBACK preserva el seed.
-- Se ejecuta desde integracion-supabase.admin-usuarios.spec.js contra Supabase.
begin;
set local role authenticated;
set local request.jwt.claims = '{"sub":"a0000000-0000-0000-0000-000000000001","role":"authenticated"}';

do $$
declare
  v_vendedor uuid := 'a0000000-0000-0000-0000-000000000104';
  v_admin uuid := 'a0000000-0000-0000-0000-000000000001';
  v_fecha timestamptz;
  v_actor uuid;
begin
  update public.perfiles set activo = false where id = v_vendedor;
  if exists (select 1 from public.productores where perfil_id = v_vendedor and activo) then
    raise exception 'La desactivacion no sincronizo productor';
  end if;
  update public.perfiles set activo = true where id = v_vendedor;
  if not exists (select 1 from public.productores where perfil_id = v_vendedor and activo) then
    raise exception 'La reactivacion no sincronizo productor';
  end if;

  update public.perfiles set eliminado_en = '1970-01-01',
    eliminado_por = 'a0000000-0000-0000-0000-000000000002' where id = v_vendedor;
  select eliminado_en, eliminado_por into v_fecha, v_actor from public.perfiles where id = v_vendedor;
  if v_fecha is distinct from transaction_timestamp() or v_actor is distinct from v_admin then
    raise exception 'La auditoria no proviene del servidor y del administrador autenticado';
  end if;
  if not exists (select 1 from public.perfiles where id = v_vendedor and not activo)
    or not exists (select 1 from public.productores where perfil_id = v_vendedor and not activo) then
    raise exception 'La eliminacion no conservo y desactivo ambas filas';
  end if;

  begin
    update public.perfiles set activo = true where id = v_vendedor;
    raise exception 'Se permitio reactivar un perfil eliminado';
  exception when check_violation then null;
  end;
  begin
    update public.perfiles set eliminado_en = null, eliminado_por = null where id = v_vendedor;
    raise exception 'Se permitio revertir la eliminacion';
  exception when check_violation then null;
  end;
  begin
    update public.perfiles set eliminado_por = v_vendedor where id = v_vendedor;
    raise exception 'Se permitio alterar al actor';
  exception when check_violation then null;
  end;
  begin
    update public.productores set activo = true where perfil_id = v_vendedor;
    raise exception 'Se permitio reactivar el productor de un perfil eliminado';
  exception when check_violation then null;
  end;
  begin
    update public.perfiles set eliminado_en = now() where id = v_admin;
    raise exception 'Se permitio eliminar al administrador protegido';
  exception when insufficient_privilege then null;
  end;
  begin
    delete from public.perfiles where id = v_vendedor;
    raise exception 'Se permitio DELETE fisico desde la API autenticada';
  exception when insufficient_privilege then null;
  end;
end;
$$;

set local request.jwt.claims = '{"sub":"a0000000-0000-0000-0000-000000000002","role":"authenticated"}';
do $$
begin
  begin
    update public.perfiles set eliminado_en = now() where id = (select auth.uid());
    raise exception 'Se permitio que un cliente marcara su propia eliminacion';
  exception when insufficient_privilege then null;
  end;
end;
$$;
rollback;
