-- Verifica el resultado completo de db reset, incluidos los fixtures de galeria.
\set ON_ERROR_STOP on
do $$
begin
  if (select count(*) from auth.users where id in (
    'e0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002',
    'e0000000-0000-0000-0000-000000000003', 'e0000000-0000-0000-0000-000000000004'
  )) <> 4 then raise exception 'Faltan cuentas de galeria'; end if;
  if (select count(*) from auth.identities where provider = 'email' and user_id in (
    'e0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002',
    'e0000000-0000-0000-0000-000000000003', 'e0000000-0000-0000-0000-000000000004'
  )) <> 4 then raise exception 'Identidades de galeria ausentes o duplicadas'; end if;
  if not exists (select 1 from public.postulaciones_vendedores
    where id = 'e2000000-0000-0000-0000-000000000004' and estado = 'en_revision'
      and rut_solicitante = '12345678-5' and tipo_de_persona = 'natural'
      and private.ruta_documento_valida(documento_identidad, perfil_id)
      and private.ruta_documento_valida(certificado_inicio_actividades_o_carnet_representante, perfil_id)
      and private.ruta_documento_valida(certificado_titularidad_bancaria, perfil_id)
      and private.ruta_documento_valida(comprobante_domicilio, perfil_id)
      and intento = 1 and revisado_por is null and revisado_en is null
  ) then raise exception 'La solicitud de galeria no cumple el contrato vigente'; end if;
  if not exists (select 1 from public.productores
    where id = '20000000-0000-0000-0000-000000000001'
      and perfil_id = 'e0000000-0000-0000-0000-000000000002'
      and rut_oficial is not null and codigo_comercio_mall is not null
  ) then raise exception 'Productor de galeria incorrecto'; end if;
  if (select count(*) from public.documentos_identidad
    where postulacion_id = 'e2000000-0000-0000-0000-000000000004') <> 2 then
    raise exception 'Documentos legacy ausentes o duplicados';
  end if;
  if (select count(*) from public.pagos) <> 4 then raise exception 'Se alteraron los pagos del seed principal'; end if;
  raise notice 'PASS: galeria completa, solicitud en_revision con antecedentes y sin duplicados';
end;
$$;
