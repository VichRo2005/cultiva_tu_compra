param([switch]$Coverage, [string]$TestPath = 'tests')
$ErrorActionPreference = 'Stop'
$repo = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$container = 'cutuco-checklist-' + [guid]::NewGuid().ToString('N').Substring(0, 10)
$started = $false
function Sql([string]$path) {
    Write-Host "SQL: $(Split-Path $path -Leaf)"
    Get-Content -Raw -LiteralPath $path | docker exec -i $container psql -U postgres -v ON_ERROR_STOP=1 -q -o /dev/null
    if ($LASTEXITCODE -ne 0) { throw "Falló $(Split-Path $path -Leaf)" }
}
try {
    # Docker fails if this port belongs to an existing local database. Never reuse it.
    docker run --name $container -e POSTGRES_PASSWORD=postgres -p 127.0.0.1:54322:5432 -d pgvector/pgvector:pg16 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear la base efímera en el puerto de pruebas.' }
    $started = $true
    for ($i=0; $i -lt 30; $i++) {
        docker exec $container pg_isready -U postgres 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { break }
        Start-Sleep -Seconds 1
    }
    Sql (Join-Path $PSScriptRoot 'bootstrap_pg16.sql')
    Get-ChildItem (Join-Path $repo 'supabase/migrations/*.sql') | Sort-Object Name | ForEach-Object { Sql $_.FullName }
    Sql (Join-Path $repo 'supabase/seed.sql')
    Sql (Join-Path $PSScriptRoot 'checklist.sql')
    Push-Location (Join-Path $repo 'backend')
    try {
        $report = if ($TestPath -eq 'tests') { 'backend.xml' } else { 'backend-targeted.xml' }
        $pytestArgs = @($TestPath, '-v', '--tb=short', '-o', 'faulthandler_timeout=45', "--junitxml=../work/checklist-audit/$report")
        if ($Coverage) {
            $pytestArgs += @('--cov=app', '--cov-report=term', '--cov-report=json:../work/checklist-audit/coverage.json')
        }
        & .\.venv\Scripts\python.exe -u -m pytest @pytestArgs
        if ($LASTEXITCODE -ne 0) { throw 'Fallaron pruebas backend; revisar reporte.' }
    } finally { Pop-Location }
} finally {
    # Exclusivamente el contenedor recién creado para esta ejecución.
    if ($started) { docker rm -f -v $container | Out-Null }
}
