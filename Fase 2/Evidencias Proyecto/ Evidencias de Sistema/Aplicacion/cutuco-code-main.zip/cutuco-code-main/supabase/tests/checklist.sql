-- CK-0242/0250/0255/0257/0273. Ejecutar solo en DB efímera, con seed.
\set ON_ERROR_STOP on
begin;
create function pg_temp.check_ok(ok boolean, label text) returns void language plpgsql as $$
begin
  if ok is distinct from true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end;
$$;
create function pg_temp.check_fails(query text, label text) returns void language plpgsql as $$
begin
  begin execute query;
  exception when others then raise notice 'PASS: %', label; return;
  end;
  raise exception 'FAIL: %', label;
end;
$$;
-- Simula una cuota emitida con monto histórico. Reemisión no debe sobrescribirla.
update public.pagos_servicio set monto=9900
where productor_id='20000000-0000-0000-0000-000000000001';
select private.crear_cuota_servicio('20000000-0000-0000-0000-000000000001');
select pg_temp.check_ok((select monto=9900 from public.pagos_servicio
where productor_id='20000000-0000-0000-0000-000000000001'
order by periodo desc limit 1), 'CK-0242 conserva cuota histórica');
select pg_temp.check_ok((select monto=2990 from public.pagos_servicio
where productor_id='20000000-0000-0000-0000-000000000002'
order by periodo desc limit 1), 'CK-0242 cuota nueva 2990');

set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-0000-0000-000000000102","role":"authenticated"}',true);
select pg_temp.check_ok(public.registrar_transferencia_servicio('QA-123456','Transferencia de prueba')->>'estado'='pendiente_revision', 'CK-0250 referencia no acredita pago');
select pg_temp.check_ok((select pagado_en is null from public.pagos_servicio
where productor_id='20000000-0000-0000-0000-000000000002'
order by periodo desc limit 1), 'CK-0250 no registra fecha de pago sin aprobación');
reset role;

select set_config('request.jwt.claims','{"sub":"a0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
set local role authenticated;
select pg_temp.check_fails(format('select public.resolver_pago_servicio(%L::uuid,''rechazado'','''')',
(select id from public.pagos_servicio where referencia='QA-123456')), 'CK-0273 rechazo exige motivo');
select public.resolver_pago_servicio((select id from public.pagos_servicio where referencia='QA-123456'),'rechazado','No se observa el abono');
select pg_temp.check_fails(format('select public.resolver_pago_servicio(%L::uuid,''pagado'',''repetido'')',
(select id from public.pagos_servicio where referencia='QA-123456')), 'CK-0277 no resuelve dos veces');
reset role;

update public.pagos_servicio set estado='pendiente',emitido_en=(now() at time zone 'America/Santiago')::date-15,
vence_en=(now() at time zone 'America/Santiago')::date-5
where productor_id='20000000-0000-0000-0000-000000000002';
select pg_temp.check_ok(private.estado_servicio('20000000-0000-0000-0000-000000000002')='pendiente', 'CK-0255 gracia incluye día 15');
update public.pagos_servicio set estado='pendiente_revision',emitido_en=emitido_en-1,vence_en=vence_en-1
where productor_id='20000000-0000-0000-0000-000000000002';
select pg_temp.check_ok(private.estado_servicio('20000000-0000-0000-0000-000000000002')='vencido', 'CK-0255 revisión no acredita pago al día 16');
rollback;
