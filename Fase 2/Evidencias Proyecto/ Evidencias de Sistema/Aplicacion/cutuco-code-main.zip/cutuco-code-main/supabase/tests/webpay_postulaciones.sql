-- Ejecutar tras migrations + seed.sql. Todo se revierte al terminar.
\set ON_ERROR_STOP on
begin;
set local storage.allow_delete_query = 'true';
create function pg_temp.ok(p_cond boolean, p_label text) returns void language plpgsql as $$
begin
  if p_cond is distinct from true then raise exception 'FAIL: %', p_label; end if;
  raise notice 'PASS: %', p_label;
end;
$$;
create function pg_temp.fails(p_sql text, p_pattern text, p_label text)
returns void language plpgsql as $$
begin
  begin
    execute p_sql;
  exception when others then
    if sqlerrm !~ p_pattern then raise exception 'FAIL %: error inesperado %', p_label, sqlerrm; end if;
    raise notice 'PASS: %', p_label;
    return;
  end;
  raise exception 'FAIL: % no rechazo la operacion', p_label;
end;
$$;
select pg_temp.ok(to_regclass('public.payouts') is null and to_regtype('public.tipo_payout') is null
  and to_regtype('public.estado_payout') is null and to_regtype('public.estado_pago') is null, 'sin payouts ni enums financieros');
select pg_temp.ok(not exists(select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
  where n.nspname in ('public','private') and p.prokind = 'f'
  and (p.prosrc ~ 'monto_retenido|monto_liquidar_productor|liberable_desde_en|payout_ejecutado_en|public\."?payouts')),
  'sin referencias funcionales a escrow');
select pg_temp.ok((select not public and file_size_limit = 10485760 from storage.buckets where id='vendedor-documentos'),
  'bucket privado con limite de 10 MiB');
insert into auth.users(id, raw_user_meta_data) values
  ('f0000000-0000-0000-0000-000000000001', '{"nombre":"Solicitante prueba"}'),
  ('f0000000-0000-0000-0000-000000000002', '{"nombre":"Otro usuario"}');
insert into public.direcciones(perfil_id, comuna_id, calle)
  values ('f0000000-0000-0000-0000-000000000001','12000000-0000-0000-0000-000000000004','Calle de prueba');

set local role authenticated;
select set_config('request.jwt.claims','{"sub":"f0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
insert into storage.objects(bucket_id,name) values ('vendedor-documentos','f0000000-0000-0000-0000-000000000001/cedula.pdf');
update storage.objects set name='f0000000-0000-0000-0000-000000000001/cedula-nueva.pdf'
  where bucket_id='vendedor-documentos' and name='f0000000-0000-0000-0000-000000000001/cedula.pdf';
select pg_temp.ok((select count(*)=1 from storage.objects where bucket_id='vendedor-documentos'), 'propietario carga y renombra antes de postular');
delete from storage.objects where bucket_id='vendedor-documentos';
select pg_temp.ok((select count(*)=0 from storage.objects where bucket_id='vendedor-documentos'), 'propietario elimina antes de postular');
select pg_temp.fails($q$insert into storage.objects(bucket_id,name) values ('vendedor-documentos','f0000000-0000-0000-0000-000000000002/cedula.pdf')$q$,
  'row-level security', 'no carga documentos en carpeta ajena');
insert into public.postulaciones_vendedores(id,perfil_id,nombre_comercial_solicitado)
  values ('f1000000-0000-0000-0000-000000000001',auth.uid(),'Tienda prueba') returning id;
select pg_temp.ok((select estado='borrador' from public.postulaciones_vendedores where perfil_id=auth.uid()), 'INSERT RETURNING y lectura del borrador');
select pg_temp.fails($q$update public.postulaciones_vendedores set estado='en_revision' where perfil_id=auth.uid()$q$,
  'Complete RUT', 'no envia solicitud incompleta');
select pg_temp.fails($q$update public.postulaciones_vendedores set documento_identidad='vendedor-documentos/f0000000-0000-0000-0000-000000000002/cedula.pdf' where perfil_id=auth.uid()$q$,
  'Documento fuera', 'no referencia documentos ajenos');
select pg_temp.fails($q$update public.postulaciones_vendedores set estado='aprobada' where perfil_id=auth.uid()$q$,
  'Solo se puede', 'no puede autoaprobarse');
select pg_temp.fails($q$update public.postulaciones_vendedores set observaciones_admin='Observacion falsa' where perfil_id=auth.uid()$q$,
  'no puede cambiar', 'no puede falsificar observaciones');
update public.postulaciones_vendedores set rut_solicitante='12345678-5', tipo_de_persona='juridica',
  documento_identidad='vendedor-documentos/'||auth.uid()||'/e-rut.pdf',
  certificado_inicio_actividades_o_carnet_representante='vendedor-documentos/'||auth.uid()||'/representante.pdf',
  certificado_titularidad_bancaria='vendedor-documentos/'||auth.uid()||'/banco.pdf',
  comprobante_domicilio='vendedor-documentos/'||auth.uid()||'/domicilio.pdf' where perfil_id=auth.uid();
insert into storage.objects(bucket_id,name) values ('vendedor-documentos',auth.uid()||'/e-rut.pdf');
update public.postulaciones_vendedores set estado='en_revision' where perfil_id=auth.uid();
select pg_temp.ok((select estado='en_revision' from public.postulaciones_vendedores where perfil_id=auth.uid()), 'envia solicitud completa');
update public.postulaciones_vendedores set descripcion='No debe guardar' where perfil_id=auth.uid();
select pg_temp.ok((select descripcion is null from public.postulaciones_vendedores where perfil_id=auth.uid()), 'solicitud en revision solo lectura');
select pg_temp.fails($q$insert into storage.objects(bucket_id,name) values ('vendedor-documentos',auth.uid()||'/extra.pdf')$q$,
  'row-level security', 'no carga durante revision');
update storage.objects set name=auth.uid()||'/cambio.pdf' where bucket_id='vendedor-documentos';
delete from storage.objects where bucket_id='vendedor-documentos';
select pg_temp.ok((select count(*)=1 from storage.objects where bucket_id='vendedor-documentos' and name=auth.uid()||'/e-rut.pdf'), 'no actualiza ni elimina documentos durante revision');
select pg_temp.fails($q$insert into public.postulaciones_vendedores(perfil_id,nombre_comercial_solicitado) values (auth.uid(),'Duplicada')$q$,
  'reutilizar', 'no evade bloqueo creando otra postulacion');
select pg_temp.fails($q$select public.resolver_postulacion_vendedor('f1000000-0000-0000-0000-000000000001','aprobada')$q$,
  'Solo un administrador', 'RPC rechaza solicitante');

select set_config('request.jwt.claims','{"sub":"f0000000-0000-0000-0000-000000000002","role":"authenticated"}',true);
select pg_temp.ok((select count(*)=0 from storage.objects where bucket_id='vendedor-documentos'), 'tercero no lee documentos');
select pg_temp.ok((select count(*)=0 from public.postulaciones_vendedores), 'tercero no lee postulaciones');
select pg_temp.ok((select count(*)=0 from public.postulaciones_revisiones), 'tercero no lee historial');

select set_config('request.jwt.claims','{"sub":"a0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
select pg_temp.ok((select count(*)=1 from storage.objects where bucket_id='vendedor-documentos'), 'admin consulta documentos');
select pg_temp.fails($q$insert into storage.objects(bucket_id,name) values ('vendedor-documentos',auth.uid()||'/admin.pdf')$q$,
  'row-level security', 'admin no carga documentos');
update storage.objects set name='cambio.pdf' where bucket_id='vendedor-documentos';
delete from storage.objects where bucket_id='vendedor-documentos';
select pg_temp.ok((select count(*)=1 from storage.objects where bucket_id='vendedor-documentos'), 'admin no actualiza ni elimina documentos');
update public.postulaciones_vendedores set descripcion='Cambio admin' where id='f1000000-0000-0000-0000-000000000001';
select pg_temp.ok((select descripcion is null from public.postulaciones_vendedores where id='f1000000-0000-0000-0000-000000000001'), 'admin no edita datos del postulante');
select pg_temp.fails($q$select public.resolver_postulacion_vendedor('f1000000-0000-0000-0000-000000000001','rechazada','')$q$,
  'requiere observaciones', 'rechazo exige motivo');
select (public.resolver_postulacion_vendedor('f1000000-0000-0000-0000-000000000001','rechazada','Falta documento legible')).id;

select set_config('request.jwt.claims','{"sub":"f0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
insert into storage.objects(bucket_id,name) values ('vendedor-documentos',auth.uid()||'/corregido.pdf');
update public.postulaciones_vendedores set documento_identidad='vendedor-documentos/'||auth.uid()||'/corregido.pdf', estado='en_revision' where perfil_id=auth.uid();
select pg_temp.ok((select estado='en_revision' and intento=2 and observaciones_admin='Falta documento legible'
  and revisado_por is null and revisado_en is null from public.postulaciones_vendedores where perfil_id=auth.uid()), 'reintento conserva observacion y reinicia revision');
select pg_temp.ok((select count(*)=1 from public.postulaciones_revisiones where observaciones_admin='Falta documento legible'), 'rechazo permanece en historial');
select pg_temp.fails($q$delete from public.postulaciones_revisiones$q$, 'permission denied', 'historial inmutable para solicitante');

select set_config('request.jwt.claims','{"sub":"a0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
select (public.resolver_postulacion_vendedor('f1000000-0000-0000-0000-000000000001','aprobada','Documentos corregidos','597055555536')).id;
select pg_temp.ok((select count(*)=2 from public.postulaciones_revisiones where postulacion_id='f1000000-0000-0000-0000-000000000001'), 'segunda decision no borra primera revision');
select pg_temp.ok((select rut_oficial='12345678-5' and region_id is not null from public.productores where perfil_id='f0000000-0000-0000-0000-000000000001'), 'aprobacion propaga RUT y region');
select set_config('request.jwt.claims','{"sub":"f0000000-0000-0000-0000-000000000001","role":"authenticated"}',true);
select pg_temp.fails($q$insert into storage.objects(bucket_id,name) values ('vendedor-documentos',auth.uid()||'/aprobada.pdf')$q$,
  'row-level security', 'documentos aprobados quedan bloqueados');
select pg_temp.fails($q$update public.productores set codigo_comercio_mall='597055555599' where perfil_id=auth.uid()$q$,
  'Solo administracion', 'vendedor no cambia comercio hijo');
select pg_temp.fails($q$update public.productores set rut_oficial='11111111-1' where perfil_id=auth.uid()$q$,
  'Solo administracion', 'vendedor no cambia RUT aprobado');
set local role anon;
select pg_temp.ok((select count(*)=0 from storage.objects where bucket_id='vendedor-documentos'), 'anonimo no lee documentos');
select pg_temp.ok(public.rut_solicitante_disponible('12345678-5') = false, 'anon consulta via RPC que el RUT ocupado no esta disponible');
select pg_temp.ok(public.rut_solicitante_disponible('99999999-9') = true, 'anon consulta via RPC que un RUT libre esta disponible');
select pg_temp.fails($q$select rut_solicitante from public.postulaciones_vendedores$q$, 'permission denied', 'anon sigue sin leer la tabla de postulaciones directamente');
select pg_temp.ok(
  exists (
    select 1
    from public.evaluaciones_publicas_productor('20000000-0000-0000-0000-000000000005', 6) e
    where e.cliente_nombre is not null
      and to_jsonb(e) ? 'cliente_foto_perfil_storage_path'
  )
  and not exists (
    select 1
    from public.evaluaciones_publicas_productor('20000000-0000-0000-0000-000000000005', 6) e
    where to_jsonb(e) ?| array['cliente_id', 'cliente_email', 'cliente_rut', 'cliente_telefono']
  ),
  'anon ve avatar y nombre de pila de reseña sin datos privados'
);
reset role;
select set_config('request.jwt.claims','',true);

-- Tres pedidos: dos comercios reutilizan el mismo codigo de integracion.
update public.productores set codigo_comercio_mall='597055555536'
  where id in ('20000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000005');
insert into public.pedidos(id,codigo_pedido,cliente_id,productor_id,region_entrega_id,comuna_entrega_id,
  direccion_entrega,nombre_destinatario,telefono_destinatario)
select ('f2000000-0000-0000-0000-'||lpad(n::text,12,'0'))::uuid,'TEST-MALL-'||n,
  'a0000000-0000-0000-0000-000000000002',
  case when n=2 then '20000000-0000-0000-0000-000000000005'::uuid else '20000000-0000-0000-0000-000000000001'::uuid end,
  '11000000-0000-0000-0000-000000000001','12000000-0000-0000-0000-000000000004','Calle prueba','Cliente','123'
from generate_series(1,3) n;
insert into public.detalles_pedido(pedido_id,producto_id,producto_nombre,precio_unitario,cantidad,subtotal)
select p.id, pr.id, pr.nombre, pr.precio, 1, pr.precio from public.pedidos p join public.productos pr on pr.productor_id=p.productor_id
where p.codigo_pedido like 'TEST-MALL-%' and right(pr.id::text,3) in ('101','501');

set local role service_role;
select pg_temp.fails($q$update public.pedidos set estado='pagado' where codigo_pedido='TEST-MALL-1'$q$, 'sin comprobante', 'no paga pedido sin registro autorizado');
select pg_temp.fails($q$insert into public.pagos(pedido_id,buy_order,monto) select id,'incompleta',total from public.pedidos where codigo_pedido='TEST-MALL-1'$q$,
  'Faltan los identificadores', 'no acepta pago incompleto');
insert into public.pagos(pedido_id,buy_order,buy_order_mall,token_ws,session_id,codigo_comercio,monto,
  codigo_autorizacion,codigo_respuesta,autorizado_en,respuesta_webpay)
select id,codigo_pedido,'MALL-COMPARTIDA','token-compartido','sesion-compartida','597055555536',total,
  'AUTH-TEST','0',now(),jsonb_build_object('status','AUTHORIZED','response_code',0,'amount',total,
  'commerce_code','597055555536','buy_order',codigo_pedido,'authorization_code','AUTH-TEST')
from public.pedidos where codigo_pedido in ('TEST-MALL-1','TEST-MALL-2');
select pg_temp.ok((select count(*)=2 from public.pagos where token_ws='token-compartido'), 'dos vendedores comparten token y codigo con ordenes hijas distintas');
select pg_temp.fails($q$insert into public.pagos(pedido_id,buy_order,buy_order_mall,token_ws,session_id,codigo_comercio,monto,
  codigo_autorizacion,codigo_respuesta,autorizado_en,respuesta_webpay)
select p3.id,p.buy_order,p.buy_order_mall,p.token_ws,p.session_id,p.codigo_comercio,p3.total,
  p.codigo_autorizacion,p.codigo_respuesta,p.autorizado_en,p.respuesta_webpay
from public.pagos p cross join public.pedidos p3 where p.buy_order='TEST-MALL-1' and p3.codigo_pedido='TEST-MALL-3'$q$,
  'uq_pago_subtransaccion', 'no duplica subtransaccion en otro pedido');
select pg_temp.fails($q$insert into public.pagos(pedido_id,buy_order,buy_order_mall,token_ws,session_id,codigo_comercio,monto,
  codigo_autorizacion,codigo_respuesta,autorizado_en,respuesta_webpay)
select id,codigo_pedido,'MALL-3','token-3','sesion-3','597055555536',total,'AUTH-3','0',now(),
  jsonb_build_object('status','FAILED','response_code',0,'amount',total,'commerce_code','597055555536','buy_order',codigo_pedido,'authorization_code','AUTH-3')
from public.pedidos where codigo_pedido='TEST-MALL-3'$q$, 'detail Webpay', 'status fallido no se acepta aunque response_code sea cero');
update public.pedidos set estado='pagado' where codigo_pedido in ('TEST-MALL-1','TEST-MALL-2');
-- HAL-CLI-010 (migración 20261101020000): al pagar el pedido queda 'pagado' y se
-- crea el envio en 'preparacion'; la transicion a 'en_preparacion' la hace el
-- vendedor con public.marcar_pedido_en_preparacion.
select pg_temp.ok((select count(*)=2 from public.pedidos where codigo_pedido in ('TEST-MALL-1','TEST-MALL-2') and estado='pagado'), 'pagos autorizados dejan el pedido pagado');
select pg_temp.ok((select count(*)=2 from public.envios e join public.pedidos p on p.id=e.pedido_id where p.codigo_pedido in ('TEST-MALL-1','TEST-MALL-2') and e.estado='preparacion'), 'pago autorizado crea el envio en preparacion');
select pg_temp.ok((select stock=49 from public.productos where id='30000000-0000-0000-0000-000000000101'), 'stock descontado una vez');
select pg_temp.fails($q$update public.pagos set monto=1 where token_ws='token-compartido'$q$, 'permission denied', 'backend no reescribe comprobantes');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"a0000000-0000-0000-0000-000000000105","role":"authenticated"}',true);
select pg_temp.ok((select count(*)=1 from public.pagos where token_ws='token-compartido'), 'vendedor solo lee su detalle del Mall');
select pg_temp.fails($q$insert into public.pagos(pedido_id,buy_order,monto) values ('f2000000-0000-0000-0000-000000000003','falso',1)$q$,
  'permission denied', 'usuario no inserta comprobantes');
rollback;
