param([string]$Image = 'pgvector/pgvector:pg16')
$ErrorActionPreference = 'Stop'
$testContainer = 'cutuco-schema-test-' + [guid]::NewGuid().ToString('N').Substring(0, 10)
$supabaseRoot = Split-Path $PSScriptRoot -Parent
# Leer los seeds del contrato real del reset, sin una lista paralela de archivos.
# Este lector acepta sql_paths en una linea; falla explicitamente ante otro formato.
$config = Get-Content -Raw (Join-Path $supabaseRoot 'config.toml')
$seedSection = [regex]::Match($config, '(?ms)^\[db\.seed\]\s*\r?\n(.*?)(?=^\[|\z)').Groups[1].Value
if ($seedSection -notmatch '(?m)^enabled\s*=\s*true\s*$') { throw 'Las pruebas requieren db.seed.enabled = true' }
$pathsMatch = [regex]::Match($seedSection, '(?m)^sql_paths\s*=\s*\[([^\r\n]*)\]\s*(?:#.*)?$')
if (-not $pathsMatch.Success) { throw 'No se pudo leer db.seed.sql_paths; actualizar el lector antes de ejecutar pruebas' }
$seedPaths = @($pathsMatch.Groups[1].Value.Split(',') | ForEach-Object {
    $literal = $_.Trim()
    if ($literal -notmatch '^"([^"\\]+)"$') { throw "Ruta de seed no soportada: $literal" }
    $pattern = Join-Path $supabaseRoot $Matches[1]
    $resolved = @(Get-ChildItem -Path $pattern -File | Sort-Object Name)
    if ($resolved.Count -eq 0) { throw "Seed configurado inexistente: $pattern" }
    $resolved.FullName
})
$started = $false
function Invoke-TestSql([string]$Path) {
    Write-Host "SQL: $(Split-Path $Path -Leaf)"
    Get-Content -Raw -LiteralPath $Path | docker exec -i $testContainer psql -U postgres -v ON_ERROR_STOP=1 -q -o /dev/null
    if ($LASTEXITCODE -ne 0) { throw "Fallo SQL: $Path" }
}
try {
    docker run --name $testContainer -e POSTGRES_PASSWORD=cutuco-test-only -d $Image | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo iniciar PostgreSQL 16' }
    $started = $true
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        docker exec $testContainer pg_isready -U postgres 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { break }
        Start-Sleep -Seconds 1
    }
    if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL no quedo disponible' }
    Invoke-TestSql (Join-Path $PSScriptRoot 'bootstrap_pg16.sql')
    Get-ChildItem (Join-Path $supabaseRoot 'migrations/*.sql') |
        Sort-Object Name | ForEach-Object { Invoke-TestSql $_.FullName }
    foreach ($seedPath in $seedPaths) { Invoke-TestSql $seedPath }
    Invoke-TestSql (Join-Path $PSScriptRoot 'gallery_seed.sql')
    Invoke-TestSql (Join-Path $supabaseRoot 'seeds/gallery_dev.sql')
    Invoke-TestSql (Join-Path $PSScriptRoot 'gallery_seed.sql')
    Invoke-TestSql (Join-Path $PSScriptRoot 'webpay_postulaciones.sql')
    $seedAgain = Get-Content -Raw (Join-Path $supabaseRoot 'seed.sql') |
        docker exec -i $testContainer psql -U postgres -v ON_ERROR_STOP=1 -q -o /dev/null 2>&1
    if ($LASTEXITCODE -eq 0 -or ($seedAgain -join "`n") -notmatch 'ya existe') {
        throw 'El seed debe rechazar una segunda ejecucion por UUIDs reservados'
    }
    Write-Host 'PASS: segunda ejecucion del seed rechazada sin duplicar datos'
    Write-Host 'PASS: migraciones, seed y regresiones PostgreSQL 16'
}
finally {
    # Solo elimina el contenedor temporal creado por esta ejecucion, sin volumen del usuario.
    if ($started) { docker rm -f -v $testContainer | Out-Null }
}
