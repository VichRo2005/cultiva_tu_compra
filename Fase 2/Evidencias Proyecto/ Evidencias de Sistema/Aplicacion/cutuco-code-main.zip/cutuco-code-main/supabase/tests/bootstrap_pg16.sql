-- Fixture MINIMO de APIs de Supabase para PostgreSQL 16 aislado.
-- No sustituye pruebas de HTTP Storage/Auth. Nunca ejecutar sobre Supabase real.
create role anon nologin;
create role authenticated nologin;
create role service_role nologin bypassrls;
create schema auth;
create schema storage;
create schema extensions;
create extension pgcrypto with schema extensions;
grant usage on schema auth, storage, extensions to anon, authenticated, service_role;
create table auth.users (
  id uuid primary key, instance_id uuid, aud text, role text, email text,
  encrypted_password text, email_confirmed_at timestamptz, raw_app_meta_data jsonb,
  raw_user_meta_data jsonb, is_super_admin boolean, is_sso_user boolean, is_anonymous boolean,
  recovery_sent_at timestamptz, confirmation_sent_at timestamptz, last_sign_in_at timestamptz,
  phone text, phone_change text, phone_change_token text, email_change_confirm_status integer,
  confirmation_token text, recovery_token text, email_change_token_new text, email_change text,
  email_change_token_current text, reauthentication_token text, created_at timestamptz, updated_at timestamptz
);
create table auth.identities (
  id uuid primary key, user_id uuid references auth.users, provider_id text,
  identity_data jsonb, provider text, last_sign_in_at timestamptz, created_at timestamptz, updated_at timestamptz
);
create function auth.uid() returns uuid language sql stable as $$
  select coalesce(nullif(current_setting('request.jwt.claim.sub',true), ''),
    nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid;
$$;
create table storage.buckets (
  id text primary key, name text not null, public boolean default false,
  file_size_limit bigint, allowed_mime_types text[]
);
create table storage.objects (
  id uuid primary key default gen_random_uuid(), bucket_id text references storage.buckets,
  name text not null, owner_id text, metadata jsonb, unique(bucket_id,name)
);
create function storage.foldername(name text) returns text[] language plpgsql immutable as $$
declare parts text[] := string_to_array(name, '/');
begin return parts[1:array_length(parts,1)-1]; end;
$$;
alter table storage.objects enable row level security;
grant all on storage.objects to authenticated, service_role;
grant select on storage.objects to anon;
alter default privileges in schema public grant all on tables to service_role;
