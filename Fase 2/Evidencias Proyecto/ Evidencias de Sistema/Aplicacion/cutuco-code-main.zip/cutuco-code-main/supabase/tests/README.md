# Webpay Mall y postulaciones documentadas

Las migraciones `20261010000000`, `20261010010000` y `20261010020000` son incrementales y compatibles con PostgreSQL 16. El proyecto local encontrado usa PostgreSQL 17.11 (`config.toml`: `major_version = 17`); no se cambia la version del servidor ni se requiere un reset para migrar. Las pruebas incluyen todas las migraciones y los seeds declarados en `config.toml`, incluidos los placeholders de galeria.

## Contrato de datos

- `payouts`, sus enums, RPC, triggers y helpers se eliminan. Los cuatro campos de escrow estaban realmente en `pedidos`, y se eliminan de esa tabla. Se actualizan calculo de totales, transiciones, entrega y confirmacion de recepcion.
- `pagos` contiene un comprobante exitoso por pedido. Conserva `pedido_id`, `buy_order` (orden hija), `token_ws`, `monto`, codigos, fecha y respuesta; agrega `buy_order_mall`, `codigo_comercio` y `session_id`. Desaparecen el enum/columna `estado` y las fechas de custodia/reembolso. La unicidad es `(token_ws, codigo_comercio, buy_order)` y `pedido_id`; token y orden Mall pueden compartirse entre vendedores.
- El backend confirma con Transbank e inserta cada detalle con `status = AUTHORIZED` y `response_code = 0`, importe igual al pedido y comercio igual al del productor. `respuesta_webpay` recibe **solo el objeto detail de ese pedido**, sin el array `details` de otros vendedores. No es una validacion criptografica: las credenciales y la confirmacion real siguen en el backend. Luego el backend cambia el pedido a `pagado` en la misma transaccion; los triggers descuentan inventario y crean el envio. Una confirmacion repetida debe recuperar el registro existente ante conflicto, sin duplicar el pedido ni modificar el comprobante.
- Los pagos Plus historicos autorizados conservan sus identificadores y respuesta; los campos nuevos quedan NULL porque no puede inferirse un comercio Mall retroactivamente. Los intentos historicos `creado`/`rechazado` se eliminan durante la migracion, sin crear una tabla auxiliar de archivo. No se inventa un resultado exitoso. El respaldo previo conserva los datos de payouts eliminados.
- `productores.rut_oficial` se copia al aprobar la solicitud. `codigo_comercio_mall` se asigna por administracion/backend y **no es UNIQUE**. Ambos quedan NULL en productores antiguos hasta su regularizacion. El vendedor no puede editar esos campos ni cambiar `perfil_id`.

La forma de los detalles autorizados se basa en la [documentacion de Webpay Plus Mall de Transbank](https://transbankdevelopers.com/documentacion/webpay-plus).

## Postulaciones y documentos

La tabla real es `postulaciones_vendedores`. Campos nuevos: `rut_solicitante`, `tipo_de_persona` (`natural`/`juridica`), `documento_identidad`, `certificado_inicio_actividades_o_carnet_representante`, `certificado_titularidad_bancaria` y `comprobante_domicilio`. El RUT exige formato normalizado sin puntos; el constraint no valida digito verificador.

1. Crear un borrador; puede editarse/eliminarse antes de enviarlo.
2. Subir documentos y guardar sus rutas. Cambiar `estado` a `en_revision` exige los seis campos. El antiguo valor `pendiente_aprobacion` se renombra a `en_revision`.
3. Administracion consulta la solicitud y documentos. Para resolver usa `resolver_postulacion_vendedor(id, 'aprobada'|'rechazada', observaciones)`. El rechazo exige observaciones. El administrador no modifica los datos enviados ni los archivos por la API directa.
4. Tras un rechazo, el solicitante puede corregir y reenviar la **misma fila** a `en_revision`. Incrementa `intento`, conserva las ultimas observaciones y limpia el revisor/fecha actuales. Cada decision queda en `postulaciones_revisiones` con snapshot de los datos y observaciones anteriores. No se permite borrar ese historial mediante la API.
5. Limite de 3 intentos (migracion `20261013000000`) con reinicio administrativo auditado (migracion `20261026000000`): la RPC `reiniciar_intentos_postulacion(id, motivo)` — solo administrador, sobre una postulacion `rechazada` — agrega un bloque extra de 3 intentos via `intentos_extra` (el maximo efectivo es 3 + intentos_extra) y registra admin, fecha, valores antes/despues y motivo en `postulaciones_reinicio_intentos`. El solicitante no puede tocar `intentos_extra` (el trigger `validar_postulacion_estado` lo bloquea).

Los registros antiguos sin documentos se conservan. Una solicitud antigua en revision puede rechazarse con observaciones para que su propietario complete los campos y reenvie; no puede aprobarse incompleta.

El bucket `vendedor-documentos` es privado, acepta PDF/JPEG/PNG y limita cada archivo a 10 MiB. En la tabla se guarda `vendedor-documentos/{auth.uid()}/cedula.pdf`; la clave que se pasa a `.storage.from('vendedor-documentos')` es `{auth.uid()}/cedula.pdf`, sin repetir el bucket. Se permiten nombres simples con letras, numeros, guion o guion bajo. Usar descarga autenticada o URL firmada temporal; no almacenar URLs publicas ni URLs firmadas que expiran. Ver [acceso a Storage mediante RLS](https://supabase.com/docs/guides/storage/security/access-control) y [descarga de archivos privados](https://supabase.com/docs/guides/storage/serving/downloads).

| Actor/estado | Documentos | Datos de solicitud |
| --- | --- | --- |
| Propietario antes de postular/borrador | CRUD | CRUD del borrador |
| Propietario en revision | SELECT | SELECT |
| Propietario rechazado | CRUD | SELECT/UPDATE y reenvio |
| Propietario aprobado | SELECT | SELECT |
| Administrador | SELECT | SELECT y RPC de resolucion |
| Terceros/anonimos | Sin acceso | Sin acceso |

`service_role` es el backend privilegiado de Supabase y omite RLS; nunca debe usarse en el navegador. El historial guarda rutas y snapshots de datos, no versiones de los bytes: reemplazar un PDF tras un rechazo puede cambiar el contenido de esa ruta. El SQL valida las rutas, no comprueba la existencia fisica de los archivos. El seed solo aporta metadatos y no sube archivos; el flujo de aplicacion debe completar la carga antes del envio.

## Verificacion

Desde la raiz del repositorio, con Docker disponible:

```powershell
./supabase/tests/run_pg16.ps1
```

Crea un contenedor efimero PostgreSQL 16 sin publicar puertos, aplica todas las migraciones y carga los seeds en el orden de `db.seed.sql_paths`. El lector de configuracion acepta la lista de rutas entre comillas dobles en una linea y falla explicitamente si cambia a un formato no soportado. Ejecuta `gallery_seed.sql`, recarga la galeria para verificar idempotencia, ejecuta `webpay_postulaciones.sql`, verifica que repetir el seed principal falla sin duplicados y elimina el contenedor. `bootstrap_pg16.sql` representa el contrato SQL minimo de Auth/Storage; no prueba el servidor HTTP, MIME real, URLs firmadas ni una transaccion bancaria real.

La bateria SQL usa roles reales `anon`, `authenticated` y `service_role`, con 44 assertions positivas/negativas de RLS, reintentos, historial, identidad del productor, idempotencia de subtransacciones, inventario y envios. Todas sus modificaciones se revierten con ROLLBACK. Ademas de la prueba de migracion incremental sobre una copia, se ejecuto el reset completo en Supabase local con `npx --no-install supabase db reset --local --yes`, seguido de las verificaciones SQL sobre esa instancia.

La primera version del runner excluia la galeria y no detecto que su seed seguia usando `pendiente_aprobacion`. `gallery_dev.sql` ahora crea la solicitud como `borrador`, completa RUT/tipo/documentos y la envia a `en_revision`; no altera una solicitud ya enviada o resuelta al recargarlo. Las pruebas de `gallery_seed.sql` comprueban cuentas, identidades, solicitud completa, productor, documentos legacy y pagos del seed principal. Una prueba del esquema aislado no reemplaza la verificacion del reset completo con los archivos configurados.

El seed actualizado genera siete cuentas, cinco productores con RUT, cinco aprobaciones auditadas, veinte productos, cinco pedidos, cuatro comprobantes autorizados y cuatro envios. Los cinco productores comparten el comercio hijo de integracion `597055555536`; `597055555537` queda reservado para el fee de la plataforma. Conserva la proteccion contra ejecucion duplicada. Para nuevas instalaciones: migraciones antes del seed; no ejecutar este seed otra vez sobre una instancia ya poblada.

Los consumidores existentes deben adoptar `en_revision`/`borrador`, la RPC de resolucion y el nuevo contrato de pagos. Este trabajo se limita a Supabase; no actualiza frontend ni backend.
