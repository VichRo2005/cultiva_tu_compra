/**
 * Auditoría UI temporal: contraste WCAG, estados de interacción, errores de
 * consola, fugas de valores y desbordes horizontales en todas las ventanas.
 */
import { chromium } from 'playwright'

const base = process.argv[2] ?? 'http://localhost:4173'
const rutas = [
  '/', '/catalogo', '/producto/30000000-0000-0000-0000-000000000100', '/precios', '/terminos', '/privacidad',
  '/ruta-inexistente', '/login', '/registro', '/recuperar-clave', '/carrito', '/checkout',
  '/pago/40000000-0000-0000-0000-000000000111', '/cliente/pedidos',
  '/cliente/pedidos/40000000-0000-0000-0000-000000000100', '/cliente/perfil', '/vendedor',
  '/vendedor/productos', '/vendedor/productos/nuevo',
  '/vendedor/productos/30000000-0000-0000-0000-000000000100/editar', '/vendedor/pedidos',
  '/vendedor/pedidos/40000000-0000-0000-0000-000000000100', '/vendedor/evidencias',
  '/vendedor/reputacion', '/vendedor/alertas-stock', '/vendedor/tienda', '/admin', '/admin/usuarios',
  '/admin/moderacion', '/admin/reportes', '/admin/catalogo', '/admin/pagos', '/admin/sanciones',
  '/admin/reclamos', '/admin/geografia',
]

const browser = await chromium.launch()
const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage()

await page.addInitScript(() => {
  window.__audit = {
    parseColor(value) {
      const m = String(value).match(/rgba?\(([^)]+)\)/)
      if (!m) return null
      const p = m[1].split(/[,\s/]+/).filter(Boolean).map(Number)
      return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }
    },
    lum({ r, g, b }) {
      const f = (c) => {
        const s = c / 255
        return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
      }
      return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
    },
    ratio(a, b) {
      const l1 = this.lum(a)
      const l2 = this.lum(b)
      const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1]
      return (hi + 0.05) / (lo + 0.05)
    },
    over(fg, bg) {
      const a = fg.a ?? 1
      if (a >= 1) return { r: fg.r, g: fg.g, b: fg.b, a: 1 }
      return {
        r: fg.r * a + bg.r * (1 - a),
        g: fg.g * a + bg.g * (1 - a),
        b: fg.b * a + bg.b * (1 - a),
        a: 1,
      }
    },
    effectiveBg(el) {
      let node = el
      let acc = null
      while (node && node !== document.documentElement.parentNode) {
        const cs = getComputedStyle(node)
        const c = this.parseColor(cs.backgroundColor)
        const hasImage = cs.backgroundImage && cs.backgroundImage !== 'none'
        if (c && c.a > 0) {
          acc = acc ? this.over(acc, c) : c
          if (acc.a >= 0.999 && !hasImage) return acc
        }
        if (hasImage) return acc && acc.a >= 0.999 ? acc : { r: 240, g: 241, b: 243, a: 1 }
        node = node.parentElement
      }
      return acc && acc.a >= 0.999 ? acc : { r: 246, g: 247, b: 249, a: 1 }
    },
    describe(el) {
      const cls = (el.className && typeof el.className === 'string')
        ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.')
        : ''
      return `${el.tagName.toLowerCase()}${cls}`
    },
    visible(el) {
      const cs = getComputedStyle(el)
      if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false
      const r = el.getBoundingClientRect()
      return r.width > 1 && r.height > 1
    },
  }
})

const auditar = async () =>
  page.evaluate(() => {
    const A = window.__audit
    const texto = (el) => (el.textContent ?? '').replace(/\s+/g, ' ').trim()
    const propio = (el) =>
      [...el.childNodes].some((n) => n.nodeType === 3 && (n.textContent ?? '').trim().length > 0)

    /* --- contraste --- */
    const contraste = []
    for (const el of document.querySelectorAll('body *')) {
      if (!propio(el) || !A.visible(el)) continue
      const cs = getComputedStyle(el)
      if (Number(cs.opacity) < 0.5) continue
      const fg0 = A.parseColor(cs.color)
      if (!fg0) continue
      const bg = A.effectiveBg(el)
      const fg = A.over(fg0, bg)
      const size = parseFloat(cs.fontSize)
      const bold = Number(cs.fontWeight) >= 700
      const grande = size >= 24 || (size >= 18.66 && bold)
      const ratio = A.ratio(fg, bg)
      const minimo = grande ? 3 : 4.5
      if (ratio < minimo) {
        contraste.push({
          sel: A.describe(el),
          texto: texto(el).slice(0, 40),
          color: cs.color,
          bg: `rgb(${Math.round(bg.r)}, ${Math.round(bg.g)}, ${Math.round(bg.b)})`,
          ratio: Number(ratio.toFixed(2)),
          minimo,
          size,
        })
      }
    }

    /* --- interacción --- */
    const interaccion = { total: 0, sinHover: [], sinFoco: [], inaccesibles: [] }
    const interactivos = document.querySelectorAll(
      'button, a[href], [role="button"], [role="tab"], input, select, textarea, summary',
    )
    for (const el of interactivos) {
      if (!A.visible(el)) continue
      interaccion.total += 1
      const r = el.getBoundingClientRect()
      const cs = getComputedStyle(el)
      if (r.width < 24 || r.height < 24) {
        interaccion.inaccesibles.push({ sel: A.describe(el), texto: texto(el).slice(0, 28), w: Math.round(r.width), h: Math.round(r.height) })
      }
      if (cs.pointerEvents === 'none') {
        interaccion.inaccesibles.push({ sel: A.describe(el), texto: texto(el).slice(0, 28), motivo: 'pointer-events: none' })
      }
    }

    /* --- fugas de valores y desbordes --- */
    const cuerpo = texto(document.body)
    const fugas = ['undefined', 'NaN', '[object Object]', 'Invalid Date'].filter((t) => cuerpo.includes(t))
    const desborde = document.documentElement.scrollWidth - document.documentElement.clientWidth
    const sinScroll = document.documentElement.scrollHeight <= document.documentElement.clientHeight + 2

    return {
      contraste: contraste.sort((a, b) => a.ratio - b.ratio),
      interaccion,
      fugas,
      desborde,
      alto: document.documentElement.scrollHeight,
      vacio: (document.querySelector('main')?.innerText ?? '').trim().length < 40,
      sinScroll,
    }
  })

const verificarEstados = async () =>
  page.evaluate(() => {
    const A = window.__audit
    const salida = { sinHover: [], sinFoco: [] }
    const objetivos = [...document.querySelectorAll('button, a[href], [role="tab"], [role="button"]')].filter((el) =>
      A.visible(el),
    )
    for (const el of objetivos.slice(0, 80)) {
      const cs = getComputedStyle(el)
      const firma = `${cs.color}|${cs.backgroundColor}|${cs.borderColor}|${cs.boxShadow}|${cs.transform}|${cs.opacity}|${cs.textDecorationLine}`
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }))
      const cs2 = getComputedStyle(el)
      const firma2 = `${cs2.color}|${cs2.backgroundColor}|${cs2.borderColor}|${cs2.boxShadow}|${cs2.transform}|${cs2.opacity}|${cs2.textDecorationLine}`
      if (firma === firma2) salida.sinHover.push(`${A.describe(el)} "${(el.textContent ?? '').trim().slice(0, 24)}"`)
      el.focus()
      const focused = document.activeElement === el
      const cf = getComputedStyle(el)
      const anillo = cf.outlineStyle !== 'none' && Number.parseFloat(cf.outlineWidth) > 0
      const sombra = cf.boxShadow !== 'none'
      if (!focused || (!anillo && !sombra)) {
        salida.sinFoco.push(`${A.describe(el)} "${(el.textContent ?? '').trim().slice(0, 24)}"`)
      }
      el.blur()
    }
    return salida
  })

const reporte = []
for (const ruta of rutas) {
  const errores = []
  const onConsole = (m) => {
    if (m.type() === 'error') errores.push(m.text().slice(0, 180))
  }
  const onError = (e) => errores.push(`pageerror: ${String(e).slice(0, 180)}`)
  page.on('console', onConsole)
  page.on('pageerror', onError)

  await page.goto(base + ruta, { waitUntil: 'networkidle' })
  await page.waitForTimeout(900)
  const base_ = await auditar()
  const estados = await verificarEstados()
  reporte.push({ ruta, errores, ...base_, estados })
  page.off('console', onConsole)
  page.off('pageerror', onError)
}

await browser.close()

const resumen = {
  totalRutas: reporte.length,
  conErrores: reporte.filter((r) => r.errores.length).map((r) => ({ ruta: r.ruta, errores: r.errores })),
  conFugas: reporte.filter((r) => r.fugas.length).map((r) => ({ ruta: r.ruta, fugas: r.fugas })),
  conDesborde: reporte.filter((r) => r.desborde > 1).map((r) => ({ ruta: r.ruta, desborde: r.desborde })),
  vacias: reporte.filter((r) => r.vacio).map((r) => r.ruta),
  contraste: reporte
    .flatMap((r) => r.contraste.map((c) => ({ ...c, ruta: r.ruta })))
    .sort((a, b) => a.ratio - b.ratio),
 sinHover: Object.entries(
    reporte
      .flatMap((r) => r.estados.sinHover)
      .reduce((acc, k) => ((acc[k] = (acc[k] ?? 0) + 1), acc), {}),
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 30),
  sinFoco: Object.entries(
    reporte
      .flatMap((r) => r.estados.sinFoco)
      .reduce((acc, k) => ((acc[k] = (acc[k] ?? 0) + 1), acc), {}),
  )
    .sort((a, b) => b[1] - a[1])
    .slice(0, 30),
  inaccesibles: reporte.flatMap((r) => r.interaccion.inaccesibles.map((i) => ({ ...i, ruta: r.ruta }))).slice(0, 30),
}
console.log(JSON.stringify(resumen, null, 1))