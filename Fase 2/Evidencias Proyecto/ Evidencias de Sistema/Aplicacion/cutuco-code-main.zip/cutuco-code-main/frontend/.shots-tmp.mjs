// Script temporal de capturas (no es parte de la app): fotografía rutas clave
// del dev server en 4 viewports. Uso: node .shots-tmp.mjs <outdir> [etiqueta]
import { chromium } from 'playwright'
import { mkdirSync } from 'node:fs'
import { join } from 'node:path'

const outdir = process.argv[2] || '.shots'
const tag = process.argv[3] || 'shot'
mkdirSync(outdir, { recursive: true })

const BASE = 'http://127.0.0.1:5173'
const sizes = [
  { name: '1440', width: 1440, height: 900 },
  { name: '1024', width: 1024, height: 768 },
  { name: '768', width: 768, height: 1024 },
  { name: '390', width: 390, height: 844 },
]

// Rutas a capturar. productId se resuelve dinámicamente desde /catalogo.
const routes = ['/', '/catalogo', '/login', '/registro', '/admin', '/admin/usuarios', '/vendedor', '/vendedor/productos', '/cliente/pedidos', '/carrito', '/checkout']

const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })

// Resolver un producto real desde el catálogo (modo demo)
let productPath = null
try {
  await page.goto(`${BASE}/catalogo`, { waitUntil: 'networkidle', timeout: 20000 })
  await page.waitForTimeout(800)
  productPath = await page.evaluate(() => document.querySelector('a[href^="/producto/"]')?.getAttribute('href') || null)
} catch (e) {
  console.log('warn catalogo:', e.message)
}
if (productPath) routes.splice(2, 0, productPath)

for (const size of sizes) {
  await page.setViewportSize({ width: size.width, height: size.height })
  for (const route of routes) {
    const name = route.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'home'
    try {
      await page.goto(`${BASE}${route}`, { waitUntil: 'networkidle', timeout: 20000 })
      await page.waitForTimeout(900)
      await page.screenshot({ path: join(outdir, `${tag}-${size.name}-${name}.png`), fullPage: false })
      console.log('ok', tag, size.name, route)
    } catch (e) {
      console.log('fail', tag, size.name, route, e.message)
    }
  }
}
await browser.close()
console.log('done ->', outdir)
