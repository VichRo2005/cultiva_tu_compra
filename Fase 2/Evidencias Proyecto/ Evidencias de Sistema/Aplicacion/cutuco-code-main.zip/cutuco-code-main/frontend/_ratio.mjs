const lum = ({ r, g, b }) => {
  const f = (c) => { const s = c / 255; return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4 }
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
}
const hex = (h) => ({ r: parseInt(h.slice(1, 3), 16), g: parseInt(h.slice(3, 5), 16), b: parseInt(h.slice(5, 7), 16) })
const ratio = (a, b) => { const l1 = lum(hex(a)), l2 = lum(hex(b)); const [hi, lo] = l1 > l2 ? [l1, l2] : [l2, l1]; return +(((hi + 0.05) / (lo + 0.05)).toFixed(2)) }
const fondos = { blanco: '#ffffff', f3: '#f3f3f5', f6: '#f6f7f9', sun: '#fafbfc', ink: '#151918', soft: '#e8f5e9' }
const textos = {
  'muted actual #8a8b8f': '#8a8b8f', 'muted #6a6c72': '#6a6c72', 'muted #64666c': '#64666c', 'muted #5f6167': '#5f6167',
  'faint #a9aaae': '#a9aaae', 'faint #7c7e84': '#7c7e84', 'faint #6f7177': '#6f7177',
  'soft #4b4c4f': '#4b4c4f', 'ink-soft #23261b': '#23261b', 'ink-muted #9aa08f': '#9aa08f', 'ink-muted #a8ae9d': '#a8ae9d',
}
console.log('--- texto sobre fondos claros (objetivo >= 4.5) ---')
for (const [n, c] of Object.entries(textos)) {
  console.log(n.padEnd(20), Object.entries(fondos).filter(([k]) => k !== 'ink').map(([k, f]) => `${k}:${ratio(c, f)}`).join('  '))
}
console.log('--- texto sobre ink #151918 (objetivo >= 4.5) ---')
for (const n of ['ink-muted #9aa08f', 'ink-muted #a8ae9d', 'blanco #ffffff', 'soft #b8bfae', 'soft #c2c9b8']) {
  const c = textos[n] ?? (n.includes(' ') ? n.split(' ')[1] : n)
  console.log(n.padEnd(20), ratio(c, '#151918'))
}
console.log('--- blanco sobre superficies de acento (objetivo >= 4.5) ---')
for (const c of ['#4caf50', '#43a047', '#388e3c', '#2e7d32', '#e53935', '#d32f2f', '#c62828', '#1e88e5', '#1565c0', '#f9a825']) {
  console.log(c, ratio('#ffffff', c))
}
console.log('--- acentos sobre blanco (objetivo >= 3 graf, 4.5 texto) ---')
for (const c of ['#ff9800', '#ef6c00', '#e07c00', '#d97706', '#c2410c']) console.log(c, ratio(c, '#ffffff'), 'sobre f6f7f9', ratio(c, '#f6f7f9'))
console.log('--- warning ink sobre #fff6e0 ---')
for (const c of ['#8d5b00', '#7a4f00', '#6d4500']) console.log(c, ratio(c, '#fff6e0'))
console.log('--- verde primario sobre blanco (texto/borde) ---')
for (const c of ['#4caf50', '#43a047', '#3f9c43', '#2e7d32']) console.log(c, 'sobre blanco', ratio(c, '#ffffff'), 'sobre f6f7f9', ratio(c, '#f6f7f9'))
