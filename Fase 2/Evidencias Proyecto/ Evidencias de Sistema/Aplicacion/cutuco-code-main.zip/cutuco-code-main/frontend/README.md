# CuTuCo · Frontend

SPA del marketplace de proximidad **CuTuCo (Cultiva Tu Compra)**: conecta
vendedores (productores AFC) con clientes, con **pago retenido por CuTuCo**,
**entrega con código de verificación**, **calificación simple de 1 a 5** y
**sanciones manuales** del administrador.

Stack: **Vue 3 + Vite + Pinia + Vue Router + Supabase JS + Chart.js**.
Alcance: los **21 requisitos funcionales vigentes** del ERS.

> El detalle de la alineación requisito por requisito está en
> [`GUIA-ALINEACION-ERS.md`](GUIA-ALINEACION-ERS.md) y el contrato del flujo de
> pago en [`src/views/client/CONTRATO-PAGO.md`](src/views/client/CONTRATO-PAGO.md).

## Puesta en marcha

```sh
npm install --legacy-peer-deps
npm run dev
```

> La instalación estándar (`npm install`) puede fallar con
> `Cannot read properties of null (reading 'edgesOut')` en este repositorio:
> usa `--legacy-peer-deps`.

La aplicación **necesita Supabase**: no existe modo demostración ni dataset
simulado en el navegador. El ERS exige datos reales, así que sin configuración
la pantalla de login explica qué variables faltan.

```sh
# 1. Base de datos, auth y storage (Docker Desktop debe estar corriendo)
supabase start

# 2. Variables del frontend
cp .env.local.example .env.local     # completar URL y publishable key

# 3. Backend de pagos (necesario para el checkout, RF-005)
cd ../backend && uvicorn app.main:app --reload --port 8000
```

Variables disponibles: ver [`.env.local.example`](.env.local.example) y
[`../DEPLOY.md`](../DEPLOY.md).

### Cuentas de prueba

**Cuentas de la galería** (`supabase/seeds/gallery_dev.sql`, contraseña
`CutucoDev2026!`) — son las que usa la vista de desarrollador y las que tienen
permisos sobre todas las ventanas:

| Rol | Correo | Uso |
| --- | --- | --- |
| Administrador | `admin@cutuco.dev` | Permisos completos: todo el panel |
| Vendedor | `vendedor@cutuco.dev` | Inventario, pedidos, entrega con código |
| Cliente | `cliente@cutuco.dev` | Compra, seguimiento y calificación |
| Vendedor pendiente | `pendiente@cutuco.dev` | Revisar los bloqueos de RF-021 |

Con `VITE_DEV_GALLERY=true` existe además `http://localhost:5173/cuentas-demo`
para entrar con cualquiera de ellas en un clic.

**Cuentas del seed base** (`supabase/seed.sql`, contraseña `CutucoTest!2026`)
siguen disponibles para probar el dominio: `cutuco.cliente.santiago@`,
`cutuco.productor.paine@`, `cutuco.productor.quillota@`,
`cutuco.productor.pausado@` y `cutuco.admin.base@` (todos `example.test`).

### Modo demostración (sin base de datos)

La aplicación funciona **siempre**: al arrancar comprueba si Supabase responde y,
si no está disponible (Docker apagado, sin red, sin `.env.local`), pasa sola al
**modo demostración** con un dataset en memoria que imita el esquema vigente.

- El aviso azul **«Modo demostración · datos de ejemplo»** aparece arriba de cada
  ventana mientras esté activo: nunca se confunde con datos reales.
- Las **mismas cuentas demo** funcionan en los dos modos (`admin@cutuco.dev`,
  `vendedor@cutuco.dev`, `cliente@cutuco.dev`, `pendiente@cutuco.dev`, contraseña
  `CutucoDev2026!`), así que la vista de desarrollador y el selector «Ver como»
  operan igual con o sin Docker.
- El catálogo, carrito, pedidos, paneles de vendedor y administración, payouts,
  sanciones y entrega con código funcionan con datos de ejemplo.
- Sólo el **checkout con Webpay** queda fuera: necesita FastAPI y Transbank, y el
  mensaje de error lo explica.
- Los cambios del modo demo se guardan en `localStorage` (`cutuco:demo:v1`). Para
  reiniciar el dataset: borra esas claves del navegador o llama a
  `createDemoDatabase().reiniciar()`.

Archivos del modo demo: `src/lib/offlineClient.js` (cliente compatible con
supabase-js) y `src/data/demoDatabase.js` (dataset). Cuando Supabase responde, no
se usan en absoluto: el camino normal sigue siendo PostgREST con RLS.

## Scripts

| Comando | Descripción |
| --- | --- |
| `npm run dev` | Servidor de desarrollo |
| `npm run build` | Build de producción |
| `npm run preview` | Sirve el build |
| `npm run test:unit` | Pruebas unitarias y de integración (Vitest) |
| `npm run test:e2e` | Pruebas end-to-end (Playwright) |
| `npm run lint` | oxlint + eslint con auto-corrección |

## Zonas de la aplicación

| Ruta | RF | Descripción |
| --- | --- | --- |
| `/` | RF-022 | Portada con acceso público al catálogo |
| `/catalogo` | RF-022, RF-002 | Catálogo con buscador, filtros por categoría y región |
| `/producto/:id` | RF-002 | Detalle del producto, vendedor y precio |
| `/vendedores/:id` | RF-006 | Perfil público del vendedor y su reputación |
| `/carrito` | RF-002, RF-009 | Carrito, stock y validación de cobertura regional |
| `/checkout` | RF-002, RF-005, RF-009 | Despacho, totales y pago con Webpay Plus |
| `/pago/retorno` | RF-005 | Retorno de Webpay y commit del pago retenido |
| `/cliente/pedidos`, `/cliente/pedidos/:id` | RF-002, RF-006, RF-025 | Historial, seguimiento, código de entrega y calificación |
| `/cliente/perfil` | RF-024 | Datos personales, dirección y cambio de contraseña |
| `/login`, `/registro`, `/registro-vendedor`, `/recuperar-clave` | RF-001, RF-020, RF-021, RF-023 | Autenticación y registro |
| `/vendedor` | RF-003 | Dashboard del vendedor (ventas, reputación, sanciones) |
| `/vendedor/productos` | RF-003, RF-017 | Inventario, stock y baja lógica |
| `/vendedor/productos/nuevo`, `/editar` | RF-003, RF-018, RF-019 | Alta y edición con foto de cámara |
| `/vendedor/pedidos`, `/vendedor/pedidos/:id` | RF-025, RF-007 | Pedidos recibidos y entrega con código |
| `/vendedor/tienda` | RF-021, RF-024 | Perfil de tienda, datos bancarios y seguridad |
| `/admin` | RF-011 | Pendientes: aprobaciones, sanciones y pagos |
| `/admin/moderacion` | RF-004, RF-021 | Aprobación manual de vendedores |
| `/admin/usuarios` | RF-004, RF-017 | Altas, activación y baja lógica de cuentas |
| `/admin/productos` | RF-004, RF-017 | Categorías y productos (desactivación) |
| `/admin/pagos` | RF-005, RF-014 | Payouts al vendedor y reembolsos al cliente |
| `/admin/sanciones` | RF-026, RF-004 | Amonestaciones, suspensiones, ban y moderación |

Los módulos cliente, vendedor y administrador exigen sesión iniciada; vendedor y
administrador además validan el rol (RF-001) y el vendedor debe estar aprobado
(RF-021).

## Arquitectura

```
src/
├── lib/            Constantes de dominio, cliente Supabase, validaciones, formato, iconos
├── services/       Acceso a datos y reglas: catalog, orders, payments, seller, admin, geography, registro, session
├── stores/         Pinia: auth, cart, geography, ui
├── router/         Rutas, guards de sesión y de rol
├── components/
│   ├── base/       Sistema de diseño (CtButton, CtInput, CtTable, CtModal…)
│   ├── domain/     ProductCard, ProductGrid, DeliveryStepper, StatusBadge, reputación…
│   └── layout/     AppShell, AppSidebar, AppTopbar, AppFooter
├── views/          public · auth · client · seller · admin · shared
└── __tests__/      Pruebas unitarias y de integración con Supabase local
```

**Separación de responsabilidades**: las vistas sólo presentan; las reglas viven
en `services/*`; el acceso a datos pasa por `lib/supabase.js` (PostgREST con
RLS) o por `apiFetch` hacia FastAPI (reglas con lógica propia: bloqueo de
cuenta, pedido, Webpay, payouts).

### Decisiones de datos

- **Consultas simples** (catálogo, categorías, regiones, comunas, direcciones,
  productos, envíos, evaluaciones) van directo a **PostgREST** con RLS.
- **Reglas con lógica** van a **FastAPI**: creación del pedido, Webpay
  (`create` → redirección → `token_ws` → `commit`), aprobación de payouts y
  reembolsos, y bloqueo de cuenta por intentos fallidos.
- **`src/lib/mockSupabase.js` y `src/data/demoDataset.js` ya no se usan**: se
  conservan comentados como referencia del prototipo anterior.

## Galería de desarrollo de vistas

`src/dev/` contiene una herramienta **opcional** para recorrer **todas las
ventanas creadas** del producto, incluidas las que salieron del alcance del ERS
vigente:

```sh
VITE_DEV_GALLERY=true   # en .env.local
```

Con la galería activa:

- El guard de rutas queda desactivado: cualquier ventana abre sin autenticarse.
- La aplicación entra automáticamente con la cuenta de administrador del seed y
  el selector **Ver como** permite saltar a la cuenta de vendedor o de cliente,
  navegando a la ventana de inicio del rol para que los paneles muestren datos
  reales de esa cuenta.
- El panel lateral lista las ventanas por módulo, incluido el grupo
  **Ventanas del prototipo anterior**: reputación con score 40/40/20 (RF-006 v1),
  alertas de stock (RF-010), reportes analíticos (RF-011 v1), reclamos y
  cobertura por comuna (RF-009 v1).

Con la galería apagada (`VITE_DEV_GALLERY=false`, valor por defecto) la
aplicación respeta los guards de rol, no inicia sesión sola y las ventanas del
prototipo anterior no se ofrecen en el menú.

### Datos de las ventanas retiradas

La migración `20261006100000_add_gallery_legacy_tables.sql` vuelve a declarar —
marcado como `HERRAMIENTA DE DESARROLLO` y sin tocar el esquema vigente— las
tablas y columnas que consumían esas ventanas: `coberturas_productor`,
`documentos_identidad`, `historial_precios`, `alertas_stock`,
`evidencias_envio`, `productos.umbral_bajo`, `productos.es_cosecha_mismo_dia`,
los criterios del score en `evaluaciones_reputacion` y las marcas de sanción
automática.

Los registros de ejemplo viven en `supabase/seeds/gallery_dev.sql`, que se carga
después de `supabase/seed.sql` (ver `[db.seed] sql_paths` en
`supabase/config.toml`). La carga es idempotente y usa datos coherentes con el
seed: coberturas derivadas de la región de cada vendedor, alertas para los cinco
productos con menos stock, historial de precios por producto y una postulación
pendiente de revisión.
