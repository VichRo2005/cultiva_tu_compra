# CuTuCo — Guía de alineación del frontend al ERS vigente (uso interno de desarrollo)

Este documento es la referencia común para ajustar las vistas de `frontend/src` al
esquema y al ERS vigentes. **No es entregable al usuario final**: es el contrato que
usan los desarrolladores (y los asistentes de código) para mantener la interfaz
consistente.

Fecha de referencia del cronograma: **2026-10-06** (Semana 4 de la Carta Gantt).
El objetivo acordado con el equipo es dejar el frontend completo contra el esquema
real, respetando el orden de la Carta Gantt (fundaciones → módulos).

---

## 1. Alcance vigente (21 RF)

| RF | Nombre | Pantallas del frontend |
| --- | --- | --- |
| RF-001 | Autenticación y perfiles multirrol | `LoginView`, guards del router, `AppTopbar` |
| RF-002 | Catálogo, carrito y compra del cliente | `CatalogView`, `ProductDetailView`, `CartView`, `CheckoutView`, `ClientOrdersView`, `ClientOrderDetailView` |
| RF-003 | Tienda, productos y stock del vendedor | `SellerDashboardView`, `SellerProductsView`, `SellerProductFormView`, `SellerOrdersView` |
| RF-004 | Gestión administrativa de usuarios, catálogo y moderación | `AdminUsersView`, `AdminCatalogView`, `AdminModerationView` |
| RF-005 | Pago en custodia (escrow) | `CheckoutView` (crea pago), `PaymentResultView` (commit), `AdminPaymentsView` (payout/reembolso) |
| RF-006 | Calificación simple 1 a 5 y promedio | `ClientOrderDetailView` (calificar), `SellerProfileView`, `SellerDashboardView` |
| RF-007 | Código de verificación de entrega | `SellerOrderDetailView`, `ClientOrderDetailView` |
| RF-009 | Venta restringida por región | `CartView`, `CheckoutView` (validación previa al pago) |
| RF-011 | Dashboard administrativo | `AdminDashboardView` |
| RF-012 | Gestión de correos | Sin pantalla propia: se informa el envío en los flujos (FastAPI/Supabase Auth) |
| RF-014 | Modelo de negocio y tarifas | `CheckoutView`, `AdminPaymentsView`, `SellerDashboardView` (fee 5% + $3.500) |
| RF-017 | Soft delete y cascada | Botones "Desactivar" en administración y vendedor |
| RF-018 | Combobox para claves foráneas | `CtSelect` en todos los formularios (categoría, región, comuna) |
| RF-019 | Validaciones en formularios | `lib/validation.js` + errores en `CtInput`/`CtSelect` |
| RF-020 | Registro de cliente | `RegisterView` |
| RF-021 | Registro de vendedor (Productor AFC) | `RegisterSellerView`, `SellerStoreProfileView`, `AdminModerationView` |
| RF-022 | Navegación sin cuenta | `HomeView`, `CatalogView`, `ProductDetailView`, `SellerProfileView` |
| RF-023 | Recuperación de contraseña | `ForgotPasswordView` |
| RF-024 | Cambio de contraseña | `ClientProfileView`, `SellerStoreProfileView` |
| RF-025 | Delivery: Preparación → En Tránsito → Entregado | `SellerOrderDetailView`, `ClientOrderDetailView` |
| RF-026 | Sanciones manuales y moderación | `AdminSanctionsView`, `AdminModerationView`, aviso en `SellerStoreProfileView` |

**Fuera de alcance (no implementar, no reintroducir):**
RF-008 historial de precios · RF-010 alertas de stock bajo · RF-013 múltiples
administradores · RF-015 retención del carnet · RF-016 rate limiting propio.
Tampoco forman parte del ERS vigente: geolocalización/GPS, mapa en tiempo real,
evidencia fotográfica por pedido, reclamos, apelaciones automatizadas, score
40/40/20, sello "Cosecha del día", reportes/BI avanzados, suscripción mensual.

> Regla de la base de datos: **no se elimina ni se modifica nada de
> `supabase/migrations/`**. Cuando algo quede en desuso, se comenta y se
> reemplaza, dejando el motivo escrito.

---

## 2. Cómo se escriben los cambios en el código

1. **Mantener el diseño visual actual.** No se rediseña: se reutilizan
   `components/base/Ct*.vue`, las clases utilitarias de `styles/utilities.css`,
   los tokens de `styles/tokens.css` y el CSS con scope propio de cada vista.
2. **No eliminar**: cuando una funcionalidad salga del alcance, se comenta con
   una nota `NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): …` y se
   reemplaza por la implementación vigente.
3. **Reutilizar antes de crear.** Si un componente o servicio ya existe, se
   extiende; no se duplica lógica ni se crean componentes paralelos.
4. **Separación de responsabilidades**: presentación en las vistas, reglas de
   negocio en `services/*`, acceso a datos en `lib/supabase.js` y `services/*`,
   tipos/modelos en `lib/constants.js`.
5. **Estados obligatorios en cada vista**: carga (`CtSpinner`/skeletons),
   error (`CtAlert`), vacío (`CtEmptyState`) y mensajes claros para el usuario.
6. **Sin datos simulados.** Todo sale de Supabase (PostgREST + RLS) o de FastAPI.
   Está prohibido volver a `src/lib/mockSupabase.js` o `src/data/demoDataset.js`.

---

## 3. Componentes base disponibles (`@/components/base`)

| Componente | Props principales | Emits |
| --- | --- | --- |
| `CtButton` | `variant` (primary/secondary/ghost/danger…), `size`, `type`, `disabled`, `loading`, `block`, `pill`, `to`, `href`, `iconOnly`, `title` | `click` |
| `CtInput` | `modelValue`, `label`, `hint`, `error`, `type`, `placeholder`, `prefix`, `suffix`, `disabled`, `required`, `clearable`, `size` | `update:modelValue`, `blur`, `enter` |
| `CtTextarea` | `modelValue`, `label`, `hint`, `error`, `placeholder`, `rows`, `maxlength`, `showCount`, `disabled`, `required` | `update:modelValue` |
| `CtSelect` | `modelValue`, `label`, `hint`, `error`, `options` (`[{value,label,disabled,group}]`), `placeholder`, `disabled`, `required`, `clearable`, `size` | `update:modelValue`, `change` |
| `CtCheckbox` / `CtToggle` | `modelValue`, `label`, `description`, `disabled`, `error` | `update:modelValue` |
| `CtTable` | `columns` (`[{key,label,align,width,sortable}]`), `rows`, `loading`, `emptyTitle`, `emptyMessage`, `emptyIcon`, `rowKey`, `clickable`, `dense`, `sortBy`, `sortDirection` | `row-click`, `sort` |
| `CtCard` | `title`, `subtitle`, `padding` (none/sm/md/lg), `hover`, `as`, `flat`, `accent` | — |
| `CtModal` | `modelValue`, `title`, `subtitle`, `size` (sm/md/lg/xl), `closeOnBackdrop`, `hideFooter` | `update:modelValue`, `close` |
| `CtConfirmDialog` | `modelValue`, `title`, `message`, `confirmLabel`, `cancelLabel`, `tone`, `loading`, `icon` | `update:modelValue`, `confirm`, `cancel` |
| `CtBadge` | `tone` (neutral/success/warning/danger/info/primary/accent/muted), `size`, `dot`, `variant`, `uppercase` | — |
| `CtStatCard` | `label`, `value`, `unit`, `hint`, `icon`, `tone`, `delta`, `deltaLabel`, `progress`, `to` | — |
| `CtStepper` | `steps` (`[{key,label,description,meta}]`), `current`, `orientation`, `tone`, `showDescriptions` | — |
| `CtTabs` | `modelValue`, `tabs` (`[{value,label,count,icon,tone}]`), `variant` (underline/pills), `stretch` | `update:modelValue`, `change` |
| `CtPagination` | `page`, `total`, `pageSize`, `label` | `update:page`, `update:pageSize` |
| `CtSearchInput` | `modelValue`, `placeholder`, `size`, `autofocus` | `update:modelValue`, `search` |
| `CtRatingStars` | `modelValue`, `max`, `interactive`, `size`, `showValue`, `decimals` | `update:modelValue` |
| `CtQuantityStepper` | `modelValue`, `min`, `max`, `step`, `size`, `disabled`, `unit` | `update:modelValue`, `change` |
| `CtFileUpload` | `modelValue` (array de File), `label`, `hint`, `multiple`, `max`, `capture` (`environment` = cámara), `required`, `error`, `emptyIcon` | `update:modelValue`, `error` |
| `CtEmptyState` | `icon`, `title`, `message`, `compact` | — |
| `CtAlert` | `tone` (info/success/warning/danger/neutral), `title`, `icon`, `compact`, `dismissible` | `dismiss` |
| `CtAvatar`, `CtIcon`, `CtProgressBar`, `CtSpinner`, `CtDateRange`, `CtChart` | ver el propio componente | — |

Componentes de dominio: `ProductCard`, `ProductGrid`, `CatalogFilters`,
`ImageGallery`, `DeliveryStepper`, `StatusBadge`, `CategoryTree`,
`NotificationBell`, `ReputationGauge`, `ReputationBreakdown`.

Los iconos se referencian por nombre (`<CtIcon name="cart" />`); la lista válida
está en `lib/icons.js` (`resolveIconName` normaliza alias).

---

## 4. Capa de datos

### 4.1 Acceso

```js
import { getClient, tryGetClient, apiFetch, storageUrl } from '@/lib/supabase'
```

- `getClient()` → cliente de Supabase (PostgREST + Auth + Storage) con RLS.
- `apiFetch(path, {method, body})` → FastAPI con el JWT de la sesión.
- Las variables de entorno son `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`,
  `VITE_API_BASE_URL`. Si faltan, `MISSING_ENV` es `true` y la app lo informa.

### 4.2 Servicios

| Módulo | Funciones clave |
| --- | --- |
| `services/session.js` | `currentAuth()`, `currentUserId()`, `unwrap()`, `vendedorAprobado()`, `motivoBloqueoVendedor()` |
| `services/catalog.js` | `listCategorias()`, `getArbolCategorias()`, `createCategoria()`, `updateCategoria()`, `eliminarCategoria()` (soft), `listProductos({texto,categoriaId,regionId,productorId,soloStock,orden,page,pageSize})`, `enrichProducts()`, `getProducto()`, `listProductores()`, `getProductorDetalle()`, `listImagenesProducto()`, `getRegionPorProductor()`, `getComunaPorPerfil()`, `getResumenCatalogo()`, `slugify()` |
| `services/geography.js` | `listRegiones()`, `listComunas({regionId})`, `getComuna()`, `getRegion()`, `getJerarquiaGeografica()`, `getOpcionesComunas()`, `listDirecciones({perfilId})`, `getDireccionProductor(productorId)`, `getRegionDeDireccion(direccion)`, `createDireccion()`, `updateDireccion()`, `desactivarDireccion()`, `direccionActivaUnica(perfilId)` |
| `services/orders.js` | `validarCoberturaRegional({direccion,productorId})`, `iniciarPago({direccionId,items,nombreDestinatario,telefonoDestinatario,referenciaEntrega})`, `confirmarPago(tokenWs)`, `getEstadoPago(pedidoId)`, `listPedidos({rol,estado,page,pageSize})`, `getPedidoDetalle(id)`, `marcarEnTransito(envioId)`, `confirmarEntregaConCodigo({envioId,codigo})`, `marcarEnvioFallido(envioId,motivo)`, `confirmarRecepcion(pedidoId)`, `cancelarPedido(id)`, `createEvaluacion({pedidoId,puntaje,comentario})`, `getEvaluacion(pedidoId)`, `getReputacionProductor(productorId)`, `getResumenCliente()` |
| `services/payments.js` | `getPagoDePedido(pedidoId)`, `listPagos({estado})`, `listPagosRetenidos()`, `listPayouts({estado,tipo})`, `listPayoutsPendientes()`, `registrarPayoutPagado({payoutId,referencia,notas})`, `registrarReembolsoCliente({pedidoId,monto,notas,referencia})`, `getResumenCustodia()` |
| `services/seller.js` | `getMiProductor()`, `getMiPostulacion()`, `listSancionesDeProductor(productorId)`, `updateTienda({productorId,nombreComercial,descripcion})`, `getTiendaConUbicacion(productorId)`, `getDatosBancarios(perfilId)`, `guardarDatosBancarios({...})`, `listProductosVendedor({productorId,incluirInactivos,texto})`, `getProductoVendedor(id)`, `createProducto({...})`, `updateProducto(id,patch)`, `actualizarStock(id,stock)`, `desactivarProducto(id)`, `reactivarProducto(id)`, `subirImagenProducto({productoId,file,...})`, `eliminarImagenProducto(imagen)`, `getResumenVentas(productorId)` |
| `services/admin.js` | `getPendientesAdmin()`, `listUsuarios({rol,texto,activo})`, `getUsuario(id)`, `actualizarUsuario(id,patch)`, `desactivarUsuario(id)`, `reactivarUsuario(id)`, `listProductosAdmin({texto,productorId,activo})`, `desactivarProductoAdmin(id)`, `reactivarProductoAdmin(id)`, `listPostulaciones({estado,texto})`, `revisarPostulacion({postulacionId,aprobar,observaciones})`, `listPalabrasProhibidas()`, `crearPalabraProhibida()`, `actualizarPalabraProhibida()`, `revisarTexto(texto)`, `listCoincidenciasModeradas()`, `listSanciones({estado,productorId})`, `contarAmonestaciones(productorId)`, `crearSancion({productorId,tipo,accion,motivo,duracionDias})`, `resolverSancion(id,estado)`, `listPayouts({estado,tipo})`, `aprobarPayout({payoutId,referencia,notas})`, `registrarReembolso({pedidoId,monto,motivo,referencia})`, `getConfiguracionLogistica()`, `actualizarTarifaDelivery(tarifa)` |
| `services/registro.js` | `registrarCliente({...})`, `registrarVendedor({...})`, `crearPostulacion({...})`, `guardarDireccionPrincipal({...})` |

### 4.3 Stores

- `useAuthStore()`: `user`, `perfil`, `productor`, `postulacion`, `sanciones`,
  `rol`, `isCliente`, `isVendedor`, `isAdmin`, `email`, `nombreCompleto`,
  `iniciales`, `estaBloqueado`, `intentosRestantes`, `postulacionPendiente`,
  `bloqueoVendedor`, `puedeOperarTienda`; acciones `init`, `refresh`, `signIn`,
  `signOut`, `updatePassword(actual, nueva)`, `sendPasswordReset(correo)`,
  `updatePerfil(patch)`, `reenviarVerificacion(correo)`.
- `useCartStore()`: `items`, `destino`, `totalItems`, `subtotal`, `envio`,
  `comision`, `total`, `vacio`, `vendedorPrincipal`, `requiereVariosVendedores`,
  `cantidadDe`, `agregar`, `setCantidad`, `ajustar`, `quitar`, `limpiar`,
  `validarCobertura(direccion)`, `cobertura`, `sincronizar()`, `toItems()`.
- `useGeographyStore()`: `regiones`, `comunas`, `load()`, `comunasDeRegion(id)`,
  `nombreComuna(id)`, `nombreRegion(id)`, `regionDeComuna(id)`,
  `regionSeleccionadaId`, `setRegionSeleccionada(id)`.
- `useUiStore()`: `success/error/info/warning(title, message)`, `toasts`,
  `notifications`, `syncNotifications({rol})`, `sidebarAbierto`, `toggleSidebar()`.

---

## 5. Modelo de datos vigente (campos usados por el frontend)

```
perfiles          id, nombre, apellido, telefono, rol, activo,
                  intentos_login_fallidos, bloqueado_hasta, es_super_admin,
                  es_protegido, ultimo_acceso_en, creado_en
direcciones       id, perfil_id, etiqueta, comuna_id, calle, numero,
                  depto_oficina, referencia, es_principal, activo
postulaciones_vendedores
                  id, perfil_id, nombre_comercial_solicitado, descripcion,
                  estado, observaciones_admin, revisado_por, revisado_en
productores       id, perfil_id, nombre_comercial, slug, descripcion, activo,
                  aprobado_en, puntaje_reputacion, cantidad_evaluaciones
datos_bancarios   id, perfil_id, banco, tipo_cuenta, numero_cuenta_cifrado,
                  titular_cuenta, rut_titular, activo
categorias        id, categoria_padre_id, nombre, slug, es_sistema, eliminado_en
productos         id, productor_id, categoria_id, nombre, slug, descripcion,
                  precio, stock, unidad_medida, fecha_cosecha, activo, eliminado_en
imagenes_productos id, producto_id, ruta_storage, nombre_archivo, mime_type,
                  tamano_bytes, texto_alternativo, posicion, es_principal, metadatos
pedidos           id, codigo_pedido, cliente_id, productor_id,
                  region_entrega_id, comuna_entrega_id, direccion_entrega,
                  referencia_entrega, nombre_destinatario, telefono_destinatario,
                  estado, subtotal_productos, tarifa_delivery,
                  porcentaje_fee_plataforma, monto_fee_plataforma, total,
                  monto_retenido, monto_liquidar_productor, confirmado_cliente_en,
                  liberable_desde_en, payout_ejecutado_en, cancelado_en
detalles_pedido   id, pedido_id, producto_id, producto_nombre, precio_unitario,
                  cantidad, subtotal
pagos             id, pedido_id, buy_order, token_ws, estado, monto,
                  codigo_autorizacion, codigo_respuesta, respuesta_webpay,
                  autorizado_en, retenido_en, liberado_en, reembolsado_en
envios            id, pedido_id, repartidor_id, estado, tarifa_fija,
                  codigo_verificacion, codigo_verificado_en, despachado_en,
                  entregado_en, fallido_en, motivo_fallo
payouts           id, beneficiario_id, pedido_id, tipo, monto, estado,
                  referencia_externa, comprobante_ruta, notas, ejecutado_por,
                  ejecutado_en
evaluaciones_reputacion id, pedido_id, productor_id, cliente_id, puntaje, comentario
sanciones         id, productor_id, tipo, accion, estado, numero_amonestacion,
                  motivo, duracion_dias, inicio_en, fin_en, impuesta_por
apelaciones       id, sancion_id, productor_id, solicitante_id, fundamento,
                  estado, resolucion, resuelto_por
palabras_prohibidas id, palabra, activo
regiones / comunas id, codigo, nombre, region_id
configuracion_logistica id (=1), tarifa_delivery_defecto
```

### 5.1 Máquina de estados (la aplican triggers; el frontend debe respetarla)

- **Pedido:** `creado → pagado → en_preparacion → completado`; `completado →
  reclamado`; `cancelado` sólo desde `creado`, `pagado` o `en_preparacion`.
- **Envío:** `preparacion → en_transito → entregado`; `fallido` desde
  `preparacion` o `en_transito` (exige `motivo_fallo`).
- **Pago:** `creado → autorizado → retenido → liberado`; `reembolsado` desde
  `autorizado`, `retenido` o `liberado`.
- **Payout:** `pendiente → procesando → pagado` (la RPC
  `registrar_payout_pagado` es la única vía para marcar `pagado`).
- El **código de verificación** lo genera el trigger al pasar el envío a
  `en_transito` y sólo puede verificarse en ese estado
  (`verificar_codigo_entrega`, que valida cliente o administrador).
- Al marcar el envío como `entregado`, el pedido pasa a `completado` y se crea
  el payout `pago_productor` en estado `pendiente` automáticamente.

### 5.2 Reglas

- Región del vendedor = región de su dirección activa (`direcciones.comuna_id →
  comunas.region_id`). RF-009 compara esa región con la de la dirección de
  entrega del cliente **antes** de crear el pago.
- RF-014: `monto_fee_plataforma = round(subtotal * 0.05)`;
  `total = subtotal + 3500`; `monto_liquidar_productor = total - fee`.
- RF-007: sin el código correcto, el envío no pasa a `entregado`.
- RF-001: bloqueo de 15 minutos tras 5 intentos fallidos (contador en el perfil).
- RF-017: nunca se borra físicamente; se usa `activo = false` o
  `eliminado_en = now()`.

---

## 6. Convenciones de interfaz

- Español de Chile, tono directo, sin tecnicismos innecesarios.
- Cifras en CLP: `formatCurrency` de `@/lib/format` (`$1.234`).
- Fechas: `formatDate` / `formatDateTime` de `@/lib/format`.
- Los estados se muestran con `StatusBadge` (`type="pedido" | "pago" | "envio" |
  "postulacion" | "sancion" | "apelacion" | "rol"`).
- Cada vista con datos remotos debe manejar: `loading`, `error`, `vacío`.
- Los formularios usan `lib/validation.js` (`validate(values, schema)`,
  `isEmail`, `isPhone`, `isRut`, `passwordPolicyMessage`, `required`,
  `isPositive`, `isNonNegative`, `isUuid`) y muestran el error en el campo.
- Nada de `alert()`/`confirm()` del navegador: usar `CtConfirmDialog` y los
  toasts de `useUiStore`.
