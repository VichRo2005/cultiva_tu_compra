import { fileURLToPath } from 'node:url'
import { mergeConfig, defineConfig, configDefaults } from 'vitest/config'
import viteConfig from './vite.config.js'

/*
 * `vite.config.js` exporta una función (lee `VITE_API_BASE_URL` para el desvío
 * del retorno de Webpay), así que hay que resolverla antes de fusionarla:
 * `mergeConfig` no acepta callbacks.
 */
export default defineConfig((configEnv) =>
  mergeConfig(
    viteConfig(configEnv),
    defineConfig({
      test: {
        environment: 'jsdom',
        exclude: [...configDefaults.exclude, 'e2e/**'],
        root: fileURLToPath(new URL('./', import.meta.url)),
      },
    }),
  ),
)
