# CuTuCo — Guía de Estilos y CSS (para agentes)

> **Objetivo:** este documento es la **referencia única** para que cualquier agente que
> cree o corrija vistas del frontend mantenga los estilos consistentes con el sistema
> de diseño existente. **No inventar nada** que no esté aquí documentado.

---

## 1. Arquitectura CSS (tres niveles — NO se rompe)

El stylesheet global se compone de tres capas importadas en orden en `src/main.js`:

```js
import '@/styles/tokens.css'     // 1. Design tokens (variables CSS en :root)
import '@/styles/base.css'        // 2. Reset / normalización adaptada al producto
import '@/styles/utilities.css'   // 3. Utilidades globales (layout, tipografía, etc.)
```

### 1.1 `src/styles/tokens.css` — Fuente de verdad

Define **todas** las variables CSS con prefijo `ct-` (CuTuCo) en `:root`.
Cualquier valor de color, espaciado, tipografía, radio, sombra, z-index o transición
que se necesite **ya existe aquí**. No se crean nuevas.

| Categoría | Prefijo | Ejemplos clave |
|---|---|---|
| Marca / acentos | `--ct-primary*` | `--ct-primary`, `--ct-primary-fill`, `--ct-primary-soft` |
| Estados | `--ct-success/danger/warning/info*` | `--ct-danger`, `--ct-warning-strong`, `--ct-success-soft` |
| Neutras / superficies | `--ct-bg`, `--ct-surface*`, `--ct-border*`, `--ct-ink*` | `--ct-surface-alt`, `--ct-border-strong` |
| Texto | `--ct-text`, `--ct-text-soft/muted/faint/invert` | — |
| Tipografía | `--ct-font`, `--ct-font-mono`, `--ct-fw-*`, `--ct-fs-*` | escala de `--ct-fs-2xs` a `--ct-fs-5xl` |
| Espaciado | `--ct-space-*` | escala 4px: `--ct-space-1`(0.25rem)…`--ct-space-20`(5rem) |
| Layout | `--ct-container`, `--ct-gutter`, `--ct-sidebar-width`, `--ct-header-height` | — |
| Radios | `--ct-radius-sm`, `--ct-radius`, `--ct-radius-md`, `--ct-radius-lg`, `--ct-radius-xl`, `--ct-radius-pill` | — |
| Sombras | `--ct-shadow-xs`…`--ct-shadow-lg`, `--ct-shadow-focus` | — |
| Transiciones | `--ct-transition`, `--ct-transition-slow` | — |
| Z-index | `--ct-z-sticky`(20)…`--ct-z-toast`(100) | usar SIEMPRE |
| Breakpoints | *(ninguno — ver sección 5)* | — |

### 1.2 `src/styles/base.css` — Reset y base (normalización del producto)

Incluye el `normalize.css` casero: box-sizing, remoción de márgenes, tipografía base,
reset de elementos nativos (`img`, `input`, `button`, etc.), estilos base de `a`/`h1-h4`,
**focus-visible**, **prefers-reduced-motion**, scrollbar discreto, selección de texto.

**Nunca se modifica** sin coordinación: es el contrato visual de la base.

### 1.3 `src/styles/utilities.css` — Utilidades globales (no hay Tailwind)

Clases para reusar directamente en templates. Ver lista completa en el archivo.
Las más usadas:

```html
<div class="container hero-dark page">     <!-- layout -->
  <section class="grid grid-cards bloque"> ... </section>
  <div class="row row--between stack stack--lg"> ... </div>
  <span class="text-sm text-soft mono"> ... </span>
  <hr class="divider" />
</div>
```

| Grupo | Clases |
|---|---|
| Layout | `.container`, `.container--narrow`, `.container--wide` |
| Grid 12 cols | `.grid`, `.col-1`…`.col-12` (auto-responsive: `<720px`→span 12) |
| Grid semántico | `.grid-cards`, `.grid-cards--sm/lg`, `.grid-kpi`, `.split`, `.split--sidebar-left` |
| Flexbox | `.stack`, `.stack--xs/sm/lg/xl`, `.row`, `.row--between/wrap/top/end/center`, `.spacer` |
| Texto | `.text-xs…text-4xl`, `.text-soft/muted/success/danger/…`, `.font-medium/semibold/bold` `.mono`, `.text-center/right`, `.truncate`, `.clamp-2/3` |
| Superficie | `.surface`, `.divider`, `.divider--vertical`, `.eyebrow`, `.chip`, `.chip--active`, `.hero-dark` |
| Página | `.page`, `.page--tight`, `.page-head`, `.page-head__title/subtitle/actions`, `.section-title`, `.section-header` |
| Animación transición | `.fade-*`, `.slide-up-*`, `@keyframes ct-skeleton`, `ct-spin` |
| Accesibilidad | `.ct-sr-only` |

---

## 2. Convención de nombrado: **BEM con namespace `ct-` + nombre-vista**

| Patrón | Ejemplo | Dónde |
|---|---|---|
| Bloque (componente base) | `.ct-btn`, `.ct-field`, `.ct-table`, `.ct-nav` | `components/base/*`, `components/layout/*` |
| Elemento | `.ct-btn__label`, `.ct-field__input` | hijos del bloque |
| Modificador | `.ct-btn--primary`, `.ct-nav__link--action` | variante/estado del bloque |
| Estado (Vue dinámico) | `.is-active`, `.is-loading`, `.is-clickable`, `.is-dense`, `.is-sticky` | bindings `:class="{ 'is-active': ... }"` |
| Vista (scoped) | `.hero__title`, `.bloque__head`, `.categoria__nombre` | solo en `<style scoped>` de la vista |

### Regla de oro

- **Componentes reutilizables** → namespace `ct-` (base/layout).
- **Estilos propios de una vista** → `<style scoped>` con `nombre-vista__elemento@`.
- **Nunca** nombrar elementos genéricos como `.title`, `.card`, `.row` en scoped
  (colisionan visualmente con utilities). Prefiere `.nombre-vista__titulo`.

---

## 3. Modelo de estilos por componente

1. Los componentes base viven en `src/components/base/` (28: `CtButton`, `CtInput`,
   `CtSelect`, `CtTable`, `CtModal`, `CtPagination`, `CtAvatar`, `CtIcon`, etc.).
2. Cada uno usa `<style scoped>` y **solo consume tokens `var(--ct-*)`**.
3. Cada componente `Ct*` expone props para variantes en lugar de clases CSS libres:
   `<CtButton variant="primary|accent|secondary|outline|ghost|danger|dark" size="sm|md|lg">`.

**Al crear una vista: reusa `Ct*` antes de escribir HTML/CSS propio.**

---

## 4. CSS scoped — reglas estrictas

- Toda vista nueva usa **`<style scoped>`**. Nunca estilos globales.
- El CSS de la vista **solo redefine detalles visuales propios**; layout general
  reutiliza utilidades (`.container`, `.page`, `.grid`, `.stack`, `.row`).
- Variables SIEMPRE:
  ```css
  /* ✅ */
  .mi-vista__titulo {
    font-size: var(--ct-fs-3xl);
    color: var(--ct-text);
    border-radius: var(--ct-radius-lg);
    transition: color var(--ct-transition);
    z-index: var(--ct-z-modal);
  }
  /* ❌ */
  .mi-vista__titulo { font-size: 30px; color: #1a1a1a; z-index: 999; }
  ```
- Para profundidad mínima en `:deep()` se permite **solo si ajustar un componente
  `Ct*` sin alternativa**, y con comentario justificando.

---

## 5. Responsividad (breakpoints consolidados)

**No existen variables de breakpoint.** Los valores usados consistentemente en el
código:

| Media query | Uso típico |
|---|---|
| `@media (max-width: 1180px)` | barra top: reduce search |
| `@media (max-width: 1024px)` | sidebar: overlay; grid: 1 col |
| `@media (max-width: 980px)` | home: grid → 1 col |
| `@media (max-width: 860px)` | topbar: esconde search/user |
| `@media (max-width: 720px)` | grid `.col-N` → span 12 (global) |
| `@media (max-width: 1100px)` | grid 12 cols → col-3/4 span 6 |

**La grilla `.grid .col-N` ya se auto-normaliza** en `<720px` a `span 12`; si usas
esa grilla no reescribas breakpoints para columnas básicas.

---

## 6. Accesibilidad (no es opcional)

- `:focus-visible` (no `:focus`) para contornos de foco.
- `prefers-reduced-motion` → ya está en `base.css`; respetarlo (no forzar animaciones).
- `aria-label`, `aria-describedby`, `role` donde el DOM nativo no baste.
- `<button type="button">` para acciones; `<a>`/`<router-link>` para navegación; **nunca**
  `<div @click>`.
- Texto accesible oculto: clase `.ct-sr-only`.
- Semántica de encabezados en orden (`h1`→`h2`→`h3`).
- Tablas: `<thead>`, `<tbody>`, `<th>` con `text-align` semántico.
- En inputs: `aria-invalid` en error, `aria-expanded` en dropdowns/menus.

---

## 7. Buenas prácticas de layout (patrones reales)

### Shell de página (vista dentro de `AppShell`)
```vue
<template>
  <div class="page">  <!-- padding vertical + gap -->
    <header class="page-head"> ... </header>
    <section class="surface"> ... </section>
  </div>
</template>
```

### Section con encabezado
```vue
<section class="bloque">
  <header class="bloque__head">
    <div class="bloque__text">
      <h2 class="section-title">...</h2>
      <p class="page-subtitle">...</p>
    </div>
  </header>
  ...
</section>
```

### Estado vacío / loading
Usar componentes `CtEmptyState` y `CtSpinner` (ya existentes).

---

## 8. Herramientas de calidad (obligatorio)

| Herramienta | Regla |
|---|---|
| **Prettier** (`.prettierrc.json`) | `semi: false`, `singleQuote: true`, `printWidth: 100` — aplica también al `<style>` |
| **Oxlint** (`.oxlintrc.json`) | `correctness: error` — ejecutar `npm run lint` (auto-fix) |
| **EditorConfig** (`.editorconfig`) | 2-space indent, UTF-8, LF, trim trailing, final newline, max 100 |
| **ESLint** (`eslint.config.js`) | flat config, Vue — `skipFormatting` desactiva formateo que Prettier cubre |

**Comandos:**
```sh
npm run lint       # oxlint + eslint --fix (autofix)
npm run format     # prettier --write src/
```

Verificar antes de finalizar cualquier cambio visual.

---

## 9. Checklist rápido (para validar una vista nueva)

- [ ] Reúso `CtButton`, `CtInput`, etc. en lugar de HTML/CSS propio.
- [ ] Layout con utilidades: `.container`, `.page`, `.grid/.col-N`, `.stack`, `.row`.
- [ ] Todo color/tamaño/radio/sombra/z-index/transición viene de `var(--ct-*)`.
- [ ] Clases en scoped siguen `nombre-vista__elemento` / `.is-*`.
- [ ] `<style scoped>`, no global.
- [ ] Breakpoints literales correctos (1180/1024/980/860/720).
- [ ] Accesibilidad: foco visible, aria, semántica, `type="button"`.
- [ ] `npm run lint` y `npm run format` pasan sin warnings de CSS.

---

## 10. Archivos de referencia (no tocar a menos que sea token)

```
src/styles/tokens.css        ← SOLO para añadir tokens nuevos (coordinar)
src/styles/base.css           ← Reset/base — no modificar sin justificación
src/styles/utilities.css      ← Utilidades — añadir solo si es genérico
src/components/base/*.vue     ← Sistema de componentes — extender con props, no con estilos sueltos
src/components/layout/*       ← Shell (AppShell, AppTopbar, AppSidebar, AppFooter)
```

Referencia modelo: `src/views/public/HomeView.vue` (combina utilities + Ct* + scoped BEM).
