import { fileURLToPath, URL } from 'node:url'

import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import vueDevTools from 'vite-plugin-vue-devtools'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, fileURLToPath(new URL('.', import.meta.url)), '')
  const apiBase = (env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')

  return {
    plugins: [vue(), vueJsx(), vueDevTools()],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },
    server: {
      watch: {
        /*
         * OneDrive crea archivos temporales (`.<archivo>.tmpdir` y variantes
         * `archivo.vue~RFxxxx.TMP`) dentro de `src/` al guardar. Vite intenta
         * vigilarlos y el proceso muere con EBUSY, tumbando el servidor de
         * desarrollo. Ignorarlos evita el problema sin afectar al recargo en
         * caliente.
         */
        ignored: [
          '**/.*.tmpdir/**',
          '**/*.tmpdir/**',
          '**/*.tmp',
          '**/*.TMP',
          '**/*~RF*',
          '**/~$*',
          '**/.git/**',
          '**/dist/**',
        ],
      },
      proxy: {
        /*
         * Retorno de Webpay Plus.
         *
         * `TRANSBANK_RETURN_URL` del backend es `http://localhost:5173/cliente/pedidos`:
         * Transbank devuelve ahí el navegador con el pago ya efectuado mediante un
         * POST del formulario, y esa ruta es de la SPA. Sin este desvío el POST
         * muere en el servidor de Vite y el commit nunca se ejecuta.
         *
         * Sólo se intercepta el POST: los GET siguen resolviendo la SPA (el
         * `bypass` devuelve la misma URL para que Vite continúe con su cadena de
         * middlewares), y FastAPI responde 303 hacia la misma ruta por GET.
         */
        '/cliente/pedidos': {
          target: apiBase,
          changeOrigin: true,
          rewrite: () => '/api/webpay/retorno',
          bypass(req) {
            if (req.method !== 'POST') return req.url
          },
        },
      },
    },
    test: {
      environment: 'jsdom',
      globals: true,
      include: ['src/**/*.spec.js'],
      // Las pruebas de integración consultan la base local y el modo demo.
      testTimeout: 30000,
    },
  }
})
