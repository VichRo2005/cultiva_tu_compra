/** Supabase real + login GoTrue del seed. No altera cuentas ni ejecuta DELETE.
 * En Windows se puede usar Edge instalado con PLAYWRIGHT_CHANNEL=msedge
 * y correr únicamente --project=chromium.
 */
import process from 'node:process'
import { test, expect } from '@playwright/test'

test.use({ headless: true, channel: process.env.PLAYWRIGHT_CHANNEL })

test.beforeEach(async ({ page }) => {
  await page.goto('/login')
  await page.getByLabel(/Correo Electrónico/).fill('cutuco.admin.base@example.test')
  await page.getByLabel(/Contraseña/).fill('CutucoTest!2026')
  await page.getByRole('button', { name: 'Acceder a la Plataforma' }).click()
  await expect(page).toHaveURL(/\/admin$/)
  await page.goto('/admin/usuarios')
  await expect(page.getByRole('heading', { name: 'Gestión de usuarios' })).toBeVisible()
  await expect(page.getByRole('table')).toBeVisible()
})

test('admin consulta perfiles, busca y no puede cambiar al administrador protegido', async ({
  page,
}, testInfo) => {
  await page.getByPlaceholder('Buscar por nombre, apellido o teléfono…').fill('Base')
  await expect(page.getByText('1 resultado · 1 en esta página', { exact: true })).toBeVisible()
  const tabla = page.getByRole('table')
  await expect(tabla.getByText('Administrador Base', { exact: true })).toBeVisible()
  await expect(
    tabla.getByRole('button', { name: 'Desactivar a Administrador Base' }),
  ).toBeDisabled()
  await page.screenshot({
    path: testInfo.outputPath('usuarios-desktop.png'),
    fullPage: true,
    animations: 'disabled',
  })
  await tabla.getByRole('button', { name: 'Ver detalle de Administrador Base' }).click()
  const dialogo = page.getByRole('dialog')
  await expect(dialogo.getByText('Cuenta protegida', { exact: true })).toBeVisible()
  await expect(dialogo.getByLabel('Cambiar rol', { exact: true })).toHaveCount(0)
  await expect(
    dialogo.getByRole('button', { name: 'Eliminar permanentemente', exact: true }),
  ).toBeDisabled()
})

test('el detalle móvil conserva la tienda y remite al vendedor a Sanciones', async ({
  page,
}, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await page.getByPlaceholder('Buscar por nombre, apellido o teléfono…').fill('Pausado')
  await expect(page.getByText('1 resultado · 1 en esta página', { exact: true })).toBeVisible()
  await page.getByRole('button', { name: 'Ver detalle de Productor Pausado' }).click()
  const dialogo = page.getByRole('dialog')
  await expect(dialogo.getByText('Huerta Pausada Test', { exact: true })).toBeVisible()
  await expect(dialogo.getByLabel('Cambiar rol', { exact: true })).toHaveCount(0)
  await expect(
    dialogo.getByRole('button', { name: 'Eliminar permanentemente', exact: true }),
  ).toBeDisabled()
  await expect(
    dialogo.getByRole('button', { name: 'Desactivar cuenta', exact: true }),
  ).toBeDisabled()
  const sanciones = dialogo.getByRole('link', { name: 'Ir a Sanciones' })
  await expect(sanciones).toHaveAttribute('href', '/admin/sanciones')
  await page.screenshot({
    path: testInfo.outputPath('usuarios-mobile.png'),
    animations: 'disabled',
  })
  await dialogo
    .getByRole('button', { name: 'Eliminar permanentemente', exact: true })
    .scrollIntoViewIfNeeded()
  await expect(
    dialogo.getByRole('button', { name: 'Eliminar permanentemente', exact: true }),
  ).toBeVisible()
  await page.screenshot({
    path: testInfo.outputPath('usuarios-mobile-controles.png'),
    animations: 'disabled',
  })
  const ancho = await page.evaluate(() => ({
    contenido: document.documentElement.scrollWidth,
    ventana: window.innerWidth,
  }))
  expect(ancho.contenido).toBeLessThanOrEqual(ancho.ventana)
  await sanciones.click()
  await expect(page).toHaveURL(/\/admin\/sanciones$/)
})

test('una sesión nueva requiere login y no entra automáticamente como administrador', async ({
  browser,
  baseURL,
}) => {
  const contexto = await browser.newContext()
  try {
    const pagina = await contexto.newPage()
    await pagina.goto(new URL('/admin/usuarios', baseURL).href)
    await expect(pagina).toHaveURL(/\/login\?redirect=/)
    await expect(pagina.getByLabel(/Correo Electrónico/)).toHaveValue('')
  } finally {
    await contexto.close()
  }
})
