/** Requiere Supabase local con migraciones y seed aplicados. Solo consulta datos. */
import { test, expect } from '@playwright/test'
import process from 'node:process'

test.use({
  headless: true,
  channel: process.env.PLAYWRIGHT_CHANNEL ?? (process.platform === 'win32' ? 'msedge' : undefined),
})

test('filtra productos y abre el detalle sin salir del administrador', async ({ page }) => {
  await page.goto('/login')
  await page.getByLabel(/Correo Electrónico/).fill('cutuco.admin.base@example.test')
  await page.getByLabel(/Contraseña/).fill('CutucoTest!2026')
  await page.getByRole('button', { name: 'Acceder a la Plataforma' }).click()
  await expect(page).toHaveURL(/\/admin$/)
  await page.goto('/admin/productos')
  await expect(page.getByRole('heading', { name: 'Administración de productos' })).toBeVisible()

  await page
    .getByRole('textbox', { name: 'Buscar productos', exact: true })
    .fill('Papas Nuevas de Melipilla')
  const tabla = page.getByRole('table')
  await expect(tabla.getByRole('button', { name: 'Papas Nuevas de Melipilla' })).toBeVisible()
  await expect(tabla.getByRole('row')).toHaveCount(2)
  await tabla.getByRole('button', { name: 'Papas Nuevas de Melipilla' }).click()
  const dialogo = page.getByRole('dialog')
  await expect(dialogo.getByText('Papas Nuevas de Melipilla').first()).toBeVisible()
  await expect(dialogo.getByRole('button', { name: 'Añadir al Carrito' })).toHaveCount(0)
  await expect(dialogo.getByRole('button', { name: 'Comprar Ahora' })).toHaveCount(0)
  await expect(page).toHaveURL(/\/admin\/productos$/)

  await dialogo.getByRole('button', { name: 'Cerrar' }).click()
  await tabla.getByRole('button', { name: 'Eliminar' }).click()
  const eliminacion = page.getByRole('dialog')
  const confirmar = eliminacion.getByRole('button', { name: 'Eliminar' })
  await expect(confirmar).toBeDisabled()
  await eliminacion.getByLabel('Justificación de la eliminación').fill('Muy breve')
  await expect(confirmar).toBeDisabled()
  await eliminacion
    .getByLabel('Justificación de la eliminación')
    .fill('Motivo de eliminación válido')
  await expect(confirmar).toBeEnabled()
})
