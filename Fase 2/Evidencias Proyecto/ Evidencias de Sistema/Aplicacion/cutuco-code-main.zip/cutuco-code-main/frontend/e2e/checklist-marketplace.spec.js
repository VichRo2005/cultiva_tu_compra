import process from 'node:process'
import { test, expect } from '@playwright/test'

test.use({ headless: true, channel: process.env.PLAYWRIGHT_CHANNEL })

async function loginCliente(page) {
  await page.goto('/login')
  await page.getByLabel(/Correo Electrónico/).fill('cutuco.cliente.santiago@example.test')
  await page.getByLabel(/Contraseña/).fill('CutucoTest!2026')
  await page.getByRole('button', { name: 'Acceder a la Plataforma' }).click()
  await expect(page.getByRole('button', { name: 'Cerrar sesión' })).toBeVisible()
}

test('CK-0016: cerrar sesión retira la vista privada de la otra pestaña', async ({ page, context }) => {
  await loginCliente(page)
  const segunda = await context.newPage()
  await segunda.goto('/cliente/perfil')
  await expect(segunda.getByRole('button', { name: 'Cerrar sesión' })).toBeVisible()
  await page.getByRole('button', { name: 'Cerrar sesión' }).click()
  await expect(segunda).toHaveURL(/\/login/)
  await expect(segunda.getByRole('button', { name: 'Acceder a la Plataforma' })).toBeVisible()
  await expect(segunda.getByRole('button', { name: 'Cerrar sesión' })).toHaveCount(0)
})

test('CK-0071/0080: dos tiendas conservan sus productos y despacho en el resumen', async ({ page }) => {
  await loginCliente(page)
  for (const id of ['30000000-0000-0000-0000-000000000102', '30000000-0000-0000-0000-000000000201']) {
    await page.goto(`/producto/${id}`)
    await page.getByRole('button', { name: 'Añadir al Carrito', exact: true }).click()
  }
  await page.getByLabel('Carrito', { exact: true }).first().click()
  await expect(page.getByText('Compra en varias tiendas', { exact: true })).toBeVisible()
  await expect(page.getByText('Papas Nuevas de Paine', { exact: true })).toBeVisible()
  await expect(page.getByText('Tomates de Melipilla', { exact: true })).toBeVisible()
  await expect(page.getByText('$4.500', { exact: true }).first()).toBeVisible()
  await page.getByRole('button', { name: 'Finalizar Pedido', exact: true }).click()
  await expect(page).toHaveURL(/\/checkout/)
  const resumen = page.getByRole('complementary').filter({
    has: page.getByRole('heading', { name: 'Resumen de Compra' }),
  })
  await expect(resumen.getByText('Papas Nuevas de Paine', { exact: true })).toBeVisible()
  await expect(resumen.getByText('Tomates de Melipilla', { exact: true })).toBeVisible()
})

test('CK-0001/0012: cliente inicia sesión y no abre administración por URL', async ({ page }) => {
  await loginCliente(page)
  await page.goto('/cliente/perfil')
  await expect(page).toHaveURL(/\/cliente\/perfil/)
  await page.goto('/admin')
  await expect(page).not.toHaveURL(/\/admin/)
  await expect(page.getByRole('button', { name: 'Cerrar sesión' })).toBeVisible()
})

test('CK-0004: contraseña incorrecta no habilita sesión', async ({ page }) => {
  await page.goto('/login')
  await page.getByLabel(/Correo Electrónico/).fill('cutuco.cliente.santiago@example.test')
  await page.getByLabel(/Contraseña/).fill('ClaveIncorrecta!2026')
  await page.getByRole('button', { name: 'Acceder a la Plataforma' }).click()
  await expect(page.getByText(/correo o la contraseña|credenciales|contraseña.*incorrect/i).first()).toBeVisible()
  await expect(page.getByRole('button', { name: 'Cerrar sesión' })).toHaveCount(0)
})

test('CK-0048/0056: catálogo público y checkout con autenticación obligatoria', async ({ page }) => {
  await page.goto('/catalogo?q=tomate')
  await expect(page.getByRole('banner').getByText('Sin sesión', { exact: true })).toBeVisible()
  await expect(page.getByText('Tomates de Melipilla', { exact: true }).first()).toBeVisible()
  await expect(page.getByRole('button', { name: 'Cerrar sesión' })).toHaveCount(0)
  await page.goto('/checkout')
  await expect(page).toHaveURL(/\/login/)
})
