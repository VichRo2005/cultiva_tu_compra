import { test, expect } from '@playwright/test'

/**
 * Humo de la interfaz: shell persistente + ventanas públicas.
 * Requieren `npx playwright install` para ejecutarse.
 */

test.beforeEach(async ({ page }) => {
  // Estos smoke tests prueban la navegación pública con el dataset local.
  // El modo demo inicia como administrador; cerrar esa sesión es parte del fixture.
  await page.route('**/rest/v1/**', (route) => route.abort())
  await page.goto('/')
  await page.getByRole('button', { name: 'Cerrar sesión' }).click()
  await expect(page.getByRole('button', { name: 'Cerrar sesión' })).toHaveCount(0)
})

test('la portada muestra el hero del diseño dentro del shell', async ({ page }) => {
  await expect(page.locator('h1').first()).toContainText('El Campo Chileno en tu Pantalla')
  await expect(page.getByRole('navigation', { name: 'Navegación principal' })).toBeVisible()
  await expect(page.locator('html')).toHaveAttribute('lang', 'es-CL')
})

test('la barra lateral persistente lleva del inicio al catálogo y al carrito', async ({ page }) => {
  const nav = page.getByRole('navigation', { name: 'Navegación principal' })

  await nav.getByRole('link', { name: 'Catálogo' }).click()
  await expect(page).toHaveURL(/\/catalogo$/)
  await expect(nav).toBeVisible()

  await page.getByLabel('Carrito').first().click()
  await expect(page).toHaveURL(/\/carrito$/)
})

test('el buscador superior filtra el catálogo', async ({ page }) => {
  await page.getByLabel('Buscar productos en CuTuCo').fill('tomate')
  // En la portada hay dos botones Buscar (topbar y hero): se acota al banner.
  await page.getByRole('banner').getByRole('button', { name: 'Buscar' }).click()
  await expect(page).toHaveURL(/q=tomate/)
})
