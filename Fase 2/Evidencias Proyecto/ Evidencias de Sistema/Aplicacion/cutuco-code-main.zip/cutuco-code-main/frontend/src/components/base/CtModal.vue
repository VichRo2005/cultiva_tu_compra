<script setup>
/** CuTuCo — Modal accesible con slots de encabezado, contenido y pie. */
import { nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: null },
  subtitle: { type: String, default: null },
  size: { type: String, default: 'md' }, // sm | md | lg | xl
  closeOnBackdrop: { type: Boolean, default: true },
  hideFooter: { type: Boolean, default: false },
})

const emit = defineEmits(['update:modelValue', 'close'])

const panel = ref(null)
const titleId = useId()
let elementoAnterior = null
let overflowAnterior = ''

const FOCUSABLE = [
  'a[href]',
  'button:not([disabled])',
  'textarea:not([disabled])',
  'input:not([disabled])',
  'select:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

function focusables() {
  if (!panel.value) return []
  return [...panel.value.querySelectorAll(FOCUSABLE)].filter(
    (el) => el.getAttribute('aria-hidden') !== 'true' && el.offsetParent !== null,
  )
}

function close() {
  emit('update:modelValue', false)
  emit('close')
}

function onKeydown(event) {
  if (!props.modelValue) return
  if (event.key === 'Escape') {
    event.stopPropagation()
    close()
    return
  }
  if (event.key !== 'Tab') return

  const lista = focusables()
  if (!lista.length) {
    event.preventDefault()
    panel.value?.focus()
    return
  }
  const primero = lista[0]
  const ultimo = lista[lista.length - 1]
  const activo = document.activeElement
  const dentro = panel.value?.contains(activo)

  if (event.shiftKey && (!dentro || activo === primero)) {
    event.preventDefault()
    ultimo.focus()
  } else if (!event.shiftKey && (!dentro || activo === ultimo)) {
    event.preventDefault()
    primero.focus()
  }
}

watch(
  () => props.modelValue,
  async (open) => {
    if (open) {
      elementoAnterior = document.activeElement
      overflowAnterior = document.body.style.overflow
      document.body.style.overflow = 'hidden'
      await nextTick()
      // Foco inicial en el panel: el lector de pantalla anuncia el nombre del
      // diálogo y el siguiente Tab entra al primer control (cerrar).
      panel.value?.focus()
    } else {
      document.body.style.overflow = overflowAnterior
      // Devuelve el foco al control que abrió el modal.
      if (elementoAnterior && typeof elementoAnterior.focus === 'function') {
        elementoAnterior.focus()
      }
      elementoAnterior = null
    }
  },
  { immediate: true },
)

onMounted(() => document.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => {
  document.removeEventListener('keydown', onKeydown)
  document.body.style.overflow = overflowAnterior || ''
})
</script>

<template>
  <Teleport to="body">
    <Transition name="ct-modal">
      <div
        v-if="modelValue"
        class="ct-modal"
        role="dialog"
        aria-modal="true"
        :aria-labelledby="title ? titleId : undefined"
        :aria-label="title ? undefined : 'Diálogo'"
        @click.self="closeOnBackdrop && close()"
      >
        <div ref="panel" class="ct-modal__panel" :class="`ct-modal__panel--${size}`" tabindex="-1">
          <header v-if="title || $slots.header" class="ct-modal__header">
            <div>
              <h3 v-if="title" :id="titleId" class="ct-modal__title">{{ title }}</h3>
              <p v-if="subtitle" class="ct-modal__subtitle">{{ subtitle }}</p>
              <slot v-else name="header" />
            </div>
            <button type="button" class="ct-modal__close" aria-label="Cerrar" @click="close">×</button>
          </header>
          <div class="ct-modal__body">
            <slot />
          </div>
          <footer v-if="!hideFooter && $slots.footer" class="ct-modal__footer">
            <slot name="footer" />
          </footer>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.ct-modal {
  position: fixed;
  inset: 0;
  z-index: var(--ct-z-modal);
  background: var(--ct-overlay);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--ct-space-6);
}

.ct-modal__panel {
  background: var(--ct-surface);
  border-radius: var(--ct-radius-xl);
  box-shadow: var(--ct-shadow-xl);
  width: 100%;
  max-height: calc(100vh - 3rem);
  max-height: calc(100dvh - 3rem);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.ct-modal__panel:focus {
  outline: none;
}

.ct-modal__panel--sm {
  max-width: 420px;
}
.ct-modal__panel--md {
  max-width: 620px;
}
.ct-modal__panel--lg {
  max-width: 880px;
}
.ct-modal__panel--xl {
  max-width: 1120px;
}

.ct-modal__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-6) var(--ct-space-6) var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
}

.ct-modal__title {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-semibold);
}

.ct-modal__subtitle {
  margin-top: var(--ct-space-1);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.ct-modal__close {
  font-size: 1.5rem;
  line-height: 1;
  color: var(--ct-text-muted);
  padding: var(--ct-space-1);
  border-radius: var(--ct-radius-sm);
}

.ct-modal__close:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.ct-modal__body {
  padding: var(--ct-space-6);
  overflow-y: auto;
}

.ct-modal__footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4) var(--ct-space-6);
  border-top: 1px solid var(--ct-border);
  background: var(--ct-surface-alt);
}

.ct-modal-enter-active,
.ct-modal-leave-active {
  transition: opacity var(--ct-transition);
}

.ct-modal-enter-active .ct-modal__panel,
.ct-modal-leave-active .ct-modal__panel {
  transition: transform var(--ct-transition);
}

.ct-modal-enter-from,
.ct-modal-leave-to {
  opacity: 0;
}

.ct-modal-enter-from .ct-modal__panel,
.ct-modal-leave-to .ct-modal__panel {
  transform: translateY(12px) scale(0.98);
}
</style>
