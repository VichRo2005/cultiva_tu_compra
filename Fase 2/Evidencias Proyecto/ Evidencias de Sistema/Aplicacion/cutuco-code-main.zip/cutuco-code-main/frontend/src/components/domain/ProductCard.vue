<script setup>
/**
 * CuTuCo — Tarjeta de producto del catálogo (RF-002 y RF-022).
 * Es el componente de referencia compartido por el catálogo público, el
 * catálogo del cliente y los grids relacionados.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el distintivo "Cosecha del
 * día" (RF-008/RF-010), el aviso de stock bajo por umbral y la comparación con
 * un precio de referencia salieron del alcance del ERS vigente.
 */
import { computed } from 'vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import { configuracionCantidadProducto, formatearCantidad, normalizarNombreCategoria } from '@/services/catalog'
import { formatCLP } from '@/lib/format'
import { placeholderImage } from '@/lib/images'

const props = defineProps({
  producto: { type: Object, required: true },
  showProducer: { type: Boolean, default: true },
  showCategory: { type: Boolean, default: false },
  showRating: { type: Boolean, default: false },
  actionable: { type: Boolean, default: true },
  to: { type: [String, Object], default: null },
  selectable: { type: Boolean, default: false },
  selected: { type: Boolean, default: false },
})

const emit = defineEmits(['add', 'toggle'])

const agotado = computed(() => Number(props.producto.stock) <= 0)
const enlace = computed(() => props.to ?? `/producto/${props.producto.id}`)
const unidad = computed(() => props.producto.unidad_medida ?? 'unidad')
const nombreCategoria = computed(() =>
  normalizarNombreCategoria(props.producto.categoria?.nombre ?? 'Sin categoría'),
)
const reglaCompra = computed(() => {
  const config = configuracionCantidadProducto(props.producto)
  if (config.agotado) return null
  return `Compra mínima: ${formatearCantidad(config.min, config.unidad)} ${config.unidad}. Hasta ${formatearCantidad(config.max, config.unidad)} ${config.unidad}; salto mínimo: ${formatearCantidad(config.paso, config.unidad)}.`
})
</script>

<template>
  <article class="pcard" :class="{ 'is-selected': selected, 'is-agotado': agotado }">
    <router-link :to="enlace" class="pcard__media">
      <img
        v-if="producto.imagenPrincipal"
        :src="producto.imagenPrincipal.url"
        :alt="producto.nombre"
        loading="lazy"
        @error="$event.target.src = placeholderImage(producto.id, producto.nombre)"
      />
      <div v-else class="pcard__placeholder" aria-hidden="true">
        <CtIcon name="leaf" :size="40" />
      </div>

      <div class="pcard__flags">
        <CtBadge v-if="agotado" tone="danger" size="sm" variant="solid">Agotado</CtBadge>
        <CtBadge v-else tone="success" size="sm">Disponible</CtBadge>
      </div>

      <label v-if="selectable" class="pcard__select" @click.prevent.stop>
        <input type="checkbox" :checked="selected" @change="emit('toggle', producto)" />
      </label>
    </router-link>

    <div class="pcard__body">
      <p v-if="showCategory" class="pcard__category">{{ nombreCategoria }}</p>

      <h3 class="pcard__title">
        <router-link :to="enlace" class="pcard__nombre">{{ producto.nombre }}</router-link>
      </h3>

      <p v-if="showProducer" class="pcard__producer">
        <CtIcon name="store" :size="13" />
        {{ producto.productor?.nombre_comercial || 'Productor CuTuCo' }}
        <span v-if="producto.comunaProductor" class="pcard__comuna">
          · {{ producto.comunaProductor.nombre }}
        </span>
      </p>

      <CtRatingStars
        v-if="showRating && Number(producto.productor?.cantidad_evaluaciones ?? 0) > 0"
        class="pcard__rating"
        :model-value="Number(producto.productor.puntaje_reputacion)"
        :size="13"
        show-value
      />

      <p v-if="producto.descripcion" class="pcard__description clamp-2">{{ producto.descripcion }}</p>

      <p v-if="reglaCompra" class="pcard__purchase-rule">{{ reglaCompra }}</p>

      <div class="pcard__footer">
        <div class="pcard__price">
          <span class="pcard__amount">{{ formatCLP(producto.precio) }}</span>
          <span class="pcard__unit">/ {{ unidad }}</span>
        </div>
        <CtRatingStars
          v-if="!showRating && producto.productor?.cantidad_evaluaciones"
          :model-value="Number(producto.productor.puntaje_reputacion)"
          :size="12"
        />
      </div>

      <div v-if="actionable" class="pcard__actions">
        <CtButton
          size="sm"
          variant="secondary"
          :to="enlace"
          class="pcard__detail"
        >
          Ver detalle
        </CtButton>
        <CtButton
          size="sm"
          :disabled="agotado"
          @click="emit('add', producto)"
        >
          <template #icon><CtIcon name="cart" :size="15" /></template>
          Agregar
        </CtButton>
      </div>
    </div>
  </article>
</template>

<style scoped>
.pcard__nombre {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
  color: var(--ct-text);
}

.pcard__nombre:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}
.pcard {
  display: flex;
  flex-direction: column;
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  overflow: hidden;
  box-shadow: var(--ct-shadow-xs);
  transition:
    box-shadow var(--ct-transition),
    transform var(--ct-transition),
    border-color var(--ct-transition);
  height: 100%;
}

.pcard:hover {
  box-shadow: var(--ct-shadow-md);
  transform: translateY(-2px);
  border-color: var(--ct-border-strong);
}

.pcard.is-selected {
  border-color: var(--ct-primary);
  box-shadow: 0 0 0 2px var(--ct-primary-soft);
}

.pcard.is-agotado .pcard__media img {
  filter: grayscale(0.6) opacity(0.7);
}

.pcard__media {
  position: relative;
  display: block;
  aspect-ratio: var(--ct-product-image-ratio);
  background: var(--ct-surface-alt);
  overflow: hidden;
}

.pcard__media img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform var(--ct-transition);
}

/* La foto hace zoom dentro de su marco al hover de la tarjeta. */
.pcard:hover .pcard__media img {
  transform: scale(1.03);
}

.pcard__placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  color: var(--ct-primary);
}

.pcard__flags {
  position: absolute;
  top: var(--ct-space-3);
  left: var(--ct-space-3);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--ct-space-1);
}

.pcard__select {
  position: absolute;
  top: var(--ct-space-3);
  right: var(--ct-space-3);
  width: 22px;
  height: 22px;
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface-translucent);
  display: grid;
  place-items: center;
  border: 1px solid var(--ct-border);
}

.pcard__body {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-4);
  flex: 1;
}

.pcard__category {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.pcard__title {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  line-height: 1.35;
}

.pcard__title a {
  color: var(--ct-text);
}

.pcard__title a:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.pcard__producer {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  display: flex;
  align-items: center;
  gap: 4px;
  flex-wrap: wrap;
}

.pcard__comuna {
  color: var(--ct-text-muted);
}

.pcard__description {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  line-height: 1.45;
}

.pcard__purchase-rule {
  padding: var(--ct-space-2) var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  font-size: var(--ct-fs-2xs);
  line-height: 1.4;
}

.pcard__rating {
  margin-top: 2px;
}

.pcard__footer {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--ct-space-2);
  margin-top: auto;
  padding-top: var(--ct-space-2);
}

.pcard__amount {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
  font-variant-numeric: tabular-nums;
}

.pcard__unit {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  margin-left: 2px;
}

.pcard__actions {
  display: flex;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-2);
}

.pcard__detail {
  flex: 1;
}
</style>
