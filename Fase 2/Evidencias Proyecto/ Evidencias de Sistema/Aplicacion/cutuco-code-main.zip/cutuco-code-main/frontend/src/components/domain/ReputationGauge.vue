<script setup>
/**
 * CuTuCo — Reputación del vendedor (RF-006).
 *
 * La reputación es el promedio simple de las calificaciones de 1 a 5 que dejan
 * los clientes: no hay ponderaciones, score 40/40/20 ni pausa automática, y
 * cualquier sanción la decide el administrador a mano (RF-026).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): los umbrales de pausa
 * automática (3.5) y de alerta (4.0) del score ponderado fueron reemplazados
 * por el semáforo de `reputationTone()` sobre el promedio real.
 */
import { computed } from 'vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import { formatNumber } from '@/lib/format'
import { reputationTone } from '@/lib/validation'

const props = defineProps({
  puntaje: { type: Number, default: 0 },
  cantidad: { type: Number, default: 0 },
  activo: { type: Boolean, default: true },
  showStars: { type: Boolean, default: true },
  size: { type: String, default: 'lg' }, // md | lg
})

const semaforo = computed(() => reputationTone(props.puntaje))
const sinEvaluaciones = computed(() => Number(props.cantidad) <= 0)
</script>

<template>
  <CtCard padding="md" class="rep">
    <div class="rep__main">
      <div class="rep__score" :class="`is-${semaforo.color}`">
        <span class="rep__value">{{ formatNumber(puntaje, 2) }}</span>
        <span class="rep__max">/ 5.0</span>
      </div>
      <div class="rep__meta">
        <CtBadge :tone="semaforo.tone" dot>{{ semaforo.label }}</CtBadge>
        <CtRatingStars v-if="showStars" :model-value="Number(puntaje)" :size="15" />
        <p class="rep__count">
          {{ cantidad }} {{ cantidad === 1 ? 'evaluación' : 'evaluaciones' }} de clientes
        </p>
      </div>
    </div>

    <CtProgressBar :value="Number(puntaje)" :max="5" :tone="semaforo.tone" />

    <p v-if="sinEvaluaciones" class="rep__alert is-neutral">
      <CtIcon name="info" :size="15" /> Todavía no tienes calificaciones. Tus clientes podrán
      calificarte de 1 a 5 cuando confirmen la entrega de su pedido.
    </p>
    <p v-else-if="semaforo.tone === 'danger'" class="rep__alert is-danger">
      <CtIcon name="alert" :size="15" /> Tu promedio está bajo. Mejora la preparación y la entrega de
      tus pedidos: si un administrador lo considera necesario, puede aplicar una sanción.
    </p>
    <p v-else-if="semaforo.tone === 'warning'" class="rep__alert is-warning">
      <CtIcon name="alert" :size="15" /> Tu promedio está en zona regular. Revisa los comentarios de
      tus clientes para mejorarlo.
    </p>
    <p v-else class="rep__alert is-success">
      <CtIcon name="check" :size="15" /> Reputación saludable: tus clientes valoran positivamente tus
      entregas. No existe pausa automática, pero mantén el estándar.
    </p>
  </CtCard>
</template>

<style scoped>
.rep {
  gap: var(--ct-space-4);
}

.rep__main {
  display: flex;
  align-items: center;
  gap: var(--ct-space-5);
}

.rep__score {
  display: flex;
  align-items: baseline;
  gap: 2px;
}

.rep__value {
  font-size: var(--ct-fs-4xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: 1;
  font-variant-numeric: tabular-nums;
}

.rep--lg .rep__value {
  font-size: 3rem;
}

.rep__max {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-muted);
}

.rep__score.is-green .rep__value {
  color: var(--ct-success);
}
.rep__score.is-blue .rep__value {
  color: var(--ct-primary-strong);
}
.rep__score.is-amber .rep__value {
  color: var(--ct-warning-strong);
}
.rep__score.is-red .rep__value {
  color: var(--ct-danger);
}
.rep__score.is-gray .rep__value {
  color: var(--ct-text-muted);
}

.rep__meta {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
}

.rep__count {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.rep__alert {
  font-size: var(--ct-fs-sm);
  border-radius: var(--ct-radius-md);
  padding: var(--ct-space-3);
  line-height: 1.5;
}

.rep__alert.is-danger {
  background: var(--ct-danger-soft);
  color: var(--ct-danger-ink);
}
.rep__alert.is-warning {
  background: var(--ct-warning-soft);
  color: var(--ct-warning-ink);
}
.rep__alert.is-success {
  background: var(--ct-success-soft);
  color: var(--ct-success-ink);
}
.rep__alert.is-neutral {
  background: var(--ct-surface-alt);
  color: var(--ct-text-soft);
}
</style>
