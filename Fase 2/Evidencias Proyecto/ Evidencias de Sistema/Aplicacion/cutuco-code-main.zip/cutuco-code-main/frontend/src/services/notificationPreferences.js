/**
 * Preferencias de notificación por cuenta.
 *
 * La tabla está protegida por RLS: una sesión sólo puede leer y modificar su
 * propia fila. Los valores por defecto conservan los avisos activos para las
 * cuentas creadas antes de esta funcionalidad.
 */
import { getClient } from '@/lib/supabase'
import { mensajeSeguro } from '@/services/errores'
import { currentUserId } from '@/services/session'

export const PREFERENCIAS_NOTIFICACION_PREDETERMINADAS = Object.freeze({
  email: true,
  inApp: true,
})

export function normalizarPreferenciasNotificacion(preferencias) {
  // `maybeSingle()` devuelve `data: null` cuando la cuenta todavía no tiene
  // una fila. Tratarlo igual que un objeto vacío mantiene los dos canales
  // activados para cuentas existentes y recién creadas.
  const origen = preferencias ?? {}
  return {
    email: origen.recibir_correo ?? origen.email ?? true,
    inApp: origen.recibir_en_plataforma ?? origen.inApp ?? true,
  }
}

export async function obtenerPreferenciasNotificacion({ perfilId = null } = {}) {
  const id = perfilId ?? (await currentUserId())
  if (!id) return { ...PREFERENCIAS_NOTIFICACION_PREDETERMINADAS }

  const { data, error } = await getClient()
    .from('preferencias_notificacion')
    .select('recibir_correo, recibir_en_plataforma')
    .eq('perfil_id', id)
    .maybeSingle()

  if (error) {
    throw new Error(mensajeSeguro(error, 'No se pudieron cargar tus preferencias de notificación'))
  }
  return normalizarPreferenciasNotificacion(data)
}

export async function guardarPreferenciasNotificacion(preferencias) {
  const perfilId = await currentUserId()
  if (!perfilId) throw new Error('Inicia sesión para guardar tus preferencias de notificación')

  const normalizadas = normalizarPreferenciasNotificacion(preferencias)
  const { data, error } = await getClient()
    .from('preferencias_notificacion')
    .upsert(
      {
        perfil_id: perfilId,
        recibir_correo: normalizadas.email,
        recibir_en_plataforma: normalizadas.inApp,
      },
      { onConflict: 'perfil_id' },
    )
    .select('recibir_correo, recibir_en_plataforma')
    .single()

  if (error) {
    throw new Error(mensajeSeguro(error, 'No se pudieron guardar tus preferencias de notificación'))
  }
  return normalizarPreferenciasNotificacion(data)
}
