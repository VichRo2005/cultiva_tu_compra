/**
 * CuTuCo — Servicio del módulo Administrador.
 *
 *   RF-004  usuarios, productos, aprobación de vendedores y moderación
 *   RF-011  dashboard reducido a pendientes (aprobaciones, sanciones y pagos)
 *   RF-026  sanciones manuales: amonestación, suspensión y ban permanente
 *   RF-017  eliminación lógica
 *
 * Todos los accesos están protegidos por las políticas RLS del esquema: sólo
 * el rol `admin` puede leer y escribir estas tablas.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Se retiraron los reportes de ventas por región, ticket promedio, KPIs de
 *   comercio, CRUD de regiones/comunas y la moderación automática con score.
 *   RF-011 quedó reducido a los tres pendientes del administrador y RF-018
 *   consulta categorías, regiones y comunas sólo para los combobox.
 */

import { mensajeSeguro } from '@/services/errores'
import { apiFetch, getClient, storageUrl } from '@/lib/supabase'
import { netoProductor } from '@/lib/orders'
import {
  ESTADO_PEDIDO,
  ESTADO_POSTULACION,
  ESTADO_SANCION,
  POSTULACIONES_PENDIENTES,
  ROL_USUARIO,
  STORAGE_BUCKETS,
} from '@/lib/constants'
import { currentUserId, unwrap } from '@/services/session'

import { listSanciones, hidratarSanciones } from '@/services/adminSanciones'
export {
  listSanciones,
  crearSancion,
  contarAmonestaciones,
  resolverSancion,
} from '@/services/adminSanciones'
export { listApelaciones, resolverApelacion } from '@/services/adminApelaciones'
export {
  listPalabrasProhibidas,
  crearPalabraProhibida,
  actualizarPalabraProhibida,
  revisarTexto,
  listCoincidenciasModeradas,
} from '@/services/adminModeracion'

const round2 = (n) => Math.round(n * 100) / 100

/* ---------------------------------------------------------------- */
/* Dashboard: pendientes (RF-011)                                      */
/* ---------------------------------------------------------------- */

/**
 * Pendientes del administrador: postulaciones de vendedor por resolver y
 * sanciones vigentes. Si no hay pendientes devuelve ceros y listas vacías para
 * que la interfaz muestre un estado vacío explícito.
 *
 * NOTA DE MIGRACIÓN (Webpay Mall): se eliminaron la tabla `payouts`, la columna
 * `pagos.estado` y `pedidos.monto_liquidar_productor`. La custodia ya no se
 * reporta aquí; los cobros autorizados los lee la vista con `listPagos()`.
 * Los errores de consulta se propagan para no presentar una ausencia de datos
 * como cero pendientes o cero ventas.
 */
async function consultaTolerante(consulta) {
  const { data, error } = await consulta
  if (error) throw new Error('No se pudo consultar la operación. Inténtalo de nuevo.')
  return data ?? []
}

export async function getPendientesAdmin() {
  const client = getClient()
  const [postulacionesRes, sancionesRes, pedidos] = await Promise.all([
    client
      .from('postulaciones_vendedores')
      .select('*')
      .in('estado', POSTULACIONES_PENDIENTES)
      .order('creado_en', { ascending: true }),
    client
      .from('sanciones')
      .select('*')
      .in('estado', [ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA])
      .order('inicio_en', { ascending: false }),
    consultaTolerante(client.from('pedidos').select('estado, total, monto_fee_plataforma')),
  ])

  if (postulacionesRes.error || sancionesRes.error) {
    throw new Error('No se pudieron cargar los pendientes administrativos. Inténtalo de nuevo.')
  }
  const postulaciones = await hidratarPostulaciones(postulacionesRes.data ?? [])
  const sanciones = await hidratarSanciones(sancionesRes.data ?? [])

  const sumar = (rows, campo) => round2(rows.reduce((acc, r) => acc + Number(r[campo] ?? 0), 0))
  const vigentes = pedidos.filter((p) => p.estado !== ESTADO_PEDIDO.CANCELADO)
  const entregados = pedidos.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO)

  return {
    pendientes: {
      productores: postulaciones.length,
      sanciones: sanciones.length,
    },
    postulaciones,
    sanciones,
    operacion: {
      pedidos: pedidos.length,
      entregados: entregados.length,
      enCurso: pedidos.filter((p) =>
        [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(p.estado),
      ).length,
      comisiones: sumar(vigentes, 'monto_fee_plataforma'),
      liquidable: sumar(entregados, 'total'),
      ventas: sumar(vigentes, 'total'),
    },
  }
}

/* ---------------------------------------------------------------- */
/* Usuarios (RF-004 y RF-017)                                          */
/* ---------------------------------------------------------------- */

// Sección original de usuarios deshabilitada: usar services/adminUsuarios.js.
// export async function listUsuarios({ rol = null, texto = '', activo = null } = {}) {
//   const client = getClient()
//   let query = client.from('perfiles').select('*')
//   if (rol) query = query.eq('rol', rol)
//   if (activo !== null) query = query.eq('activo', activo)
//   if (texto.trim()) {
//     const term = texto.trim()
//     query = query.or(`nombre.ilike.%${term}%,apellido.ilike.%${term}%`)
//   }
//   const { data, error } = await query.order('creado_en', { ascending: false })
//   if (error) throw new Error(mensajeSeguro(error))
//
//   const perfiles = data ?? []
//   if (!perfiles.length) return []
//
//   const { data: productores } = await client
//     .from('productores')
//     .select('*')
//     .in(
//       'perfil_id',
//       perfiles.map((p) => p.id),
//     )
//   const productorMap = new Map((productores ?? []).map((p) => [p.perfil_id, p]))
//
//   return perfiles.map((perfil) => ({
//     ...perfil,
//     productor: productorMap.get(perfil.id) ?? null,
//     bloqueado: Boolean(perfil.bloqueado_hasta && new Date(perfil.bloqueado_hasta) > new Date()),
//   }))
// }
//
// export async function getUsuario(perfilId) {
//   const client = getClient()
//   const { data, error } = await client.from('perfiles').select('*').eq('id', perfilId).maybeSingle()
//   if (error || !data) return null
//   const { data: productor } = await client.from('productores').select('*').eq('perfil_id', perfilId).maybeSingle()
//   return { ...data, productor: productor ?? null }
// }
//
// /**
//  * Actualiza un perfil.
//  * Restricciones del esquema: el Administrador Base protegido no puede
//  * modificarse, y los controles de autenticación (intentos, bloqueo) sólo se
//  * cambian desde el backend.
//  */
// export async function actualizarUsuario(perfilId, patch) {
//   const client = getClient()
//   const permitido = { ...patch }
//   delete permitido.intentos_login_fallidos
//   delete permitido.bloqueado_hasta
//   delete permitido.ultimo_acceso_en
//   return unwrap(
//     await client.from('perfiles').update(permitido).eq('id', perfilId).select().single(),
//     'No se pudo actualizar el usuario',
//   )
// }
//
// /** Baja lógica del usuario (RF-017). No se elimina la fila. */
// export async function desactivarUsuario(perfilId) {
//   const cliente = await getUsuario(perfilId)
//   if (!cliente) throw new Error('Usuario inexistente')
//   if (cliente.es_protegido || cliente.es_super_admin) {
//     throw new Error('El Administrador Base protegido no puede desactivarse')
//   }
//   const actual = await currentUserId()
//   if (actual === perfilId) throw new Error('No puedes desactivar tu propia cuenta')
//   return actualizarUsuario(perfilId, { activo: false })
// }
//
// export async function reactivarUsuario(perfilId) {
//   return actualizarUsuario(perfilId, { activo: true })
// }
//
//
/* ---------------------------------------------------------------- */
/* Productos (RF-004 y RF-017)                                         */
/* ---------------------------------------------------------------- */

export async function listProductosAdmin({ texto = '', productorId = null, activo = null } = {}) {
  const client = getClient()
  let query = client.from('productos').select('*')
  if (texto.trim()) query = query.ilike('nombre', `%${texto.trim()}%`)
  if (productorId) query = query.eq('productor_id', productorId)
  if (activo !== null) query = query.eq('activo', activo)
  const { data, error } = await query.order('actualizado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const productos = data ?? []
  const [productoresRes, categoriasRes, imagenesRes] = await Promise.all([
    client.from('productores').select('id, nombre_comercial, activo'),
    client.from('categorias').select('id, nombre'),
    productos.length
      ? client
          .from('imagenes_productos')
          .select('*')
          .in(
            'producto_id',
            productos.map((p) => p.id),
          )
          .order('posicion', { ascending: true })
      : Promise.resolve({ data: [] }),
  ])

  const productorMap = new Map((productoresRes.data ?? []).map((p) => [p.id, p]))
  const categoriaMap = new Map((categoriasRes.data ?? []).map((c) => [c.id, c]))
  const galeriaMap = new Map()
  for (const img of imagenesRes.data ?? []) {
    if (!galeriaMap.has(img.producto_id)) galeriaMap.set(img.producto_id, [])
    galeriaMap
      .get(img.producto_id)
      .push({ ...img, url: storageUrl(img.ruta_storage, { bucket: STORAGE_BUCKETS.productos }) })
  }

  return productos.map((p) => {
    const galeria = galeriaMap.get(p.id) ?? []
    return {
      ...p,
      productor: productorMap.get(p.productor_id) ?? null,
      categoria: categoriaMap.get(p.categoria_id) ?? null,
      imagenes: galeria,
      imagenPrincipal: galeria.find((i) => i.es_principal) ?? galeria[0] ?? null,
    }
  })
}

/** Baja lógica de un producto desde el panel (RF-017). */
export async function desactivarProductoAdmin(productoId) {
  const client = getClient()
  return unwrap(
    await client.from('productos').update({ activo: false }).eq('id', productoId).select().single(),
    'No se pudo desactivar el producto',
  )
}

export async function reactivarProductoAdmin(productoId) {
  const client = getClient()
  return unwrap(
    await client
      .from('productos')
      .update({ activo: true, eliminado_en: null })
      .eq('id', productoId)
      .select()
      .single(),
    'No se pudo reactivar el producto',
  )
}

/* ---------------------------------------------------------------- */
/* Aprobación de vendedores (RF-004 y RF-021)                          */
/* ---------------------------------------------------------------- */

export async function listPostulaciones({ estado = null, texto = '' } = {}) {
  const client = getClient()
  let query = client.from('postulaciones_vendedores').select('*')
  if (estado) query = query.eq('estado', estado)
  if (texto.trim()) query = query.ilike('nombre_comercial_solicitado', `%${texto.trim()}%`)
  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  return hidratarPostulaciones(data ?? [])
}

/**
 * Datos bancarios del solicitante, ENMASCARADOS, consultados a FastAPI
 * (`GET /datos-bancarios/admin/{perfil_id}`, JWT admin; responde una lista).
 * La migración 20261007004557 revocó el acceso PostgREST a `datos_bancarios`,
 * así que el navegador nunca consulta la tabla directamente. La API sólo
 * responde a administradores autenticados y permite revisar la cuenta completa
 * de una postulación antes de aprobarla.
 */
/**
 * C1/C2 — Descarga segura de un documento de la postulación: el bucket es
 * privado, así que el administrador recibe una URL FIRMADA de 60 segundos;
 * jamás se construye una URL pública ni se expone el objeto completo.
 */
export async function urlFirmadaDocumentoPostulacion(ruta) {
  if (!ruta) throw new Error('Ese documento no fue subido por el solicitante.')
  const [bucket, ...resto] = String(ruta).split('/')
  const objeto = resto.join('/')
  const client = getClient()
  const { data, error } = await client.storage.from(bucket).createSignedUrl(objeto, 60)
  if (error || !data?.signedUrl) {
    throw new Error('No se pudo recuperar el documento: inténtalo de nuevo en unos segundos.')
  }
  return data.signedUrl
}

async function getDatosBancariosAdmin(perfilId) {
  try {
    const lista = await apiFetch(`/datos-bancarios/admin/${perfilId}`)
    const datos = (Array.isArray(lista) ? lista : [lista]).find((d) => d?.activo) ?? null
    if (!datos) return { datos: null, error: null }
    return {
      datos: {
        banco: datos.banco ?? null,
        tipo_cuenta: datos.tipo_cuenta ?? null,
        titular: datos.titular ?? datos.titular_cuenta ?? null,
        rut_titular: datos.rut_titular ?? null,
        numeroCuenta: datos.numero_cuenta ?? null,
      },
      error: null,
    }
  } catch (e) {
    // Un fallo del servicio NO equivale a "sin datos bancarios": el
    // administrador debe saber que no pudo verificar el requisito de payout.
    return {
      datos: null,
      error: e?.message ?? 'No se pudieron consultar los datos bancarios del solicitante',
    }
  }
}

async function hidratarPostulaciones(postulaciones) {
  if (!postulaciones.length) return []
  const client = getClient()
  const perfilIds = postulaciones.map((p) => p.perfil_id)
  const [perfilesRes, direccionesRes, bancosPares, comunasRes, regionesRes] = await Promise.all([
    client.from('perfiles').select('*').in('id', perfilIds),
    client.from('direcciones').select('*').in('perfil_id', perfilIds).eq('activo', true),
    Promise.all([...new Set(perfilIds)].map(async (id) => [id, await getDatosBancariosAdmin(id)])),
    client.from('comunas').select('*'),
    client.from('regiones').select('*'),
  ])
  const perfiles = perfilesRes.data ?? []
  const direcciones = direccionesRes.data ?? []
  const comunas = comunasRes.data ?? []
  const regiones = regionesRes.data ?? []

  const perfilMap = new Map((perfiles ?? []).map((p) => [p.id, p]))
  const bancoMap = new Map()
  const bancoErrorMap = new Map()
  for (const [perfilId, resultado] of bancosPares) {
    if (resultado?.datos) bancoMap.set(perfilId, resultado.datos)
    if (resultado?.error) bancoErrorMap.set(perfilId, resultado.error)
  }
  const comunaMap = new Map((comunas ?? []).map((c) => [c.id, c]))
  const regionMap = new Map((regiones ?? []).map((r) => [r.id, r]))

  return postulaciones.map((post) => {
    const direccion = direcciones.find((d) => d.perfil_id === post.perfil_id) ?? null
    const comuna = direccion ? (comunaMap.get(direccion.comuna_id) ?? null) : null
    return {
      ...post,
      perfil: perfilMap.get(post.perfil_id) ?? null,
      direccion,
      comuna,
      region: comuna ? (regionMap.get(comuna.region_id) ?? null) : null,
      datosBancarios: bancoMap.get(post.perfil_id) ?? null,
      datosBancariosError: bancoErrorMap.get(post.perfil_id) ?? null,
    }
  })
}

/** §6.3: límites de observaciones_admin (el campo es varchar(2500)). */
export const MIN_OBSERVACIONES = 10
export const MAX_OBSERVACIONES = 2500

/**
 * Mensajes del esquema (triggers/RPC) convertidos a algo accionable para el
 * administrador.
 */
function traducirErrorPostulacion(mensaje) {
  const texto = String(mensaje ?? '')
  if (texto.includes('TRANSBANK_MALL_SELLER_COMMERCE_CODE')) {
    return 'La aprobación automática de Webpay Mall no está configurada. Contacta al equipo técnico.'
  }
  if (texto.includes('Se alcanzo el maximo de 3 postulaciones')) {
    return 'El solicitante alcanzó el máximo de 3 postulaciones permitidas. Ya no puede reenviar la solicitud.'
  }
  if (texto.includes('exactamente una direccion activa')) {
    return 'La cuenta del vendedor debe tener exactamente una dirección activa antes de ser aprobada.'
  }
  return mensajeSeguro(texto, 'No se pudo resolver la postulación')
}

/**
 * Aprueba o rechaza una postulación mediante FastAPI. El backend autentica al
 * administrador y, al aprobar, toma el comercio hijo Mall de su entorno
 * privado antes de invocar la RPC canónica. El navegador nunca envía ni decide
 * el código de Transbank.
 *
 * Compatibilidad: también acepta `{ aprobar: boolean }` en lugar de `estado`.
 */
export async function revisarPostulacion({
  postulacionId,
  estado = null,
  aprobar = null,
  observaciones = null,
}) {
  const esAprobacion = aprobar !== null ? Boolean(aprobar) : estado === ESTADO_POSTULACION.APROBADA
  const estadoFinal = esAprobacion ? ESTADO_POSTULACION.APROBADA : ESTADO_POSTULACION.RECHAZADA
  const obs = observaciones?.trim() ? observaciones.trim() : null

  // Las observaciones son opcionales. Si están vacías el correo de decisión
  // muestra el mensaje automático correspondiente; si se escriben, el rango
  // se aplica en frontend, backend y la RPC.
  if (obs && (obs.length < MIN_OBSERVACIONES || obs.length > MAX_OBSERVACIONES)) {
    throw new Error(
      `Las observaciones deben tener entre ${MIN_OBSERVACIONES} y ${MAX_OBSERVACIONES} caracteres.`,
    )
  }

  try {
    return await apiFetch(`/api/admin/postulaciones/${encodeURIComponent(postulacionId)}/resolver`, {
      method: 'POST',
      body: { estado: estadoFinal, observaciones: obs },
    })
  } catch (error) {
    const texto = String(error?.message ?? '')
    if (texto.includes('No existe una postulacion en revision con ese ID')) {
      throw new Error(mensajePostulacionFueraDeRevision(), { cause: error })
    }
    throw new Error(traducirErrorPostulacion(texto), { cause: error })
  }
}

/**
 * D2 — Mensaje accionable cuando la revisión corresponde a una postulación que
 * ya no está en revisión (lista desactualizada o decisión tomada en otra
 * sesión). El control de integridad del backend se conserva: se traduce.
 */
function mensajePostulacionFueraDeRevision() {
  return (
    'Esta postulación ya no está en revisión: otro administrador la resolvió o la lista está ' +
    'desactualizada. Pulsa "Actualizar" para recargar el estado real.'
  )
}

/**
 * D4 — Historial íntegro de revisiones de una postulación (postulaciones_
 * revisiones, RLS: administrador o solicitante). Cada decisión queda archivada
 * con intento, estado, observaciones y snapshot JSONB de la solicitud.
 */
export async function listarRevisionesPostulacion(postulacionId) {
  if (!postulacionId) return []
  const client = getClient()
  const { data, error } = await client
    .from('postulaciones_revisiones')
    .select('id, postulacion_id, intento, estado, observaciones_admin, revisado_en, solicitud')
    .eq('postulacion_id', postulacionId)
    .order('intento', { ascending: true })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/**
 * F — Reinicio administrativo del límite de 3 postulaciones: otorga un bloque
 * extra de 3 intentos a una postulación RECHAZADA y registra quién, cuándo y
 * con qué motivo (postulaciones_reinicio_intentos). La RPC es la única vía:
 * el solicitante no puede tocar el contador.
 */
export const MIN_MOTIVO_REINICIO = 10

export async function reiniciarIntentosPostulacion(postulacionId, motivo) {
  const texto = String(motivo ?? '').trim()
  if (texto.length < MIN_MOTIVO_REINICIO) {
    throw new Error(`El reinicio requiere un motivo de al menos ${MIN_MOTIVO_REINICIO} caracteres.`)
  }
  const client = getClient()
  const { data, error } = await client.rpc('reiniciar_intentos_postulacion', {
    p_postulacion_id: postulacionId,
    p_motivo: texto,
  })
  if (error) {
    if (String(error.message ?? '').includes('no está disponible en modo demo')) {
      throw new Error('El reinicio de intentos requiere la base de datos real (no está en modo demo).')
    }
    if (String(error.message ?? '').includes('Solo se puede reiniciar una postulacion rechazada')) {
      throw new Error('Sólo se puede reiniciar el límite de una postulación rechazada.')
    }
    throw new Error(mensajeSeguro(error))
  }
  return data
}

/* ---------------------------------------------------------------- */
/* Moderación con palabras prohibidas (RF-004)                         */
/* ---------------------------------------------------------------- */

// @deprecated - movido a adminSanciones.js - ya no se usa por nuevo consumo
// Moderacion y apelaciones se trasladan a adminModeracion.js y adminApelaciones.js.
// export async function listPalabrasProhibidas({ soloActivas = false } = {}) {
//   const client = getClient()
//   let query = client.from('palabras_prohibidas').select('*')
//   if (soloActivas) query = query.eq('activo', true)
//   const { data, error } = await query.order('palabra', { ascending: true })
//   if (error) throw new Error(mensajeSeguro(error))
//   return data ?? []
// }
//
// export async function crearPalabraProhibida(palabra) {
//   const client = getClient()
//   return unwrap(
//     await client
//       .from('palabras_prohibidas')
//       .insert({ palabra: palabra.trim(), activo: true })
//       .select()
//       .single(),
//     'No se pudo agregar la palabra',
//   )
// }
//
// export async function actualizarPalabraProhibida(id, patch) {
//   const client = getClient()
//   return unwrap(
//     await client.from('palabras_prohibidas').update(patch).eq('id', id).select().single(),
//     'No se pudo actualizar la palabra',
//   )
// }
//
// /**
//  * Revisa un texto contra la blacklist usando la función del esquema, que aplica
//  * el operador LIKE case-insensitive (RF-004).
//  */
// export async function revisarTexto(texto) {
//   const client = getClient()
//   const { data, error } = await client.rpc('contiene_palabra_prohibida', { p_texto: texto })
//   if (error) throw new Error(mensajeSeguro(error))
//   return Boolean(data)
// }
//
// /**
//  * Productos cuyo nombre o descripción contiene una palabra prohibida.
//  * La comparación se hace en el cliente con la lista activa porque PostgREST no
//  * expone el operador LIKE sobre un array de términos.
//  */
// export async function listCoincidenciasModeradas() {
//   const client = getClient()
//   const [palabras, productosRes] = await Promise.all([
//     listPalabrasProhibidas({ soloActivas: true }),
//     client.from('productos').select('id, nombre, descripcion, activo, productor_id'),
//   ])
//   const { data: productores } = await client.from('productores').select('id, nombre_comercial')
//   const productorMap = new Map((productores ?? []).map((p) => [p.id, p]))
//   const terminos = (palabras ?? []).map((p) => p.palabra.toLowerCase())
//
//   const coincidencias = []
//   for (const producto of productosRes.data ?? []) {
//     const texto = `${producto.nombre ?? ''} ${producto.descripcion ?? ''}`.toLowerCase()
//     const encontradas = terminos.filter((t) => texto.includes(t))
//     if (encontradas.length) {
//       coincidencias.push({
//         ...producto,
//         productor: productorMap.get(producto.productor_id) ?? null,
//         palabras: encontradas,
//       })
//     }
//   }
//   return { palabras: palabras ?? [], coincidencias }
// }
//
// /* ---------------------------------------------------------------- */
// /* Sanciones (RF-026)                                                  */
// /* ---------------------------------------------------------------- */
//
// export async function listSanciones({ estado = null, productorId = null } = {}) {
//   const client = getClient()
//   let query = client.from('sanciones').select('*')
//   if (estado) query = query.eq('estado', estado)
//   if (productorId) query = query.eq('productor_id', productorId)
//   const { data, error } = await query.order('inicio_en', { ascending: false })
//   if (error) throw new Error(mensajeSeguro(error))
//   return hidratarSanciones(data ?? [])
// }
//
// async function hidratarSanciones(sanciones) {
//   if (!sanciones.length) return []
//   const client = getClient()
//   const ids = [...new Set(sanciones.map((s) => s.productor_id))]
//   const { data: productores } = await client.from('productores').select('*').in('id', ids)
//   const perfilIds = (productores ?? []).map((p) => p.perfil_id)
//   const { data: perfiles } = perfilIds.length
//     ? await client.from('perfiles').select('id, nombre, apellido').in('id', perfilIds)
//     : { data: [] }
//   const { data: apelaciones } = await client.from('apelaciones').select('*').in('productor_id', ids)
//
//   const productorMap = new Map((productores ?? []).map((p) => [p.id, p]))
//   const perfilMap = new Map((perfiles ?? []).map((p) => [p.id, p]))
//
//   return sanciones.map((sancion) => {
//     const productor = productorMap.get(sancion.productor_id) ?? null
//     return {
//       ...sancion,
//       productor,
//       perfil: productor ? perfilMap.get(productor.perfil_id) ?? null : null,
//       apelacion: (apelaciones ?? []).find((a) => a.sancion_id === sancion.id) ?? null,
//     }
//   })
// }
//
// /** Conteo de amonestaciones vigentes del vendedor (RF-026). */
// export async function contarAmonestaciones(productorId) {
//   const client = getClient()
//   const { data } = await client
//     .from('sanciones')
//     .select('id, numero_amonestacion')
//     .eq('productor_id', productorId)
//     .eq('tipo', TIPO_SANCION.AMONESTACION)
//     .in('estado', [ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA])
//   const numeros = (data ?? []).map((s) => Number(s.numero_amonestacion ?? 0)).filter(Boolean)
//   return {
//     total: (data ?? []).length,
//     ultimoNumero: numeros.length ? Math.max(...numeros) : 0,
//   }
// }
//
// /**
//  * Registra una sanción manual (RF-026).
//  *  - amonestación: número correlativo y duración opcional en días
//  *  - suspensión: duración obligatoria en días
//  *  - ban permanente: suspensión sin fecha de término
//  * El trigger `aplicar_efecto_sancion` desactiva la cuenta del vendedor cuando
//  * corresponde.
//  */
// export async function crearSancion({ productorId, tipo, accion, motivo, duracionDias = null }) {
//   const client = getClient()
//   const adminId = await currentUserId()
//
//   if (!motivo?.trim()) throw new Error('La sanción requiere un motivo')
//
//   const payload = {
//     productor_id: productorId,
//     tipo,
//     accion,
//     estado: ESTADO_SANCION.ACTIVA,
//     motivo: motivo.trim(),
//     duracion_dias: duracionDias ? Number(duracionDias) : null,
//     impuesta_por: adminId,
//     numero_amonestacion: null,
//   }
//
//   if (tipo === TIPO_SANCION.AMONESTACION) {
//     const { ultimoNumero } = await contarAmonestaciones(productorId)
//     payload.numero_amonestacion = ultimoNumero + 1
//     payload.accion = ACCION_SANCION.NINGUNA
//     payload.duracion_dias = null
//   }
//
//   if (tipo === TIPO_SANCION.SUSPENSION) {
//     if (accion === ACCION_SANCION.SUSPENDER && !payload.duracion_dias) {
//       throw new Error('La suspensión necesita una duración en días')
//     }
//     if (accion === ACCION_SANCION.BAN_PERMANENTE) payload.duracion_dias = null
//   }
//
//   return unwrap(
//     await client.from('sanciones').insert(payload).select().single(),
//     'No se pudo registrar la sanción',
//   )
// }
//
// /** Cierra, cancela o expira una sanción. */
// export async function resolverSancion(sancionId, estado = ESTADO_SANCION.RESUELTA) {
//   const client = getClient()
//   return unwrap(
//     await client
//       .from('sanciones')
//       .update({ estado, resuelta_en: new Date().toISOString() })
//       .eq('id', sancionId)
//       .select()
//       .single(),
//     'No se pudo actualizar la sanción',
//   )
// }
//
// /** Apelaciones del vendedor: revisión manual del administrador (RF-026). */
// export async function listApelaciones({ estado = null } = {}) {
//   const client = getClient()
//   let query = client.from('apelaciones').select('*')
//   if (estado) query = query.eq('estado', estado)
//   const { data, error } = await query.order('creado_en', { ascending: false })
//   if (error) throw new Error(mensajeSeguro(error))
//   if (!data?.length) return []
//
//   const ids = [...new Set(data.map((a) => a.productor_id))]
//   const { data: productores } = await client.from('productores').select('*').in('id', ids)
//   const map = new Map((productores ?? []).map((p) => [p.id, p]))
//   return data.map((a) => ({ ...a, productor: map.get(a.productor_id) ?? null }))
// }
//
// export async function resolverApelacion(apelacionId, estado, resolucion) {
//   const client = getClient()
//   const adminId = await currentUserId()
//   return unwrap(
//     await client
//       .from('apelaciones')
//       .update({
//         estado,
//         resolucion: resolucion?.trim() ? resolucion.trim() : null,
//         resuelto_por: adminId,
//         resuelto_en: new Date().toISOString(),
//       })
//       .eq('id', apelacionId)
//       .select()
//       .single(),
//     'No se pudo resolver la apelación',
//   )
// }
//
//
/* ---------------------------------------------------------------- */
/* Pagos: payouts y reembolsos — ELIMINADO con Webpay Mall              */
/*
 * La migración 20261010010000_webpay_mall_postulaciones.sql eliminó la tabla
 * `payouts` y las RPC `registrar_payout_pagado` / `registrar_devolucion_cliente`;
 * Webpay Mall liquida directamente a cada comercio hijo. Las funciones
 * `listPayouts`, `aprobarPayout` y `registrarReembolso` se retiraron porque
 * llamaban a esos objetos inexistentes (rompían en runtime).
 * `AdminPaymentsView` (en manos de otro agente) debe dejar de importarlas y
 * usar el flujo Webpay Mall de `services/payments.js`.
 * ---------------------------------------------------------------- */

/** Tarifa de delivery vigente del MVP (RF-014), configurable por el administrador. */
export async function getConfiguracionLogistica() {
  const client = getClient()
  const { data } = await client
    .from('configuracion_logistica')
    .select('*')
    .eq('id', 1)
    .maybeSingle()
  return data ?? { id: 1, tarifa_delivery_defecto: 3500 }
}

export async function actualizarTarifaDelivery(tarifa) {
  const client = getClient()
  return unwrap(
    await client
      .from('configuracion_logistica')
      .update({ tarifa_delivery_defecto: Number(tarifa) })
      .eq('id', 1)
      .select()
      .single(),
    'No se pudo actualizar la tarifa de delivery',
  )
}

/* ==================================================================
 * SERVICIOS HEREDADOS — SÓLO GALERÍA DE DESARROLLO
 * ==================================================================
 * NOTA DE MIGRACIÓN (alcance anterior, ya se usa sólo en las ventanas que la
 * galería de desarrollo sigue mostrando):
 *   `getDashboardAdmin` y `getReporte` alimentaban el panel analítico con KPIs
 *   de comercio, ventas por región y ticket promedio, y `listReclamos` la
 *   ventana de reclamos. RF-011 v2.0 redujo el dashboard del administrador a
 *   los tres pendientes (aprobaciones, sanciones y pagos) y los reclamos no
 *   forman parte del alcance vigente.
 *
 *   La implementación se mantiene viva sobre el esquema ACTUAL (no hay datos
 *   simulados): agrega pedidos, pagos y payouts reales de Supabase.
 * ================================================================ */

const round2Galeria = (n) => Math.round(Number(n ?? 0) * 100) / 100

/** Tipos de reporte del panel analítico heredado. */
export const TIPOS_REPORTE = Object.freeze([
  { key: 'ventas', label: 'Ventas por región y comuna' },
  { key: 'comisiones', label: 'Comisiones retenidas' },
  { key: 'productores', label: 'Ranking de productores' },
  { key: 'sanciones', label: 'Productores sancionados' },
  { key: 'operaciones', label: 'Operaciones y estados de pedido' },
  { key: 'usuarios', label: 'Usuarios por rol' },
])

function diaClave(valor) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(new Date(valor))
}

function mesClave(valor) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Santiago',
    year: 'numeric',
    month: '2-digit',
  }).format(new Date(valor))
}

/**
 * Panel analítico del administrador (versión anterior de RF-011).
 * Reutiliza `perfiles`, `productores`, `pedidos`, `pagos` y `payouts` reales.
 */
export async function getDashboardAdmin({ desde, hasta } = {}) {
  const client = getClient()
  const fin = hasta ? new Date(`${hasta}T23:59:59`) : new Date()
  const inicio = desde ? new Date(`${desde}T00:00:00`) : new Date(Date.now() - 89 * 86400000)
  const rango = { desde: inicio.toISOString(), hasta: fin.toISOString() }

  const [pedidosRes, pagosRes, productoresRes, regionesRes, usuariosRes, reclamosRes] =
    await Promise.all([
      client
        .from('pedidos')
        .select('*')
        .gte('creado_en', rango.desde)
        .lte('creado_en', rango.hasta),
      client.from('pagos').select('*').gte('creado_en', rango.desde).lte('creado_en', rango.hasta),
      client.from('productores').select('*'),
      client.from('regiones').select('*'),
      client.from('perfiles').select('*'),
      client
        .from('reclamos')
        .select('*')
        .gte('creado_en', rango.desde)
        .lte('creado_en', rango.hasta),
    ])

  const pedidos = pedidosRes.data ?? []
  const pagos = pagosRes.data ?? []
  const productores = productoresRes.data ?? []
  const regiones = regionesRes.data ?? []
  const usuarios = usuariosRes.data ?? []

  const finiquitados = pedidos.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO)
  const pendientes = pedidos.filter((p) =>
    [ESTADO_PEDIDO.CREADO, ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(p.estado),
  )
  const rechazados = pedidos.filter((p) =>
    [ESTADO_PEDIDO.CANCELADO, ESTADO_PEDIDO.RECLAMADO].includes(p.estado),
  )
  const sumar = (rows, campo) =>
    round2Galeria(rows.reduce((acc, r) => acc + Number(r[campo] ?? 0), 0))
  const gmv = sumar(
    pedidos.filter((p) => p.estado !== ESTADO_PEDIDO.CANCELADO),
    'total',
  )

  // Series temporales y agregados del panel heredado.
  const porDia = new Map()
  const porRegion = new Map()
  const porEstado = new Map()
  const dias = Math.max(1, Math.round((fin - inicio) / 86400000))
  const granularidad = dias > 70 ? 'month' : 'day'
  const cursor = new Date(inicio)
  while (cursor <= fin) {
    const clave = granularidad === 'month' ? mesClave(cursor) : diaClave(cursor)
    porDia.set(clave, { periodo: clave, total: 0, pedidos: 0, comisiones: 0 })
    cursor.setDate(cursor.getDate() + (granularidad === 'month' ? 30 : 1))
  }
  for (const pedido of pedidos) {
    const clave = granularidad === 'month' ? mesClave(pedido.creado_en) : diaClave(pedido.creado_en)
    const fila = porDia.get(clave)
    if (fila) {
      fila.total += Number(pedido.total ?? 0)
      fila.comisiones += Number(pedido.monto_fee_plataforma ?? 0)
      fila.pedidos += 1
    }
    porEstado.set(pedido.estado, (porEstado.get(pedido.estado) ?? 0) + 1)
    if (pedido.estado === ESTADO_PEDIDO.CANCELADO) continue
    const region = porRegion.get(pedido.region_entrega_id) ?? {
      total: 0,
      pedidos: 0,
      comisiones: 0,
    }
    region.total += Number(pedido.total ?? 0)
    region.comisiones += Number(pedido.monto_fee_plataforma ?? 0)
    region.pedidos += 1
    porRegion.set(pedido.region_entrega_id, region)
  }

  const ventasPorRegion = [...porRegion.entries()]
    .map(([regionId, fila]) => ({
      regionId,
      regionNombre: regiones.find((r) => r.id === regionId)?.nombre ?? 'Sin región',
      regionCodigo: regiones.find((r) => r.id === regionId)?.codigo ?? '—',
      total: round2Galeria(fila.total),
      comisiones: round2Galeria(fila.comisiones),
      pedidos: fila.pedidos,
    }))
    .sort((a, b) => b.total - a.total)

  const topProductores = productores
    .map((productor) => {
      const propios = pedidos.filter(
        (p) => p.productor_id === productor.id && p.estado !== ESTADO_PEDIDO.CANCELADO,
      )
      return {
        productorId: productor.id,
        productor,
        pedidos: propios.length,
        total: sumar(propios, 'total'),
        neto: Math.round(propios.reduce((acc, p) => acc + netoProductor(p), 0) * 100) / 100,
      }
    })
    .filter((fila) => fila.pedidos > 0)
    .sort((a, b) => b.total - a.total)
    .slice(0, 8)

  return {
    rango,
    kpis: {
      gmv,
      transaccionesFiniquitadas: finiquitados.length,
      montoFiniquitado: sumar(finiquitados, 'total'),
      transaccionesPendientes: pendientes.length,
      montoPendiente: sumar(pendientes, 'total'),
      transaccionesRechazadas: rechazados.length,
      comisionesRetenidas: sumar([...finiquitados, ...pendientes], 'monto_fee_plataforma'),
      comisionesTotales: sumar(pedidos, 'monto_fee_plataforma'),
      ticketPromedio: pedidos.length ? round2Galeria(gmv / pedidos.length) : 0,
      escrowRetenido: sumar(
        pagos.filter((p) => p.estado === 'retenido'),
        'monto',
      ),
      productoresActivos: productores.filter((p) => p.activo).length,
      productoresPausados: productores.filter((p) => !p.activo).length,
      usuariosTotales: usuarios.length,
      clientes: usuarios.filter((u) => u.rol === ROL_USUARIO.CLIENTE).length,
      vendedores: usuarios.filter((u) => u.rol === ROL_USUARIO.VENDEDOR).length,
      administradores: usuarios.filter((u) => u.rol === ROL_USUARIO.ADMIN).length,
    },
    ventasPorRegion,
    ventasPorDia: [...porDia.values()].map((fila) => ({
      ...fila,
      total: round2Galeria(fila.total),
      comisiones: round2Galeria(fila.comisiones),
    })),
    estadosPedido: Object.values(ESTADO_PEDIDO).map((estado) => ({
      estado,
      count: porEstado.get(estado) ?? 0,
    })),
    topProductores,
    reclamos: reclamosRes.data ?? [],
  }
}

/** Reportes tabulados del panel heredado (mismo origen de datos del dashboard). */
export async function getReporte({ tipo, desde, hasta } = {}) {
  const panel = await getDashboardAdmin({ desde, hasta })

  switch (tipo) {
    case 'comisiones':
      return {
        columnas: [
          { key: 'periodo', label: 'Período' },
          { key: 'pedidos', label: 'Pedidos' },
          { key: 'total', label: 'Ventas' },
          { key: 'comisiones', label: 'Comisiones' },
        ],
        filas: panel.ventasPorDia,
        resumen: {
          Ventas: panel.kpis.gmv,
          Comisiones: panel.kpis.comisionesTotales,
          'Ticket promedio': panel.kpis.ticketPromedio,
        },
      }
    case 'productores':
      return {
        columnas: [
          { key: 'nombre', label: 'Vendedor' },
          { key: 'pedidos', label: 'Pedidos' },
          { key: 'total', label: 'Ventas' },
          { key: 'neto', label: 'Neto vendedor' },
        ],
        filas: panel.topProductores.map((fila) => ({
          nombre: fila.productor?.nombre_comercial ?? '—',
          pedidos: fila.pedidos,
          total: fila.total,
          neto: fila.neto,
        })),
        resumen: { Vendedores: panel.kpis.productoresActivos },
      }
    case 'operaciones':
      return {
        columnas: [
          { key: 'estado', label: 'Estado' },
          { key: 'count', label: 'Pedidos' },
        ],
        filas: panel.estadosPedido,
        resumen: { Total: panel.estadosPedido.reduce((acc, e) => acc + e.count, 0) },
      }
    case 'usuarios':
      return {
        columnas: [
          { key: 'rol', label: 'Rol' },
          { key: 'count', label: 'Usuarios' },
        ],
        filas: [
          { rol: 'Clientes', count: panel.kpis.clientes },
          { rol: 'Vendedores', count: panel.kpis.vendedores },
          { rol: 'Administradores', count: panel.kpis.administradores },
        ],
        resumen: { Total: panel.kpis.usuariosTotales },
      }
    case 'sanciones': {
      const sanciones = await listSanciones()
      return {
        columnas: [
          { key: 'productor', label: 'Vendedor' },
          { key: 'tipo', label: 'Tipo' },
          { key: 'estado', label: 'Estado' },
          { key: 'inicio', label: 'Inicio' },
        ],
        filas: sanciones.map((s) => ({
          productor: s.productor?.nombre_comercial ?? '—',
          tipo: s.tipo,
          estado: s.estado,
          inicio: s.inicio_en,
        })),
        resumen: { Sanciones: sanciones.length },
      }
    }
    case 'ventas':
    default:
      return {
        columnas: [
          { key: 'regionNombre', label: 'Región' },
          { key: 'pedidos', label: 'Pedidos' },
          { key: 'total', label: 'Ventas' },
          { key: 'comisiones', label: 'Comisiones' },
        ],
        filas: panel.ventasPorRegion,
        resumen: {
          GMV: panel.kpis.gmv,
          Pedidos: panel.estadosPedido.reduce((acc, e) => acc + e.count, 0),
        },
      }
  }
}

/**
 * Reclamos con su pedido asociado (ventana heredada del administrador).
 * La tabla `reclamos` pertenece al prototipo anterior; se lee para la galería.
 */
// @deprecated - movido a adminReclamos.js - ya no se usa por nuevo consumo
// export async function listReclamos({ estado = null } = {}) {
//   const client = getClient()
//   let query = client.from('reclamos').select('*')
//   if (estado) query = query.eq('estado', estado)
//   const { data, error } = await query.order('creado_en', { ascending: false })
//   if (error) throw new Error(mensajeSeguro(error))
//   if (!data?.length) return []
//
//   const pedidoIds = [...new Set(data.map((r) => r.pedido_id).filter(Boolean))]
//   const { data: pedidos } = pedidoIds.length
//     ? await client.from('pedidos').select('*').in('id', pedidoIds)
//     : { data: [] }
//   const map = new Map((pedidos ?? []).map((p) => [p.id, p]))
//   return data.map((r) => ({ ...r, pedido: map.get(r.pedido_id) ?? null }))
// }
//
export { listReclamos } from '@/services/adminReclamos'

export { ROL_USUARIO }
