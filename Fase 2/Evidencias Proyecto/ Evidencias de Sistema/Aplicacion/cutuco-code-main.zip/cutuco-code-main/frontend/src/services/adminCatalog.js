/** Administración de productos sobre Supabase Auth, PostgREST y Storage. */
import { mensajeSeguro } from '@/services/errores'
import { getClient, storageUrl } from '@/lib/supabase'
import { STORAGE_BUCKETS } from '@/lib/constants'

function check(result, message) {
  if (result.error) throw new Error(mensajeSeguro(result.error, message))
  return result.data ?? []
}

export async function cargarCatalogoAdmin() {
  const [productosRes, productoresRes, categoriasRes] = await Promise.all([
    getClient().from('productos').select('*').order('actualizado_en', { ascending: false }),
    getClient().from('productores').select('id, nombre_comercial, activo').order('nombre_comercial'),
    getClient().from('categorias').select('id, nombre, categoria_padre_id').order('nombre'),
  ])
  const productos = check(productosRes, 'No se pudieron cargar los productos')
  const productores = check(productoresRes, 'No se pudieron cargar los productores')
  const categorias = check(categoriasRes, 'No se pudieron cargar las categorías')
  const imagenes = productos.length
    ? check(
        await getClient()
          .from('imagenes_productos')
          .select('producto_id, ruta_storage, es_principal, posicion, texto_alternativo')
          .in(
            'producto_id',
            productos.map((p) => p.id),
          )
          .order('posicion'),
        'No se pudieron cargar las imágenes',
      )
    : []
  const productorPorId = new Map(productores.map((p) => [p.id, p]))
  const categoriaPorId = new Map(categorias.map((c) => [c.id, c]))
  const imagenPorProducto = new Map()
  for (const imagen of imagenes) {
    if (!imagenPorProducto.has(imagen.producto_id) || imagen.es_principal) {
      imagenPorProducto.set(imagen.producto_id, {
        ...imagen,
        url: storageUrl(imagen.ruta_storage, { bucket: STORAGE_BUCKETS.productos }),
      })
    }
  }
  return {
    productos: productos.map((p) => ({
      ...p,
      productor: productorPorId.get(p.productor_id) ?? null,
      categoria: categoriaPorId.get(p.categoria_id) ?? null,
      imagenPrincipal: imagenPorProducto.get(p.id) ?? null,
    })),
    productores,
    categorias,
  }
}

export function filtrarProductosAdmin(
  productos,
  { texto = '', categoriaId = '', productorId = '', estado = '' } = {},
) {
  const termino = texto.trim().toLocaleLowerCase('es')
  return productos.filter((p) => {
    if (categoriaId && p.categoria_id !== categoriaId) return false
    if (productorId && p.productor_id !== productorId) return false
    if (estado === 'publicado' && (!p.activo || p.eliminado_en)) return false
    if (estado === 'pausado' && (p.activo || p.eliminado_en)) return false
    if (estado === 'eliminado' && !p.eliminado_en) return false
    return (
      !termino ||
      [p.nombre, p.productor?.nombre_comercial, p.categoria?.nombre].some((valor) =>
        String(valor ?? '')
          .toLocaleLowerCase('es')
          .includes(termino),
      )
    )
  })
}

export function resumenProductosAdmin(productos, { productorId = '' } = {}) {
  const activos = productos.filter(
    (p) => p.activo && !p.eliminado_en && (!productorId || p.productor_id === productorId),
  )
  return {
    publicados: activos.length,
    stockTotal: activos.reduce((total, p) => total + Number(p.stock ?? 0), 0),
  }
}

export const MIN_CARACTERES_MOTIVO = 10
export const MAX_CARACTERES_MOTIVO = 1000

export function errorMotivoProducto(accion, motivo = '') {
  if (!['pausar', 'eliminar'].includes(accion)) return null
  const longitud = Array.from(String(motivo).trim()).length
  if (longitud >= MIN_CARACTERES_MOTIVO && longitud <= MAX_CARACTERES_MOTIVO) return null
  return `La justificación debe tener entre ${MIN_CARACTERES_MOTIVO} y ${MAX_CARACTERES_MOTIVO} caracteres.`
}

export async function cambiarEstadoProductoAdmin(producto, accion, motivo = '') {
  if (producto.eliminado_en) throw new Error('Un producto eliminado no puede cambiar de estado.')
  if (!['pausar', 'publicar', 'eliminar'].includes(accion)) throw new Error('Acción inválida.')
  const razon = String(motivo).trim()
  const errorMotivo = errorMotivoProducto(accion, razon)
  if (errorMotivo) throw new Error(errorMotivo)

  // Reconsulta el productor antes de escribir; el trigger de BD repite la validación
  // bajo bloqueo para cubrir cambios concurrentes y otros clientes PostgREST.
  const productorRes = await getClient()
    .from('productores')
    .select('activo')
    .eq('id', producto.productor_id)
    .single()
  const productor = check(productorRes, 'No se pudo validar el productor')
  if (!productor.activo) throw new Error('El productor está desactivado.')

  const cambios =
    accion === 'pausar'
      ? { activo: false, motivo_pausa: razon }
      : accion === 'publicar'
        ? { activo: true, motivo_pausa: null }
        : {
            activo: false,
            eliminado_en: new Date().toISOString(),
            motivo_pausa: null,
            motivo_eliminacion: razon,
          }
  const result = await getClient()
    .from('productos')
    .update(cambios)
    .eq('id', producto.id)
    .is('eliminado_en', null)
    .select('*')
    .single()
  return check(result, 'No se pudo actualizar el producto')
}
