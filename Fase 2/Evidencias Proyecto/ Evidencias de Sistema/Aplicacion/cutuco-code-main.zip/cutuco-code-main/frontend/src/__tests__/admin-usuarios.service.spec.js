import { beforeEach, describe, expect, it, vi } from 'vitest'

const sdk = vi.hoisted(() => ({
  from: vi.fn(),
  auth: {
    getUser: vi.fn(),
    getSession: vi.fn(),
    getClaims: vi.fn(),
    signInWithPassword: vi.fn(),
    signOut: vi.fn(),
  },
}))
vi.mock('@/lib/supabase.js', () => ({
  supabase: sdk,
  getClient: () => sdk,
  tryGetClient: () => sdk,
  storageUrl: vi.fn(),
  SUPABASE_URL: 'http://127.0.0.1:54321',
}))
import { listarUsuarios, obtenerDetalle, toggleActivo, eliminar } from '@/services/adminUsuarios.js'

const ADMIN_SEED_ID = 'a0000000-0000-0000-0000-000000000001'

const perfil = {
  id: 'perfil-cliente',
  nombre: 'Ana',
  apellido: 'Pérez',
  telefono: '+56911112222',
  rol: 'cliente',
  activo: true,
  es_protegido: false,
  es_super_admin: false,
  eliminado_en: null,
  eliminado_por: null,
}
function consulta(resultado) {
  const query = {}
  for (const metodo of ['select', 'eq', 'in', 'is', 'or', 'order', 'range', 'update', 'maybeSingle']) {
    query[metodo] = vi.fn(() => query)
  }
  // El builder de PostgREST es thenable: el mock debe conservar ese contrato.
  // oxlint-disable-next-line unicorn/no-thenable
  query.then = (resolver, rechazar) => Promise.resolve(resultado).then(resolver, rechazar)
  sdk.from.mockReturnValueOnce(query)
  return query
}

beforeEach(() => {
  vi.resetAllMocks()
  vi.unstubAllEnvs()
  sdk.auth.getUser.mockResolvedValue({ data: { user: { id: ADMIN_SEED_ID } }, error: null })
})

describe('admin-usuarios · service', () => {
  it('pagina en servidor, usa conteo global y carga estado de postulación e imagen del productor', async () => {
    const query = consulta({ data: [perfil], count: 31, error: null })
    consulta({ data: [], error: null })
    consulta({ data: [], error: null })
    const resultado = await listarUsuarios({
      page: 3,
      pageSize: 12,
      rol: 'cliente',
      activo: false,
      texto: 'Ana',
    })
    expect(query.select).toHaveBeenCalledWith(expect.stringContaining('es_protegido'), {
      count: 'exact',
    })
    expect(query.eq.mock.calls).toEqual([
      ['rol', 'cliente'],
      ['activo', false],
    ])
    expect(query.range).toHaveBeenCalledWith(24, 35)
    expect(query.order.mock.calls).toEqual([
      ['creado_en', { ascending: false }],
      ['id', { ascending: true }],
    ])
    expect(query.or).toHaveBeenCalledWith(
      'nombre.ilike."%Ana%",apellido.ilike."%Ana%",telefono.ilike."%Ana%"',
    )
    expect(resultado).toMatchObject({
      total: 31,
      page: 3,
      pageSize: 12,
      items: [{ nombreCompleto: 'Ana Pérez', protegido: false }],
    })
    expect(sdk.from.mock.calls.map(([tabla]) => tabla)).toEqual([
      'perfiles',
      'postulaciones_vendedores',
      'productores',
    ])
  })

  it('encierra valores reservados y escapa comodines de búsqueda', async () => {
    const query = consulta({ data: [], count: 0, error: null })
    await listarUsuarios({ texto: 'x",activo.eq.true)_*%' })
    const expresion = query.or.mock.calls[0][0]
    expect(expresion).toContain('ilike."%x\\",activo.eq.true)')
    expect(expresion).toContain('\\\\_\\\\*\\\\%')
    expect(query.eq).not.toHaveBeenCalled()
  })

  it('normaliza un resultado vacío', async () => {
    consulta({ data: null, count: 0, error: null })
    await expect(listarUsuarios()).resolves.toEqual({ items: [], total: 0, page: 1, pageSize: 12 })
  })

  it.each([
    { page: 0 },
    { page: 1.5 },
    { pageSize: 101 },
    { pageSize: 0 },
    { rol: 'superadmin' },
    { activo: 'false' },
  ])('rechaza parámetros inválidos antes de consultar: %j', async (opciones) => {
    await expect(listarUsuarios(opciones)).rejects.toThrow(
      /no son válidos|Rol inválido|Estado activo inválido/,
    )
    expect(sdk.from).not.toHaveBeenCalled()
  })

  it('propaga un error RLS con código y mensaje normalizado', async () => {
    consulta({ data: null, error: { code: '42501', message: 'permission denied' } })
    await expect(listarUsuarios()).rejects.toMatchObject({
      code: '42501',
      message: 'No tienes permisos para realizar esta operación.',
    })
  })

  it('el detalle de cliente consulta las relaciones para informar postulación e imágenes vigentes', async () => {
    consulta({ data: perfil, error: null })
    consulta({ data: [], error: null })
    consulta({ data: [], error: null })
    await expect(obtenerDetalle(perfil.id)).resolves.toMatchObject({ ...perfil, productor: null })
    expect(sdk.from.mock.calls.map(([tabla]) => tabla)).toEqual([
      'perfiles',
      'postulaciones_vendedores',
      'productores',
    ])
  })

  it('lee el productor asociado para el detalle del vendedor', async () => {
    consulta({ data: { ...perfil, rol: 'vendedor' }, error: null })
    consulta({ data: [], error: null })
    const query = consulta({
      data: [{ id: 'productor', perfil_id: perfil.id, nombre_comercial: 'Huerta' }],
      error: null,
    })
    const resultado = await obtenerDetalle(perfil.id)
    expect(resultado.productor.nombre_comercial).toBe('Huerta')
    expect(query.in).toHaveBeenCalledWith('perfil_id', [perfil.id])
  })

  it('no disimula un fallo al consultar el productor', async () => {
    consulta({ data: { ...perfil, rol: 'vendedor' }, error: null })
    consulta({ data: [], error: null })
    consulta({ error: { message: 'PostgREST no disponible' }, data: null })
    await expect(obtenerDetalle(perfil.id)).rejects.toThrow('PostgREST no disponible')
  })

  it('devuelve null si el detalle no existe y rechaza editarlo', async () => {
    consulta({ data: null, error: null })
    await expect(obtenerDetalle('inexistente')).resolves.toBeNull()
    consulta({ data: null, error: null })
    await expect(toggleActivo('inexistente')).rejects.toThrow('El perfil no existe')
  })

  it.each([true, false])('invierte el estado actual %s y solo escribe activo', async (activo) => {
    consulta({ data: { ...perfil, activo }, error: null })
    const escritura = consulta({ data: { ...perfil, activo: !activo }, error: null })
    await expect(toggleActivo(perfil.id)).resolves.toMatchObject({ activo: !activo })
    expect(escritura.update).toHaveBeenCalledExactlyOnceWith({ activo: !activo })
    expect(escritura.is).toHaveBeenCalledWith('eliminado_en', null)
    expect(escritura.eq.mock.calls).toEqual([
      ['id', perfil.id],
      ['es_protegido', false],
      ['es_super_admin', false],
      ['rol', 'cliente'],
      ['activo', activo],
    ])
  })

  it.each(['es_protegido', 'es_super_admin'])(
    'bloquea cambios para %s incluso al activar',
    async (flag) => {
      consulta({ data: { ...perfil, activo: false, [flag]: true }, error: null })
      await expect(toggleActivo(perfil.id)).rejects.toThrow('cuenta protegida')
      consulta({ data: { ...perfil, [flag]: true }, error: null })
      await expect(eliminar(perfil.id)).rejects.toThrow('cuenta protegida')
      expect(sdk.from).toHaveBeenCalledTimes(2)
    },
  )

  it('evita modificar la propia cuenta desde el service', async () => {
    sdk.auth.getUser.mockResolvedValue({ data: { user: { id: perfil.id } }, error: null })
    consulta({ data: perfil, error: null })
    await expect(toggleActivo(perfil.id)).rejects.toThrow('tu propia cuenta')
    expect(sdk.from).toHaveBeenCalledTimes(1)
  })

  it('exige identidad verificada antes de escribir', async () => {
    sdk.auth.getUser.mockResolvedValue({ data: { user: null }, error: null })
    consulta({ data: perfil, error: null })
    await expect(eliminar(perfil.id)).rejects.toThrow('Inicia sesión')
    expect(sdk.from).toHaveBeenCalledTimes(1)
  })

  it('reporta cambios concurrentes o filas ocultas por RLS sin éxito falso', async () => {
    consulta({ data: perfil, error: null })
    consulta({ data: null, error: null })
    await expect(toggleActivo(perfil.id)).rejects.toThrow('Recarga el listado')
  })

  it('rechaza una confirmación con estado que cambió desde que se abrió el diálogo', async () => {
    consulta({ data: { ...perfil, activo: false }, error: null })
    await expect(toggleActivo(perfil.id, true)).rejects.toThrow('antes de confirmar')
    expect(sdk.from).toHaveBeenCalledTimes(1)
  })

  it('elimina permanentemente con UPDATE auditado, nunca DELETE ni credenciales de login', async () => {
    consulta({ data: perfil, error: null })
    const escritura = consulta({
      data: {
        ...perfil,
        activo: false,
        eliminado_en: '2026-10-09T15:00:00Z',
        eliminado_por: ADMIN_SEED_ID,
      },
      error: null,
    })
    await expect(eliminar(perfil.id)).resolves.toMatchObject({ activo: false, eliminado: true })
    expect(escritura.update).toHaveBeenCalledExactlyOnceWith({
      activo: false,
      eliminado_en: expect.any(String),
    })
    expect(escritura.is).toHaveBeenCalledWith('eliminado_en', null)
    expect(sdk.from.mock.calls).toEqual([['perfiles'], ['perfiles']])
    expect(sdk.auth.signInWithPassword).not.toHaveBeenCalled()
  })

  it.each(['activar', 'eliminar'])('no permite %s un perfil eliminado', async (accion) => {
    consulta({
      data: { ...perfil, activo: false, eliminado_en: '2026-10-09T15:00:00Z' },
      error: null,
    })
    await expect(
      accion === 'activar' ? toggleActivo(perfil.id) : eliminar(perfil.id),
    ).rejects.toThrow('no se puede reactivar')
    expect(sdk.from).toHaveBeenCalledTimes(1)
  })

  it.each([
    ['vendedor', 'activar', false],
    ['vendedor', 'desactivar', true],
    ['vendedor', 'eliminar', true],
    ['admin', 'activar', false],
    ['admin', 'desactivar', true],
    ['admin', 'eliminar', true],
  ])('rechaza %s: %s en el frontend sin escribir', async (rol, accion, activo) => {
    const lectura = consulta({ data: { ...perfil, rol, activo }, error: null })
    await expect(
      accion === 'eliminar' ? eliminar(perfil.id) : toggleActivo(perfil.id),
    ).rejects.toThrow('solo para clientes')
    expect(lectura.update).not.toHaveBeenCalled()
    expect(sdk.from.mock.calls).toEqual([['perfiles']])
  })
})
