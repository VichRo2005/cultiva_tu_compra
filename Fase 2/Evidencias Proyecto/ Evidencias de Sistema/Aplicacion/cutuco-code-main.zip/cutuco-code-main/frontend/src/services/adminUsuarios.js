/** CuTuCo — Administración de usuarios (RF-004 y RF-017).
 * View → adminUsuarios → SDK Supabase → PostgREST, RLS y triggers.
 */
import { supabase } from '@/lib/supabase.js'
import { formatSupabaseError } from '@/lib/format.js'
import { ROL_USUARIO } from '@/lib/constants.js'

const CAMPOS_PERFIL =
  'id,nombre,apellido,telefono,rol,activo,eliminado_en,eliminado_por,es_protegido,es_super_admin,bloqueado_hasta,ultimo_acceso_en,creado_en,actualizado_en,foto_perfil_storage_path'
const CAMPOS_PRODUCTOR =
  'id,perfil_id,nombre_comercial,slug,descripcion,activo,aprobado_en,puntaje_reputacion,cantidad_evaluaciones,foto_perfil_storage_path,portada_storage_path,actualizado_en'
const CAMPOS_POSTULACION = 'id,perfil_id,estado,intento,intentos_extra,actualizado_en'
const ESTADOS_POSTULANTE = ['borrador', 'en_revision', 'rechazada']

function datosUsuarios({ data, error }, fallback) {
  if (error) throw formatSupabaseError(error, fallback)
  return data
}

function normalizarPerfil(perfil, { postulacion = null, productor = null } = {}) {
  return {
    ...perfil,
    postulacion,
    productor,
    esPostulante: Boolean(postulacion),
    rolMostrado: postulacion ? ROL_USUARIO.POSTULANTE : perfil.rol,
    nombreCompleto: [perfil.nombre, perfil.apellido].filter(Boolean).join(' '),
    protegido: Boolean(perfil.es_protegido || perfil.es_super_admin),
    eliminado: Boolean(perfil.eliminado_en),
    bloqueado: Boolean(perfil.bloqueado_hasta && new Date(perfil.bloqueado_hasta) > new Date()),
  }
}

async function cargarPostulacionesActivas(perfilIds) {
  if (!perfilIds.length) return new Map()
  const filas = datosUsuarios(
    await supabase
      .from('postulaciones_vendedores')
      .select(CAMPOS_POSTULACION)
      .in('perfil_id', perfilIds)
      .in('estado', ESTADOS_POSTULANTE),
    'No se pudieron cargar las postulaciones de los usuarios',
  )
  return new Map((filas ?? []).map((fila) => [fila.perfil_id, fila]))
}

async function cargarProductores(perfilIds) {
  if (!perfilIds.length) return new Map()
  const filas = datosUsuarios(
    await supabase.from('productores').select(CAMPOS_PRODUCTOR).in('perfil_id', perfilIds),
    'No se pudieron cargar los perfiles de productor',
  )
  return new Map((filas ?? []).map((fila) => [fila.perfil_id, fila]))
}

async function hidratarPerfiles(perfiles) {
  const ids = perfiles.map((perfil) => perfil.id)
  const [postulaciones, productores] = await Promise.all([
    cargarPostulacionesActivas(ids),
    cargarProductores(ids),
  ])
  return perfiles.map((perfil) =>
    normalizarPerfil(perfil, {
      postulacion: postulaciones.get(perfil.id) ?? null,
      productor: productores.get(perfil.id) ?? null,
    }),
  )
}

/** Paginación y filtros en PostgREST; el conteo corresponde a todos los resultados. */
export async function listarUsuarios({
  page = 1,
  pageSize = 12,
  texto = '',
  rol = '',
  activo = null,
} = {}) {
  if (
    !Number.isInteger(page) ||
    page < 1 ||
    !Number.isInteger(pageSize) ||
    pageSize < 1 ||
    pageSize > 100
  ) {
    throw new Error('La página y el tamaño de página no son válidos (máximo 100).')
  }
  if (rol && !Object.values(ROL_USUARIO).includes(rol)) throw new Error('Rol inválido')
  if (activo !== null && typeof activo !== 'boolean') throw new Error('Estado activo inválido')

  let query = supabase.from('perfiles').select(CAMPOS_PERFIL, { count: 'exact' })
  if (rol === ROL_USUARIO.POSTULANTE) {
    const filas = datosUsuarios(
      await supabase
        .from('postulaciones_vendedores')
        .select('perfil_id')
        .in('estado', ESTADOS_POSTULANTE),
      'No se pudieron filtrar los postulantes',
    )
    const ids = [...new Set((filas ?? []).map((fila) => fila.perfil_id).filter(Boolean))]
    if (!ids.length) return { items: [], total: 0, page, pageSize }
    query = query.in('id', ids)
  } else if (rol) query = query.eq('rol', rol)
  if (activo !== null) query = query.eq('activo', activo)
  const termino = String(texto).trim()
  if (termino) {
    // Valor entre comillas: comas/paréntesis no alteran la expresión de PostgREST.
    // Escape LIKE para que %, _ y * se busquen literalmente.
    const patron = `%${termino.replace(/[\\%_*]/g, '\\$&')}%`
    const valor = `"${patron.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`
    query = query.or(
      ['nombre', 'apellido', 'telefono'].map((campo) => `${campo}.ilike.${valor}`).join(','),
    )
  }
  const desde = (page - 1) * pageSize
  const resultado = await query
    .order('creado_en', { ascending: false })
    .order('id', { ascending: true })
    .range(desde, desde + pageSize - 1)
  const perfiles = datosUsuarios(resultado, 'No se pudieron cargar los usuarios') ?? []
  return {
    items: await hidratarPerfiles(perfiles),
    total: resultado.count ?? 0,
    page,
    pageSize,
  }
}

async function leerPerfil(id) {
  if (!id) throw new Error('Falta el identificador del perfil')
  const perfil = datosUsuarios(
    await supabase.from('perfiles').select(CAMPOS_PERFIL).eq('id', id).maybeSingle(),
    'No se pudo cargar el perfil',
  )
  return perfil ? normalizarPerfil(perfil) : null
}

export async function obtenerDetalle(id) {
  const perfil = await leerPerfil(id)
  if (!perfil) return null
  const [postulaciones, productores] = await Promise.all([
    cargarPostulacionesActivas([id]),
    cargarProductores([id]),
  ])
  return normalizarPerfil(perfil, {
    postulacion: postulaciones.get(id) ?? null,
    productor: productores.get(id) ?? null,
  })
}

async function perfilEditable(id) {
  const perfil = await leerPerfil(id)
  if (!perfil) throw new Error('El perfil no existe o no tienes permisos para consultarlo.')
  if (perfil.protegido)
    throw new Error('No se puede modificar una cuenta protegida o superadministradora.')
  if (perfil.eliminado)
    throw new Error('La cuenta fue eliminada permanentemente y no se puede reactivar.')
  // Restricción del panel de Usuarios, aplicada solo en el frontend.
  if (perfil.rol !== ROL_USUARIO.CLIENTE)
    throw new Error(
      'Estas acciones están disponibles solo para clientes. Gestiona vendedores desde Sanciones.',
    )
  const { data, error } = await supabase.auth.getUser()
  if (error) throw formatSupabaseError(error, 'No se pudo verificar la sesión')
  if (!data?.user) throw new Error('Inicia sesión como administrador para gestionar usuarios.')
  if (data.user.id === id)
    throw new Error('No puedes desactivar ni eliminar tu propia cuenta desde este panel.')
  return perfil
}

async function guardarCambio(perfil, patch) {
  const actualizado = datosUsuarios(
    await supabase
      .from('perfiles')
      .update(patch)
      .eq('id', perfil.id)
      .eq('es_protegido', false)
      .eq('es_super_admin', false)
      .is('eliminado_en', null)
      .eq('rol', perfil.rol)
      .eq('activo', perfil.activo)
      .select(CAMPOS_PERFIL)
      .maybeSingle(),
    'No se pudo actualizar el perfil',
  )
  if (!actualizado) throw new Error('El perfil cambió o ya no tienes permisos. Recarga el listado.')
  return normalizarPerfil(actualizado)
}

/** Activa/desactiva clientes desde el panel de Usuarios. */
export async function toggleActivo(id, activoEsperado) {
  const perfil = await perfilEditable(id)
  if (activoEsperado !== undefined && perfil.activo !== activoEsperado) {
    throw new Error('El estado de la cuenta cambió. Recarga el listado antes de confirmar.')
  }
  return guardarCambio(perfil, { activo: !perfil.activo })
}

/** Baja permanente lógica: la BD asigna la fecha y el actor y bloquea su reversión. */
export async function eliminar(id) {
  const perfil = await perfilEditable(id)
  return guardarCambio(perfil, { activo: false, eliminado_en: new Date().toISOString() })
}
