<script setup>
/**
 * CuTuCo — Centro de reportes y análisis (prototipo anterior).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no está en el menú del producto):
 *   Ventana conservada para la GALERÍA DE DESARROLLO (`VITE_DEV_GALLERY=true`).
 *   RF-011 v2.0 redujo el dashboard del administrador a los pendientes
 *   (aprobaciones, sanciones y pagos) y dejó fuera las ventas por región, el
 *   ticket promedio y el resto de las estadísticas analíticas.
 *
 *   Los reportes se calculan con `getDashboardAdmin()` / `getReporte()`, que
 *   siguen vivos en `services/admin.js` sobre pedidos, pagos y productores
 *   reales de Supabase.
 */ import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import { exportExcel, exportJSON } from '@/lib/csv'
import { daysAgoISO, formatDateTime, formatNumber, startOfMonthISO, todayISO } from '@/lib/format'
import { TIPOS_REPORTE, getReporte } from '@/services/admin'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const geo = useGeographyStore()

const STORAGE_KEY = 'cutuco:admin:reportes'

/** Categorías del diseño mapeadas a los tipos de reporte que el servicio soporta. */
const CATEGORIAS = [
  {
    value: 'ventas',
    label: 'Ventas y Pagos',
    descripcion: 'Ventas por región y comisiones retenidas por periodo.',
    tipos: ['ventas', 'comisiones'],
  },
  {
    value: 'productores',
    label: 'Productores',
    descripcion: 'Ranking de productores y sanciones vigentes.',
    tipos: ['productores', 'sanciones'],
  },
  {
    value: 'inventario',
    label: 'Inventario',
    descripcion: 'El servicio de reportes no expone un agregado de inventario.',
    tipos: [],
  },
  {
    value: 'logistica',
    label: 'Logística',
    descripcion: 'Operaciones y estados de pedido de la cadena de despacho.',
    tipos: ['operaciones'],
  },
]

const PERIODOS = [
  { value: '30', label: 'Últimos 30 días' },
  { value: '90', label: 'Últimos 90 días' },
  { value: 'mes', label: 'Mes en curso' },
]

const FORMATOS = [
  { value: 'xlsx', label: 'Excel (.xlsx)' },
  { value: 'json', label: 'JSON / API' },
  { value: 'pdf', label: 'PDF (no disponible)', disabled: true },
]

const FRECUENCIAS = [
  { value: 'diaria', label: 'Diaria' },
  { value: 'semanal', label: 'Semanal' },
  { value: 'mensual', label: 'Mensual' },
]

const categoria = ref('ventas')
const tipo = ref('ventas')
const periodo = ref('30')
const formato = ref('xlsx')
const regionId = ref('')
const filasEstimadas = ref(null)
const estimando = ref(false)
const generando = ref(false)
const loading = ref(true)
const error = ref(null)

const historialAbierto = ref(false)
const programacionAbierto = ref(false)
const programaciones = ref([])
const descargas = ref([])

const programacionForm = ref({ nombre: '', tipo: 'ventas', frecuencia: 'mensual' })

const categoriaActual = computed(() => CATEGORIAS.find((c) => c.value === categoria.value))

const opcionesTipo = computed(() => {
  const permitidos = categoriaActual.value?.tipos ?? []
  return TIPOS_REPORTE.filter((t) => permitidos.includes(t.key)).map((t) => ({
    value: t.key,
    label: t.label,
  }))
})

const tipoActual = computed(() => TIPOS_REPORTE.find((t) => t.key === tipo.value) ?? null)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)

/** Sólo el reporte de ventas trae columna de región, así que el filtro se habilita ahí. */
const regionFiltrable = computed(() => tipo.value === 'ventas')

const desdeISO = computed(() =>
  periodo.value === 'mes' ? startOfMonthISO() : daysAgoISO(Number(periodo.value)),
)
const hastaISO = computed(() => todayISO())

const columnasHistorial = [
  { key: 'id', label: 'ID' },
  { key: 'archivo', label: 'Nombre del Archivo' },
  { key: 'tipo', label: 'Tipo' },
  { key: 'fecha', label: 'Fecha' },
  { key: 'estado', label: 'Estado' },
  { key: 'acciones', label: 'Acción', align: 'right' },
]

const columnasHistorialCompleto = [
  { key: 'id', label: 'ID' },
  { key: 'archivo', label: 'Nombre del Archivo' },
  { key: 'tipo', label: 'Tipo' },
  { key: 'formato', label: 'Formato' },
  { key: 'fecha', label: 'Fecha' },
  { key: 'estado', label: 'Estado' },
]

/** Al cambiar de categoría se elige el primer tipo real disponible. */
function aplicarCategoria(value) {
  const elegida = CATEGORIAS.find((c) => c.value === value)
  tipo.value = elegida?.tipos[0] ?? ''
  filasEstimadas.value = null
}

function aplicarRegion(filas) {
  if (!regionFiltrable.value || !regionId.value) return filas
  const nombre = geo.regiones.find((r) => String(r.id) === String(regionId.value))?.nombre
  if (!nombre) return filas
  return filas.filter((f) => f.regionNombre === nombre)
}

function leerAlmacenamiento() {
  try {
    const crudo = localStorage.getItem(STORAGE_KEY)
    if (!crudo) return { descargas: [], programaciones: [] }
    const datos = JSON.parse(crudo)
    return {
      descargas: Array.isArray(datos.descargas) ? datos.descargas : [],
      programaciones: Array.isArray(datos.programaciones) ? datos.programaciones : [],
    }
  } catch {
    return { descargas: [], programaciones: [] }
  }
}

function guardarAlmacenamiento() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ descargas: descargas.value, programaciones: programaciones.value }),
    )
  } catch {
    ui.error('No se pudo guardar en el navegador', 'El almacenamiento local no está disponible.')
  }
}

function registrarDescarga({
  archivo,
  tipoReporte,
  tipoClave,
  periodoUsado,
  formatoUsado,
  estado,
}) {
  descargas.value = [
    {
      id: `RPT-${String(descargas.value.length + 1).padStart(4, '0')}`,
      archivo,
      tipo: tipoReporte,
      tipoClave,
      periodo: periodoUsado,
      formato: formatoUsado,
      fecha: new Date().toISOString(),
      estado,
    },
    ...descargas.value,
  ].slice(0, 50)
  guardarAlmacenamiento()
}

const kpis = computed(() => {
  const mesActual = new Date().toISOString().slice(0, 7)
  const delMes = descargas.value.filter((d) => d.fecha.slice(0, 7) === mesActual)
  const mesAnterior = new Date()
  mesAnterior.setMonth(mesAnterior.getMonth() - 1)
  const claveAnterior = mesAnterior.toISOString().slice(0, 7)
  const previos = descargas.value.filter((d) => d.fecha.slice(0, 7) === claveAnterior)
  return {
    ultimaActualizacion: descargas.value[0]?.fecha ?? null,
    generadosMes: delMes.length,
    variacion: previos.length ? ((delMes.length - previos.length) / previos.length) * 100 : null,
  }
})

async function cargarReporte() {
  return getReporte({ tipo: tipo.value, desde: desdeISO.value, hasta: hastaISO.value })
}

async function estimarFilas() {
  if (!tipoActual.value) return
  estimando.value = true
  try {
    const reporte = await cargarReporte()
    filasEstimadas.value = aplicarRegion(reporte.filas).length
  } catch (e) {
    filasEstimadas.value = null
    ui.error('No se pudo estimar', e.message)
  } finally {
    estimando.value = false
  }
}

async function generarReporte() {
  if (!tipoActual.value) {
    ui.warning(
      'Selecciona un tipo de reporte',
      'La categoría elegida no tiene reportes disponibles.',
    )
    return
  }
  if (formato.value === 'pdf') {
    ui.warning('PDF no disponible', 'Usa Excel o JSON / API para descargar el reporte.')
    return
  }
  generando.value = true
  const base = `cutuco-${tipo.value}-${desdeISO.value}-${hastaISO.value}`
  try {
    const reporte = await cargarReporte()
    const filas = aplicarRegion(reporte.filas)
    if (!filas.length) {
      ui.warning('Sin filas para exportar', 'El periodo o la región seleccionados no tienen datos.')
      return
    }
    const columnas = reporte.columnas.map((c) => ({ key: c.key, label: c.label }))
    if (formato.value === 'xlsx') {
      await exportExcel(filas, base, columnas)
    } else {
      exportJSON(
        {
          reporte: tipo.value,
          generado_en: new Date().toISOString(),
          periodo: { desde: desdeISO.value, hasta: hastaISO.value },
          resumen: reporte.resumen,
          columnas: reporte.columnas,
          filas,
        },
        base,
      )
    }
    registrarDescarga({
      archivo: `${base}.${formato.value}`,
      tipoReporte: tipoActual.value.label,
      tipoClave: tipo.value,
      periodoUsado: periodo.value,
      formatoUsado: formato.value.toUpperCase(),
      estado: 'Completado',
    })
    filasEstimadas.value = filas.length
    ui.success(
      'Reporte generado',
      `${filas.length} filas exportadas en ${formato.value.toUpperCase()}.`,
    )
  } catch (e) {
    registrarDescarga({
      archivo: `${base}.${formato.value}`,
      tipoReporte: tipoActual.value.label,
      tipoClave: tipo.value,
      periodoUsado: periodo.value,
      formatoUsado: formato.value.toUpperCase(),
      estado: 'Fallido',
    })
    ui.error('No se pudo generar el reporte', e.message)
  } finally {
    generando.value = false
  }
}

function guardarProgramacion() {
  const nombre = programacionForm.value.nombre.trim()
  if (!nombre) {
    ui.warning('Nombre requerido', 'Indica un nombre para la programación.')
    return
  }
  const tipoReporte = TIPOS_REPORTE.find((t) => t.key === programacionForm.value.tipo)
  programaciones.value = [
    {
      id: `PRG-${String(programaciones.value.length + 1).padStart(3, '0')}`,
      nombre,
      tipo: tipoReporte?.label ?? programacionForm.value.tipo,
      frecuencia: programacionForm.value.frecuencia,
      estado: 'Activa',
      creada_en: new Date().toISOString(),
    },
    ...programaciones.value,
  ]
  guardarAlmacenamiento()
  programacionAbierto.value = false
  programacionForm.value = { nombre: '', tipo: 'ventas', frecuencia: 'mensual' }
  ui.success('Programación registrada', `${nombre} quedó activa en este navegador.`)
}

function alternarProgramacion(programacion) {
  programacion.estado = programacion.estado === 'Activa' ? 'Pausada' : 'Activa'
  guardarAlmacenamiento()
}

function eliminarProgramacion(programacion) {
  programaciones.value = programaciones.value.filter((p) => p.id !== programacion.id)
  guardarAlmacenamiento()
  ui.info('Programación eliminada', programacion.nombre)
}

/** Vuelve a producir el archivo de una descarga con los mismos parámetros. */
async function regenerar(descarga) {
  tipo.value = descarga.tipoClave ?? tipo.value
  periodo.value = descarga.periodo ?? periodo.value
  formato.value = String(descarga.formato ?? 'XLSX').toLowerCase()
  if (formato.value === 'csv') formato.value = 'xlsx'
  await generarReporte()
}

async function cargar() {
  loading.value = true
  error.value = null
  try {
    void geo.load()
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
  const guardado = leerAlmacenamiento()
  descargas.value = guardado.descargas
  programaciones.value = guardado.programaciones
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <p class="eyebrow">Módulo de Análisis</p>
        <h1 class="page-head__title">Centro de Reportes y Análisis</h1>
        <p class="page-head__subtitle">
          Genera, exporta y programa reportes operativos de la plataforma CuTuCo.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :loading="generando" @click="estimarFilas">
          <template #icon><CtIcon name="reports" :size="16" /></template>
          Estimar filas
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo preparar el centro de reportes">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-if="loading" label="Preparando el centro de reportes…" />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Última actualización"
          :value="
            kpis.ultimaActualizacion ? formatDateTime(kpis.ultimaActualizacion) : 'Sin reportes'
          "
          icon="clock"
          tone="info"
          hint="Última descarga generada en este navegador"
        />
        <CtStatCard
          label="Reportes generados (mes)"
          :value="formatNumber(kpis.generadosMes)"
          icon="reports"
          tone="primary"
          :delta="kpis.variacion"
          :delta-label="
            kpis.variacion === null ? 'Sin mes anterior para comparar' : 'vs. mes anterior'
          "
        />
        <CtStatCard
          label="Programaciones activas"
          :value="formatNumber(programaciones.filter((p) => p.estado === 'Activa').length)"
          icon="calendar"
          tone="accent"
          hint="Definidas localmente en este navegador"
        />
      </div>

      <div class="reporte">
        <CtCard
          title="Configurar nuevo reporte"
          subtitle="Define el alcance y el formato de salida"
        >
          <form class="form" @submit.prevent="generarReporte">
            <div class="form__fila">
              <CtSelect
                v-model="categoria"
                label="Categoría del reporte"
                :options="CATEGORIAS.map((c) => ({ value: c.value, label: c.label }))"
                @change="aplicarCategoria"
              />
              <CtSelect
                v-model="tipo"
                label="Tipo de reporte"
                :options="opcionesTipo"
                :disabled="!opcionesTipo.length"
                placeholder="Sin reportes disponibles"
                @change="filasEstimadas = null"
              />
            </div>

            <p v-if="categoriaActual" class="form__descripcion">
              {{ categoriaActual.descripcion }}
            </p>

            <CtAlert
              v-if="!opcionesTipo.length"
              tone="warning"
              compact
              title="Categoría sin reportes"
            >
              <p>
                El servicio <code class="mono">getReporte</code> no expone un agregado de
                inventario. El detalle de stock por producto se revisa en el módulo de catálogo.
              </p>
              <CtButton size="sm" variant="secondary" to="/admin/catalogo">Ir a catálogo</CtButton>
            </CtAlert>

            <div class="form__fila">
              <CtSelect v-model="periodo" label="Periodo de tiempo" :options="PERIODOS" />
              <CtSelect
                v-model="formato"
                label="Formato de salida"
                :options="FORMATOS"
                :hint="formato === 'pdf' ? 'El frontend no genera PDF: elige Excel o JSON.' : null"
              />
            </div>

            <div class="form__fila">
              <CtSelect
                v-model="regionId"
                label="Filtro de datos: región"
                :options="opcionesRegion"
                clearable
                :disabled="!regionFiltrable"
                :hint="
                  regionFiltrable
                    ? 'Se aplica sobre las filas del reporte de ventas.'
                    : 'Sólo el reporte de ventas incluye región de entrega.'
                "
              />
              <div class="estimacion">
                <p class="eyebrow">Filas estimadas</p>
                <p class="estimacion__valor">
                  <template v-if="estimando">Calculando…</template>
                  <template v-else-if="filasEstimadas === null">Sin estimar</template>
                  <template v-else>{{ formatNumber(filasEstimadas) }} filas</template>
                </p>
              </div>
            </div>

            <CtButton type="submit" block :loading="generando" :disabled="!tipoActual">
              <template #icon><CtIcon name="download" :size="16" /></template>
              Generar y Exportar Reporte
            </CtButton>
          </form>
        </CtCard>

        <div class="reporte__aside">
          <CtCard title="Programar reportes" subtitle="Agenda local de generación">
            <template #actions>
              <CtButton size="sm" @click="programacionAbierto = true">
                <template #icon><CtIcon name="plus" :size="14" /></template>
                Nueva Programación
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!programaciones.length"
              compact
              icon="calendar"
              title="Sin programaciones"
              message="Registra una agenda para no tener que generar el reporte cada vez."
            />

            <ul v-else class="programaciones">
              <li v-for="p in programaciones" :key="p.id" class="programacion">
                <div class="programacion__texto">
                  <p class="programacion__nombre">{{ p.nombre }}</p>
                  <p class="programacion__meta">
                    {{ p.tipo }} · {{ FRECUENCIAS.find((f) => f.value === p.frecuencia)?.label }}
                  </p>
                </div>
                <CtBadge :tone="p.estado === 'Activa' ? 'success' : 'neutral'" size="sm">
                  {{ p.estado }}
                </CtBadge>
                <div class="programacion__acciones">
                  <CtButton size="sm" variant="ghost" @click="alternarProgramacion(p)">
                    {{ p.estado === 'Activa' ? 'Pausar' : 'Activar' }}
                  </CtButton>
                  <CtButton size="sm" variant="ghost" @click="eliminarProgramacion(p)">
                    <template #icon><CtIcon name="trash" :size="14" /></template>
                  </CtButton>
                </div>
              </li>
            </ul>

            <p class="nota">
              El esquema no incluye una tabla de programaciones ni un planificador en el backend,
              por eso las agendas y el historial se guardan en el
              <code class="mono">localStorage</code> de este navegador y no se ejecutan de forma
              automática.
            </p>
          </CtCard>

          <CtCard title="Historial de descargas recientes" subtitle="Últimas 5 generaciones">
            <template #actions>
              <CtButton size="sm" variant="ghost" @click="historialAbierto = true">
                Ver historial completo
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!descargas.length"
              compact
              icon="download"
              title="Sin descargas"
              message="Genera tu primer reporte para empezar el historial."
            />

            <CtTable
              v-else
              :columns="columnasHistorial"
              :rows="descargas.slice(0, 5)"
              dense
              min-width="520px"
            >
              <template #cell-archivo="{ row }">
                <span class="mono text-xs">{{ row.archivo }}</span>
              </template>
              <template #cell-tipo="{ row }">
                <span class="text-sm">{{ row.tipo }}</span>
              </template>
              <template #cell-fecha="{ row }">
                <span class="text-xs text-muted">{{ formatDateTime(row.fecha) }}</span>
              </template>
              <template #cell-estado="{ row }">
                <CtBadge :tone="row.estado === 'Completado' ? 'success' : 'danger'" size="sm">
                  {{ row.estado }}
                </CtBadge>
              </template>
              <template #cell-id="{ row }">
                <span class="mono text-xs">{{ row.id }}</span>
              </template>
              <template #cell-acciones="{ row }">
                <CtButton
                  size="sm"
                  variant="ghost"
                  :disabled="row.estado !== 'Completado'"
                  @click="regenerar(row)"
                >
                  <template #icon><CtIcon name="download" :size="14" /></template>
                  Bajar
                </CtButton>
              </template>
            </CtTable>
          </CtCard>
        </div>
      </div>

      <CtCard title="¿Necesitas ayuda?" subtitle="Recursos del centro de reportes">
        <div class="ayuda">
          <router-link to="/admin" class="ayuda__enlace">
            <span class="ayuda__icono" aria-hidden="true"
              ><CtIcon name="dashboard" :size="18"
            /></span>
            <span class="ayuda__titulo">Panel de administración</span>
            <span class="ayuda__texto">KPIs y crecimiento de plataforma en tiempo real.</span>
          </router-link>
          <router-link to="/admin/pagos" class="ayuda__enlace">
            <span class="ayuda__icono" aria-hidden="true"><CtIcon name="scale" :size="18" /></span>
            <span class="ayuda__titulo">Transacciones y escrow</span>
            <span class="ayuda__texto">Detalle pago a pago antes de exportar comisiones.</span>
          </router-link>
          <router-link to="/privacidad" class="ayuda__enlace">
            <span class="ayuda__icono" aria-hidden="true"><CtIcon name="lock" :size="18" /></span>
            <span class="ayuda__titulo">Tratamiento de datos</span>
            <span class="ayuda__texto">Qué información puede incluirse en un reporte.</span>
          </router-link>
        </div>
      </CtCard>

      <footer class="pie">
        <p class="pie__motor">CuTuCo Analytics Engine v2.4.0</p>
        <nav class="pie__enlaces">
          <router-link to="/terminos">Términos y condiciones</router-link>
          <router-link to="/privacidad">Política de privacidad</router-link>
        </nav>
      </footer>
    </template>

    <!-- ==================== Nueva programación ==================== -->
    <CtModal
      v-model="programacionAbierto"
      title="Nueva programación"
      subtitle="Agenda local"
      size="sm"
    >
      <div class="stack">
        <CtInput
          v-model="programacionForm.nombre"
          label="Nombre"
          required
          placeholder="Cierre mensual"
        />
        <CtSelect
          v-model="programacionForm.tipo"
          label="Reporte"
          :options="TIPOS_REPORTE.map((t) => ({ value: t.key, label: t.label }))"
        />
        <CtSelect v-model="programacionForm.frecuencia" label="Frecuencia" :options="FRECUENCIAS" />
        <CtAlert tone="neutral" compact>
          <p>
            La programación queda registrada en este navegador como referencia del reporte que debes
            exportar; el backend no la ejecuta automáticamente.
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="programacionAbierto = false">Cancelar</CtButton>
        <CtButton @click="guardarProgramacion">Guardar programación</CtButton>
      </template>
    </CtModal>

    <!-- ==================== Historial completo ==================== -->
    <CtModal
      v-model="historialAbierto"
      title="Historial completo de descargas"
      :subtitle="`${descargas.length} registro(s) guardados en este navegador`"
      size="lg"
    >
      <CtEmptyState
        v-if="!descargas.length"
        compact
        icon="download"
        title="Sin descargas registradas"
        message="Genera un reporte para que aparezca en el historial."
      />
      <CtTable
        v-else
        :columns="columnasHistorialCompleto"
        :rows="descargas"
        dense
        min-width="680px"
      />
      <p class="nota">
        Sólo se conserva el detalle de cada descarga; el archivo ya descargado vive en tu equipo.
        Usa “Generar y Exportar Reporte” para volver a producirlo.
      </p>
      <template #footer>
        <CtButton variant="secondary" @click="historialAbierto = false">Cerrar</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.reporte {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 420px;
  gap: var(--ct-space-6);
  align-items: start;
}

.reporte__aside {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-6);
}

.form {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.form__fila {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
}

.form__descripcion {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
  margin-top: calc(var(--ct-space-4) * -1);
}

.estimacion {
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  gap: var(--ct-space-1);
  padding-bottom: var(--ct-space-2);
}

.estimacion__valor {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.01em;
}

.programaciones {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  margin-bottom: var(--ct-space-4);
}

.programacion {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
}

.programacion__texto {
  flex: 1;
  min-width: 0;
}

.programacion__nombre {
  font-weight: var(--ct-fw-semibold);
}

.programacion__meta {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.programacion__acciones {
  display: flex;
  gap: var(--ct-space-1);
}

.nota {
  margin-top: var(--ct-space-3);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  line-height: var(--ct-lh-normal);
}

.ayuda {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--ct-space-4);
}

.ayuda__enlace {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-4);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  color: var(--ct-text-soft);
  transition:
    border-color var(--ct-transition),
    background-color var(--ct-transition);
}

.ayuda__enlace:hover {
  border-color: var(--ct-primary);
  background: var(--ct-primary-softer);
  text-decoration: none;
}

.ayuda__icono {
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  border-radius: var(--ct-radius);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.ayuda__titulo {
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.ayuda__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.pie {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
}

.pie__motor {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.pie__enlaces {
  display: flex;
  gap: var(--ct-space-4);
  font-size: var(--ct-fs-xs);
}

.pie__enlaces a {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding-inline: 2px;
}

@media (max-width: 1200px) {
  .reporte {
    grid-template-columns: minmax(0, 1fr);
  }
}

@media (max-width: 720px) {
  .form__fila {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
