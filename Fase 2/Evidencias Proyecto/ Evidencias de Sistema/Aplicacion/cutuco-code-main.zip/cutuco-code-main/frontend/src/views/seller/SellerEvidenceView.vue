<script setup>
/**
 * CuTuCo — Ventana retirada: evidencias fotográficas de envío.
 *
 * La funcionalidad de evidencias quedó descartada del alcance (HAL-CLI-022 /
 * HAL-VEN-023). La ruta no está registrada en el router; se conserva el archivo
 * neutralizado para no romper enlaces antiguos de la galería de desarrollo.
 * La entrega se respalda únicamente con el código de verificación (RF-007).
 */
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Evidencias de envío</h1>
        <p class="page-head__subtitle">Funcionalidad retirada del alcance vigente</p>
      </div>
    </header>

    <CtCard>
      <CtAlert tone="info" compact title="Las evidencias fotográficas ya no se utilizan">
        <p>
          El seguimiento de pedidos usa únicamente el código de verificación que recibe el cliente.
          No hay carga de fotos, comprobantes visuales ni validaciones asociadas a evidencias.
        </p>
      </CtAlert>
      <CtButton variant="secondary" to="/vendedor/pedidos">Volver a pedidos recibidos</CtButton>
    </CtCard>
  </div>
</template>
