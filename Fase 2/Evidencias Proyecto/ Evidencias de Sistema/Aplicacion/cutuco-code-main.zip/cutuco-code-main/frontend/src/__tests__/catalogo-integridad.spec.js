import { beforeEach, describe, expect, it, vi } from 'vitest'

const mock = vi.hoisted(() => ({ tables: {}, errors: {}, rpc: vi.fn() }))
vi.mock('@/lib/supabase', () => ({
  getClient: () => ({
    rpc: mock.rpc,
    from: (table) => {
      const query = { then: (resolve) => Promise.resolve({ data: mock.tables[table] ?? [], error: mock.errors[table] ?? null }).then(resolve) }
      for (const method of ['select', 'in', 'eq', 'is', 'order', 'gt']) query[method] = () => query
      query.maybeSingle = async () => ({ data: mock.tables[table]?.[0] ?? null, error: mock.errors[table] ?? null })
      return query
    },
  }),
  storageUrl: (path) => `https://storage.example.test/${path}`,
}))
vi.mock('@/services/geography', () => ({
  listRegiones: async () => [{ id: 'r1', nombre: 'Metropolitana' }],
  listComunas: async () => [],
}))

import {
  enrichProducts,
  getComunaPorPerfil,
  getProducto,
  getProductorDetalle,
  listEvaluacionesPublicasProductor,
  listProductos,
} from '@/services/catalog'

beforeEach(() => {
  mock.errors = {}
  mock.tables = {
    productores: [{ id: 'v1', perfil_id: 'perfil1', activo: true, region_id: 'r1' }],
    imagenes_productos: [{ producto_id: 'p1', ruta_storage: 'p1/foto.jpg', es_principal: true }],
  }
  mock.rpc.mockReset().mockResolvedValue({ data: [{ perfil_id: 'perfil1', comuna_id: 'c1', nombre: 'Buin', region_id: 'r1' }], error: null })
})

describe('integridad del catálogo público', () => {
  it.each(['producto pausado', 'producto eliminado', 'tienda pausada', 'servicio suspendido'])(
    'no ofrece %s aunque el usuario pueda leerlo por permisos de propietario o admin', async (caso) => {
      const producto = { id: 'p1', productor_id: 'v1', activo: true, stock: 5, precio: 1000 }
      if (caso === 'producto pausado') producto.activo = false
      if (caso === 'producto eliminado') producto.eliminado_en = '2026-11-04T12:00:00Z'
      if (caso === 'tienda pausada') mock.tables.productores[0].activo = false
      if (caso === 'servicio suspendido') mock.tables.productores[0].servicio_suspendido = true
      mock.tables.productos = [producto]
      expect((await listProductos()).items).toEqual([])
      expect(await getProducto('p1')).toBeNull()
    },
  )
  it('no presenta una falla del vendedor como tienda inexistente o sin evaluaciones', async () => {
    mock.errors.productores = { message: 'Consulta fallida' }
    await expect(getProductorDetalle('v1')).rejects.toThrow('No se pudo consultar el vendedor')
    mock.errors = {}
    mock.rpc.mockResolvedValue({ data: null, error: { message: 'RPC fallida' } })
    await expect(getProductorDetalle('v1')).rejects.toThrow('No se pudo cargar la información del vendedor')
  })
  it.each(['productores', 'categorias'])('no convierte un fallo de %s en catálogo vacío', async (table) => {
    mock.errors[table] = { message: 'Detalle interno de consulta' }
    await expect(enrichProducts([{ id: 'p1', productor_id: 'v1' }])).rejects.toThrow('Inténtalo de nuevo')
  })
  it('distingue producto inexistente de consulta fallida', async () => {
    expect(await getProducto('inexistente')).toBeNull()
    mock.errors.productos = { message: 'Detalle interno de consulta' }
    await expect(getProducto('p1')).rejects.toThrow('No se pudo consultar el producto')
    await expect(listProductos()).rejects.toThrow('No se pudo cargar el catálogo')
  })
  it('conserva la fotografía real y muestra solo stock libre de reservas', async () => {
    const [producto] = await enrichProducts([{ id: 'p1', productor_id: 'v1', nombre: 'Tomates', stock: 10, stock_reservado: 4 }])
    expect(producto.imagenPrincipal.url).toBe('https://storage.example.test/p1/foto.jpg')
    expect(producto.stock).toBe(6)
    expect(producto.stock_total).toBe(10)
    expect(producto.comunaProductor.nombre).toBe('Buin')
  })

  it('no inventa una comuna cuando no existe o falla la RPC', async () => {
    mock.rpc.mockResolvedValue({ data: null, error: { message: 'RPC no disponible' } })
    expect((await getComunaPorPerfil(['perfil1'])).size).toBe(0)
    mock.rpc.mockResolvedValue({ data: [], error: null })
    expect((await getComunaPorPerfil(['perfil1'])).size).toBe(0)
  })

  it('pagina y filtra las evaluaciones públicas en la RPC', async () => {
    mock.rpc.mockResolvedValue({ data: [{ id: 'evaluacion-4', puntaje: 4 }], error: null })

    await expect(
      listEvaluacionesPublicasProductor('v1', { limit: 11, offset: 10, puntaje: 4 }),
    ).resolves.toEqual([{ id: 'evaluacion-4', puntaje: 4 }])

    expect(mock.rpc).toHaveBeenCalledWith('evaluaciones_publicas_productor', {
      p_productor_id: 'v1',
      p_limit: 11,
      p_offset: 10,
      p_puntaje: 4,
    })
  })

  it('filtra productos totalmente reservados y pagina con desempate estable', async () => {
    mock.tables.productos = [
      { id: 'p3', productor_id: 'v1', nombre: 'Tomates', precio: 1000, stock: 2, stock_reservado: 0 },
      { id: 'p1', productor_id: 'v1', nombre: 'Tomates', precio: 1000, stock: 2, stock_reservado: 2 },
      { id: 'p2', productor_id: 'v1', nombre: 'Tomates', precio: 1000, stock: 2, stock_reservado: 1 },
    ]
    const result = await listProductos({ soloStock: true, orden: 'precio_asc', pageSize: 1 })
    expect(result.total).toBe(2)
    expect(result.items.map((p) => p.id)).toEqual(['p2'])
    expect((await listProductos({ soloStock: true, orden: 'precio_asc', page: 2, pageSize: 1 })).items[0].id).toBe('p3')
  })
})
