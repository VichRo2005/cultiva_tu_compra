<script setup>
/** CuTuCo — Campana de notificaciones transversales a todos los roles. */
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUiStore } from '@/stores/ui'
import CtBadge from '@/components/base/CtBadge.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import { iconName } from '@/lib/icons'

const ui = useUiStore()
const router = useRouter()

const TONE_ICON = {
  success: 'check',
  warning: 'alert',
  danger: 'ban',
  info: 'info',
  accent: 'alert',
  primary: 'leaf',
}

const TONE_BADGE = {
  success: 'success',
  warning: 'warning',
  danger: 'danger',
  info: 'info',
  accent: 'accent',
  primary: 'primary',
}

const ordenadas = computed(() => [...ui.notifications].sort((a, b) => Number(a.leida) - Number(b.leida)))

function abrir(notification) {
  ui.marcarLeida(notification.id)
  ui.panelAbierto = false
  if (notification.enlace) router.push(notification.enlace)
}
</script>

<template>
  <div class="ct-bell">
    <button
      type="button"
      class="ct-bell__trigger"
      :aria-expanded="ui.panelAbierto"
      aria-label="Notificaciones"
      @click="ui.togglePanel()"
    >
      <CtIcon name="info" :size="19" />
      <span v-if="ui.noLeidas" class="ct-bell__count">{{ ui.noLeidas > 9 ? '9+' : ui.noLeidas }}</span>
    </button>

    <Transition name="bell">
      <div v-if="ui.panelAbierto" class="ct-bell__panel">
        <header class="ct-bell__header">
          <strong>Notificaciones</strong>
          <button
            v-if="ui.noLeidas"
            type="button"
            class="ct-bell__action"
            @click="ui.marcarTodasLeidas()"
          >
            Marcar leídas
          </button>
        </header>

        <div class="ct-bell__list">
          <CtEmptyState
            v-if="!ordenadas.length"
            compact
            icon="info"
            title="Sin novedades"
            message="Te avisaremos cuando tengas pedidos, alertas o cambios de estado."
          />
          <button
            v-for="n in ordenadas"
            :key="n.id"
            type="button"
            class="ct-bell__item"
            :class="{ 'is-unread': !n.leida }"
            @click="abrir(n)"
          >
            <span class="ct-bell__icon" aria-hidden="true">
              <CtIcon :name="iconName(TONE_ICON[n.tone], 'info')" :size="16" />
            </span>
            <span class="ct-bell__content">
              <span class="ct-bell__title">{{ n.titulo }}</span>
              <span class="ct-bell__message">{{ n.mensaje }}</span>
            </span>
            <CtBadge v-if="!n.leida" :tone="TONE_BADGE[n.tone] ?? 'primary'" size="sm">Nuevo</CtBadge>
          </button>
        </div>
      </div>
    </Transition>

    <div v-if="ui.panelAbierto" class="ct-bell__backdrop" @click="ui.togglePanel()" />
  </div>
</template>

<style scoped>
.ct-bell {
  position: relative;
}

.ct-bell__trigger {
  position: relative;
  width: 40px;
  height: 40px;
  border-radius: var(--ct-radius-pill);
  display: grid;
  place-items: center;
  color: var(--ct-text-soft);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  transition:
    background-color var(--ct-transition),
    border-color var(--ct-transition),
    color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-bell__trigger:hover {
  background: var(--ct-surface-alt);
  border-color: var(--ct-border-strong);
  color: var(--ct-text);
  box-shadow: var(--ct-shadow-sm);
}

.ct-bell__count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding-inline: 4px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-danger);
  color: var(--ct-text-invert);
  font-size: 0.625rem;
  font-weight: var(--ct-fw-bold);
  display: grid;
  place-items: center;
}

.ct-bell__panel {
  position: absolute;
  right: 0;
  top: calc(100% + 10px);
  width: 340px;
  max-width: calc(100vw - 2rem);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-xl);
  z-index: var(--ct-z-drawer);
  overflow: hidden;
}

.ct-bell__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--ct-space-3) var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
  font-size: var(--ct-fs-md);
}

.ct-bell__action {
  font-size: var(--ct-fs-xs);
  color: var(--ct-primary-strong);
}

.ct-bell__list {
  max-height: 380px;
  overflow-y: auto;
}

.ct-bell__item {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  width: 100%;
  padding: var(--ct-space-3) var(--ct-space-4);
  text-align: left;
  border-bottom: 1px solid var(--ct-border);
  transition: background-color var(--ct-transition);
}

.ct-bell__item:hover {
  background: var(--ct-surface-alt);
}

.ct-bell__item.is-unread {
  background: var(--ct-primary-softer);
}

.ct-bell__icon {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface-alt);
  color: var(--ct-text-soft);
  flex-shrink: 0;
}

.ct-bell__content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
  min-width: 0;
}

.ct-bell__title {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
}

.ct-bell__message {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.ct-bell__backdrop {
  position: fixed;
  inset: 0;
  z-index: calc(var(--ct-z-drawer) - 1);
}

.bell-enter-active,
.bell-leave-active {
  transition: all var(--ct-transition);
}

.bell-enter-from,
.bell-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}
</style>
