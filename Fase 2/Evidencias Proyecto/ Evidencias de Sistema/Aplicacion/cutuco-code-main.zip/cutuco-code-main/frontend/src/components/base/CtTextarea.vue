<script setup>
/** CuTuCo — Área de texto multilínea. */
import { computed, useAttrs, useId } from 'vue'

defineOptions({ inheritAttrs: false })

const props = defineProps({
  modelValue: { type: String, default: '' },
  label: { type: String, default: null },
  hint: { type: String, default: null },
  error: { type: String, default: null },
  placeholder: { type: String, default: null },
  rows: { type: Number, default: 4 },
  maxlength: { type: Number, default: null },
  showCount: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  required: { type: Boolean, default: false },
})

const emit = defineEmits(['update:modelValue'])

const attrs = useAttrs()
const id = useId()

const value = computed({
  get: () => props.modelValue,
  set: (v) => emit('update:modelValue', v),
})
</script>

<template>
  <label class="ct-textarea__wrap" :for="id">
    <span v-if="label" class="ct-textarea__label">
      {{ label }}
      <span v-if="required" class="ct-textarea__required">*</span>
    </span>
    <textarea
      :id="id"
      v-model="value"
      v-bind="attrs"
      class="ct-textarea__control"
      :class="{ 'is-error': error }"
      :rows="rows"
      :maxlength="maxlength ?? undefined"
      :placeholder="placeholder"
      :disabled="disabled"
      @blur="emit('update:modelValue', value)"
    />
    <span class="ct-textarea__footer">
      <span v-if="error" class="ct-textarea__error">{{ error }}</span>
      <span v-else-if="hint" class="ct-textarea__hint">{{ hint }}</span>
      <span v-if="showCount && maxlength" class="ct-textarea__count">
        {{ String(value ?? '').length }}/{{ maxlength }}
      </span>
    </span>
  </label>
</template>

<style scoped>
.ct-textarea__wrap {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.ct-textarea__label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
}

.ct-textarea__required {
  color: var(--ct-danger);
}

.ct-textarea__control {
  width: 100%;
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  background: var(--ct-surface);
  padding: var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
  resize: vertical;
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-textarea__control:hover:not(:focus) {
  border-color: var(--ct-border-strong);
}

.ct-textarea__control:focus {
  outline: none;
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-textarea__control.is-error {
  border-color: var(--ct-danger);
}

.ct-textarea__control:disabled {
  background: var(--ct-surface-alt);
}

.ct-textarea__footer {
  display: flex;
  justify-content: space-between;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-xs);
}

.ct-textarea__hint {
  color: var(--ct-text-muted);
}

.ct-textarea__error {
  color: var(--ct-danger);
  font-weight: var(--ct-fw-medium);
}

.ct-textarea__count {
  color: var(--ct-text-muted);
  margin-left: auto;
}
</style>
