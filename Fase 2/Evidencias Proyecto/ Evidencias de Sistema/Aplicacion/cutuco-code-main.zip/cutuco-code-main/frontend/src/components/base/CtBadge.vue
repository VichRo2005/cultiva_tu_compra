<script setup>
/** CuTuCo — Badge de estado reutilizable (pedidos, pagos, vendedores, envíos). */
defineProps({
  tone: {
    type: String,
    default: 'neutral',
    validator: (v) =>
      ['neutral', 'success', 'warning', 'danger', 'info', 'primary', 'accent', 'muted'].includes(v),
  },
  size: { type: String, default: 'md' }, // sm | md
  dot: { type: Boolean, default: false },
  variant: { type: String, default: 'soft' }, // soft | solid | outline
  uppercase: { type: Boolean, default: false },
})
</script>

<template>
  <span class="ct-badge" :class="[`ct-badge--${tone}`, `ct-badge--${variant}`, `ct-badge--${size}`]">
    <span v-if="dot" class="ct-badge__dot" aria-hidden="true" />
    <slot name="icon" />
    <span :class="{ 'ct-badge__upper': uppercase }"><slot /></span>
  </span>
</template>

<style scoped>
.ct-badge {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-1);
  border-radius: var(--ct-radius-pill);
  font-weight: var(--ct-fw-semibold);
  white-space: nowrap;
  line-height: 1.3;
  border: 1px solid transparent;
}

.ct-badge--md {
  font-size: var(--ct-fs-xs);
  padding: 0.25rem 0.625rem;
}

.ct-badge--sm {
  font-size: var(--ct-fs-2xs);
  padding: 0.125rem 0.5rem;
}

.ct-badge--upper {
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.ct-badge__dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentcolor;
  flex-shrink: 0;
}

.ct-badge--solid {
  color: var(--ct-text-invert);
}
.ct-badge--solid.ct-badge--neutral {
  background: var(--ct-neutral);
}
.ct-badge--solid.ct-badge--success {
  background: var(--ct-success);
}
.ct-badge--solid.ct-badge--warning {
  background: var(--ct-warning-strong);
}
.ct-badge--solid.ct-badge--danger {
  background: var(--ct-danger);
}
.ct-badge--solid.ct-badge--info {
  background: var(--ct-info);
}
.ct-badge--solid.ct-badge--primary {
  background: var(--ct-primary-strong);
}
.ct-badge--solid.ct-badge--accent {
  background: var(--ct-accent-strong);
  color: var(--ct-text-invert);
}

.ct-badge--outline {
  background: transparent;
  border-style: solid;
  border-width: 1px;
  border-color: currentcolor;
}
.ct-badge--outline.ct-badge--neutral {
  color: var(--ct-neutral);
}
.ct-badge--outline.ct-badge--success {
  color: var(--ct-success);
}
.ct-badge--outline.ct-badge--warning {
  color: var(--ct-warning-strong);
}
.ct-badge--outline.ct-badge--danger {
  color: var(--ct-danger);
}
.ct-badge--outline.ct-badge--info {
  color: var(--ct-info);
}
.ct-badge--outline.ct-badge--primary {
  color: var(--ct-primary-strong);
}
.ct-badge--outline.ct-badge--accent {
  color: var(--ct-accent-strong);
}

.ct-badge--soft.ct-badge--neutral,
.ct-badge--soft.ct-badge--muted {
  background: var(--ct-neutral-soft);
  color: var(--ct-neutral-ink);
}

.ct-badge--soft.ct-badge--success {
  background: var(--ct-success-soft);
  color: var(--ct-success-ink);
}

.ct-badge--soft.ct-badge--warning {
  background: var(--ct-warning-soft);
  color: var(--ct-warning-ink);
}

.ct-badge--soft.ct-badge--danger {
  background: var(--ct-danger-soft);
  color: var(--ct-danger-ink);
}

.ct-badge--soft.ct-badge--info {
  background: var(--ct-info-soft);
  color: var(--ct-info-ink);
}

.ct-badge--soft.ct-badge--primary {
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.ct-badge--soft.ct-badge--accent {
  background: var(--ct-accent-soft);
  color: var(--ct-accent-strong);
}
</style>
