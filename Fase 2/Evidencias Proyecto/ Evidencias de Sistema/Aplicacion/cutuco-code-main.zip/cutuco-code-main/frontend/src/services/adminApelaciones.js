import { getClient } from '@/lib/supabase'
import { currentUserId } from '@/services/session'
import { adminResult as unwrap } from '@/services/adminErrores'
import { contarSancionesVigentes, hidratarSanciones } from '@/services/adminSanciones'
export async function listApelaciones({ estado = null, texto = '' } = {}) {
  const client = getClient()
  let query = client.from('apelaciones').select('*')
  if (estado) query = query.eq('estado', estado)
  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) unwrap({ error })
  if (!data?.length) return []

  const ids = [...new Set(data.map((a) => a.productor_id))]
  const productores = unwrap(await client.from('productores').select('*').in('id', ids))
  const map = new Map((productores ?? []).map((p) => [p.id, p]))
  const sanciones = await hidratarSanciones(
    unwrap(
      await client
        .from('sanciones')
        .select('*')
        .in(
          'id',
          data.map((a) => a.sancion_id),
        ),
    ),
  )
  const sancionMap = new Map(sanciones.map((s) => [s.id, s]))
  return filtrarApelaciones(
    data.map((a) => ({
      ...a,
      productor: map.get(a.productor_id) ?? null,
      sancion: sancionMap.get(a.sancion_id) ?? null,
    })),
    { texto },
  )
}

export async function resolverApelacion(apelacionId, estado, resolucion) {
  const client = getClient()
  const adminId = await currentUserId()
  if (!['aprobada', 'rechazada'].includes(estado)) throw new Error('Selecciona aprobar o rechazar.')
  if (!resolucion?.trim()) throw new Error('Escribe el fundamento de la resolución.')
  const apelacion = unwrap(
    await client.from('apelaciones').select('*').eq('id', apelacionId).single(),
  )
  if (apelacion.estado !== 'pendiente') throw new Error('Esta apelación ya fue resuelta.')
  const sancion = unwrap(
    await client.from('sanciones').select('*').eq('id', apelacion.sancion_id).single(),
  )
  if (sancion.accion === 'ban_permanente')
    throw new Error('El ban permanente solo se levanta con Reactivar cuenta.')
  if (sancion.estado !== 'apelada') throw new Error('La sanción ya no está pendiente de apelación.')
  // Comprobación previa para informar a la UI. El trigger repite el conteo en la
  // misma transacción, evitando reactivar si otra sanción sigue activa o apelada.
  const vigentes = await contarSancionesVigentes(apelacion.productor_id)
  const resultado = unwrap(
    await client
      .from('apelaciones')
      .update({
        estado,
        resolucion: resolucion?.trim() ? resolucion.trim() : null,
        resuelto_por: adminId,
        resuelto_en: new Date().toISOString(),
      })
      .eq('id', apelacionId)
      .eq('estado', 'pendiente')
      .select()
      .single(),
    'No se pudo resolver la apelación',
  )
  return {
    ...resultado,
    otrasSancionesVigentes: Math.max(0, vigentes - (estado === 'aprobada' ? 1 : 0)),
  }
}

export function filtrarApelaciones(rows, { texto = '', estado = '' } = {}) {
  const term = texto.trim().toLocaleLowerCase('es')
  return rows.filter(
    (a) =>
      (!estado || a.estado === estado) &&
      [
        a.id,
        a.sancion_id,
        a.fundamento,
        a.resolucion,
        a.productor?.nombre_comercial,
        a.sancion?.perfil?.nombre,
        a.sancion?.perfil?.apellido,
      ].some((v) =>
        String(v ?? '')
          .toLocaleLowerCase('es')
          .includes(term),
      ),
  )
}
