/**
 * CuTuCo — Ventanas nuevas de Direcciones y Vendedor (r11-r15, r52-r53, r54-r58).
 *
 * Son pruebas de montaje: comprueban que las vistas se renderizan con los datos
 * que devuelven sus servicios y que exponen las acciones que exige el mapeo.
 * Los servicios se mockean para no depender de la base local; la verificación de
 * RLS, triggers y grants vive en `integracion-supabase.spec.js` y en las pruebas
 * del backend.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

const direccionesMock = vi.hoisted(() => ({
  listDirecciones: vi.fn(),
  createDireccion: vi.fn(),
  updateDireccion: vi.fn(),
  eliminarDireccion: vi.fn(),
  marcarDireccionPrincipal: vi.fn(),
  listRegiones: vi.fn(),
  listComunas: vi.fn(),
  // El store de geografía carga por aquí (`stores/geography.js:29`).
  getJerarquiaGeografica: vi.fn(),
  getComuna: vi.fn(),
  getRegion: vi.fn(),
}))

const sellerMock = vi.hoisted(() => ({
  getMiProductor: vi.fn(),
  listMisSanciones: vi.fn(),
  listMisApelaciones: vi.fn(),
  crearApelacion: vi.fn(),
}))

const reclamosMock = vi.hoisted(() => ({
  listReclamosProductor: vi.fn(),
  responderReclamo: vi.fn(),
}))

vi.mock('@/services/geography', () => direccionesMock)
vi.mock('@/services/seller', () => sellerMock)
vi.mock('@/services/reclamos', () => reclamosMock)

import AddressesView from '@/views/shared/AddressesView.vue'
import SellerClaimsView from '@/views/seller/SellerClaimsView.vue'
import SellerSanctionsView from '@/views/seller/SellerSanctionsView.vue'

const REGION = { id: 'r-rm', nombre: 'Región Metropolitana de Santiago' }
const COMUNA = { id: 'c-santiago', nombre: 'Santiago', region_id: REGION.id }

const stubs = {
  RouterLink: { template: '<a><slot /></a>' },
  RouterView: { template: '<div />' },
}

function montar(componente) {
  return mount(componente, { global: { stubs } })
}

beforeEach(() => {
  setActivePinia(createPinia())
  vi.clearAllMocks()
  direccionesMock.listRegiones.mockResolvedValue([REGION])
  direccionesMock.listComunas.mockResolvedValue([COMUNA])
  direccionesMock.getJerarquiaGeografica.mockResolvedValue([{ ...REGION, comunas: [COMUNA] }])
  direccionesMock.getComuna.mockResolvedValue(COMUNA)
  direccionesMock.getRegion.mockResolvedValue(REGION)
})

describe('Mis Direcciones (r11-r15)', () => {
  it('lista las direcciones del perfil con su comuna y región', async () => {
    direccionesMock.listDirecciones.mockResolvedValue([
      {
        id: 'd-1',
        etiqueta: 'Casa cliente',
        calle: 'Av. Siempre Viva',
        numero: '742',
        depto_oficina: null,
        referencia: 'Portón verde',
        comuna_id: COMUNA.id,
        es_principal: true,
        activo: true,
      },
      {
        id: 'd-2',
        etiqueta: 'Trabajo',
        calle: 'Calle Compañía',
        numero: '200',
        comuna_id: COMUNA.id,
        es_principal: false,
        activo: true,
      },
    ])

    const wrapper = montar(AddressesView)
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Casa cliente')
    expect(texto).toContain('Trabajo')
    expect(texto).toContain('Santiago')
    expect(texto).toContain('Principal')
    expect(texto).toContain('Agregar dirección')
  })

  it('ofrece eliminar y marcar como principal, y bloquea la creación al productor', async () => {
    direccionesMock.listDirecciones.mockResolvedValue([
      {
        id: 'd-1',
        etiqueta: 'Predio Paine',
        calle: 'Camino Rural',
        numero: null,
        comuna_id: COMUNA.id,
        es_principal: true,
        activo: true,
      },
    ])

    const wrapper = montar(AddressesView)
    await flushPromises()

    const acciones = wrapper.text()
    expect(acciones).toContain('Eliminar')
    expect(acciones).toContain('Editar')

    // El botón de alta queda deshabilitado si el perfil ya es productor con una
    // dirección activa (la regla la impone `trg_validar_direccion`).
    const auth = (await import('@/stores/auth')).useAuthStore()
    auth.productor = { id: 'prod-1', activo: true }
    await flushPromises()

    const botonAlta = wrapper
      .findAll('button')
      .find((b) => b.text().includes('Agregar dirección'))
    expect(botonAlta?.attributes('disabled')).toBeDefined()
  })

  it('muestra el estado vacío cuando no hay direcciones', async () => {
    direccionesMock.listDirecciones.mockResolvedValue([])
    const wrapper = montar(AddressesView)
    await flushPromises()
    expect(wrapper.text()).toContain('Todavía no tienes direcciones')
  })
})

describe('Reclamos recibidos del vendedor (r52-r53)', () => {
  it('lista los reclamos de mis pedidos y ofrece responder', async () => {
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    reclamosMock.listReclamosProductor.mockResolvedValue([
      {
        id: 'rec-1',
        pedido_id: 'p-1',
        motivo: 'Producto en mal estado',
        descripcion: 'Llegó golpeado',
        estado: 'abierto',
        respuesta_productor: null,
        vigente: true,
        creado_en: '2026-10-01T12:00:00Z',
        pedido: { id: 'p-1', codigo_pedido: 'CUTU-20261001-ABC123', total: 9100, monto_retenido: 9100 },
        cliente: { id: 'u-1', nombre: 'Camila', apellido: 'Rojas' },
      },
    ])

    const wrapper = montar(SellerClaimsView)
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Reclamos Recibidos')
    expect(texto).toContain('CUTU-20261001-ABC123')
    expect(texto).toContain('Producto en mal estado')
    expect(texto).toContain('Camila Rojas')
    expect(texto).toContain('Responder')
    expect(reclamosMock.listReclamosProductor).toHaveBeenCalledWith('prod-1')
  })

  it('muestra el estado vacío sin reclamos', async () => {
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    reclamosMock.listReclamosProductor.mockResolvedValue([])
    const wrapper = montar(SellerClaimsView)
    await flushPromises()
    expect(wrapper.text()).toContain('Sin reclamos')
  })

  it('muestra textos de reclamo almacenados sin crear etiquetas ejecutables', async () => {
    const ataque = '<img src=x onerror="window.__reclamoXss=1"><script>window.__reclamoXss=2</script>'
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    reclamosMock.listReclamosProductor.mockResolvedValue([{
      id: 'rec-xss', pedido_id: 'p-xss', motivo: ataque, descripcion: ataque,
      estado: 'abierto', respuesta_productor: null, vigente: true,
      creado_en: '2026-11-04T12:00:00Z',
      pedido: { id: 'p-xss', codigo_pedido: 'CUTU-XSS', total: 1000 },
      cliente: { id: 'u-xss', nombre: 'Cliente', apellido: 'QA' },
    }])
    const wrapper = montar(SellerClaimsView)
    await flushPromises()
    expect(wrapper.text()).toContain(ataque)
    expect(wrapper.findAll('script')).toHaveLength(0)
    expect(wrapper.findAll('img')).toHaveLength(0)
    expect(window.__reclamoXss).toBeUndefined()
  })
})

describe('Sanciones y apelaciones del vendedor (r54-r58)', () => {
  const SANCION = {
    id: 'san-1',
    tipo: 'suspension',
    accion: 'suspender',
    estado: 'activa',
    motivo: 'Entregas fuera de plazo reiteradas',
    duracion_dias: 30,
    inicio_en: '2026-10-01T12:00:00Z',
    fin_en: '2026-10-31T12:00:00Z',
    numero_amonestacion: null,
  }

  it('lista mis sanciones con duración y término, y permite apelar', async () => {
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    sellerMock.listMisSanciones.mockResolvedValue([SANCION])
    sellerMock.listMisApelaciones.mockResolvedValue([])

    const wrapper = montar(SellerSanctionsView)
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Entregas fuera de plazo reiteradas')
    expect(texto).toContain('30 días')
    expect(texto).toContain('Suspensión temporal')
    expect(texto).toContain('Apelar')
    expect(sellerMock.listMisSanciones).toHaveBeenCalled()
  })

  it('no ofrece apelar si ya hay una pendiente para esa sanción', async () => {
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    sellerMock.listMisSanciones.mockResolvedValue([SANCION])
    sellerMock.listMisApelaciones.mockResolvedValue([
      {
        id: 'ape-1',
        sancion_id: 'san-1',
        estado: 'pendiente',
        fundamento: 'Los plazos se debieron a un corte de camino',
        creado_en: '2026-10-02T12:00:00Z',
      },
    ])

    const wrapper = montar(SellerSanctionsView)
    await flushPromises()

    const botones = wrapper.findAll('button').map((b) => b.text())
    expect(botones.some((t) => t.includes('Apelar'))).toBe(false)
    expect(wrapper.text()).toContain('Los plazos se debieron a un corte de camino')
    expect(wrapper.text()).toContain('Pendiente')
  })

  it('muestra el estado vacío sin sanciones', async () => {
    sellerMock.getMiProductor.mockResolvedValue({ id: 'prod-1' })
    sellerMock.listMisSanciones.mockResolvedValue([])
    sellerMock.listMisApelaciones.mockResolvedValue([])
    const wrapper = montar(SellerSanctionsView)
    await flushPromises()
    expect(wrapper.text()).toContain('Sin sanciones registradas')
  })
})
