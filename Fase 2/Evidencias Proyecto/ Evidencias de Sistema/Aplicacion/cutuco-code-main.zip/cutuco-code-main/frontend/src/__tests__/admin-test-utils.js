import { vi } from 'vitest'
export function consulta(sdk, result) {
  const q = {}
  for (const method of ['select', 'eq', 'in', 'order', 'insert', 'update', 'single', 'maybeSingle'])
    q[method] = vi.fn(() => q)
  // oxlint-disable-next-line unicorn/no-thenable
  q.then = (resolve, reject) => Promise.resolve(result).then(resolve, reject)
  sdk.from.mockReturnValueOnce(q)
  return q
}
export function admin(sdk) {
  sdk.auth.getUser.mockResolvedValue({ data: { user: { id: 'admin' } } })
}
