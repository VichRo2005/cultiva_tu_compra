<script setup>
/**
 * CuTuCo — Carrito del cliente (página 6 del diseño oficial).
 *
 * Reglas de negocio respetadas:
 * - Un pedido pertenece a un único productor: el carrito agrupa por tienda y
 *   crea un pedido por cada tienda mediante Webpay Mall.
 * - El envío se cobra con la tarifa que aplica `crear_envio_al_pagar_pedido`
 *   (`REGLAS.TARIFAS.deliveryDefecto`): no existe envío gratis por monto.
 * - La cobertura se valida con `cart.validarCobertura` contra las coberturas
 *   activas del productor.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtQuantityStepper from '@/components/base/CtQuantityStepper.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import { LABELS, REGLAS } from '@/lib/constants'
import { formatMontoCompra as formatCLP, pluralize } from '@/lib/format'
import {
  isDeptoOficina,
  isNumeroDireccion,
  isReferenciaDireccion,
  LIMITES,
  maxLength,
  required,
} from '@/lib/validation'
import { configuracionCantidadProducto, formatearCantidad } from '@/services/catalog'
import { createDireccion, listDirecciones, updateDireccion } from '@/services/geography'
import { useAuthStore } from '@/stores/auth'
import { useCartStore } from '@/stores/cart'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const SOPORTE = 'mailto:cutucosoporte@gmail.com'

const router = useRouter()
const auth = useAuthStore()
const cart = useCartStore()
const geo = useGeographyStore()
const ui = useUiStore()

const confirmacionVaciar = ref(false)
const validando = ref(false)
const errorCobertura = ref(null)
const modalDireccion = ref(false)
const guardandoDireccion = ref(false)

const direccion = ref({
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
  regionId: null,
  comunaId: null,
})

/* --------------------------- direcciones reales -------------------------- */

/** Direcciones activas del cliente (tabla `direcciones`). */
const direcciones = ref([])
const direccionSeleccionadaId = ref(null)
const cargandoDirecciones = ref(false)
// El catálogo y el carrito se pueden recorrer como invitado, pero una dirección
// pertenece a un perfil y la RLS no permite guardarla sin sesión.
const requiereCuentaParaDireccion = computed(() => !auth.user?.id || !auth.perfil?.id)

/* ------------------------------- destino ------------------------------- */

const direccionSeleccionada = computed(
  () => direcciones.value.find((d) => d.id === direccionSeleccionadaId.value) ?? null,
)

const destinoComuna = computed(
  () => direccionSeleccionada.value?.comuna_id ?? cart.destino.comunaId ?? null,
)
/** La región se deriva de la comuna elegida; nunca de un formulario en edición. */
const destinoRegion = computed(() =>
  destinoComuna.value ? geo.regionDeComuna(destinoComuna.value) : (cart.destino.regionId ?? null),
)
const nombreComunaDestino = computed(() =>
  destinoComuna.value ? geo.nombreComuna(destinoComuna.value) : 'Sin comuna definida',
)
const nombreRegionDestino = computed(() =>
  destinoRegion.value ? geo.nombreRegion(destinoRegion.value) : 'Sin región definida',
)
const direccionTexto = computed(() => {
  const d = direccionSeleccionada.value
  if (!d) return 'Registra tu dirección en Mi Perfil para continuar.'
  return [d.calle, d.numero, d.depto_oficina].filter(Boolean).join(' ')
})

const opcionesDireccion = computed(() =>
  direcciones.value.map((d) => ({
    value: d.id,
    label: `${d.etiqueta} · ${[d.calle, d.numero, d.depto_oficina].filter(Boolean).join(' ')}`,
  })),
)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)
const opcionesComuna = computed(() =>
  geo.comunasDeRegion(direccion.value.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

/* ------------------------------- cobertura ------------------------------ */

/**
 * RF-009: la cobertura es sólo regional. `cart.validarCobertura()` compara la
 * región de la dirección elegida con la región del vendedor y publica el
 * resultado en `cart.cobertura`.
 */
const coberturaVerificada = computed(() => cart.cobertura?.ok === true)
const fueraDeCobertura = computed(() =>
  cart.porVendedor.filter((grupo) => cart.cobertura?.productoresFuera?.includes(grupo.productorId)),
)

/* -------------------------------- totales ------------------------------- */

const subtotal = computed(() => cart.subtotal)
const costoEnvio = computed(() => cart.envio)
const baseImponible = computed(() => cart.baseImponible)
const iva = computed(() => cart.iva)
const tasaIva = computed(() => cart.tasaIva)
const comision = computed(() => cart.comision)
const total = computed(() => cart.total)
const despachosPorProductor = computed(() =>
  cart.porVendedor.map((grupo) => ({
    productorId: grupo.productorId,
    productorNombre: grupo.productorNombre,
    monto: REGLAS.TARIFAS.deliveryDefecto,
  })),
)

const pesoKg = computed(() =>
  cart.items
    .filter((item) => item.unidad === 'kg')
    .reduce((acc, item) => acc + Number(item.cantidad), 0),
)
function configuracionCantidadItem(item) {
  return configuracionCantidadProducto({
    unidad_medida: item.unidad,
    stock: item.stock,
    incremento_venta: item.incrementoVenta,
    cantidad_minima_compra: item.cantidadMinimaCompra,
  })
}
/** Muestra la cantidad real con su unidad (0,5 kg, no «0»). */
function formatCantidad(valor, unidad) {
  return formatearCantidad(valor, unidad)
}

const otrasUnidades = computed(() => {
  const mapa = new Map()
  for (const item of cart.items) {
    if (item.unidad === 'kg') continue
    mapa.set(item.unidad, (mapa.get(item.unidad) ?? 0) + Number(item.cantidad))
  }
  return [...mapa.entries()].map(([unidad, cantidad]) => ({ unidad, cantidad }))
})

const pesoTotalTexto = computed(() => {
  const partes = []
  if (pesoKg.value > 0) partes.push(`${formatCantidad(pesoKg.value, 'kg')} kg`)
  for (const otra of otrasUnidades.value) {
    partes.push(
      `${formatCantidad(otra.cantidad, otra.unidad)} ${LABELS.unidad[otra.unidad] ?? otra.unidad}`,
    )
  }
  return partes.length ? partes.join(' · ') : 'Sin peso estimado'
})

const checkoutBloqueado = computed(
  () =>
    Boolean(cart.errorMontos) ||
    validando.value ||
    !coberturaVerificada.value ||
    !destinoComuna.value,
)

/* -------------------------------- acciones ------------------------------ */

async function validarCobertura() {
  if (!destinoComuna.value || cart.vacio) {
    cart.cobertura = null
    return
  }
  validando.value = true
  errorCobertura.value = null
  try {
    const direccionEntrega = direcciones.value.find((d) => d.id === direccionSeleccionadaId.value)
    if (!direccionEntrega) {
      cart.cobertura = null
      return
    }
    const resultado = await cart.validarCobertura(direccionEntrega)
    if (resultado && !resultado.ok) {
      ui.warning('Revisa tu carrito', resultado.motivo ?? 'El vendedor no entrega en tu región.')
    }
  } catch (e) {
    errorCobertura.value = e?.message ?? 'No se pudo validar la cobertura'
  } finally {
    validando.value = false
  }
}

function vaciar() {
  cart.limpiar()
  confirmacionVaciar.value = false
  ui.info('Carrito vacío', 'Se quitaron todos los productos')
}

function quitarProducto(productoId) {
  cart.quitar(productoId)
}

function quitarProductor(productorId) {
  for (const item of cart.items.filter((i) => i.productorId === productorId)) {
    cart.quitar(item.productoId)
  }
  ui.info('Productos eliminados', 'Quitaste los productos fuera de cobertura')
}

function abrirModalDireccion() {
  const actual = direccionSeleccionada.value
  direccion.value = {
    calle: actual?.calle ?? '',
    numero: actual?.numero ?? '',
    deptoOficina: actual?.depto_oficina ?? '',
    referencia: actual?.referencia ?? '',
    regionId: actual?.comuna_id ? geo.regionDeComuna(actual.comuna_id) : destinoRegion.value,
    comunaId: actual?.comuna_id ?? destinoComuna.value,
  }
  modalDireccion.value = true
}

/** Guarda la dirección de entrega en la tabla `direcciones` (RF-009 y RF-019). */
async function guardarDireccion() {
  if (guardandoDireccion.value) return
  if (requiereCuentaParaDireccion.value) {
    ui.warning(
      'Crea una cuenta para guardar tu dirección',
      'Las direcciones de entrega se guardan en tu perfil para proteger tus pedidos.',
    )
    return
  }
  const calle = String(direccion.value.calle ?? '').trim()
  const numero = String(direccion.value.numero ?? '').trim()
  const deptoOficina = String(direccion.value.deptoOficina ?? '').trim()
  const referencia = String(direccion.value.referencia ?? '').trim()

  if (!required(calle)) {
    ui.warning('Falta la calle', 'Escribe la calle de tu dirección de entrega')
    return
  }
  if (!maxLength(calle, LIMITES.calle)) {
    ui.warning('Dirección demasiado larga', `La calle no puede superar ${LIMITES.calle} caracteres`)
    return
  }
  // HAL-CLI-001: el número es opcional y alfanumérico ("123-B", "Casa 3").
  if (!isNumeroDireccion(numero)) {
    ui.warning(
      'Número inválido',
      `El número es opcional; si lo ingresas, usa hasta ${LIMITES.numero} caracteres alfanuméricos`,
    )
    return
  }
  if (!isDeptoOficina(deptoOficina)) {
    ui.warning(
      'Depto u oficina inválido',
      `Usa hasta ${LIMITES.deptoOficina} caracteres alfanuméricos o déjalo vacío`,
    )
    return
  }
  if (!isReferenciaDireccion(referencia)) {
    ui.warning(
      'Referencia inválida',
      `La referencia es opcional; si la ingresas, usa hasta ${LIMITES.referencia} caracteres`,
    )
    return
  }
  if (!direccion.value.comunaId) {
    ui.warning('Falta la comuna', 'Selecciona la comuna de entrega')
    return
  }

  guardandoDireccion.value = true
  try {
    if (direccionSeleccionada.value) {
      await updateDireccion(direccionSeleccionada.value.id, {
        comuna_id: direccion.value.comunaId,
        calle,
        numero: numero || null,
        depto_oficina: deptoOficina || null,
        referencia: referencia || null,
      })
    } else {
      await createDireccion({
        perfilId: auth.perfil.id,
        etiqueta: direcciones.value.length ? 'Entrega' : 'Principal',
        comunaId: direccion.value.comunaId,
        calle,
        numero: numero || null,
        deptoOficina: deptoOficina || null,
        referencia: referencia || null,
        esPrincipal: direcciones.value.length === 0,
      })
    }
    await cargarDirecciones()
    modalDireccion.value = false
    ui.success('Dirección actualizada', 'Volvemos a validar la cobertura del vendedor')
    await validarCobertura()
  } catch (e) {
    ui.error('No se pudo guardar la dirección', e?.message)
  } finally {
    guardandoDireccion.value = false
  }
}

/** Carga las direcciones del cliente y preselecciona la principal. */
async function cargarDirecciones() {
  if (requiereCuentaParaDireccion.value) {
    direcciones.value = []
    direccionSeleccionadaId.value = null
    return
  }
  cargandoDirecciones.value = true
  try {
    const lista = await listDirecciones({ perfilId: auth.perfil?.id })
    direcciones.value = lista
    if (
      !direccionSeleccionadaId.value ||
      !lista.some((d) => d.id === direccionSeleccionadaId.value)
    ) {
      direccionSeleccionadaId.value = (lista.find((d) => d.es_principal) ?? lista[0])?.id ?? null
    }
    const seleccionada = lista.find((d) => d.id === direccionSeleccionadaId.value)
    if (seleccionada) {
      cart.destino = {
        direccionId: seleccionada.id,
        comunaId: seleccionada.comuna_id,
        // `direcciones` no guarda la región: se deriva de la comuna (RF-009).
        regionId: geo.regionDeComuna(seleccionada.comuna_id),
      }
      direccion.value.regionId = cart.destino.regionId
    }
  } catch (e) {
    errorCobertura.value = e?.message ?? 'No se pudieron cargar tus direcciones'
  } finally {
    cargandoDirecciones.value = false
  }
}

function finalizarPedido() {
  if (checkoutBloqueado.value) return
  router.push('/checkout')
}

onMounted(async () => {
  // La dirección y los montos deben poder cargarse aunque la jerarquía de
  // regiones/comunas tarde; sus opciones aparecerán al resolver el store.
  void geo.load()
  // El resumen parte con la tasa legal y se ajusta de manera reactiva cuando
  // llegue la configuración. Nunca retrases la dirección por esta lectura.
  void cart.cargarConfiguracionIva()
  if (auth.isAuthenticated) await cargarDirecciones()
  if (!cart.vacio) await validarCobertura()
})

watch(direccionSeleccionadaId, () => {
  const seleccionada = direccionSeleccionada.value
  if (!seleccionada) return
  // Mantiene sincronizado el destino del carrito al cambiar de dirección.
  cart.destino = {
    direccionId: seleccionada.id,
    comunaId: seleccionada.comuna_id,
    regionId: geo.regionDeComuna(seleccionada.comuna_id),
  }
})

watch([destinoComuna, destinoRegion], () => {
  if (!cart.vacio) validarCobertura()
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <CtButton to="/catalogo" variant="ghost" size="sm" class="volver">
          <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
          Volver al catálogo
        </CtButton>
        <h1 class="page-head__title">Tu Carrito</h1>
        <p class="page-head__subtitle">
          {{ cart.cantidadProductos }}
          {{ pluralize(cart.cantidadProductos, 'producto', 'productos') }} ·
          {{ pesoTotalTexto }} listos para pagar con Webpay.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="cart.vacio" @click="confirmacionVaciar = true">
          <template #icon><CtIcon name="trash" :size="16" /></template>
          Vaciar Carrito
        </CtButton>
      </div>
    </header>

    <CtEmptyState
      v-if="cart.vacio"
      icon=""
      title="Tu carrito está vacío"
      message="Agrega productos del catálogo para revisar la cobertura y pagar con protección."
    >
      <CtButton to="/catalogo">
        <template #icon><CtIcon name="catalog" :size="16" /></template>
        Ir al catálogo
      </CtButton>
    </CtEmptyState>

    <template v-else>
      <CtAlert v-if="cart.requiereVariosVendedores" tone="info" title="Compra en varias tiendas">
        <p class="linea">
          <CtIcon name="alert" :size="16" />
          <span> Se creará un pedido por tienda. El despacho se cobra por cada vendedor. </span>
        </p>
      </CtAlert>

      <CtAlert
        v-for="grupo in fueraDeCobertura"
        :key="`fuera-${grupo.productorId}`"
        tone="danger"
        :title="`${grupo.productorNombre} no entrega en tu región`"
      >
        <p class="linea">
          <CtIcon name="pin" :size="16" />
          <span>
            {{ cart.cobertura?.motivo ?? `El vendedor sólo entrega en su propia región.` }} Quita
            sus productos para poder finalizar el pedido.
          </span>
        </p>
        <CtButton size="sm" variant="danger" @click="quitarProductor(grupo.productorId)">
          Quitar productos de esta tienda
        </CtButton>
      </CtAlert>

      <CtAlert
        v-if="requiereCuentaParaDireccion"
        tone="warning"
        title="Crea una cuenta para guardar tu dirección"
      >
        <p>
          Puedes revisar el catálogo y armar tu carrito como invitado. Para guardar una dirección y
          continuar con la compra, crea una cuenta de cliente.
        </p>
        <CtButton size="sm" to="/registro">
          <template #icon><CtIcon name="user" :size="15" /></template>
          Crear cuenta de cliente
        </CtButton>
      </CtAlert>

      <CtAlert v-else-if="!destinoComuna" tone="warning" title="Falta tu dirección de entrega">
        <p class="linea">
          <CtIcon name="pin" :size="16" />
          <span>
            Necesitamos tu región y comuna para validar que el vendedor entrega donde estás.
          </span>
        </p>
        <CtButton size="sm" variant="secondary" @click="abrirModalDireccion">
          <template #icon><CtIcon name="edit" :size="15" /></template>
          Indicar mi dirección
        </CtButton>
      </CtAlert>

      <CtAlert v-if="errorCobertura" tone="danger" title="No se pudo validar la cobertura">
        <p class="linea">
          <CtIcon name="alert" :size="16" />
          <span>{{ errorCobertura }}</span>
        </p>
        <CtButton size="sm" variant="secondary" @click="validarCobertura">Reintentar</CtButton>
      </CtAlert>

      <div class="carrito">
        <div class="carrito__principal stack">
          <!-- ================= Productos ================= -->
          <CtCard
            v-for="grupo in cart.porVendedor"
            :key="grupo.productorId"
            :title="`Productos (${grupo.items.length})`"
            subtitle="Gestiona tus productos y verifica la cobertura antes de finalizar."
          >
            <template #actions>
              <CtBadge tone="neutral" size="sm">
                <template #icon><CtIcon name="store" :size="13" /></template>
                {{ grupo.productorNombre }}
              </CtBadge>
            </template>

            <ul class="lineas">
              <li v-for="item in grupo.items" :key="item.productoId" class="linea-item">
                <div class="linea-item__medio">
                  <div class="linea-item__img">
                    <img v-if="item.imagen" :src="item.imagen" :alt="item.nombre" loading="lazy" />
                    <CtIcon v-else name="leaf" :size="20" />
                  </div>
                  <div class="linea-item__datos">
                    <router-link :to="`/producto/${item.productoId}`" class="linea-item__nombre">
                      {{ item.nombre }}
                    </router-link>
                    <span class="linea-item__meta">Productor: {{ item.productorNombre }}</span>
                    <span class="linea-item__meta">
                      {{ formatCLP(item.precio) }} /
                      {{ LABELS.unidad[item.unidad] ?? item.unidad }} ·
                      {{ formatCantidad(item.cantidad, item.unidad) }} de
                      {{ formatCantidad(item.stock, item.unidad) }}
                      {{ LABELS.unidad[item.unidad] ?? item.unidad }} disponibles
                    </span>
                  </div>
                </div>

                <div class="linea-item__acciones">
                  <CtQuantityStepper
                    :model-value="item.cantidad"
                    :min="configuracionCantidadItem(item).min"
                    :max="configuracionCantidadItem(item).max"
                    :step="configuracionCantidadItem(item).paso"
                    :decimals="configuracionCantidadItem(item).decimales"
                    :disabled="configuracionCantidadItem(item).agotado"
                    :unit="LABELS.unidad[item.unidad] ?? item.unidad"
                    :label="`Cantidad de ${item.nombre}`"
                    @change="cart.setCantidad(item.productoId, $event)"
                  />
                  <span class="linea-item__subtotal">
                    {{ formatCLP(item.precio * item.cantidad) }}
                  </span>
                  <CtButton
                    variant="ghost"
                    size="sm"
                    icon-only
                    title="Quitar del carrito"
                    @click="quitarProducto(item.productoId)"
                  >
                    <template #icon><CtIcon name="trash" :size="16" /></template>
                  </CtButton>
                </div>
              </li>
            </ul>

            <template #footer>
              <div class="peso">
                <span class="peso__label">Peso Total Estimado</span>
                <span class="peso__valor">{{ pesoTotalTexto }}</span>
                <span class="peso__nota">Despacho directo desde el productor</span>
              </div>
            </template>
          </CtCard>

          <!-- ============ Validación de cobertura logística ============ -->
          <CtCard title="Validación de Cobertura Logística">
            <template #actions>
              <CtButton variant="secondary" size="sm" @click="abrirModalDireccion">
                <template #icon><CtIcon name="edit" :size="15" /></template>
                Editar dirección
              </CtButton>
            </template>

            <div class="cobertura">
              <div class="cobertura__direccion">
                <span class="eyebrow">Dirección de entrega</span>
                <CtSelect
                  v-if="direcciones.length > 1"
                  v-model="direccionSeleccionadaId"
                  label="Entrega en"
                  :options="opcionesDireccion"
                />
                <p class="cobertura__linea">{{ direccionTexto }}</p>
                <p class="cobertura__linea is-soft">
                  {{ nombreComunaDestino }} · {{ nombreRegionDestino }}
                </p>
              </div>

              <div class="cobertura__estado">
                <CtBadge :tone="coberturaVerificada ? 'success' : 'warning'" dot>
                  {{ coberturaVerificada ? 'Cobertura verificada' : 'Cobertura por verificar' }}
                </CtBadge>
                <CtBadge tone="neutral">{{ nombreRegionDestino }}</CtBadge>
              </div>
            </div>

            <CtSpinner
              v-if="validando || cargandoDirecciones"
              inline
              size="20"
              label="Validando la región del vendedor"
            />

            <p v-else-if="coberturaVerificada" class="cobertura__mensaje">
              <CtIcon name="check" :size="16" />
              <span>
                Todas las tiendas del carrito entregan en tu región. El despacho total es
                {{ formatCLP(costoEnvio) }}, con un envío por vendedor.
              </span>
            </p>

            <p v-else class="cobertura__mensaje is-pending">
              <CtIcon name="info" :size="16" />
              <span>
                Revisaremos la región del vendedor antes de crear el pago. El seguimiento de la
                entrega queda registrado con fecha y hora en cada cambio de estado.
              </span>
            </p>
          </CtCard>

          <!-- ================= Garantías ================= -->
          <div class="garantias">
            <article class="garantia">
              <span class="garantia__icono"><CtIcon name="shieldCheck" :size="18" /></span>
              <div>
                <h3 class="garantia__titulo">Garantía CuTuCo</h3>
                <p class="garantia__texto">
                  Pagas con Webpay Mall y la entrega se cierra con el código de verificación de tu
                  pedido.
                </p>
              </div>
            </article>
            <article class="garantia">
              <span class="garantia__icono"><CtIcon name="cold" :size="18" /></span>
              <div>
                <h3 class="garantia__titulo">Entrega con código</h3>
                <p class="garantia__texto">
                  Recibes un código de entrega y se lo entregas al vendedor. Él lo valida y cierra
                  el pedido; sin código correcto no se marca como entregado.
                </p>
              </div>
            </article>
            <article class="garantia">
              <span class="garantia__icono"><CtIcon name="lock" :size="18" /></span>
              <div>
                <h3 class="garantia__titulo">Pago Seguro</h3>
                <p class="garantia__texto">
                  Al confirmar la compra, pagas de forma segura con Webpay. El productor recibe el
                  pago de su venta y CuTuCo descuenta su comisión.
                </p>
              </div>
            </article>
          </div>
        </div>

        <!-- ================= Resumen de compra ================= -->
        <aside class="carrito__aside stack">
          <CtCard title="Resumen de Compra">
            <p class="cotizacion">
              <CtIcon name="info" :size="14" />
              <span>El precio y el stock se confirman al iniciar el pago.</span>
            </p>

            <div class="totales">
              <div class="totales__fila">
                <span>Productos (neto)</span>
                <span class="totales__valor">{{ formatCLP(subtotal) }}</span>
              </div>
              <div class="totales__fila">
                <span>Despacho ({{ despachosPorProductor.length }} × {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }})</span>
                <span class="totales__valor">{{ formatCLP(costoEnvio) }}</span>
              </div>
              <div
                v-for="despacho in despachosPorProductor"
                :key="despacho.productorId"
                class="totales__fila is-suave"
              >
                <span>Despacho · {{ despacho.productorNombre }}</span>
                <span class="totales__valor">{{ formatCLP(despacho.monto) }}</span>
              </div>
              <div v-if="tasaIva" class="totales__fila">
                <span>IVA ({{ tasaIva * 100 }}% sobre {{ formatCLP(baseImponible) }})</span>
                <span class="totales__valor">{{ formatCLP(iva) }}</span>
              </div>
              <div class="totales__fila is-suave">
                <span>
                  Comisión de CuTuCo ({{ REGLAS.TARIFAS.feePlataforma * 100 }}%, se descuenta al
                  productor y no se suma a tu total)
                </span>
                <span class="totales__valor">{{ formatCLP(comision) }}</span>
              </div>
              <div class="totales__separador" />
              <div class="totales__fila is-total">
                <span>{{ tasaIva ? 'Total (IVA incluido)' : 'Total a pagar' }}</span>
                <span class="totales__total">{{ formatCLP(total) }}</span>
              </div>
            </div>

            <p class="nota-garantia">
              <CtIcon name="shieldCheck" :size="14" />
              <span>Compra protegida: el pago se procesa de forma segura con Webpay.</span>
            </p>

            <CtMoneyInfo title="Cómo se calcula tu total">
              <p class="linea">
                <CtIcon name="info" :size="15" />
                <span>
                  El total considera productos y despacho netos{{ tasaIva ? ` más IVA de ${tasaIva * 100}%` : '' }}.
                  Cada productor incluido cobra su propio despacho de
                  {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }}; por eso se muestran
                  {{ despachosPorProductor.length }} despacho{{ despachosPorProductor.length === 1 ? '' : 's' }}.
                  El desglose se recalcula en el servidor antes del pago.
                </span>
              </p>
            </CtMoneyInfo>

            <CtAlert v-if="cart.errorMontos" tone="warning" compact>{{ cart.errorMontos }}</CtAlert>

            <div class="acciones">
              <CtButton size="lg" block :disabled="checkoutBloqueado" @click="finalizarPedido">
                <template #icon><CtIcon name="lock" :size="16" /></template>
                Finalizar Pedido
              </CtButton>
              <p class="acciones__nota">
                En el siguiente paso deberás aceptar expresamente los términos de CuTuCo antes de
                pagar con Webpay.
              </p>
            </div>

            <div class="atencion">
              <span class="eyebrow">Atención Directa</span>
              <p class="atencion__texto">
                ¿Dudas con el pedido o la entrega? Escríbenos y te respondemos en horario hábil.
              </p>
              <CtButton variant="secondary" size="sm" :href="SOPORTE">
                <template #icon><CtIcon name="mail" :size="15" /></template>
                Contactar soporte
              </CtButton>
            </div>
          </CtCard>
        </aside>
      </div>
    </template>

    <!-- ============ Modal de dirección ============ -->
    <CtModal
      v-model="modalDireccion"
      title="Dirección de entrega"
      subtitle="Tu región se compara con la del vendedor antes de cada pago."
      size="sm"
    >
      <CtAlert
        v-if="requiereCuentaParaDireccion"
        tone="warning"
        title="Dirección disponible con una cuenta"
      >
        <p>
          Crea una cuenta de cliente o inicia sesión para guardar tu dirección y usarla en tus
          pedidos.
        </p>
        <div class="acciones">
          <CtButton size="sm" to="/registro" @click="modalDireccion = false"
            >Crear cuenta de cliente</CtButton
          >
          <CtButton size="sm" variant="secondary" to="/login" @click="modalDireccion = false">
            Iniciar sesión
          </CtButton>
        </div>
      </CtAlert>
      <div v-else class="stack">
        <div class="formulario__fila">
          <CtInput v-model="direccion.calle" label="Calle" placeholder="Calle Compañía" required />
          <CtInput
            v-model="direccion.numero"
            label="Nro./Altura de calle (opcional)"
            placeholder="123-B, Casa 3"
            :hint="`Opcional y alfanumérico (máx. ${LIMITES.numero} caracteres)`"
          />
        </div>
        <CtInput
          v-model="direccion.deptoOficina"
          label="Depto u oficina (opcional)"
          placeholder="Depto 402, Local B"
          :hint="`Complemento separado de la calle (máx. ${LIMITES.deptoOficina} caracteres)`"
        />
        <CtInput
          v-model="direccion.referencia"
          label="Referencia"
          placeholder="Portón verde, timbre 3"
          hint="Opcional: ayuda al repartidor"
        />
        <CtSelect
          v-model="direccion.regionId"
          label="Región"
          :options="opcionesRegion"
          :disabled="geo.cargando"
          @change="direccion.comunaId = null"
        />
        <CtSelect
          v-model="direccion.comunaId"
          label="Comuna"
          :options="opcionesComuna"
          :disabled="!direccion.regionId"
          :hint="direccion.regionId ? undefined : 'Selecciona primero una región'"
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="modalDireccion = false">Cancelar</CtButton>
        <CtButton
          v-if="!requiereCuentaParaDireccion"
          :loading="guardandoDireccion"
          @click="guardarDireccion"
        >
          Guardar dirección
        </CtButton>
      </template>
    </CtModal>

    <CtConfirmDialog
      v-model="confirmacionVaciar"
      title="¿Vaciar el carrito?"
      message="Se quitarán todos los productos guardados. Esta acción no se puede deshacer."
      confirm-label="Vaciar carrito"
      tone="danger"
      @confirm="vaciar"
    >
      <template #icon><CtIcon name="trash" :size="20" /></template>
    </CtConfirmDialog>
  </div>
</template>

<style scoped>
.volver {
  margin-bottom: var(--ct-space-2);
  margin-inline-start: calc(-1 * var(--ct-space-3));
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.carrito {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

@media (max-width: 1100px) {
  .carrito {
    grid-template-columns: minmax(0, 1fr);
  }
}

.lineas {
  list-style: none;
  margin: 0;
  padding: 0;
}

.linea-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-5);
  flex-wrap: wrap;
  padding: var(--ct-space-4) 0;
  border-bottom: 1px solid var(--ct-border);
}

.linea-item:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.linea-item__medio {
  display: flex;
  align-items: center;
  gap: var(--ct-space-4);
  min-width: 0;
  flex: 1 1 260px;
}

.linea-item__img {
  width: 64px;
  height: 64px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface-alt);
  color: var(--ct-text-muted);
  display: grid;
  place-items: center;
  overflow: hidden;
}

.linea-item__img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.linea-item__datos {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.linea-item__nombre {
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
  font-size: var(--ct-fs-base);
}

.linea-item__nombre:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.linea-item__meta {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.linea-item__acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
}

.linea-item__cantidad {
  width: 120px;
}

.linea-item__subtotal {
  min-width: 96px;
  text-align: right;
  font-weight: var(--ct-fw-semibold);
}

.peso {
  display: flex;
  align-items: baseline;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.peso__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.peso__valor {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
}

.peso__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.cobertura {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
}

.cobertura__direccion {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
  min-width: 0;
}

.cobertura__linea {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.cobertura__linea.is-soft {
  font-weight: var(--ct-fw-regular);
  color: var(--ct-text-soft);
}

.cobertura__estado {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.cobertura__mensaje {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-4);
  padding: var(--ct-space-3);
  border-radius: var(--ct-radius-md);
  /* El texto y el icono son blancos: necesitan un fondo de estado sólido. */
  background: var(--ct-success);
  color: var(--ct-text-invert);
  font-size: var(--ct-fs-sm);
  line-height: var(--ct-lh-normal);
}

.cobertura__mensaje.is-pending {
  background: var(--ct-surface-alt);
  color: var(--ct-text-soft);
}

.garantias {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--ct-space-4);
}

.garantia {
  display: flex;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-xs);
}

.garantia__icono {
  width: 36px;
  height: 36px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  display: grid;
  place-items: center;
}

.garantia__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.garantia__texto {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
  margin-top: 2px;
}

.cotizacion {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  margin-bottom: var(--ct-space-4);
}

.totales {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.totales__fila {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.totales__fila.is-suave {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.totales__valor {
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.totales__separador {
  height: 1px;
  background: var(--ct-border);
  margin: var(--ct-space-2) 0;
}

.totales__fila.is-total {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.totales__total {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  color: var(--ct-primary-strong);
}

.nota-garantia {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  margin: var(--ct-space-4) 0;
  padding: var(--ct-space-2) var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  /* Aviso informativo con texto blanco: se mantiene legible en toda la tarjeta. */
  background: var(--ct-primary-fill);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-invert);
}

.acciones {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-4);
}

.acciones__nota {
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
  line-height: var(--ct-lh-normal);
}

.atencion {
  margin-top: var(--ct-space-5);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  align-items: flex-start;
}

.atencion__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}
</style>
