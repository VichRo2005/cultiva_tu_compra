import { describe, it, expect } from 'vitest'

import {
  emailPolicyMessage,
  isEmail,
  isRut,
  isPhone,
  isNombrePropio,
  isNumeroDireccion,
  isReferenciaDireccion,
  isNumeroCuentaBancaria,
  isTitularCuenta,
  normalizarTelefonoChileno,
  LIMITES,
  required,
  minLength,
  maxLength,
  validate,
  passwordStrength,
  passwordPolicyMessage,
  reputationTone,
  sanitizeFileName,
  isAllowedImage,
} from '@/lib/validation'
import { calcularLiquidacion, deliveryStepIndex, ESTADO_ENVIO, ESTADO_PEDIDO, REGLAS } from '@/lib/constants'

describe('validation · correo', () => {
  it('acepta correos válidos', () => {
    expect(isEmail('productor.paine@example.test')).toBe(true)
    expect(isEmail('santiago.cliente@cutuco.cl')).toBe(true)
    expect(isEmail('nombre+etiqueta@sub.dominio.cl')).toBe(true)
    expect(isEmail('nombre_apellido@dominio.cl')).toBe(true)
    expect(isEmail('nombre-apellido@dominio.cl')).toBe(true)
  })

  it('rechaza correos inválidos', () => {
    expect(isEmail('sin-arroba.cl')).toBe(false)
    expect(isEmail('')).toBe(false)
    expect(isEmail(null)).toBe(false)
    expect(isEmail('usuario@')).toBe(false)
    expect(isEmail('usuario@dominio')).toBe(false)
    expect(isEmail('usuario@.cl')).toBe(false)
    expect(isEmail('usuario@@dominio.cl')).toBe(false)
    expect(isEmail('usuario@dominio..cl')).toBe(false)
    expect(isEmail('usuario@-dominio.cl')).toBe(false)
    expect(isEmail('usuario@dominio-.cl')).toBe(false)
  })

  it('rechaza espacios externos, Unicode y exceso de longitud', () => {
    expect(isEmail(' usuario@dominio.cl')).toBe(false)
    expect(isEmail('usuario@dominio.cl ')).toBe(false)
    expect(isEmail('usu ario@dominio.cl')).toBe(false)
    expect(isEmail('usuario@dominio.cl\n')).toBe(false)
    expect(isEmail('josé@dominio.cl')).toBe(false)
    expect(isEmail('usuario@dominio.cl😀')).toBe(false)
    expect(isEmail(`${'a'.repeat(65)}@dominio.cl`)).toBe(false)
    expect(isEmail(`${'a'.repeat(244)}@dominio.cl`)).toBe(false)
  })

  it('emailPolicyMessage devuelve null para un correo válido y el motivo si no lo es', () => {
    expect(emailPolicyMessage('cliente@cutuco.dev')).toBeNull()
    expect(emailPolicyMessage(' usuario@dominio.cl')).toContain('espacios')
    expect(emailPolicyMessage('usuario@dominio')).toContain('válido')
    expect(emailPolicyMessage('')).toContain('obligatorio')
  })
})

describe('validation · RUT', () => {
  it('acepta rut con puntos y guion y valida el dígito verificador', () => {
    expect(isRut('12.345.678-5')).toBe(true)
    expect(isRut('12345678-5')).toBe(true)
    expect(isRut('12.345.678-9')).toBe(false)
  })

  it('rechaza rut inválido', () => {
    expect(isRut('abc')).toBe(false)
    expect(isRut('123456789')).toBe(false)
    expect(isRut('')).toBe(false)
  })
})

describe('validation · teléfono', () => {
  it('acepta números chilenos con y sin código de país', () => {
    expect(isPhone('+56912345678')).toBe(true)
    expect(isPhone('56912345678')).toBe(true)
    expect(isPhone('912345678')).toBe(true)
    expect(isPhone('9 1234 5678')).toBe(true)
  })

  it('rechaza números demasiado cortos o con letras', () => {
    expect(isPhone('123')).toBe(false)
    expect(isPhone('91234abc8')).toBe(false)
  })

  it('A6: el prefijo por sí solo no acredita validez (estructura chilena)', () => {
    // 88888888 no es ni móvil (9 dígitos que empiezan con 9) ni fijo 2/3.
    expect(isPhone('88888888')).toBe(false)
    expect(isPhone('+569123456789')).toBe(false)
    expect(isPhone('+56812345678')).toBe(false)
  })

  it('A6: acepta fijo con código de área 2 y normaliza al formato canónico', () => {
    expect(isPhone('+56223456789')).toBe(true)
    expect(isPhone('223456789')).toBe(true)
    expect(isPhone('2 2345 6789')).toBe(true)
    expect(normalizarTelefonoChileno('+56 9 1234 5678')).toBe('+56912345678')
    expect(normalizarTelefonoChileno('56-9-1234-5678')).toBe('+56912345678')
    expect(normalizarTelefonoChileno('88888888')).toBeNull()
    expect(normalizarTelefonoChileno('')).toBeNull()
  })

  it('A3: expone los límites del esquema para los formularios', () => {
    expect(LIMITES.calle).toBe(255)
    expect(LIMITES.nombre).toBe(100)
    expect(LIMITES.nombreComercial).toBe(160)
  })
})

describe('validation · nombres propios (A2)', () => {
  it('acepta nombres reales con tildes, espacios, apóstrofes y guiones', () => {
    expect(isNombrePropio('María José')).toBe(true)
    expect(isNombrePropio('Ángel')).toBe(true)
    expect(isNombrePropio("O'Brien")).toBe(true)
    expect(isNombrePropio('Pérez-Luna')).toBe(true)
  })

  it('rechaza valores compuestos por espacios, números o símbolos', () => {
    expect(isNombrePropio('   ')).toBe(false)
    expect(isNombrePropio('Juan123')).toBe(false)
    expect(isNombrePropio('Ana@@')).toBe(false)
    expect(isNombrePropio('')).toBe(false)
  })

  it('rechaza espacios dobles internos', () => {
    expect(isNombrePropio('Juan  Pérez')).toBe(false)
  })
})

describe('validation · contraseña', () => {
  it('exige la política fuerte completa', () => {
    expect(passwordPolicyMessage('CutucoTest!2026')).toBeNull()
    expect(passwordPolicyMessage('Clave1234!')).toBeNull()
    expect(passwordPolicyMessage('corte123')).toBe(
      'La contraseña debe incluir al menos una mayúscula',
    )
    expect(passwordPolicyMessage('12345678')).toBe(
      'La contraseña debe incluir al menos una mayúscula',
    )
    expect(passwordPolicyMessage('corte')).toBe(
      'La contraseña debe tener al menos 8 caracteres',
    )
    expect(passwordPolicyMessage('corteclavelarga')).toBe(
      'La contraseña debe incluir al menos una mayúscula',
    )
    expect(passwordPolicyMessage('SinSimbolo123')).toBe(
      'La contraseña debe incluir al menos un símbolo (por ejemplo ! # $ %)',
    )
    expect(passwordPolicyMessage('sinmayuscula1!')).toBe(
      'La contraseña debe incluir al menos una mayúscula',
    )
    expect(passwordPolicyMessage('SINMINUSCULA1!')).toBe(
      'La contraseña debe incluir al menos una minúscula',
    )
    expect(passwordPolicyMessage('SinNumero!!')).toBe(
      'La contraseña debe incluir al menos un número',
    )
  })

  it('acepta 72 caracteres ASCII y rechaza 73 o Unicode', () => {
    const base = 'Aa1!'
    expect(passwordPolicyMessage(base + 'x'.repeat(68))).toBeNull()
    expect(passwordPolicyMessage(base + 'x'.repeat(69))).toBe(
      'La contraseña no puede superar 72 caracteres',
    )
    expect(passwordPolicyMessage('Clave1!ñ')).toBe(
      'La contraseña sólo puede usar caracteres ASCII (sin tildes, ñ, emojis ni símbolos Unicode)',
    )
    expect(passwordPolicyMessage('Clave1!😀')).toBe(
      'La contraseña sólo puede usar caracteres ASCII (sin tildes, ñ, emojis ni símbolos Unicode)',
    )
    expect(passwordPolicyMessage('')).toBe('La contraseña es obligatoria')
  })

  it('puntúa la seguridad de la contraseña sin contradecir la política', () => {
    expect(passwordStrength('').score).toBe(0)
    expect(passwordStrength('CutucoTest!2026').score).toBeGreaterThanOrEqual(3)
    expect(passwordStrength('CutucoTest!2026').valid).toBe(true)
    expect(passwordStrength('corte').valid).toBe(false)
    expect(passwordStrength('corte').label).not.toMatch(/Buena|Fuerte/)
  })
})

describe('validation · reglas de campo', () => {
  it('required, minLength y maxLength devuelven booleanos', () => {
    expect(required('Ana')).toBe(true)
    expect(required('   ')).toBe(false)
    expect(minLength('ab', 3)).toBe(false)
    expect(minLength('abc', 3)).toBe(true)
    expect(maxLength('abcdef', 3)).toBe(false)
    expect(maxLength('abc', 3)).toBe(true)
  })

  it('validate devuelve valid y errors según el esquema', () => {
    const resultado = validate(
      { nombre: '', email: 'malo', stock: -4, tipo: 'vendedor' },
      {
        nombre: { required: true },
        email: { required: true, email: true },
        stock: { nonNegative: true },
        tipo: { oneOf: ['cliente', 'vendedor'] },
      },
    )
    expect(resultado.valid).toBe(false)
    expect(resultado.errors.nombre).toBe('Este campo es obligatorio')
    expect(resultado.errors.email).toBe('Correo electrónico inválido')
    expect(resultado.errors.stock).toBe('No puede ser negativo')
    expect(resultado.errors.tipo).toBeUndefined()
  })

  it('validate acepta un formulario correcto', () => {
    const resultado = validate(
      { nombre: 'Ana', email: 'ana@cutuco.cl' },
      { nombre: { required: true, minLength: 3 }, email: { required: true, email: true } },
    )
    expect(resultado.valid).toBe(true)
    expect(resultado.errors).toEqual({})
  })
})

/**
 * RF-009: la cobertura es sólo regional. La comparación se hace entre la región
 * del vendedor y la de la dirección de entrega, sin comunas ni geolocalización.
 * (Antes existía `isCoveredBy` con cobertura por comuna: salió del alcance.)
 */
describe('reglas · cobertura regional (RF-009)', () => {
  function mismaRegion(regionVendedor, regionCliente) {
    if (!regionVendedor || !regionCliente) return false
    return regionVendedor.id === regionCliente.id
  }

  it('permite la compra cuando las regiones coinciden', () => {
    expect(mismaRegion({ id: 'rm' }, { id: 'rm' })).toBe(true)
  })

  it('bloquea la compra cuando las regiones son distintas', () => {
    expect(mismaRegion({ id: 'rm' }, { id: 'v' })).toBe(false)
  })

  it('no permite comparar si falta una región', () => {
    expect(mismaRegion(null, { id: 'rm' })).toBe(false)
    expect(mismaRegion({ id: 'rm' }, null)).toBe(false)
  })
})

describe('reglas · tarifas, IVA y liquidación (RF-014)', () => {
  it('calcula el IVA al cliente y el payout descontando sólo el fee de 5%', () => {
    const r = calcularLiquidacion({ subtotal: 10000 })
    expect(r.tarifaDelivery).toBe(3500)
    expect(r.montoFee).toBe(500)
    expect(r.baseImponible).toBe(13500)
    expect(r.iva).toBe(2565)
    expect(r.total).toBe(16065)
    expect(r.montoLiquidar).toBe(15565)
  })

  it('usa la tarifa configurada cuando se indica', () => {
    const r = calcularLiquidacion({ subtotal: 2000, tarifaDelivery: 0 })
    expect(r.iva).toBe(380)
    expect(r.total).toBe(2380)
    expect(r.montoLiquidar).toBe(2280)
  })

  it('expone la regla del fee y de la tarifa fija en REGLAS', () => {
    expect(REGLAS.TARIFAS.feePlataforma).toBe(0.05)
    expect(REGLAS.TARIFAS.deliveryDefecto).toBe(3500)
  })
})

describe('reglas · delivery (RF-025 y RF-007)', () => {
  it('ubica el paso según el estado del envío', () => {
    expect(deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.PAGADO, envioEstado: null })).toBe(0)
    expect(
      deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.EN_PREPARACION, envioEstado: ESTADO_ENVIO.PREPARACION }),
    ).toBe(1)
    expect(deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.PAGADO, envioEstado: ESTADO_ENVIO.EN_TRANSITO })).toBe(2)
    expect(deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.COMPLETADO, envioEstado: ESTADO_ENVIO.ENTREGADO })).toBe(3)
  })

  it('no avanza cuando la entrega falló o el pedido se canceló', () => {
    expect(deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.PAGADO, envioEstado: ESTADO_ENVIO.FALLIDO })).toBe(1)
    expect(deliveryStepIndex({ pedidoEstado: ESTADO_PEDIDO.CANCELADO, envioEstado: null })).toBe(1)
  })
})

describe('validation · reputación (RF-006)', () => {
  it('clasifica el promedio simple de 1 a 5 sin pausa automática', () => {
    expect(reputationTone(4.8).tone).toBe('success')
    expect(reputationTone(3.8).tone).toBe('info')
    expect(reputationTone(2.8).tone).toBe('warning')
    expect(reputationTone(1.5).tone).toBe('danger')
    expect(reputationTone(0).tone).toBe('neutral')
  })
})

describe('validation · dirección', () => {
  it('acepta número vacío (opcional) y valores alfanuméricos', () => {
    expect(isNumeroDireccion('')).toBe(true)
    expect(isNumeroDireccion('   ')).toBe(true)
    expect(isNumeroDireccion('1200')).toBe(true)
    expect(isNumeroDireccion('12B')).toBe(true)
    expect(isNumeroDireccion('Casa 3')).toBe(true)
    expect(isNumeroDireccion('Parcela 4')).toBe(true)
    expect(isNumeroDireccion('sin número')).toBe(true)
    expect(isNumeroDireccion('1'.repeat(21))).toBe(false)
    expect(isNumeroDireccion('<script>')).toBe(false)
  })

  it('acepta referencia vacía pero valida la escrita', () => {
    expect(isReferenciaDireccion('')).toBe(true)
    expect(isReferenciaDireccion('Portón verde')).toBe(true)
    expect(isReferenciaDireccion('abc')).toBe(true)
    expect(isReferenciaDireccion('...')).toBe(false)
    expect(isReferenciaDireccion('x'.repeat(501))).toBe(false)
  })
})

describe('validation · cuenta bancaria', () => {
  it('valida 7 a 12 dígitos sin importar el tipo', () => {
    expect(isNumeroCuentaBancaria('1234567', 'cuenta_rut')).toBe(true)
    expect(isNumeroCuentaBancaria('123456789012', 'cuenta_corriente')).toBe(true)
    expect(isNumeroCuentaBancaria('123', 'cuenta_corriente')).toBe(false)
    expect(isNumeroCuentaBancaria('123456', 'cuenta_rut')).toBe(false)
    expect(isNumeroCuentaBancaria('1234567890123', 'cuenta_ahorro')).toBe(false)
    expect(isNumeroCuentaBancaria('12A45678', 'cuenta_vista')).toBe(false)
    expect(isNumeroCuentaBancaria(' 12345678 ', 'cuenta_vista')).toBe(true)
  })

  it('valida el titular sin aceptar sólo signos', () => {
    expect(isTitularCuenta('María Pérez')).toBe(true)
    expect(isTitularCuenta('---')).toBe(false)
    expect(isTitularCuenta('')).toBe(false)
  })
})

describe('validation · archivos', () => {
  it('sanitiza nombres de archivo', () => {
    expect(sanitizeFileName('Mi Foto (1).jpg')).toBe('mi-foto-1.jpg')
    expect(sanitizeFileName('A photograph.JPG')).toBe('a-photograph.jpg')
  })

  it('valida tipo y tamaño de imagen', () => {
    const ok = new File(['x'], 'foto.jpg', { type: 'image/jpeg' })
    expect(isAllowedImage(ok)).toBeNull()

    const mala = new File(['x'], 'doc.pdf', { type: 'application/pdf' })
    expect(isAllowedImage(mala)).toBe('Formato no permitido (JPG, PNG o WEBP)')

    const grande = new File(['x'.repeat(10)], 'grande.png', { type: 'image/png' })
    expect(isAllowedImage(grande, { maxBytes: 4 })).toContain('tamaño máximo')
  })
})
