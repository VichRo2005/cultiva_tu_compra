<script setup>
/**
 * CuTuCo — Aviso de la galería de vistas (herramienta de desarrollo).
 *
 * Se monta desde `layouts/AppShell.vue` y `layouts/AuthLayout.vue`. Informa dos
 * cosas: que la interfaz está en desarrollo y, cuando corresponde, que los datos
 * son de ejemplo porque la base de datos no está conectada (modo demostración).
 */
import { computed } from 'vue'
import CtIcon from '@/components/base/CtIcon.vue'
import { MODO_DEMO } from '@/lib/supabase'

defineEmits(['open-gallery'])

const etiquetaDemo = computed(() =>
  MODO_DEMO.value
    ? 'Modo demostración · datos de ejemplo (sin base de datos)'
    : 'Vistas en Desarrollo',
)
</script>

<template>
  <div class="dev-banner" :class="{ 'is-demo': MODO_DEMO }" role="status">
    <div class="dev-banner__inner">
      <span class="dev-banner__badge">
        <CtIcon :name="MODO_DEMO ? 'info' : 'alert'" :size="16" />
        {{ etiquetaDemo }}
      </span>
      <span v-if="MODO_DEMO" class="dev-banner__hint">
        Las cuentas demo funcionan sin Docker; el checkout con Webpay requiere el backend.
      </span>
      <button type="button" class="dev-banner__action" @click="$emit('open-gallery')">
        <CtIcon name="grid" :size="16" />
        Ver todas las ventanas
      </button>
    </div>
  </div>
</template>

<style scoped>
.dev-banner {
  background: var(--ct-warning-soft);
  border-bottom: 1px solid var(--ct-warning-border);
  color: var(--ct-warning-ink);
}

.dev-banner__inner {
  max-width: var(--ct-container);
  margin-inline: auto;
  padding: 10px var(--ct-space-6);
  display: flex;
  align-items: center;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
}

.dev-banner__badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-right: auto;
  padding: 5px 12px;
  border-radius: 999px;
  background: var(--ct-warning);
  color: var(--ct-accent-ink);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-wide);
  text-transform: uppercase;
  white-space: nowrap;
}

.dev-banner__action {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 7px 14px;
  border: 1px solid var(--ct-warning-border);
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface);
  color: var(--ct-warning-ink);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  cursor: pointer;
  transition:
    background var(--ct-transition),
    border-color var(--ct-transition);
}

/* Modo demostración: el aviso pasa a tono informativo azulado. */
.dev-banner.is-demo {
  background: var(--ct-info-soft);
  border-bottom-color: var(--ct-info-border);
  color: var(--ct-info-ink);
}

.dev-banner.is-demo .dev-banner__badge {
  background: var(--ct-info);
  color: var(--ct-text-invert);
}

.dev-banner.is-demo .dev-banner__action {
  border-color: var(--ct-info-border);
  color: var(--ct-info-ink);
}

.dev-banner.is-demo .dev-banner__action:hover {
  background: var(--ct-info);
  border-color: var(--ct-info);
  color: var(--ct-text-invert);
}

.dev-banner__hint {
  font-size: var(--ct-fs-xs);
  color: inherit;
  opacity: 0.85;
}

.dev-banner__action:hover {
  background: var(--ct-warning);
  border-color: var(--ct-warning);
  color: var(--ct-accent-ink);
}
</style>