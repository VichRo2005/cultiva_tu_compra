<script setup>
/**
 * CuTuCo — Mi Postulación (RF-021).
 *
 * El solicitante nace cliente y su postulación vive en una ÚNICA fila
 * (postulaciones_vendedores) con estados borrador -> en_revision ->
 * aprobada/rechazada (migración 20261010020000). Esta vista permite:
 *   - recuperar automáticamente los documentos y datos bancarios ingresados
 *     antes de confirmar el correo, y completar el borrador (intento = 1),
 *   - corregir una rechazada reemplazando documentos y datos,
 *   - reenviar la MISMA postulación (el trigger suma intento y conserva el
 *     historial en postulaciones_revisiones),
 *   - revisar el historial íntegro de decisiones y observaciones.
 *
 * En en_revision / aprobada queda en solo lectura: la RLS de la base de datos
 * (postulaciones_update_borrador_rechazada) es la barrera real y el trigger
 * validar_postulacion_estado impide modificar una solicitud bajo revisión.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_POSTULACION, BANCOS_DISPONIBLES, LABELS, TIPOS_CUENTA_BANCARIA } from '@/lib/constants'
import { formatDateTime } from '@/lib/format'
import {
  isNumeroCuentaBancaria,
  isDeptoOficina,
  isNombrePropio,
  isNumeroDireccion,
  isPhone,
  isReferenciaDireccion,
  isRut,
  isTitularCuenta,
  LIMITES,
  maxLength,
} from '@/lib/validation'
import { createDireccion, listDirecciones, updateDireccion } from '@/services/geography'
import { getDatosBancarios, guardarDatosBancarios } from '@/services/seller'
import { useAuthStore } from '@/stores/auth'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import {
  actualizarPostulacion,
  crearPostulacion,
  formatearRut,
  limpiarBorradorLocal,
  limpiarBorradorProtegidoLocal,
  guardarDocumentosBorrador,
  leerBorradorLocal,
  leerBorradorProtegidoLocal,
  listarMisRevisiones,
  obtenerMiPostulacion,
  reenviarPostulacion,
  subirDocumentoPostulacion,
  validarDocumentoPostulante,
  verDocumentoPostulacion,
} from '@/services/registro'

const router = useRouter()
const ui = useUiStore()
const auth = useAuthStore()
const geo = useGeographyStore()

const cargando = ref(true)
const errorCarga = ref(null)
const postulacion = ref(null)
const revisiones = ref([])
const borradorLocal = ref(null)
const borradorProtegido = ref(null)
/** E1 — dirección activa y teléfono que el solicitante ya registró. */
const direccion = ref(null)
const datosContacto = ref({ nombre: '', apellido: '', telefono: '' })
const direccionForm = ref({
  id: null,
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
  regionId: '',
  comunaId: '',
})
const erroresContacto = ref({})
const guardandoContacto = ref(false)
const datosBancarios = ref(null)
const guardandoBanco = ref(false)
const erroresBanco = ref({})
const bancoForm = ref({
  banco: '',
  tipoCuenta: '',
  numeroCuenta: '',
  titular: '',
  rutTitular: '',
})
/** C2 — descarga/preview de documentos propios en curso. */
const abriendo = ref({})

const form = ref({
  nombreComercial: '',
  descripcion: '',
  tipoPersona: 'natural',
  rutSolicitante: '',
})
const documentos = ref({
  documentoIdentidad: null,
  certificadoActividadesOCarnet: null,
  certificadoTitularidad: null,
  comprobanteDomicilio: null,
})
const errores = ref({})
const guardando = ref(false)
const enviando = ref(false)

const CAMPOS_DOCUMENTO = [
  { clave: 'documentoIdentidad', etiquetaNatural: 'Cédula de identidad', etiquetaJuridica: 'E-RUT de la empresa' },
  {
    clave: 'certificadoActividadesOCarnet',
    etiquetaNatural: 'Certificado de inicio de actividades (SII)',
    etiquetaJuridica: 'Cédula del representante legal',
  },
  {
    clave: 'certificadoTitularidad',
    etiquetaNatural: 'Certificado de titularidad bancaria',
    etiquetaJuridica: 'Certificado de titularidad bancaria de la empresa',
  },
  { clave: 'comprobanteDomicilio', etiquetaNatural: 'Comprobante de domicilio', etiquetaJuridica: 'Comprobante de domicilio tributario' },
]

const COLUMNAS_DOCUMENTO = {
  documentoIdentidad: 'documento_identidad',
  certificadoActividadesOCarnet: 'certificado_inicio_actividades_o_carnet_representante',
  certificadoTitularidad: 'certificado_titularidad_bancaria',
  comprobanteDomicilio: 'comprobante_domicilio',
}

const editable = computed(
  () =>
    Boolean(postulacion.value) &&
    ['borrador', ESTADO_POSTULACION.RECHAZADA].includes(postulacion.value.estado) &&
    !intentosAgotados.value,
)
const rechazada = computed(() => postulacion.value?.estado === ESTADO_POSTULACION.RECHAZADA)
const enRevision = computed(() =>
  postulacion.value && [ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(postulacion.value.estado),
)
const aprobada = computed(() => postulacion.value?.estado === ESTADO_POSTULACION.APROBADA)

const COLUMNAS_REVISIONES = [
  { key: 'intento', label: 'Intento', width: '90px' },
  { key: 'estado', label: 'Decisión' },
  { key: 'observaciones', label: 'Observaciones del administrador' },
  { key: 'fecha', label: 'Fecha', align: 'right' },
]

const OPCIONES_TIPO = [
  { value: 'natural', label: 'Persona natural' },
  { value: 'juridica', label: 'Persona jurídica (empresa)' },
]

const OPCIONES_BANCO = BANCOS_DISPONIBLES.map((b) => ({ value: b, label: b }))
const OPCIONES_CUENTA = TIPOS_CUENTA_BANCARIA
const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((region) => ({ value: region.id, label: region.nombre })),
)
const opcionesComuna = computed(() =>
  geo.comunasDeRegion(direccionForm.value.regionId).map((comuna) => ({
    value: comuna.id,
    label: comuna.nombre,
  })),
)

function etiquetaDocumento(campo) {
  return form.value.tipoPersona === 'juridica' ? campo.etiquetaJuridica : campo.etiquetaNatural
}

/** Documento ya guardado en la postulación (ruta en la BD). */
function documentoGuardado(clave) {
  const columna = COLUMNAS_DOCUMENTO[clave]
  return postulacion.value?.[columna] ?? null
}

/** Nombre de archivo amigable a partir de la ruta de Storage. */
function nombreGuardado(ruta) {
  if (!ruta) return null
  return ruta.split('/').pop() ?? null
}

/** Documentos finales al enviar: el nuevo (si se reemplazó) o el guardado. */
function documentosCompletos() {
  return CAMPOS_DOCUMENTO.every((campo) => documentos.value[campo.clave] || documentoGuardado(campo.clave))
}

function subirDocumento(clave, event) {
  const file = event?.target?.files?.[0] ?? null
  if (event?.target) event.target.value = ''
  // C3: formato, tamaño y archivos vacíos se validan antes de subir.
  const rechazo = validarDocumentoPostulante(file)
  if (rechazo) {
    errores.value = { ...errores.value, [clave]: rechazo }
    documentos.value[clave] = null
    return
  }
  const limpio = { ...errores.value }
  delete limpio[clave]
  errores.value = limpio
  documentos.value[clave] = file
}

/** C2: abre un documento YA guardado con URL firmada de 60 s. */
async function abrirDocumentoGuardado(clave, ruta) {
  if (!ruta || abriendo.value[clave]) return
  abriendo.value = { ...abriendo.value, [clave]: true }
  try {
    await verDocumentoPostulacion(ruta)
  } catch (e) {
    ui.error('Documento no disponible', e.message)
  } finally {
    abriendo.value = { ...abriendo.value, [clave]: false }
  }
}

/** F: ¿el límite de intentos ya está agotado? */
const intentosAgotados = computed(() => {
  if (!postulacion.value) return false
  return (
    (postulacion.value.intento ?? 1) >= 3 + (postulacion.value.intentos_extra ?? 0) &&
    postulacion.value.estado === ESTADO_POSTULACION.RECHAZADA
  )
})

function quitarSeleccion(clave) {
  documentos.value[clave] = null
}

function validarFormulario() {
  const errs = {}
  // A3/A7: límites del esquema validados antes de enviar.
  if (!form.value.nombreComercial.trim()) errs.nombreComercial = 'Ingresa el nombre de tu tienda'
  else if (!maxLength(form.value.nombreComercial, LIMITES.nombreComercial))
    errs.nombreComercial = `El nombre comercial no puede superar ${LIMITES.nombreComercial} caracteres`
  if (form.value.descripcion && !maxLength(form.value.descripcion, LIMITES.descripcion))
    errs.descripcion = `La descripción no puede superar ${LIMITES.descripcion} caracteres`
  if (!['natural', 'juridica'].includes(form.value.tipoPersona)) errs.tipoPersona = 'Selecciona el tipo de persona'
  if (!isRut(form.value.rutSolicitante)) errs.rutSolicitante = 'RUT inválido (formato 12.345.678-9)'
  errores.value = errs
  return Object.keys(errs).length === 0
}

function cargarFormulario(p) {
  form.value = {
    nombreComercial: p?.nombre_comercial_solicitado ?? '',
    descripcion: p?.descripcion ?? '',
    tipoPersona: p?.tipo_de_persona ?? 'natural',
    rutSolicitante: formatearRut(p?.rut_solicitante),
  }
}

function cargarDatosContacto() {
  datosContacto.value = {
    nombre: auth.perfil?.nombre ?? '',
    apellido: auth.perfil?.apellido ?? '',
    telefono: auth.perfil?.telefono ?? '',
  }
  direccionForm.value = {
    id: direccion.value?.id ?? null,
    calle: direccion.value?.calle ?? '',
    numero: direccion.value?.numero ?? '',
    deptoOficina: direccion.value?.depto_oficina ?? '',
    referencia: direccion.value?.referencia ?? '',
    regionId: direccion.value?.comuna_id ? geo.regionDeComuna(direccion.value.comuna_id) ?? '' : '',
    comunaId: direccion.value?.comuna_id ?? '',
  }
}

function limpiarOpcionesComunaIncompatibles() {
  const pertenece = opcionesComuna.value.some((comuna) => comuna.value === direccionForm.value.comunaId)
  if (!pertenece) direccionForm.value.comunaId = ''
}

watch(() => direccionForm.value.regionId, limpiarOpcionesComunaIncompatibles)

// La geografía se carga de manera no bloqueante. Cuando termina después de la
// postulación, completa la región de una dirección existente sin borrar una
// selección que el usuario ya haya empezado a editar.
watch(
  () => geo.cargado,
  (cargado) => {
    if (!cargado || direccionForm.value.regionId || !direccion.value?.comuna_id) return
    direccionForm.value.regionId = geo.regionDeComuna(direccion.value.comuna_id) ?? ''
  },
)

function validarDatosContacto() {
  const errs = {}
  const nombre = String(datosContacto.value.nombre ?? '').trim()
  const apellido = String(datosContacto.value.apellido ?? '').trim()
  const telefono = String(datosContacto.value.telefono ?? '').trim()
  const calle = String(direccionForm.value.calle ?? '').trim()
  if (!isNombrePropio(nombre) || !maxLength(nombre, LIMITES.nombre)) errs.nombre = 'Ingresa un nombre válido'
  if (!isNombrePropio(apellido) || !maxLength(apellido, LIMITES.apellido)) errs.apellido = 'Ingresa un apellido válido'
  if (!isPhone(telefono)) errs.telefono = 'Ingresa un teléfono chileno válido'
  if (!calle || !maxLength(calle, LIMITES.calle)) errs.calle = 'Ingresa una calle válida'
  if (!direccionForm.value.regionId) errs.regionId = 'Selecciona una región'
  if (!direccionForm.value.comunaId) errs.comunaId = 'Selecciona una comuna'
  if (!isNumeroDireccion(direccionForm.value.numero)) {
    errs.numero = `El Nro./Altura de calle no puede superar ${LIMITES.numero} caracteres`
  }
  if (!isDeptoOficina(direccionForm.value.deptoOficina)) {
    errs.deptoOficina = `El complemento no puede superar ${LIMITES.deptoOficina} caracteres`
  }
  if (!isReferenciaDireccion(direccionForm.value.referencia)) {
    errs.referencia = `La referencia no puede superar ${LIMITES.referencia} caracteres`
  }
  erroresContacto.value = errs
  return Object.keys(errs).length === 0
}

/** Guarda los datos que administración debe poder contrastar al reevaluar la solicitud. */
async function guardarDatosContacto({ silencioso = false } = {}) {
  if (!validarDatosContacto()) {
    if (!silencioso) ui.warning('Revisa tus datos', 'Completa los datos personales y la dirección marcados.')
    return false
  }
  guardandoContacto.value = true
  try {
    await auth.updatePerfil({ ...datosContacto.value })
    const opcional = (valor) => String(valor ?? '').trim() || null
    const datosDireccion = {
      comuna_id: direccionForm.value.comunaId,
      calle: String(direccionForm.value.calle).trim(),
      numero: opcional(direccionForm.value.numero),
      depto_oficina: opcional(direccionForm.value.deptoOficina),
      referencia: opcional(direccionForm.value.referencia),
    }
    direccion.value = direccionForm.value.id
      ? await updateDireccion(direccionForm.value.id, datosDireccion)
      : await createDireccion({
          perfilId: auth.perfil.id,
          etiqueta: 'Dirección de postulación',
          esPrincipal: true,
          comunaId: datosDireccion.comuna_id,
          calle: datosDireccion.calle,
          numero: datosDireccion.numero,
          deptoOficina: datosDireccion.depto_oficina,
          referencia: datosDireccion.referencia,
        })
    cargarDatosContacto()
    if (!silencioso) ui.success('Datos actualizados', 'Guardamos tu información para la nueva revisión.')
    return true
  } catch (e) {
    if (!silencioso) ui.error('No se pudieron guardar tus datos', e.message)
    return false
  } finally {
    guardandoContacto.value = false
  }
}

/** Da formato visible al salir del campo; la persistencia sigue normalizando sin puntos. */
function formatearRutVisible(campo) {
  if (campo === 'rutSolicitante') {
    form.value.rutSolicitante = formatearRut(form.value.rutSolicitante)
    return
  }
  bancoForm.value.rutTitular = formatearRut(bancoForm.value.rutTitular)
}

async function cargar() {
  cargando.value = true
  errorCarga.value = null
  try {
    if (!auth.user) {
      await router.replace('/login')
      return
    }
    if (!auth.perfil?.id) {
      throw new Error(
        'Tu cuenta quedó incompleta. Vuelve a iniciar sesión o completa tu registro antes de abrir Mi Postulación.',
      )
    }
    // La solicitud y sus documentos no dependen de que el selector de
    // geografía termine de descargar; evita dejar esta vista bloqueada.
    void geo.load()
    borradorLocal.value = leerBorradorLocal()
    borradorProtegido.value = await leerBorradorProtegidoLocal(auth.perfil.id)
    const propia = await obtenerMiPostulacion()
    postulacion.value = propia
    // E1: dirección activa del solicitante (misma que usará el administrador).
    if (auth.perfil?.id) {
      const direcciones = await listDirecciones({ perfilId: auth.perfil.id })
      direccion.value = direcciones.find((d) => d.es_principal) ?? direcciones[0] ?? null
      cargarDatosContacto()
      datosBancarios.value = await getDatosBancarios().catch(() => null)
      hidratarBanco()
    }
    if (propia) {
      cargarFormulario(propia)
      revisiones.value = await listarMisRevisiones(propia.id)
      await restaurarBorradorProtegido()
      if (propia.estado !== ESTADO_POSTULACION.RECHAZADA) limpiarBorradorLocal()
    } else if (borradorLocal.value) {
      form.value = {
        nombreComercial: borradorLocal.value.nombreComercial ?? '',
        descripcion: borradorLocal.value.descripcion ?? '',
        tipoPersona: borradorLocal.value.tipoPersona ?? 'natural',
        rutSolicitante: formatearRut(borradorLocal.value.rutSolicitante),
      }
    }
  } catch (e) {
    // No se debe mostrar «Aún no tienes una postulación» cuando en realidad
    // falló la consulta: eso llevaría al usuario a crear una duplicada.
    errorCarga.value = e?.message ?? 'No se pudo cargar tu postulación'
  } finally {
    cargando.value = false
  }
}

/**
 * Completa el tramo que no podía ejecutarse antes de confirmar el correo: los
 * archivos ya elegidos pasan al bucket privado y la cuenta bancaria llega al
 * endpoint que la cifra. Nunca cambia el estado de la postulación: el envío a
 * revisión sigue siendo una acción explícita del solicitante.
 */
async function restaurarBorradorProtegido() {
  const respaldo = borradorProtegido.value
  const perfilId = auth.perfil?.id
  if (!respaldo || !perfilId || !postulacion.value) return

  const pendientes = []
  let bancoListo = Boolean(datosBancarios.value)
  if (!bancoListo && respaldo.datosBancarios?.numeroCuenta) {
    bancoForm.value = { ...bancoForm.value, ...respaldo.datosBancarios }
    try {
      await guardarDatosBancarios(respaldo.datosBancarios)
      datosBancarios.value = await getDatosBancarios()
      hidratarBanco()
      bancoListo = true
    } catch (e) {
      pendientes.push(`datos bancarios: ${e.message}`)
    }
  }

  const rutas = {}
  for (const campo of CAMPOS_DOCUMENTO) {
    const clave = campo.clave
    const file = respaldo.documentos?.[clave]
    if (!file || documentoGuardado(clave)) continue
    try {
      rutas[clave] = await subirDocumentoPostulacion(perfilId, clave, file)
    } catch (e) {
      // Se conserva en memoria y en el respaldo cifrado para reintentar sin
      // pedir al solicitante que vuelva a elegir el archivo.
      documentos.value[clave] = file
      pendientes.push(`${etiquetaDocumento(campo)}: ${e.message}`)
    }
  }
  if (Object.keys(rutas).length) {
    try {
      const actualizada = await guardarDocumentosBorrador(postulacion.value.id, rutas)
      if (actualizada) postulacion.value = { ...postulacion.value, ...actualizada }
    } catch (e) {
      for (const clave of Object.keys(rutas)) {
        documentos.value[clave] = respaldo.documentos?.[clave] ?? null
        pendientes.push(`${etiquetaDocumento(CAMPOS_DOCUMENTO.find((campo) => campo.clave === clave))}: ${e.message}`)
      }
    }
  }

  const documentosListos = CAMPOS_DOCUMENTO.every(
    (campo) => documentoGuardado(campo.clave) || !respaldo.documentos?.[campo.clave],
  )
  if (bancoListo && documentosListos && !pendientes.length) {
    await limpiarBorradorProtegidoLocal(perfilId)
    borradorProtegido.value = null
    ui.success(
      'Datos del registro recuperados',
      'Guardamos los documentos en tu expediente privado y los datos bancarios cifrados. Revisa la solicitud y envíala a revisión cuando estés listo.',
    )
  } else if (pendientes.length) {
    ui.warning(
      'Quedaron datos por recuperar',
      'Conservamos el respaldo temporal cifrado en este navegador para reintentar: ' + pendientes.join(' · '),
    )
  }
}

function hidratarBanco() {
  bancoForm.value = {
    banco: datosBancarios.value?.banco ?? '',
    tipoCuenta: datosBancarios.value?.tipo_cuenta ?? '',
    // La API entrega este valor únicamente al dueño autenticado. Precargarlo
    // evita que una corrección menor obligue a reescribir toda la cuenta.
    numeroCuenta: datosBancarios.value?.numero_cuenta ?? '',
    titular: datosBancarios.value?.titular_cuenta ?? auth.nombreCompleto ?? '',
    rutTitular: formatearRut(datosBancarios.value?.rut_titular),
  }
}

// Banco -> campos dependientes: limpiar tipo y número al cambiarlo.
watch(
  () => bancoForm.value.banco,
  (nuevo, anterior) => {
    if (!anterior || nuevo === anterior) return
    bancoForm.value.tipoCuenta = ''
    bancoForm.value.numeroCuenta = ''
    erroresBanco.value = {}
  },
)

async function guardarBanco() {
  erroresBanco.value = {}
  const errores = {}
  if (!bancoForm.value.banco) errores.banco = 'Selecciona el banco'
  if (!bancoForm.value.tipoCuenta) errores.tipoCuenta = 'Selecciona el tipo de cuenta'
  if (!bancoForm.value.numeroCuenta.trim()) {
    errores.numeroCuenta = 'Ingresa el nuevo número de cuenta'
  } else if (!isNumeroCuentaBancaria(bancoForm.value.numeroCuenta, bancoForm.value.tipoCuenta)) {
    errores.numeroCuenta = 'El número no es válido para el tipo de cuenta elegido'
  }
  if (!isTitularCuenta(bancoForm.value.titular)) {
    errores.titular = 'Ingresa el nombre o razón social del titular'
  }
  if (!isRut(bancoForm.value.rutTitular)) {
    errores.rutTitular = 'RUT inválido (formato 12.345.678-9)'
  }
  erroresBanco.value = errores
  if (Object.keys(errores).length) {
    ui.warning('Revisa los datos bancarios', 'Hay campos obligatorios o con formato inválido')
    return
  }

  guardandoBanco.value = true
  try {
    await guardarDatosBancarios({
      banco: bancoForm.value.banco,
      tipoCuenta: bancoForm.value.tipoCuenta,
      numeroCuenta: bancoForm.value.numeroCuenta,
      titular: bancoForm.value.titular,
      rutTitular: bancoForm.value.rutTitular,
    })
    datosBancarios.value = await getDatosBancarios()
    hidratarBanco()
    ui.success(
      'Datos bancarios actualizados',
      'El número quedó cifrado y actualizado para los próximos pagos.',
    )
  } catch (e) {
    ui.error('No se pudieron actualizar los datos bancarios', e.message)
  } finally {
    guardandoBanco.value = false
  }
}

/**
 * A1: si GoTrue exigió confirmar el correo, el registro NO crea la postulación.
 * Con el borrador local guardado, aquí se crea la postulación única (borrador,
 * intento 1) con esos datos y el usuario continúa en esta misma vista.
 */
async function crearDesdeBorradorLocal() {
  if (!borradorLocal.value) return
  guardando.value = true
  try {
    const creada = await crearPostulacion({
      perfilId: auth.perfil.id,
      nombreComercial: form.value.nombreComercial,
      descripcion: form.value.descripcion,
      rutSolicitante: form.value.rutSolicitante,
      tipoPersona: form.value.tipoPersona,
    })
    postulacion.value = creada
    revisiones.value = await listarMisRevisiones(creada.id)
    await restaurarBorradorProtegido()
    limpiarBorradorLocal()
    borradorLocal.value = null
    ui.success('Postulación creada', 'Completa los documentos y envíala a revisión.')
  } catch (e) {
    ui.error('No se pudo crear la postulación', e.message)
  } finally {
    guardando.value = false
  }
}

async function guardarBorrador() {
  if (!validarFormulario()) {
    ui.warning('Revisa el formulario', 'Hay campos inválidos marcados en rojo.')
    return
  }
  guardando.value = true
  try {
    if (!(await guardarDatosContacto({ silencioso: true }))) return
    const actualizada = await actualizarPostulacion(postulacion.value.id, form.value)
    postulacion.value = { ...postulacion.value, ...actualizada }
    ui.success('Borrador guardado', 'Puedes completar el resto cuando quieras.')
  } catch (e) {
    ui.error('No se pudo guardar', e.message)
  } finally {
    guardando.value = false
  }
}

/**
 * Envía (o reenvía) la postulación a revisión: sube los documentos nuevos y
 * hace UN único UPDATE con estado en_revision. Si venía rechazada, el trigger
 * incrementa el intento y archiva la revisión anterior.
 */
async function enviarRevision() {
  if (!validarFormulario()) {
    ui.warning('Revisa el formulario', 'Hay campos inválidos marcados en rojo.')
    return
  }
  if (!documentosCompletos()) {
    ui.warning('Documentos incompletos', 'Adjunta los cuatro documentos requeridos antes de enviar.')
    return
  }
  enviando.value = true
  try {
    if (!(await guardarDatosContacto({ silencioso: true }))) {
      ui.warning('Revisa tus datos', 'Completa los datos personales y la dirección antes de reenviar.')
      return
    }
    await actualizarPostulacion(postulacion.value.id, form.value)
    const perfilId = auth.perfil.id
    const rutasNuevas = {}
    for (const campo of CAMPOS_DOCUMENTO) {
      const file = documentos.value[campo.clave]
      if (file) {
        const resultado = await subirDocumentoPostulacion(perfilId, campo.clave, file)
        rutasNuevas[campo.clave] = resultado
      }
    }
    const enviada = await reenviarPostulacion({
      perfilId,
      postulacionId: postulacion.value.id,
      rutasNuevas,
    })
    postulacion.value = { ...postulacion.value, ...enviada }
    revisiones.value = await listarMisRevisiones(postulacion.value.id)
    documentos.value = { documentoIdentidad: null, certificadoActividadesOCarnet: null, certificadoTitularidad: null, comprobanteDomicilio: null }
    limpiarBorradorLocal()
    ui.success(
      'Solicitud enviada a revisión',
      'Intento ' + enviada.intento + '. El administrador revisará tus antecedentes.',
    )
  } catch (e) {
    ui.error('No se pudo enviar la postulación', e.message)
  } finally {
    enviando.value = false
  }
}

function irABloqueProductores() {
  router.push({ name: 'home', hash: '#quiero-vender-en-cutuco' })
}

onMounted(cargar)
</script>
<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Mi Postulación</h1>
        <p class="page-head__subtitle">
          Tu solicitud para vender en CuTuCo: complétala, corrígela y reenvíala cuando lo necesites.
        </p>
      </div>
      <div v-if="postulacion" class="page-head__actions">
        <CtBadge tone="neutral" size="md">Intento {{ postulacion.intento }}</CtBadge>
        <StatusBadge type="postulacion" :value="postulacion.estado" />
      </div>
    </header>

    <CtAlert v-if="errorCarga" tone="danger" title="No pudimos cargar tu postulación">
      <p>{{ errorCarga }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-else-if="cargando" label="Cargando tu postulación…" />

    <template v-else>
      <!-- Sin postulación: nueva o recuperada del borrador local (A1) -->
      <CtCard v-if="!postulacion" padding="md">
        <CtAlert v-if="borradorLocal" tone="info" title="Continúa tu registro como vendedor">
          <p>
            Guardamos los datos que enviaste al crear tu cuenta. Revísalos, modifica lo que
            necesites y crea tu postulación; después podrás adjuntar los documentos.
          </p>
          <CtButton :loading="guardando" @click="crearDesdeBorradorLocal">Crear mi postulación</CtButton>
        </CtAlert>
        <CtAlert v-else tone="neutral" title="Aún no tienes una postulación">
          <p>Inicia tu solicitud de vendedor para publicar en el catálogo.</p>
          <CtButton @click="irABloqueProductores">Quiero vender en CuTuCo</CtButton>
        </CtAlert>

        <form v-if="borradorLocal" class="mi-post__form" @submit.prevent>
          <CtInput v-model="form.nombreComercial" label="Nombre comercial" :error="errores.nombreComercial" />
          <CtTextarea v-model="form.descripcion" label="Descripción de tu tienda" :rows="3" />
          <CtSelect v-model="form.tipoPersona" label="Tipo de persona" :options="OPCIONES_TIPO" :error="errores.tipoPersona" />
          <CtInput
            v-model="form.rutSolicitante"
            label="RUT del solicitante"
            :error="errores.rutSolicitante"
            @blur="formatearRutVisible('rutSolicitante')"
          />
        </form>
      </CtCard>

      <template v-else>
        <!-- Aviso de rechazo con observaciones (§6.3) -->
        <CtAlert
          v-if="intentosAgotados"
          tone="warning"
          title="Alcanzaste el máximo de 3 intentos"
        >
          <p>
            Tu solicitud fue rechazada {{ postulacion.intento }} veces y ya no admite reenvíos
            automáticos. Escribe al equipo de CuTuCo por el canal de soporte: un administrador puede
            autorizar intentos adicionales dejando registro de la decisión.
          </p>
        </CtAlert>
        <CtAlert v-else-if="rechazada && postulacion.observaciones_admin" tone="danger" title="Tu solicitud fue rechazada">
          <p>Observaciones del administrador: {{ postulacion.observaciones_admin }}</p>
          <p>
            Corrige lo señalado y reenvía la misma postulación: quedará como intento
            {{ postulacion.intento + 1 }}.
          </p>
        </CtAlert>
        <CtAlert v-else-if="enRevision" tone="warning" title="Solicitud en revisión">
          <p>
            El administrador está revisando tus antecedentes. Mientras dura la revisión no puedes
            modificar los datos ni los documentos.
          </p>
        </CtAlert>
        <CtAlert v-else-if="aprobada" tone="success" title="¡Tu postulación fue aprobada!">
          <p>Tu tienda ya está activa. Revisa el panel del vendedor para publicar productos.</p>
        </CtAlert>

        <!-- E1: todos los datos que el usuario entregó en su postulación y
             su cuenta, coherentes con lo que revisa el administrador. -->
        <CtCard padding="md">
          <h2 class="eyebrow">Tus datos registrados</h2>
          <form v-if="editable" class="mi-post__form" @submit.prevent="guardarDatosContacto">
            <p class="mi-post__nota text-sm text-muted">
              Corrige aquí los datos observados por administración. Se guardan junto con el reenvío de tu solicitud.
            </p>
            <div class="mi-post__fila">
              <CtInput
                v-model="datosContacto.nombre"
                label="Nombre del solicitante"
                :maxlength="LIMITES.nombre"
                :error="erroresContacto.nombre"
                required
              />
              <CtInput
                v-model="datosContacto.apellido"
                label="Apellido del solicitante"
                :maxlength="LIMITES.apellido"
                :error="erroresContacto.apellido"
                required
              />
            </div>
            <CtInput
              v-model="datosContacto.telefono"
              label="Teléfono de contacto"
              placeholder="+56 9 1234 5678"
              :maxlength="LIMITES.telefono"
              :error="erroresContacto.telefono"
              required
            />
            <h3 class="eyebrow">Dirección completa</h3>
            <div class="mi-post__fila">
              <CtSelect
                v-model="direccionForm.regionId"
                label="Región"
                :options="opcionesRegion"
                placeholder="Selecciona tu región"
                :error="erroresContacto.regionId"
                required
              />
              <CtSelect
                v-model="direccionForm.comunaId"
                label="Comuna"
                :options="opcionesComuna"
                :disabled="!direccionForm.regionId"
                placeholder="Selecciona tu comuna"
                :error="erroresContacto.comunaId"
                required
              />
            </div>
            <div class="mi-post__fila">
              <CtInput
                v-model="direccionForm.calle"
                label="Calle"
                :maxlength="LIMITES.calle"
                :error="erroresContacto.calle"
                required
              />
              <CtInput
                v-model="direccionForm.numero"
                label="Nro./Altura de calle"
                :maxlength="LIMITES.numero"
                :error="erroresContacto.numero"
              />
            </div>
            <div class="mi-post__fila">
              <CtInput
                v-model="direccionForm.deptoOficina"
                label="Depto., oficina, casa o parcela"
                :maxlength="LIMITES.deptoOficina"
                :error="erroresContacto.deptoOficina"
              />
              <CtInput
                v-model="direccionForm.referencia"
                label="Referencia para llegar"
                :maxlength="LIMITES.referencia"
                :error="erroresContacto.referencia"
              />
            </div>
            <CtButton type="submit" variant="secondary" :loading="guardandoContacto">
              Guardar datos personales y dirección
            </CtButton>
          </form>
          <dl v-else class="mi-post__datos">
            <div>
              <dt>Correo de la cuenta</dt>
              <dd class="mono">{{ auth.email || '—' }}</dd>
            </div>
            <div>
              <dt>Nombre del solicitante</dt>
              <dd>{{ [auth.perfil?.nombre, auth.perfil?.apellido].filter(Boolean).join(' ') || '—' }}</dd>
            </div>
            <div>
              <dt>Teléfono de contacto</dt>
              <dd>{{ auth.perfil?.telefono || 'Sin teléfono registrado' }}</dd>
            </div>
            <div>
              <dt>Dirección activa (cobertura)</dt>
              <dd>
                <template v-if="direccion">
                  {{ direccion.calle }} {{ direccion.numero ?? '' }}
                  <span class="text-muted">{{ direccion.referencia ? '· ' + direccion.referencia : '' }}</span>
                </template>
                <template v-else>
                  Sin dirección activa: es requisito para aprobar tu cuenta
                </template>
              </dd>
            </div>
            <div>
              <dt>Presentada</dt>
              <dd>{{ formatDateTime(postulacion.creado_en) }}</dd>
            </div>
            <div>
              <dt>Última actualización</dt>
              <dd>{{ formatDateTime(postulacion.actualizado_en) }}</dd>
            </div>
          </dl>
        </CtCard>

        <!-- Datos bancarios: editables mientras la postulación está en borrador o
             rechazada. Una vez aprobada, se centralizan en Perfil de tienda
             (HAL-VEN-008): aquí sólo queda el resumen de lectura. -->
        <CtCard padding="md">
          <h2 class="eyebrow">Datos bancarios para pagos</h2>
          <p class="text-sm text-muted">
            Esta es la cuenta donde recibirás los pagos de tus ventas. La mostramos aquí para que
            sólo tengas que modificar lo necesario.
          </p>
          <p v-if="datosBancarios" class="mi-post__nota">
            Actual: <strong>{{ datosBancarios.banco }}</strong> ·
            {{ datosBancarios.tipo_cuenta?.replaceAll('_', ' ') }} ·
            <span class="mono">{{ datosBancarios.numero_cuenta }}</span> ·
            {{ datosBancarios.titular_cuenta }}
          </p>
          <p v-else class="mi-post__nota text-warning">
            Aún no registras una cuenta bancaria. Agrégala para recibir los pagos de tus ventas.
          </p>

          <template v-if="aprobada">
            <CtAlert tone="info" compact>
              Tu postulación está aprobada y queda como historial de lectura. Los datos bancarios se
              administran desde Perfil de tienda.
            </CtAlert>
            <CtButton v-if="auth.isVendedor" to="/vendedor/tienda" variant="secondary">
              Ir a Perfil de tienda
            </CtButton>
          </template>

          <form v-else-if="editable" class="mi-post__form" @submit.prevent="guardarBanco">
            <div class="mi-post__fila">
              <CtSelect
                v-model="bancoForm.banco"
                label="Banco"
                :options="OPCIONES_BANCO"
                placeholder="Selecciona el banco"
                :error="erroresBanco.banco"
                required
              />
              <CtSelect
                v-model="bancoForm.tipoCuenta"
                label="Tipo de cuenta"
                :options="OPCIONES_CUENTA"
                placeholder="Selecciona el tipo"
                :error="erroresBanco.tipoCuenta"
                required
              />
            </div>
            <CtInput
              v-model="bancoForm.numeroCuenta"
              label="Nuevo número de cuenta"
              placeholder="000123456789"
              hint="Sólo dígitos, entre 7 y 12; se guarda cifrado"
              :error="erroresBanco.numeroCuenta"
              required
            />
            <div class="mi-post__fila">
              <CtInput
                v-model="bancoForm.titular"
                label="Titular de la cuenta"
                :error="erroresBanco.titular"
                required
              />
              <CtInput
                v-model="bancoForm.rutTitular"
                label="RUT del titular"
                :error="erroresBanco.rutTitular"
                required
                @blur="formatearRutVisible('rutTitular')"
              />
            </div>
            <CtButton type="submit" :loading="guardandoBanco">Guardar datos bancarios</CtButton>
          </form>
          <CtAlert v-else tone="info" compact>
            Tu solicitud ya fue enviada a revisión. Los datos bancarios quedan bloqueados hasta que
            exista una decisión; sólo podrás corregirlos y reenviar la solicitud si es rechazada.
          </CtAlert>
        </CtCard>

        <!-- Datos editables (borrador / rechazada) o solo lectura -->
        <CtCard padding="md">
          <h2 class="eyebrow">Datos de la solicitud</h2>
          <form class="mi-post__form" @submit.prevent>
            <CtInput
              v-model="form.nombreComercial"
              label="Nombre comercial"
              :disabled="!editable"
              :error="editable ? errores.nombreComercial : null"
            />
            <CtTextarea v-model="form.descripcion" label="Descripción de tu tienda" :rows="3" :disabled="!editable" />
            <div class="mi-post__fila">
              <CtSelect
                v-model="form.tipoPersona"
                label="Tipo de persona"
                :disabled="!editable"
                :options="OPCIONES_TIPO"
                :error="editable ? errores.tipoPersona : null"
              />
              <CtInput
                v-model="form.rutSolicitante"
                label="RUT del solicitante"
                :disabled="!editable"
                :error="editable ? errores.rutSolicitante : null"
                @blur="formatearRutVisible('rutSolicitante')"
              />
            </div>
          </form>

          <template v-if="editable">
            <h2 class="eyebrow">Documentos</h2>
            <p class="mi-post__nota text-sm text-muted">
              PDF, JPG o PNG (máx. 10 MB cada uno). Si ya subiste un documento, selecciona otro
              archivo sólo para reemplazarlo.
            </p>
            <div class="mi-post__documentos">
              <label v-for="campo in CAMPOS_DOCUMENTO" :key="campo.clave" class="mi-post__doc">
                <span class="mi-post__doc-titulo">{{ etiquetaDocumento(campo) }}</span>
                <span v-if="documentoGuardado(campo.clave)" class="text-xs text-success">
                  <CtIcon name="check" :size="14" />
                  Actual: {{ nombreGuardado(documentoGuardado(campo.clave)) }}
                </span>
                <span v-if="documentos[campo.clave]" class="text-xs">
                  Nuevo: {{ documentos[campo.clave].name }}
                  <button type="button" class="mi-post__doc-quitar" @click="quitarSeleccion(campo.clave)">
                    quitar
                  </button>
                </span>
                <span v-if="errores[campo.clave]" class="mi-post__doc-error">
                  {{ errores[campo.clave] }}
                </span>
                <!-- C2: comprobación del documento ya guardado antes de enviar. -->
                <button
                  v-if="documentoGuardado(campo.clave)"
                  type="button"
                  class="mi-post__doc-ver"
                  :disabled="abriendo[campo.clave]"
                  @click="abrirDocumentoGuardado(campo.clave, documentoGuardado(campo.clave))"
                >
                  {{ abriendo[campo.clave] ? 'Abriendo…' : 'Ver documento actual' }}
                </button>
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"
                  @change="subirDocumento(campo.clave, $event)"
                />
              </label>
            </div>
            <div class="mi-post__acciones">
              <CtButton variant="secondary" :loading="guardando" @click="guardarBorrador">
                Guardar borrador
              </CtButton>
              <CtButton :loading="enviando" @click="enviarRevision">
                {{ rechazada ? 'Reenviar a revisión' : 'Enviar a revisión' }}
              </CtButton>
            </div>
          </template>
          <template v-else>
            <h2 class="eyebrow">Documentos enviados</h2>
            <ul class="mi-post__lista">
              <li v-for="campo in CAMPOS_DOCUMENTO" :key="campo.clave">
                {{ etiquetaDocumento(campo) }}:
                <span v-if="documentoGuardado(campo.clave)" class="mono">
                  {{ nombreGuardado(documentoGuardado(campo.clave)) }}
                </span>
                <span v-else class="text-muted">sin documento</span>
                <button
                  v-if="documentoGuardado(campo.clave)"
                  type="button"
                  class="mi-post__doc-ver"
                  :disabled="abriendo[campo.clave]"
                  @click="abrirDocumentoGuardado(campo.clave, documentoGuardado(campo.clave))"
                >
                  {{ abriendo[campo.clave] ? 'Abriendo…' : 'Ver' }}
                </button>
              </li>
            </ul>
          </template>
        </CtCard>

        <!-- Historial íntegro de revisiones (postulaciones_revisiones) -->
        <CtCard v-if="revisiones.length" padding="md">
          <h2 class="eyebrow">Historial de revisiones</h2>
          <p class="mi-post__nota text-sm text-muted">
            Cada decisión administrativa queda archivada con su intento, sus observaciones y una
            copia de la solicitud evaluada.
          </p>
          <table class="mi-post__tabla">
            <thead>
              <tr>
                <th v-for="col in COLUMNAS_REVISIONES" :key="col.key" :style="{ width: col.width }">
                  {{ col.label }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="rev in revisiones" :key="rev.id">
                <td class="mono">#{{ rev.intento }}</td>
                <td>
                  <CtBadge :tone="rev.estado === 'aprobada' ? 'success' : 'danger'" size="sm">
                    {{ LABELS.postulacion[rev.estado] ?? rev.estado }}
                  </CtBadge>
                </td>
                <td>{{ rev.observaciones_admin ?? '—' }}</td>
                <td class="text-sm text-muted">{{ formatDateTime(rev.revisado_en) }}</td>
              </tr>
            </tbody>
          </table>
        </CtCard>
      </template>
    </template>
  </div>
</template>

<style scoped>
.mi-post__form {
  display: grid;
  gap: var(--ct-space-3);
  margin-block: var(--ct-space-4);
}
.mi-post__fila {
  display: grid;
  gap: var(--ct-space-3);
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
}
.mi-post__documentos {
  display: grid;
  gap: var(--ct-space-3);
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  margin-block: var(--ct-space-3);
}
.mi-post__doc {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
  padding: var(--ct-space-3);
  border: 1px dashed var(--ct-border-strong);
  border-radius: var(--ct-radius);
}
.mi-post__doc-titulo {
  font-weight: var(--ct-fw-medium);
}
.mi-post__doc-quitar {
  border: 0;
  background: none;
  color: var(--ct-danger);
  cursor: pointer;
  text-decoration: underline;
  margin-left: var(--ct-space-2);
}

.mi-post__doc-ver {
  border: 0;
  background: none;
  color: var(--ct-primary-strong);
  cursor: pointer;
  text-decoration: underline;
  font-size: var(--ct-fs-xs);
  margin-left: var(--ct-space-2);
}

.mi-post__doc-ver:disabled {
  cursor: default;
  opacity: 0.6;
}

.mi-post__doc-error {
  display: block;
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
}

.mi-post__datos {
  display: grid;
  gap: var(--ct-space-2);
  margin: 0;
}

.mi-post__datos > div {
  display: grid;
  grid-template-columns: 220px 1fr;
  gap: var(--ct-space-3);
  padding-block: var(--ct-space-1);
  border-bottom: 1px solid var(--ct-border);
}

.mi-post__datos dt {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.mi-post__datos dd {
  margin: 0;
  font-size: var(--ct-fs-sm);
}

@media (max-width: 560px) {
  .mi-post__datos > div {
    grid-template-columns: 1fr;
    gap: 2px;
  }
}
.mi-post__acciones {
  display: flex;
  gap: var(--ct-space-3);
  justify-content: flex-end;
  margin-top: var(--ct-space-4);
}
.mi-post__lista {
  list-style: none;
  padding: 0;
  display: grid;
  gap: var(--ct-space-1);
}
.mi-post__tabla {
  width: 100%;
  border-collapse: collapse;
  margin-top: var(--ct-space-3);
}
.mi-post__tabla th,
.mi-post__tabla td {
  text-align: left;
  padding: var(--ct-space-2) var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
  vertical-align: top;
}
.mi-post__nota {
  margin-block: var(--ct-space-2);
}
</style>
