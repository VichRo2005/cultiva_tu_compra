<script setup>
/**
 * CuTuCo — Dashboard del productor (página 11 del diseño).
 *
 * Resumen real de la tienda conectado a los servicios vigentes:
 *   RF-003  resumen de ventas, inventario y pedidos recibidos
 *   RF-006  reputación = promedio simple de calificaciones de 1 a 5
 *   RF-014  comisión 5% y tarifa fija de delivery; neto sólo de pedidos entregados
 *   RF-021  aviso de cuenta pendiente de aprobación
 *   RF-026  aviso de suspensión o ban permanente (sanciones vigentes)
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Este panel mostraba el score de reputación 40/40/20 (`getDashboardVendedor`,
 *   `Reglas.REPUTACION`, "Métricas de Confianza", pausa automática por score),
 *   las alertas de stock bajo con umbral (RF-010) y las tendencias de precio
 *   (RF-008). Nada de eso existe en el ERS vigente: la reputación es un promedio
 *   de 1 a 5 sin reglas automáticas, el stock se revisa a mano y el historial de
 *   precios salió del alcance. Se reemplazó por `getResumenVentas`,
 *   `listProductosVendedor`, `listSancionesDeProductor` y el estado del store de
 *   autenticación (`postulacionPendiente`, `bloqueoVendor`).
 */
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtChart from '@/components/base/CtChart.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import {
  ESTADO_ENVIO,
  ESTADO_POSTULACION,
  ESTADO_PEDIDO,
  ESTADO_SANCION,
  LABELS,
  REGLAS,
} from '@/lib/constants'
import { exportExcel } from '@/lib/csv'
import { formatCLP, formatDate, formatDateTime, formatDayMonth, formatNumber } from '@/lib/format'
import { netoProductor } from '@/lib/orders'
import { NAV_SECUNDARIO } from '@/lib/navigation'
import { useAsync } from '@/composables/useAsync'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import { listPedidos, getReputacionProductor } from '@/services/orders'
import {
  ESTADOS_VENTA_AUTORIZADA,
  getMiPostulacion,
  getMiProductor,
  getResumenVentas,
  listProductosVendedor,
  listSancionesDeProductor,
} from '@/services/seller'

const auth = useAuthStore()
const ui = useUiStore()
const router = useRouter()

const dias = ref(7)
const tabsSerie = [
  { value: 7, label: '7 días' },
  { value: 30, label: '30 días' },
]

/** Estados de pedido que siguen esperando despacho del vendedor (RF-025). */
const ESTADOS_POR_DESPACHAR = Object.freeze([ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION])

/** Sanciones que restringen la operación de la tienda (RF-026). */
const SANCIONES_VIGENTES = Object.freeze([ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA])

const { data, loading, error, reload } = useAsync(async () => {
  const [postulacion, productorApi, pedidosRes] = await Promise.all([
    getMiPostulacion(),
    getMiProductor(),
    listPedidos({ rol: 'productor', all: true }),
  ])

  const pedidos = pedidosRes.items ?? []
  // Si PostgREST no devuelve la tienda pero el store de sesión ya la cargó, se
  // usa la del store: evita el falso "sin tienda" cuando hay productor activo.
  const productor = productorApi ?? auth.productor ?? null
  const base = { postulacion, productor, pedidos }

  if (!productor?.id) {
    return {
      ...base,
      resumen: null,
      productos: [],
      sanciones: [],
      reputacion: { puntaje: null, cantidad: 0, evaluaciones: [] },
    }
  }

  const [resumen, productos, sanciones, reputacion] = await Promise.all([
    getResumenVentas(productor.id),
    listProductosVendedor({ productorId: productor.id, incluirInactivos: true }),
    listSancionesDeProductor(productor.id).catch(() => []),
    getReputacionProductor(productor.id),
  ])

  return { ...base, resumen, productos, sanciones, reputacion }
})

const postulacion = computed(() => data.value?.postulacion ?? auth.postulacion ?? null)
const productor = computed(() => data.value?.productor ?? auth.productor ?? null)
const pedidos = computed(() => data.value?.pedidos ?? [])
const resumen = computed(() => data.value?.resumen ?? null)
const productos = computed(() => data.value?.productos ?? [])
const reputacion = computed(
  () => data.value?.reputacion ?? { puntaje: null, cantidad: 0, evaluaciones: [] },
)
const sanciones = computed(() => data.value?.sanciones ?? auth.sanciones ?? [])

const sinTienda = computed(() => !loading.value && !error.value && !productor.value)

/* ------------------------------------------------------------------ */
/* Estado de la cuenta (RF-021 y RF-026)                               */
/* ------------------------------------------------------------------ */

const sancionesVigentes = computed(() =>
  sanciones.value.filter((s) => SANCIONES_VIGENTES.includes(s.estado)),
)

const aprobado = computed(
  () =>
    postulacion.value?.estado === ESTADO_POSTULACION.APROBADA &&
    Boolean(productor.value?.aprobado_en),
)

/** Motivo por el que la cuenta no puede vender; null cuando sí puede operar. */
const motivoBloqueo = computed(() => {
  if (auth.bloqueoVendedor) return auth.bloqueoVendedor
  if (postulacion.value?.estado === ESTADO_POSTULACION.RECHAZADA) {
    return postulacion.value.observaciones_admin
      ? `Tu solicitud fue rechazada: ${postulacion.value.observaciones_admin}`
      : 'Tu solicitud de vendedor fue rechazada.'
  }
  if (
    [ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(
      postulacion.value?.estado,
    )
  ) {
    return 'Tu solicitud de vendedor está pendiente de aprobación del administrador. Aún no puedes publicar productos ni gestionar pedidos.'
  }
  if (productor.value && productor.value.activo === false) {
    return 'Tu tienda está desactivada. Contacta al administrador antes de publicar productos.'
  }
  return null
})

/**
 * El vendedor sólo puede operar con la cuenta activa. `auth.puedeOperarTienda`
 * evalúa el estado efectivo (sanciones vencidas, ban, postulación) además de
 * `productor.activo`.
 */
const puedeOperar = computed(
  () =>
    Boolean(auth.puedeOperarTienda) &&
    !motivoBloqueo.value &&
    Boolean(productor.value?.activo) &&
    aprobado.value,
)

const estadoCuenta = computed(() => {
  if (motivoBloqueo.value) {
    const sancion = sancionesVigentes.value.find((s) => s.accion === 'ban_permanente')
    if (sancion) return { tone: 'danger', label: 'Cuenta con ban permanente', icon: 'ban' }
    if (sancionesVigentes.value.length)
      return { tone: 'danger', label: 'Cuenta suspendida', icon: 'ban' }
    if (postulacion.value?.estado === ESTADO_POSTULACION.RECHAZADA) {
      return { tone: 'danger', label: 'Solicitud rechazada', icon: 'alert' }
    }
    if (auth.estaBloqueado) return { tone: 'warning', label: 'Cuenta bloqueada', icon: 'lock' }
    return { tone: 'warning', label: 'Pendiente de aprobación', icon: 'clock' }
  }
  return { tone: 'success', label: 'Cuenta aprobada y activa', icon: 'check' }
})

/* ------------------------------------------------------------------ */
/* Indicadores (RF-003 y RF-014)                                       */
/* ------------------------------------------------------------------ */

const dentroDe = (pedido, diasVentana) => {
  const limite = Date.now() - diasVentana * 86400000
  return new Date(pedido.creado_en).getTime() >= limite
}

const porDespachar = computed(() =>
  pedidos.value.filter((p) => ESTADOS_POR_DESPACHAR.includes(p.estado)),
)

const enTransito = computed(() =>
  pedidos.value.filter((p) => p.envio?.estado === ESTADO_ENVIO.EN_TRANSITO),
)

const indicadores = computed(() => {
  // Misma población que `getResumenVentas`: sólo pedidos con pago autorizado
  // (no `creado`, no `cancelado`). Los no entregados no suman al neto.
  const autorizados = pedidos.value.filter((p) => ESTADOS_VENTA_AUTORIZADA.includes(p.estado))
  const entregados = autorizados.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO)
  const actuales = autorizados.filter((p) => dentroDe(p, 30))
  const previos = autorizados.filter((p) => !dentroDe(p, 30) && dentroDe(p, 60))
  const suma = (lista, campo) => lista.reduce((acc, p) => acc + Number(p[campo] ?? 0), 0)
  const sumaNeta = (lista) =>
    Math.round(lista.reduce((acc, p) => acc + netoProductor(p), 0) * 100) / 100
  const variacion = (actual, previo) =>
    previo ? Math.round(((actual - previo) / previo) * 1000) / 10 : null

  return {
    ventasAutorizadas: resumen.value?.ventasAutorizadas ?? suma(autorizados, 'total'),
    ventasEntregadas: resumen.value?.ventasEntregadas ?? suma(entregados, 'total'),
    netoEntregado: resumen.value?.netoEntregado ?? sumaNeta(entregados),
    netoAutorizado: resumen.value?.netoAutorizado ?? sumaNeta(autorizados),
    comisionesAutorizadas:
      resumen.value?.comisionesAutorizadas ?? suma(autorizados, 'monto_fee_plataforma'),
    entregados: resumen.value?.pedidosEntregados ?? entregados.length,
    variacionVentas: variacion(suma(actuales, 'total'), suma(previos, 'total')),
    variacionPedidos: variacion(actuales.length, previos.length),
  }
})

const inventario = computed(() => {
  const items = productos.value.filter((p) => !p.eliminado_en)
  const publicados = items.filter((p) => p.activo)
  return {
    total: items.length,
    publicados: publicados.length,
    stockTotal: publicados.reduce((acc, p) => acc + Number(p.stock ?? 0), 0),
    sinStock: publicados.filter((p) => Number(p.stock) <= 0).length,
  }
})

/* ------------------------------------------------------------------ */
/* Rendimiento de ventas                                               */
/* ------------------------------------------------------------------ */

const serie = computed(() => {
  const cantidad = dias.value
  const indice = new Map()
  const diasSerie = []

  for (let i = cantidad - 1; i >= 0; i -= 1) {
    const fecha = new Date()
    fecha.setHours(0, 0, 0, 0)
    fecha.setDate(fecha.getDate() - i)
    const clave = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(fecha)
    diasSerie.push({
      clave,
      total: 0,
      pedidos: 0,
      etiqueta:
        cantidad <= 7
          ? capitalizar(
              new Intl.DateTimeFormat('es-CL', {
                weekday: 'short',
                timeZone: 'America/Santiago',
              }).format(fecha),
            )
          : formatDayMonth(fecha),
    })
    indice.set(clave, diasSerie[diasSerie.length - 1])
  }

  for (const pedido of pedidos.value) {
    // El gráfico usa la misma población que la métrica "Ventas autorizadas".
    if (!ESTADOS_VENTA_AUTORIZADA.includes(pedido.estado)) continue
    const fila = indice.get(
      new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(
        new Date(pedido.creado_en),
      ),
    )
    if (!fila) continue
    fila.total += Number(pedido.total ?? 0)
    fila.pedidos += 1
  }

  return diasSerie
})

const graficoVentas = computed(() => ({
  labels: serie.value.map((d) => d.etiqueta),
  datasets: [{ label: 'Ventas diarias (CLP)', data: serie.value.map((d) => Math.round(d.total)) }],
}))

const mejorDia = computed(() => {
  if (!serie.value.length) return null
  return [...serie.value].sort((a, b) => b.total - a.total)[0]
})

function capitalizar(texto) {
  return texto ? texto.charAt(0).toUpperCase() + texto.slice(1) : texto
}

/* ------------------------------------------------------------------ */
/* Pedidos recientes                                                   */
/* ------------------------------------------------------------------ */

const columnasPedidos = [
  { key: 'codigo', label: 'ID Pedido' },
  { key: 'cliente', label: 'Cliente' },
  { key: 'fecha', label: 'Fecha' },
  { key: 'monto', label: 'Monto', align: 'right' },
  { key: 'estado', label: 'Estado', width: '150px' },
]

const pedidosRecientes = computed(() => pedidos.value.slice(0, 6))

function abrirPedido(pedido) {
  router.push(`/vendedor/pedidos/${pedido.id}`)
}

/* ------------------------------------------------------------------ */
/* Exportación                                                         */
/* ------------------------------------------------------------------ */

const columnasExport = [
  { key: 'codigo_pedido', label: 'Pedido' },
  { key: 'cliente_id', label: 'Cliente' },
  { key: 'creado_en', label: 'Fecha', get: (row) => formatDateTime(row.creado_en) },
  { key: 'total', label: 'Total', get: (row) => formatCLP(row.total) },
  {
    key: 'neto_productor',
    label: 'Neto al productor (entregado)',
    get: (row) => (row.estado === ESTADO_PEDIDO.COMPLETADO ? formatCLP(netoProductor(row)) : '—'),
  },
  { key: 'estado', label: 'Estado', get: (row) => LABELS.pedido[row.estado] ?? row.estado },
]

async function exportar() {
  const ok = await exportExcel(pedidosRecientes.value, 'panel-productor-pedidos', columnasExport)
  if (ok) ui.success('Reporte generado', 'Se descargó el Excel de los pedidos recientes.')
  else ui.warning('Sin datos para exportar', 'Todavía no tienes pedidos registrados.')
}

/* ------------------------------------------------------------------ */
/* Módulos del panel                                                   */
/* ------------------------------------------------------------------ */

const enlacesSecundarios = computed(() =>
  NAV_SECUNDARIO.vendedor.filter((item) => item.to !== '/vendedor/productos/nuevo'),
)
</script>

<template>
  <div class="container page panel-page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">
          Hola{{ auth.perfil?.nombre ? `, ${auth.perfil.nombre}` : '' }}!
        </h1>
        <p class="page-head__subtitle">
          Resumen de ventas, pedidos por despachar y reputación de tu tienda en CuTuCo.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="!pedidosRecientes.length" @click="exportar">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar
        </CtButton>
        <!-- Sin cuenta aprobada no se ofrecen acciones de venta. -->
        <CtButton v-if="puedeOperar" to="/vendedor/productos/nuevo">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Nuevo Producto
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="loading" label="Cargando tu panel" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar el panel">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="reload">Reintentar</CtButton>
    </CtAlert>

    <CtCard v-else-if="sinTienda" title="Tu tienda aún no está activa">
      <CtEmptyState
        icon=""
        title="Sin tienda de productor"
        message="Para vender tu cosecha debes postular como vendedor. Un administrador revisa tu solicitud y, cuando la aprueba, tu tienda queda disponible en el catálogo."
      >
        <CtButton to="/vendedor/tienda">Ir a mi perfil de tienda</CtButton>
      </CtEmptyState>
    </CtCard>

    <template v-else>
      <!-- ============ Estado de la cuenta ============ -->
      <CtAlert
        v-if="motivoBloqueo"
        :tone="estadoCuenta.tone === 'danger' ? 'danger' : 'warning'"
        :title="estadoCuenta.label"
      >
        <p>{{ motivoBloqueo }}</p>
        <p v-if="postulacion?.observaciones_admin" class="text-sm">
          Observaciones del administrador: {{ postulacion.observaciones_admin }}
        </p>
        <div class="row row--wrap">
          <CtButton size="sm" variant="secondary" to="/vendedor/tienda">
            Ver estado de mi solicitud
          </CtButton>
          <CtButton size="sm" variant="ghost" @click="reload">Actualizar estado</CtButton>
        </div>
      </CtAlert>

      <div class="row row--wrap">
        <CtBadge :tone="estadoCuenta.tone" dot>{{ estadoCuenta.label }}</CtBadge>
        <CtBadge v-if="productor?.nombre_comercial" tone="neutral">
          Productor: {{ productor.nombre_comercial }}
        </CtBadge>
        <CtBadge v-if="postulacion" tone="neutral">
          Solicitud: {{ LABELS.postulacion[postulacion.estado] ?? postulacion.estado }}
        </CtBadge>
        <CtBadge v-if="sancionesVigentes.length" tone="danger">
          {{ sancionesVigentes.length }} sanción(es) vigente(s)
        </CtBadge>
      </div>

      <!-- ============ Indicadores ============ -->
      <div class="grid-kpi panel-kpi">
        <CtStatCard
          label="Ventas autorizadas"
          :value="formatCLP(indicadores.ventasAutorizadas)"
          tone="success"
          :delta="indicadores.variacionVentas"
          delta-label="vs. 30 días anteriores"
          :hint="`${formatCLP(indicadores.netoEntregado)} neto al productor en pedidos entregados`"
          calculation="Suma los pedidos pagados y no cancelados de tu tienda, incluido el IVA de las compras nuevas. Muestra ventas confirmadas; revisa tu banco para conocer los abonos recibidos."
          :to="puedeOperar ? '/vendedor/pedidos' : null"
        />
        <CtStatCard
          label="Pedidos por Despachar"
          :value="formatNumber(porDespachar.length)"
          tone="warning"
          :delta="indicadores.variacionPedidos"
          delta-label="vs. 30 días anteriores"
          :hint="`${formatNumber(enTransito.length)} en tránsito · ${formatNumber(indicadores.entregados)} entregados`"
          :to="puedeOperar ? '/vendedor/pedidos' : null"
        />
        <CtStatCard
          label="Reputación Promedio"
          :value="reputacion.puntaje === null ? '—' : formatNumber(reputacion.puntaje, 2)"
          unit="/ 5,0"
          tone="accent"
          :progress="reputacion.puntaje === null ? null : (Number(reputacion.puntaje) / 5) * 100"
          :hint="`${formatNumber(reputacion.cantidad)} evaluación(es) de clientes`"
        />
        <CtStatCard
          label="Productos Publicados"
          :value="formatNumber(inventario.publicados)"
          tone="primary"
          :hint="`${formatNumber(inventario.total)} en tu inventario · ${formatNumber(inventario.stockTotal)} unidades en stock`"
          :to="puedeOperar ? '/vendedor/productos' : null"
        />
      </div>

      <!-- ============ Rendimiento + reputación ============ -->
      <div class="grid grid--tight panel-grid">
        <div class="col-7">
          <CtCard title="Rendimiento de Ventas" subtitle="Ventas diarias en pesos chilenos (CLP)">
            <template #actions>
              <CtTabs v-model="dias" :tabs="tabsSerie" variant="pills" />
            </template>

            <CtChart
              type="line"
              :labels="graficoVentas.labels"
              :datasets="graficoVentas.datasets"
              :height="260"
              currency
              :show-legend="false"
            />

            <p v-if="mejorDia && mejorDia.total > 0" class="text-xs text-muted">
              Mejor día del período:
              <strong>{{ mejorDia.etiqueta }}</strong> con {{ formatCLP(mejorDia.total) }} en
              {{ mejorDia.pedidos }} pedido(s).
            </p>
            <p v-else class="text-xs text-muted">
              No hay ventas registradas en los últimos {{ dias }} días.
            </p>
          </CtCard>
        </div>

        <div class="col-5">
          <CtCard
            title="Reputación de la Tienda"
            subtitle="Promedio simple de las calificaciones de tus clientes"
          >
            <div class="confianza">
              <div class="confianza__score">
                <div>
                  <p class="eyebrow">Promedio actual</p>
                  <p class="confianza__valor">
                    {{ reputacion.puntaje === null ? '—' : formatNumber(reputacion.puntaje, 2) }}
                  </p>
                </div>
                <CtRatingStars
                  v-if="reputacion.puntaje !== null"
                  :model-value="Number(reputacion.puntaje)"
                  :size="16"
                />
              </div>

              <p v-if="reputacion.cantidad" class="text-sm text-soft">
                <strong>{{ formatNumber(reputacion.cantidad) }}</strong>
                {{
                  reputacion.cantidad === 1 ? 'evaluación registrada' : 'evaluaciones registradas'
                }}
                en la escala de 1 a 5.
              </p>
              <p v-else class="text-sm text-muted">
                Todavía no tienes calificaciones. El cliente califica de 1 a 5 cuando recibe su
                pedido.
              </p>

              <div v-if="reputacion.evaluaciones.length" class="stack stack--sm">
                <p class="eyebrow">Últimas calificaciones</p>
                <ul class="barras">
                  <li v-for="(evaluacion, index) in reputacion.evaluaciones" :key="index">
                    <div class="row row--between">
                      <span class="text-sm">{{ formatDate(evaluacion.creado_en) }}</span>
                      <span class="text-xs text-muted"
                        >{{ formatNumber(evaluacion.puntaje) }} / 5</span
                      >
                    </div>
                    <p v-if="evaluacion.comentario" class="text-xs text-muted">
                      {{ evaluacion.comentario }}
                    </p>
                  </li>
                </ul>
              </div>

              <CtAlert tone="neutral" compact>
                <p>
                  La reputación es el promedio de las calificaciones de 1 a 5: no existen reglas
                  automáticas ni pausas por puntaje. Cualquier sanción la decide el administrador.
                </p>
              </CtAlert>
            </div>
          </CtCard>
        </div>
      </div>

      <!-- ============ Despacho + pedidos ============ -->
      <div class="grid grid--tight panel-grid">
        <div class="col-5">
          <CtCard
            title="Pedidos por Despachar"
            subtitle="Pedidos pagados con Webpay que esperan tu preparación"
          >
            <template #actions>
              <CtButton v-if="puedeOperar" size="sm" variant="ghost" to="/vendedor/pedidos">
                Gestionar pedidos
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!porDespachar.length"
              compact
              icon="truck"
              title="Sin pedidos pendientes"
              message="No tienes pedidos pagados esperando preparación o despacho."
            />

            <ul v-else class="lista">
              <li v-for="pedido in porDespachar.slice(0, 5)" :key="pedido.id" class="lista__item">
                <div>
                  <p class="font-semibold">{{ pedido.codigo_pedido }}</p>
                  <p class="text-xs text-muted">
                    {{ pedido.nombre_destinatario ?? 'Cliente' }} ·
                    {{ LABELS.pedido[pedido.estado] ?? pedido.estado }} ·
                    {{ formatDate(pedido.creado_en) }}
                  </p>
                </div>
                <CtButton
                  v-if="puedeOperar"
                  size="sm"
                  variant="secondary"
                  @click="abrirPedido(pedido)"
                >
                  Despachar
                </CtButton>
              </li>
            </ul>
          </CtCard>
        </div>

        <div class="col-7">
          <CtCard title="Pedidos Recientes" subtitle="Últimos pedidos recibidos">
            <template #actions>
              <CtButton v-if="puedeOperar" size="sm" variant="ghost" to="/vendedor/pedidos"
                >Ver todos</CtButton
              >
            </template>

            <CtTable
              :columns="columnasPedidos"
              :rows="pedidosRecientes"
              row-key="id"
              dense
              clickable
              min-width="620px"
              empty-icon=""
              empty-title="Todavía no hay pedidos"
              empty-message="Cuando un cliente compre tus productos, aparecerán aquí."
              @row-click="abrirPedido"
            >
              <template #cell-codigo="{ row }">
                <router-link :to="`/vendedor/pedidos/${row.id}`" class="enlace">
                  {{ row.codigo_pedido }}
                </router-link>
              </template>
              <template #cell-cliente="{ row }">
                <span class="text-sm">{{ row.nombre_destinatario ?? '—' }}</span>
              </template>
              <template #cell-fecha="{ row }">
                <span class="text-sm text-soft">{{ formatDateTime(row.creado_en) }}</span>
              </template>
              <template #cell-monto="{ row }">
                <span class="font-semibold">{{ formatCLP(row.total) }}</span>
              </template>
              <template #cell-estado="{ row }">
                <StatusBadge type="pedido" :value="row.estado" size="sm" />
              </template>
            </CtTable>
          </CtCard>
        </div>
      </div>

      <!-- ============ Resumen de dinero + sanciones ============ -->
      <div class="grid grid--tight panel-grid">
        <div class="col-7">
          <CtCard
            title="Desglose del dinero"
            subtitle="Ventas autorizadas, entregadas y neto del productor"
          >
            <section class="dinero" aria-label="Desglose monetario">
              <article class="dinero__fila">
                <p class="dinero__label">Ventas autorizadas (pedidos pagados, no cancelados)</p>
                <strong class="dinero__valor">{{
                  formatCLP(indicadores.ventasAutorizadas)
                }}</strong>
                <CtMoneyInfo title="Origen de las ventas autorizadas">
                  <p>
                    Suma los pedidos con pago Webpay Mall autorizado y no cancelados. Incluye el IVA
                    registrado en las compras nuevas y no representa un saldo disponible.
                  </p>
                </CtMoneyInfo>
              </article>
              <article class="dinero__fila">
                <p class="dinero__label">
                  Comisión de CuTuCo ({{ formatNumber(REGLAS.TARIFAS.feePlataforma * 100) }}%) sobre
                  ventas autorizadas
                </p>
                <strong class="dinero__valor"
                  >− {{ formatCLP(indicadores.comisionesAutorizadas) }}</strong
                >
                <CtMoneyInfo title="Origen de la comisión">
                  <p>
                    Suma el cargo de plataforma de los pedidos autorizados. Es el 5% del subtotal de
                    productos y no se calcula sobre el IVA ni el despacho.
                  </p>
                </CtMoneyInfo>
              </article>
              <article class="dinero__fila">
                <p class="dinero__label">Ventas entregadas (pedidos completados)</p>
                <strong class="dinero__valor">{{ formatCLP(indicadores.ventasEntregadas) }}</strong>
                <CtMoneyInfo title="Origen de las ventas entregadas">
                  <p>
                    Es el subconjunto de ventas autorizadas cuya entrega ya fue completada con su
                    código de verificación.
                  </p>
                </CtMoneyInfo>
              </article>
              <article class="dinero__fila">
                <p class="dinero__label">Neto al productor (entregado)</p>
                <strong class="dinero__valor dinero__neto">{{
                  formatCLP(indicadores.netoEntregado)
                }}</strong>
                <CtMoneyInfo title="Origen del neto al productor">
                  <p>
                    Resta la comisión de plataforma a las ventas entregadas. Revisa tu banco para
                    confirmar los abonos recibidos.
                  </p>
                </CtMoneyInfo>
              </article>
            </section>
            <CtMoneyInfo title="Sobre el neto estimado y el despacho">
              <p>
                El neto estimado de las ventas autorizadas es
                {{ formatCLP(indicadores.netoAutorizado) }}; incluye pedidos aún no entregados y no
                es saldo disponible. La tarifa fija de delivery vigente es
                {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }} por pedido.
              </p>
            </CtMoneyInfo>
            <CtAlert tone="neutral" compact>
              <!-- Neto al productor sólo suma pedidos entregados. -->
              <p>
                Cuando se confirma una venta con Webpay, el pago se envía a tu cuenta registrada.
                CuTuCo descuenta su comisión de plataforma. Por eso “Neto al productor” sólo suma
                pedidos entregados y las ventas autorizadas no se muestran como dinero disponible.
              </p>
            </CtAlert>
          </CtCard>
        </div>

        <div class="col-5">
          <CtCard title="Sanciones Vigentes" subtitle="Amonestaciones, suspensiones y bans">
            <CtEmptyState
              v-if="!sancionesVigentes.length"
              compact
              icon="shieldCheck"
              title="Sin sanciones vigentes"
              message="Tu cuenta no tiene amonestaciones, suspensiones ni bans activos."
            />

            <ul v-else class="lista">
              <li v-for="sancion in sancionesVigentes" :key="sancion.id" class="lista__item">
                <div>
                  <p class="font-semibold">
                    {{ LABELS.accionSancion[sancion.accion] ?? sancion.accion }}
                  </p>
                  <p class="text-xs text-muted">
                    {{ LABELS.tipoSancion[sancion.tipo] ?? sancion.tipo }} · desde
                    {{ formatDate(sancion.inicio_en) }}
                    <template v-if="sancion.fin_en">
                      · hasta {{ formatDate(sancion.fin_en) }}</template
                    >
                    <template v-else> · sin fecha de término</template>
                  </p>
                  <p v-if="sancion.motivo" class="text-xs text-muted">{{ sancion.motivo }}</p>
                </div>
                <StatusBadge type="sancion" :value="sancion.estado" size="sm" />
              </li>
            </ul>

            <template #footer>
              <CtButton size="sm" variant="ghost" to="/vendedor/tienda"
                >Ver mi perfil de tienda</CtButton
              >
            </template>
          </CtCard>
        </div>
      </div>

      <!-- ============ Inventario + módulos ============ -->
      <div class="grid grid--tight panel-grid">
        <div class="col-7">
          <CtCard title="Mi Inventario" subtitle="Productos publicados, stock y avisos manuales">
            <div class="confianza">
              <ul class="barras">
                <li>
                  <div class="row row--between">
                    <span class="text-sm">Productos publicados</span>
                    <span class="text-xs text-muted">
                      {{ formatNumber(inventario.publicados) }} de
                      {{ formatNumber(inventario.total) }}
                    </span>
                  </div>
                  <CtProgressBar
                    :value="inventario.total ? (inventario.publicados / inventario.total) * 100 : 0"
                    :max="100"
                    size="sm"
                    tone="success"
                  />
                </li>
                <li>
                  <div class="row row--between">
                    <span class="text-sm">Publicados sin stock</span>
                    <span class="text-xs text-muted">{{ formatNumber(inventario.sinStock) }}</span>
                  </div>
                  <CtProgressBar
                    :value="
                      inventario.publicados
                        ? (inventario.sinStock / inventario.publicados) * 100
                        : 0
                    "
                    :max="100"
                    size="sm"
                    :tone="inventario.sinStock ? 'warning' : 'info'"
                  />
                </li>
              </ul>

              <CtAlert v-if="inventario.sinStock" tone="warning" compact>
                <p>
                  {{ inventario.sinStock }} producto(s) publicados no tienen stock. Revísalos y
                  actualiza su disponibilidad para evitar nuevas compras.
                </p>
              </CtAlert>

              <div class="row row--wrap">
                <CtButton v-if="puedeOperar" size="sm" variant="secondary" to="/vendedor/productos">
                  Gestionar inventario
                </CtButton>
                <CtButton
                  v-if="puedeOperar"
                  size="sm"
                  variant="ghost"
                  to="/vendedor/productos/nuevo"
                >
                  <template #icon><CtIcon name="plus" :size="15" /></template>
                  Nuevo producto
                </CtButton>
              </div>
            </div>
          </CtCard>
        </div>

        <div class="col-5">
          <CtCard title="Módulos del productor" subtitle="Todo lo que cuelga de este panel">
            <ul class="enlaces">
              <li v-for="item in enlacesSecundarios" :key="item.to">
                <router-link :to="item.to" class="enlaces__item">
                  <CtIcon :name="item.icon" :size="16" />
                  <span>{{ item.label }}</span>
                  <CtIcon name="chevronRight" :size="14" />
                </router-link>
              </li>
            </ul>
          </CtCard>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.panel-page {
  gap: var(--ct-space-6);
}

.panel-kpi,
.panel-grid {
  gap: var(--ct-space-4);
}

.panel-grid {
  align-items: start;
}

.panel-grid > [class*='col-'] {
  min-width: 0;
}

.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.confianza {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.confianza__score {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.confianza__valor {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
  color: var(--ct-accent-strong);
}

.barras {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.lista {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.lista__item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
}

.lista__item:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.dinero {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0 0 var(--ct-space-4);
}

.dinero__fila {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: baseline;
  gap: var(--ct-space-4);
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.dinero__fila:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.dinero__label {
  margin: 0;
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.dinero__valor {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.dinero__fila :deep(.money-info) {
  grid-column: 1 / -1;
  border-top: 1px solid var(--ct-border);
  padding-top: var(--ct-space-2);
}

.dinero__neto {
  color: var(--ct-success);
}

.enlaces {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.enlaces__item {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
  color: var(--ct-text);
  text-decoration: none;
  font-size: var(--ct-fs-md);
}

.enlaces__item:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.enlaces__item > :last-child {
  margin-left: auto;
  color: var(--ct-text-muted);
}

.enlaces li:last-child .enlaces__item {
  border-bottom: none;
  padding-bottom: 0;
}

.enlace {
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-primary-strong);
}
</style>
