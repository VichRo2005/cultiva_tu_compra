/**
 * CuTuCo — Lote 20 (CK-0031): reenvío de confirmación de correo.
 * GoTrue impone límites y vigencia del token (resend type 'signup'); el
 * frontend no concede acceso prematuro: sin correo confirmado el alta queda
 * en borrador local y no hay sesión protegida.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const contexto = vi.hoisted(() => ({
  currentAuth: vi.fn(),
  motivoBloqueoVendedor: vi.fn(),
  sancionVigente: vi.fn(() => false),
  estadoEfectivoCuenta: vi.fn(({ perfil } = {}) => (perfil ? 'activo' : 'sin_perfil')),
}))
const cliente = vi.hoisted(() => ({
  from: vi.fn(),
  auth: {
    getSession: vi.fn(),
    getUser: vi.fn(),
    signInWithPassword: vi.fn(),
    signOut: vi.fn(),
    updateUser: vi.fn(),
    resetPasswordForEmail: vi.fn(),
    resend: vi.fn(),
    onAuthStateChange: vi.fn(),
  },
}))
vi.mock('@/services/session', () => contexto)
vi.mock('@/lib/supabase', () => ({
  getClient: () => cliente,
  tryGetClient: () => cliente,
  MISSING_ENV: false,
  MODO_DEMO: { value: false },
}))
import { useAuthStore } from '@/stores/auth.js'

beforeEach(() => {
  vi.resetAllMocks()
  setActivePinia(createPinia())
  cliente.auth.getSession.mockResolvedValue({ data: { session: null }, error: null })
  cliente.auth.onAuthStateChange.mockReturnValue({
    data: { subscription: { unsubscribe: vi.fn() } },
  })
  cliente.auth.resend.mockResolvedValue({ error: null })
})

describe('CK-0031 · reenvío de verificación', () => {
  it('usa resend de GoTrue (type signup) con redirect propio', async () => {
    const auth = useAuthStore()
    await auth.reenviarVerificacion('qa@example.test')
    expect(cliente.auth.resend).toHaveBeenCalledTimes(1)
    const llamada = cliente.auth.resend.mock.calls[0][0]
    expect(llamada.type).toBe('signup')
    expect(llamada.email).toBe('qa@example.test')
    expect(new URL(llamada.options.emailRedirectTo).origin).toBe(window.location.origin)
  })

  it('un límite de reenvío de GoTrue (429) se muestra como espera, sin filtrar detalle interno', async () => {
    cliente.auth.resend.mockResolvedValueOnce({
      error: { status: 429, message: 'over_email_send_rate_limit DETAIL: SQLSTATE 42501' },
    })
    const auth = useAuthStore()
    const error = await auth.reenviarVerificacion('qa@example.test').catch((e) => e)
    expect(String(error?.message)).toMatch(/Espera|Demasiados/i)
    expect(String(error?.message)).not.toMatch(/SQLSTATE|DETAIL/)
  })

  it('sin correo confirmado no hay acceso: el registro queda en borrador local', () => {
    // cubierto por registro-borrador-privacidad.spec.js y postulacion-lote12.spec.js:
    // guardarBorradorClienteLocal no persiste contraseñas y la postulación no nace
    // hasta confirmar el correo (CK-0218).
    const src = require('node:fs').readFileSync
    expect(src('src/services/registro.js', 'utf8')).toMatch(/guardarBorradorClienteLocal/)
    expect(src('src/views/auth/RegisterView.vue', 'utf8')).toMatch(/confirma tu correo/i)
  })
})
