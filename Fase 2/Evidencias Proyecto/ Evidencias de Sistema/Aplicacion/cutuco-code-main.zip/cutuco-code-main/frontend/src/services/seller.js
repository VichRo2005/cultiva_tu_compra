/**
 * CuTuCo — Servicio del módulo Vendedor (Productor AFC).
 *
 *   RF-003  tienda, productos (con foto de cámara), stock y ventas
 *   RF-021  registro de vendedor y aprobación manual del administrador
 *   RF-025  gestión de los pedidos recibidos y del delivery
 *   RF-017  desactivación lógica de productos
 *
 * Los productos y el stock se escriben directo a PostgREST con RLS: el
 * vendedor aprobado es el único que puede crear y editar lo suyo.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Antes este servicio exponía `listCoberturas` (cobertura por comuna,
 *   RF-009 versión antigua) y `getReputacionBreakdown` con el score 40/40/20
 *   (RF-006 versión antigua). La reputación ahora es el promedio simple de las
 *   calificaciones de 1 a 5 y la cobertura es sólo regional.
 */

import { mensajeSeguro } from '@/services/errores'
import { apiFetch, getClient, readFileAsDataURL, storageUrl } from '@/lib/supabase'
import { ESTADO_PEDIDO, STORAGE_BUCKETS } from '@/lib/constants'
import { netoProductor } from '@/lib/orders'
import { currentUserId, unwrap } from '@/services/session'
import { slugify } from '@/services/catalog'
import { getDireccionProductor } from '@/services/geography'

/**
 * Límites de `public.productos` (migración 20261004021917):
   *   * El precio se limita por negocio a 999.999 CLP, aunque la columna admita
   *     un rango técnico mayor. Así la publicación conserva un límite razonable
   *     para el marketplace y coincide con el formulario.
 *   * `stock numeric(12,1)`: el tope técnico de la columna sería 99.999.999.999,
 *     pero HAL-VEN-026 definió un tope de NEGOCIO a escala campesina de
 *     999.999 unidades: 999.999.999 rompía la UI del carrito y el checkout.
 *     Sigue siendo menor que el máximo del validador del backend
 *     (STOCK_MAXIMO = 999.999.999.999), así que la BD nunca rechaza antes que la UI.
 */
export const LIMITES_PRODUCTO = Object.freeze({
  precioMin: 1,
  precioMax: 999999,
  stockMin: 0,
  stockMax: 999999,
})

/** Justificación por defecto al pausar un producto (10..1000 caracteres en BD). */
export const MOTIVO_PAUSA_POR_DEFECTO = 'Pausado manualmente por el productor'
export const MOTIVO_PRODUCTO_MIN = 10
export const MOTIVO_PRODUCTO_MAX = 1000

/**
 * Población exacta de las métricas de ventas del vendedor.
 *
 * Con Webpay Mall el pago se autoriza en el commit del Mall; `pedidos.estado`
 * pasa a `pagado` o superior sólo después de esa autorización. `creado` es un
 * pedido sin pago y `cancelado` queda fuera de las ventas. Los pedidos
 * `reclamado` sí tuvieron un pago autorizado, por eso integran la población.
 */
export const ESTADOS_VENTA_AUTORIZADA = Object.freeze([
  ESTADO_PEDIDO.PAGADO,
  ESTADO_PEDIDO.EN_PREPARACION,
  ESTADO_PEDIDO.COMPLETADO,
  ESTADO_PEDIDO.RECLAMADO,
])

/* ---------------------------------------------------------------- */
/* Identidad de la tienda                                              */
/* ---------------------------------------------------------------- */

export async function getMiProductor() {
  return getProductorDeSesion()
}

export async function getMiPostulacion() {
  return getPostulacionDeSesion()
}

export async function getProductorDeSesion() {
  const client = getClient()
  const userId = await currentUserId()
  if (!userId) return null
  const { data } = await client
    .from('productores')
    .select('*')
    .eq('perfil_id', userId)
    .maybeSingle()
  return data ?? null
}

export async function getPostulacionDeSesion() {
  const client = getClient()
  const userId = await currentUserId()
  if (!userId) return null
  const { data } = await client
    .from('postulaciones_vendedores')
    .select('*')
    .eq('perfil_id', userId)
    .order('creado_en', { ascending: false })
    .limit(1)
    .maybeSingle()
  return data ?? null
}

/** Sanciones del vendedor (RF-026): amonestaciones, suspensiones y bans. */
export async function listSancionesDeProductor(productorId) {
  const client = getClient()
  const { data, error } = await client
    .from('sanciones')
    .select('*')
    .eq('productor_id', productorId)
    .order('inicio_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/** Base de slug de la tienda; devuelve '' cuando el nombre sólo tiene símbolos. */
export function slugTiendaBase(nombre) {
  return slugify(String(nombre ?? '').trim())
}

/**
 * Deduplica el slug de una tienda contra los ya usados (índice único
 * `uq_productor_slug`, case-insensitive). Mantiene el máximo de 200 caracteres
 * de `productores.slug` y agrega sufijos -2, -3… igual que el trigger de BD.
 */
export function slugUnicoTienda(base, ocupados = []) {
  const limpio = String(base ?? '').trim()
  if (!limpio) return ''
  const usados = new Set((ocupados ?? []).map((slug) => String(slug ?? '').toLowerCase()))
  if (!usados.has(limpio.toLowerCase())) return limpio

  for (let n = 2; n <= 999; n += 1) {
    const sufijo = `-${n}`
    const candidato = `${limpio.slice(0, 200 - sufijo.length).replace(/-+$/g, '')}${sufijo}`
    if (!usados.has(candidato.toLowerCase())) return candidato
  }
  // Salida de emergencia para datasets con cientos de colisiones.
  return `${limpio.slice(0, 180)}-${Date.now().toString(36)}`.slice(0, 200)
}

/** Mensaje funcional en español para los errores de la tienda (sin códigos internos). */
export function mensajeErrorTienda(mensaje, fallback = 'No se pudo actualizar la tienda') {
  const texto = String(mensaje ?? '')
    .replace(/^.*?ERROR:\s*/i, '')
    .replace(/CONTEXT:.*$/s, '')
    .trim()
  if (
    /ck_productor_slug_formato|slug/i.test(texto) &&
    /check|formato|inv[aá]lid|vac[ií]o/i.test(texto)
  ) {
    return 'El nombre comercial debe incluir al menos una letra o número para generar la dirección de tu tienda.'
  }
  if (/nombre_comercial/i.test(texto) && /duplicate|unique|ya existe/i.test(texto)) {
    return 'Ya existe una tienda con ese nombre comercial. Elige otro nombre.'
  }
  if (/uq_productor_slug|duplicate key/i.test(texto)) {
    return 'Ya existe una tienda con una dirección similar. Ajusta el nombre comercial e inténtalo de nuevo.'
  }
  if (/row-level security|permission denied|PGRST116|no rows/i.test(texto)) {
    return 'No tienes permiso para editar esta tienda o la tienda ya no existe.'
  }
  if (!texto || /^PGRST|^column|^relation|^syntax|violates|duplicate key/i.test(texto))
    return mensajeSeguro(texto, fallback)
  return mensajeSeguro(texto)
}

/**
 * Actualiza el perfil de tienda. El nombre comercial y la descripción viven en
 * `productores`; la región del vendedor se define en su dirección activa y sólo
 * puede cambiarla el propio vendedor (RF-009).
 *
 * El slug se calcula en el cliente porque el trigger de BD sólo corre en INSERT
 * y `productores.slug` tiene CHECK de formato + índice único. Un nombre hecho
 * sólo de símbolos produce un slug vacío: se rechaza antes de llegar a PostgREST
 * con un mensaje funcional (HAL-VEN-005).
 */
export async function updateTienda({ productorId, nombreComercial, descripcion }) {
  const client = getClient()
  const nombre = String(nombreComercial ?? '').trim()
  const base = slugTiendaBase(nombre)

  if (!nombre) throw new Error('El nombre comercial es obligatorio')
  if (!base) {
    throw new Error(
      'El nombre comercial debe incluir al menos una letra o número para generar la dirección de tu tienda.',
    )
  }

  const { data: otros, error: errorSlugs } = await client
    .from('productores')
    .select('id, slug')
    .neq('id', productorId)
  if (errorSlugs) {
    throw new Error('No pudimos verificar la dirección de tu tienda. Inténtalo nuevamente.')
  }

  const { data, error } = await client
    .from('productores')
    .update({
      nombre_comercial: nombre,
      slug: slugUnicoTienda(
        base,
        (otros ?? []).map((p) => p.slug),
      ),
      descripcion: descripcion?.trim() ? descripcion.trim() : null,
    })
    .eq('id', productorId)
    .select()
    .maybeSingle()

  if (error) throw new Error(mensajeErrorTienda(error.message))
  if (!data) {
    throw new Error('No tienes permiso para editar esta tienda o la tienda ya no existe.')
  }
  return data
}

/**
 * Tienda + su única dirección activa. La dirección se resuelve con el servicio
 * existente `getDireccionProductor` (no se duplica la lectura de comuna/región),
 * y se expone anidada para que todas las vistas muestren el mismo valor
 * (HAL-VEN-009/HAL-VEN-010).
 */
export async function getTiendaConUbicacion(productorId) {
  const client = getClient()
  const { data: productor } = await client
    .from('productores')
    .select('*')
    .eq('id', productorId)
    .maybeSingle()
  if (!productor) return null

  const direccion = await getDireccionProductor(productor.id)
  return {
    ...productor,
    direccion,
    comuna: direccion?.comuna ?? null,
    region: direccion?.region ?? null,
  }
}

/* ---------------------------------------------------------------- */
/* Datos bancarios del comercio del productor (RF-014 y RF-021):        */
/* ---------------------------------------------------------------- */

/**
 * Datos bancarios activos del perfil.
 *
 * Se leen SIEMPRE por FastAPI: `public.datos_bancarios` tiene revocados los
 * permisos de `anon` y `authenticated` (migración
 * `20261007004557_datos_bancarios_fastapi_only.sql`), así que PostgREST no puede
 * devolver los datos. La respuesta se limita a la sesión propietaria y viaja
 * por HTTPS; incluye el número para precargar el formulario de modificación.
 * @returns {Promise<object|null>} `{ id, banco, tipo_cuenta, numero_cuenta, titular_cuenta, rut_titular, activo, ... }`
 */
export async function getDatosBancarios() {
  const cuentas = await apiFetch('/datos-bancarios/me')
  const lista = Array.isArray(cuentas) ? cuentas : []
  return lista.find((c) => c.activo) ?? lista[0] ?? null
}

/**
 * Registra o actualiza los datos bancarios del vendedor.
 *
 * El número de cuenta viaja en claro sobre TLS y se cifra con Fernet en el
 * backend (`BANK_ENCRYPTION_KEY`) antes de escribir `numero_cuenta_cifrado`
 * (bytea). El frontend nunca cifra ni escribe `datos_bancarios` directamente.
 *
 * @returns {Promise<object>} la cuenta guardada para la sesión propietaria
 */
export async function guardarDatosBancarios({
  banco,
  tipoCuenta,
  numeroCuenta,
  titular,
  rutTitular,
}) {
  const existente = await getDatosBancarios().catch(() => null)
  const cuerpo = {
    banco,
    tipo_cuenta: tipoCuenta,
    numero_cuenta: String(numeroCuenta ?? '').trim(),
    titular_cuenta: String(titular ?? '').trim(),
    rut_titular: String(rutTitular ?? '').trim(),
  }

  if (existente?.id) {
    return apiFetch(`/datos-bancarios/${existente.id}`, { method: 'PATCH', body: cuerpo })
  }
  return apiFetch('/datos-bancarios', { method: 'POST', body: cuerpo })
}

/* ---------------------------------------------------------------- */
/* Productos (RF-003 y RF-017)                                         */
/* ---------------------------------------------------------------- */

/**
 * Productos del vendedor, incluyendo los desactivados (baja lógica).
 * La RLS permite al dueño ver los suyos aunque estén inactivos.
 */
export async function listProductosVendedor({
  productorId,
  incluirInactivos = true,
  texto = '',
} = {}) {
  const client = getClient()
  let query = client.from('productos').select('*').eq('productor_id', productorId)
  if (!incluirInactivos) query = query.eq('activo', true).is('eliminado_en', null)
  if (texto.trim()) query = query.ilike('nombre', `%${texto.trim()}%`)
  const { data, error } = await query.order('actualizado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const productos = data ?? []
  if (!productos.length) return []

  const { data: imagenes } = await client
    .from('imagenes_productos')
    .select('*')
    .in(
      'producto_id',
      productos.map((p) => p.id),
    )
    .order('posicion', { ascending: true })

  const imagenMap = new Map()
  for (const img of imagenes ?? []) {
    if (!imagenMap.has(img.producto_id)) imagenMap.set(img.producto_id, [])
    imagenMap.get(img.producto_id).push({
      ...img,
      url: storageUrl(img.ruta_storage, { bucket: STORAGE_BUCKETS.productos }),
    })
  }

  return productos.map((p) => {
    const galeria = imagenMap.get(p.id) ?? []
    return {
      ...p,
      imagenes: galeria,
      imagenPrincipal: galeria.find((i) => i.es_principal) ?? galeria[0] ?? null,
    }
  })
}

export async function getProductoVendedor(productoId) {
  const client = getClient()
  const { data, error } = await client
    .from('productos')
    .select('*')
    .eq('id', productoId)
    .maybeSingle()
  if (error || !data) return null
  const { data: imagenes } = await client
    .from('imagenes_productos')
    .select('*')
    .eq('producto_id', productoId)
    .order('posicion', { ascending: true })
  const galeria = (imagenes ?? []).map((img) => ({
    ...img,
    url: storageUrl(img.ruta_storage, { bucket: STORAGE_BUCKETS.productos }),
  }))
  return {
    ...data,
    imagenes: galeria,
    imagenPrincipal: galeria.find((i) => i.es_principal) ?? galeria[0] ?? null,
  }
}

/**
 * Crea un producto. La RLS exige `activo = true`, `eliminado_en is null` y que
 * el vendedor sea el dueño del `productor_id`.
 */
export async function createProducto({
  productorId,
  nombre,
  descripcion = null,
  precio,
  stock,
  unidadMedida,
  incrementoVenta,
  cantidadMinimaCompra,
  categoriaId = null,
  fechaCosecha = null,
}) {
  const client = getClient()
  validarNumerosProducto({
    precio,
    stock,
    unidadMedida,
    incrementoVenta,
    cantidadMinimaCompra,
  })
  return unwrap(
    await client
      .from('productos')
      .insert({
        productor_id: productorId,
        categoria_id: categoriaId,
        nombre,
        // El slug NO se envía: lo genera el trigger `trg_generar_slug_producto`
        // (`before insert`) a partir del nombre y lo deduplica con sufijos -2, -3…
        // Mandarlo desde el cliente rompería esa deduplicación.
        descripcion: descripcion?.trim() ? descripcion.trim() : null,
        precio,
        stock,
        unidad_medida: unidadMedida,
        incremento_venta: incrementoVenta ?? 1,
        cantidad_minima_compra: cantidadMinimaCompra ?? 1,
        fecha_cosecha: fechaCosecha || null,
        activo: true,
      })
      .select()
      .single(),
    'No se pudo crear el producto',
  )
}

/** Valida una justificación de pausa/eliminación (10..1000 en BD). */
export function validarMotivoProducto(
  motivo,
  { min = MOTIVO_PRODUCTO_MIN, max = MOTIVO_PRODUCTO_MAX } = {},
) {
  const texto = String(motivo ?? '').trim()
  if (!texto) return 'Escribe la justificación de la pausa.'
  if (texto.length < min) return `La justificación debe tener al menos ${min} caracteres.`
  if (texto.length > max) return `La justificación no puede superar ${max} caracteres.`
  return null
}

/**
 * Traduce los errores de PostgREST/trigger a mensajes funcionales en español.
 * Evita exponer «Cannot coerce the result to a single JSON object», códigos
 * PGRST y errores de columnas al vendedor (HAL-VEN-016).
 */
export function mensajeErrorProducto(mensaje, fallback = 'No se pudo actualizar el producto') {
  const texto = String(mensaje ?? '')
    .replace(/^.*?ERROR:\s*/i, '')
    .replace(/CONTEXT:.*$/s, '')
    .trim()
  if (/cannot coerce|PGRST116|0 rows|json object|no rows|result to a single/i.test(texto)) {
    return 'El producto no existe, fue eliminado o no pertenece a tu tienda. No se guardaron cambios.'
  }
  if (/row-level security|permission denied|violates row-level/i.test(texto)) {
    return 'No tienes permiso para modificar este producto. Sólo puedes editar los productos de tu tienda.'
  }
  if (/justificaci[oó]n de pausa/i.test(texto)) {
    return 'La justificación de pausa debe tener entre 10 y 1000 caracteres.'
  }
  if (/justificaci[oó]n de eliminaci[oó]n/i.test(texto)) {
    return 'La justificación de eliminación debe tener entre 10 y 1000 caracteres.'
  }
  if (/productor desactivado/i.test(texto)) {
    return 'No puedes cambiar el estado de tus productos mientras tu tienda esté desactivada.'
  }
  if (/stock reservado/i.test(texto)) {
    return 'El stock reservado lo administra el checkout; no puedes modificarlo directamente.'
  }
  if (/incremento.*venta|cantidad.*m[ií]nima|ck_producto_(incremento|minimo|cantidad_minima)/i.test(texto)) {
    return 'Revisa el incremento de venta y la compra mínima: ambos deben ser positivos, compatibles con la unidad y el mínimo debe ser múltiplo del incremento.'
  }
  if (/identidad comercial/i.test(texto)) {
    return 'El código comercial del producto no se puede modificar.'
  }
  if (/uq_producto_slug|duplicate key/i.test(texto)) {
    return 'Ya existe un producto con un nombre similar. Ajusta el nombre e inténtalo de nuevo.'
  }
  if (!texto || /^PGRST|^column|^relation|^syntax|^null value|^new row|violates/i.test(texto)) {
    return mensajeSeguro(texto, fallback)
  }
  return mensajeSeguro(texto)
}

function validarNumerosProducto(patch = {}) {
  if (Object.prototype.hasOwnProperty.call(patch, 'precio')) {
    const precio = Number(patch.precio)
    if (
      !Number.isInteger(precio) ||
      precio < LIMITES_PRODUCTO.precioMin ||
      precio > LIMITES_PRODUCTO.precioMax
    ) {
      throw new Error(
        `El precio debe ser un entero entre ${LIMITES_PRODUCTO.precioMin} y ${LIMITES_PRODUCTO.precioMax} CLP.`,
      )
    }
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'stock')) {
    const stock = Number(patch.stock)
    if (
      !Number.isFinite(stock) ||
      stock < LIMITES_PRODUCTO.stockMin ||
      stock > LIMITES_PRODUCTO.stockMax ||
      Math.abs(stock - Math.round(stock * 10) / 10) > 1e-9
    ) {
      throw new Error(
        `El stock debe estar entre ${LIMITES_PRODUCTO.stockMin} y ${LIMITES_PRODUCTO.stockMax} y tener como máximo un decimal.`,
      )
    }
  }

  const incremento = patch.incremento_venta ?? patch.incrementoVenta
  const minimo = patch.cantidad_minima_compra ?? patch.cantidadMinimaCompra
  const unidad = patch.unidad_medida ?? patch.unidadMedida
  const validarCantidadComercial = (valor, etiqueta) => {
    const cantidad = Number(valor)
    const escalada = Math.round(cantidad * 10)
    if (
      !Number.isFinite(cantidad) ||
      cantidad <= 0 ||
      cantidad > LIMITES_PRODUCTO.stockMax ||
      Math.abs(cantidad - escalada / 10) > 1e-9
    ) {
      throw new Error(`${etiqueta} debe ser mayor que cero y tener como máximo un decimal.`)
    }
    if (
      unidad &&
      !['kg', 'g', 'litro', 'ml'].includes(String(unidad)) &&
      !Number.isInteger(cantidad)
    ) {
      throw new Error(`${etiqueta} debe ser una cantidad entera para esta unidad de medida.`)
    }
    return escalada
  }

  const incrementoEscalado =
    incremento === undefined ? null : validarCantidadComercial(incremento, 'El incremento de venta')
  const minimoEscalado =
    minimo === undefined ? null : validarCantidadComercial(minimo, 'La compra mínima')
  if (
    incrementoEscalado !== null &&
    minimoEscalado !== null &&
    minimoEscalado % incrementoEscalado !== 0
  ) {
    throw new Error('La compra mínima debe ser múltiplo del incremento de venta.')
  }
  if (minimoEscalado !== null && Object.prototype.hasOwnProperty.call(patch, 'stock')) {
    const stock = Number(patch.stock)
    if (Number.isFinite(stock) && stock > 0 && minimoEscalado / 10 > stock) {
      throw new Error('La compra mínima no puede superar el stock publicado.')
    }
  }
}

/**
 * Actualiza un producto.
 *
 * El `slug` no se recalcula: el trigger que lo genera es `before insert`, así que
 * en `UPDATE` la base de datos lo mantiene estable. Recalcularlo en el cliente
 * (como se hacía antes) chocaba con `uq_producto_slug` en cuanto dos productos
 * compartían nombre.
 *
 * Antes de escribir se verifica que el producto sea visible para el vendedor
 * (la RLS lo oculta si es de otro). Así se mantiene la validación de propiedad y
 * no se llega al `single()` que exponía el error de serialización HAL-VEN-016.
 */
export async function updateProducto(productoId, patch) {
  const client = getClient()
  validarNumerosProducto(patch)

  const { data: propio, error: errorPropiedad } = await client
    .from('productos')
    .select('id')
    .eq('id', productoId)
    .maybeSingle()
  if (errorPropiedad) {
    throw new Error('No pudimos verificar el producto. Inténtalo nuevamente.')
  }
  if (!propio) {
    throw new Error(
      'El producto no existe, fue eliminado o no pertenece a tu tienda. No se guardaron cambios.',
    )
  }

  const { data, error } = await client
    .from('productos')
    .update({ ...patch })
    .eq('id', productoId)
    .select()
    .maybeSingle()
  if (error) throw new Error(mensajeErrorProducto(error.message))
  if (!data) {
    throw new Error(
      'El producto no existe, fue eliminado o no pertenece a tu tienda. No se guardaron cambios.',
    )
  }
  return data
}

/** Actualiza sólo el stock de un producto (RF-003). */
export async function actualizarStock(productoId, stock) {
  return updateProducto(productoId, { stock: Number(stock) })
}

/**
 * Desactivación lógica del producto (RF-017): sale del catálogo sin borrarse.
 *
 * El trigger `controlar_estado_producto` exige `motivo_pausa` de 10 a 1000
 * caracteres cuando `activo` pasa de true a false. Sin este dato la acción
 * fallaba (HAL-VEN-014); el valor por defecto es una justificación válida y la
 * vista permite editarla antes de confirmar.
 */
export async function desactivarProducto(productoId, motivo = MOTIVO_PAUSA_POR_DEFECTO) {
  const texto = String(motivo ?? MOTIVO_PAUSA_POR_DEFECTO).trim()
  const error = validarMotivoProducto(texto)
  if (error) throw new Error(error)
  return updateProducto(productoId, { activo: false, motivo_pausa: texto })
}

/**
 * Eliminación lógica del producto por el vendedor (HAL-VEN-014).
 *
 * A diferencia de la pausa (`activo = false`), la eliminación marca
 * `eliminado_en` + `motivo_eliminacion` (igual que la lógica correcta de
 * /admin/productos): el producto ya NO se puede reactivar ni editar desde el
 * panel del vendedor. La justificación es obligatoria (10..1000 caracteres),
 * igual que en la pausa.
 */
export async function eliminarProductoVendedor(productoId, motivo) {
  const texto = String(motivo ?? '').trim()
  const error = validarMotivoProducto(texto)
  if (error) throw new Error(error)
  return updateProducto(productoId, {
    activo: false,
    eliminado_en: new Date().toISOString(),
    motivo_pausa: null,
    motivo_eliminacion: texto,
  })
}

/**
 * Reactivación: el trigger limpia `motivo_pausa` cuando el producto vuelve a
 * estar activo. HAL-VEN-014: un producto eliminado (`eliminado_en`) nunca se
 * puede reactivar; se rechaza antes de tocar la BD.
 */
export async function reactivarProducto(productoId) {
  const client = getClient()
  const { data: propio, error } = await client
    .from('productos')
    .select('id, eliminado_en')
    .eq('id', productoId)
    .maybeSingle()
  if (error) throw new Error('No pudimos verificar el producto. Inténtalo nuevamente.')
  if (propio?.eliminado_en) {
    throw new Error(
      'El producto fue eliminado y no se puede reactivar. Consulta el motivo en el detalle del inventario.',
    )
  }
  return updateProducto(productoId, { activo: true, motivo_pausa: null })
}

/* ---------------------------------------------------------------- */
/* Imágenes del producto (RF-003)                                      */
/* ---------------------------------------------------------------- */

/**
 * Sube la fotografía del producto (tomada con la cámara) y registra la fila en
 * `imagenes_productos`. La primera imagen queda como principal.
 *
 * La ruta DEBE ser `<uuid del producto>/<archivo>`: la policy de Storage
 * `storage_product_images_insert` autoriza con
 * `es_productor_actual_de_producto((storage.foldername(name))[1]::uuid)`, es
 * decir, castea el **primer** segmento de la ruta a uuid y lo interpreta como el
 * producto. Cualquier prefijo adicional (por ejemplo el uuid del perfil) hace que
 * la subida falle con «new row violates row-level security policy».
 */
export async function subirImagenProducto({
  productoId,
  file,
  textoAlternativo = null,
  esPrincipal = null,
}) {
  const client = getClient()
  const extension = (file.type?.split('/')[1] ?? 'jpg').replace('jpeg', 'jpg').split('+')[0]
  const nombre = `${productoId}-${Date.now()}.${extension}`
  const ruta = `${productoId}/${nombre}`

  const { error: upError } = await client.storage
    .from(STORAGE_BUCKETS.productos)
    .upload(ruta, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type,
    })
  if (upError) throw new Error(mensajeSeguro(upError))

  const { data: existentes } = await client
    .from('imagenes_productos')
    .select('id, es_principal, posicion')
    .eq('producto_id', productoId)

  // `uq_imagen_producto_posicion` es UNIQUE (producto_id, posicion): tras borrar
  // una imagen el conteo reutilizaría una posición ocupada, así que se toma la
  // posición siguiente al máximo real.
  const posicion =
    (existentes ?? []).reduce((max, img) => Math.max(max, Number(img.posicion ?? 0)), 0) + 1
  const principal = esPrincipal ?? (existentes?.length ?? 0) === 0

  if (principal && existentes?.length) {
    await client
      .from('imagenes_productos')
      .update({ es_principal: false })
      .eq('producto_id', productoId)
  }

  let imagen
  try {
    imagen = unwrap(
      await client
        .from('imagenes_productos')
        .insert({
          producto_id: productoId,
          ruta_storage: ruta,
          nombre_archivo: nombre,
          mime_type: file.type,
          tamano_bytes: file.size,
          texto_alternativo: textoAlternativo ?? null,
          posicion,
          es_principal: principal,
          metadatos: {},
        })
        .select()
        .single(),
      'No se pudo registrar la imagen del producto',
    )
  } catch (e) {
    // El archivo ya está en Storage: si la metadata no se pudo registrar, se
    // retira para no dejar objetos huérfanos en el bucket.
    await client.storage.from(STORAGE_BUCKETS.productos).remove([ruta])
    throw e
  }

  return { ...imagen, url: storageUrl(ruta, { bucket: STORAGE_BUCKETS.productos }) }
}

/**
 * RF-003: elimina una imagen en dos pasos — primero el archivo del bucket y
 * después su metadata en `imagenes_productos`.
 *
 * El borrado del archivo SÍ se comprueba: si Storage falla, la metadata se
 * conserva para no dejar una fila apuntando a un archivo que sigue existiendo (y
 * porque el error indica que la imagen no se pudo retirar realmente).
 */
export async function eliminarImagenProducto(imagen) {
  const client = getClient()
  if (imagen?.ruta_storage) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.productos)
      .remove([imagen.ruta_storage])
    if (removeError) {
      throw new Error(`No se pudo borrar el archivo de la imagen: ${removeError.message}`)
    }
  }
  return unwrap(
    await client.from('imagenes_productos').delete().eq('id', imagen.id),
    'No se pudo eliminar la imagen',
  )
}

/* ---------------------------------------------------------------- */
/* Portada de la tienda (imagen de fondo del perfil)                 */
/* ---------------------------------------------------------------- */

/**
 * Sube/reemplaza la portada de la tienda en el bucket público `store-covers`
 * dentro de la carpeta del productor y guarda la ruta en
 * `productores.portada_storage_path` (RLS permite el update al dueño).
 * Devuelve la URL pública de la nueva portada.
 */
export async function subirPortadaTienda({ productorId, file, rutaActual = null }) {
  const client = getClient()

  if (!file) {
    throw new Error('No se recibió ningún archivo')
  }

  const extensiones = {
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
  }
  const extension = extensiones[file.type]
  if (!extension) throw new Error('Selecciona una imagen JPG, PNG o WebP válida')

  if (file.size > 5 * 1024 * 1024) {
    throw new Error('La imagen no debe superar 5 MB')
  }

  // Una ruta nueva por carga evita que el navegador reutilice una portada
  // anterior almacenada en caché después de reemplazarla.
  const version =
    globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
  const ruta = `${productorId}/portada-${version}.${extension}`

  const { error: upError } = await client.storage
    .from(STORAGE_BUCKETS.portadasTienda)
    .upload(ruta, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type,
    })

  if (upError) {
    throw new Error(mensajeSeguro(upError))
  }

  try {
    unwrap(
      await client.from('productores').update({ portada_storage_path: ruta }).eq('id', productorId),
      'No se pudo guardar la portada de la tienda',
    )
  } catch (error) {
    // No dejamos un archivo huérfano si no se puede guardar la ruta en la tienda.
    await client.storage.from(STORAGE_BUCKETS.portadasTienda).remove([ruta])
    throw error
  }

  // La nueva portada ya quedó guardada en la BD. Si no se puede borrar la
  // anterior, se conserva como archivo residual sin ocultar la nueva imagen.
  if (rutaActual && rutaActual !== ruta) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.portadasTienda)
      .remove([rutaActual])
    if (removeError) {
      console.warn('[subirPortadaTienda] No se pudo limpiar la portada anterior', removeError)
    }
  }

  return storageUrl(ruta, { bucket: STORAGE_BUCKETS.portadasTienda })
}

/** Quita la portada personalizada: borra el objeto y limpia la columna. */
export async function quitarPortadaTienda({ productorId, rutaActual }) {
  const client = getClient()
  unwrap(
    await client.from('productores').update({ portada_storage_path: null }).eq('id', productorId),
    'No se pudo quitar la portada de la tienda',
  )
  if (rutaActual) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.portadasTienda)
      .remove([rutaActual])
    if (removeError) {
      console.warn('[quitarPortadaTienda] No se pudo borrar la portada anterior', removeError)
    }
  }
}

/* ---------------------------------------------------------------- */
/* Foto de perfil del vendedor                                     */
/* ---------------------------------------------------------------- */

/**
 * Sube/reemplaza la foto de perfil del vendedor en el bucket público `seller-avatars`
 * dentro de la carpeta del productor y guarda la ruta en
 * `productores.foto_perfil_storage_path` (RLS permite el update al dueño).
 * Devuelve la URL pública de la nueva foto.
 */
export async function subirFotoPerfil({ productorId, file, rutaActual = null }) {
  const client = getClient()

  if (!file) {
    throw new Error('No se recibió ningún archivo')
  }

  const extensiones = {
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
  }
  const extension = extensiones[file.type]
  if (!extension) throw new Error('Selecciona una imagen JPG, PNG o WebP válida')

  if (file.size > 5 * 1024 * 1024) {
    throw new Error('La imagen no debe superar 5 MB')
  }

  // Cada carga usa una ruta nueva. Así el navegador no reutiliza en caché la
  // foto anterior cuando el vendedor reemplaza su avatar.
  const version =
    globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
  const ruta = `${productorId}/avatar-${version}.${extension}`
  const { error: upError } = await client.storage
    .from(STORAGE_BUCKETS.avataresVendedor)
    .upload(ruta, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type,
    })

  if (upError) {
    throw new Error(mensajeSeguro(upError))
  }

  try {
    unwrap(
      await client
        .from('productores')
        .update({ foto_perfil_storage_path: ruta })
        .eq('id', productorId),
      'No se pudo guardar la foto de perfil',
    )
  } catch (error) {
    // No dejamos un archivo huérfano si la actualización de la tienda falla.
    await client.storage.from(STORAGE_BUCKETS.avataresVendedor).remove([ruta])
    throw error
  }

  // El borrado de la versión anterior no debe ocultar una foto recién guardada
  // si falla por red; la ruta actual en la base de datos ya es la nueva.
  if (rutaActual && rutaActual !== ruta) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.avataresVendedor)
      .remove([rutaActual])
    if (removeError)
      console.warn('[subirFotoPerfil] No se pudo limpiar la foto anterior', removeError)
  }

  return storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresVendedor })
}

/** Quita la foto de perfil personalizada: borra el objeto y limpia la columna. */
export async function quitarFotoPerfil({ productorId, rutaActual }) {
  const client = getClient()
  unwrap(
    await client
      .from('productores')
      .update({ foto_perfil_storage_path: null })
      .eq('id', productorId),
    'No se pudo quitar la foto de perfil',
  )
  if (rutaActual) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.avataresVendedor)
      .remove([rutaActual])
    if (removeError)
      console.warn('[quitarFotoPerfil] No se pudo borrar la foto anterior', removeError)
  }
}

/* ---------------------------------------------------------------- */
/* Ventas del vendedor (RF-003 y RF-011)                               */
/* ---------------------------------------------------------------- */

/**
 * Resumen de ventas del vendedor con poblaciones explícitas (HAL-VEN-004/017):
 *
 *   * `ventasAutorizadas`: pedidos con pago autorizado y no cancelados. Incluye
 *     los que aún no se entregan, por eso NO es dinero disponible.
 *   * `ventasEntregadas`: pedidos en estado `completado` (entrega cerrada).
 *   * `netoEntregado`: total menos comisión (`netoProductor`) sólo de los
 *     pedidos entregados. Es la única cifra rotulada como neta al productor.
 *   * `netoAutorizado`: el mismo cálculo sobre ventas autorizadas; se muestra
 *     como estimación, nunca como saldo disponible.
 *
 * Con Webpay Mall, Transbank resuelve el cobro en el commit del Mall: no hay
 * payout, liquidación ni retención de CuTuCo que justifique otra métrica.
 */
export async function getResumenVentas(productorId) {
  const client = getClient()
  const { data, error } = await client
    .from('pedidos')
    .select('id, estado, total, monto_fee_plataforma, creado_en')
    .eq('productor_id', productorId)
    .order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const pedidos = data ?? []
  const sumar = (rows, campo) =>
    Math.round(rows.reduce((acc, p) => acc + Number(p[campo] ?? 0), 0) * 100) / 100
  const sumarNeto = (rows) =>
    Math.round(rows.reduce((acc, p) => acc + netoProductor(p), 0) * 100) / 100

  const autorizados = pedidos.filter((p) => ESTADOS_VENTA_AUTORIZADA.includes(p.estado))
  const entregados = pedidos.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO)

  return {
    total: pedidos.length,
    pedidosAutorizados: autorizados.length,
    ventasAutorizadas: sumar(autorizados, 'total'),
    comisionesAutorizadas: sumar(autorizados, 'monto_fee_plataforma'),
    netoAutorizado: sumarNeto(autorizados),
    pedidosEntregados: entregados.length,
    ventasEntregadas: sumar(entregados, 'total'),
    comisionesEntregadas: sumar(entregados, 'monto_fee_plataforma'),
    netoEntregado: sumarNeto(entregados),
    pendientes: pedidos.filter((p) =>
      [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(p.estado),
    ).length,
    entregados: entregados.length,
    reclamados: pedidos.filter((p) => p.estado === ESTADO_PEDIDO.RECLAMADO).length,
    ultimo: pedidos[0] ?? null,
  }
}

export { readFileAsDataURL }

/* ==================================================================
 * SERVICIOS HEREDADOS — SÓLO GALERÍA DE DESARROLLO
 * ==================================================================
 * NOTA DE MIGRACIÓN (alcance anterior, ya se usa sólo en la ventana
 * "Alertas de stock" que la galería sigue mostrando):
 *   RF-010 (avisos automáticos de stock bajo) salió del alcance: el vendedor
 *   revisa su stock a mano en `SellerProductsView`. La tabla `alertas_stock` y
 *   la columna `productos.umbral_bajo` están declaradas como HERRAMIENTA DE
 *   DESARROLLO en la migración `20261006100000_add_gallery_legacy_tables.sql`.
 * ================================================================ */

/** Alertas de stock del vendedor (heredado). */
export async function listStockAlertas({ productorId = null, soloPendientes = false } = {}) {
  const client = getClient()
  let query = client.from('alertas_stock').select('*')
  if (soloPendientes) query = query.is('atendida_en', null)
  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  if (!data?.length) return []

  const productoIds = [...new Set(data.map((a) => a.producto_id))]
  const { data: productos } = await client.from('productos').select('*').in('id', productoIds)
  const productorMap = new Map((productos ?? []).map((p) => [p.id, p]))

  return data
    .map((alerta) => ({ ...alerta, producto: productorMap.get(alerta.producto_id) ?? null }))
    .filter((alerta) => (productorId ? alerta.producto?.productor_id === productorId : true))
}

/** Marca una alerta como atendida (heredado). */
export async function atenderAlerta(alertaId) {
  const client = getClient()
  return unwrap(
    await client
      .from('alertas_stock')
      .update({ atendida_en: new Date().toISOString() })
      .eq('id', alertaId)
      .select()
      .single(),
    'No se pudo marcar la alerta como atendida',
  )
}

/** Vigilancia de stock bajo por producto (heredado). */
export async function listProductosBajoUmbral({ productorId }) {
  const productos = await listProductosVendedor({ productorId, incluirInactivos: false })
  return productos.filter((p) => Number(p.stock) <= Number(p.umbral_bajo ?? 0))
}

/**
 * Panel de reputación del vendedor (heredado).
 * Devuelve el productor, su promedio real (`puntaje_reputacion`) y el historial
 * de calificaciones. Los criterios ponderados del score anterior
 * (`entrega_a_tiempo`, `calidad`, `respuesta_reclamos`) los declaró la
 * migración de galería y quedan nulos en los datos nuevos.
 */
export async function getDashboardVendedor({ productorId = null, dias = 365 } = {}) {
  const client = getClient()
  const productor = productorId
    ? await client
        .from('productores')
        .select('*')
        .eq('id', productorId)
        .maybeSingle()
        .then((r) => r.data)
    : await getProductorDeSesion()
  if (!productor) return null

  const desde = new Date(Date.now() - dias * 86400000).toISOString()
  const [evaluacionesRes, sancionesRes] = await Promise.all([
    client
      .from('evaluaciones_reputacion')
      .select('*')
      .eq('productor_id', productor.id)
      .gte('creado_en', desde)
      .order('creado_en', { ascending: false }),
    client
      .from('sanciones')
      .select('*')
      .eq('productor_id', productor.id)
      .order('inicio_en', { ascending: false }),
  ])

  return {
    productor,
    reputation: {
      puntaje: Number(productor.puntaje_reputacion ?? 0),
      cantidad: Number(productor.cantidad_evaluaciones ?? 0),
      activa: Boolean(productor.activo),
    },
    evaluaciones: evaluacionesRes.data ?? [],
    sanciones: sancionesRes.data ?? [],
  }
}

/** Sanciones del vendedor autenticado (heredado). */
export async function listMisSanciones() {
  const productor = await getProductorDeSesion()
  if (!productor) return []
  return listSancionesDeProductor(productor.id)
}

/** Apelaciones del vendedor autenticado (heredado). */
export async function listMisApelaciones() {
  const productor = await getProductorDeSesion()
  if (!productor) return []
  const client = getClient()
  const { data, error } = await client
    .from('apelaciones')
    .select('*')
    .eq('productor_id', productor.id)
    .order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/**
 * RF-026: el vendedor apela una sanción con su fundamento (máx. 3000 caracteres).
 *
 * Reglas del esquema que condicionan el envío:
 *   * `apelaciones_insert_vendedor` (RLS) exige `solicitante_id = auth.uid()` y
 *     que el productor sea del solicitante.
 *   * `uq_apelacion_pendiente_sancion` admite una sola apelación pendiente por
 *     sanción.
 *   * `validar_apelacion` exige que la sanción exista, que el productor coincida
 *     y que una apelación nueva quede en estado `pendiente`.
 *   * `trg_moderar_apelacion` valida el fundamento contra `palabras_prohibidas`.
 *   * `sincronizar_apelacion_sancion_al_crear` deja la sanción en `apelada` si
 *     estaba `activa`.
 */
export async function crearApelacion({ sancionId, productorId, fundamento }) {
  const client = getClient()
  const solicitanteId = await currentUserId()
  if (!solicitanteId) throw new Error('Debes iniciar sesión para apelar una sanción')
  const texto = String(fundamento ?? '').trim()
  if (!texto) throw new Error('Escribe el fundamento de la apelación')

  // El ban permanente no entra al flujo de apelaciones: el administrador lo
  // levanta con «Reactivar cuenta». Evitamos crear apelaciones que luego no
  // pueden resolverse desde el panel.
  const { data: sancion } = await client
    .from('sanciones')
    .select('accion')
    .eq('id', sancionId)
    .maybeSingle()
  if (sancion?.accion === 'ban_permanente') {
    throw new Error(
      'El ban permanente se revisa directamente con administración; no admite apelación.',
    )
  }

  const { data, error } = await client
    .from('apelaciones')
    .insert({
      sancion_id: sancionId,
      productor_id: productorId,
      solicitante_id: solicitanteId,
      fundamento: texto,
      estado: 'pendiente',
    })
    .select()
    .single()
  if (error) throw new Error(mensajeErrorApelacion(error.message))
  return data
}

/** Traduce los errores del esquema al apelar una sanción. */
function mensajeErrorApelacion(mensaje = '') {
  const texto = String(mensaje)
    .replace(/^.*?ERROR:\s*/i, '')
    .replace(/CONTEXT:.*$/s, '')
    .trim()
  if (/uq_apelacion_pendiente_sancion|duplicate key/i.test(texto)) {
    return 'Ya tienes una apelación pendiente para esta sanción.'
  }
  if (/palabra prohibida|moderad/i.test(texto)) {
    return 'El fundamento contiene palabras no permitidas. Reescríbelo con tus propias palabras.'
  }
  if (/sancion inexistente/i.test(texto)) return 'La sanción ya no existe.'
  if (/sancion inexistente/i.test(texto)) return 'La sanción ya no existe.'
  return mensajeSeguro(texto, 'No se pudo enviar la apelación')
}
