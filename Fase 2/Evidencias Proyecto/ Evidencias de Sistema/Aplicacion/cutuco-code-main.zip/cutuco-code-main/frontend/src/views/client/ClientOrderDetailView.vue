<script setup>
/**
 * CuTuCo — Detalle de un pedido del cliente (página 9 del diseño oficial).
 *
 * La línea de tiempo usa los 4 hitos base compartidos con el vendedor. «Descargar
 * comprobante (PDF)» entrega el comprobante del pedido en formato PDF con el
 * diseño de la plataforma.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_ENVIO, ESTADO_PAGO, ESTADO_PEDIDO, LABELS, MOTIVOS_RECLAMO } from '@/lib/constants'
import { formatCLP, formatDateTime, formatNumber, formatPhone, formatTime } from '@/lib/format'
import {
  estadoActualPedido,
  etiquetaEstadoActual,
  hitosPedido,
  motivoCancelacion,
  tonoEstadoActual,
} from '@/lib/orders'
import { formatearCantidad, getProductorDetalle } from '@/services/catalog'
import { createEvaluacion, getPedidoDetalle } from '@/services/orders'
import { crearReclamo, getReclamoVigenteDePedido } from '@/services/reclamos'
import { useUiStore } from '@/stores/ui'
import { tryGetClient } from '@/lib/supabase'

const SOPORTE = 'mailto:cutucosoporte@gmail.com'

const route = useRoute()
const ui = useUiStore()

const pedido = ref(null)
const productor = ref(null)
const cargando = ref(true)
const error = ref(null)
const enviandoEvaluacion = ref(false)
/**
 * RF-006: una sola calificación de 1 a 5 con comentario opcional.
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): los tres criterios
 * ponderados (entrega a tiempo, calidad y respuesta a reclamos) salieron del
 * alcance; el esquema sólo guarda `puntaje` y `comentario`.
 */
const evaluacion = ref({
  puntaje: 0,
  comentario: '',
})

/* ---------------------- código de entrega (RF-007) ---------------------- */

/**
 * HAL-VEN-018: el código lo muestra la plataforma al cliente y el **vendedor**
 * lo ingresa para cerrar la entrega. El cliente no valida el código ni llama a
 * la RPC; sólo lo entrega al vendedor.
 */
const codigoEntrega = computed(
  () => pedido.value?.envio?.codigo_verificacion ?? pedido.value?.codigo_entrega ?? null,
)
const codigoVerificado = computed(() => Boolean(pedido.value?.envio?.codigo_verificado_en))

/* ------------------------------- reclamos ------------------------------- */

/**
 * RF-025: reclamo vigente del pedido. El esquema admite un solo reclamo abierto
 * o en revisión por pedido (`uq_reclamo_abierto_por_pedido`), así que basta con
 * consultar el vigente para saber si se puede abrir otro.
 */
const reclamo = ref(null)
const modalReclamo = ref(false)
const guardandoReclamo = ref(false)
const errorReclamo = ref(null)
const formularioReclamo = ref({ motivo: '', descripcion: '' })

const opcionesMotivoReclamo = computed(() => MOTIVOS_RECLAMO.map((m) => ({ value: m, label: m })))
const puedeReclamar = computed(() => Boolean(pedido.value) && !reclamo.value)

const pedidoId = computed(() => route.params.id)

const subtotal = computed(() => Number(pedido.value?.subtotal_productos ?? 0))
const iva = computed(() => Number(pedido.value?.monto_iva ?? 0))
const tasaIva = computed(() => Number(pedido.value?.tasa_iva ?? 0))
const costoEnvio = computed(() =>
  pedido.value?.envio?.tarifa_fija != null
    ? Number(pedido.value.envio.tarifa_fija)
    : Math.max(0, Number(pedido.value?.total ?? 0) - subtotal.value - iva.value),
)
const comision = computed(() => Number(pedido.value?.monto_fee_plataforma ?? 0))
const total = computed(() => Number(pedido.value?.total ?? 0))
const cancelado = computed(() => pedido.value?.estado === ESTADO_PEDIDO.CANCELADO)
const motivoCancelacionPedido = computed(() => motivoCancelacion(pedido.value))
const entregaFallida = computed(
  () => !cancelado.value && pedido.value?.envio?.estado === ESTADO_ENVIO.FALLIDO,
)
/** No mostrar la tarjeta del código en pedidos cancelados o con entrega fallida. */
const mostrarCodigoEntrega = computed(
  () => Boolean(pedido.value?.envio) && !cancelado.value && !entregaFallida.value,
)

const documentoSolicitado = computed(() => {
  const documento = pedido.value?.documento_tributario
  if (!documento?.tipo) return null
  return documento.tipo === 'factura'
    ? 'Factura (la genera el productor)'
    : 'Boleta (la genera el productor)'
})

const yaConfirmado = computed(() => Boolean(pedido.value?.confirmado_cliente_en))
/**
 * HAL-VEN-018: el vendedor valida el código y cierra la entrega; el pedido
 * queda `completado`. La calificación se habilita recién en ese momento.
 */
const puedeEvaluar = computed(
  () => pedido.value?.estado === ESTADO_PEDIDO.COMPLETADO && !pedido.value?.evaluacion,
)
const evaluacionCompleta = computed(
  () => Number(evaluacion.value.puntaje) >= 1 && Number(evaluacion.value.puntaje) <= 5,
)

const columnasProductos = [
  { key: 'producto_nombre', label: 'Producto' },
  { key: 'codigo_producto', label: 'Código', width: '120px' },
  { key: 'precio_unitario', label: 'Precio Unit.', align: 'right', width: '130px' },
  { key: 'cantidad', label: 'Cantidad', align: 'right', width: '110px' },
  { key: 'subtotal', label: 'Subtotal', align: 'right', width: '130px' },
]

/**
 * Línea de tiempo de "Seguimiento de Entrega": reutiliza los 4 hitos base que
 * comparte con el vendedor (`hitosPedido`, HAL-VEN-030) y no inventa hitos por
 * rol. La fecha de preparación sale de `envios.preparado_en` (acción real del
 * vendedor); nunca se usa `envios.creado_en`, que es el alta automática del
 * envío al pagar (HAL-CLI-010).
 */
const hitos = computed(() => {
  if (!pedido.value) return []
  const envio = pedido.value.envio
  const preparadoEn = envio?.preparado_en ?? null
  return hitosPedido(pedido.value).map((hito) => {
    if (hito.key !== ESTADO_ENVIO.PREPARACION) {
      return {
        key: hito.key,
        titulo: hito.label,
        detalle: hito.description,
        momento: hito.meta,
        estado: hito.estado,
        failed: hito.failed,
        cancelado: hito.cancelado,
      }
    }
    // La preparación sólo tiene fecha si el vendedor la registró
    // (`envios.preparado_en`). `envios.creado_en` es el alta automática del
    // envío al pagar y no se usa como fecha de preparación (HAL-CLI-010).
    return {
      key: hito.key,
      titulo: hito.label,
      detalle: hito.description,
      momento: preparadoEn,
      estado: preparadoEn ? 'hecho' : hito.estado,
      failed: hito.failed,
      cancelado: hito.cancelado,
    }
  })
})

const urlSoporte = computed(
  () =>
    `${SOPORTE}?subject=${encodeURIComponent(`Pedido ${pedido.value?.codigo_pedido ?? ''}`)}&body=${encodeURIComponent(
      `Hola, necesito ayuda con el pedido ${pedido.value?.codigo_pedido ?? ''} (${pedido.value?.id ?? ''}).`,
    )}`,
)

const emailProductor = computed(() => productor.value?.perfil?.email ?? null)

async function descargarComprobante() {
  try {
    const client = tryGetClient()
    let token = null
    if (client?.auth?.getSession) {
      const { data } = await client.auth.getSession()
      token = data?.session?.access_token ?? null
    }
    const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(
      /\/$/,
      '',
    )
    const res = await fetch(`${API_BASE_URL}/api/webpay/comprobante/${pedido.value.id}/pdf`, {
      method: 'GET',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
    if (!res.ok) {
      const text = await res.text()
      throw new Error(text || `Error ${res.status} al descargar el comprobante`)
    }
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `comprobante-${pedido.value.codigo_pedido}.pdf`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    // No revocar sincrónicamente: algunos navegadores cancelan la descarga si
    // el blob URL se libera en el mismo tick del click.
    setTimeout(() => URL.revokeObjectURL(url), 10_000)
    ui.info('Comprobante descargado', 'Se descargó el PDF de tu boleta/factura')
  } catch (e) {
    ui.error('Error al descargar', e?.message ?? 'No se pudo descargar el comprobante')
  }
}

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const resultado = await getPedidoDetalle(pedidoId.value)
    if (!resultado) {
      error.value = 'No encontramos el pedido solicitado'
      return
    }
    pedido.value = resultado
    productor.value = await getProductorDetalle(resultado.productor_id)
    reclamo.value = await getReclamoVigenteDePedido(resultado.id)
    if (resultado.evaluacion) {
      evaluacion.value = {
        puntaje: Number(resultado.evaluacion.puntaje ?? 0),
        comentario: resultado.evaluacion.comentario ?? '',
      }
    }
  } catch (e) {
    error.value = e?.message ?? 'No se pudo cargar el pedido'
  } finally {
    cargando.value = false
  }
}

/* --------------------------- abrir un reclamo --------------------------- */

function abrirModalReclamo() {
  errorReclamo.value = null
  formularioReclamo.value = { motivo: '', descripcion: '' }
  modalReclamo.value = true
}

/** RF-025: registra el reclamo del cliente sobre este pedido. */
async function enviarReclamo() {
  errorReclamo.value = null
  if (!formularioReclamo.value.motivo) {
    errorReclamo.value = 'Selecciona el motivo del reclamo'
    return
  }
  if (!formularioReclamo.value.descripcion.trim()) {
    errorReclamo.value = 'Describe lo que ocurrió con tu pedido'
    return
  }
  guardandoReclamo.value = true
  try {
    await crearReclamo({
      pedidoId: pedido.value.id,
      motivo: formularioReclamo.value.motivo,
      descripcion: formularioReclamo.value.descripcion,
    })
    modalReclamo.value = false
    ui.success('Reclamo registrado', 'El administrador tramitará tu reclamo y te contactará')
    await cargar()
  } catch (e) {
    errorReclamo.value = e?.message ?? 'No se pudo registrar el reclamo'
  } finally {
    guardandoReclamo.value = false
  }
}

async function enviarEvaluacion() {
  if (!evaluacionCompleta.value) {
    ui.warning('Falta la calificación', 'Elige una nota de 1 a 5 estrellas para el vendedor.')
    return
  }
  enviandoEvaluacion.value = true
  try {
    await createEvaluacion({
      pedidoId: pedido.value.id,
      puntaje: Number(evaluacion.value.puntaje),
      comentario: evaluacion.value.comentario || null,
    })
    ui.success('Calificación enviada', 'Gracias por valorar a este vendedor.')
    await cargar()
  } catch (e) {
    ui.error('No se pudo guardar la calificación', e?.message)
  } finally {
    enviandoEvaluacion.value = false
  }
}

onMounted(cargar)
watch(pedidoId, cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <CtButton to="/cliente/pedidos" variant="ghost" size="sm" class="volver">
          <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
          Volver al Historial
        </CtButton>
        <h1 class="page-head__title">
          Pedido <span class="mono">{{ pedido?.codigo_pedido ?? '—' }}</span>
        </h1>
        <p class="page-head__subtitle">
          Realizado el {{ formatDateTime(pedido?.creado_en) }} · Garantía CuTuCo Activa
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="!pedido" @click="descargarComprobante">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Descargar comprobante (PDF)
        </CtButton>
        <CtButton variant="secondary" :href="urlSoporte">
          <template #icon><CtIcon name="mail" :size="16" /></template>
          Contactar soporte
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="cargando" label="Cargando el pedido" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo mostrar el pedido">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" to="/cliente/pedidos">Ver mis pedidos</CtButton>
    </CtAlert>

    <template v-else-if="pedido">
      <div class="chips">
        <CtBadge tone="success" dot>Garantía CuTuCo Activa</CtBadge>
        <CtBadge :tone="tonoEstadoActual(estadoActualPedido(pedido))" size="sm">
          {{ etiquetaEstadoActual(estadoActualPedido(pedido)) }}
        </CtBadge>
        <StatusBadge v-if="pedido.pago" type="pago" :value="pedido.pago.estado" size="sm" />
        <CtBadge v-if="pedido.estado === ESTADO_PEDIDO.RECLAMADO" tone="danger" size="sm">
          Reclamo en trámite
        </CtBadge>
      </div>

      <CtAlert
        v-if="pedido.estado === ESTADO_PEDIDO.RECLAMADO"
        tone="danger"
        title="Este pedido tiene un reclamo abierto"
      >
        <p class="linea">
          <CtIcon name="alert" :size="16" />
          <span>
            CuTuCo registra este reclamo como constancia. Coordina directamente con el productor la
            solución fuera de la plataforma; este registro no cambia el pago.
          </span>
        </p>
      </CtAlert>

      <CtAlert
        v-else-if="pedido.pago?.estado === ESTADO_PAGO.AUTORIZADO && !yaConfirmado"
        tone="info"
        title="Pago autorizado por Webpay Mall"
      >
        <p class="linea">
          <CtIcon name="lock" :size="16" />
          <span>
            Tu pago se confirmó. El productor recibe el pago de su venta y CuTuCo descuenta su
            comisión, sin sumar un cobro extra a tu total.
          </span>
        </p>
      </CtAlert>

      <div class="detalle">
        <div class="detalle__principal stack">
          <!-- ============== Seguimiento de entrega ============== -->
          <CtCard title="Seguimiento de Entrega" subtitle="Hitos reales registrados en tu pedido">
            <ol class="linea-tiempo">
              <li v-for="hito in hitos" :key="hito.key" class="hito" :class="`is-${hito.estado}`">
                <span class="hito__marca" aria-hidden="true">
                  <CtIcon v-if="hito.estado !== 'pendiente'" name="check" :size="13" />
                  <span v-else class="hito__punto" />
                </span>
                <div class="hito__cuerpo">
                  <p class="hito__titulo">{{ hito.titulo }}</p>
                  <p class="hito__detalle">{{ hito.detalle }}</p>
                  <p v-if="hito.momento" class="hito__fecha">
                    {{ formatDateTime(hito.momento) }} · {{ formatTime(hito.momento) }}
                  </p>
                  <p v-else-if="hito.estado === 'hecho'" class="hito__fecha is-pendiente">
                    Fecha no registrada
                  </p>
                  <p v-else-if="hito.estado === 'actual'" class="hito__fecha is-pendiente">
                    En curso
                  </p>
                  <p v-else class="hito__fecha is-pendiente">Pendiente</p>
                </div>
              </li>
            </ol>

            <CtAlert v-if="cancelado" tone="danger" compact class="seguimiento__nota">
              <p class="linea">
                <CtIcon name="alert" :size="15" />
                <span class="texto-largo">
                  El pedido fue cancelado{{
                    motivoCancelacionPedido ? `: ${motivoCancelacionPedido}` : ''
                  }}. La cancelación es un evento distinto de una entrega fallida.
                </span>
              </p>
            </CtAlert>
            <CtAlert v-else-if="entregaFallida" tone="danger" compact class="seguimiento__nota">
              <p class="linea">
                <CtIcon name="alert" :size="15" />
                <span class="texto-largo"
                  >La entrega falló:
                  {{ pedido.envio?.motivo_fallo || 'sin motivo registrado' }}.</span
                >
              </p>
            </CtAlert>
          </CtCard>

          <!-- ============== Código de entrega ============== -->
          <CtCard
            v-if="mostrarCodigoEntrega"
            title="Código de entrega"
            subtitle="Comparte estos 6 dígitos con el vendedor para cerrar la entrega"
          >
            <div class="stack stack--sm">
              <template v-if="codigoEntrega">
                <div class="codigo">
                  <span class="eyebrow">Código de entrega · 6 dígitos</span>
                  <p class="codigo__valor mono">{{ codigoEntrega }}</p>
                  <p v-if="!codigoVerificado" class="codigo__nota">
                    Entrega estos 6 dígitos al vendedor para que confirme la entrega. El cliente no
                    lo ingresa en la plataforma: sólo lo muestra y se lo comunica al vendedor.
                  </p>
                  <p v-else class="codigo__nota">
                    El vendedor ya confirmó la entrega con este código.
                  </p>
                </div>

                <div class="row row--wrap">
                  <CtBadge :tone="codigoVerificado ? 'success' : 'warning'" size="sm" dot>
                    {{
                      codigoVerificado
                        ? 'Entrega confirmada por el vendedor'
                        : 'Pendiente de confirmación del vendedor'
                    }}
                  </CtBadge>
                  <span
                    v-if="codigoVerificado && pedido.envio?.codigo_verificado_en"
                    class="text-xs text-muted"
                  >
                    {{ formatDateTime(pedido.envio.codigo_verificado_en) }}
                  </span>
                </div>
              </template>

              <CtAlert v-else tone="info" compact>
                <p>
                  El código se generará cuando el pedido salga a reparto. Cuando lo tengas,
                  entrégalo al vendedor para que confirme la entrega.
                </p>
              </CtAlert>
            </div>
          </CtCard>

          <!-- ============== Detalle de productos ============== -->
          <CtCard title="Detalle de Productos">
            <template #actions>
              <CtButton
                v-if="emailProductor"
                size="sm"
                variant="secondary"
                :href="`mailto:${emailProductor}?subject=${encodeURIComponent(`Pedido ${pedido.codigo_pedido}`)}`"
              >
                <template #icon><CtIcon name="mail" :size="15" /></template>
                Contactar Productor
              </CtButton>
            </template>

            <CtTable
              :columns="columnasProductos"
              :rows="pedido.detalles"
              empty-icon=""
              empty-title="Sin productos"
              empty-message="Este pedido no tiene ítems registrados."
              min-width="520px"
            >
              <template #cell-producto_nombre="{ row }">
                <router-link :to="`/producto/${row.producto_id}`" class="producto-enlace">
                  {{ row.producto_nombre }}
                </router-link>
              </template>
              <template #cell-codigo_producto="{ row }">
                <span class="mono">{{ row.codigo_producto ?? '—' }}</span>
              </template>
              <template #cell-precio_unitario="{ row }">
                {{ formatCLP(row.precio_unitario) }}
              </template>
              <template #cell-cantidad="{ row }">
                {{ formatearCantidad(row.cantidad, row.unidad) }}
                {{ LABELS.unidad[row.unidad] ?? row.unidad ?? '' }}
              </template>
              <template #cell-subtotal="{ row }">
                <span class="font-semibold">{{ formatCLP(row.subtotal) }}</span>
              </template>
            </CtTable>

            <p v-if="!emailProductor" class="nota-contacto">
              <CtIcon name="info" :size="14" />
              <span>
                El pedido no expone el correo del productor. Usa «Contactar soporte» en el
                encabezado; el enlace incluye el identificador de este pedido.
              </span>
            </p>
          </CtCard>

          <CtCard v-if="puedeEvaluar" title="Califica al vendedor" padding="md">
            <div class="stack">
              <p class="text-sm text-soft">
                Tu nota se promedia con las demás calificaciones del vendedor. Sólo puedes calificar
                una vez por pedido.
              </p>
              <div class="puntaje">
                <span class="puntaje__label">Tu nota</span>
                <CtRatingStars
                  v-model="evaluacion.puntaje"
                  :max="5"
                  interactive
                  :size="26"
                  show-value
                />
              </div>
              <CtTextarea
                v-model="evaluacion.comentario"
                label="Comentario (opcional)"
                placeholder="Cuéntanos cómo fue tu experiencia con este vendedor"
                :rows="4"
                :maxlength="2000"
                show-count
              />
              <div class="row">
                <CtButton
                  :loading="enviandoEvaluacion"
                  :disabled="!evaluacionCompleta"
                  @click="enviarEvaluacion"
                >
                  Enviar calificación
                </CtButton>
              </div>
            </div>
          </CtCard>

          <CtCard v-else-if="pedido.evaluacion" title="Tu calificación" padding="md">
            <div class="stack stack--sm">
              <div class="row row--wrap">
                <CtRatingStars
                  :model-value="Number(pedido.evaluacion.puntaje)"
                  :size="18"
                  show-value
                />
                <CtBadge tone="success" size="sm">
                  {{ Number(pedido.evaluacion.puntaje) }}/5
                </CtBadge>
                <span v-if="pedido.evaluacion.creado_en" class="text-xs text-muted">
                  {{ formatDateTime(pedido.evaluacion.creado_en) }}
                </span>
              </div>
              <p v-if="pedido.evaluacion.comentario" class="text-sm text-soft">
                {{ pedido.evaluacion.comentario }}
              </p>
            </div>
          </CtCard>

          <!-- ============== Reclamos ============== -->
          <CtCard v-if="reclamo" title="Reclamo abierto" padding="md">
            <div class="stack stack--sm">
              <div class="row row--wrap">
                <StatusBadge type="reclamo" :value="reclamo.estado" />
                <span class="text-xs text-muted">{{ formatDateTime(reclamo.creado_en) }}</span>
              </div>
              <p class="text-sm text-soft texto-largo">
                <strong>{{ reclamo.motivo }}</strong>
              </p>
              <p class="text-sm text-soft texto-largo">{{ reclamo.descripcion }}</p>
              <CtAlert tone="warning" compact>
                <p class="linea">
                  <CtIcon name="lock" :size="15" />
                  <span>
                    El reclamo no bloquea dinero: lo tramita el administrador y puede derivar en un
                    reembolso.
                  </span>
                </p>
              </CtAlert>
              <CtButton variant="secondary" :to="`/cliente/reclamos/${reclamo.id}`">
                <template #icon><CtIcon name="alert" :size="16" /></template>
                Ver el reclamo
              </CtButton>
            </div>
          </CtCard>

          <CtCard v-else-if="puedeReclamar" title="¿Algo salió mal con este pedido?" padding="md">
            <p class="text-sm text-soft">
              Puedes dejar constancia de un problema con el pedido. Luego, coordina directamente con
              el productor una solución fuera de CuTuCo; este registro no crea reembolsos automáticos.
            </p>
            <CtButton variant="secondary" @click="abrirModalReclamo">
              <template #icon><CtIcon name="alert" :size="16" /></template>
              Abrir reclamo
            </CtButton>
          </CtCard>
        </div>

        <!-- ================== Columna derecha ================== -->
        <aside class="detalle__aside stack">
          <CtCard title="Vendido por" padding="md">
            <div class="vendedor">
              <div class="vendedor__head">
                <span class="vendedor__icono"><CtIcon name="store" :size="20" /></span>
                <div>
                  <p class="vendedor__nombre">
                    {{ pedido.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
                  </p>
                  <p class="vendedor__lugar">
                    {{ pedido.comuna?.nombre ?? 'Región no informada' }}
                  </p>
                </div>
              </div>

              <div class="vendedor__puntaje">
                <CtRatingStars
                  :model-value="Number(productor?.puntaje_reputacion ?? 0)"
                  :size="15"
                  show-value
                />
                <span class="text-xs text-muted">
                  {{ formatNumber(productor?.cantidad_evaluaciones ?? 0) }} reseñas
                </span>
              </div>

              <CtBadge :tone="productor?.activo ? 'success' : 'danger'" size="sm">
                {{ productor?.activo ? 'Identidad Verificada' : 'Tienda Pausada' }}
              </CtBadge>
            </div>
          </CtCard>

          <CtCard title="Información de Envío" padding="md">
            <dl class="datos">
              <div class="dato">
                <dt class="dato__label">Dirección</dt>
                <dd class="dato__valor">{{ pedido.direccion_entrega }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Comuna</dt>
                <dd class="dato__valor">
                  {{ pedido.comuna?.nombre ?? '—' }}
                  <span v-if="pedido.envio?.repartidor" class="dato__nota">
                    Repartidor: {{ pedido.envio.repartidor.nombre }}
                    {{ pedido.envio.repartidor.apellido ?? '' }}
                  </span>
                </dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Instrucciones de despacho</dt>
                <dd class="dato__valor">{{ pedido.referencia_entrega || 'Sin instrucciones' }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Documento solicitado</dt>
                <dd class="dato__valor">
                  {{ documentoSolicitado ?? 'No registrado' }}
                </dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Comprobante</dt>
                <dd class="dato__valor">PDF descargable del pedido (no es factura electrónica)</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Método de pago</dt>
                <dd class="dato__valor">
                  Webpay{{ pedido.pago ? ` · ${LABELS.pago[pedido.pago.estado]}` : ' · Pendiente' }}
                </dd>
              </div>
              <div v-if="pedido.telefono_destinatario" class="dato">
                <dt class="dato__label">Contacto</dt>
                <dd class="dato__valor">{{ formatPhone(pedido.telefono_destinatario) }}</dd>
              </div>
            </dl>
          </CtCard>

          <CtCard title="Totales" padding="md">
            <div class="totales">
              <div class="totales__fila">
                <span>Productos (neto)</span>
                <span class="totales__valor">{{ formatCLP(subtotal) }}</span>
              </div>
              <div class="totales__fila">
                <span>Despacho (neto)</span>
                <span class="totales__valor">{{ formatCLP(costoEnvio) }}</span>
              </div>
              <div v-if="iva || tasaIva" class="totales__fila">
                <span>IVA ({{ tasaIva * 100 }}%)</span>
                <span class="totales__valor">{{ formatCLP(iva) }}</span>
              </div>
              <div class="totales__fila is-suave">
                <span>Comisión de plataforma (5%, la descuenta CuTuCo al productor)</span>
                <span class="totales__valor">{{ formatCLP(comision) }}</span>
              </div>
              <div class="totales__separador" />
              <div class="totales__fila is-total">
                <span>Total (IVA incluido)</span>
                <span class="totales__total">{{ formatCLP(total) }}</span>
              </div>
              <CtMoneyInfo title="Cómo se calcula este total">
                <p>
                  El total corresponde a productos y envío netos más el IVA registrado al pagar. La
                  comisión se descuenta al productor y no se suma aparte.
                </p>
              </CtMoneyInfo>
              <p class="totales__moneda">Montos en pesos chilenos (CLP)</p>
            </div>
          </CtCard>

          <CtCard title="Compra Protegida" padding="md" class="protegida">
            <ul class="garantias">
              <li>
                <CtIcon name="lock" :size="15" />
                <span>Pago seguro con Webpay: el productor recibe el pago de su venta.</span>
              </li>
              <li>
                <CtIcon name="truck" :size="15" />
                <span>Seguimiento con la fecha real de cada transición del envío.</span>
              </li>
              <li>
                <CtIcon name="scale" :size="15" />
                <span>Ante un problema puedes registrar una constancia y coordinar con el productor.</span>
              </li>
            </ul>
          </CtCard>
        </aside>
      </div>
    </template>

    <CtModal v-model="modalReclamo" title="Abrir un reclamo" size="md">
      <div class="stack">
        <CtAlert v-if="errorReclamo" tone="danger">{{ errorReclamo }}</CtAlert>

        <p class="text-sm text-soft">
          Pedido <span class="mono font-semibold">{{ pedido?.codigo_pedido }}</span> ·
          {{ pedido?.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
        </p>

        <CtSelect
          v-model="formularioReclamo.motivo"
          label="Motivo"
          :options="opcionesMotivoReclamo"
          placeholder="Selecciona el motivo"
          required
        />
        <CtTextarea
          v-model="formularioReclamo.descripcion"
          label="¿Qué ocurrió?"
          placeholder="Cuéntanos con detalle qué pasó con tu pedido"
          :rows="5"
          :maxlength="2500"
          show-count
          required
        />
        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              Un pedido admite un solo reclamo abierto a la vez y el texto pasa por la moderación de
              la plataforma.
            </span>
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="guardandoReclamo" @click="modalReclamo = false">
          Cancelar
        </CtButton>
        <CtButton :loading="guardandoReclamo" @click="enviarReclamo">Enviar reclamo</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.volver {
  margin-bottom: var(--ct-space-2);
  margin-inline-start: calc(-1 * var(--ct-space-3));
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

/* HAL-VEN-027: textos largos (motivos de reclamo, cancelación o entrega
   fallida) ajustan la línea en lugar de desbordar el contenedor. */
.texto-largo {
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.chips {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.detalle {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

.detalle__principal,
.detalle__aside {
  min-width: 0;
}

@media (max-width: 1100px) {
  .detalle {
    grid-template-columns: minmax(0, 1fr);
  }
}

/* ------------------------- línea de tiempo ------------------------- */

.linea-tiempo {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.hito {
  position: relative;
  display: flex;
  gap: var(--ct-space-4);
  padding-bottom: var(--ct-space-5);
}

.hito:last-child {
  padding-bottom: 0;
}

.hito:not(:last-child)::before {
  content: '';
  position: absolute;
  top: 26px;
  left: 12px;
  width: 2px;
  height: calc(100% - 8px);
  background: var(--ct-border);
}

.hito.is-hecho:not(:last-child)::before {
  background: var(--ct-primary);
}

.hito__marca {
  position: relative;
  z-index: 1;
  width: 26px;
  height: 26px;
  flex-shrink: 0;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-surface);
  border: 2px solid var(--ct-border-strong);
  color: var(--ct-text-muted);
}

.hito.is-hecho .hito__marca {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.hito__punto {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: currentcolor;
}

.hito__cuerpo {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.hito__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.hito.is-actual .hito__marca {
  box-shadow: 0 0 0 4px var(--ct-primary-soft);
}

.hito.is-fallido .hito__marca {
  background: var(--ct-danger-soft);
  border-color: var(--ct-danger);
  color: var(--ct-danger);
}

.seguimiento__nota {
  margin-top: var(--ct-space-4);
}

.hito:not(.is-hecho):not(.is-actual) .hito__titulo {
  color: var(--ct-text-soft);
}

.hito__detalle {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  overflow-wrap: anywhere;
  word-break: break-word;
}

.hito__fecha {
  font-size: var(--ct-fs-xs);
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-medium);
}

.hito__fecha.is-pendiente {
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-regular);
}

/* ------------------------ código de entrega ------------------------ */

.codigo {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--ct-space-3) var(--ct-space-4);
  border: 1px dashed var(--ct-border-strong);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-sunken);
}

.codigo__valor {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: 0.14em;
}

.codigo__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

/* ---------------------------- producto ---------------------------- */

.producto-enlace {
  color: var(--ct-text);
  font-weight: var(--ct-fw-semibold);
}

.producto-enlace {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
}

.producto-enlace:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.nota-contacto {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-4);
  padding: var(--ct-space-3);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.puntaje {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.puntaje__label {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

/* ---------------------------- vendedor ---------------------------- */

.vendedor {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  align-items: flex-start;
}

.vendedor__head {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.vendedor__icono {
  width: 40px;
  height: 40px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  display: grid;
  place-items: center;
}

.vendedor__nombre {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: var(--ct-tracking-tight);
}

.vendedor__lugar {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.vendedor__puntaje {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

/* ----------------------------- datos ----------------------------- */

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.dato__nota {
  display: block;
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-regular);
  color: var(--ct-text-muted);
}

.totales {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.totales__fila {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.totales__fila.is-suave {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.totales__valor {
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.totales__separador {
  height: 1px;
  background: var(--ct-border);
  margin: var(--ct-space-2) 0;
}

.totales__fila.is-total {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.totales__total {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  color: var(--ct-primary-strong);
}

.totales__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.totales__moneda {
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  font-weight: var(--ct-fw-semibold);
}

.garantias {
  list-style: none;
  margin: 0 0 var(--ct-space-4);
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.garantias li {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.garantias li > svg {
  color: var(--ct-primary-strong);
  margin-top: 2px;
}

.protegida__boton {
  margin-top: auto;
}
/* HAL-VEN-027: textos largos de reclamos o motivos no desbordan la tabla. */
:deep(.ct-table td) {
  overflow-wrap: anywhere;
  word-break: break-word;
  min-width: 0;
}
</style>
