/**
 * CuTuCo — Lote 11 (Registro cliente), lado frontend.
 *
 * CK-0019: formulario con todos los campos. CK-0022: confirmación de contraseña.
 * CK-0024: alta con confirmación de correo (metadata + GoTrue). CK-0032: borrador
 * de compra se recupera tras el alta. CK-0364/0366/0370/0372: validaciones de interfaz.
 * CK-0376: comunas filtradas por la región elegida. CK-0444 (HAL-REG-001): teléfono
 * obligatorio en ambos registros. CK-0445 (HAL-REG-002): ayuda = política real.
 * CK-0446 (HAL-REG-003): fortaleza coherente con el error. CK-0447 (HAL-REG-004):
 * depto_oficina en registro cliente. CK-0454 (HAL-REG-011): tope 72 de GoTrue.
 * CK-0460 (HAL-REG-017): validación por etapa antes de avanzar.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0019 · formulario de registro completo', () => {
  it('RegisterView presenta nombre, apellido, correo, teléfono, contraseña+confirmación, región, comuna y dirección', () => {
    const v = src('views/auth/RegisterView.vue')
    for (const campo of ['nombre', 'apellido', 'email', 'telefono', 'password', 'confirmacion', 'regionId', 'comunaId', 'calle', 'deptoOficina']) {
      expect(v).toContain(campo)
    }
  })
})

describe('CK-0022 · confirmación de contraseña', () => {
  it('mensajeConfirmacion señala la discrepancia', async () => {
    const { mensajeConfirmacion } = await import('@/services/registro.js')
    expect(mensajeConfirmacion('Clave1234!', 'OtraClave1!')).toMatch(/coinciden|iguales/i)
    expect(mensajeConfirmacion('Clave1234!', 'Clave1234!')).toBeNull()
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('mensajeConfirmacion')
  })
})

describe('CK-0024 · alta con verificación de correo', () => {
  it('signUp envía metadata para el trigger y GoTrue envía la verificación', () => {
    const servicio = src('services/registro.js')
    expect(servicio).toContain('tipo_registro')
    // el alta vía auth.signUp dispara el correo de confirmación de GoTrue
    expect(servicio).toMatch(/signUp\(/)
  })

  it('oculta el formulario y bloquea reenvíos de registro después de pedir confirmación', () => {
    const vista = src('views/auth/RegisterView.vue')
    expect(vista).toContain('v-if="!requiereConfirmacionPantalla"')
    expect(vista).toContain('enviando.value || requiereConfirmacionPantalla.value')
  })
})

describe('CK-0032 · volver al checkout tras el alta', () => {
  it('el registro recupera el borrador de compra y el checkout revalida stock y precios', () => {
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('draft')
    const carrito = src('stores/cart.js')
    expect(carrito).toContain("cutuco:carrito") // el carrito sobrevive al alta (localStorage)
    expect(carrito).toContain('localStorage')
  })
})

describe('CK-0364/0366/0370/0372 · validaciones de interfaz', () => {
  it('nombre, correo, teléfono y contraseña rechazan entradas inválidas', async () => {
    const { mensajeNombre, mensajeEmail, mensajeTelefono, mensajePassword } = await import('@/services/registro.js')
    expect(mensajeNombre('   ')).toBeTruthy()
    expect(mensajeNombre('Ana')).toBeNull()
    expect(mensajeEmail('sin-arroba')).toBeTruthy()
    expect(mensajeEmail('sin@dominio')).toBeTruthy()
    expect(mensajeEmail('ana@example.cl')).toBeNull()
    expect(mensajeTelefono('')).toBeTruthy()
    expect(mensajeTelefono('+54911111111')).toBeTruthy() // prefijo extranjero
    expect(mensajeTelefono('+56912345678')).toBeNull()
    expect(mensajePassword('')).toBeTruthy()
    expect(mensajePassword('corta')).toBeTruthy() // fuera de política
    expect(mensajePassword('Clave1234!')).toBeNull()
  })
})

describe('CK-0376 · comuna coherente con la región', () => {
  it('las comunas ofrecidas se filtran por la región seleccionada y el select queda deshabilitado sin región', () => {
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('geo.comunasDeRegion(form.regionId)')
    expect(v).toContain(':disabled="!form.regionId"')
    expect(v).toContain("Selecciona tu comuna")
  })
})

describe('CK-0444 (HAL-REG-001) · teléfono +56 obligatorio en ambos registros', () => {
  it('RegisterView y RegisterSellerView marcan teléfono como obligatorio', () => {
    for (const v of ['views/auth/RegisterView.vue', 'views/auth/RegisterSellerView.vue']) {
      const c = src(v)
      expect(c).toContain('telefono')
      expect(c).toMatch(/required/)
    }
    const pol = src('__tests__/registro-politicas.spec.js')
    expect(pol).toContain('REG-TEL')
  })
})

describe('CK-0445 (HAL-REG-002) · ayuda de contraseña = política real', () => {
  it('PASSWORD_REQUIREMENTS describe exactamente lo que mensajePassword exige', async () => {
    const { PASSWORD_REQUIREMENTS, passwordChecks } = await import('@/lib/validation.js')
    const texto = PASSWORD_REQUIREMENTS.map((r) => r.label).join(' ')
    expect(texto).toContain('8')
    expect(texto).toContain('72')
    const checks = passwordChecks('Clave1234!')
    expect(Object.values(checks).every(Boolean)).toBe(true)
    const checksMala = passwordChecks('corta')
    expect(Object.values(checksMala).some((x) => !x)).toBe(true)
  })
})

describe('CK-0446 (HAL-REG-003) · fortaleza coherente con el error', () => {
  it('el indicador nunca marca "buena" una clave inválida', async () => {
    const { passwordStrength, passwordChecks, PASSWORD_MIN_LENGTH } = await import('@/lib/validation.js')
    for (const mala of ['corta', 'sietecar', 'x'.repeat(73)]) {
      const checks = passwordChecks(mala)
      if (Object.values(checks).some((x) => !x)) {
        expect(passwordStrength(mala)).not.toBe('buena')
      }
    }
    expect(PASSWORD_MIN_LENGTH).toBe(8)
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('fuerza')
    expect(v).toContain('HAL-REG-003')
  })
})

describe('CK-0447 (HAL-REG-004) · complemento/depto en registro cliente', () => {
  it('el formulario incluye deptoOficina separado de la referencia', () => {
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('deptoOficina')
    expect(v).toContain('mensajeDeptoOficina')
  })
})

describe('CK-0454 (HAL-REG-011) · tope de 72 caracteres de GoTrue', () => {
  it('la política local rechaza 73 y traduce el error del proveedor', async () => {
    const { PASSWORD_MAX_LENGTH, passwordChecks } = await import('@/lib/validation.js')
    const { mensajePassword } = await import('@/services/registro.js')
    expect(PASSWORD_MAX_LENGTH).toBe(72)
    const larga = 'Aa1!' + 'x'.repeat(69) // 73
    expect(mensajePassword(larga)).toBeTruthy()
    expect(passwordChecks('Aa1!' + 'x'.repeat(69)).length).toBe(false) // 73 > 72
    expect(passwordChecks('Aa1!' + 'x'.repeat(68)).length).toBe(true) // 72 = tope permitido
  })
})

describe('CK-0460 (HAL-REG-017) · validación por etapa', () => {
  it('cada etapa valida sus campos antes de avanzar y al final se revisan todas', () => {
    const v = src('views/auth/RegisterView.vue')
    expect(v).toContain('validarPaso(paso.value)')
    expect(v).toContain('paso.value + 1')
    expect(v).toContain('HAL-REG-017')
    expect(v).toContain('Errores de UNA etapa')
  })
})
