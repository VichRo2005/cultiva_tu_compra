<script setup>
/**
 * CuTuCo — Catálogo público (página 5 del diseño).
 * Columna de filtros (categorías, regiones, rango de precio) y grilla de tres
 * columnas de tarjetas con carga real contra el servicio de catálogo.
 *
 * RF-022: la navegación es pública, sin sesión. RF-009: el filtro de región
 * compara la región de la dirección activa del vendedor; no existe cobertura
 * por comuna ni geolocalización.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el filtro "Solo cosecha
 * del día" (`soloCosechaDia`, query `?cosecha=1`) y el sello de cosecha del
 * mismo día salieron del ERS. `listProductos()` tampoco acepta ese parámetro.
 */
import { computed, nextTick, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import {
  construirQueryCatalogo,
  configuracionCantidadProducto,
  filtrarCategoriasVisibles,
  formatearCantidad,
  getArbolCategorias,
  leerFiltrosCatalogo,
  listProductos,
  listProductoresPorRegion,
  normalizarNombreCategoria,
} from '@/services/catalog'
import { getRegionCliente } from '@/services/geography'
import { useAuthStore } from '@/stores/auth'
import { useCartStore } from '@/stores/cart'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import { formatCLP, formatDate } from '@/lib/format'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const geo = useGeographyStore()
const cart = useCartStore()
const ui = useUiStore()

const pageSize = ref(12)
/** El rango de precio se aplica sobre el conjunto traído, para que la paginación lo respete. */
const TRAIDA_PAGE_SIZE = 200

const filtrosIniciales = leerFiltrosCatalogo(route.query)

const categorias = ref([])
const loading = ref(true)
const error = ref(null)
const todos = ref([])
const page = ref(filtrosIniciales.page)
const mostrarFiltros = ref(false)

const filters = reactive({
  texto: filtrosIniciales.texto,
  categoriaId: filtrosIniciales.categoriaId,
  subcategoriaId: filtrosIniciales.subcategoriaId,
  regionId: filtrosIniciales.regionId,
  productorId: filtrosIniciales.productorId,
  precioMin: filtrosIniciales.precioMin,
  precioMax: filtrosIniciales.precioMax,
  fechaCosecha: filtrosIniciales.fechaCosecha ?? '',
  orden: filtrosIniciales.orden,
})

/**
 * Región de entrega del cliente autenticado (RF-009) y vendedores que operan en
 * ella. `perfiles` no guarda la región: se deriva de su dirección activa
 * principal (`direcciones` -> `comunas` -> `regiones`).
 */
const regionCliente = ref(null)
const productoresRegion = ref([])
const cargandoProductores = ref(false)
const filtradoPorRegionCliente = ref(false)

const ORDENES = [
  { value: 'relevancia', label: 'Más recientes' },
  { value: 'cosecha', label: 'Fecha de cosecha (más nueva)' },
  { value: 'precio_asc', label: 'Menor precio' },
  { value: 'precio_desc', label: 'Mayor precio' },
  { value: 'stock', label: 'Mayor stock' },
]

/** Índice del árbol de categorías para resolver padre, raíz y descendientes. */
const indiceCategorias = computed(() => {
  const mapa = new Map()
  const recorrer = (nodos, padre = null, raiz = null, profundidad = 0) => {
    for (const nodo of nodos) {
      const raizActual = raiz ?? nodo
      mapa.set(String(nodo.id), { nodo, padre, raiz: raizActual, profundidad })
      recorrer(nodo.hijos ?? [], nodo, raizActual, profundidad + 1)
    }
  }
  recorrer(categorias.value)
  return mapa
})

/** Primer nivel: categorías y subcategorías nunca comparten el mismo selector. */
const opcionesCategoriaPadre = computed(() => [
  { value: '', label: 'Todas las categorías' },
  ...categorias.value.map((categoria) => ({
    value: String(categoria.id),
    label: normalizarNombreCategoria(categoria.nombre),
  })),
])

/** Segundo nivel dependiente de la categoría elegida. */
const opcionesSubcategoria = computed(() => {
  if (!filters.categoriaId) return []
  const seleccionada = indiceCategorias.value.get(String(filters.categoriaId))
  if (!seleccionada) return []
  const opciones = [{ value: '', label: 'Todas las subcategorías' }]
  const recorrer = (nodos, nivel = 1) => {
    for (const nodo of nodos) {
      opciones.push({
        value: String(nodo.id),
        label: `${'· '.repeat(nivel - 1)}${normalizarNombreCategoria(nodo.nombre)}`,
      })
      recorrer(nodo.hijos ?? [], nivel + 1)
    }
  }
  recorrer(seleccionada.nodo.hijos ?? [])
  return opciones
})

const opcionesRegion = computed(() => [
  { value: '', label: 'Todas las regiones' },
  ...geo.regionesOrdenadas.map((region) => ({ value: String(region.id), label: region.nombre })),
])

const opcionesProductor = computed(() => [
  { value: '', label: 'Todos los vendedores' },
  ...productoresRegion.value.map((p) => ({ value: p.id, label: p.nombre_comercial })),
])

const nombreProductor = computed(
  () => productoresRegion.value.find((p) => p.id === filters.productorId)?.nombre_comercial ?? null,
)

const nombreCategoria = computed(() => {
  const subcategoria = filters.subcategoriaId
    ? indiceCategorias.value.get(String(filters.subcategoriaId))
    : null
  const padre = filters.categoriaId
    ? indiceCategorias.value.get(String(filters.categoriaId))
    : null
  if (subcategoria?.nodo) {
    const nombrePadre = padre?.nodo ? normalizarNombreCategoria(padre.nodo.nombre) : null
    const nombreSub = normalizarNombreCategoria(subcategoria.nodo.nombre)
    return nombrePadre ? `${nombrePadre} · ${nombreSub}` : nombreSub
  }
  return padre?.nodo ? normalizarNombreCategoria(padre.nodo.nombre) : null
})

const nombreRegion = computed(
  () => geo.regiones.find((r) => String(r.id) === String(filters.regionId))?.nombre ?? null,
)

const nombreOrden = computed(() => ORDENES.find((o) => o.value === filters.orden)?.label ?? 'Relevancia')

/** IDs del subárbol de la categoría activa (una categoría incluye sus hijas). */
const idsCategoria = computed(() => {
  const nodo = filters.subcategoriaId
    ? indiceCategorias.value.get(String(filters.subcategoriaId))?.nodo
    : filters.categoriaId
      ? indiceCategorias.value.get(String(filters.categoriaId))?.nodo
      : null
  if (!nodo) return null
  const ids = [String(nodo.id)]
  const recorrer = (hijos = []) => {
    for (const hijo of hijos) {
      ids.push(String(hijo.id))
      recorrer(hijo.hijos ?? [])
    }
  }
  recorrer(nodo.hijos ?? [])
  return ids
})

/** Aplica el rango de precio y la fecha de cosecha sobre el conjunto ya ordenado. */
const filtrados = computed(() => {
  const min = filters.precioMin === '' ? null : Number(filters.precioMin)
  const max = filters.precioMax === '' ? null : Number(filters.precioMax)
  const fecha = filters.fechaCosecha || null
  return todos.value.filter((p) => {
    const precio = Number(p.precio)
    if (min !== null && !Number.isNaN(min) && precio < min) return false
    if (max !== null && !Number.isNaN(max) && precio > max) return false
    if (fecha && String(p.fecha_cosecha ?? '') !== fecha) return false
    return true
  })
})

const total = computed(() => filtrados.value.length)

function reglaCompra(producto) {
  const config = configuracionCantidadProducto(producto)
  if (config.agotado) return null
  return `Compra desde ${formatearCantidad(config.min, config.unidad)} hasta ${formatearCantidad(config.max, config.unidad)} ${config.unidad}; incrementos de ${formatearCantidad(config.paso, config.unidad)}.`
}

const items = computed(() => {
  const inicio = (page.value - 1) * pageSize.value
  return filtrados.value.slice(inicio, inicio + pageSize.value)
})

const totalPaginas = computed(() => Math.max(1, Math.ceil(total.value / pageSize.value)))

/** Encabezado y chips hablan del mismo filtro activo (HAL-VEN-007). */
const tituloResultados = computed(() => {
  if (nombreCategoria.value && nombreRegion.value) {
    return `${nombreCategoria.value} en ${nombreRegion.value}`
  }
  if (nombreCategoria.value) return nombreCategoria.value
  if (nombreRegion.value) return `Productos en ${nombreRegion.value}`
  return 'Todos los Productos'
})

const subtituloResultados = computed(() => {
  const productos = `${total.value} ${total.value === 1 ? 'producto' : 'productos'}`
  if (nombreRegion.value) return `${productos} en ${nombreRegion.value}`
  return `${productos} de productores verificados`
})

/** Chips de filtros activos, cada uno con su acción de quitar. */
const chipsActivos = computed(() => {
  const chips = []
  if (filters.texto) chips.push({ key: 'texto', label: `“${filters.texto}”` })
  if (filters.categoriaId) chips.push({ key: 'categoria', label: nombreCategoria.value })
  if (filters.regionId) {
    chips.push({ key: 'region', label: nombreRegion.value ?? 'Región seleccionada' })
  }
  if (filters.productorId) chips.push({ key: 'productor', label: nombreProductor.value })
  if (filters.precioMin !== '') {
    chips.push({ key: 'precioMin', label: `Desde ${formatCLP(filters.precioMin)}` })
  }
  if (filters.precioMax !== '') {
    chips.push({ key: 'precioMax', label: `Hasta ${formatCLP(filters.precioMax)}` })
  }
  if (filters.fechaCosecha) {
    chips.push({ key: 'fechaCosecha', label: `Cosecha ${formatDate(filters.fechaCosecha)}` })
  }
  return chips.filter((chip) => Boolean(chip.label))
})

function quitarChip(key) {
  if (key === 'texto') filters.texto = ''
  else if (key === 'categoria') {
    filters.categoriaId = ''
    filters.subcategoriaId = ''
  } else if (key === 'region') {
    filters.regionId = ''
    filters.productorId = ''
    geo.setRegionSeleccionada(null)
    filtradoPorRegionCliente.value = false
  } else if (key === 'productor') filters.productorId = ''
  else if (key === 'precioMin') filters.precioMin = ''
  else if (key === 'precioMax') filters.precioMax = ''
  else if (key === 'fechaCosecha') filters.fechaCosecha = ''
  page.value = 1
}

function limpiarTodo() {
  Object.assign(filters, {
    texto: '',
    categoriaId: '',
    subcategoriaId: '',
    regionId: '',
    productorId: '',
    precioMin: '',
    precioMax: '',
    fechaCosecha: '',
    orden: 'relevancia',
  })
  filtradoPorRegionCliente.value = false
  geo.setRegionSeleccionada(null)
  page.value = 1
}

/** Selección de categoría: aplica de inmediato y resetea la subcategoría. */
function elegirCategoriaPadre(categoriaId) {
  filters.categoriaId = categoriaId ? String(categoriaId) : ''
  filters.subcategoriaId = ''
  page.value = 1
}

function elegirSubcategoria(subcategoriaId) {
  filters.subcategoriaId = subcategoriaId ? String(subcategoriaId) : ''
  page.value = 1
}

/**
 * HAL-CLI-014 / HAL-VEN-007: el filtro regional se aplica en el mismo evento
 * de selección. Los `watch` recargan resultados y vendedores, y el chip de la
 * barra superior queda sincronizado con la región activa.
 */
function elegirRegion(regionId) {
  filters.regionId = regionId ? String(regionId) : ''
  // Un vendedor pertenece a una sola región: al cambiar de región se suelta.
  filters.productorId = ''
  filtradoPorRegionCliente.value = false
  geo.setRegionSeleccionada(filters.regionId || null)
  page.value = 1
}

/** Quita sólo el acotado regional, conservando búsqueda, categoría y precio. */
function verTodasLasRegiones() {
  filters.regionId = ''
  filters.productorId = ''
  filtradoPorRegionCliente.value = false
  geo.setRegionSeleccionada(null)
  page.value = 1
}

/** Vuelve al catálogo acotado a la región de entrega del cliente (RF-009). */
function verMiRegion() {
  if (!regionCliente.value?.region?.id) return
  filters.regionId = String(regionCliente.value.region.id)
  filters.productorId = ''
  filtradoPorRegionCliente.value = true
  geo.setRegionSeleccionada(filters.regionId)
  page.value = 1
}

/** Filtra el catálogo por un vendedor concreto de la región mostrada (RF-009). */
function elegirProductor(productorId) {
  filters.productorId = productorId ? String(productorId) : ''
  page.value = 1
}

let tokenProductores = 0
/** Vendedores activos de la región mostrada, para el combobox. */
async function cargarProductoresRegion() {
  const token = ++tokenProductores
  if (!filters.regionId) {
    productoresRegion.value = []
    return
  }
  cargandoProductores.value = true
  try {
    const productores = await listProductoresPorRegion(filters.regionId)
    if (token === tokenProductores) {
      productoresRegion.value = productores
      // Un vendedor pertenece a una sola región: al cambiar de región se suelta.
      if (
        filters.productorId &&
        !productores.some((productor) => String(productor.id) === String(filters.productorId))
      ) {
        filters.productorId = ''
      }
    }
  } catch {
    if (token === tokenProductores) productoresRegion.value = []
  } finally {
    if (token === tokenProductores) cargandoProductores.value = false
  }
}

/**
 * Acota el catálogo a la región de entrega del cliente autenticado (RF-009).
 * Sólo se aplica cuando el cliente todavía no eligió una región (por ejemplo al
 * llegar con `?region=` en la URL o al usar el selector).
 * @returns {Promise<boolean>} true si quedó acotado por la región del cliente.
 */
async function aplicarRegionDelCliente() {
  if (!auth.isAuthenticated || filters.regionId) return false
  try {
    regionCliente.value = await getRegionCliente(auth.perfil?.id)
  } catch {
    regionCliente.value = null
  }
  if (!regionCliente.value?.region?.id) return false
  filters.regionId = String(regionCliente.value.region.id)
  filtradoPorRegionCliente.value = true
  geo.setRegionSeleccionada(filters.regionId)
  page.value = 1
  return true
}

function aplicarPrecio() {
  page.value = 1
}

/** Compara la query real con la que se va a escribir para no navegar en vano. */
function mismaQuery(actual = {}, siguiente = {}) {
  const claves = new Set([...Object.keys(actual), ...Object.keys(siguiente)])
  for (const clave of claves) {
    const a = Array.isArray(actual[clave]) ? actual[clave].join(',') : String(actual[clave] ?? '')
    const b = Array.isArray(siguiente[clave])
      ? siguiente[clave].join(',')
      : String(siguiente[clave] ?? '')
    if (a !== b) return false
  }
  return true
}

function sincronizarUrl() {
  const query = construirQueryCatalogo(filters, page.value)
  if (mismaQuery(route.query, query)) return
  router.replace({ query }).catch(() => {})
}

/** Evita que el watch de filtros reinicie la página cuando el cambio viene de la URL. */
let aplicandoDesdeUrl = false

/** La URL es la fuente de verdad: back/forward y el buscador global la actualizan. */
function sincronizarDesdeUrl(query) {
  const siguiente = leerFiltrosCatalogo(query)
  let cambio = false
  if (siguiente.texto !== filters.texto) {
    filters.texto = siguiente.texto
    cambio = true
  }
  if (siguiente.categoriaId !== filters.categoriaId) {
    filters.categoriaId = siguiente.categoriaId
    cambio = true
  }
  if (siguiente.subcategoriaId !== filters.subcategoriaId) {
    filters.subcategoriaId = siguiente.subcategoriaId
    cambio = true
  }
  if (siguiente.regionId !== filters.regionId) {
    filters.regionId = siguiente.regionId
    filtradoPorRegionCliente.value = false
    cambio = true
  }
  if (siguiente.productorId !== filters.productorId) {
    filters.productorId = siguiente.productorId
    cambio = true
  }
  if (siguiente.precioMin !== filters.precioMin) {
    filters.precioMin = siguiente.precioMin
    cambio = true
  }
  if (siguiente.precioMax !== filters.precioMax) {
    filters.precioMax = siguiente.precioMax
    cambio = true
  }
  if ((siguiente.fechaCosecha ?? '') !== filters.fechaCosecha) {
    filters.fechaCosecha = siguiente.fechaCosecha ?? ''
    cambio = true
  }
  if (siguiente.orden !== filters.orden) {
    filters.orden = siguiente.orden
    cambio = true
  }
  if (siguiente.page !== page.value) {
    page.value = siguiente.page
  }
  if (cambio && filters.regionId) geo.setRegionSeleccionada(filters.regionId)
  if (cambio) {
    aplicandoDesdeUrl = true
    nextTick(() => {
      aplicandoDesdeUrl = false
    })
  }
}

let tokenCarga = 0
async function cargar() {
  const token = ++tokenCarga
  loading.value = true
  error.value = null
  try {
    const resultado = await listProductos({
      texto: filters.texto,
      categoriaIds: idsCategoria.value,
      categoriaId: filters.categoriaId || null,
      regionId: filters.regionId || null,
      productorId: filters.productorId || null,
      soloStock: false,
      orden: filters.orden,
      page: 1,
      pageSize: TRAIDA_PAGE_SIZE,
    })
    if (token !== tokenCarga) return
    todos.value = resultado.items
  } catch (e) {
    if (token !== tokenCarga) return
    error.value = e.message
    todos.value = []
  } finally {
    if (token === tokenCarga) loading.value = false
  }
}

async function recargar() {
  await cargar()
  sincronizarUrl()
}

/**
 * Resuelve una URL antigua que apuntaba directamente a una subcategoría:
 * el primer selector queda en la raíz y el segundo en la subcategoría.
 */
function resolverSeleccionCategoria() {
  if (filters.subcategoriaId) {
    const info = indiceCategorias.value.get(String(filters.subcategoriaId))
    if (info) filters.categoriaId = String(info.raiz.id)
    else filters.subcategoriaId = ''
  }
  if (!filters.categoriaId) return
  const info = indiceCategorias.value.get(String(filters.categoriaId))
  if (!info) {
    // La URL puede apuntar a una categoría retirada (por ejemplo mascotas).
    if (categorias.value.length) filters.categoriaId = ''
    return
  }
  if (info.padre) {
    filters.categoriaId = String(info.raiz.id)
    if (!filters.subcategoriaId) filters.subcategoriaId = String(info.nodo.id)
  }
}

onMounted(async () => {
  // No bloquees la primera consulta del catálogo por datos auxiliares de
  // geografía; el store actualiza los filtros de forma reactiva al terminar.
  void geo.load()
  try {
    categorias.value = filtrarCategoriasVisibles(await getArbolCategorias())
  } catch {
    categorias.value = []
  }
  // El chip superior y el catálogo comparten la misma región activa.
  if (!filters.regionId && geo.regionSeleccionadaId) {
    filters.regionId = String(geo.regionSeleccionadaId)
  }
  resolverSeleccionCategoria()
  if (filters.regionId) geo.setRegionSeleccionada(filters.regionId)
  /*
   * Si el cliente entra sin filtro de región, el catálogo se acota a su región
   * de entrega. En ese caso son los `watch` de `filters.regionId` los que
   * recargan productos y vendedores, así que aquí no se repite la carga.
   */
  const acotado = await aplicarRegionDelCliente()
  if (!acotado) await Promise.all([cargarProductoresRegion(), cargar()])
})

watch(
  [() => ({ ...filters }), page],
  () => {
    sincronizarUrl()
  },
  { deep: true },
)

watch(
  () => route.query,
  (query) => {
    sincronizarDesdeUrl(query)
  },
  { deep: true },
)

watch(
  () => filters.texto,
  () => {
    if (!aplicandoDesdeUrl) page.value = 1
    cargar()
  },
)

watch(
  () => [filters.categoriaId, filters.subcategoriaId, filters.regionId, filters.productorId, filters.orden],
  () => {
    if (!aplicandoDesdeUrl) page.value = 1
    cargar()
  },
)

/** La lista de vendedores depende de la región mostrada (RF-009). */
watch(
  () => filters.regionId,
  (regionId) => {
    // El chip superior nunca debe decir "Todo Chile" con una región filtrada.
    geo.setRegionSeleccionada(regionId || null)
    cargarProductoresRegion()
  },
)

watch(total, (value) => {
  if (page.value > Math.ceil(value / pageSize.value)) page.value = Math.max(1, Math.ceil(value / pageSize.value))
})

function agregar(producto) {
  if (Number(producto.stock) <= 0) {
    ui.warning('Producto agotado', `${producto.nombre} no tiene stock disponible`)
    return
  }
  try {
    cart.agregar(producto)
    const unidad = producto.unidad_medida ?? 'unidad'
    ui.success(
      'Añadido al carrito',
      `${producto.nombre} (${formatearCantidad(1, unidad)} ${unidad})`,
    )
  } catch (e) {
    ui.error('No se pudo añadir al carrito', e.message)
  }
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Catálogo de Productos</h1>
        <p class="page-head__subtitle">{{ subtituloResultados }}</p>
      </div>
      <div class="page-head__actions">
        <CtSelect
          v-model="filters.orden"
          class="catalogo__orden"
          label="Ordenar por"
          :options="ORDENES"
          searchable
        />
        <CtButton
          variant="secondary"
          class="catalogo__toggle"
          type="button"
          @click="mostrarFiltros = !mostrarFiltros"
        >
          <template #icon><CtIcon name="filter" :size="16" /></template>
          Filtros
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el catálogo">
      {{ error }}
      <CtButton variant="secondary" size="sm" type="button" @click="recargar">
        Reintentar
      </CtButton>
    </CtAlert>

    <!-- Acotado a la región de entrega del cliente. -->
    <CtAlert
      v-if="filtradoPorRegionCliente && regionCliente"
      tone="info"
      compact
      title="Mostrando sólo tu región de entrega"
      dismissible
      @dismiss="filtradoPorRegionCliente = false"
    >
      <p class="linea">
        <CtIcon name="pin" :size="15" />
        <span>
          Estás viendo los productos y vendedores de
          <strong>{{ regionCliente.region.nombre }}</strong>, la región de tu dirección
          {{ regionCliente.comuna?.nombre ? `en ${regionCliente.comuna.nombre}` : '' }}. Los
          vendedores de CuTuCo entregan sólo dentro de su propia región.
        </span>
      </p>
      <CtButton size="sm" variant="ghost" type="button" @click="verTodasLasRegiones">
        Ver todas las regiones
      </CtButton>
    </CtAlert>

    <!-- El cliente tiene región de entrega pero está mirando otra región. -->
    <CtAlert
      v-else-if="regionCliente && String(filters.regionId) !== String(regionCliente.region.id)"
      tone="neutral"
      compact
      title="Tu región de entrega"
      dismissible
    >
      <p class="linea">
        <CtIcon name="pin" :size="15" />
        <span>
          Tus entregas van a <strong>{{ regionCliente.region.nombre }}</strong>. Los vendedores de
          CuTuCo despachan sólo dentro de su propia región.
        </span>
      </p>
      <CtButton size="sm" variant="secondary" type="button" @click="verMiRegion">
        Ver mi región
      </CtButton>
    </CtAlert>

    <div class="catalogo">
      <!-- ==================== FILTROS ==================== -->
      <aside class="filtros" :class="{ 'is-open': mostrarFiltros }">
        <CtCard padding="sm" class="filtros__card">
          <section class="filtros__grupo">
            <CtSelect
              label="Categoría"
              :model-value="filters.categoriaId"
              :options="opcionesCategoriaPadre"
              searchable
              @update:model-value="elegirCategoriaPadre"
            />
            <CtSelect
              v-if="filters.categoriaId && opcionesSubcategoria.length > 1"
              label="Subcategoría"
              :model-value="filters.subcategoriaId"
              :options="opcionesSubcategoria"
              searchable
              @update:model-value="elegirSubcategoria"
            />
          </section>

          <hr class="divider" />

          <section class="filtros__grupo">
            <CtSelect
              label="Región"
              :model-value="filters.regionId"
              :options="opcionesRegion"
              searchable
              @update:model-value="elegirRegion"
            />
          </section>

          <!--
            Vendedores que operan en la región mostrada. Se resuelven con
            `productores.region_id`, la columna derivada que mantiene el trigger
            `trg_sincronizar_region_productor`; `direcciones` no es pública.
          -->
          <template v-if="filters.regionId">
            <hr class="divider" />

            <section class="filtros__grupo">
              <CtSelect
                label="Vendedor"
                :model-value="filters.productorId"
                :options="opcionesProductor"
                :disabled="cargandoProductores"
                searchable
                :hint="
                  !cargandoProductores && !productoresRegion.length
                    ? 'No hay vendedores activos en esta región.'
                    : null
                "
                @update:model-value="elegirProductor"
              />
              <p v-if="cargandoProductores" class="text-xs text-muted">Cargando vendedores…</p>
            </section>
          </template>

          <hr class="divider" />

          <section class="filtros__grupo">
            <h2 class="eyebrow">Rango de precio</h2>
            <div class="filtros__precios">
              <CtInput
                v-model="filters.precioMin"
                type="number"
                min="0"
                placeholder="Mín."
                suffix="$"
                aria-label="Precio mínimo en pesos"
                @update:model-value="aplicarPrecio"
              />
              <CtInput
                v-model="filters.precioMax"
                type="number"
                min="0"
                placeholder="Máx."
                suffix="$"
                aria-label="Precio máximo en pesos"
                @update:model-value="aplicarPrecio"
              />
            </div>
          </section>

          <hr class="divider" />

          <section class="filtros__grupo">
            <CtInput
              v-model="filters.fechaCosecha"
              type="date"
              label="Fecha de cosecha"
              aria-label="Filtrar por fecha de cosecha"
            />
          </section>

          <template #footer>
            <CtButton variant="ghost" block type="button" @click="limpiarTodo">
              Limpiar todo
            </CtButton>
          </template>
        </CtCard>
      </aside>

      <!-- ==================== RESULTADOS ==================== -->
      <section class="resultados">
        <div class="resultados__barra">
          <h2 class="resultados__titulo">
            {{ tituloResultados }}
            <span class="resultados__conteo">({{ total }} resultados)</span>
          </h2>
          <p class="resultados__orden">Ordenar por: {{ nombreOrden }}</p>
        </div>

        <div v-if="chipsActivos.length" class="chips">
          <span v-for="chip in chipsActivos" :key="chip.key" class="chip chip--active">
            {{ chip.label }}
            <button
              type="button"
              class="chips__quitar"
              :aria-label="`Quitar filtro ${chip.label}`"
              @click="quitarChip(chip.key)"
            >
              <CtIcon name="close" :size="12" />
            </button>
          </span>
          <button type="button" class="chips__limpiar" @click="limpiarTodo">
            Limpiar todo
          </button>
        </div>

        <CtSpinner v-if="loading" label="Buscando productos…" />

        <CtEmptyState
          v-else-if="!items.length && !error"
          title="Sin coincidencias"
          message="No encontramos productos con esos filtros. Prueba quitando alguno o revisa el rango de precio."
        >
          <CtButton variant="secondary" type="button" @click="limpiarTodo">Limpiar todo</CtButton>
        </CtEmptyState>

        <template v-else>
          <ul class="grilla">
            <li v-for="producto in items" :key="producto.id">
              <article class="tarjeta">
                <router-link :to="`/producto/${producto.id}`" class="tarjeta__media">
                  <img
                    v-if="producto.imagenPrincipal"
                    :src="producto.imagenPrincipal.url"
                    :alt="producto.nombre"
                    loading="lazy"
                  />
                  <span v-else class="tarjeta__placeholder" aria-hidden="true">
                    <CtIcon name="leaf" :size="28" />
                  </span>
                </router-link>

                <div class="tarjeta__body">
                  <p class="tarjeta__categoria">
                    {{ producto.categoria?.nombre ?? 'Sin categoría' }}
                  </p>

                  <CtRatingStars
                    v-if="Number(producto.productor?.cantidad_evaluaciones ?? 0) > 0"
                    class="tarjeta__estrellas"
                    :model-value="Number(producto.productor.puntaje_reputacion)"
                    :size="13"
                  />

                  <h3 class="tarjeta__nombre">
                    <router-link :to="`/producto/${producto.id}`">{{ producto.nombre }}</router-link>
                  </h3>

                  <p class="tarjeta__productor">
                    {{ producto.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
                    <span v-if="producto.regionProductor" class="tarjeta__comuna">
                      · {{ producto.regionProductor.nombre }}
                    </span>
                  </p>

                  <p class="tarjeta__precio">
                    <strong>{{ formatCLP(producto.precio) }}</strong>
                    <span>/ {{ producto.unidad_medida ?? 'unidad' }}</span>
                  </p>

                  <p
                    class="tarjeta__stock"
                    :class="{ 'is-agotado': Number(producto.stock) <= 0 }"
                  >
                    {{ Number(producto.stock) > 0
                      ? `Disponible: ${formatearCantidad(producto.stock, producto.unidad_medida)} ${producto.unidad_medida ?? 'unidad'}`
                      : 'Sin stock disponible' }}
                  </p>

                  <p v-if="reglaCompra(producto)" class="tarjeta__regla-compra">
                    {{ reglaCompra(producto) }}
                  </p>

                  <CtButton
                    block
                    type="button"
                    :disabled="Number(producto.stock) <= 0"
                    @click="agregar(producto)"
                  >
                    <template #icon><CtIcon name="cart" :size="16" /></template>
                    Añadir al Carro
                  </CtButton>
                </div>
              </article>
            </li>
          </ul>

          <CtPagination
            :page="page"
            :total="total"
            :page-size="pageSize"
            label="productos"
            @update:page="page = $event"
            @update:page-size="pageSize = $event; page = 1"
          />
          <p v-if="totalPaginas > 1" class="resultados__pie">
            Página {{ page }} de {{ totalPaginas }}
          </p>
        </template>
      </section>
    </div>
  </div>
</template>

<style scoped>
.catalogo {
  display: grid;
  grid-template-columns: 260px minmax(0, 1fr);
  gap: var(--ct-space-8);
  align-items: start;
}

.catalogo__buscador {
  min-width: 260px;
}

.catalogo__orden {
  min-width: 170px;
}

.catalogo__categoria {
  min-width: 190px;
}

.catalogo__vendedor {
  min-width: 200px;
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.catalogo__toggle {
  display: none;
}

/* -------------------- Filtros -------------------- */

.filtros {
  position: sticky;
  top: calc(var(--ct-header-height) + var(--ct-space-4));
}

.filtros__card {
  gap: var(--ct-space-4);
}

.filtros__grupo {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.filtros__lista {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 260px;
  overflow-y: auto;
}

.filtros__opcion {
  width: 100%;
  text-align: left;
  padding: 0.45rem var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  transition:
    background-color var(--ct-transition),
    color var(--ct-transition);
}

.filtros__opcion:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.filtros__opcion.is-active {
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

.filtros__opcion.is-active:hover {
  background: var(--ct-accent-tint-50);
  color: var(--ct-accent-ink);
}

.filtros__precios {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-2);
}

/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 * `.filtros__check` estilaba el check "Solo cosecha del día", filtro que salió
 * del ERS junto con el sello de cosecha del mismo día (`.tarjeta__flag`). Se
 * conservan las reglas para no alterar el diseño existente.
 */
.filtros__check {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  cursor: pointer;
}

.filtros__check input {
  width: 16px;
  height: 16px;
  accent-color: var(--ct-primary-strong);
}

/* -------------------- Resultados -------------------- */

.resultados {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
  min-width: 0;
}

.resultados__barra {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.resultados__titulo {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.resultados__conteo {
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-medium);
}

.resultados__orden {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.resultados__pie {
  text-align: center;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.chips {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ct-space-2);
}

.chips__quitar {
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  color: var(--ct-primary-ink);
  transition: background-color var(--ct-transition);
}

.chips__quitar:hover {
  background: var(--ct-primary-softer);
}

.chips__limpiar {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-soft);
  text-decoration: underline;
}

.chips__limpiar:hover {
  color: var(--ct-primary-strong);
}

/* -------------------- Grilla de tarjetas -------------------- */

.grilla {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--ct-space-5);
}

.tarjeta {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  overflow: hidden;
  box-shadow: var(--ct-shadow-xs);
  transition:
    box-shadow var(--ct-transition),
    transform var(--ct-transition),
    border-color var(--ct-transition);
}

.tarjeta:hover {
  box-shadow: var(--ct-shadow-md);
  transform: translateY(-3px);
  border-color: var(--ct-border-strong);
}

.tarjeta__media {
  position: relative;
  display: block;
  aspect-ratio: var(--ct-product-image-ratio);
  background: var(--ct-surface-alt);
  overflow: hidden;
}

.tarjeta__media img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.tarjeta__placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  color: var(--ct-primary);
}

.tarjeta__flag {
  position: absolute;
  top: var(--ct-space-3);
  left: var(--ct-space-3);
}

.tarjeta__body {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-4);
  flex: 1;
}

.tarjeta__categoria {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-muted);
}

.tarjeta__estrellas {
  margin-top: -2px;
}

.tarjeta__nombre {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  line-height: 1.35;
}

.tarjeta__nombre a {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
  color: var(--ct-text);
}

.tarjeta__nombre a:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.tarjeta__productor {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.tarjeta__comuna {
  color: var(--ct-text-muted);
}

.tarjeta__precio {
  display: flex;
  align-items: baseline;
  gap: 3px;
  margin-top: auto;
  padding-top: var(--ct-space-2);
}

.tarjeta__precio strong {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

.tarjeta__precio span {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.tarjeta__stock {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.tarjeta__regla-compra {
  padding: var(--ct-space-2) var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  font-size: var(--ct-fs-2xs);
  line-height: 1.4;
}

/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): `.is-bajo` pintaba el aviso
 * de stock bajo (, fuera del ERS) y `.tarjeta__flag` posicionaba el sello
 * de cosecha del día. El catálogo vigente sólo informa disponibilidad.
 */
.tarjeta__stock.is-bajo {
  color: var(--ct-warning-ink);
  font-weight: var(--ct-fw-semibold);
}

.tarjeta__stock.is-agotado {
  color: var(--ct-danger);
  font-weight: var(--ct-fw-semibold);
}

@media (max-width: 1280px) {
  .grilla {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1024px) {
  .catalogo {
    grid-template-columns: minmax(0, 1fr);
  }

  .filtros {
    display: none;
    position: static;
  }

  .filtros.is-open {
    display: block;
  }

  .catalogo__toggle {
    display: inline-flex;
  }
}

@media (max-width: 720px) {
  .grilla {
    grid-template-columns: minmax(0, 1fr);
  }

  .catalogo__buscador {
    min-width: 100%;
  }
}
</style>
