/** CuTuCo — Store de interfaz: notificaciones, toasts y estado global de la app */

import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { tryGetClient } from '@/lib/supabase'
import { mensajeSeguro } from '@/services/errores'
import { obtenerPreferenciasNotificacion } from '@/services/notificationPreferences'
import { currentUserId } from '@/services/session'

let toastSeq = 0

export const useUiStore = defineStore('ui', () => {
  /* ------------------------------ toasts ------------------------------ */
  const toasts = ref([])

  function pushToast({ title, message = '', tone = 'info', timeout = 4500, action = null }) {
    toastSeq += 1
    const id = toastSeq
    toasts.value = [...toasts.value, { id, title, message, tone, action }]
    if (timeout > 0) {
      setTimeout(() => dismissToast(id), timeout)
    }
    return id
  }

  const success = (title, message) => pushToast({ title, message, tone: 'success' })
  const error = (title, message) =>
    pushToast({
      title,
      message: message ? mensajeSeguro(message) : 'Inténtalo nuevamente en unos minutos.',
      tone: 'danger',
      timeout: 6000,
    })
  const info = (title, message) => pushToast({ title, message, tone: 'info' })
  const warning = (title, message) => pushToast({ title, message, tone: 'warning' })

  function dismissToast(id) {
    toasts.value = toasts.value.filter((t) => t.id !== id)
  }

  /* -------------------------- notificaciones -------------------------- */
  const notifications = ref([])
  let versionNotificaciones = 0
  const panelAbierto = ref(false)

  const noLeidas = computed(() => notifications.value.filter((n) => !n.leida).length)

  function addNotification(notification) {
    notifications.value = [
      { id: `${Date.now()}-${Math.random()}`, leida: false, creada_en: new Date().toISOString(), ...notification },
      ...notifications.value,
    ]
  }

  function marcarLeida(id) {
    const item = notifications.value.find((n) => n.id === id)
    if (item) item.leida = true
  }

  function marcarTodasLeidas() {
    notifications.value = notifications.value.map((n) => ({ ...n, leida: true }))
  }

  function limpiarNotificaciones() {
    versionNotificaciones += 1
    notifications.value = []
  }

  function togglePanel() {
    panelAbierto.value = !panelAbierto.value
  }

  /**
   * Deriva las notificaciones de cada rol a partir de los datos del dominio.
   * Cubre sólo los pendientes del alcance vigente: pedidos por confirmar,
   * entregas por despachar y las aprobaciones del administrador (RF-011).
   *
   * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): las alertas de
   * "Cosecha del día" (RF-008/RF-010), el stock bajo, los reclamos abiertos y
   * la pausa automática por reputación salieron del ERS.
   */
  async function syncNotifications({ rol }) {
    const version = versionNotificaciones
    const client = tryGetClient()
    const userId = await currentUserId()
    if (version !== versionNotificaciones) return
    if (!client || !userId) {
      notifications.value = []
      return
    }
    // La entrega dentro de CuTuCo se consulta antes de recorrer pedidos o
    // reclamos. Si no existe aún una fila, el servicio conserva el valor
    // predeterminado activo para las cuentas creadas antes de esta mejora.
    try {
      const preferencias = await obtenerPreferenciasNotificacion({ perfilId: userId })
      if (version !== versionNotificaciones) return
      if (!preferencias.inApp) {
        notifications.value = []
        return
      }
    } catch {
      // Una preferencia que no pueda leerse nunca debe ocultar alertas
      // operativas; se conserva el comportamiento seguro por defecto.
    }
    const items = []

    if (rol === 'cliente') {
      const { data: pedidos } = await client
        .from('pedidos')
        .select('*')
        .eq('cliente_id', userId)
        .in('estado', ['pagado', 'en_preparacion', 'completado', 'cancelado'])
        .order('creado_en', { ascending: false })
        .limit(10)

      for (const pedido of pedidos ?? []) {
        if (pedido.estado === 'completado' && !pedido.confirmado_cliente_en) {
          items.push({
            id: `pedido-${pedido.id}`,
            tipo: 'pedido',
            tone: 'success',
            titulo: 'Tu pedido fue entregado',
            mensaje: `Confirma la recepción de ${pedido.codigo_pedido} y califica al vendedor.`,
            enlace: `/cliente/pedidos/${pedido.id}`,
          })
        }
        if (pedido.estado === 'en_preparacion') {
          items.push({
            id: `preparacion-${pedido.id}`,
            tipo: 'pedido',
            tone: 'info',
            titulo: 'Pedido en preparación',
            mensaje: `${pedido.codigo_pedido} está siendo preparado por el vendedor.`,
            enlace: `/cliente/pedidos/${pedido.id}`,
          })
        }
        if (pedido.estado === 'cancelado') {
          const motivo = String(pedido.motivo_cancelacion ?? '').trim()
          items.push({
            id: `cancelado-${pedido.id}`,
            tipo: 'pedido',
            tone: 'danger',
            titulo: 'Pedido cancelado',
            mensaje: motivo
              ? `${pedido.codigo_pedido} fue cancelado. Motivo: ${motivo}`
              : `${pedido.codigo_pedido} fue cancelado por el vendedor.`,
            enlace: `/cliente/pedidos/${pedido.id}`,
          })
        }
      }

      // Reclamos activos del cliente (INT-NOT-002): una sola alerta por reclamo.
      const { data: reclamos } = await client
        .from('reclamos')
        .select('id, estado, motivo')
        .eq('cliente_id', userId)
        .in('estado', ['abierto', 'en_revision'])
      for (const reclamo of reclamos ?? []) {
        items.push({
          id: `reclamo-${reclamo.id}`,
          tipo: 'reclamo',
          tone: 'warning',
          titulo: 'Reclamo en revisión',
          mensaje: `Tu reclamo por "${reclamo.motivo}" sigue abierto.`,
          enlace: `/cliente/reclamos/${reclamo.id}`,
        })
      }
    }

    if (rol === 'vendedor') {
      const { data: productor } = await client
        .from('productores')
        .select('*')
        .eq('perfil_id', userId)
        .maybeSingle()
      if (productor) {
        const { data: pedidos } = await client
          .from('pedidos')
          .select('*')
          .eq('productor_id', productor.id)
          .in('estado', ['pagado', 'en_preparacion'])
          .order('creado_en', { ascending: false })
        for (const pedido of pedidos ?? []) {
          items.push({
            id: `pedido-${pedido.id}`,
            tipo: 'pedido',
            tone: 'warning',
            titulo: 'Pedido por despachar',
            mensaje: `${pedido.codigo_pedido} espera el cambio de estado del delivery.`,
            enlace: `/vendedor/pedidos`,
          })
        }

        if (!productor.activo) {
          items.push({
            id: 'tienda-suspendida',
            tipo: 'tienda',
            tone: 'danger',
            titulo: 'Cuenta suspendida',
            mensaje: 'Tu cuenta está suspendida o con ban permanente. Revisa las sanciones en tu perfil.',
            enlace: '/vendedor/sanciones',
          })
        }

        // Reclamos abiertos de los pedidos del vendedor: una alerta por reclamo.
        // La RLS `reclamos_select_participantes` limita las filas a los pedidos
        // del vendedor autenticado, así que no se filtra por productor aquí.
        const { data: reclamos } = await client
          .from('reclamos')
          .select('id, estado, motivo')
          .in('estado', ['abierto', 'en_revision'])
        for (const reclamo of reclamos ?? []) {
          items.push({
            id: `reclamo-${reclamo.id}`,
            tipo: 'reclamo',
            tone: 'warning',
            titulo: 'Reclamo por responder',
            mensaje: `Un cliente abrió un reclamo por "${reclamo.motivo}".`,
            enlace: '/vendedor/reclamos',
          })
        }
      }

      const { data: postulacion } = await client
        .from('postulaciones_vendedores')
        .select('*')
        .eq('perfil_id', userId)
        .order('creado_en', { ascending: false })
        .limit(1)
        .maybeSingle()
      if (postulacion && postulacion.estado !== 'aprobada') {
        items.push({
          id: `postulacion-${postulacion.id}`,
          tipo: 'validacion',
          tone: postulacion.estado === 'rechazada' ? 'danger' : 'warning',
          titulo: 'Solicitud de vendedor',
          mensaje:
            postulacion.estado === 'rechazada'
              ? 'Tu solicitud fue rechazada. Revisa las observaciones del administrador.'
              : 'Tu solicitud está pendiente de aprobación del administrador.',
          enlace: '/mi-postulacion',
        })
      }
    }

    if (rol === 'admin') {
      const { data: postulaciones } = await client
        .from('postulaciones_vendedores')
        .select('*')
        .eq('estado', 'en_revision')
      for (const p of postulaciones ?? []) {
        items.push({
          id: `postulacion-${p.id}`,
          tipo: 'moderacion',
          tone: 'warning',
          titulo: 'Vendedor por aprobar',
          mensaje: `${p.nombre_comercial_solicitado} espera la revisión de antecedentes.`,
          enlace: '/admin/moderacion',
        })
      }

      const { data: sanciones } = await client
        .from('sanciones')
        .select('*')
        .in('estado', ['activa', 'apelada'])
      if ((sanciones ?? []).length) {
        items.push({
          id: 'sanciones-activas',
          tipo: 'sancion',
          tone: 'warning',
          titulo: 'Sanciones vigentes',
          mensaje: `${sanciones.length} vendedor(es) con sanción activa o apelada.`,
          enlace: '/admin/sanciones',
        })
      }

      const { data: reclamos } = await client
        .from('reclamos')
        .select('id')
        .in('estado', ['abierto', 'en_revision'])
      if ((reclamos ?? []).length) {
        items.push({
          id: 'reclamos-pendientes',
          tipo: 'reclamo',
          tone: 'warning',
          titulo: 'Reclamos por revisar',
          mensaje: `${reclamos.length} reclamo(s) esperan resolución.`,
          enlace: '/admin/reclamos',
        })
      }
    }

    if (version !== versionNotificaciones) return
    notifications.value = items.map((n) => {
      const existente = notifications.value.find((e) => e.id === n.id)
      return { ...n, leida: existente?.leida ?? false }
    })
  }

  /* ------------------------------ global ------------------------------ */
  const sidebarAbierto = ref(false)
  const modoDesarrollo = ref(true)

  function toggleSidebar() {
    sidebarAbierto.value = !sidebarAbierto.value
  }

  return {
    toasts,
    notifications,
    panelAbierto,
    noLeidas,
    sidebarAbierto,
    modoDesarrollo,
    pushToast,
    success,
    error,
    info,
    warning,
    dismissToast,
    addNotification,
    marcarLeida,
    marcarTodasLeidas,
    limpiarNotificaciones,
    togglePanel,
    syncNotifications,
    toggleSidebar,
  }
})
