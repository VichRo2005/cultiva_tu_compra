/**
 * CuTuCo — Store de autenticación (RF-001, RF-021, RF-023 y RF-024).
 *
 * El login, el refresh de sesión y el cambio/recuperación de contraseña los
 * resuelve Supabase Auth (GoTrue). La protección contra fuerza bruta es el
 * límite nativo de GoTrue (HTTP 429), que se traduce a un mensaje claro en
 * `normalizarErrorAuth`; no hay bloqueo de cuenta propio.
 */

import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { getClient, MODO_DEMO, MISSING_ENV, tryGetClient } from '@/lib/supabase'
import { mensajeSeguro } from '@/services/errores'
import { ESTADO_POSTULACION, ROL_USUARIO } from '@/lib/constants'
import {
  currentAuth,
  estadoEfectivoCuenta,
  motivoBloqueoVendedor,
  sancionVigente,
} from '@/services/session'
import {
  emailPolicyMessage,
  isEmail,
  isNombrePropio,
  isPhone,
  LIMITES,
  normalizarEmail,
  normalizarTelefonoChileno,
  passwordPolicyMessage,
  required,
} from '@/lib/validation'

const AUTH_TIMEOUT_MS = 20_000

function conTimeout(promesa, ms = AUTH_TIMEOUT_MS) {
  let timer
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const error = new Error(
        'La conexión tardó demasiado. Revisa tu red e inténtalo de nuevo.',
      )
      error.code = 'timeout'
      reject(error)
    }, ms)
  })
  return Promise.race([promesa, timeout]).finally(() => clearTimeout(timer))
}

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const perfil = ref(null)
  const productor = ref(null)
  const postulacion = ref(null)
  const sanciones = ref([])
  const loading = ref(false)
  const initializing = ref(true)
  const error = ref(null)
  /**
   * Falta configuración de Supabase y tampoco hay modo demostración disponible:
   * sólo entonces la aplicación no puede operar con datos.
   */
  const configuracionFaltante = computed(() => MISSING_ENV && !MODO_DEMO.value)
  /**
   * La SPA llegó desde el enlace de recuperación de GoTrue (RF-023): hay una
   * sesión de recuperación activa y todavía falta definir la contraseña nueva.
   * Se marca desde la URL (`?recuperacion=1`) y desde el evento
   * `PASSWORD_RECOVERY` de Supabase Auth.
   */
  const recuperacionPendiente = ref(false)

  /**
   * RF-026: sanciones vigentes (`activa` o `apelada`, sin superar `fin_en`).
   * Se cargan en `refresh()` al iniciar sesión y alimentan el aviso del shell.
   */
  const sancionesVigentes = computed(() => sanciones.value.filter((s) => sancionVigente(s)))

  /** Suscripción a los cambios de sesión de Supabase Auth. */
  let _suscripcion = null
  let versionSesion = 0
  let refrescoProgramado = null

  function limpiarSesion() {
    versionSesion += 1
    clearTimeout(refrescoProgramado)
    user.value = null
    perfil.value = null
    productor.value = null
    postulacion.value = null
    sanciones.value = []
    recuperacionPendiente.value = false
  }

  const isAuthenticated = computed(() => Boolean(user.value))
  const rol = computed(() => perfil.value?.rol ?? null)
  const isCliente = computed(() => rol.value === ROL_USUARIO.CLIENTE)
  const isVendedor = computed(() => rol.value === ROL_USUARIO.VENDEDOR)
  const isAdmin = computed(() => rol.value === ROL_USUARIO.ADMIN && perfil.value?.activo === true)

  const email = computed(() => user.value?.email ?? '')
  const nombreCompleto = computed(() => {
    if (!perfil.value) return ''
    return [perfil.value.nombre, perfil.value.apellido].filter(Boolean).join(' ')
  })
  const iniciales = computed(() =>
    [perfil.value?.nombre, perfil.value?.apellido]
      .filter(Boolean)
      .map((w) => w[0]?.toUpperCase())
      .slice(0, 2)
      .join(''),
  )
  const tieneTienda = computed(() => Boolean(productor.value))
  /** Borrador (le faltan los documentos) o ya enviada a revisión: ambas bloquean re-postular. */
  const postulacionPendiente = computed(() =>
    [ESTADO_POSTULACION.BORRADOR, ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(
      postulacion.value?.estado,
    ),
  )
  const postulacionRechazada = computed(
    () => postulacion.value?.estado === ESTADO_POSTULACION.RECHAZADA,
  )

  const bloqueoVendedor = computed(() =>
    isVendedor.value || postulacion.value
      ? motivoBloqueoVendedor({
          perfil: perfil.value,
          productor: productor.value,
          postulacion: postulacion.value,
          sanciones: sanciones.value,
        })
      : null,
  )

  /** Estado efectivo de la cuenta (incluye sanciones vencidas y ban). */
  const estadoCuenta = computed(() =>
    estadoEfectivoCuenta({
      perfil: perfil.value,
      productor: productor.value,
      postulacion: postulacion.value,
      sanciones: sanciones.value,
    }),
  )
  const estaSuspendido = computed(() => estadoCuenta.value === 'suspendido')
  const estaBaneado = computed(() => estadoCuenta.value === 'baneado')
  const enPostulacion = computed(() => estadoCuenta.value === 'postulacion')

  /** ¿Puede operar la tienda y publicar productos? (RF-003 y RF-021) */
  const puedeOperarTienda = computed(() => estadoCuenta.value === 'activo')

  async function refresh() {
    const version = versionSesion
    const ctx = await currentAuth()
    if (version !== versionSesion) return { user: null, perfil: null }
    user.value = ctx.user
    perfil.value = ctx.perfil
    productor.value = ctx.productor
    postulacion.value = ctx.postulacion

    // Una sesión persistida tampoco puede recuperar una cuenta eliminada.
    if (ctx.perfil?.eliminado_en) {
      await signOut()
      return ctx
    }

    if (ctx.productor?.id) {
      const client = tryGetClient()
      const { data, error: sancionesError } = await client
        .from('sanciones')
        .select('*')
        .eq('productor_id', ctx.productor.id)
        .order('inicio_en', { ascending: false })
      if (version !== versionSesion) return { user: null, perfil: null }
      if (sancionesError) {
        limpiarSesion()
        throw new Error('No pudimos verificar las restricciones de tu cuenta. Inténtalo de nuevo.')
      }
      if (version === versionSesion) sanciones.value = data ?? []
    } else {
      sanciones.value = []
    }
    return ctx
  }

  async function init() {
    if (configuracionFaltante.value) {
      initializing.value = false
      return null
    }
    loading.value = true
    try {
      const client = getClient()
      await client.auth.getSession()
      const { data } = client.auth.onAuthStateChange((event) => {
        if (event === 'PASSWORD_RECOVERY') {
          // GoTrue procesó el enlace del correo de recuperación (RF-023).
          recuperacionPendiente.value = true
          return
        }
        if (event === 'SIGNED_OUT') {
          limpiarSesion()
        }
        if (event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
          // Salir del callback evita bloquear el mutex del SDK de Supabase.
          clearTimeout(refrescoProgramado)
          const version = versionSesion
          refrescoProgramado = setTimeout(async () => {
            if (version !== versionSesion) return
            try {
              await refresh()
            } catch {
              if (version !== versionSesion) return
              limpiarSesion()
              error.value = 'No se pudo verificar tu sesión. Vuelve a iniciar sesión.'
            }
          }, 0)
        }
      })
      _suscripcion = data?.subscription ?? null
      await refresh()
      return true
    } catch (e) {
      // Un fallo de red/perfil al arrancar no deja una sesión parcial
      // utilizable: se limpia y el guard envía al login con el error visible.
      error.value = e?.message ?? 'No se pudo verificar la sesión.'
      try {
        await signOut()
      } catch {
        user.value = null
        perfil.value = null
        productor.value = null
        postulacion.value = null
        sanciones.value = []
      }
      return null
    } finally {
      loading.value = false
      initializing.value = false
    }
  }

  function detenerEscucha() {
    clearTimeout(refrescoProgramado)
    _suscripcion?.unsubscribe?.()
    _suscripcion = null
  }

  /**
   * Inicia sesión y aplica las reglas de negocio de la cuenta:
   *  - Credenciales inválidas/no confirmadas: mensaje genérico en español.
   *  - Perfil/rol inaccesible: no concede acceso, elimina la sesión parcial.
   *  - Cuenta eliminada, desactivada o con ban permanente: cierra sesión.
   *  - Suspensión temporal vigente: permite entrar sólo a amonestaciones.
   *  - Postulación activa: el router la lleva a /mi-postulacion.
   */
  async function signIn({ email: correo, password }) {
    const client = tryGetClient()
    if (!client)
      throw new Error('La aplicación no tiene configuración de datos (VITE_SUPABASE_URL/ANON_KEY).')

    loading.value = true
    error.value = null
    try {
      const { error: authError } = await conTimeout(
        client.auth.signInWithPassword({
          email: normalizarEmail(correo),
          password,
        }),
      )
      if (authError) throw normalizarErrorAuth(authError)

      let ctx
      try {
        ctx = await conTimeout(refresh())
      } catch (e) {
        // LOG-NEG-007: si no se puede verificar rol/estado, no hay acceso.
        await descartarSesionParcial()
        throw new Error(
          e?.code === 'timeout'
            ? 'La conexión tardó demasiado al verificar tu cuenta. Inténtalo de nuevo.'
            : 'No pudimos verificar el estado de tu cuenta. Inténtalo de nuevo en unos segundos.',
          { cause: e },
        )
      }

      if (!ctx.perfil) {
        await descartarSesionParcial()
        throw new Error(
          'No pudimos cargar tu perfil. Inténtalo de nuevo; si persiste, contacta al soporte.',
        )
      }

      const estado = estadoEfectivoCuenta({
        perfil: ctx.perfil,
        productor: ctx.productor,
        postulacion: ctx.postulacion,
        sanciones: sanciones.value,
      })

      if (estado === 'eliminado' || estado === 'desactivado' || estado === 'baneado') {
        await descartarSesionParcial()
        if (estado === 'eliminado') {
          throw new Error('Tu cuenta fue eliminada permanentemente y no se puede reactivar.')
        }
        if (estado === 'baneado') {
          throw new Error(
            'Tu cuenta tiene un ban permanente y no puede iniciar sesión. Contacta al administrador.',
          )
        }
        throw new Error('Tu cuenta está desactivada. Contacta al administrador.')
      }

      return ctx.perfil
    } catch (e) {
      // Una sesión a medio crear (p. ej. timeout) no puede quedar utilizable.
      if (e?.code === 'timeout') {
        await descartarSesionParcial()
      }
      error.value = e.message
      throw e
    } finally {
      loading.value = false
    }
  }

  async function signOut() {
    const client = tryGetClient()
    limpiarSesion()
    if (client) {
      const result = await client.auth.signOut()
      if (result?.error) throw normalizarErrorAuth(result.error)
    }
  }

  async function descartarSesionParcial() {
    try {
      await signOut()
    } catch {
      // signOut limpia primero la identidad local, aunque falle la red.
    }
  }

  /** RF-024: cambio de contraseña del usuario autenticado. */
  async function updatePassword(passwordActual, passwordNueva) {
    const client = getClient()

    if (!required(passwordActual)) throw new Error('Ingresa tu contraseña actual')

    const politica = passwordPolicyMessage(passwordNueva)
    if (politica) throw new Error(politica)

    if (passwordActual) {
      const { error: reauthError } = await conTimeout(
        client.auth.signInWithPassword({
          email: email.value,
          password: passwordActual,
        }),
      )
      if (reauthError) throw new Error('La contraseña actual no es correcta')
    }

    const { error: updateError } = await conTimeout(
      client.auth.updateUser({ password: passwordNueva }),
    )
    if (updateError) throw normalizarErrorAuth(updateError)
    return true
  }

  /**
   * RF-023: recuperación de contraseña con mensaje genérico.
   * No se revela si el correo existe. Los errores de rate limit o de servicio
   * SÍ se informan: el usuario debe saber que no se envió el correo y que
   * puede reintentar más tarde (REC-FRM-010/011, REC-MAIL-005/007).
   */
  async function sendPasswordReset(correo) {
    const mensajeCorreo = emailPolicyMessage(correo)
    if (mensajeCorreo) throw new Error(mensajeCorreo)
    // El backend pide a GoTrue un enlace de recuperación y lo entrega con
    // Brevo. GoTrue sigue creando la sesión PASSWORD_RECOVERY al abrirlo;
    // Brevo sólo reemplaza el transportador para igualar todos los correos de
    // CuTuCo y no exponer la clave de servicio en el navegador.
    const apiBase = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')
    let response
    try {
      response = await fetch(`${apiBase}/api/auth/password-recovery`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: normalizarEmail(correo) }),
      })
    } catch {
      throw new Error('No se pudo contactar el servicio de recuperación. Intenta nuevamente.')
    }
    if (!response.ok) {
      if (response.status === 429) {
        throw new Error('Demasiados intentos en poco tiempo. Espera unos segundos antes de volver a intentar.')
      }
      throw new Error('No se pudo enviar el enlace. Intenta nuevamente.')
    }
    return true
  }

  /**
   * RF-023: cierra la recuperación definiendo la contraseña nueva.
   *
   * GoTrue ya dejó una sesión de recuperación activa al abrir el enlace, así que
   * NO se pide la contraseña anterior (a diferencia de `updatePassword`, que sí
   * la exige para un cambio desde el perfil). Al terminar se cierra la sesión:
   * Supabase Auth invalida las demás sesiones y el usuario vuelve a entrar con
   * la clave nueva.
   */
  async function completarRecuperacion(passwordNueva) {
    // Defensa en profundidad: sin el evento PASSWORD_RECOVERY de GoTrue no hay
    // una sesión de recuperación válida y no se puede cambiar la clave sin la
    // contraseña actual.
    if (!recuperacionPendiente.value) {
      throw new Error('El enlace de recuperación ya no es válido. Solicita uno nuevo.')
    }
    const politica = passwordPolicyMessage(passwordNueva)
    if (politica) throw new Error(politica)
    const client = getClient()

    // REC-NEG-001/002/004/007: antes de restablecer la clave, verificar que la
    // cuenta sigue activa. Si el estado cambió después de emitir el enlace
    // (desactivación, eliminación o ban permanente), se bloquea el
    // restablecimiento para que no se recupere el acceso a una cuenta inhabilitada.
    const { data: authUser, error: authUserError } = await client.auth.getUser()
    if (authUserError || !authUser?.user) {
      await descartarSesionParcial()
      throw new Error('No se pudo verificar la sesión de recuperación. Solicita un enlace nuevo.')
    }
    if (authUser.user) {
      const { data: perfil, error: perfilError } = await client
        .from('perfiles')
        .select('activo, eliminado_en')
        .eq('id', authUser.user.id)
        .maybeSingle()
      if (perfilError || !perfil) {
        throw new Error(
          'No pudimos verificar el estado de tu cuenta. Revisa tu conexión e inténtalo de nuevo.',
        )
      }
      if (perfil && perfil.eliminado_en) {
        recuperacionPendiente.value = false
        try {
          await client.auth.signOut()
        } catch {
          /* noop */
        }
        throw new Error(
          'Tu cuenta fue eliminada permanentemente y no se puede reactivar.',
        )
      }
      if (perfil && perfil.activo === false) {
        recuperacionPendiente.value = false
        try {
          await client.auth.signOut()
        } catch {
          /* noop */
        }
        throw new Error(
          'Tu cuenta está desactivada. No se puede restablecer la contraseña mientras la cuenta esté inactiva. Contacta al administrador.',
        )
      }
    }

    const { error: updateError } = await conTimeout(
      client.auth.updateUser({ password: passwordNueva }),
    )
    if (updateError) {
      const traducido = normalizarErrorAuth(updateError)
      // Token vencido con el formulario abierto: se cierra la sesión temporal
      // para que no quede un estado de recuperación utilizable.
      recuperacionPendiente.value = false
      try {
        await client.auth.signOut()
      } catch {
        /* noop */
      }
      throw traducido
    }
    recuperacionPendiente.value = false
    await signOut()
    return true
  }

  /** Marca el alta de recuperación cuando la SPA llega desde el correo. */
  function marcarRecuperacion(valor = true) {
    recuperacionPendiente.value = Boolean(valor)
  }

  /**
   * RF-001 y RF-020: cambio de correo de la cuenta.
   *
   * HAL-CLI-027: exige reautenticación con la contraseña actual antes de
   * solicitar el cambio. Con `double_confirm_changes = true` GoTrue exige
   * confirmar el cambio en la dirección antigua y en la nueva antes de
   * aplicarlo, así que la sesión sigue mostrando el correo actual hasta que
   * ambas confirmaciones ocurran.
   * @returns {Promise<string>} el correo solicitado
   */
  async function updateEmail(nuevoCorreo, passwordActual) {
    const client = getClient()
    const correo = normalizarEmail(nuevoCorreo)
    if (!required(passwordActual)) throw new Error('Ingresa tu contraseña actual')
    if (!isEmail(String(nuevoCorreo ?? ''))) {
      throw new Error(emailPolicyMessage(nuevoCorreo))
    }
    if (correo === String(email.value).toLowerCase()) {
      throw new Error('El correo nuevo debe ser distinto del actual')
    }

    const { error: reauthError } = await conTimeout(
      client.auth.signInWithPassword({ email: email.value, password: passwordActual }),
    )
    if (reauthError) throw new Error('La contraseña actual no es correcta')

    const { error: updateError } = await conTimeout(
      client.auth.updateUser(
        { email: correo },
        { emailRedirectTo: `${window.location.origin}/cliente/perfil` },
      ),
    )
    if (updateError) throw normalizarErrorAuth(updateError)
    return correo
  }

  /** Actualiza datos propios del perfil (nombre, apellido, teléfono). */
  async function updatePerfil(patch) {
    if (!perfil.value) return null
    const client = getClient()
    const permitido = {
      nombre: patch.nombre ?? perfil.value.nombre,
      apellido: patch.apellido ?? perfil.value.apellido,
      telefono: patch.telefono ?? perfil.value.telefono,
    }
    if (!required(permitido.nombre) || !isNombrePropio(permitido.nombre)) {
      throw new Error('Ingresa un nombre válido (sólo letras, espacios, apóstrofes o guiones)')
    }
    if (!required(permitido.apellido) || !isNombrePropio(permitido.apellido)) {
      throw new Error('Ingresa un apellido válido (sólo letras, espacios, apóstrofes o guiones)')
    }
    if (!isPhone(permitido.telefono)) {
      throw new Error('El teléfono es obligatorio y debe ser un número chileno válido')
    }
    if (String(permitido.nombre).length > LIMITES.nombre) {
      throw new Error(`El nombre no puede superar ${LIMITES.nombre} caracteres`)
    }
    if (String(permitido.apellido).length > LIMITES.apellido) {
      throw new Error(`El apellido no puede superar ${LIMITES.apellido} caracteres`)
    }
    permitido.telefono = normalizarTelefonoChileno(permitido.telefono)
    permitido.nombre = String(permitido.nombre).trim()
    permitido.apellido = String(permitido.apellido).trim()

    const { data, error: updateError } = await client
      .from('perfiles')
      .update(permitido)
      .eq('id', perfil.value.id)
      .select()
      .single()
    if (updateError) throw new Error(mensajeSeguro(updateError))
    perfil.value = data
    return data
  }

  /** Reenvía el correo de verificación de la cuenta (RF-012 y RF-020). */
  async function reenviarVerificacion(correo) {
    const client = getClient()
    const { error: resendError } = await client.auth.resend({
      type: 'signup',
      email: String(correo).trim().toLowerCase(),
      options: { emailRedirectTo: `${window.location.origin}/login` },
    })
    if (resendError) throw new Error(mensajeSeguro(resendError))
    return true
  }

  return {
    user,
    perfil,
    productor,
    postulacion,
    sanciones,
    loading,
    initializing,
    error,
    configuracionFaltante,
    recuperacionPendiente,
    sancionesVigentes,
    rol,
    email,
    isAuthenticated,
    isCliente,
    isVendedor,
    isAdmin,
    nombreCompleto,
    iniciales,
    tieneTienda,
    postulacionPendiente,
    postulacionRechazada,
    bloqueoVendedor,
    estadoCuenta,
    estaSuspendido,
    estaBaneado,
    enPostulacion,
    puedeOperarTienda,
    init,
    refresh,
    signIn,
    signOut,
    updatePassword,
    completarRecuperacion,
    marcarRecuperacion,
    sendPasswordReset,
    updateEmail,
    updatePerfil,
    reenviarVerificacion,
    detenerEscucha,
  }
})

/** Traduce los errores de GoTrue a mensajes claros para el usuario (RF-001). */
function normalizarErrorAuth(error) {
  const mensaje = String(error?.message ?? '')
  const codigo = String(error?.code ?? '')
  const status = Number(error?.status ?? 0)
  if (error?.code === 'timeout') {
    return new Error('La conexión tardó demasiado. Revisa tu red e inténtalo de nuevo.')
  }
  if (
    status === 429 ||
    /rate limit|too many|too many requests|for security purposes/i.test(mensaje)
  ) {
    return new Error(
      'Demasiados intentos en poco tiempo. Espera unos segundos antes de volver a intentar.',
    )
  }
  if (/invalid login credentials|invalid credentials/i.test(mensaje)) {
    return new Error('El correo o la contraseña no son correctos.')
  }
  if (/email not confirmed|email_not_confirmed/i.test(mensaje)) {
    return new Error(
      'Debes verificar tu correo antes de iniciar sesión. Revisa tu bandeja de entrada.',
    )
  }
  if (/password.*72|password.*too long|max.*password/i.test(mensaje)) {
    return new Error('La contraseña no puede superar los 72 caracteres.')
  }
  if (/weak.?password|password.*(weak|short|requirement)/i.test(mensaje)) {
    return new Error(
      'La contraseña no cumple la política: debe tener entre 8 y 72 caracteres, con mayúscula, minúscula, número y símbolo.',
    )
  }
  if (/email.*(long|length|max)/i.test(mensaje) || /email address.*too long/i.test(mensaje)) {
    return new Error('El correo electrónico es demasiado largo.')
  }
  if (/invalid.*email|email.*invalid|unable to validate email/i.test(mensaje)) {
    return new Error('Ingresa un correo electrónico válido.')
  }
  if (/already registered|already exists|duplicate.*email|email.*(already|taken)|unique.*email/i.test(mensaje)) {
    return new Error('Ese correo ya está registrado en otra cuenta. Usa otro correo o inicia sesión con él.')
  }
  if (/otp.*(expired|invalid)|token.*(expired|invalid)|recovery.*(expired|invalid)|expired.*link|link.*expired/i.test(mensaje)) {
    return new Error(
      'El enlace de recuperación venció o ya fue utilizado. Solicita un enlace nuevo.',
    )
  }
  if (
    status >= 500 ||
    /service unavailable|internal server error|database error|fetch failed|networkerror|failed to fetch/i.test(
      mensaje,
    )
  ) {
    return new Error(
      'El servicio de autenticación no está disponible en este momento. Inténtalo de nuevo en unos minutos.',
    )
  }
  if (codigo && /timeout/i.test(codigo)) {
    return new Error('La conexión tardó demasiado. Revisa tu red e inténtalo de nuevo.')
  }
  return new Error(mensajeSeguro(mensaje, 'No se pudo iniciar sesión'))
}
