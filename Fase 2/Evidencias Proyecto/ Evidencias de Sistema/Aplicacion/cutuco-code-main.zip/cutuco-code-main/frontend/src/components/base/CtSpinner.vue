<script setup>
/** CuTuCo — Indicador de carga. */
defineProps({
  size: { type: Number, default: 28 },
  label: { type: String, default: null },
  inline: { type: Boolean, default: false },
})
</script>

<template>
  <div class="ct-spinner" :class="{ 'is-inline': inline }" role="status">
    <span class="ct-spinner__ring" :style="{ width: `${size}px`, height: `${size}px` }" />
    <span v-if="label" class="ct-spinner__label">{{ label }}</span>
  </div>
</template>

<style scoped>
.ct-spinner {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-3);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
}

.ct-spinner__ring {
  display: inline-block;
  border: 3px solid var(--ct-border);
  border-top-color: var(--ct-primary);
  border-radius: 50%;
  animation: ct-spin 0.75s linear infinite;
}

@keyframes ct-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
