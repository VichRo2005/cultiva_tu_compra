import { describe, it, expect, beforeEach } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

import App from '@/App.vue'
import router from '@/router'
import { NAV_SECTIONS } from '@/lib/navigation'
import { MISSING_ENV, SUPABASE_URL, tryGetClient } from '@/lib/supabase'

/**
 * Arranque de la aplicación con datos reales.
 *
 * La app ya no usa el cliente simulado en memoria: se conecta a Supabase
 * (PostgREST + Auth + RLS) y a FastAPI. Esta prueba verifica que la
 * configuración esté presente, que el cliente real responda y que el router
 * exponga las rutas del alcance vigente.
 */
describe('arranque de la aplicación', () => {
  beforeEach(async () => {
    localStorage.clear()
    setActivePinia(createPinia())
    router.replace('/')
    await router.isReady()
  })

  it('tiene configurada la URL de Supabase (frontend/.env.local)', () => {
    expect(SUPABASE_URL).toMatch(/^https?:\/\//)
  })

  it('construye el cliente real de Supabase', () => {
    const client = tryGetClient()
    expect(client).not.toBeNull()
    expect(typeof client.from).toBe('function')
    expect(typeof client.auth.signInWithPassword).toBe('function')
  })

  it('no activa el modo simulado en ningún caso', () => {
    expect(MISSING_ENV).toBe(false)
  })

  it('monta la aplicación y sale del estado de carga', async () => {
    const wrapper = mount(App, { global: { plugins: [router] } })
    await flushPromises()
    await flushPromises()

    expect(wrapper.find('.ct-boot').exists()).toBe(false)
    wrapper.unmount()
  })

  it('la ruta raíz existe y no exige autenticación (RF-022)', () => {
    expect(router.resolve('/').name).toBe('home')
    expect(router.resolve('/').meta.requiresAuth).toBeUndefined()
    expect(router.resolve('/catalogo').meta.requiresAuth).toBeUndefined()
    expect(router.resolve('/producto/abc').meta.requiresAuth).toBeUndefined()
  })

  it('las rutas de cliente exigen sesión (RF-002)', () => {
    expect(router.resolve('/cliente/pedidos').meta.requiresAuth).toBe(true)
    expect(router.resolve('/checkout').meta.requiresAuth).toBe(true)
    expect(router.resolve('/pago/retorno').meta.requiresAuth).toBe(true)
  })

  it('las rutas de vendedor y admin declaran sus roles (RF-001)', () => {
    expect(router.resolve('/vendedor').meta.roles).toEqual(['vendedor', 'admin'])
    expect(router.resolve('/admin').meta.roles).toEqual(['admin'])
    expect(router.resolve('/admin/pagos').meta.roles).toEqual(['admin'])
  })

  it('todas las rutas registradas resuelven a un componente o redirigen', () => {
    for (const ruta of router.getRoutes()) {
      expect(ruta.name ?? ruta.path).toBeTruthy()
    }
    expect(router.resolve('/ruta-inexistente').name).toBe('not-found')
  })

  it('las ventanas del prototipo anterior quedan marcadas como galería', () => {
    // RF-006 v1 (score), RF-008 (precios), RF-010 (alertas) y RF-011 v1
    // (reportes) salieron del alcance: sus ventanas se conservan sólo para la
    // galería de desarrollo y no están en el menú. RF-027 (reclamos) sí es
    // alcance vigente: el administrador resuelve los reclamos.
    const soloGaleria = [
      '/vendedor/reputacion',
      '/vendedor/alertas-stock',
      '/admin/reportes',
      '/admin/geografia',
    ]
    for (const ruta of soloGaleria) {
      const resuelta = router.resolve(ruta)
      expect(resuelta.name, `no registrada: ${ruta}`).not.toBe('not-found')
      expect(resuelta.meta.gallery, `${ruta} debería estar marcada como galería`).toBe(true)
    }
  })

  it('el administrador tiene entrada al flujo de reclamos (RF-027)', () => {
    const admin = NAV_SECTIONS.find((seccion) => seccion.key === 'administracion')
    expect(admin.items.some((item) => item.to === '/admin/reclamos')).toBe(true)
    expect(router.resolve('/admin/reclamos').meta.gallery).toBeUndefined()
  })

  it('la ventana de precios se retiró por completo (RF-008)', () => {
    expect(router.resolve('/precios').name).toBe('not-found')
  })
})
