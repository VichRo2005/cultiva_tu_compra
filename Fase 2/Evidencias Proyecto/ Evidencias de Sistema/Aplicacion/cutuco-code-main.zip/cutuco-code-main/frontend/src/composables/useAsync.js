/** CuTuCo — Composables de apoyo para las vistas */

import { ref, shallowRef } from 'vue'
import { useUiStore } from '@/stores/ui'

/**
 * Carga asíncrona simple con estado de error y recarga.
 * @param {Function} loader  Función asíncrona que devuelve los datos
 * @param {Array} immediate  Si se ejecuta al montar
 */
export function useAsync(loader, { immediate = true } = {}) {
  const data = shallowRef(null)
  const loading = ref(false)
  const error = ref(null)
  const ui = useUiStore()

  async function run(...args) {
    loading.value = true
    error.value = null
    try {
      const result = await loader(...args)
      data.value = result
      return result
    } catch (e) {
      error.value = e?.message ?? 'Error inesperado'
      ui.error('No se pudo cargar la información', e?.message)
      return null
    } finally {
      loading.value = false
    }
  }

  if (immediate) run()

  return { data, loading, error, run, reload: () => run() }
}

/** Debounce simple para campos de búsqueda. */
export function useDebounceFn(fn, delay = 350) {
  let timer = null
  return (...args) => {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => fn(...args), delay)
  }
}

/** Copia un valor al portapapeles mostrando un toast. */
export async function copyWithToast(text, mensaje = 'Copiado al portapapeles') {
  const ui = useUiStore()
  try {
    await navigator.clipboard.writeText(text)
    ui.success(mensaje)
    return true
  } catch {
    ui.error('No se pudo copiar', 'Revisa los permisos del navegador')
    return false
  }
}
