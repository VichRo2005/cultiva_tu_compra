import { beforeEach, describe, expect, it, vi } from 'vitest'

const sdk = vi.hoisted(() => ({ from: vi.fn() }))
vi.mock('@/lib/supabase', () => ({
  getClient: () => sdk,
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
}))
import { getPendientesAdmin } from '@/services/admin'

describe('Pendientes administrativos: errores de consulta', () => {
  beforeEach(() => vi.resetAllMocks())

  it.each(['postulaciones_vendedores', 'sanciones', 'pedidos'])(
    'no presenta ceros cuando falla %s',
    async (tablaFallida) => {
      sdk.from.mockImplementation((tabla) => {
        const resultado = {
          data: tabla === tablaFallida ? null : [],
          error: tabla === tablaFallida ? { message: 'detalle interno sensible' } : null,
        }
        const consulta = {
          select: () => consulta,
          in: () => consulta,
          order: () => consulta,
          then: (resolve, reject) => Promise.resolve(resultado).then(resolve, reject),
        }
        return consulta
      })
      await expect(getPendientesAdmin()).rejects.toThrow('Inténtalo de nuevo')
      await expect(getPendientesAdmin()).rejects.not.toThrow('detalle interno sensible')
    },
  )
})
