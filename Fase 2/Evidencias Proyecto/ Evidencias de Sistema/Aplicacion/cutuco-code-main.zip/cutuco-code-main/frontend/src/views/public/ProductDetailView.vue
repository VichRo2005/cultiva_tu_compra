<script setup>
/**
 * CuTuCo — Detalle público de un producto (página 2 del diseño).
 * Galería, compra, pestañas de información y ficha del vendedor con su
 * reputación (RF-022 y RF-006).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el bloque "Análisis de
 * Precios" (`PriceHistoryChart`, `producto.historial`, referencia externa y
 * porcentaje de ahorro) correspondía a RF-008, fuera del ERS; el sello "Cosecha
 * del día" y el aviso de stock bajo (`stockBajo`, RF-010) también salieron.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtQuantityStepper from '@/components/base/CtQuantityStepper.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import ImageGallery from '@/components/domain/ImageGallery.vue'
import ProductGrid from '@/components/domain/ProductGrid.vue'
import portadaFondoUrl from '@/assets/fondo-agro.jpg'
import { STORAGE_BUCKETS } from '@/lib/constants'
import { storageUrl } from '@/lib/supabase'
import NotFoundView from '@/views/shared/NotFoundView.vue'
import {
  calcularTotalProducto,
  configuracionCantidadProducto,
  esCantidadValida,
  estadoCalificacion,
  formatearCantidad,
  getProductorDetalle,
  getProducto,
  listProductos,
  normalizarNombreCategoria,
} from '@/services/catalog'
import { useAuthStore } from '@/stores/auth'
import { useCartStore } from '@/stores/cart'
import { useUiStore } from '@/stores/ui'
import { formatMontoCompra as formatCLP, formatDate } from '@/lib/format'

const props = defineProps({
  adminProduct: { type: Object, default: null },
  adminMode: { type: Boolean, default: false },
})

const route = useRoute()
const router = useRouter()
const cart = useCartStore()
const auth = useAuthStore()
const ui = useUiStore()

const producto = ref(null)
const productor = ref(null)
const relacionados = ref([])
const cargando = ref(true)
const error = ref(null)
const noEncontrado = ref(false)
const cantidad = ref(1)
const pestaña = ref('descripcion')

/**
 * HAL-VEN-002: los botones de carrito/compra son del rol cliente. Un vendedor
 * (o administrador) que abre la ficha desde su detalle de pedido no ve las
 * acciones de compra; el modo admin ya las ocultaba con `adminMode`.
 */
const puedeComprar = computed(() => !props.adminMode && !auth.isVendedor && !auth.isAdmin)

const PESTANAS = [
  { value: 'descripcion', label: 'Descripción' },
  { value: 'ficha', label: 'Ficha Técnica' },
  { value: 'logistica', label: 'Logística' },
]

const BENEFICIOS = [
  {
    icon: 'calendar',
    title: 'Fecha de cosecha',
    text: 'El productor declara la fecha de cosecha de cada lote.',
  },
  {
    icon: 'lock',
    title: 'Pago seguro con Webpay',
    text: 'Pagas de forma segura con Webpay y el productor recibe el pago de su venta.',
  },
]

/** Unidad comercial real del producto: nunca se reemplaza por "unidad". */
const unidad = computed(() => producto.value?.unidad_medida ?? 'unidad')

/**
 * La cantidad inicial, el mínimo y el incremento se definen por publicación.
 * El máximo se ajusta al último múltiplo disponible de ese incremento.
 */
const configCantidad = computed(() => configuracionCantidadProducto(producto.value ?? {}))
const agotado = computed(() => configCantidad.value.agotado)
const cantidadValida = computed(() => esCantidadValida(cantidad.value, configCantidad.value))
const totalCantidad = computed(() =>
  cantidadValida.value
    ? formatCLP(calcularTotalProducto(producto.value?.precio, cantidad.value))
    : '—',
)

const hayCalificaciones = computed(
  () =>
    estadoCalificacion({
      puntaje: producto.value?.productor?.puntaje_reputacion,
      cantidadEvaluaciones: producto.value?.productor?.cantidad_evaluaciones,
    }) === 'resumen',
)

const productorConCalificaciones = computed(
  () =>
    estadoCalificacion({
      puntaje: productor.value?.puntaje_reputacion,
      cantidadEvaluaciones: productor.value?.cantidad_evaluaciones,
    }) === 'resumen',
)

/** El esquema no tiene columna `sku`: se muestra el identificador del catálogo. */
const sku = computed(() =>
  String(producto.value?.id ?? '')
    .slice(0, 8)
    .toUpperCase(),
)

/**
 * HAL-CLI-006: el origen del producto es la comuna/región de su productor, la
 * misma fuente que usa el perfil público. Si falta, ambas vistas dicen
 * "No informada" en lugar de inventar "Chile".
 */
const lugarProductor = computed(() => {
  const comuna = producto.value?.comunaProductor?.nombre
  const region = producto.value?.regionProductor?.nombre
  return [comuna, region].filter(Boolean).join(', ') || 'No informada'
})

const nombreCategoria = computed(() =>
  producto.value?.categoria?.nombre
    ? normalizarNombreCategoria(producto.value.categoria.nombre)
    : null,
)

/** Perfil público del vendedor del producto (RF-022 y RF-006). */
const enlaceVendedor = computed(() => {
  const id = producto.value?.productor?.id ?? producto.value?.productor_id
  return id ? `/vendedores/${id}` : '/catalogo'
})

/**
 * La ficha conserva la identidad visual que el productor publica en su tienda:
 * portada como contexto y avatar como referencia personal. Si alguna imagen no
 * existe, se usan los fallbacks de la misma tienda pública, nunca iconos que
 * puedan parecer una foto real del productor.
 */
const portadaVendedor = computed(() => {
  const ruta = productor.value?.portada_storage_path
  const base = ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.portadasTienda }) : null
  if (!base || base.startsWith('data:') || base.startsWith('offline:'))
    return base ?? portadaFondoUrl
  return `${base}${base.includes('?') ? '&' : '?'}v=${productor.value?.actualizado_en ?? ''}`
})

const fotoPerfilVendedor = computed(() => {
  const ruta = productor.value?.foto_perfil_storage_path
  const base = ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresVendedor }) : null
  if (!base || base.startsWith('data:') || base.startsWith('offline:')) return base
  return `${base}${base.includes('?') ? '&' : '?'}v=${productor.value?.actualizado_en ?? ''}`
})

async function cargar() {
  cargando.value = true
  error.value = null
  noEncontrado.value = false
  producto.value = null
  try {
    if (props.adminMode && props.adminProduct) {
      producto.value = props.adminProduct
      productor.value = props.adminProduct.productor
      cantidad.value = configuracionCantidadProducto(props.adminProduct).inicial
      return
    }
    const encontrado = await getProducto(route.params.id)

    // CLI-PRO-009: un identificador inexistente muestra la página 404, sin
    // reutilizar datos de otro producto.
    if (!encontrado) {
      noEncontrado.value = true
      return
    }
    producto.value = encontrado
    cantidad.value = configuracionCantidadProducto(encontrado).inicial
    const [detalle, similares] = await Promise.all([
      getProductorDetalle(encontrado.productor_id),
      listProductos({ categoriaId: encontrado.categoria_id, pageSize: 5 }),
    ])
    productor.value = detalle
    relacionados.value = similares.items.filter((p) => p.id !== encontrado.id).slice(0, 4)
  } catch (e) {
    error.value = e.message
  } finally {
    cargando.value = false
  }
}

onMounted(cargar)
watch(() => route.params.id, cargar)
watch(() => props.adminProduct, cargar)

function cantidadPermitida() {
  if (!producto.value || agotado.value) return false
  if (!cantidadValida.value) {
    ui.warning(
      'Cantidad no válida',
      `Ingresa entre ${formatearCantidad(configCantidad.value.min, unidad.value)} y ${formatearCantidad(configCantidad.value.max, unidad.value)} ${unidad.value}.`,
    )
    return false
  }
  return true
}

function irAlCarrito() {
  if (!cantidadPermitida()) return
  try {
    cart.agregar(producto.value, cantidad.value)
    router.push('/carrito')
  } catch (e) {
    ui.error('No se pudo añadir al carrito', e.message)
  }
}

function comprarAhora() {
  if (!cantidadPermitida()) return
  try {
    cart.agregar(producto.value, cantidad.value)
    router.push('/checkout')
  } catch (e) {
    ui.error('No se pudo iniciar la compra', e.message)
  }
}

function agregarRelacionado(p) {
  try {
    cart.agregar(p)
    ui.success('Añadido al carrito', p.nombre)
  } catch (e) {
    ui.error('No se pudo añadir al carrito', e.message)
  }
}
</script>

<template>
  <div class="container page">
    <CtSpinner v-if="cargando" label="Cargando producto…" />

    <NotFoundView v-else-if="noEncontrado" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar el producto">
      {{ error }}
      <CtButton variant="secondary" size="sm" @click="cargar">Reintentar</CtButton>
      <CtButton v-if="!adminMode" variant="secondary" size="sm" to="/catalogo"
        >Volver al catálogo</CtButton
      >
    </CtAlert>

    <template v-else-if="producto">
      <nav v-if="!adminMode" class="detalle__migas" aria-label="Ruta">
        <router-link to="/">Inicio</router-link>
        <span aria-hidden="true">›</span>
        <router-link to="/catalogo">Catálogo</router-link>
        <template v-if="producto.categoria">
          <span aria-hidden="true">›</span>
          <router-link :to="{ path: '/catalogo', query: { categoria: producto.categoria.id } }">
            {{ nombreCategoria }}
          </router-link>
        </template>
        <span aria-hidden="true">›</span>
        <span class="detalle__miga-actual">{{ producto.nombre }}</span>
      </nav>

      <div class="detalle">
        <!-- ============ GALERÍA Y COMPRA ============ -->
        <div class="detalle__principal">
          <div class="detalle__etiquetas">
            <CtBadge tone="primary" dot>ORIGEN CHILE</CtBadge>
            <span class="detalle__sku">SKU: {{ sku }}</span>
          </div>

          <ImageGallery
            :images="producto.imagenes ?? []"
            :respaldo="producto.imagenPrincipal?.url"
            :alt="producto.nombre"
          />

          <section class="detalle__info">
            <h1 class="detalle__titulo">{{ producto.nombre }}</h1>

            <div v-if="hayCalificaciones" class="detalle__rating">
              <CtRatingStars
                :model-value="Number(producto.productor.puntaje_reputacion)"
                :size="16"
                show-value
              />
              <span class="text-sm text-muted">
                ({{ producto.productor.cantidad_evaluaciones }}
                {{ Number(producto.productor.cantidad_evaluaciones) === 1 ? 'reseña' : 'reseñas' }})
              </span>
            </div>
            <p v-else-if="producto.productor" class="detalle__sin-rating">
              Sin valoraciones todavía
            </p>

            <div class="detalle__precio">
              <span class="detalle__precio-valor">{{ formatCLP(producto.precio) }}</span>
              <span class="detalle__precio-unidad">/ {{ unidad }}</span>
            </div>

            <!--
              NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): aquí se
              mostraba "Ahorra X% frente a la referencia de la región" con
              `producto.historial` (, fuera del ERS).
            -->

            <div class="detalle__inventario">
              <p class="eyebrow">Inventario disponible</p>
              <p class="detalle__stock" :class="{ 'is-agotado': agotado }">
                {{
                  Number(producto.stock) > 0
                    ? `${formatearCantidad(producto.stock, unidad)} ${unidad}`
                    : 'Sin stock disponible'
                }}
              </p>
            </div>

            <div
              v-if="puedeComprar && !agotado"
              class="detalle__cantidad"
              role="group"
              :aria-label="`Cantidad en ${unidad}`"
            >
              <span class="detalle__cantidad-label">Cantidad ({{ unidad }})</span>
              <CtQuantityStepper
                :model-value="cantidad"
                :min="configCantidad.min"
                :max="configCantidad.max"
                :step="configCantidad.paso"
                :decimals="configCantidad.decimales"
                :disabled="agotado"
                :unit="unidad"
                :label="`Cantidad en ${unidad}`"
                @update:model-value="cantidad = $event"
              />
            </div>

            <p v-if="puedeComprar && !agotado" class="detalle__cantidad-regla">
              Compra mínima: {{ formatearCantidad(configCantidad.inicial, unidad) }} {{ unidad }}.
              Puedes comprar hasta {{ formatearCantidad(configCantidad.max, unidad) }} {{ unidad }};
              salto mínimo: {{ formatearCantidad(configCantidad.paso, unidad) }} {{ unidad }}.
            </p>

            <p
              v-if="puedeComprar && !agotado && !cantidadValida"
              class="detalle__cantidad-error"
              role="alert"
            >
              Ingresa una cantidad válida entre
              {{ formatearCantidad(configCantidad.min, unidad) }} y
              {{ formatearCantidad(configCantidad.max, unidad) }} {{ unidad }}.
            </p>

            <p v-if="puedeComprar && !agotado" class="detalle__total">
              Total estimado: {{ totalCantidad }}
            </p>

            <div v-if="puedeComprar" class="detalle__acciones">
              <CtButton block :disabled="agotado || !cantidadValida" @click="irAlCarrito">
                <template #icon><CtIcon name="cart" :size="17" /></template>
                Añadir al Carrito
              </CtButton>
              <CtButton
                block
                variant="secondary"
                :disabled="agotado || !cantidadValida"
                @click="comprarAhora"
              >
                <template #icon><CtIcon name="truck" :size="17" /></template>
                Comprar Ahora
              </CtButton>
            </div>

            <CtAlert v-if="puedeComprar && agotado" tone="warning" compact>
              Producto agotado por el momento. Puedes revisar productos similares más abajo.
            </CtAlert>
            <CtAlert v-else-if="puedeComprar && !auth.isAuthenticated" tone="info" compact>
              Inicia sesión para pagar seguro con Webpay y recibir tu pedido con protección.
            </CtAlert>
            <!-- HAL-VEN-002: el vendedor/admin no tiene acciones de compra en la ficha. -->
            <CtAlert
              v-else-if="!adminMode && (auth.isVendedor || auth.isAdmin)"
              tone="info"
              compact
            >
              Estás navegando como {{ auth.isVendedor ? 'vendedor' : 'administrador' }}: las
              acciones de carrito y compra sólo aplican a las cuentas de cliente.
            </CtAlert>

            <ul v-if="puedeComprar" class="detalle__confianza">
              <li>
                <CtIcon name="lock" :size="16" />
                Pago Seguro
              </li>
              <li>
                <CtIcon name="shieldCheck" :size="16" />
                Certificado Origen Chile
              </li>
            </ul>
          </section>

          <div class="detalle__pestanas">
            <CtTabs v-model="pestaña" :tabs="PESTANAS" stretch />

            <div class="detalle__panel">
              <p v-if="pestaña === 'descripcion'" class="detalle__texto">
                {{
                  producto.descripcion ||
                  'El productor aún no publicó una descripción para este producto.'
                }}
              </p>

              <dl v-else-if="pestaña === 'ficha'" class="detalle__ficha">
                <div>
                  <dt>Categoría</dt>
                  <dd>{{ nombreCategoria ?? '—' }}</dd>
                </div>
                <div>
                  <dt>Unidad de venta</dt>
                  <dd>{{ unidad }}</dd>
                </div>
                <div>
                  <dt>Fecha de cosecha</dt>
                  <dd>{{ formatDate(producto.fecha_cosecha) }}</dd>
                </div>
                <div>
                  <dt>Publicado</dt>
                  <dd>{{ formatDate(producto.creado_en) }}</dd>
                </div>
                <div>
                  <dt>Stock total</dt>
                  <dd>{{ formatearCantidad(producto.stock, unidad) }} {{ unidad }}</dd>
                </div>
                <div>
                  <dt>Última actualización</dt>
                  <dd>{{ formatDate(producto.actualizado_en) }}</dd>
                </div>
              </dl>

              <div v-else class="detalle__logistica">
                <p class="detalle__texto">
                  CuTuCo compara la región de tu dirección de entrega con la región del productor
                  antes de crear el pago. El costo de despacho se informa antes de confirmar y la
                  entrega se cierra con el código de verificación del pedido.
                </p>
                <dl class="detalle__ficha">
                  <div>
                    <dt>Origen</dt>
                    <dd>{{ lugarProductor }}</dd>
                  </div>
                  <div>
                    <dt>Costo de envío</dt>
                    <dd>Se informa al momento de finalizar el pedido</dd>
                  </div>
                </dl>
              </div>
            </div>

            <div v-if="puedeComprar" class="detalle__beneficios">
              <article v-for="beneficio in BENEFICIOS" :key="beneficio.title" class="beneficio">
                <span class="beneficio__icon" aria-hidden="true">
                  <CtIcon :name="beneficio.icon" :size="20" />
                </span>
                <div>
                  <h3 class="beneficio__titulo">{{ beneficio.title }}</h3>
                  <p class="beneficio__texto">{{ beneficio.text }}</p>
                </div>
              </article>
            </div>
          </div>
        </div>

        <!-- ============ COLUMNA DERECHA ============ -->
        <aside class="detalle__lateral">
          <CtCard padding="none" class="vendedor">
            <div class="vendedor__portada">
              <img class="vendedor__portada-img" :src="portadaVendedor" alt="" aria-hidden="true" />
              <div class="vendedor__portada-velo" aria-hidden="true" />
              <p class="eyebrow vendedor__eyebrow">Vendido por</p>
            </div>
            <div class="vendedor__contenido">
              <div class="vendedor__head">
                <CtAvatar
                  class="vendedor__avatar"
                  :src="fotoPerfilVendedor"
                  :name="producto.productor?.nombre_comercial ?? 'Productor CuTuCo'"
                  :size="56"
                />
                <div class="vendedor__identidad">
                  <h2 class="vendedor__nombre">
                    {{ producto.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
                  </h2>
                  <p class="vendedor__lugar">{{ lugarProductor }}</p>
                </div>
              </div>

              <div v-if="productorConCalificaciones" class="vendedor__reputacion">
                <CtRatingStars
                  :model-value="Number(productor?.puntaje_reputacion ?? 0)"
                  :size="16"
                  show-value
                />
                <span class="text-xs text-muted">
                  {{ productor?.cantidad_evaluaciones ?? 0 }}
                  {{
                    Number(productor?.cantidad_evaluaciones ?? 0) === 1
                      ? 'evaluación'
                      : 'evaluaciones'
                  }}
                </span>
              </div>
              <p v-else class="text-xs text-muted">Sin valoraciones todavía</p>

              <CtBadge :tone="productor?.activo ? 'success' : 'danger'" size="sm">
                {{ productor?.activo ? 'Productor Verificado' : 'Tienda pausada' }}
              </CtBadge>

              <p class="vendedor__descripcion clamp-3">{{ productor?.descripcion }}</p>

              <CtButton v-if="!adminMode" variant="secondary" block :to="enlaceVendedor"
                >Ver Perfil</CtButton
              >
            </div>
          </CtCard>

          <!--
            NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): la tarjeta
            "Análisis de Precios" con `PriceHistoryChart`, `producto.historial` y
            el enlace a `/precios` correspondía a (historial de precios),
            fuera del alcance vigente. La ruta `/precios` ya no existe.
          -->
        </aside>
      </div>

      <!-- ============ RELACIONADOS ============ -->
      <section v-if="puedeComprar && relacionados.length" class="relacionados">
        <div class="relacionados__head">
          <h2 class="relacionados__titulo">También te podría interesar</h2>
          <CtButton variant="secondary" to="/catalogo">Ver Todo el Catálogo</CtButton>
        </div>
        <ProductGrid
          :productos="relacionados"
          :show-rating="true"
          empty-title="Sin productos relacionados"
          @add="agregarRelacionado"
        />
      </section>
    </template>
  </div>
</template>

<style scoped>
.detalle__migas {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.detalle__migas a {
  color: var(--ct-text-muted);
}

.detalle__migas a {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding-inline: 2px;
  border-radius: var(--ct-radius-sm);
}

.detalle__migas a:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.detalle__miga-actual {
  color: var(--ct-text);
  font-weight: var(--ct-fw-medium);
}

.detalle {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

.detalle__principal {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-6);
  min-width: 0;
}

.detalle__etiquetas {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ct-space-3);
}

.detalle__sku {
  font-family: var(--ct-font-mono);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

/* ------------------------- Compra ------------------------- */

.detalle__info {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding: var(--ct-space-6);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-xs);
}

.detalle__titulo {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: 1.15;
}

.detalle__rating {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.detalle__precio {
  display: flex;
  align-items: baseline;
  gap: var(--ct-space-2);
  padding-block: var(--ct-space-3);
  border-block: 1px solid var(--ct-border);
}

.detalle__precio-valor {
  font-size: var(--ct-fs-4xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  color: var(--ct-primary-strong);
}

.detalle__precio-unidad {
  font-size: var(--ct-fs-lg);
  color: var(--ct-text-muted);
}

/* NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): `.detalle__ahorro`
   pintaba el ahorro contra la referencia externa de precio. */
.detalle__ahorro {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-success);
}

.detalle__inventario {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.detalle__stock {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

/* NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): `.is-bajo` era el color
   del aviso de stock bajo (, fuera del ERS). */
.detalle__stock.is-bajo {
  color: var(--ct-warning);
}

.detalle__stock.is-agotado {
  color: var(--ct-danger);
}

.detalle__cantidad {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-2);
}

.detalle__cantidad-label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.detalle__cantidad-regla {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  line-height: var(--ct-lh-normal);
}

.detalle__cantidad-error {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-danger);
}

.detalle__sin-rating {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.detalle__total {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.detalle__acciones {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-2);
}

.detalle__confianza {
  list-style: none;
  margin: var(--ct-space-4) 0 0;
  padding: var(--ct-space-4) 0 0;
  border-top: 1px solid var(--ct-border);
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-6);
}

.detalle__confianza li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
}

.detalle__confianza svg {
  color: var(--ct-primary-strong);
}

/* ------------------------- Pestañas ------------------------- */

.detalle__panel {
  padding-top: var(--ct-space-5);
}

.detalle__texto {
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
  white-space: pre-line;
}

.detalle__ficha {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: var(--ct-space-4);
  margin: 0;
}

.detalle__ficha dt {
  font-size: var(--ct-fs-xs);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.detalle__ficha dd {
  margin: 2px 0 0;
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
}

.detalle__logistica {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.detalle__beneficios {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
  margin-top: var(--ct-space-6);
}

.beneficio {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4);
  background: var(--ct-surface-alt);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
}

.beneficio__icon {
  width: 38px;
  height: 38px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-sm);
  display: grid;
  place-items: center;
  background: var(--ct-primary-fill);
  color: var(--ct-text-invert);
}

.beneficio__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.beneficio__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: 1.5;
}

/* ------------------------- Lateral ------------------------- */

.detalle__lateral {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
  position: sticky;
  top: calc(var(--ct-header-height) + var(--ct-space-4));
}

.vendedor {
  overflow: hidden;
}

.vendedor__portada {
  position: relative;
  min-height: 86px;
  overflow: hidden;
  background: var(--ct-primary-soft);
}

.vendedor__portada-img,
.vendedor__portada-velo {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}

.vendedor__portada-img {
  object-fit: cover;
}

.vendedor__portada-velo {
  background: linear-gradient(100deg, rgba(14, 46, 30, 0.86), rgba(14, 46, 30, 0.38));
}

.vendedor__eyebrow {
  position: relative;
  z-index: 1;
  margin: var(--ct-space-4) var(--ct-space-5);
  color: var(--ct-white);
}

.vendedor__contenido {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding: var(--ct-space-5);
}

.vendedor__head {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  margin-top: calc(var(--ct-space-5) * -1);
  position: relative;
  z-index: 1;
}

.vendedor__avatar {
  border: 3px solid var(--ct-surface);
  box-shadow: var(--ct-shadow-sm);
}

.vendedor__identidad {
  min-width: 0;
}

.vendedor__nombre {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.vendedor__lugar {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.vendedor__reputacion {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  margin-top: var(--ct-space-2);
}

.vendedor__descripcion {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

/* NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): `.analisis*` estilaba la
   tarjeta "Análisis de Precios". */
.analisis__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-3);
  width: 100%;
}

.analisis__titulo {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.analisis__leyenda {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--ct-space-1) var(--ct-space-2);
  margin-top: var(--ct-space-2);
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-soft);
}

.analisis__punto {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-left: var(--ct-space-2);
}

.analisis__punto.is-actual {
  background: var(--ct-primary-strong);
}

.analisis__punto.is-mercado {
  background: var(--ct-accent);
}

.analisis__nota {
  margin-top: var(--ct-space-4);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  line-height: 1.5;
}

/* ------------------------- Relacionados ------------------------- */

.relacionados {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.relacionados__head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
}

.relacionados__titulo {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

@media (max-width: 1100px) {
  .detalle {
    grid-template-columns: minmax(0, 1fr);
  }

  .detalle__lateral {
    position: static;
  }
}

@media (max-width: 640px) {
  .detalle__acciones,
  .detalle__beneficios {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
