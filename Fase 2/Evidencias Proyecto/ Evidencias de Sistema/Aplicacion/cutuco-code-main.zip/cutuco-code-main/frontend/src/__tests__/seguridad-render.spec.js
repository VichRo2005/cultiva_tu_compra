import { describe, expect, it, vi } from 'vitest'
import { mount } from '@vue/test-utils'

vi.mock('@/services/catalog', async (importOriginal) => ({
  ...(await importOriginal()),
  normalizarNombreCategoria: (value) => value,
}))

import ProductCard from '@/components/domain/ProductCard.vue'

describe('seguridad de contenido almacenado', () => {
  it('renderiza nombre, descripción y vendedor como texto sin crear HTML ejecutable', () => {
    const ataque = '<img src=x onerror="window.__xss=1"><script>window.__xss=2</script>'
    const wrapper = mount(ProductCard, {
      props: {
        actionable: false,
        producto: {
          id: 'xss-qa', nombre: ataque, descripcion: ataque,
          precio: 1000, stock: 1, unidad_medida: 'unidad',
          productor: { nombre_comercial: ataque }, imagenPrincipal: null,
        },
      },
      global: { stubs: { RouterLink: { template: '<a><slot /></a>' } } },
    })
    expect(wrapper.text()).toContain(ataque)
    expect(wrapper.findAll('script')).toHaveLength(0)
    expect(wrapper.findAll('img')).toHaveLength(0)
    expect(window.__xss).toBeUndefined()
    wrapper.unmount()
  })
})
