/**
 * CuTuCo — Lote 19 (Acceso y sesión / Contraseña y correo), lado frontend.
 *
 * CK-0005/0006: límite nativo de GoTrue (429) -> mensaje "espera"; tras
 *               restablecerse, credenciales válidas entran de nuevo.
 * CK-0007: correo sin confirmar no habilita sesión protegida.
 * CK-0042–0045, CK-0406: cambio de correo con reautenticación, validación de
 *               formato, rechazo de correo ocupado y doble confirmación de
 *               GoTrue (el correo local no cambia hasta confirmar ambos).
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const contexto = vi.hoisted(() => ({
  currentAuth: vi.fn(),
  motivoBloqueoVendedor: vi.fn(),
  sancionVigente: vi.fn(() => false),
  estadoEfectivoCuenta: vi.fn(({ perfil } = {}) => {
    if (!perfil) return 'sin_perfil'
    if (perfil.eliminado_en) return 'eliminado'
    if (perfil.activo === false) return 'desactivado'
    return 'activo'
  }),
}))
const cliente = vi.hoisted(() => ({
  from: vi.fn(),
  auth: {
    getSession: vi.fn(),
    getUser: vi.fn(),
    signInWithPassword: vi.fn(),
    signOut: vi.fn(),
    updateUser: vi.fn(),
    resetPasswordForEmail: vi.fn(),
    resend: vi.fn(),
    onAuthStateChange: vi.fn(),
  },
}))
vi.mock('@/services/session', () => contexto)
vi.mock('@/lib/supabase', () => ({
  getClient: () => cliente,
  tryGetClient: () => cliente,
  MISSING_ENV: false,
  MODO_DEMO: { value: false },
}))
import { useAuthStore } from '@/stores/auth.js'

const PERFIL_CLIENTE = { id: 'u1', rol: 'cliente', activo: true }

beforeEach(() => {
  vi.resetAllMocks()
  setActivePinia(createPinia())
  contexto.currentAuth.mockResolvedValue({
    user: { id: 'u1', email: 'qa@example.test' },
    perfil: PERFIL_CLIENTE,
    productor: null,
    postulacion: null,
  })
  cliente.auth.getSession.mockResolvedValue({ data: { session: null }, error: null })
  cliente.auth.onAuthStateChange.mockReturnValue({
    data: { subscription: { unsubscribe: vi.fn() } },
  })
  cliente.auth.signInWithPassword.mockResolvedValue({ error: null })
  cliente.auth.signOut.mockResolvedValue({ error: null })
  cliente.auth.updateUser.mockResolvedValue({ error: null })
})

describe('CK-0005/CK-0006 · límite de GoTrue (429) y recuperación', () => {
  it('429 se traduce a "espera" sin conceder acceso', async () => {
    cliente.auth.signInWithPassword.mockResolvedValueOnce({
      error: { status: 429, message: 'Too many requests' },
    })
    const auth = useAuthStore()
    await expect(auth.signIn({ email: 'qa@example.test', password: 'Clave123!' })).rejects.toThrow(
      /Demasiados intentos.*Espera/i,
    )
    expect(auth.perfil).toBeNull()
  })

  it('tras restablecerse el límite, credenciales válidas entran de nuevo', async () => {
    cliente.auth.signInWithPassword
      .mockResolvedValueOnce({ error: { status: 429, message: 'rate limit' } })
      .mockResolvedValueOnce({ error: null })
    const auth = useAuthStore()
    await expect(auth.signIn({ email: 'qa@example.test', password: 'mala' })).rejects.toThrow(/Espera/i)
    const perfil = await auth.signIn({ email: 'qa@example.test', password: 'Clave123!' })
    expect(perfil.rol).toBe('cliente')
  })
})

describe('CK-0007 · correo sin confirmar no habilita funciones protegidas', () => {
  it('email_not_confirmed se traduce y no queda sesión utilizable', async () => {
    cliente.auth.signInWithPassword.mockResolvedValueOnce({
      error: { status: 400, message: 'Email not confirmed' },
    })
    const auth = useAuthStore()
    await expect(auth.signIn({ email: 'sinconfirmar@example.test', password: 'Clave123!' })).rejects.toThrow(
      /verificar tu correo/i,
    )
    expect(auth.perfil).toBeNull()
    expect(auth.isAuthenticated).toBe(false)
  })
})

describe('CK-0042–0045, CK-0406 · cambio de correo', () => {
  it('CK-0042: exige reautenticación antes de solicitar el cambio', async () => {
    cliente.auth.signInWithPassword.mockResolvedValueOnce({
      error: { status: 400, message: 'Invalid login credentials' },
    })
    const auth = useAuthStore()
    auth.user = { id: 'u1', email: 'qa@example.test' }
    await expect(auth.updateEmail('nuevo@example.test', 'incorrecta')).rejects.toThrow(
      /contraseña actual no es correcta/i,
    )
    expect(cliente.auth.updateUser).not.toHaveBeenCalled()
  })

  it('CK-0406: rechaza formato inválido y correo igual al actual sin llamar a GoTrue', async () => {
    const auth = useAuthStore()
    auth.user = { id: 'u1', email: 'qa@example.test' }
    await expect(auth.updateEmail('no-es-correo', 'Clave123!')).rejects.toThrow(/correo/i)
    await expect(auth.updateEmail('QA@example.test', 'Clave123!')).rejects.toThrow(/distinto del actual/i)
    expect(cliente.auth.updateUser).not.toHaveBeenCalled()
  })

  it('CK-0045/CK-0407: correo ocupado se rechaza con mensaje claro y no toca el correo actual', async () => {
    cliente.auth.updateUser.mockResolvedValueOnce({
      error: { status: 422, message: 'User already registered' },
    })
    const auth = useAuthStore()
    auth.user = { id: 'u1', email: 'qa@example.test' }
    await expect(auth.updateEmail('ocupado@example.test', 'Clave123!')).rejects.toThrow(
      /ya está registrado en otra cuenta/i,
    )
    expect(auth.user.email).toBe('qa@example.test')
  })

  it('CK-0043/CK-0044: solicita el cambio a GoTrue (doble confirmación) y conserva el correo local', async () => {
    const auth = useAuthStore()
    auth.user = { id: 'u1', email: 'qa@example.test' }
    const solicitado = await auth.updateEmail('nuevo@example.test', 'Clave123!')
    expect(solicitado).toBe('nuevo@example.test')
    expect(cliente.auth.updateUser).toHaveBeenCalledTimes(1)
    const payload = cliente.auth.updateUser.mock.calls[0][0]
    expect(payload).toEqual({ email: 'nuevo@example.test' }) // sólo el correo; GoTrue confirma ambos lados
    // hasta que ambas confirmaciones ocurran, la sesión sigue con el correo anterior
    expect(auth.user.email).toBe('qa@example.test')
  })
})
