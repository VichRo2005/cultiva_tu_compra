<script setup>
/**
 * CuTuCo — Campo de texto con etiqueta, ayuda, error e iconos.
 * Los campos de contraseña incluyen el control mostrar/ocultar (A1 del
 * encargo de auditoría): alterna la visibilidad sin perder el valor ni el
 * foco del formulario.
 */
import { computed, ref, useAttrs, useId } from 'vue'
import CtIcon from '@/components/base/CtIcon.vue'

defineOptions({ inheritAttrs: false })

const props = defineProps({
  modelValue: { type: [String, Number], default: '' },
  label: { type: String, default: null },
  hint: { type: String, default: null },
  error: { type: String, default: null },
  type: { type: String, default: 'text' },
  placeholder: { type: String, default: null },
  prefix: { type: String, default: null },
  suffix: { type: String, default: null },
  disabled: { type: Boolean, default: false },
  required: { type: Boolean, default: false },
  clearable: { type: Boolean, default: false },
  // Formularios sensibles (cambio de contraseña) deben requerir escritura
  // explícita. Evita que el gestor del navegador reutilice una credencial.
  preventAutofill: { type: Boolean, default: false },
  size: { type: String, default: 'md' }, // sm | md | lg
})

const emit = defineEmits(['update:modelValue', 'blur', 'enter'])

const attrs = useAttrs()
const id = useId()
const errorId = `${id}-error`
const hintId = `${id}-hint`

const value = computed({
  get: () => props.modelValue,
  set: (v) => emit('update:modelValue', v),
})

const clases = computed(() => [
  'ct-field__wrap',
  `ct-field--${props.size}`,
  {
    'ct-field--error': Boolean(props.error),
    'ct-field--disabled': props.disabled,
  },
])

const descritoPor = computed(() => (props.error ? errorId : props.hint ? hintId : undefined))

/** A1: visibilidad de la contraseña sin borrar lo escrito. */
const esPassword = computed(() => props.type === 'password')
const visible = ref(false)
const tipoEfectivo = computed(() => (esPassword.value && visible.value ? 'text' : props.type))
const inputAttrs = computed(() => {
  if (!props.preventAutofill) return attrs
  const resto = { ...attrs }
  delete resto.autocomplete
  delete resto.name
  return resto
})
const autocomplete = computed(() => (props.preventAutofill ? 'new-password' : attrs.autocomplete))
const name = computed(() => (props.preventAutofill ? `manual-password-${id}` : attrs.name))
</script>

<template>
  <div :class="clases">
    <label v-if="label" :for="id" class="ct-field__label">
      {{ label }}
      <span v-if="required" class="ct-field__required" aria-hidden="true">*</span>
    </label>

    <span class="ct-field__control">
      <span v-if="$slots.leading || prefix" class="ct-field__affix">
        <slot name="leading">{{ prefix }}</slot>
      </span>
      <input
        :id="id"
        v-model="value"
        v-bind="inputAttrs"
        class="ct-field__input"
        :type="tipoEfectivo"
        :placeholder="placeholder"
        :disabled="disabled"
        :required="required"
        :autocomplete="autocomplete"
        :name="name"
        :data-1p-ignore="preventAutofill ? 'true' : undefined"
        :data-lpignore="preventAutofill ? 'true' : undefined"
        :aria-invalid="Boolean(error) || undefined"
        :aria-describedby="descritoPor"
        @blur="emit('blur', $event)"
        @keyup.enter="emit('enter', $event)"
      />
      <button
        v-if="esPassword"
        type="button"
        class="ct-field__ver"
        :aria-label="visible ? 'Ocultar contraseña' : 'Mostrar contraseña'"
        :aria-pressed="visible"
        :title="visible ? 'Ocultar contraseña' : 'Mostrar contraseña'"
        @click="visible = !visible"
      >
        <CtIcon :name="visible ? 'eyeOff' : 'eye'" :size="16" aria-hidden="true" />
      </button>
      <button
        v-if="clearable && value"
        type="button"
        class="ct-field__clear"
        aria-label="Limpiar"
        @click="emit('update:modelValue', '')"
      >
        ×
      </button>
      <span v-if="suffix || $slots.trailing" class="ct-field__affix ct-field__affix--suffix">
        <slot name="trailing">{{ suffix }}</slot>
      </span>
    </span>

    <span v-if="error" :id="errorId" class="ct-field__error" role="alert">{{ error }}</span>
    <span v-else-if="hint" :id="hintId" class="ct-field__hint">{{ hint }}</span>
  </div>
</template>

<style scoped>
.ct-field__wrap {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  min-width: 0;
}

.ct-field__label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.ct-field__required {
  color: var(--ct-danger);
}

.ct-field__control {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  padding-inline: var(--ct-space-3);
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition),
    background-color var(--ct-transition);
}

/* Borde que se refuerza al pasar el puntero (sin confundir con el foco). */
.ct-field__control:hover:not(:focus-within) {
  border-color: var(--ct-border-strong);
}

.ct-field--sm .ct-field__control {
  min-height: 36px;
}
.ct-field--md .ct-field__control {
  min-height: 42px;
}
.ct-field--lg .ct-field__control {
  min-height: 48px;
}

.ct-field__control:focus-within {
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-field--error .ct-field__control {
  border-color: var(--ct-danger);
}

.ct-field--error .ct-field__control:focus-within {
  box-shadow: var(--ct-shadow-focus-danger);
}

.ct-field--disabled .ct-field__control {
  background: var(--ct-surface-alt);
  opacity: 0.7;
}

.ct-field__input {
  flex: 1;
  min-width: 0;
  min-height: 34px;
  border: none;
  outline: none;
  background: transparent;
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
  padding-block: 0;
}

.ct-field__input::placeholder {
  color: var(--ct-text-muted);
}

.ct-field__affix {
  display: inline-flex;
  align-items: center;
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-sm);
  white-space: nowrap;
}

.ct-field__clear {
  color: var(--ct-text-muted);
  font-size: 1.1rem;
  line-height: 1;
}

.ct-field__ver {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: 0;
  background: none;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-text-muted);
  cursor: pointer;
}

.ct-field__ver:hover {
  color: var(--ct-text);
  background: var(--ct-surface-alt);
}

.ct-field__clear:hover {
  color: var(--ct-text);
}

.ct-field__hint {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ct-field__error {
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
  font-weight: var(--ct-fw-medium);
}
</style>
