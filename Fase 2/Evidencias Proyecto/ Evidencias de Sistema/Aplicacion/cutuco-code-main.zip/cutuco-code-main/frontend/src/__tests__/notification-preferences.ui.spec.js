import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const supabaseMock = vi.hoisted(() => ({ tryGetClient: vi.fn() }))
const sessionMock = vi.hoisted(() => ({ currentUserId: vi.fn() }))
const preferencesMock = vi.hoisted(() => ({ obtenerPreferenciasNotificacion: vi.fn() }))

vi.mock('@/lib/supabase', () => supabaseMock)
vi.mock('@/services/session', () => sessionMock)
vi.mock('@/services/notificationPreferences', () => preferencesMock)

import { useUiStore } from '@/stores/ui'

beforeEach(() => {
  setActivePinia(createPinia())
  sessionMock.currentUserId.mockResolvedValue('perfil-cliente')
})

afterEach(() => vi.resetAllMocks())

describe('avisos dentro de CuTuCo', () => {
  it('no consulta ni muestra alertas cuando el canal de plataforma está desactivado', async () => {
    const from = vi.fn()
    supabaseMock.tryGetClient.mockReturnValue({ from })
    preferencesMock.obtenerPreferenciasNotificacion.mockResolvedValue({ email: true, inApp: false })
    const ui = useUiStore()

    await ui.syncNotifications({ rol: 'cliente' })

    expect(from).not.toHaveBeenCalled()
    expect(ui.notifications).toEqual([])
  })
})
