<script setup>
/**
 * CuTuCo — Recuperación de contraseña (RF-023). Mismo lenguaje visual que el
 * inicio de sesión.
 *
 * La vista tiene dos momentos:
 *
 *  1. **Solicitud**: el visitante escribe su correo y GoTrue envía el enlace.
 *  2. **Definición de la clave nueva**: al abrir el enlace, GoTrue deja una
 *     sesión de recuperación y devuelve el navegador a
 *     `/recuperar-clave?recuperacion=1`. En ese momento se pide la contraseña
 *     nueva, sin exigir la anterior (el usuario no la recuerda: de eso se trata
 *     la recuperación).
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import {
  emailPolicyMessage,
  isEmail,
  LIMITES,
  PASSWORD_REQUIREMENTS,
  passwordChecks,
  passwordPolicyMessage,
  passwordStrength,
} from '@/lib/validation'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const ui = useUiStore()

const email = ref('')
const error = ref(null)
const errorEmail = ref(null)
const enviando = ref(false)
const enviado = ref(route.query.exito === '1')

/** Segundo momento: se llegó desde el enlace del correo. */
const enRecuperacion = ref(route.query.recuperacion === '1')
const enlaceInvalido = ref(false)
const cuentaInhabilitada = ref(false)
const clave = ref({ nueva: '', repetir: '' })
const erroresClave = ref({})
const guardandoClave = ref(false)

const fuerza = computed(() => passwordStrength(clave.value.nueva))
const requisitos = computed(() => passwordChecks(clave.value.nueva))

/**
 * Sólo GoTrue puede acreditar que el enlace es válido: al procesarlo emite
 * PASSWORD_RECOVERY y `stores/auth` enciende `recuperacionPendiente`. Una sesión
 * normal (aunque se abra `?recuperacion=1` a mano) no habilita este formulario.
 */
const puedeDefinirClave = computed(() => auth.recuperacionPendiente)

const ayuda = [
  'Revisa la carpeta de spam si no llega en unos minutos.',
  'El enlace caduca por seguridad; si expira, vuelve a solicitarlo.',
  'Debes usar el correo con el que registraste tu cuenta.',
]

/**
 * GoTrue puede devolver el error en el hash (#error_code=otp_expired) en vez de
 * query. Se lee ANTES de que el SDK limpie la URL, para mostrar el vencimiento
 * y ofrecer un enlace nuevo (REC-LINK-003).
 */
function leerErrorDelEnlace() {
  const hash = String(window.location.hash ?? '')
  const query = route.query
  const codigo = String(query.error_code ?? query.error ?? '')
  const descripcion = String(query.error_description ?? '')
  if (codigo || descripcion || /error_code=otp_expired|error=access_denied/.test(hash)) {
    enRecuperacion.value = true
    enlaceInvalido.value = true
    auth.marcarRecuperacion(false)
    if (/otp_expired|expired|access_denied/i.test(`${codigo} ${descripcion} ${hash}`)) {
      error.value =
        'El enlace de recuperación venció o ya fue utilizado. Solicita un enlace nuevo e inténtalo otra vez.'
    }
  } else if (/type=recovery/.test(hash)) {
    enRecuperacion.value = true
  }
}

onMounted(leerErrorDelEnlace)

watch(
  () => auth.recuperacionPendiente,
  (activo) => {
    if (activo) {
      enRecuperacion.value = true
      enlaceInvalido.value = false
      error.value = null
    }
  },
  { immediate: true },
)

async function enviar() {
  if (enviando.value) return
  error.value = null
  errorEmail.value = null
  if (!String(email.value ?? '').trim()) {
    errorEmail.value = 'El correo electrónico es obligatorio'
    return
  }
  if (!isEmail(email.value)) {
    errorEmail.value = emailPolicyMessage(email.value)
    return
  }
  enviando.value = true
  try {
    await auth.sendPasswordReset(email.value)
    enviado.value = true
  } catch (e) {
    // Rate limit o fallo temporal: se informa sin revelar si la cuenta existe.
    error.value = e.message
  } finally {
    enviando.value = false
  }
}

/** RF-023: cierra la recuperación con la contraseña nueva. */
async function guardarClave() {
  if (guardandoClave.value) return
  erroresClave.value = {}
  error.value = null
  erroresClave.value.nueva = passwordPolicyMessage(clave.value.nueva) ?? undefined
  if (!clave.value.repetir) {
    erroresClave.value.repetir = 'Repite la contraseña nueva'
  } else if (clave.value.nueva !== clave.value.repetir) {
    erroresClave.value.repetir = 'Las contraseñas no coinciden'
  }
  if (Object.values(erroresClave.value).some(Boolean)) return

  guardandoClave.value = true
  try {
    await auth.completarRecuperacion(clave.value.nueva)
    ui.success('Contraseña actualizada', 'Inicia sesión con tu nueva contraseña')
    router.push({ name: 'login' })
  } catch (e) {
    const msg = e?.message ?? 'No se pudo actualizar la contraseña. Verifica que el enlace sea válido y no haya expirado.'
    error.value = msg
    // Errores de estado de cuenta (desactivada/eliminada): no sirve solicitar
    // otro enlace; el usuario debe contactar al administrador.
    cuentaInhabilitada.value = /eliminada permanentemente|está desactivada|inactiva/i.test(msg)
    // Token vencido con el formulario abierto: se ofrece solicitar otro.
    if (!cuentaInhabilitada.value && /venció|expiró|inválido|utilizado/i.test(msg)) {
      enlaceInvalido.value = true
      enRecuperacion.value = true
    }
  } finally {
    guardandoClave.value = false
  }
}

function solicitarOtroEnlace() {
  auth.marcarRecuperacion(false)
  enlaceInvalido.value = false
  cuentaInhabilitada.value = false
  enRecuperacion.value = false
  enviado.value = false
  error.value = null
  clave.value = { nueva: '', repetir: '' }
}
</script>

<template>
  <AuthLayout
    title="Recupera tu contraseña"
    subtitle="Te enviaremos un enlace seguro para crear una nueva contraseña."
  >
    <nav class="recupera__tabs" aria-label="Acceso a la plataforma">
      <router-link to="/login" class="recupera__tab is-active" aria-current="page">
        Iniciar Sesión
      </router-link>
      <router-link to="/registro" class="recupera__tab">Crear Cuenta</router-link>
    </nav>

    <!-- ============ Definir la contraseña nueva ============ -->
    <div v-if="enRecuperacion" class="stack stack--lg">
      <CtAlert v-if="error && !enlaceInvalido" tone="danger">{{ error }}</CtAlert>

      <template v-if="puedeDefinirClave">
        <CtAlert tone="success" title="Enlace verificado">
          Ya validamos tu enlace de recuperación. Define tu contraseña nueva.
        </CtAlert>

        <form class="stack" novalidate @submit.prevent="guardarClave">
          <CtInput
            v-model="clave.nueva"
            label="Nueva contraseña"
            type="password"
            hint="Entre 8 y 72 caracteres ASCII, con mayúscula, minúscula, número y símbolo."
            autocomplete="new-password"
            :maxlength="LIMITES.password"
            :error="erroresClave.nueva ?? null"
            required
          />
          <CtProgressBar
            v-if="clave.nueva"
            :value="fuerza.score"
            :max="4"
            :tone="fuerza.tone"
            show-label
            :label="fuerza.label"
            class="recupera__fuerza"
          />
          <ul v-if="clave.nueva" class="recupera__requisitos" aria-label="Requisitos de la contraseña">
            <li
              v-for="req in PASSWORD_REQUIREMENTS"
              :key="req.key"
              :class="{ 'is-ok': requisitos[req.key] }"
            >
              <CtIcon :name="requisitos[req.key] ? 'check' : 'close'" :size="13" aria-hidden="true" />
              <span>{{ req.label }}</span>
            </li>
          </ul>
          <CtInput
            v-model="clave.repetir"
            label="Repetir contraseña"
            type="password"
            autocomplete="new-password"
            :maxlength="LIMITES.password"
            :error="erroresClave.repetir ?? null"
            required
          />
          <CtButton type="submit" block size="lg" :loading="guardandoClave" :disabled="guardandoClave">
            Guardar la contraseña nueva
          </CtButton>
        </form>

        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              Por seguridad, al cambiarla se cerrarán las demás sesiones abiertas. Tendrás que
              iniciar sesión otra vez con la contraseña nueva.
            </span>
          </p>
        </CtAlert>
      </template>

      <template v-else>
        <template v-if="cuentaInhabilitada">
          <CtAlert tone="warning" title="No se puede restablecer la contraseña">
            {{ error || 'Tu cuenta está desactivada o eliminada y no se puede restablecer la contraseña. Contacta al administrador.' }}
          </CtAlert>
          <div class="recupera__acciones">
            <CtButton variant="secondary" to="/login">Volver a iniciar sesión</CtButton>
          </div>
        </template>
        <template v-else>
          <CtAlert tone="warning" title="El enlace ya no es válido">
            {{ error || 'El enlace de recuperación caducó, ya se usó o se abrió en otro navegador. Solicita uno nuevo e inténtalo de nuevo.' }}
          </CtAlert>
          <div class="recupera__acciones">
            <CtButton variant="secondary" to="/login">Volver a iniciar sesión</CtButton>
            <CtButton @click="solicitarOtroEnlace">Solicitar un enlace nuevo</CtButton>
          </div>
        </template>
      </template>
    </div>

    <!-- ============ Solicitar el enlace ============ -->
    <div v-else class="stack stack--lg">
      <CtAlert v-if="enviado" tone="success" title="Enlace enviado">
        Si el correo <strong>{{ email || 'ingresado' }}</strong> tiene una cuenta en CuTuCo,
        recibirás un enlace para restablecer tu contraseña en unos minutos.
      </CtAlert>

      <CtAlert v-else-if="error" tone="danger">{{ error }}</CtAlert>

      <form v-if="!enviado" class="stack" novalidate @submit.prevent="enviar">
        <CtInput
          v-model="email"
          label="Correo Electrónico"
          type="email"
          placeholder="tucorreo@ejemplo.cl"
          autocomplete="email"
          :maxlength="LIMITES.email"
          :error="errorEmail"
          :disabled="enviando"
          required
        />
        <CtButton type="submit" block size="lg" :loading="enviando" :disabled="enviando">
          Enviar enlace de recuperación
        </CtButton>
      </form>

      <div v-else class="recupera__acciones">
        <CtButton variant="secondary" type="button" @click="enviado = false">
          Usar otro correo
        </CtButton>
        <CtButton to="/login" type="button">Volver a iniciar sesión</CtButton>
      </div>

      <CtCard padding="sm">
        <div class="row">
          <span class="recupera__ayuda-icon" aria-hidden="true">
            <CtIcon name="info" :size="18" />
          </span>
          <strong>¿No te llega el correo?</strong>
        </div>
        <ul class="recupera__ayuda">
          <li v-for="a in ayuda" :key="a">{{ a }}</li>
        </ul>
      </CtCard>

      <p class="recupera__pie">
        ¿Recordaste la contraseña?
        <router-link to="/login">Vuelve a iniciar sesión</router-link>
      </p>
    </div>
  </AuthLayout>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.recupera__tabs {
  display: flex;
  gap: var(--ct-space-6);
  border-bottom: 1px solid var(--ct-border);
}

.recupera__envio a {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
}

.recupera__tab {
  padding-bottom: var(--ct-space-3);
  margin-bottom: -1px;
  border-bottom: 2px solid transparent;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
}

.recupera__tab:hover {
  color: var(--ct-text);
  text-decoration: none;
}

.recupera__tab.is-active {
  color: var(--ct-primary-strong);
  border-bottom-color: var(--ct-primary);
  font-weight: var(--ct-fw-semibold);
}

.recupera__acciones {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
  justify-content: center;
}

.recupera__fuerza {
  margin-top: calc(-1 * var(--ct-space-2));
}

.recupera__requisitos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
  gap: var(--ct-space-1) var(--ct-space-3);
  margin: 0;
  padding: 0;
  list-style: none;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.recupera__requisitos li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.recupera__requisitos li.is-ok {
  color: var(--ct-success);
}

.recupera__ayuda-icon {
  width: 32px;
  height: 32px;
  border-radius: var(--ct-radius-sm);
  display: grid;
  place-items: center;
  background: var(--ct-info-soft);
  color: var(--ct-info);
  flex-shrink: 0;
}

.recupera__ayuda {
  margin: var(--ct-space-3) 0 0;
  padding-left: var(--ct-space-5);
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.recupera__pie {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  text-align: center;
}

.recupera__pie a {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}
</style>
