<script setup>
/**
 * CuTuCo — Stepper de seguimiento del delivery (RF-025 y RF-007).
 *
 * Usa la máquina de hitos compartida de `lib/orders.js`:
 * Pago recibido → Preparación → En tránsito → Entregado. Cliente y vendedor
 * deben mostrar los mismos cuatro hitos base; cada rol agrega su información
 * propia fuera del stepper (HAL-VEN-030).
 *
 * HAL-CLI-010: el envío se crea al autorizarse el pago, pero «Preparación» sólo
 * se cierra cuando el vendedor confirma el hito (`envio.preparado_en`).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el paso "Finiquitado" y
 * la custodia/escrow salieron del alcance con Webpay Mall.
 */
import { computed } from 'vue'
import CtStepper from '@/components/base/CtStepper.vue'
import { ESTADO_ENVIO } from '@/lib/constants'
import { formatDateTime } from '@/lib/format'
import {
  estadoActualPedido,
  hitosPedido,
  motivoCancelacion,
  pasoActualPedido,
} from '@/lib/orders'

const props = defineProps({
  pedido: { type: Object, required: true },
  orientation: { type: String, default: 'horizontal' },
  tone: { type: String, default: 'primary' },
})

const envio = computed(() => props.pedido.envio ?? null)
const pago = computed(() => props.pedido.pago ?? null)

const estadoActual = computed(() => estadoActualPedido(props.pedido))
const cancelado = computed(() => estadoActual.value === 'cancelado')
const reclamado = computed(() => estadoActual.value === 'reclamado')
const fallido = computed(() => estadoActual.value === ESTADO_ENVIO.FALLIDO)
const pagoAutorizado = computed(() => Boolean(pago.value))
const motivoCancelado = computed(() => motivoCancelacion(props.pedido))

const pasos = computed(() =>
  hitosPedido(props.pedido).map((step) => {
    let description = step.description
    if (step.key === ESTADO_ENVIO.PREPARACION && envio.value?.preparado_en) {
      description = `Preparación confirmada el ${formatDateTime(envio.value.preparado_en)}`
    }
    if (step.key === ESTADO_ENVIO.EN_TRANSITO && envio.value?.codigo_verificado_en) {
      description = `Código validado por el vendedor el ${formatDateTime(envio.value.codigo_verificado_en)}`
    }
    if (step.failed) {
      description = envio.value?.motivo_fallo ?? 'Entrega fallida'
    }
    return {
      ...step,
      description,
      meta: step.meta ? formatDateTime(step.meta) : null,
    }
  }),
)

const current = computed(() => pasoActualPedido(props.pedido))
</script>

<template>
  <div class="ct-delivery">
    <CtStepper
      :steps="pasos"
      :current="current"
      :orientation="orientation"
      :tone="tone"
      :show-descriptions="true"
    />

    <p v-if="cancelado" class="ct-delivery__note is-danger texto-largo">
      El pedido fue cancelado{{ motivoCancelado ? `: ${motivoCancelado}` : '' }}. El inventario se
      repuso al catálogo y no hay acciones de entrega pendientes.
    </p>
    <p v-else-if="reclamado" class="ct-delivery__note is-warning texto-largo">
      El pedido tiene una constancia abierta. Coordina directamente con la otra parte fuera de
      CuTuCo; el registro no modifica el pago.
    </p>
    <p v-else-if="fallido" class="ct-delivery__note is-danger texto-largo">
      La entrega falló: {{ envio?.motivo_fallo || 'sin motivo registrado' }}. Coordina el caso
      directamente con la otra parte y usa esta constancia como respaldo.
    </p>
    <p v-else-if="pagoAutorizado" class="ct-delivery__note is-success texto-largo">
      El pago se confirmó con Webpay. El productor recibe el pago de su venta y CuTuCo descuenta su
      comisión.
    </p>
  </div>
</template>

<style scoped>
.ct-delivery {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
  min-width: 0;
}

.ct-delivery__note {
  font-size: var(--ct-fs-sm);
  padding: var(--ct-space-3);
  border-radius: var(--ct-radius-md);
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.ct-delivery__note.is-danger {
  background: var(--ct-danger-soft);
  color: var(--ct-danger-ink);
}

.ct-delivery__note.is-warning {
  background: var(--ct-warning-soft);
  color: var(--ct-warning-ink);
}

.ct-delivery__note.is-success {
  background: var(--ct-success-soft);
  color: var(--ct-success-ink);
}
</style>
