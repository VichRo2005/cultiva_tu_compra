<script setup>
/** CuTuCo — Selector de cantidad con límites. */
import { computed, ref, watch } from 'vue'
import { UNIDADES_FRACCIONABLES } from '@/lib/constants'

const props = defineProps({
  /**
   * La cantidad puede quedar vacía mientras se edita (CLI-PRO-017); la vista
   * que lo usa decide si permite agregar al carrito.
   */
  modelValue: { type: [Number, String, null], default: 1 },
  min: { type: Number, default: 1 },
  max: { type: Number, default: 99 },
  /** Paso explícito; si no se indica, se usa 1 y se respeta la precisión de la unidad. */
  step: { type: Number, default: null },
  /** Decimales visibles; si no se indican, se deducen de la unidad o del valor. */
  decimals: { type: Number, default: null },
  size: { type: String, default: 'md' }, // sm | md
  disabled: { type: Boolean, default: false },
  unit: { type: String, default: null },
  label: { type: String, default: 'Cantidad' },
})

const emit = defineEmits(['update:modelValue', 'change'])

const editando = ref(false)

const unidadFraccionable = computed(() =>
  UNIDADES_FRACCIONABLES.includes(String(props.unit ?? '').toLowerCase()),
)

/**
 * Precisión visible: explícita o deducida de la unidad comercial.
 * Las vistas de producto envían los decimales de su regla comercial. Cuando
 * no llega una regla explícita se conserva el fallback histórico de un decimal
 * para las unidades fraccionables.
 */
const decimales = computed(() => {
  if (props.decimals !== null && props.decimals !== undefined) {
    return Math.max(0, Number(props.decimals) || 0)
  }
  if (unidadFraccionable.value) return 1
  const n = Number(props.modelValue)
  return Number.isFinite(n) && !Number.isInteger(n) ? 1 : 0
})

const paso = computed(() => {
  const explicito = Number(props.step)
  return Number.isFinite(explicito) && explicito > 0 ? explicito : 1
})

const exigirPaso = computed(
  () => props.step !== null && props.step !== undefined && Number(props.step) > 0,
)

const texto = ref(formatear(props.modelValue))

const valorActual = computed(() => {
  if (props.modelValue === null || props.modelValue === undefined || props.modelValue === '') {
    return null
  }
  const n = Number(props.modelValue)
  return Number.isFinite(n) ? n : null
})

const puedeBajar = computed(
  () => !props.disabled && valorActual.value !== null && valorActual.value > props.min + 1e-9,
)
const puedeSubir = computed(() => {
  if (props.disabled) return false
  if (valorActual.value === null) return props.max >= props.min
  return valorActual.value < props.max - 1e-9
})

watch(
  () => props.modelValue,
  (valor) => {
    if (editando.value) return
    if (valor === null || valor === undefined || valor === '') {
      texto.value = ''
      return
    }
    const n = Number(valor)
    if (!Number.isFinite(n)) return
    texto.value = formatear(n)
  },
)

function formatear(valor) {
  const n = Number(valor)
  if (!Number.isFinite(n)) return ''
  return new Intl.NumberFormat('es-CL', {
    maximumFractionDigits: decimales.value,
    useGrouping: false,
  }).format(n)
}

function redondear(valor) {
  const factor = 10 ** decimales.value
  return Math.round((Number(valor) + Number.EPSILON) * factor) / factor
}

function esValorPermitido(n) {
  if (!Number.isFinite(n)) return false
  if (n + 1e-9 < props.min || n - 1e-9 > props.max) return false
  if (decimales.value === 0 && Math.abs(n - Math.round(n)) > 1e-9) return false
  if (exigirPaso.value) {
    const pasos = n / paso.value
    const multiplo = Math.abs(pasos - Math.round(pasos)) < 1e-6
    if (!multiplo) return false
  }
  return true
}

/**
 * `change` se emite sólo con valores válidos. Las vistas de carrito lo usan
 * para persistir la línea (un `null` la eliminaría); la ficha de producto usa
 * `update:modelValue` para deshabilitar la compra mientras la cantidad no sea
 * válida.
 */
function emitir(valor, { notificarCambio = true } = {}) {
  emit('update:modelValue', valor)
  if (notificarCambio) emit('change', valor)
}

function aplicarDelta(delta) {
  editando.value = false
  const base = valorActual.value ?? props.min
  const next = Math.min(props.max, Math.max(props.min, redondear(base + delta * paso.value)))
  texto.value = formatear(next)
  emitir(next)
}

function onInput(event) {
  editando.value = true
  const crudo = String(event.target.value ?? '')
  texto.value = crudo
  if (!crudo.trim()) {
    emitir(null, { notificarCambio: false })
    return
  }
  // La notación científica no puede usarse para evadir mínimo ni máximo.
  if (/[eE]/.test(crudo)) {
    emitir(null, { notificarCambio: false })
    return
  }
  const n = Number(crudo.replace(',', '.').replace(/\s/g, ''))
  if (!esValorPermitido(n)) {
    emitir(null, { notificarCambio: false })
    return
  }
  const redondeado = redondear(n)
  if (Math.abs(redondeado - n) > 1e-9) {
    emitir(null, { notificarCambio: false })
    return
  }
  emitir(redondeado)
}

function onBlur() {
  editando.value = false
  if (props.modelValue === null || props.modelValue === undefined || props.modelValue === '') {
    return
  }
  const n = Number(props.modelValue)
  if (Number.isFinite(n)) texto.value = formatear(n)
}
</script>

<template>
  <div class="ct-qty" :class="[`ct-qty--${size}`, { 'is-disabled': disabled }]">
    <button
      type="button"
      class="ct-qty__btn"
      :aria-label="`Restar ${formatear(paso)}${unit ? ` ${unit}` : ''}`"
      :disabled="disabled || !puedeBajar"
      @click="aplicarDelta(-1)"
    >
      −
    </button>
    <input
      class="ct-qty__input"
      type="text"
      :inputmode="decimals > 0 ? 'decimal' : 'numeric'"
      :value="texto"
      :disabled="disabled"
      :aria-label="label"
      @input="onInput"
      @blur="onBlur"
    />
    <button
      type="button"
      class="ct-qty__btn"
      :aria-label="`Sumar ${formatear(paso)}${unit ? ` ${unit}` : ''}`"
      :disabled="disabled || !puedeSubir"
      @click="aplicarDelta(1)"
    >
      +
    </button>
    <span v-if="unit" class="ct-qty__unit">{{ unit }}</span>
  </div>
</template>

<style scoped>
.ct-qty {
  display: inline-flex;
  align-items: center;
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  background: var(--ct-surface);
  overflow: hidden;
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-qty:focus-within {
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-qty.is-disabled {
  opacity: 0.6;
}

.ct-qty__btn {
  width: 34px;
  height: 38px;
  font-size: 1.1rem;
  color: var(--ct-text-soft);
  background: var(--ct-surface);
  transition: background-color var(--ct-transition);
}

.ct-qty--sm .ct-qty__btn {
  width: 28px;
  height: 30px;
  font-size: 1rem;
}

.ct-qty__btn:hover:not(:disabled) {
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.ct-qty__btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.ct-qty__input {
  width: 46px;
  height: 38px;
  border: none;
  border-inline: 1px solid var(--ct-border);
  text-align: center;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  background: var(--ct-surface);
  outline: none;
  -moz-appearance: textfield;
  appearance: textfield;
}

.ct-qty__input::-webkit-outer-spin-button,
.ct-qty__input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

.ct-qty--sm .ct-qty__input {
  width: 38px;
  height: 30px;
  font-size: var(--ct-fs-sm);
}

.ct-qty__unit {
  padding-inline: var(--ct-space-2);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}
</style>
