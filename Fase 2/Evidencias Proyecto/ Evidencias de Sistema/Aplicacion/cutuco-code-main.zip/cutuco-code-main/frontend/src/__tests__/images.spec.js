/**
 * CuTuCo — Imágenes placeholder generadas.
 * Verifica que los SVG sean XML válido y que cada familia de producto y cada
 * escena de despacho tenga su ilustración correspondiente.
 */
import { describe, expect, it } from 'vitest'
import { avatarImage, documentPlaceholder, escenaImage, paisajeImage, placeholderImage } from '@/lib/images'

function svgDe(dataUri) {
  const [, payload] = dataUri.split(',')
  return decodeURIComponent(payload)
}

function esXmlValido(svg) {
  const doc = new DOMParser().parseFromString(svg, 'image/svg+xml')
  return !doc.querySelector('parsererror')
}

const PRODUCTOS = [
  'Tomates Roma de Paine',
  'Lechugas Hidropónicas',
  'Papas Nuevas',
  'Miel Multifloral',
  'Uvas Thomson Seedless',
  'Naranjas Navel',
  'Queso Fresco de Tenca',
  'Zanahorias de Montaña',
  'Almendras Duchesel',
  'Mermelada de Frutilla',
  'Acelga Lombarda',
  'Berries Mixto',
]

describe('imágenes · validez del SVG', () => {
  it('genera XML válido para cada producto del catálogo demo', () => {
    for (const nombre of PRODUCTOS) {
      const url = placeholderImage(`seed-${nombre}`, nombre)
      expect(url.startsWith('data:image/svg+xml;utf8,')).toBe(true)
      const svg = svgDe(url)
      expect(esXmlValido(svg), `SVG inválido para ${nombre}`).toBe(true)
      expect(svg).toContain('<svg')
      expect(svg).toContain('</svg>')
    }
  })

  it('dibuja una ilustración distinta por familia de producto', () => {
    const tomate = svgDe(placeholderImage('a', 'Tomates Roma'))
    const hoja = svgDe(placeholderImage('b', 'Lechugas'))
    const miel = svgDe(placeholderImage('c', 'Miel Multifloral'))
    expect(tomate).toContain('url(#fruta)')
    expect(hoja).toContain('url(#hoja)')
    expect(miel).toContain('url(#miel)')
  })

  it('respeta el tamaño solicitado y no deja el contenedor vacío', () => {
    const url = placeholderImage('seed', 'Tomates de Paine', { size: [640, 480] })
    const svg = svgDe(url)
    expect(svg).toContain('width="640"')
    expect(svg).toContain('height="480"')
    expect(svg).toContain('<rect width="640" height="480"')
  })

  it('genera evidencias de armado y de entrega en destino', () => {
    for (const tipo of ['armado', 'entregado']) {
      const svg = svgDe(escenaImage(tipo, `envio-${tipo}`))
      expect(esXmlValido(svg), `SVG inválido para evidencia ${tipo}`).toBe(true)
      expect(svg).toContain(tipo === 'armado' ? 'Armado del pedido' : 'Entrega en destino')
    }
  })

  it('genera paisajes utilizables como fondo', () => {
    for (const tono of ['atardecer', 'amanecer']) {
      const svg = svgDe(paisajeImage('cutuco', { size: [1440, 640], tono }))
      expect(esXmlValido(svg)).toBe(true)
      expect(svg).toContain('width="1440"')
    }
  })

  it('genera avatar con iniciales y documento de identidad', () => {
    const avatar = svgDe(avatarImage('Ana González'))
    expect(esXmlValido(avatar)).toBe(true)
    expect(avatar).toContain('>AG<')

    for (const tipo of ['frente', 'dorso']) {
      const doc = svgDe(documentPlaceholder(tipo, 'Jorge Alarcón'))
      expect(esXmlValido(doc)).toBe(true)
      expect(doc).toContain(tipo.toUpperCase())
    }
  })

  it('es determinista: misma semilla produce la misma imagen', () => {
    expect(placeholderImage('x', 'Papas')).toBe(placeholderImage('x', 'Papas'))
    expect(escenaImage('armado', 'y')).toBe(escenaImage('armado', 'y'))
  })
})