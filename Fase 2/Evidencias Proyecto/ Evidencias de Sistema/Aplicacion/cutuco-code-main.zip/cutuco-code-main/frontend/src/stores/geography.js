/** CuTuCo — Store de geografía (regiones y comunas cacheadas para los formularios) */

import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { getJerarquiaGeografica, getComuna, getRegion } from '@/services/geography'

const STORAGE_REGION = 'cutuco:region'

function loadRegion() {
  try {
    return localStorage.getItem(STORAGE_REGION) ?? null
  } catch {
    return null
  }
}

export const useGeographyStore = defineStore('geography', () => {
  const regiones = ref([])
  const comunas = ref([])
  const cargando = ref(false)
  const error = ref(null)
  const cargado = ref(false)

  async function load({ force = false } = {}) {
    if (cargado.value && !force) return
    cargando.value = true
    error.value = null
    try {
      const jerarquia = await getJerarquiaGeografica()
      regiones.value = jerarquia.map(({ id, codigo, nombre }) => ({ id, codigo, nombre }))
      comunas.value = jerarquia.flatMap((r) => r.comunas)
      cargado.value = true
    } catch (e) {
      error.value = e.message
    } finally {
      cargando.value = false
    }
  }

  const regionesOrdenadas = computed(() =>
    [...regiones.value].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')),
  )

  function comunasDeRegion(regionId) {
    if (!regionId) return []
    return comunas.value.filter((c) => c.region_id === regionId).sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))
  }

  function nombreComuna(comunaId) {
    return comunas.value.find((c) => c.id === comunaId)?.nombre ?? '—'
  }

  function nombreRegion(regionId) {
    return regiones.value.find((r) => r.id === regionId)?.nombre ?? '—'
  }

  function regionDeComuna(comunaId) {
    return comunas.value.find((c) => c.id === comunaId)?.region_id ?? null
  }

  async function detalleComuna(comunaId) {
    if (comunas.value.some((c) => c.id === comunaId)) return getComuna(comunaId)
    return getComuna(comunaId)
  }

  async function detalleRegion(regionId) {
    return getRegion(regionId)
  }

  /* ------------------- región de trabajo (chip superior) ------------------- */

  const regionSeleccionadaId = ref(loadRegion())

  watch(regionSeleccionadaId, (value) => {
    try {
      if (value) localStorage.setItem(STORAGE_REGION, value)
      else localStorage.removeItem(STORAGE_REGION)
    } catch {
      /* almacenamiento no disponible */
    }
  })

  const regionSeleccionada = computed(
    () => regiones.value.find((r) => r.id === regionSeleccionadaId.value) ?? null,
  )

  function setRegionSeleccionada(regionId) {
    regionSeleccionadaId.value = regionId || null
  }

  return {
    regiones,
    comunas,
    cargando,
    error,
    cargado,
    regionesOrdenadas,
    load,
    comunasDeRegion,
    nombreComuna,
    nombreRegion,
    regionDeComuna,
    detalleComuna,
    detalleRegion,
    regionSeleccionadaId,
    regionSeleccionada,
    setRegionSeleccionada,
  }
})
