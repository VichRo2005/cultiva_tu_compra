/**
 * Integración real de Usuarios: SDK → GoTrue/PostgREST → RLS y triggers.
 * Usa únicamente cuentas de supabase/seed.sql. Sin mock ni fallback offline.
 * Solo Supabase local; cada cambio reversible del seed se restaura en finally.
 * La baja permanente se verifica en una transacción SQL con ROLLBACK.
 * Correr: npx vitest run admin-usuarios
 */
import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import process from 'node:process'
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '@/stores/auth.js'
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY, MISSING_ENV } from '@/lib/supabase.js'
import { listarUsuarios, obtenerDetalle, toggleActivo, eliminar } from '@/services/adminUsuarios.js'

const ADMIN_SEED_ID = 'a0000000-0000-0000-0000-000000000001'
const CLIENTE_ID = 'a0000000-0000-0000-0000-000000000002'
const VENDEDOR_ID = 'a0000000-0000-0000-0000-000000000104'
const cuentas = {
  admin: { email: 'cutuco.admin.base@example.test', password: 'CutucoTest!2026' },
  cliente: { email: 'cutuco.cliente.santiago@example.test', password: 'CutucoTest!2026' },
}
let disponible = false
async function iniciarSesion(rol) {
  // Cierra únicamente la sesión del test, conservando las del navegador.
  const { error } = await supabase.auth.signOut({ scope: 'local' })
  if (error) throw error
  const resultado = await supabase.auth.signInWithPassword(cuentas[rol])
  if (resultado.error) throw resultado.error
  return resultado.data.user
}

beforeAll(async () => {
  if (MISSING_ENV || !['localhost', '127.0.0.1', '[::1]'].includes(new URL(SUPABASE_URL).hostname))
    return
  let respuesta
  try {
    respuesta = await fetch(`${SUPABASE_URL}/rest/v1/regiones?select=id&limit=1`, {
      headers: { apikey: SUPABASE_ANON_KEY },
      signal: AbortSignal.timeout(2500),
    })
  } catch {
    return
  }
  if (!respuesta.ok)
    throw new Error(`Supabase local respondió ${respuesta.status}; revisa la configuración.`)
  disponible = true
})
beforeEach(async (contexto) => {
  if (!disponible)
    contexto.skip(
      true,
      'Requiere Supabase local disponible y frontend/.env.local; no se simula RLS.',
    )
  await iniciarSesion('admin')
})
afterAll(async () => {
  if (disponible) await supabase.auth.signOut({ scope: 'local' })
})

describe('integracion-supabase.admin-usuarios · PostgREST real', () => {
  it('el inicio sin sesión conserva el login existente y no autentica al administrador', async () => {
    await supabase.auth.signOut({ scope: 'local' })
    setActivePinia(createPinia())
    const auth = useAuthStore()
    try {
      await auth.init()
      expect(auth.user).toBeNull()
      expect(auth.isAuthenticated).toBe(false)
      expect(auth.isAdmin).toBe(false)
    } finally {
      auth.detenerEscucha()
      await auth.signOut()
    }
  })

  it('admin obtiene conteo global y páginas sin duplicados', async () => {
    const primera = await listarUsuarios({ pageSize: 3 })
    const segunda = await listarUsuarios({ page: 2, pageSize: 3 })
    expect(primera.total).toBeGreaterThanOrEqual(7)
    expect(segunda.total).toBe(primera.total)
    expect(primera.items).toHaveLength(3)
    expect(segunda.items).toHaveLength(3)
    expect(new Set([...primera.items, ...segunda.items].map((p) => p.id)).size).toBe(6)
  })

  it('combina búsqueda, rol y activo en servidor', async () => {
    const original = await obtenerDetalle(CLIENTE_ID)
    const resultado = await listarUsuarios({
      texto: 'Santiago',
      rol: 'cliente',
      activo: original.activo,
    })
    expect(resultado.items.map((p) => p.id)).toContain(CLIENTE_ID)
    expect(resultado.items.every((p) => p.rol === 'cliente' && p.activo === original.activo)).toBe(
      true,
    )
    const literal = await listarUsuarios({ texto: '",rol.eq.admin)_*%' })
    expect(literal.total).toBe(0)
    expect(literal.items).toEqual([])
  })

  it('consulta al productor inactivo como admin y conserva las protecciones del seed', async () => {
    const admin = await obtenerDetalle(ADMIN_SEED_ID)
    expect(admin).toMatchObject({
      rol: 'admin',
      activo: true,
      es_protegido: true,
      es_super_admin: true,
      productor: null,
    })
    const vendedor = await obtenerDetalle(VENDEDOR_ID)
    expect(vendedor).toMatchObject({
      rol: 'vendedor',
      productor: { perfil_id: VENDEDOR_ID, activo: false },
    })
  })

  it('activa/desactiva mediante el service y restaura el estado original', async () => {
    const original = await obtenerDetalle(CLIENTE_ID)
    try {
      expect(await toggleActivo(CLIENTE_ID)).toMatchObject({ activo: !original.activo })
      const filtrados = await listarUsuarios({ texto: 'Santiago', activo: !original.activo })
      expect(filtrados.items.map((p) => p.id)).toContain(CLIENTE_ID)
    } finally {
      const actual = await obtenerDetalle(CLIENTE_ID)
      if (actual.activo !== original.activo) await toggleActivo(CLIENTE_ID)
    }
    expect((await obtenerDetalle(CLIENTE_ID)).activo).toBe(original.activo)
  })

  it('el service frontend rechaza mutaciones de vendedores y conserva perfil y productor', async () => {
    const original = await obtenerDetalle(VENDEDOR_ID)
    await expect(toggleActivo(VENDEDOR_ID)).rejects.toThrow('solo para clientes')
    await expect(eliminar(VENDEDOR_ID)).rejects.toThrow('solo para clientes')
    const actual = await obtenerDetalle(VENDEDOR_ID)
    expect(actual.activo).toBe(original.activo)
    expect(actual.eliminado_en).toBe(original.eliminado_en)
    expect(actual.productor.activo).toBe(original.productor.activo)
  })

  it('rechaza cambios de estado y baja del administrador protegido', async () => {
    await expect(toggleActivo(ADMIN_SEED_ID)).rejects.toThrow('cuenta protegida')
    await expect(eliminar(ADMIN_SEED_ID)).rejects.toThrow('cuenta protegida')
    const { error } = await supabase
      .from('perfiles')
      .update({ activo: false })
      .eq('id', ADMIN_SEED_ID)
      .select('id')
    expect(error).not.toBeNull()
    expect((await obtenerDetalle(ADMIN_SEED_ID)).activo).toBe(true)
  })

  it('la BD audita y bloquea la reversión de la baja permanente sin alterar el seed', () => {
    const sql = readFileSync(
      resolve(process.cwd(), '../supabase/snippets/admin_usuarios_verificacion.sql'),
      'utf8',
    )
    const resultado = execFileSync(
      'docker',
      [
        'exec',
        '-i',
        process.env.CUTUCO_TEST_DB_CONTAINER || 'supabase_db_cutuco-code',
        'psql',
        '-X',
        '-q',
        '-v',
        'ON_ERROR_STOP=1',
        '-U',
        'postgres',
        '-d',
        'postgres',
      ],
      { input: sql, encoding: 'utf8', timeout: 15000 },
    )
    expect(resultado).not.toContain('ERROR')
  })
  it('RLS restringe SELECT del cliente a su perfil y el trigger impide autoescalamiento', async () => {
    await iniciarSesion('cliente')
    const resultado = await listarUsuarios()
    expect(resultado.items.map((p) => p.id)).toEqual([CLIENTE_ID])
    expect(resultado.total).toBe(1)
    expect(await obtenerDetalle(ADMIN_SEED_ID)).toBeNull()
    await expect(toggleActivo(ADMIN_SEED_ID)).rejects.toThrow('El perfil no existe')
    const { error } = await supabase
      .from('perfiles')
      .update({ rol: 'admin' })
      .eq('id', CLIENTE_ID)
      .select('id')
    expect(error).not.toBeNull()
    expect((await obtenerDetalle(CLIENTE_ID)).rol).toBe('cliente')
  })

  it('un visitante no puede leer perfiles por PostgREST', async () => {
    await supabase.auth.signOut({ scope: 'local' })
    const { data, error } = await supabase.from('perfiles').select('id')
    expect(error !== null || data?.length === 0).toBe(true)
  })
})
