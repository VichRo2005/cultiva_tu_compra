<script setup>
/**
 * CuTuCo — Historial de pedidos del cliente (página 8 del diseño oficial).
 *
 * `listPedidos` no acepta texto ni rango de fechas y tampoco hidrata
 * `perfiles`, así que la vista trae el listado completo y filtra en cliente
 * por código de pedido, destinatario y productor.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtToggle from '@/components/base/CtToggle.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { exportExcel } from '@/lib/csv'
import { ESTADO_ENVIO, ESTADO_PAGO, ESTADO_PEDIDO, LABELS } from '@/lib/constants'
import { formatCLP, formatDate, formatNumber, pluralize } from '@/lib/format'
import {
  estadoActualPedido,
  etiquetaEstadoActual,
  OPCIONES_ESTADO_ACTUAL,
  pedidoCoincideEstado,
  tonoEstadoActual,
} from '@/lib/orders'
import { listPedidos } from '@/services/orders'
import { useCartStore } from '@/stores/cart'
import { useUiStore } from '@/stores/ui'

/** El servicio corta la paginación en el servidor: pedimos el listado completo. */
const PAGE_SIZE_MAX = 500
const PAGE_SIZE = 10

const route = useRoute()
const router = useRouter()
const cart = useCartStore()
const ui = useUiStore()

const pedidos = ref([])
const cargando = ref(true)
const error = ref(null)

const busqueda = ref(String(route.query.q ?? ''))
const estado = ref(String(route.query.estado ?? ''))
const soloReclamos = ref(route.query.reclamos === '1')
const mostrarFiltros = ref(false)
const pagina = ref(Number(route.query.pagina ?? 1) || 1)
const pageSize = ref(PAGE_SIZE)

const columns = [
  { key: 'codigo_pedido', label: 'ID Pedido', width: '170px' },
  { key: 'creado_en', label: 'Fecha', width: '130px' },
  { key: 'nombre_destinatario', label: 'Cliente' },
  { key: 'detalles', label: 'Ítems', width: '110px' },
  { key: 'total', label: 'Monto Total', align: 'right', width: '140px' },
  { key: 'estado', label: 'Estado', width: '180px' },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '120px' },
]

const opcionesEstado = computed(() => [
  { value: '', label: 'Todos los estados' },
  ...OPCIONES_ESTADO_ACTUAL,
])

/* ----------------------------- filtros cliente --------------------------- */

const filtrados = computed(() => {
  const term = busqueda.value.trim().toLowerCase()
  return pedidos.value.filter((pedido) => {
    if (soloReclamos.value && estadoActualPedido(pedido) !== ESTADO_PEDIDO.RECLAMADO) return false
    // El filtro usa el estado actual único compartido con el vendedor: así
    // "En tránsito" y "Entrega fallida" existen también para el cliente.
    if (!pedidoCoincideEstado(pedido, estado.value || null)) return false
    if (!term) return true
    return [pedido.codigo_pedido, pedido.nombre_destinatario, pedido.productor?.nombre_comercial]
      .filter(Boolean)
      .some((campo) => String(campo).toLowerCase().includes(term))
  })
})

const visibles = computed(() => {
  const inicio = (pagina.value - 1) * pageSize.value
  return filtrados.value.slice(inicio, inicio + pageSize.value)
})

/* ------------------------------- tarjetas ------------------------------- */

const conteos = computed(() => {
  const items = pedidos.value
  const actuales = items.map((p) => estadoActualPedido(p))
  return {
    completados: actuales.filter((estado) => estado === ESTADO_PEDIDO.COMPLETADO).length,
    enRuta: actuales.filter((estado) => estado === ESTADO_ENVIO.EN_TRANSITO).length,
    // "Pendientes" son pagados o en preparación; los pedidos sólo creados aún
    // no tienen pago autorizado.
    pendientes: actuales.filter((estado) =>
      [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(estado),
    ).length,
    pagosAutorizados: items.filter((p) => p.pago?.estado === ESTADO_PAGO.AUTORIZADO).length,
  }
})

const hayFiltros = computed(
  () => Boolean(busqueda.value.trim()) || Boolean(estado.value) || soloReclamos.value,
)

function limpiarFiltros() {
  busqueda.value = ''
  estado.value = ''
  soloReclamos.value = false
  pagina.value = 1
}

function cantidadItems(pedido) {
  return (pedido.detalles ?? []).reduce((acc, d) => acc + Number(d.cantidad), 0)
}

/** Los filtros y la paginación se resuelven en cliente sobre el listado completo. */
function irAPaginaUno() {
  pagina.value = 1
}

/* --------------------------------- datos -------------------------------- */

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const resultado = await listPedidos({
      rol: 'cliente',
      page: 1,
      pageSize: PAGE_SIZE_MAX,
    })
    pedidos.value = resultado.items
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron cargar tus pedidos'
  } finally {
    cargando.value = false
  }
}

async function exportar() {
  const ok = await exportExcel(filtrados.value, 'cutuco-pedidos', [
    { label: 'ID Pedido', get: (p) => p.codigo_pedido },
    { label: 'Fecha', get: (p) => formatDate(p.creado_en) },
    { label: 'Cliente', get: (p) => p.nombre_destinatario },
    { label: 'Productor', get: (p) => p.productor?.nombre_comercial ?? '' },
    { label: 'Ítems', get: (p) => cantidadItems(p) },
    { label: 'Monto Total', get: (p) => p.total },
    {
      label: 'Estado',
      get: (p) => etiquetaEstadoActual(estadoActualPedido(p)) ?? p.estado,
    },
    {
      label: 'Estado Pago',
      get: (p) => (p.pago ? (LABELS.pago[p.pago.estado] ?? p.pago.estado) : ''),
    },
  ])
  if (!ok) {
    ui.warning('Sin datos para exportar', 'Ajusta los filtros o espera tu primer pedido')
  }
}

function verDetalle(pedido) {
  router.push(`/cliente/pedidos/${pedido.id}`)
}

let ignorarSync = false

/** Compara el query deseado con el de la URL para no disparar navegaciones vacías. */
function mismoQuery(a, b) {
  const claves = new Set([...Object.keys(a), ...Object.keys(b)])
  for (const clave of claves) {
    if (String(a[clave] ?? '') !== String(b[clave] ?? '')) return false
  }
  return true
}

function sincronizarUrl() {
  const query = {}
  if (busqueda.value.trim()) query.q = busqueda.value.trim()
  if (estado.value) query.estado = estado.value
  if (soloReclamos.value) query.reclamos = '1'
  if (pagina.value > 1) query.pagina = String(pagina.value)
  if (mismoQuery(query, route.query)) return
  ignorarSync = true
  router.replace({ query })
}

watch([busqueda, estado, soloReclamos], () => {
  // Un filtro nuevo vuelve a la primera página para no mostrar una página vacía.
  if (pagina.value !== 1) pagina.value = 1
})

watch([busqueda, estado, soloReclamos, pagina, pageSize], () => {
  sincronizarUrl()
})

onMounted(cargar)

watch(
  () => route.query,
  (query) => {
    if (ignorarSync) {
      ignorarSync = false
      return
    }
    busqueda.value = String(query.q ?? '')
    estado.value = String(query.estado ?? '')
    soloReclamos.value = query.reclamos === '1'
    pagina.value = Number(query.pagina ?? 1) || 1
  },
)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Historial de Pedidos</h1>
        <p class="page-head__subtitle">
          {{ pedidos.length }} {{ pluralize(pedidos.length, 'pedido', 'pedidos') }} ·
          {{ filtrados.length }} visibles con los filtros aplicados.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="!filtrados.length" @click="exportar">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton to="/catalogo">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Nuevo Pedido
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar tus pedidos">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <div class="grid-kpi">
      <CtStatCard
        label="Completados"
        :value="conteos.completados"
        tone="success"
        hint="Entregados y confirmados"
      />
      <CtStatCard label="En Ruta" :value="conteos.enRuta" tone="info" hint="Envíos en tránsito" />
      <CtStatCard
        label="Pendientes"
        :value="conteos.pendientes"
        tone="warning"
        hint="Pagados o en preparación"
      />
      <CtStatCard
        label="Pagos autorizados"
        :value="conteos.pagosAutorizados"
        tone="primary"
        hint="Compras autorizadas por Webpay"
      />
    </div>

    <CtCard padding="md">
      <div class="filtros">
        <CtSearchInput
          v-model="busqueda"
          placeholder="Buscar por código de pedido, destinatario o productor"
          @search="irAPaginaUno"
        />
        <div class="filtros__acciones">
          <CtButton
            variant="secondary"
            :class="{ 'is-active': mostrarFiltros }"
            @click="mostrarFiltros = !mostrarFiltros"
          >
            <template #icon><CtIcon name="filter" :size="16" /></template>
            Y Filtros Avanzados
          </CtButton>
          <CtButton v-if="hayFiltros" variant="ghost" size="sm" @click="limpiarFiltros">
            Limpiar todo
          </CtButton>
        </div>
      </div>

      <div v-if="mostrarFiltros" class="filtros__avanzados">
        <CtSelect
          v-model="estado"
          label="Estado del pedido"
          :options="opcionesEstado"
          clearable
          @change="irAPaginaUno"
        />
        <CtToggle
          v-model="soloReclamos"
          label="Solo pedidos con reclamo"
          description="Filtra los pedidos con una constancia abierta para que puedas coordinarlos con el productor."
        />
      </div>
    </CtCard>

    <CtAlert tone="info" compact title="Sobre los pagos y comprobantes">
      <p class="linea">
        <CtIcon name="info" :size="15" />
        <span>
          El indicador cuenta pagos autorizados por Webpay. CuTuCo no emite factura electrónica: el
          productor genera el documento y el comprobante disponible es el detalle de cada pedido,
          que puedes exportar en Excel o revisar desde la tabla.
        </span>
      </p>
    </CtAlert>

    <CtSpinner v-if="cargando" label="Cargando tu historial" />

    <template v-else>
      <CtTable
        :columns="columns"
        :rows="visibles"
        empty-icon=""
        empty-title="Todavía no tienes pedidos"
        empty-message="Cuando confirmes tu primera compra aparecerá aquí con su seguimiento."
        clickable
        row-key="id"
        min-width="900px"
        @row-click="verDetalle"
      >
        <template #empty-action>
          <CtButton to="/catalogo">
            <template #icon><CtIcon name="catalog" :size="16" /></template>
            Ir al catálogo
          </CtButton>
        </template>

        <template #cell-codigo_pedido="{ row }">
          <span class="mono font-semibold">{{ row.codigo_pedido }}</span>
        </template>

        <template #cell-creado_en="{ row }">
          {{ formatDate(row.creado_en) }}
        </template>

        <template #cell-nombre_destinatario="{ row }">
          <div class="stack stack--xs">
            <span class="font-semibold">{{ row.nombre_destinatario || '—' }}</span>
            <span class="text-xs text-muted">
              {{ row.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
            </span>
          </div>
        </template>

        <template #cell-detalles="{ row }">
          <span class="text-sm">
            {{ (row.detalles ?? []).length }}
            {{ pluralize((row.detalles ?? []).length, 'producto') }} ·
            {{
              (row.detalles ?? [])
                .map(
                  (d) =>
                    `${formatNumber(d.cantidad)} ${LABELS.unidad[d.unidad] ?? d.unidad ?? 'unidad'}`,
                )
                .join(', ')
            }}
          </span>
        </template>

        <template #cell-total="{ row }">
          <span class="font-semibold">{{ formatCLP(row.total) }}</span>
        </template>

        <template #cell-estado="{ row }">
          <div class="row row--wrap">
            <CtBadge :tone="tonoEstadoActual(estadoActualPedido(row))" size="sm">
              {{ etiquetaEstadoActual(estadoActualPedido(row)) }}
            </CtBadge>
            <StatusBadge v-if="row.pago" type="pago" :value="row.pago.estado" size="sm" />
          </div>
        </template>

        <template #cell-acciones="{ row }">
          <CtButton size="sm" variant="outline" @click.stop="verDetalle(row)">Detalles</CtButton>
        </template>
      </CtTable>

      <CtPagination
        :page="pagina"
        :total="filtrados.length"
        :page-size="pageSize"
        label="pedidos"
        @update:page="pagina = $event"
        @update:page-size="pageSize = $event"
      />
    </template>

    <CtAlert v-if="cart.totalItems" tone="info" compact>
      <p class="linea">
        <CtIcon name="cart" :size="15" />
        <span>Tienes {{ cart.totalItems }} unidades en el carrito listas para pagar.</span>
      </p>
      <CtButton size="sm" variant="secondary" to="/carrito">Ir al carrito</CtButton>
    </CtAlert>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.filtros {
  display: flex;
  align-items: flex-end;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.filtros > :first-child {
  flex: 1 1 280px;
}

.filtros__acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.filtros__acciones .is-active {
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.filtros__avanzados {
  display: grid;
  grid-template-columns: minmax(200px, 280px) minmax(0, 1fr);
  gap: var(--ct-space-5);
  align-items: end;
  margin-top: var(--ct-space-5);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
}

@media (max-width: 720px) {
  .filtros__avanzados {
    grid-template-columns: minmax(0, 1fr);
  }
}

/* HAL-VEN-027: nombres, códigos y textos largos no deben desbordar la tabla. */
:deep(.ct-table td) {
  overflow-wrap: anywhere;
  word-break: break-word;
  min-width: 0;
}
</style>
