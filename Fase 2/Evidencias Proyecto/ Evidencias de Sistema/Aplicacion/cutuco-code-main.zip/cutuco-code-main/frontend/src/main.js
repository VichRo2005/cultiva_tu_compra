import { createApp } from 'vue'
import { createPinia } from 'pinia'

import '@/styles/tokens.css'
import '@/styles/base.css'
import '@/styles/utilities.css'

import App from './App.vue'
import router from './router'
import { prepararCliente } from '@/lib/supabase'

/**
 * Arranque: primero se decide la fuente de datos (Supabase real o, si no
 * responde, el modo demostración offline) y sólo después se monta la aplicación.
 * Así ninguna vista alcanza a consultar con el cliente equivocado.
 */
async function arrancar() {
  await prepararCliente()

  const app = createApp(App)
  app.use(createPinia())
  app.use(router)
  app.mount('#app')
}

arrancar()

