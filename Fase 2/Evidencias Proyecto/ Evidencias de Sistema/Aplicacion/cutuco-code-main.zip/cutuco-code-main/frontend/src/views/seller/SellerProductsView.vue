<script setup>
/**
 * CuTuCo — Gestión de inventario del productor (página 12 del diseño).
 *
 *   RF-003  listado real de productos del vendedor con su stock y categoría
 *   RF-017  baja lógica (`desactivarProducto`) y reactivación
 *   RF-018  filtro por categoría con el nombre real de la tabla relacionada
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Esta vista usaba `listMisProductos`, `toggleProductoActivo`, `eliminarProducto`
 *   y `getMiProducto(...).historial`: alertas de stock bajo con umbral (RF-010),
 *   sugerencia de precios con historial de mercado (RF-008) y "eliminación"
 *   física. Todo eso salió del alcance: el stock se revisa a mano, no hay
 *   historial de precios y la baja es lógica (`activo = false`, RF-017). Los
 *   accesos rápidos a `/vendedor/alertas-stock`, `/vendedor/evidencias` y
 *   `/vendedor/reputacion` también se retiraron porque esas pantallas ya no
 *   existen en el alcance vigente.
 */
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import { ESTADO_POSTULACION, LABELS } from '@/lib/constants'
import { exportExcel } from '@/lib/csv'
import { formatCLP, formatDate, formatNumber, formatRelative } from '@/lib/format'
import { validate } from '@/lib/validation'
import { useAsync, useDebounceFn } from '@/composables/useAsync'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import {
  filtrarCategoriasVisibles,
  formatearCantidad,
  listCategorias,
  normalizarNombreCategoria,
} from '@/services/catalog'
import {
  actualizarStock,
  desactivarProducto,
  eliminarProductoVendedor,
  getMiPostulacion,
  getMiProductor,
  LIMITES_PRODUCTO,
  listProductosVendedor,
  MOTIVO_PAUSA_POR_DEFECTO,
  MOTIVO_PRODUCTO_MAX,
  reactivarProducto,
  validarMotivoProducto,
} from '@/services/seller'

const router = useRouter()
const ui = useUiStore()
const auth = useAuthStore()

const ESTADOS_ORDEN = [
  { value: 'recientes', label: 'Más recientes' },
  { value: 'nombre', label: 'Nombre (A-Z)' },
  { value: 'precio_desc', label: 'Mayor precio' },
  { value: 'precio_asc', label: 'Menor precio' },
  { value: 'stock_asc', label: 'Menor stock' },
  { value: 'actualizado', label: 'Actualización reciente' },
]

const texto = ref('')
const busqueda = ref('')
const estado = ref('todos')
const categoriaId = ref(null)
const unidad = ref(null)
const fechaCosecha = ref('')
const orden = ref('recientes')
const sortKey = ref(null)
const sortAsc = ref(true)
const mostrarFiltros = ref(false)
const page = ref(1)
const pageSize = ref(6)

/** Edición rápida de stock (RF-003): sólo un producto a la vez. */
const stockEnEdicion = ref(null)
const stockValor = ref(0)
const stockError = ref(null)
const guardandoStock = ref(false)

/** Cambio de estado del producto: baja lógica o reactivación (RF-017). */
const porDesactivar = ref(null)
const confirmDesactivar = ref(false)
const cambiandoEstado = ref(false)
const motivoDesactivacion = ref(MOTIVO_PAUSA_POR_DEFECTO)
const errorMotivo = ref(null)

/** Eliminación lógica de producto (HAL-VEN-013/014): no se puede restaurar. */
const porEliminar = ref(null)
const confirmEliminar = ref(false)
const eliminando = ref(false)
const motivoEliminacion = ref(MOTIVO_PAUSA_POR_DEFECTO)
const errorEliminacion = ref(null)

/** Detalle de sólo lectura (HAL-VEN-013): no abre el formulario de edición. */
const detalleProducto = ref(null)

const { data, loading, error, run } = useAsync(async () => {
  const [productorApi, postulacion, categorias] = await Promise.all([
    getMiProductor(),
    getMiPostulacion(),
    listCategorias().catch(() => []),
  ])
  // Si la consulta puntual no devuelve la tienda pero la sesión ya la tiene,
  // se usa la del store para no ocultar el inventario real (mismo criterio que
  // el dashboard). Un error de red no cae aquí: useAsync lo muestra.
  const productor = productorApi ?? auth.productor ?? null
  const productos = productor?.id
    ? await listProductosVendedor({
        productorId: productor.id,
        incluirInactivos: true,
        texto: busqueda.value,
      })
    : []
  return { productor, postulacion, categorias, productos }
})

const buscar = useDebounceFn((valor) => {
  busqueda.value = valor
  page.value = 1
  run()
}, 350)

function filtrar() {
  page.value = 1
  run()
}

const productor = computed(() => data.value?.productor ?? auth.productor ?? null)
const postulacion = computed(() => data.value?.postulacion ?? auth.postulacion ?? null)
const productos = computed(() => data.value?.productos ?? [])
const hayTienda = computed(() => Boolean(productor.value))

const categoriasPorId = computed(
  () => new Map((data.value?.categorias ?? []).map((c) => [c.id, c.nombre])),
)

/**
 * Árbol de categorías padre → hijos para mostrar jerarquía en el filtro
 * (HAL-VEN-006). `filtrarCategoriasVisibles` normaliza "Sin categoría"/
 * "Sin Categoría", elimina duplicados y quita las fuera de alcance.
 */
const categoriasArbol = computed(() => {
  const lista = data.value?.categorias ?? []
  const porId = new Map(lista.map((c) => ({ ...c, hijos: [] })))
  const raices = []
  for (const c of lista) {
    const nodo = porId.get(c.id)
    const padreId = c.categoria_padre_id ?? c.parent_id
    if (padreId && porId.has(padreId)) {
      porId.get(padreId).hijos.push(nodo)
    } else {
      raices.push(nodo)
    }
  }
  return filtrarCategoriasVisibles(raices)
})

/** Opciones de categoría a partir de las categorías realmente usadas en los
 *  productos del vendedor (así el filtro nunca omite una que aparezca en la
 *  tabla), más "Sin categoría" para los productos sin asignar. */
const opcionesCategoria = computed(() => {
  const opciones = [{ value: 'sin_categoria', label: 'Sin categoría' }]
  const idsVistos = new Set()
  for (const p of productos.value) {
    if (!p.categoria_id || idsVistos.has(p.categoria_id)) continue
    idsVistos.add(p.categoria_id)
    const nombre = categoriasPorId.value.get(p.categoria_id) ?? 'Categoría no disponible'
    opciones.push({ value: p.categoria_id, label: normalizarNombreCategoria(nombre) })
  }
  opciones.sort((a, b) => a.label.localeCompare(b.label, 'es'))
  return opciones
})

/** La cuenta sólo opera con la postulación aprobada y la tienda activa (RF-021). */
const puedeOperar = computed(
  () =>
    Boolean(auth.puedeOperarTienda) &&
    Boolean(productor.value?.activo) &&
    postulacion.value?.estado === ESTADO_POSTULACION.APROBADA &&
    !auth.bloqueoVendedor,
)

const opcionesUnidad = computed(() => {
  const usadas = new Set(productos.value.map((p) => p.unidad_medida).filter(Boolean))
  return [...usadas].map((valor) => ({ value: valor, label: LABELS.unidad[valor] ?? valor }))
})

/** Click en el header de una columna ordenable: alterna asc/desc. */
function ordenarPor(key) {
  if (sortKey.value === key) {
    sortAsc.value = !sortAsc.value
  } else {
    sortKey.value = key
    sortAsc.value = true
  }
  page.value = 1
}

/** Filtros y orden aplicados en el cliente sobre el resultado del servicio. */
const catalogo = computed(() => {
  let items = productos.value
  if (estado.value === 'activos') items = items.filter((p) => p.activo && !p.eliminado_en)
  if (estado.value === 'inactivos') items = items.filter((p) => !p.activo && !p.eliminado_en)
  if (estado.value === 'sin_stock') items = items.filter((p) => p.activo && Number(p.stock) <= 0)
  if (categoriaId.value === 'sin_categoria') items = items.filter((p) => !p.categoria_id)
  else if (categoriaId.value) items = items.filter((p) => p.categoria_id === categoriaId.value)
  if (unidad.value) items = items.filter((p) => p.unidad_medida === unidad.value)
  if (fechaCosecha.value)
    items = items.filter((p) => String(p.fecha_cosecha ?? '') === fechaCosecha.value)

  const ordenes = {
    recientes: (a, b) => new Date(b.creado_en ?? 0) - new Date(a.creado_en ?? 0),
    nombre: (a, b) => String(a.nombre).localeCompare(String(b.nombre), 'es'),
    precio_desc: (a, b) => Number(b.precio) - Number(a.precio),
    precio_asc: (a, b) => Number(a.precio) - Number(b.precio),
    stock_asc: (a, b) => Number(a.stock) - Number(b.stock),
    actualizado: (a, b) => new Date(b.actualizado_en ?? 0) - new Date(a.actualizado_en ?? 0),
  }
  // El click en el header de la tabla tiene prioridad sobre el select "Ordenar por".
  if (sortKey.value) {
    const dir = sortAsc.value ? 1 : -1
    const porClave = {
      stock: (a, b) => (Number(a.stock) - Number(b.stock)) * dir,
      precio: (a, b) => (Number(a.precio) - Number(b.precio)) * dir,
      estado: (a, b) =>
        String(estadoProducto(a).label).localeCompare(String(estadoProducto(b).label), 'es') * dir,
    }
    return [...items].sort(porClave[sortKey.value])
  }
  return [...items].sort(ordenes[orden.value] ?? ordenes.recientes)
})

const tabItems = computed(() => [
  { value: 'todos', label: 'Todos', count: productos.value.length },
  {
    value: 'activos',
    label: 'Publicados',
    count: productos.value.filter((p) => p.activo && !p.eliminado_en).length,
  },
  {
    value: 'inactivos',
    label: 'Desactivados',
    count: productos.value.filter((p) => !p.activo && !p.eliminado_en).length,
  },
  {
    value: 'sin_stock',
    label: 'Sin stock',
    count: productos.value.filter((p) => p.activo && Number(p.stock) <= 0).length,
  },
])

const indicadores = computed(() => {
  const items = productos.value.filter((p) => !p.eliminado_en)
  const publicados = items.filter((p) => p.activo)
  const ultima = items.reduce(
    (max, p) => (new Date(p.actualizado_en ?? 0) > new Date(max) ? p.actualizado_en : max),
    0,
  )
  return {
    total: items.length,
    publicados: publicados.length,
    desactivados: items.length - publicados.length,
    stockTotal: publicados.reduce((acc, p) => acc + Number(p.stock ?? 0), 0),
    sinStock: publicados.filter((p) => Number(p.stock) <= 0).length,
    actualizacion: ultima || null,
  }
})

const visibles = computed(() =>
  catalogo.value.slice((page.value - 1) * pageSize.value, page.value * pageSize.value),
)

const columnas = [
  { key: 'imagen', label: 'Imagen', width: '104px' },
  { key: 'producto', label: 'Producto', width: '22%' },
  { key: 'categoria', label: 'Categoría', width: '110px' },
  { key: 'referencia', label: 'Referencia', width: '100px' },
  { key: 'stock', label: 'Stock', align: 'right', width: '150px', sortable: true },
  { key: 'precio', label: 'Precio', align: 'right', width: '130px', sortable: true },
  { key: 'estado', label: 'Estado', width: '170px', sortable: true },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '240px' },
]

function unidades(producto) {
  return LABELS.unidad[producto?.unidad_medida] ?? producto?.unidad_medida ?? ''
}

function nombreCategoria(producto) {
  if (!producto?.categoria_id) return 'Sin categoría'
  return categoriasPorId.value.get(producto.categoria_id) ?? 'Categoría no disponible'
}

/** Código comercial estable del producto (PRD-000001, migración 20261022000000). */
function referencia(producto) {
  if (producto.codigo_producto) return producto.codigo_producto
  // Modo demostración (dataset sin la columna): conserva el formato anterior.
  return `CTC-${String(producto.id).slice(-6).toUpperCase()}`
}

function estadoProducto(producto) {
  if (producto.eliminado_en) return { tone: 'neutral', label: 'Eliminado' }
  if (!producto.activo) return { tone: 'warning', label: 'Pausado' }
  if (Number(producto.stock) <= 0) return { tone: 'danger', label: 'Sin stock' }
  return { tone: 'success', label: 'Publicado' }
}

/**
 * Justificación vigente del producto (HAL-VEN-015). El trigger de BD limpia
 * `motivo_pausa` al publicar y `motivo_eliminacion` al reactivar; por eso basta
 * con leer la columna que corresponda al estado actual.
 */
function justificacionProducto(producto) {
  if (!producto) return null
  if (producto.eliminado_en) return producto.motivo_eliminacion || null
  if (!producto.activo) return producto.motivo_pausa || null
  return null
}

function abrirDetalle(producto) {
  detalleProducto.value = producto
}

function cerrarDetalle() {
  detalleProducto.value = null
}

function editarDesdeDetalle(producto) {
  const id = producto?.id
  cerrarDetalle()
  if (id) router.push(`/vendedor/productos/${id}/editar`)
}

/* ------------------------------------------------------------------ */
/* Edición rápida de stock (RF-003)                                    */
/* ------------------------------------------------------------------ */

function editarStock(producto) {
  stockEnEdicion.value = producto.id
  stockValor.value = Number(producto.stock ?? 0)
  stockError.value = null
}

function cancelarStock() {
  stockEnEdicion.value = null
  stockError.value = null
}

async function guardarStock(producto) {
  stockError.value = null
  const { valid, errors } = validate(
    { stock: stockValor.value },
    {
      stock: {
        required: true,
        nonNegative: true,
        custom: (valor) => {
          const stock = Number(valor)
          if (!Number.isFinite(stock) || Math.abs(stock - Math.round(stock * 10) / 10) > 1e-9) {
            return 'El stock puede tener como máximo un decimal.'
          }
          return stock > LIMITES_PRODUCTO.stockMax
            ? `El stock no puede superar ${formatNumber(LIMITES_PRODUCTO.stockMax)} unidades`
            : null
        },
      },
    },
  )
  if (!valid) {
    stockError.value = errors.stock ?? 'Stock inválido'
    return
  }

  guardandoStock.value = true
  try {
    await actualizarStock(producto.id, Number(stockValor.value))
    ui.success(
      'Stock actualizado',
      `${producto.nombre}: ${formatearCantidad(stockValor.value, producto.unidad_medida)} ${unidades(producto)}`,
    )
    stockEnEdicion.value = null
    await run()
  } catch (e) {
    stockError.value = e.message
    ui.error('No se pudo actualizar el stock', e.message)
  } finally {
    guardandoStock.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Baja lógica y reactivación (RF-017)                                 */
/* ------------------------------------------------------------------ */

const nombrePorDesactivar = computed(() => porDesactivar.value?.nombre ?? '')

const errorJustificacion = computed(() =>
  validarMotivoProducto(motivoDesactivacion.value, { max: MOTIVO_PRODUCTO_MAX }),
)

function pedirDesactivacion(producto) {
  porDesactivar.value = producto
  motivoDesactivacion.value = MOTIVO_PAUSA_POR_DEFECTO
  errorMotivo.value = null
  confirmDesactivar.value = true
}

function cancelarDesactivacion() {
  confirmDesactivar.value = false
  porDesactivar.value = null
  errorMotivo.value = null
}

async function confirmarDesactivacion() {
  if (!porDesactivar.value) return
  // La justificación es obligatoria en la BD (10..1000): se valida antes de la
  // llamada para no enviar un UPDATE que el trigger rechazará (HAL-VEN-014).
  const motivo = motivoDesactivacion.value.trim()
  const error = errorJustificacion.value
  if (error) {
    errorMotivo.value = error
    return
  }
  cambiandoEstado.value = true
  try {
    await desactivarProducto(porDesactivar.value.id, motivo)
    ui.success(
      'Producto pausado',
      `${porDesactivar.value.nombre} salió del catálogo sin borrarse. Puedes reactivarlo cuando quieras.`,
    )
    cancelarDesactivacion()
    await run()
  } catch (e) {
    ui.error('No se pudo pausar el producto', e.message)
  } finally {
    cambiandoEstado.value = false
  }
}

function pedirEliminacion(producto) {
  porEliminar.value = producto
  motivoEliminacion.value = MOTIVO_PAUSA_POR_DEFECTO
  errorEliminacion.value = null
  confirmEliminar.value = true
}

function cancelarEliminacion() {
  confirmEliminar.value = false
  porEliminar.value = null
  errorEliminacion.value = null
}

/**
 * HAL-VEN-014: eliminar es una baja definitiva (`eliminado_en` +
 * `motivo_eliminacion`), igual que en /admin/productos. A diferencia de la
 * pausa, un producto eliminado NO se puede reactivar desde el vendedor.
 */
async function confirmarEliminacion() {
  if (!porEliminar.value) return
  const motivo = motivoEliminacion.value.trim()
  const errorMotivo = validarMotivoProducto(motivo)
  if (errorMotivo) {
    errorEliminacion.value = errorMotivo
    return
  }
  eliminando.value = true
  try {
    await eliminarProductoVendedor(porEliminar.value.id, motivo)
    ui.success(
      'Producto eliminado',
      `${porEliminar.value.nombre} quedó eliminado del catálogo y no se puede restaurar.`,
    )
    cancelarEliminacion()
    await run()
  } catch (e) {
    ui.error('No se pudo eliminar el producto', e.message)
  } finally {
    eliminando.value = false
  }
}

async function reactivar(producto) {
  // HAL-VEN-014: un producto eliminado no admite reactivación.
  if (producto.eliminado_en) {
    ui.warning(
      'Producto eliminado',
      'Este producto fue eliminado y no se puede reactivar. Consulta la justificación en el detalle.',
    )
    return
  }
  cambiandoEstado.value = true
  try {
    await reactivarProducto(producto.id)
    ui.success(
      'Producto reactivado',
      `${producto.nombre} vuelve a estar disponible en el catálogo.`,
    )
    await run()
  } catch (e) {
    ui.error('No se pudo reactivar el producto', e.message)
  } finally {
    cambiandoEstado.value = false
  }
}

function editar(producto) {
  router.push(`/vendedor/productos/${producto.id}/editar`)
}

/* ------------------------------------------------------------------ */
/* Exportación                                                         */
/* ------------------------------------------------------------------ */

const columnasExport = [
  { key: 'nombre', label: 'Producto' },
  { key: 'categoria', label: 'Categoría', get: (row) => nombreCategoria(row) },
  { key: 'referencia', label: 'Referencia', get: (row) => referencia(row) },
  { key: 'stock', label: 'Stock', get: (row) => formatearCantidad(row.stock, row.unidad_medida) },
  { key: 'precio', label: 'Precio', get: (row) => formatCLP(row.precio) },
  { key: 'unidad_medida', label: 'Unidad', get: (row) => unidades(row) },
  { key: 'estado', label: 'Estado', get: (row) => estadoProducto(row).label },
  {
    key: 'justificacion',
    label: 'Justificación de pausa/eliminación',
    get: (row) => justificacionProducto(row) ?? '',
  },
]

async function exportar() {
  const ok = await exportExcel(catalogo.value, 'inventario-productos', columnasExport)
  if (ok) ui.success('Inventario exportado', 'Se descargó el Excel de tus productos.')
  else ui.warning('Sin datos para exportar', 'Todavía no tienes productos en esta vista.')
}

function limpiarFiltros() {
  unidad.value = null
  categoriaId.value = null
  fechaCosecha.value = ''
  orden.value = 'nombre'
  estado.value = 'todos'
  texto.value = ''
  busqueda.value = ''
  page.value = 1
  run()
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Gestión de Inventario</h1>
        <p class="page-head__subtitle">
          Publica, desactiva y actualiza los productos de tu cosecha, con su stock y su
          disponibilidad.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="!productos.length" @click="exportar">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton v-if="puedeOperar" to="/vendedor/productos/nuevo">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Nuevo Producto
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="loading && !data" label="Cargando tu inventario" />

    <template v-else>
      <CtAlert v-if="error" tone="danger" title="No se pudieron cargar tus productos">
        <p>{{ error }}</p>
        <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
      </CtAlert>

      <CtAlert
        v-if="!hayTienda && !loading"
        tone="warning"
        title="Necesitas una tienda para publicar"
      >
        <p>
          Tu cuenta todavía no tiene una tienda de productor verificada. La postulación se revisa
          antes de habilitar la publicación de productos.
        </p>
        <CtButton size="sm" variant="secondary" to="/vendedor/tienda">Ir a mi tienda</CtButton>
      </CtAlert>

      <CtAlert
        v-else-if="hayTienda && !puedeOperar"
        tone="warning"
        title="Tu cuenta no puede operar la tienda"
      >
        <p>
          {{
            auth.bloqueoVendedor ?? 'La tienda está desactivada o la solicitud no está aprobada.'
          }}
          Mientras la situación no se resuelva no puedes publicar, reactivar ni vender productos.
        </p>
        <CtButton size="sm" variant="secondary" to="/vendedor/tienda"
          >Ver mi perfil de tienda</CtButton
        >
      </CtAlert>

      <!-- ============ Indicadores ============ -->
      <div class="grid-kpi">
        <CtStatCard
          label="Total productos"
          :value="formatNumber(indicadores.total)"
          tone="primary"
          :hint="`${formatNumber(indicadores.publicados)} publicados en el catálogo`"
        />
        <CtStatCard
          label="Productos sin stock"
          :value="formatNumber(indicadores.sinStock)"
          tone="danger"
          :hint="`Última actualización: ${
            indicadores.actualizacion ? formatRelative(indicadores.actualizacion) : 'sin datos'
          }`"
        />
        <CtStatCard
          label="Productos desactivados"
          :value="formatNumber(indicadores.desactivados)"
          tone="warning"
          hint="Bajas lógicas: se conservan y puedes reactivarlos"
        />
      </div>

      <!-- ============ Filtros ============ -->
      <CtCard padding="sm">
        <div class="filtros">
          <CtSearchInput
            v-model="texto"
            placeholder="Buscar por nombre de producto"
            @update:model-value="buscar"
            @search="buscar"
          />
          <CtButton variant="secondary" @click="mostrarFiltros = !mostrarFiltros">
            <template #icon><CtIcon name="filter" :size="16" /></template>
            Filtros Avanzados
          </CtButton>
        </div>

        <div v-if="mostrarFiltros" class="avanzados">
          <CtSelect
            v-model="categoriaId"
            :options="opcionesCategoria"
            label="Categoría"
            clearable
            searchable
            placeholder="Todas las categorías"
          />
          <CtSelect
            v-model="unidad"
            :options="opcionesUnidad"
            label="Unidad de medida"
            clearable
            searchable
            placeholder="Todas las unidades"
          />
          <CtSelect v-model="orden" :options="ESTADOS_ORDEN" label="Ordenar por" />
          <CtInput
            v-model="fechaCosecha"
            type="date"
            label="Fecha de cosecha"
            aria-label="Filtrar por fecha de cosecha"
            @update:model-value="filtrar"
          />
          <CtButton variant="ghost" @click="limpiarFiltros">Limpiar filtros</CtButton>
        </div>

        <CtTabs v-model="estado" :tabs="tabItems" variant="pills" @change="filtrar" />
      </CtCard>

      <!-- ============ Tabla ============ -->
      <CtCard padding="none">
        <CtTable
          :columns="columnas"
          :rows="visibles"
          :loading="loading"
          row-key="id"
          min-width="980px"
          :sort-by="sortKey"
          :sort-direction="sortAsc ? 'asc' : 'desc'"
          @sort="ordenarPor"
          empty-icon="inventory"
          empty-title="No tienes productos en esta vista"
          empty-message="Agrega tu primer producto o cambia el filtro aplicado."
        >
          <template #empty-action>
            <CtButton v-if="puedeOperar" to="/vendedor/productos/nuevo">Nuevo Producto</CtButton>
          </template>

          <template #cell-imagen="{ row }">
            <img
              v-if="row.imagenPrincipal?.url"
              class="thumb"
              :src="row.imagenPrincipal.url"
              :alt="row.nombre"
            />
            <span v-else class="thumb thumb--vacio" aria-hidden="true">
              <CtIcon name="leaf" :size="18" />
            </span>
          </template>

          <template #cell-producto="{ row }">
            <div class="producto">
              <p class="font-semibold">{{ row.nombre }}</p>
              <p class="text-xs text-muted">
                {{ unidades(row) }}
                <template v-if="row.fecha_cosecha">
                  · cosecha {{ formatDate(row.fecha_cosecha) }}</template
                >
              </p>
            </div>
          </template>

          <template #cell-categoria="{ row }">
            <span class="text-sm">{{ nombreCategoria(row) }}</span>
          </template>

          <template #cell-referencia="{ row }">
            <span class="mono text-xs">{{ referencia(row) }}</span>
          </template>

          <template #cell-stock="{ row }">
            <div v-if="stockEnEdicion === row.id" class="stock-edit">
              <CtInput
                v-model="stockValor"
                type="number"
                size="sm"
                :min="LIMITES_PRODUCTO.stockMin"
                :max="LIMITES_PRODUCTO.stockMax"
                step="0.1"
                :hint="`Máximo ${formatNumber(LIMITES_PRODUCTO.stockMax)} unidades`"
                :error="stockError"
                :disabled="guardandoStock"
              />
              <div class="row">
                <CtButton
                  size="sm"
                  :loading="guardandoStock"
                  :disabled="!puedeOperar"
                  @click="guardarStock(row)"
                >
                  Guardar
                </CtButton>
                <CtButton
                  size="sm"
                  variant="ghost"
                  :disabled="guardandoStock"
                  @click="cancelarStock"
                >
                  Cancelar
                </CtButton>
              </div>
            </div>
            <div v-else class="stock">
              <span class="font-semibold">{{
                formatearCantidad(row.stock, row.unidad_medida)
              }}</span>
              <span class="text-xs text-muted"> {{ unidades(row) }}</span>
              <CtButton
                size="sm"
                variant="ghost"
                :disabled="!puedeOperar || Boolean(row.eliminado_en)"
                @click.stop="editarStock(row)"
              >
                <template #icon><CtIcon name="edit" :size="14" /></template>
                Editar
              </CtButton>
            </div>
          </template>

          <template #cell-precio="{ row }">
            <span class="font-semibold">{{ formatCLP(row.precio) }}</span>
            <span class="text-xs text-muted">/ {{ unidades(row) }}</span>
          </template>

          <template #cell-estado="{ row }">
            <CtBadge :tone="estadoProducto(row).tone" size="sm" dot>
              {{ estadoProducto(row).label }}
            </CtBadge>
          </template>

          <template #cell-acciones="{ row }">
            <div class="row row--end">
              <CtButton size="sm" variant="ghost" @click.stop="abrirDetalle(row)">
                <template #icon><CtIcon name="eye" :size="15" /></template>
                Ver detalle
              </CtButton>
              <CtButton
                size="sm"
                variant="secondary"
                :disabled="!puedeOperar || Boolean(row.eliminado_en)"
                @click.stop="editar(row)"
              >
                Editar
              </CtButton>
              <CtButton
                v-if="row.activo && !row.eliminado_en"
                size="sm"
                variant="ghost"
                :disabled="!puedeOperar"
                @click.stop="pedirDesactivacion(row)"
              >
                <template #icon><CtIcon name="ban" :size="15" /></template>
                Desactivar
              </CtButton>
              <CtButton
                v-if="row.activo && !row.eliminado_en"
                size="sm"
                variant="danger"
                :disabled="!puedeOperar"
                @click.stop="pedirEliminacion(row)"
              >
                <template #icon><CtIcon name="delete" :size="15" /></template>
                Eliminar
              </CtButton>
              <CtButton
                v-else-if="!row.eliminado_en"
                size="sm"
                variant="ghost"
                :loading="cambiandoEstado"
                :disabled="!puedeOperar"
                @click.stop="reactivar(row)"
              >
                <template #icon><CtIcon name="refresh" :size="15" /></template>
                Reactivar
              </CtButton>
            </div>
          </template>
        </CtTable>

        <template #footer>
          <CtPagination
            v-model:page="page"
            v-model:page-size="pageSize"
            :total="catalogo.length"
            label="productos"
          />
        </template>
      </CtCard>

      <!-- ============ Tarjetas de aviso ============ -->
      <div class="grid">
        <div class="col-6">
          <CtCard
            title="Stock bajo control manual"
            subtitle="Así funciona el inventario en el alcance vigente"
          >
            <div class="stack stack--sm">
              <CtAlert v-if="indicadores.sinStock" tone="warning" compact>
                <p>
                  {{ indicadores.sinStock }} producto(s) publicados están sin stock. Mientras el
                  stock sea 0 el cliente no puede completar la compra.
                </p>
              </CtAlert>
              <CtAlert v-else tone="success" compact>
                <p>Todos tus productos publicados tienen stock disponible.</p>
              </CtAlert>
              <p class="text-sm text-soft">
                En el alcance vigente no existen umbrales ni alertas automáticas de stock bajo
                (quedó fuera del alcance): revisa y actualiza el stock a mano con el botón Editar de
                cada fila.
              </p>
            </div>
            <template #footer>
              <CtButton size="sm" variant="ghost" to="/vendedor">Volver al panel</CtButton>
            </template>
          </CtCard>
        </div>

        <div class="col-6">
          <CtCard title="Accesos rápidos" subtitle="Continúa trabajando tu tienda">
            <ul class="accesos">
              <li>
                <router-link to="/vendedor/pedidos" class="accesos__item">
                  <CtIcon name="orders" :size="16" />
                  <span>Ir a pedidos recibidos</span>
                  <CtIcon name="chevronRight" :size="14" />
                </router-link>
              </li>
              <li>
                <router-link to="/vendedor/tienda" class="accesos__item">
                  <CtIcon name="store" :size="16" />
                  <span>Editar el perfil de mi tienda</span>
                  <CtIcon name="chevronRight" :size="14" />
                </router-link>
              </li>
              <li>
                <router-link to="/vendedor/productos/nuevo" class="accesos__item">
                  <CtIcon name="plus" :size="16" />
                  <span>Agregar un producto nuevo</span>
                  <CtIcon name="chevronRight" :size="14" />
                </router-link>
              </li>
            </ul>
          </CtCard>
        </div>
      </div>
    </template>

    <!-- ============ Detalle de sólo lectura (HAL-VEN-013) ============ -->
    <CtModal
      :model-value="Boolean(detalleProducto)"
      :title="detalleProducto?.nombre ?? 'Detalle del producto'"
      size="lg"
      @update:model-value="!$event && cerrarDetalle()"
    >
      <div v-if="detalleProducto" class="detalle">
        <div class="detalle__cabecera">
          <img
            v-if="detalleProducto.imagenPrincipal?.url"
            class="detalle__imagen"
            :src="detalleProducto.imagenPrincipal.url"
            :alt="detalleProducto.nombre"
          />
          <span v-else class="detalle__imagen detalle__imagen--vacia" aria-hidden="true">
            <CtIcon name="leaf" :size="28" />
          </span>
          <div class="detalle__resumen">
            <div class="row row--wrap">
              <CtBadge :tone="estadoProducto(detalleProducto).tone" dot>
                {{ estadoProducto(detalleProducto).label }}
              </CtBadge>
              <CtBadge tone="neutral" size="sm">{{ nombreCategoria(detalleProducto) }}</CtBadge>
            </div>
            <dl class="detalle__datos">
              <div>
                <dt>Referencia</dt>
                <dd class="mono">{{ referencia(detalleProducto) }}</dd>
              </div>
              <div>
                <dt>Precio por unidad</dt>
                <dd>{{ formatCLP(detalleProducto.precio) }} / {{ unidades(detalleProducto) }}</dd>
              </div>
              <div>
                <dt>Stock disponible</dt>
                <dd>
                  {{ formatearCantidad(detalleProducto.stock, detalleProducto.unidad_medida) }}
                  {{ unidades(detalleProducto) }}
                </dd>
              </div>
              <div>
                <dt>Fecha de cosecha</dt>
                <dd>
                  {{
                    detalleProducto.fecha_cosecha
                      ? formatDate(detalleProducto.fecha_cosecha)
                      : 'No informada'
                  }}
                </dd>
              </div>
              <div>
                <dt>Última actualización</dt>
                <dd>
                  {{
                    detalleProducto.actualizado_en
                      ? formatDate(detalleProducto.actualizado_en)
                      : '—'
                  }}
                </dd>
              </div>
            </dl>
          </div>
        </div>

        <div>
          <h4 class="detalle__subtitulo">Descripción</h4>
          <p class="text-sm text-soft">
            {{ detalleProducto.descripcion || 'Sin descripción registrada.' }}
          </p>
        </div>

        <CtAlert
          v-if="justificacionProducto(detalleProducto)"
          :tone="detalleProducto.eliminado_en ? 'danger' : 'warning'"
          compact
          :title="
            detalleProducto.eliminado_en ? 'Justificación de eliminación' : 'Justificación de pausa'
          "
        >
          <p>{{ justificacionProducto(detalleProducto) }}</p>
        </CtAlert>
        <CtAlert v-else-if="!detalleProducto.activo" tone="warning" compact>
          <p>El producto está pausado sin una justificación registrada.</p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="cerrarDetalle">Cerrar</CtButton>
        <CtButton
          v-if="puedeOperar && !detalleProducto?.eliminado_en"
          @click="editarDesdeDetalle(detalleProducto)"
        >
          Editar producto
        </CtButton>
      </template>
    </CtModal>

    <!-- ============ Pausa con justificación obligatoria (HAL-VEN-014) ============ -->
    <CtModal
      v-model="confirmDesactivar"
      title="Pausar producto"
      subtitle="El producto sale del catálogo sin borrarse y puedes reactivarlo cuando quieras."
      size="sm"
      @update:model-value="!$event && cancelarDesactivacion()"
    >
      <div class="stack">
        <p class="text-sm text-soft">
          Se aplicará una <strong>baja lógica</strong> a <strong>{{ nombrePorDesactivar }}</strong>.
          Los pedidos ya confirmados no se ven afectados.
        </p>
        <CtTextarea
          v-model="motivoDesactivacion"
          label="Justificación de la pausa"
          hint="Obligatoria: entre 10 y 1000 caracteres. Se muestra en el detalle del producto."
          :error="errorMotivo ?? errorJustificacion"
          :rows="3"
          :maxlength="MOTIVO_PRODUCTO_MAX"
          show-count
          required
          placeholder="Explica por qué pausas este producto"
          @update:model-value="errorMotivo = null"
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="cambiandoEstado" @click="cancelarDesactivacion">
          Cancelar
        </CtButton>
        <CtButton
          variant="danger"
          :loading="cambiandoEstado"
          :disabled="Boolean(errorJustificacion)"
          @click="confirmarDesactivacion"
        >
          Pausar producto
        </CtButton>
      </template>
    </CtModal>

    <!-- ============ Eliminación lógica definitiva (HAL-VEN-013/014) ============ -->
    <CtModal
      v-model="confirmEliminar"
      title="Eliminar producto"
      subtitle="Esta acción retira el producto del catálogo y no se puede deshacer."
      size="sm"
      @update:model-value="!$event && cancelarEliminacion()"
    >
      <div class="stack">
        <p class="text-sm text-soft">
          <strong>{{ porEliminar?.nombre ?? '' }}</strong> dejará de mostrarse en el catálogo. Los
          pedidos ya confirmados no se modifican y el producto
          <strong>no podrá volver a publicarse</strong> desde tu panel.
        </p>
        <CtTextarea
          v-model="motivoEliminacion"
          label="Justificación de la eliminación"
          hint="Obligatoria: explica brevemente por qué retiras esta publicación."
          :error="errorEliminacion"
          :rows="3"
          :maxlength="MOTIVO_PRODUCTO_MAX"
          show-count
          required
          placeholder="Explica por qué eliminas este producto"
          @update:model-value="errorEliminacion = null"
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="eliminando" @click="cancelarEliminacion">
          Cancelar
        </CtButton>
        <CtButton
          variant="danger"
          :loading="eliminando"
          :disabled="eliminando || Boolean(errorEliminacion)"
          @click="confirmarEliminacion"
        >
          Eliminar producto
        </CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.motivo {
  margin: 4px 0 0;
  max-width: 17ch;
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-xs);
  line-height: var(--ct-lh-tight);
  overflow-wrap: anywhere;
}

.detalle {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
  min-width: 0;
}

.detalle__cabecera {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-4);
  min-width: 0;
}

.detalle__imagen {
  width: 132px;
  height: 132px;
  flex: 0 0 132px;
  border-radius: var(--ct-radius-lg);
  border: 1px solid var(--ct-border);
  object-fit: cover;
  background: var(--ct-surface-alt);
}

.detalle__imagen--vacia {
  display: grid;
  place-items: center;
  color: var(--ct-text-muted);
}

.detalle__resumen {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  min-width: 0;
  flex: 1;
}

.detalle__datos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: var(--ct-space-3);
  margin: 0;
}

.detalle__datos dt {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.detalle__datos dd {
  margin: 2px 0 0;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  overflow-wrap: anywhere;
}

.detalle__subtitulo {
  margin: 0 0 var(--ct-space-2);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.detalle__subtitulo + p {
  overflow-wrap: anywhere;
  white-space: pre-line;
}

@media (max-width: 640px) {
  .detalle__cabecera {
    flex-direction: column;
  }

  .detalle__imagen {
    width: 100%;
    height: 180px;
    flex-basis: auto;
  }
}

.filtros {
  display: grid;
  grid-template-columns: minmax(220px, 1fr) auto;
  gap: var(--ct-space-4);
  align-items: center;
  margin-bottom: var(--ct-space-4);
}

/* En móvil el botón de filtros baja a su propia fila para no desbordar. */
@media (max-width: 520px) {
  .filtros {
    grid-template-columns: 1fr;
  }
  .filtros > * {
    min-width: 0;
  }
}

.avanzados {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 260px));
  gap: var(--ct-space-4);
  align-items: end;
  margin-bottom: var(--ct-space-4);
}

.thumb {
  width: 68px;
  height: 68px;
  border-radius: var(--ct-radius-md);
  object-fit: cover;
  border: 1px solid var(--ct-border);
  background: var(--ct-surface-alt);
}

.thumb--vacio {
  display: grid;
  place-items: center;
  color: var(--ct-text-muted);
}

.producto {
  min-width: 0;
}

.stock,
.stock-edit {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: var(--ct-space-1);
}

.stock {
  flex-direction: row;
  align-items: center;
  justify-content: flex-end;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.stock-edit {
  min-width: 150px;
}

.accesos {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.accesos__item {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
  color: var(--ct-text);
  text-decoration: none;
  font-size: var(--ct-fs-md);
}

.accesos__item:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.accesos__item > :last-child {
  margin-left: auto;
  color: var(--ct-text-muted);
}

.accesos li:last-child .accesos__item {
  border-bottom: none;
  padding-bottom: 0;
}
</style>
