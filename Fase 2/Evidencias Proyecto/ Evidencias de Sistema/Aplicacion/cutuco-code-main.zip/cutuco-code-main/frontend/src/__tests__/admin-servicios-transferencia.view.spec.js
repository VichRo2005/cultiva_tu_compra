import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

const servicio = vi.hoisted(() => ({
  actualizarDatosTransferenciaCutuco: vi.fn(),
  actualizarMorosidadServicio: vi.fn(),
  listPagosServicioAdmin: vi.fn(),
  listServiciosAdmin: vi.fn(),
  obtenerDatosTransferenciaCutuco: vi.fn(),
  resolverPagoServicio: vi.fn(),
}))

vi.mock('@/services/servicio', async (importOriginal) => ({
  ...(await importOriginal()),
  ...servicio,
}))

import AdminServicesView from '@/views/admin/AdminServicesView.vue'

let wrapper

beforeEach(() => {
  setActivePinia(createPinia())
  servicio.listServiciosAdmin.mockResolvedValue([])
  servicio.listPagosServicioAdmin.mockResolvedValue([])
  servicio.obtenerDatosTransferenciaCutuco.mockResolvedValue({
    banco: 'BancoEstado',
    tipoCuenta: 'Cuenta corriente',
    numeroCuenta: '12345678',
    titular: 'CuTuCo SpA',
    rut: '76.543.210-8',
    actualizadoEn: '2026-11-26T12:00:00Z',
  })
})

afterEach(() => {
  wrapper?.unmount()
  vi.resetAllMocks()
})

describe('AdminServicesView · datos de transferencia', () => {
  it('mantiene el formulario cerrado hasta que administración decide editarlo', async () => {
    wrapper = mount(AdminServicesView, {
      global: {
        plugins: [createPinia()],
        stubs: { CtDateRange: true, CtStatCard: true, CtTable: true },
      },
    })
    await flushPromises()

    expect(wrapper.findAll('.servicio-admin__datos-transferencia input')).toHaveLength(0)
    const editar = wrapper.findAll('button').find((boton) => boton.text() === 'Editar datos bancarios')
    expect(editar.attributes('aria-expanded')).toBe('false')
    await editar.trigger('click')
    await flushPromises()

    const entradas = wrapper.findAll('.servicio-admin__datos-transferencia input')
    expect(entradas).toHaveLength(5)
    expect(entradas.map((entrada) => entrada.element.value)).toEqual([
      'BancoEstado', 'Cuenta corriente', '12345678', 'CuTuCo SpA', '76.543.210-8',
    ])

    await entradas[0].setValue('Banco de Chile')
    servicio.actualizarDatosTransferenciaCutuco.mockResolvedValue({
      banco: 'Banco de Chile',
      tipoCuenta: 'Cuenta corriente',
      numeroCuenta: '12345678',
      titular: 'CuTuCo SpA',
      rut: '76.543.210-8',
      actualizadoEn: '2026-11-26T12:05:00Z',
    })
    await wrapper.find('form.servicio-admin__datos-transferencia').trigger('submit')
    await flushPromises()

    expect(servicio.actualizarDatosTransferenciaCutuco).toHaveBeenCalledWith({
      banco: 'Banco de Chile',
      tipoCuenta: 'Cuenta corriente',
      numeroCuenta: '12345678',
      titular: 'CuTuCo SpA',
      rut: '76.543.210-8',
      actualizadoEn: '2026-11-26T12:00:00Z',
    })
    expect(wrapper.text()).toContain('Configurados')

    const ocultar = wrapper.findAll('button').find((boton) => boton.text() === 'Ocultar edición')
    await ocultar.trigger('click')
    await flushPromises()
    expect(wrapper.findAll('.servicio-admin__datos-transferencia input')).toHaveLength(0)
  })
})
