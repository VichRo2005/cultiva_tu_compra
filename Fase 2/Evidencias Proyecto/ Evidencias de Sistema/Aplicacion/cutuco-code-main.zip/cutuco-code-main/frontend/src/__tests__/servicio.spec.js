import { describe, expect, it } from 'vitest'

import {
  normalizarDatosTransferenciaCutuco,
  diasHastaSuspension,
  etiquetaEstadoServicio,
  tonoEstadoServicio,
} from '@/services/servicio'
import { ESTADO_SERVICIO, ESTADO_TIENDA_SERVICIO } from '@/lib/constants'

describe('servicio · estados', () => {
  it('etiqueta estados de tienda y de cuota', () => {
    expect(etiquetaEstadoServicio(ESTADO_TIENDA_SERVICIO.AL_DIA)).toBe('Al día')
    expect(etiquetaEstadoServicio(ESTADO_TIENDA_SERVICIO.VENCIDO)).toContain('Vencido')
    expect(etiquetaEstadoServicio(ESTADO_SERVICIO.PENDIENTE_REVISION)).toContain('revisión')
  })

  it('asigna tonos coherentes', () => {
    expect(tonoEstadoServicio(ESTADO_TIENDA_SERVICIO.AL_DIA)).toBe('success')
    expect(tonoEstadoServicio(ESTADO_TIENDA_SERVICIO.PENDIENTE)).toBe('warning')
    expect(tonoEstadoServicio(ESTADO_TIENDA_SERVICIO.VENCIDO)).toBe('danger')
    expect(tonoEstadoServicio(ESTADO_SERVICIO.RECHAZADO)).toBe('danger')
  })

  it('cuenta días de gracia desde el vencimiento', () => {
    const hoy = new Date()
    const vence = new Date(hoy)
    vence.setDate(vence.getDate() + 10)
    const fecha = `${vence.getFullYear()}-${String(vence.getMonth() + 1).padStart(2, '0')}-${String(vence.getDate()).padStart(2, '0')}`
    expect(diasHastaSuspension({ vence_en: fecha })).toBe(15)
  })

  it('normaliza los datos bancarios publicados sin exponer nulls en la vista', () => {
    expect(normalizarDatosTransferenciaCutuco(null)).toMatchObject({
      banco: '', tipoCuenta: '', numeroCuenta: '', titular: '', rut: '',
    })
    expect(normalizarDatosTransferenciaCutuco({
      banco: ' BancoEstado ', tipo_cuenta: ' CuentaRUT ', numero_cuenta: 12345678,
      titular: ' CuTuCo SpA ', rut: ' 76.543.210-8 ', actualizado_en: '2026-11-26T10:00:00Z',
    })).toEqual({
      banco: 'BancoEstado', tipoCuenta: 'CuentaRUT', numeroCuenta: '12345678',
      titular: 'CuTuCo SpA', rut: '76.543.210-8', actualizadoEn: '2026-11-26T10:00:00Z',
    })
  })
})
