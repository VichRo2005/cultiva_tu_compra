<script setup>
/**
 * CuTuCo — Pagos autorizados (Webpay Mall Plus, RF-005).
 *
 * Vista informativa del administrador: lista los comprobantes exitosos de
 * `pagos` (escritos por FastAPI con service_role al confirmar el commit) y los
 * hidrata con el `codigo_pedido` de su pedido. La dispersión a los vendedores la
 * hace Transbank vía Webpay Mall: la comisión del 5% de CuTuCo se registra como
 * un cargo del Mall y el resto llega directo al comercio del productor.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, eliminado): la custodia/escrow, la tabla
 * `payouts`, la aprobación manual de payouts y los reembolsos
 * (`listPayouts`, `aprobarPayout`, `registrarReembolso`, `getResumenCustodia`)
 * se retiraron con la migración `20261010010000_webpay_mall_postulaciones.sql`.
 */
import { computed, onMounted, ref, watch } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtDateRange from '@/components/base/CtDateRange.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtToggle from '@/components/base/CtToggle.vue'
import { exportExcel } from '@/lib/csv'
import { formatCLP, formatDateTime, formatNumber } from '@/lib/format'
import { TASA_IVA_CHILE } from '@/lib/taxes'
import { getClient } from '@/lib/supabase'
import { actualizarIvaHabilitado, obtenerConfiguracionCobro } from '@/services/configuracionCobro'
import { listPagos } from '@/services/payments'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const shortId = (id) => String(id ?? '').slice(0, 8)

const texto = ref('')
const fechaDesde = ref('')
const fechaHasta = ref('')
const page = ref(1)
const pageSize = ref(12)
const loading = ref(true)
const error = ref(null)
const pagos = ref([])
const ivaHabilitado = ref(null)
const cargandoIva = ref(true)
const guardandoIva = ref(false)
const errorIva = ref(null)
const editandoIva = ref(false)
const cambioIva = ref({ abierto: false, valor: null })
const versionInterruptorIva = ref(0)
const columnas = [
  { key: 'pedido', label: 'Pedido', width: '20%' },
  { key: 'buy_order', label: 'Orden Webpay' },
  { key: 'autorizacion', label: 'Autorización' },
  { key: 'monto', label: 'Neto al productor', align: 'right' },
  { key: 'iva', label: 'IVA', align: 'right' },
  { key: 'comision', label: 'Comisión', align: 'right' },
  { key: 'creado', label: 'Autorizado' },
]

const estadoIva = computed(() => {
  if (cargandoIva.value) return 'Cargando…'
  if (ivaHabilitado.value === null) return 'No disponible'
  return ivaHabilitado.value ? 'Aplicado · 19 %' : 'Sin IVA'
})

const tonoEstadoIva = computed(() => {
  if (cargandoIva.value || ivaHabilitado.value === null) return 'warning'
  return ivaHabilitado.value ? 'success' : 'neutral'
})

/**
 * `pagos.monto` es el neto que recibe el comercio del productor; la comisión
 * viaja como un cargo del Mall (`monto_fee_descontado`). Por eso el
 * total cobrado es neto + fee, y no se puede estimar la comisión como 5% del
 * neto (sería 5% de un monto que ya viene sin fee).
 */
const totalAutorizado = computed(
  () =>
    Math.round(
      filtrados.value.reduce(
        (acc, p) => acc + Number(p.monto ?? 0) + Number(p.monto_fee_descontado ?? 0),
        0,
      ) * 100,
    ) / 100,
)

const comisionCobrada = computed(
  () =>
    Math.round(
      filtrados.value.reduce((acc, p) => acc + Number(p.monto_fee_descontado ?? 0), 0) * 100,
    ) / 100,
)

// La comisión guardada por Webpay incluye IVA. Se separa para que el ingreso
// efectivo de CuTuCo no se confunda con el impuesto que debe declararse.
const ivaComision = computed(() =>
  Math.round(comisionCobrada.value * (TASA_IVA_CHILE / (1 + TASA_IVA_CHILE))),
)
const ingresoNetoComision = computed(() => comisionCobrada.value - ivaComision.value)

const dispersadoVendedores = computed(
  () => Math.round(filtrados.value.reduce((acc, p) => acc + Number(p.monto ?? 0), 0) * 100) / 100,
)

const filtrados = computed(() => {
  const busqueda = texto.value.trim().toLowerCase()
  return pagos.value.filter((p) => {
    const fecha = String(p.creado_en ?? '').slice(0, 10)
    if (
      (fechaDesde.value && fecha < fechaDesde.value) ||
      (fechaHasta.value && fecha > fechaHasta.value)
    ) {
      return false
    }
    if (!busqueda) return true
    return (
      String(p.pedido_codigo ?? '')
        .toLowerCase()
        .includes(busqueda) ||
      String(p.buy_order ?? '')
        .toLowerCase()
        .includes(busqueda) ||
      String(p.codigo_autorizacion ?? '')
        .toLowerCase()
        .includes(busqueda)
    )
  })
})

watch([texto, fechaDesde, fechaHasta], () => {
  page.value = 1
})

const items = computed(() => {
  const inicio = (page.value - 1) * pageSize.value
  return filtrados.value.slice(inicio, inicio + pageSize.value)
})

async function cargar() {
  loading.value = true
  error.value = null
  try {
    const lista = await listPagos()
    // Hidrata pedido_id -> codigo_pedido para mostrar el código visible.
    const ids = [...new Set(lista.map((p) => p.pedido_id).filter(Boolean))]
    let mapa = new Map()
    if (ids.length) {
      const client = getClient()
      const { data: pedidos } = await client
        .from('pedidos')
        .select('id, codigo_pedido, total, tasa_iva, monto_iva')
        .in('id', ids)
      mapa = new Map((pedidos ?? []).map((pd) => [pd.id, pd]))
    }
    pagos.value = lista.map((p) => {
      const pedido = mapa.get(p.pedido_id)
      return {
        ...p,
        pedido_codigo: pedido?.codigo_pedido ?? null,
        iva: Number(pedido?.monto_iva ?? 0),
        tasa_iva: Number(pedido?.tasa_iva ?? 0),
        total_cobrado: Number(
          pedido?.total ?? Number(p.monto ?? 0) + Number(p.monto_fee_descontado ?? 0),
        ),
      }
    })
  } catch (e) {
    error.value = e.message
    pagos.value = []
  } finally {
    loading.value = false
  }
}

async function cargarConfiguracionIva() {
  cargandoIva.value = true
  errorIva.value = null
  try {
    const configuracion = await obtenerConfiguracionCobro()
    ivaHabilitado.value = configuracion.ivaHabilitado
  } catch (e) {
    ivaHabilitado.value = null
    errorIva.value = e.message
  } finally {
    cargandoIva.value = false
  }
}

function alternarEdicionIva() {
  editandoIva.value = !editandoIva.value
}

function solicitarCambioIva(valor) {
  const proximoValor = Boolean(valor)
  if (
    cargandoIva.value ||
    guardandoIva.value ||
    ivaHabilitado.value === null ||
    proximoValor === ivaHabilitado.value
  ) {
    return
  }
  errorIva.value = null
  cambioIva.value = { abierto: true, valor: proximoValor }
  // El checkbox nativo cambia antes de que se abra el diálogo. Al recrearlo
  // con el valor persistido, la interfaz no anticipa un cambio que aún puede
  // cancelarse.
  versionInterruptorIva.value += 1
}

async function confirmarCambioIva() {
  const proximoValor = cambioIva.value.valor
  if (guardandoIva.value || typeof proximoValor !== 'boolean') return

  guardandoIva.value = true
  errorIva.value = null
  try {
    const configuracion = await actualizarIvaHabilitado(proximoValor)
    ivaHabilitado.value = configuracion.ivaHabilitado
    cambioIva.value.abierto = false
    ui.success(
      proximoValor ? 'IVA aplicado a nuevos pagos' : 'IVA retirado de nuevos pagos',
      proximoValor
        ? 'Los próximos checkouts sumarán IVA de 19 % sobre productos y despacho.'
        : 'Los próximos checkouts cobrarán sólo productos y despacho netos.',
    )
  } catch (e) {
    errorIva.value = e.message
    ui.error('No se pudo actualizar el IVA', e.message)
  } finally {
    guardandoIva.value = false
  }
}

async function recargar() {
  await Promise.all([cargar(), cargarConfiguracionIva()])
}

function quitarRangoFechas() {
  fechaDesde.value = ''
  fechaHasta.value = ''
}

async function exportarPagos() {
  if (!filtrados.value.length) {
    ui.warning('Sin datos para exportar', 'No hay pagos con los filtros actuales.')
    return
  }
  const ok = await exportExcel(
    filtrados.value.map((p) => ({
      pedido: p.pedido_codigo ?? shortId(p.pedido_id),
      orden: p.buy_order ?? '',
      autorizacion: p.codigo_autorizacion ?? '',
      neto_productor: p.monto,
      iva: p.iva,
      comision: p.monto_fee_descontado,
      total_cobrado: p.total_cobrado,
      autorizado: p.creado_en,
    })),
    'cutuco-pagos-webpay',
    [
      { key: 'pedido', label: 'Pedido' },
      { key: 'orden', label: 'Orden Webpay' },
      { key: 'autorizacion', label: 'Autorización' },
      { key: 'neto_productor', label: 'Neto al productor' },
      { key: 'iva', label: 'IVA' },
      { key: 'comision', label: 'Comisión CuTuCo' },
      { key: 'total_cobrado', label: 'Total cobrado' },
      { key: 'autorizado', label: 'Autorizado' },
    ],
  )
  if (ok) ui.success('Pagos exportados', 'Se descargó el Excel de comprobantes autorizados.')
  else ui.error('No se pudo exportar', 'No hay filas para exportar.')
}

function actualizarTamanoPagina(valor) {
  pageSize.value = valor
  page.value = 1
}

onMounted(recargar)
</script>

<template>
  <div class="container page panel-page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Pagos</h1>
        <p class="page-head__subtitle">
          Comprobantes de pago autorizados por Webpay. La dispersión a los vendedores la hace
          Transbank vía Webpay Mall: CuTuCo registra su comisión del 5% como cargo del Mall y el
          resto llega directo al comercio del productor.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="loading" @click="exportarPagos">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton :loading="loading || cargandoIva" @click="recargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar los pagos">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-if="loading && !pagos.length" label="Cargando pagos…" />

    <template v-else>
      <CtCard padding="md">
        <div class="pagos__encabezado-configuracion">
          <div>
            <h2 class="eyebrow">IVA en pagos de productos</h2>
            <p class="text-sm text-muted">
              Define si los nuevos checkouts de productos y despacho suman IVA de 19 %.
            </p>
          </div>
          <div class="pagos__encabezado-acciones">
            <CtBadge :tone="tonoEstadoIva" size="sm">{{ estadoIva }}</CtBadge>
            <CtButton
              size="sm"
              variant="secondary"
              :aria-expanded="editandoIva"
              aria-controls="configuracion-iva-pagos"
              @click="alternarEdicionIva"
            >
              {{ editandoIva ? 'Ocultar configuración' : 'Configurar IVA' }}
            </CtButton>
          </div>
        </div>

        <div id="configuracion-iva-pagos" class="pagos__contenido-configuracion">
          <p v-if="!editandoIva" class="pagos__resumen-iva text-sm text-muted" aria-live="polite">
            <template v-if="cargandoIva">Cargando la configuración tributaria actual…</template>
            <template v-else-if="ivaHabilitado === true">
              Los nuevos pagos sumarán IVA de 19 % sobre los productos y el despacho.
            </template>
            <template v-else-if="ivaHabilitado === false">
              Los nuevos pagos cobrarán sólo productos y despacho netos, sin IVA.
            </template>
            <template v-else>
              No se pudo confirmar el estado del IVA. Abre la configuración para reintentar.
            </template>
          </p>

          <div v-else class="pagos__ajuste-iva">
            <CtAlert v-if="errorIva" tone="danger" title="No se pudo cargar la configuración de IVA" role="alert">
              <p>{{ errorIva }}</p>
              <CtButton size="sm" variant="secondary" :loading="cargandoIva" @click="cargarConfiguracionIva">
                Reintentar
              </CtButton>
            </CtAlert>

            <CtToggle
              :key="versionInterruptorIva"
              :model-value="ivaHabilitado === true"
              :disabled="cargandoIva || guardandoIva || ivaHabilitado === null"
              :label="
                ivaHabilitado === null
                  ? 'Estado de IVA no disponible'
                  : ivaHabilitado
                    ? 'Aplicar IVA de 19 % a los nuevos pagos'
                    : 'No aplicar IVA a los nuevos pagos'
              "
              :description="
                ivaHabilitado === null
                  ? 'Reintenta cargar la configuración antes de modificarla.'
                  : ivaHabilitado
                    ? 'El cliente paga productos y despacho netos más IVA.'
                    : 'El cliente paga sólo productos y despacho netos.'
              "
              @update:model-value="solicitarCambioIva"
            />
            <p class="pagos__nota-iva text-sm text-muted">
              El cambio sólo afecta checkouts iniciados después de guardarlo. No modifica pedidos ni
              pagos Webpay ya creados.
            </p>
          </div>
        </div>
      </CtCard>

      <div class="grid-kpi panel-kpi">
        <CtStatCard
          label="Comprobantes autorizados"
          :value="formatNumber(filtrados.length)"
          icon="check"
          tone="success"
          hint="Filas exitosas en la tabla pagos"
        />
        <CtStatCard
          label="Total cobrado vía Webpay"
          :value="formatCLP(totalAutorizado)"
          icon="scale"
          tone="accent"
          hint="Suma de los comprobantes autorizados"
          calculation="Suma, por cada comprobante autorizado dentro del período, el neto que recibe el vendedor más el cargo de CuTuCo registrado por Webpay Mall."
        />
        <CtStatCard
          label="Comisión bruta cobrada"
          :value="formatCLP(comisionCobrada)"
          icon="lock"
          tone="info"
          hint="Total de cargos de comisión registrados"
          calculation="Suma de los cargos de CuTuCo registrados por Webpay Mall en los comprobantes filtrados."
        />
        <CtStatCard
          label="IVA de comisión"
          :value="formatCLP(ivaComision)"
          icon="scale"
          tone="warning"
          hint="IVA incluido dentro de la comisión bruta"
          calculation="Se obtiene separando el 19 % incluido en la comisión bruta: comisión × 19 / 119."
        />
        <CtStatCard
          label="Ingreso neto de comisión"
          :value="formatCLP(ingresoNetoComision)"
          icon="check"
          tone="success"
          hint="Comisión bruta menos IVA de comisión"
          calculation="Monto que queda para CuTuCo después de descontar el IVA de la comisión."
        />
        <CtStatCard
          label="Dispersado a vendedores"
          :value="formatCLP(dispersadoVendedores)"
          icon="store"
          tone="neutral"
          hint="Neto que Transbank ya depositó a cada comercio"
          calculation="Suma el monto neto de los comprobantes autorizados que Transbank asigna al comercio de cada vendedor. Es informativo y debe conciliarse con los abonos bancarios."
        />
      </div>

      <CtCard padding="md">
        <div class="barra">
          <CtSearchInput
            v-model="texto"
            class="barra__buscador"
            placeholder="Buscar por pedido, orden o autorización…"
            aria-label="Buscar pagos"
          />
          <CtDateRange
            v-model:desde="fechaDesde"
            v-model:hasta="fechaHasta"
            label="Accesos rápidos"
          />
          <CtButton
            v-if="fechaDesde || fechaHasta"
            size="sm"
            variant="ghost"
            @click="quitarRangoFechas"
          >
            Quitar rango de fechas
          </CtButton>
        </div>

        <CtTable
          :columns="columnas"
          :rows="items"
          :loading="loading"
          dense
          min-width="760px"
          empty-icon="scale"
          empty-title="Sin pagos registrados"
          empty-message="Todavía no hay comprobantes autorizados por Webpay Mall."
        >
          <template #cell-pedido="{ row }">
            <span class="mono text-xs" :title="row.pedido_id">
              {{ row.pedido_codigo ?? shortId(row.pedido_id) }}
            </span>
          </template>

          <template #cell-buy_order="{ row }">
            <span class="mono text-xs">{{ row.buy_order ?? '—' }}</span>
          </template>

          <template #cell-autorizacion="{ row }">
            <span class="mono text-xs">{{ row.codigo_autorizacion ?? '—' }}</span>
          </template>

          <template #cell-monto="{ row }">
            <span class="font-semibold">{{ formatCLP(row.monto) }}</span>
          </template>

          <template #cell-iva="{ row }">
            <span class="text-sm text-muted">
              {{ row.tasa_iva ? `${formatCLP(row.iva)} (${row.tasa_iva * 100}%)` : '—' }}
            </span>
          </template>

          <template #cell-comision="{ row }">
            <span class="text-sm text-muted">{{ formatCLP(row.monto_fee_descontado) }}</span>
          </template>

          <template #cell-creado="{ row }">
            <span class="text-sm text-muted">{{ formatDateTime(row.creado_en) }}</span>
          </template>
        </CtTable>

        <CtPagination
          :page="page"
          :total="filtrados.length"
          :page-size="pageSize"
          label="pagos"
          @update:page="page = $event"
          @update:page-size="actualizarTamanoPagina"
        />
      </CtCard>

      <CtConfirmDialog
        v-model="cambioIva.abierto"
        :title="cambioIva.valor ? 'Aplicar IVA a los nuevos pagos' : 'Quitar IVA de los nuevos pagos'"
        :message="
          cambioIva.valor
            ? 'Los próximos checkouts sumarán 19 % de IVA sobre productos y despacho. Los pedidos ya creados no cambian.'
            : 'Los próximos checkouts dejarán de sumar IVA. Los pedidos ya creados no cambian.'
        "
        :confirm-label="cambioIva.valor ? 'Aplicar IVA' : 'Quitar IVA'"
        :tone="cambioIva.valor ? 'primary' : 'danger'"
        :loading="guardandoIva"
        @confirm="confirmarCambioIva"
      />
    </template>
  </div>
</template>

<style scoped>
.panel-page {
  gap: var(--ct-space-6);
}

.panel-kpi {
  gap: var(--ct-space-4);
}

.barra {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-4);
}

.barra__buscador {
  max-width: 420px;
}

.pagos__encabezado-configuracion {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-3);
}

.pagos__encabezado-configuracion h2,
.pagos__encabezado-configuracion p,
.pagos__resumen-iva,
.pagos__nota-iva {
  margin: 0;
}

.pagos__encabezado-acciones {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--ct-space-2);
}

.pagos__ajuste-iva {
  display: grid;
  gap: var(--ct-space-4);
}

@media (max-width: 760px) {
  .pagos__encabezado-configuracion {
    align-items: stretch;
    flex-direction: column;
  }

  .pagos__encabezado-acciones {
    justify-content: space-between;
  }
}
</style>
