/**
 * CuTuCo — Lote 25 (CK-0373): la política de contraseña del servidor (GoTrue,
 * supabase/config.toml) debe coincidir con la política del frontend
 * (validation.js): 8-72 ASCII con mayúscula, minúscula, número y símbolo.
 */
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import {
  PASSWORD_MAX_LENGTH,
  PASSWORD_MIN_LENGTH,
  passwordPolicyMessage,
} from '@/lib/validation'

const config = readFileSync('../supabase/config.toml', 'utf8')

function valorConfig(clave) {
  const m = config.match(new RegExp(`^${clave}\\s*=\\s*"?([^"\\n]*)"?`, 'm'))
  return m ? m[1].trim() : null
}

describe('CK-0373 · política de contraseña servidor == frontend', () => {
  it('config.toml exige mínimo 8 y complejidad completa (letras+mayúsculas+dígitos+símbolos)', () => {
    expect(Number(valorConfig('minimum_password_length'))).toBe(PASSWORD_MIN_LENGTH)
    expect(valorConfig('password_requirements')).toBe('lower_upper_letters_digits_symbols')
  })

  it('el frontend rechaza lo que GoTrue ahora rechaza y conserva el dato anterior ante fallo', () => {
    expect(PASSWORD_MIN_LENGTH).toBe(8)
    expect(PASSWORD_MAX_LENGTH).toBe(72)
    expect(passwordPolicyMessage('cort1!A')).toMatch(/al menos 8/)
    expect(passwordPolicyMessage('SinSimbolo123')).toMatch(/símbolo/)
    expect(passwordPolicyMessage('CutucoTest!2026')).toBeNull()
  })

  it('el cambio de contraseña exige la contraseña actual (reauth) y no altera el dato local si falla', () => {
    const auth = readFileSync('src/stores/auth.js', 'utf8')
    expect(auth).toMatch(/passwordActual/)
    expect(auth).toMatch(/updateUser\(\{ password/)
  })
})
