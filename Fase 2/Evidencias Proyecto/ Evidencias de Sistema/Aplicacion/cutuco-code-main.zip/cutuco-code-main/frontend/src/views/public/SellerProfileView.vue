<script setup>
/**
 * CuTuCo — Perfil público del vendedor (RF-022 y RF-006).
 *
 * Navegación sin cuenta: cualquier visitante revisa el nombre comercial del
 * productor, la región donde entrega (según la región de su dirección activa,
 * RF-009), su reputación promedio de 1 a 5 (RF-006) y su catálogo activo.
 *
 * Datos reales: `getProductorDetalle(id)` de `@/services/catalog` entrega el
 * productor, su perfil, su dirección activa (comuna -> región), sus productos
 * activos y sus últimas evaluaciones; `listProductos({ productorId })` refresca
 * el catálogo enriquecido para la grilla.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): aquí no se muestran
 * historial de precios (RF-008), alertas de stock (RF-010), geolocalización ni
 * cobertura por comuna, y no se usa `ReputationGauge`/`ReputationBreakdown`
 * porque esos componentes todavía dependen de `REGLAS.REPUTACION` (score
 * 40/40/20 con pausa automática), que ya no existe en `lib/constants.js`.
 * La reputación se muestra con la regla vigente: promedio simple de 1 a 5.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import ProductGrid from '@/components/domain/ProductGrid.vue'
import portadaFondoUrl from '@/assets/fondo-agro.jpg'
import { STORAGE_BUCKETS } from '@/lib/constants'
import {
  estadoCalificacion,
  filtrarProductosVisibles,
  getProductorDetalle,
  listEvaluacionesPublicasProductor,
  listProductos,
} from '@/services/catalog'
import { useCartStore } from '@/stores/cart'
import { useUiStore } from '@/stores/ui'
import { formatDate, formatNumber } from '@/lib/format'
import { storageUrl } from '@/lib/supabase'
import { reputationTone } from '@/lib/validation'

const route = useRoute()
const cart = useCartStore()
const ui = useUiStore()

const productorId = computed(() => route.params.id)

const detalle = ref(null)
const productos = ref([])
const cargando = ref(true)
const error = ref(null)
const portadaConError = ref(false)
const portadaVersion = ref(Date.now())
const fotoPerfilVersion = ref(Date.now())
const evaluaciones = ref([])
const filtroPuntaje = ref('')
const cargandoEvaluaciones = ref(false)
const errorEvaluaciones = ref(null)
const hayMasEvaluaciones = ref(false)
const contenedorEvaluaciones = ref(null)

const EVALUACIONES_POR_PAGINA = 10
const EVALUACIONES_CON_INDICADOR = EVALUACIONES_POR_PAGINA + 1
const OPCIONES_FILTRO_EVALUACIONES = [
  { value: '', label: 'Todas las estrellas' },
  { value: '5', label: '5 estrellas' },
  { value: '4', label: '4 estrellas' },
  { value: '3', label: '3 estrellas' },
  { value: '2', label: '2 estrellas' },
  { value: '1', label: '1 estrella' },
]
let solicitudEvaluaciones = 0

/** RF-006: promedio simple de las calificaciones de 1 a 5. */
const puntaje = computed(() => {
  const valor = detalle.value?.puntaje_reputacion
  return valor == null ? null : Number(valor)
})
const cantidadEvaluaciones = computed(() => Number(detalle.value?.cantidad_evaluaciones ?? 0))
const semaforo = computed(() => reputationTone(puntaje.value))

/**
 * HAL-CLI-005: el resumen con calificación y el estado vacío son excluyentes.
 * Puede existir un promedio/cantidad sin que la lista de comentarios venga
 * cargada, así que se resuelve con una sola condición.
 */
const tieneCalificaciones = computed(
  () =>
    estadoCalificacion({
      puntaje: puntaje.value,
      cantidadEvaluaciones: cantidadEvaluaciones.value,
      evaluaciones: evaluaciones.value,
    }) === 'resumen',
)

const nombreComercial = computed(() => detalle.value?.nombre_comercial || 'Productor CuTuCo')
const descripcion = computed(
  () =>
    detalle.value?.descripcion ||
    'Este productor todavía no publicó una descripción de su actividad.',
)

/** RF-009: la cobertura del productor es la región de su dirección activa. */
const region = computed(() => detalle.value?.region?.nombre ?? null)
const comuna = computed(() => detalle.value?.comuna?.nombre ?? null)
const ubicacion = computed(
  () => [comuna.value, region.value].filter(Boolean).join(', ') || 'No informada',
)

const contacto = computed(() => detalle.value?.perfil?.telefono ?? null)
const esActivo = computed(() => Boolean(detalle.value?.activo))
const miembroDesde = computed(() => detalle.value?.aprobado_en ?? detalle.value?.creado_en ?? null)

/** La portada publicada por la tienda es pública; si no existe o falla, se usa el fondo agrícola. */
const portadaFondo = computed(() => {
  if (portadaConError.value) return portadaFondoUrl
  const ruta = detalle.value?.portada_storage_path
  const base = ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.portadasTienda }) : null
  if (!base) return portadaFondoUrl
  if (base.startsWith('data:') || base.startsWith('offline:')) return base
  return `${base}${base.includes('?') ? '&' : '?'}v=${portadaVersion.value}`
})

/** Foto de perfil pública configurada por el vendedor; CtAvatar cubre el fallback con iniciales. */
const fotoPerfil = computed(() => {
  const ruta = detalle.value?.foto_perfil_storage_path
  const base = ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresVendedor }) : null
  if (!base || base.startsWith('data:') || base.startsWith('offline:')) return base
  return `${base}${base.includes('?') ? '&' : '?'}v=${fotoPerfilVersion.value}`
})

/** Cada reseña expone sólo el nombre de pila y una ruta de avatar ya pública. */
function nombreClienteEvaluacion(evaluacion) {
  const nombre = String(evaluacion?.cliente_nombre ?? '').trim()
  return nombre || 'Cliente verificado'
}

function fotoClienteEvaluacion(evaluacion) {
  const ruta = String(evaluacion?.cliente_foto_perfil_storage_path ?? '').trim()
  return ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresCliente }) : null
}

function puntajeFiltrado() {
  return [1, 2, 3, 4, 5].includes(Number(filtroPuntaje.value))
    ? Number(filtroPuntaje.value)
    : null
}

function aplicarPaginaEvaluaciones(respuesta, { reiniciar }) {
  const pagina = respuesta.slice(0, EVALUACIONES_POR_PAGINA)
  if (reiniciar) {
    evaluaciones.value = pagina
  } else {
    const idsActuales = new Set(evaluaciones.value.map((evaluacion) => evaluacion.id))
    evaluaciones.value = [
      ...evaluaciones.value,
      ...pagina.filter((evaluacion) => !idsActuales.has(evaluacion.id)),
    ]
  }
  hayMasEvaluaciones.value = respuesta.length > EVALUACIONES_POR_PAGINA
}

async function cargarEvaluaciones({ reiniciar = false } = {}) {
  if (!productorId.value || (cargandoEvaluaciones.value && !reiniciar)) return

  const solicitud = ++solicitudEvaluaciones
  const offset = reiniciar ? 0 : evaluaciones.value.length
  if (reiniciar) {
    evaluaciones.value = []
    hayMasEvaluaciones.value = false
    errorEvaluaciones.value = null
    if (contenedorEvaluaciones.value) contenedorEvaluaciones.value.scrollTop = 0
  }

  cargandoEvaluaciones.value = true
  try {
    const respuesta = await listEvaluacionesPublicasProductor(productorId.value, {
      limit: EVALUACIONES_CON_INDICADOR,
      offset,
      puntaje: puntajeFiltrado(),
    })
    if (solicitud !== solicitudEvaluaciones) return
    aplicarPaginaEvaluaciones(respuesta, { reiniciar })
  } catch (e) {
    if (solicitud !== solicitudEvaluaciones) return
    errorEvaluaciones.value = e?.message ?? 'No se pudieron cargar más comentarios.'
  } finally {
    if (solicitud === solicitudEvaluaciones) cargandoEvaluaciones.value = false
  }
}

function cargarMasEvaluaciones(event) {
  const contenedor = event.currentTarget
  const llegoAlFinal = contenedor.scrollHeight - contenedor.scrollTop - contenedor.clientHeight <= 32
  if (llegoAlFinal && hayMasEvaluaciones.value && !cargandoEvaluaciones.value) {
    cargarEvaluaciones()
  }
}

function reintentarEvaluaciones() {
  // Si la falla ocurrió al pedir otra página, se conserva lo ya leído y se
  // reintenta desde el mismo offset. Para una lista vacía, reinicia el filtro.
  cargarEvaluaciones({ reiniciar: evaluaciones.value.length === 0 })
}

async function cargar() {
  cargando.value = true
  error.value = null
  detalle.value = null
  productos.value = []
  evaluaciones.value = []
  hayMasEvaluaciones.value = false
  errorEvaluaciones.value = null
  solicitudEvaluaciones += 1
  cargandoEvaluaciones.value = false
  portadaConError.value = false
  portadaVersion.value = Date.now()
  fotoPerfilVersion.value = Date.now()
  try {
    const ficha = await getProductorDetalle(productorId.value)
    if (!ficha) {
      error.value =
        'No encontramos el vendedor que buscas. Puede que su tienda ya no esté publicada.'
      return
    }
    detalle.value = ficha
    aplicarPaginaEvaluaciones(Array.isArray(ficha.evaluaciones) ? ficha.evaluaciones : [], {
      reiniciar: true,
    })
    // Sólo el catálogo activo del productor; la ficha ya trae una primera copia.
    const listado = await listProductos({
      productorId: productorId.value,
      soloStock: false,
      pageSize: 60,
    })
    productos.value = filtrarProductosVisibles(
      listado.items.length ? listado.items : (ficha.productos ?? []),
    )
  } catch (e) {
    error.value = e?.message ?? 'No se pudo cargar el perfil del vendedor'
  } finally {
    cargando.value = false
  }
}

function agregar(producto) {
  try {
    cart.agregar(producto)
    ui.success('Producto agregado', `${producto.nombre} está en tu carrito`)
  } catch (e) {
    ui.error('No se pudo agregar', e.message)
  }
}

function usarPortadaPorDefecto() {
  portadaConError.value = true
}

onMounted(cargar)
watch(productorId, () => {
  filtroPuntaje.value = ''
  cargar()
})
watch(filtroPuntaje, () => {
  if (!cargando.value && detalle.value) cargarEvaluaciones({ reiniciar: true })
})
</script>

<template>
  <div class="container page">
    <CtSpinner v-if="cargando" label="Cargando el perfil del vendedor" />

    <CtAlert v-else-if="error" tone="danger" title="No pudimos mostrar este vendedor">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton variant="secondary" size="sm" @click="cargar">Reintentar</CtButton>
      <CtButton variant="secondary" size="sm" to="/catalogo">Volver al catálogo</CtButton>
    </CtAlert>

    <template v-else-if="detalle">
      <header class="perfil-portada">
        <img
          :key="`portada-publica-${portadaVersion}`"
          class="perfil-portada__fondo"
          :src="portadaFondo"
          alt=""
          aria-hidden="true"
          @error="usarPortadaPorDefecto"
        />
        <div class="perfil-portada__contenido">
          <CtButton to="/catalogo" variant="ghost" size="sm" class="volver">
            <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
            Volver al catálogo
          </CtButton>
          <p class="perfil-portada__eyebrow">Tienda en CuTuCo</p>
          <h1 class="perfil-portada__titulo">{{ nombreComercial }}</h1>
          <p class="perfil-portada__subtitulo">
            <CtIcon name="pin" :size="14" />
            {{ ubicacion }} ·
            {{ productos.length }}
            {{ productos.length === 1 ? 'producto publicado' : 'productos publicados' }}
          </p>
        </div>
        <div class="perfil-portada__acciones">
          <CtBadge :tone="esActivo ? 'success' : 'danger'" size="sm" dot>
            {{ esActivo ? 'Tienda activa' : 'Tienda pausada' }}
          </CtBadge>
          <CtButton variant="secondary" :disabled="!productos.length" to="/carrito">
            <template #icon><CtIcon name="cart" :size="16" /></template>
            Ver mi carrito
          </CtButton>
        </div>
      </header>

      <div class="vendedor">
        <div class="vendedor__principal stack">
          <CtCard
            title="Reputación del vendedor"
            subtitle="Promedio simple de las calificaciones de 1 a 5"
          >
            <template v-if="tieneCalificaciones">
              <div class="reputacion">
                <div class="reputacion__score">
                  <span class="reputacion__valor">
                    {{ puntaje != null ? formatNumber(puntaje, 1) : '—' }}
                  </span>
                  <span class="reputacion__max">/ 5.0</span>
                </div>
                <div class="reputacion__meta">
                  <CtRatingStars
                    v-if="puntaje != null"
                    :model-value="puntaje"
                    :size="18"
                    show-value
                  />
                  <CtBadge :tone="semaforo.tone" dot>{{ semaforo.label }}</CtBadge>
                  <p class="reputacion__conteo">
                    {{ cantidadEvaluaciones }}
                    {{
                      cantidadEvaluaciones === 1
                        ? 'evaluación de clientes'
                        : 'evaluaciones de clientes'
                    }}
                  </p>
                </div>
              </div>

              <CtProgressBar :value="puntaje" :max="5" :tone="semaforo.tone" />
            </template>
            <CtAlert v-else tone="neutral" compact>
              Este vendedor todavía no tiene calificaciones. El promedio aparece cuando un cliente
              califica un pedido entregado.
            </CtAlert>
          </CtCard>

          <CtCard
            title="Evaluaciones de clientes"
            subtitle="Filtra por estrellas y desplázate para ver más comentarios"
          >
            <div v-if="tieneCalificaciones" class="evaluaciones__filtros">
              <CtSelect
                v-model="filtroPuntaje"
                label="Filtrar evaluaciones"
                size="sm"
                :options="OPCIONES_FILTRO_EVALUACIONES"
              />
            </div>

            <div
              v-if="evaluaciones.length"
              ref="contenedorEvaluaciones"
              class="evaluaciones__scroll"
              role="region"
              aria-label="Comentarios de clientes"
              :aria-busy="cargandoEvaluaciones || undefined"
              tabindex="0"
              @scroll.passive="cargarMasEvaluaciones"
            >
              <ul class="evaluaciones">
              <li v-for="evaluacion in evaluaciones" :key="evaluacion.id" class="evaluacion">
                <div class="evaluacion__head">
                  <div class="evaluacion__autor">
                    <CtAvatar
                      :src="fotoClienteEvaluacion(evaluacion)"
                      :name="nombreClienteEvaluacion(evaluacion)"
                      :size="36"
                    />
                    <div class="evaluacion__calificacion">
                      <span class="evaluacion__cliente">{{ nombreClienteEvaluacion(evaluacion) }}</span>
                      <CtRatingStars :model-value="Number(evaluacion.puntaje)" :size="14" show-value />
                    </div>
                  </div>
                  <span class="text-xs text-muted">{{ formatDate(evaluacion.creado_en) }}</span>
                </div>
                <p v-if="evaluacion.comentario" class="evaluacion__comentario">
                  {{ evaluacion.comentario }}
                </p>
                <p v-else class="evaluacion__comentario is-vacio">
                  El cliente calificó sin dejar comentario.
                </p>
              </li>
              </ul>
              <CtSpinner
                v-if="cargandoEvaluaciones"
                :size="18"
                inline
                label="Cargando más comentarios…"
                class="evaluaciones__cargando"
              />
              <p v-else-if="hayMasEvaluaciones" class="evaluaciones__ayuda">
                Desplázate hacia abajo para cargar más comentarios.
              </p>
            </div>
            <CtSpinner
              v-else-if="cargandoEvaluaciones"
              :size="22"
              inline
              label="Cargando comentarios…"
            />
            <template v-else-if="tieneCalificaciones">
              <p class="evaluaciones__nota">
                {{
                  filtroPuntaje
                    ? `No hay evaluaciones de ${filtroPuntaje} ${filtroPuntaje === '1' ? 'estrella' : 'estrellas'} para mostrar.`
                    : 'El vendedor tiene calificaciones registradas, pero no hay comentarios públicos para mostrar.'
                }}
              </p>
              <CtButton
                v-if="errorEvaluaciones"
                variant="secondary"
                size="sm"
                class="evaluaciones__reintentar"
                @click="reintentarEvaluaciones"
              >
                Reintentar
              </CtButton>
            </template>
            <CtAlert v-if="errorEvaluaciones && evaluaciones.length" tone="warning" compact>
              <p class="linea">
                <CtIcon name="alert" :size="15" />
                <span>{{ errorEvaluaciones }}</span>
              </p>
              <CtButton variant="secondary" size="sm" @click="reintentarEvaluaciones">
                Reintentar
              </CtButton>
            </CtAlert>
            <CtEmptyState
              v-if="!tieneCalificaciones"
              icon="star"
              compact
              title="Sin valoraciones todavía"
              message="Cuando los clientes califiquen sus pedidos entregados, verás aquí sus comentarios."
            />
          </CtCard>

          <section class="bloque">
            <header class="bloque__head">
              <div class="bloque__text">
                <h2 class="bloque__titulo">Catálogo activo</h2>
                <p class="bloque__subtitulo">Productos publicados por este vendedor</p>
              </div>
            </header>

            <ProductGrid
              :productos="productos"
              show-rating
              show-category
              empty-title="Este vendedor no tiene productos publicados"
              empty-message="Vuelve pronto: el productor publica su cosecha a medida que está disponible."
              @add="agregar"
            />
          </section>
        </div>

        <aside class="vendedor__lateral stack">
          <CtCard title="Datos de la tienda" padding="md">
            <div class="identidad">
              <CtAvatar
                class="identidad__avatar"
                :src="fotoPerfil"
                :name="nombreComercial"
                :size="56"
              />
              <div>
                <p class="identidad__nombre">{{ nombreComercial }}</p>
                <p class="identidad__lugar">{{ ubicacion }}</p>
              </div>
            </div>

            <p class="identidad__descripcion">{{ descripcion }}</p>

            <dl class="datos">
              <div class="dato">
                <dt class="dato__label">Región de entrega</dt>
                <dd class="dato__valor">{{ region ?? 'No informada' }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Comuna de origen</dt>
                <dd class="dato__valor">{{ comuna ?? 'No informada' }}</dd>
              </div>
              <div v-if="contacto" class="dato">
                <dt class="dato__label">Teléfono de contacto</dt>
                <dd class="dato__valor">{{ contacto }}</dd>
              </div>
              <div v-if="miembroDesde" class="dato">
                <dt class="dato__label">Productor desde</dt>
                <dd class="dato__valor">{{ formatDate(miembroDesde) }}</dd>
              </div>
            </dl>

            <CtAlert tone="info" compact>
              <p class="linea">
                <CtIcon name="info" :size="15" />
                <span>
                  CuTuCo compara tu región de entrega con la de este vendedor antes de crear el
                  pago. Si no coinciden, la compra se bloquea con el motivo indicado.
                </span>
              </p>
            </CtAlert>
          </CtCard>

          <div class="grid-kpi">
            <CtStatCard
              label="Productos activos"
              :value="productos.length"
              tone="primary"
              hint="Publicados en el catálogo"
            />
            <CtStatCard
              label="Evaluaciones"
              :value="cantidadEvaluaciones"
              tone="info"
              hint="Pedidos calificados"
            />
          </div>

          <CtCard title="Compra protegida" padding="md" flat>
            <ul class="garantias">
              <li>
                <CtIcon name="lock" :size="15" />
                <span
                  >Pago seguro con Webpay: el productor recibe el pago de su venta y CuTuCo descuenta
                  su comisión.</span
                >
              </li>
              <li>
                <CtIcon name="check" :size="15" />
                <span>La entrega se cierra con el código de verificación del pedido.</span>
              </li>
            </ul>
            <CtButton block variant="secondary" to="/catalogo">
              <template #icon><CtIcon name="catalog" :size="15" /></template>
              Explorar más productores
            </CtButton>
          </CtCard>
        </aside>
      </div>
    </template>
  </div>
</template>

<style scoped>
.perfil-portada {
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  min-height: 260px;
  gap: var(--ct-space-6);
  overflow: hidden;
  padding: var(--ct-space-8);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-ink);
  color: var(--ct-text-invert);
}

.perfil-portada::after {
  position: absolute;
  z-index: 0;
  inset: 0;
  content: '';
  background: linear-gradient(
    90deg,
    rgba(12, 25, 20, 0.88) 0%,
    rgba(12, 25, 20, 0.62) 58%,
    rgba(12, 25, 20, 0.38) 100%
  );
}

.perfil-portada__fondo {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.8;
  pointer-events: none;
}

.perfil-portada__contenido,
.perfil-portada__acciones {
  position: relative;
  z-index: 1;
}

.perfil-portada__contenido {
  min-width: 0;
  max-width: 760px;
}

.volver {
  margin-bottom: var(--ct-space-6);
  color: var(--ct-text-invert);
  border-color: rgba(255, 255, 255, 0.45);
  background: rgba(0, 0, 0, 0.16);
}

.volver:hover {
  color: var(--ct-text-invert);
  border-color: rgba(255, 255, 255, 0.75);
  background: rgba(0, 0, 0, 0.3);
}

.perfil-portada__eyebrow,
.perfil-portada__titulo,
.perfil-portada__subtitulo {
  margin: 0;
}

.perfil-portada__eyebrow {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: var(--ct-tracking-wide);
  text-transform: uppercase;
  color: var(--ct-primary-soft);
}

.perfil-portada__titulo {
  margin-top: var(--ct-space-2);
  font-size: clamp(var(--ct-fs-2xl), 4vw, var(--ct-fs-4xl));
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  overflow-wrap: anywhere;
}

.perfil-portada__subtitulo {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  margin-top: var(--ct-space-3);
  color: var(--ct-primary-soft);
}

.perfil-portada__acciones {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
  flex: 0 0 auto;
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

@media (max-width: 720px) {
  .perfil-portada {
    align-items: flex-start;
    flex-direction: column;
    min-height: 0;
    padding: var(--ct-space-6);
  }

  .perfil-portada::after {
    background: rgba(12, 25, 20, 0.72);
  }

  .perfil-portada__acciones {
    justify-content: flex-start;
  }
}

.vendedor {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

.vendedor__principal,
.vendedor__lateral {
  min-width: 0;
}

@media (max-width: 1100px) {
  .vendedor {
    grid-template-columns: minmax(0, 1fr);
  }
}

/* --------------------------- reputación --------------------------- */

.reputacion {
  display: flex;
  align-items: center;
  gap: var(--ct-space-5);
  flex-wrap: wrap;
  margin-bottom: var(--ct-space-4);
}

.reputacion__score {
  display: flex;
  align-items: baseline;
  gap: 2px;
}

.reputacion__valor {
  font-size: var(--ct-fs-4xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  line-height: 1;
  color: var(--ct-primary-strong);
}

.reputacion__max {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-muted);
}

.reputacion__meta {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
}

.reputacion__conteo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.evaluaciones {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.evaluaciones__filtros {
  width: min(100%, 18rem);
  margin-bottom: var(--ct-space-4);
}

.evaluaciones__scroll {
  max-height: min(38rem, 70dvh);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-gutter: stable;
  padding-right: var(--ct-space-3);
}

.evaluaciones__scroll:focus-visible {
  outline: none;
  box-shadow: var(--ct-shadow-focus);
  border-radius: var(--ct-radius);
}

.evaluaciones__cargando,
.evaluaciones__ayuda {
  margin: var(--ct-space-4) 0 0;
}

.evaluaciones__ayuda,
.evaluaciones__nota {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
  line-height: var(--ct-lh-relaxed);
}

.evaluaciones__reintentar {
  margin-top: var(--ct-space-3);
}

.evaluacion {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-4) 0;
  border-bottom: 1px solid var(--ct-border);
}

.evaluacion:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.evaluacion__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.evaluacion__autor {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  min-width: 0;
}

.evaluacion__calificacion {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  min-width: 0;
}

.evaluacion__cliente {
  max-width: 18rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.evaluacion__comentario {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.evaluacion__comentario.is-vacio {
  color: var(--ct-text-muted);
  font-style: italic;
}

/* ---------------------------- catálogo ---------------------------- */

.bloque {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.bloque__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--ct-space-4);
}

.bloque__titulo {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

.bloque__subtitulo {
  margin-top: var(--ct-space-1);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-md);
}

/* ---------------------------- lateral ---------------------------- */

.identidad {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  position: relative;
}

.identidad__avatar {
  position: relative;
  z-index: 0;
  flex-shrink: 0;
  box-shadow: var(--ct-shadow-sm);
  cursor: zoom-in;
  transform-origin: left center;
  transition:
    transform var(--ct-transition),
    box-shadow var(--ct-transition);
}

@media (hover: hover) and (pointer: fine) {
  .identidad__avatar:hover {
    z-index: 2;
    transform: scale(2.85);
    box-shadow: var(--ct-shadow-lg);
  }
}

.identidad__nombre {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: var(--ct-tracking-tight);
}

.identidad__lugar {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.identidad__descripcion {
  margin-top: var(--ct-space-3);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: var(--ct-space-5) 0 0;
}

.dato {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  text-align: right;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.garantias {
  list-style: none;
  margin: 0 0 var(--ct-space-4);
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.garantias li {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.garantias li > svg {
  color: var(--ct-primary-strong);
  margin-top: 2px;
}
</style>
