<script setup>
/** CuTuCo — Selector desplegable con soporte de grupos y búsqueda por texto. */
import { computed, ref, useId, onMounted, onBeforeUnmount } from 'vue'
import CtIcon from './CtIcon.vue'
import { normalizarTextoComparable } from '@/services/catalog'

const props = defineProps({
  modelValue: { type: [String, Number, null], default: null },
  label: { type: String, default: null },
  hint: { type: String, default: null },
  error: { type: String, default: null },
  options: { type: Array, default: () => [] }, // [{ value, label, disabled, group }]
  placeholder: { type: String, default: 'Seleccionar…' },
  disabled: { type: Boolean, default: false },
  required: { type: Boolean, default: false },
  clearable: { type: Boolean, default: false },
  size: { type: String, default: 'md' },
  /** Cuando es true, el control permite escribir para filtrar las opciones. */
  searchable: { type: Boolean, default: false },
})

const emit = defineEmits(['update:modelValue', 'change'])

const id = useId()
const errorId = `${id}-error`
const hintId = `${id}-hint`

const value = computed({
  get: () => props.modelValue,
  set: (v) => {
    emit('update:modelValue', v)
    emit('change', v)
  },
})

const descritoPor = computed(() => (props.error ? errorId : props.hint ? hintId : undefined))

/** Texto completo de la opción elegida (el control puede truncarlo con «…»). */
const etiquetaSeleccionada = computed(() => {
  const opcion = props.options.find((o) => String(o.value) === String(props.modelValue ?? ''))
  return opcion?.label ?? ''
})

/** Agrupa las opciones por `group` cuando existe. */
const grouped = computed(() => {
  const hasGroups = props.options.some((o) => o.group)
  if (!hasGroups) return [{ label: null, items: props.options }]
  const map = new Map()
  for (const option of props.options) {
    const key = option.group ?? ''
    if (!map.has(key)) map.set(key, [])
    map.get(key).push(option)
  }
  return [...map.entries()].map(([label, items]) => ({ label, items }))
})

/* ---------- Modo buscable (combobox) ---------- */
const abierto = ref(false)
const busqueda = ref('')
const rootRef = ref(null)

const opcionesFiltradas = computed(() => {
  const q = normalizarTextoComparable(busqueda.value)
  if (!q) return grouped.value
  return grouped.value
    .map((g) => ({
      label: g.label,
      items: g.items.filter((o) => normalizarTextoComparable(o.label).includes(q)),
    }))
    .filter((g) => g.items.length > 0)
})

function abrir() {
  if (props.disabled) return
  busqueda.value = ''
  abierto.value = true
}

function elegir(option) {
  if (option.disabled) return
  value.value = option.value
  abierto.value = false
  busqueda.value = ''
}

function cerrarFuera(e) {
  if (rootRef.value && !rootRef.value.contains(e.target)) {
    abierto.value = false
    busqueda.value = ''
  }
}

onMounted(() => document.addEventListener('click', cerrarFuera))
onBeforeUnmount(() => document.removeEventListener('click', cerrarFuera))
</script>

<template>
  <label class="ct-select__wrap" :for="id" ref="rootRef">
    <span v-if="label" class="ct-select__label">
      {{ label }}
      <span v-if="required" class="ct-select__required">*</span>
    </span>
    <!-- Modo buscable: el dropdown va dentro de un contenedor relativo aparte
         del control (el control tiene overflow:hidden y recortaría la lista). -->
    <template v-if="searchable">
      <span class="ct-select__anchor">
        <span class="ct-select__control" :class="[`ct-select__control--${size}`, { 'is-error': error }]">
        <input
          :id="id"
          type="text"
          class="ct-select__search"
          :value="abierto ? busqueda : etiquetaSeleccionada"
          :placeholder="etiquetaSeleccionada || placeholder"
          :disabled="disabled"
          :aria-invalid="Boolean(error) || undefined"
          :aria-describedby="descritoPor"
          role="combobox"
          :aria-expanded="abierto"
          autocomplete="off"
          @focus="abrir"
          @click.stop="abrir"
          @input="busqueda = $event.target.value; abierto = true"
        />
        <span class="ct-select__arrow" aria-hidden="true"><CtIcon name="chevronDown" :size="15" /></span>
        </span>
        <div v-if="abierto" class="ct-select__dropdown" role="listbox">
        <p v-if="!opcionesFiltradas.length" class="ct-select__empty">Sin coincidencias</p>
        <template v-for="group in opcionesFiltradas" :key="group.label ?? 'sin-grupo'">
          <p v-if="group.label" class="ct-select__group-label">{{ group.label }}</p>
          <button
            v-for="option in group.items"
            :key="option.value"
            type="button"
            class="ct-select__option"
            :class="{ 'is-selected': String(option.value) === String(modelValue ?? '') }"
            :disabled="option.disabled"
            role="option"
            @click.stop="elegir(option)"
          >
            {{ option.label }}
          </button>
        </template>
      </div>
      </span>
    </template>
    <span v-else class="ct-select__control" :class="[`ct-select__control--${size}`, { 'is-error': error }]">
      <select
        :id="id"
        v-model="value"
        class="ct-select__select"
        :disabled="disabled"
        :aria-invalid="Boolean(error) || undefined"
        :aria-describedby="descritoPor"
        :title="etiquetaSeleccionada || undefined"
      >
        <option :value="null" disabled>{{ placeholder }}</option>
        <template v-for="group in grouped" :key="group.label ?? 'sin-grupo'">
          <optgroup v-if="group.label" :label="group.label">
            <option
              v-for="option in group.items"
              :key="option.value"
              :value="option.value"
              :disabled="option.disabled"
            >
              {{ option.label }}
            </option>
          </optgroup>
          <template v-else>
            <option
              v-for="option in group.items"
              :key="option.value"
              :value="option.value"
              :disabled="option.disabled"
            >
              {{ option.label }}
            </option>
          </template>
        </template>
      </select>
      <span class="ct-select__arrow" aria-hidden="true"><CtIcon name="chevronDown" :size="15" /></span>
    </span>
    <span v-if="error" :id="errorId" class="ct-select__error" role="alert">{{ error }}</span>
    <span v-else-if="hint" :id="hintId" class="ct-select__hint">{{ hint }}</span>
    <button
      v-if="clearable && modelValue"
      type="button"
      class="ct-select__clear"
      @click.prevent.stop="value = null"
    >
      Limpiar
    </button>
  </label>
</template>

<style scoped>
.ct-select__wrap {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  position: relative;
  min-width: 0;
}

.ct-select__label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
}

.ct-select__required {
  color: var(--ct-danger);
}

.ct-select__control {
  display: flex;
  align-items: center;
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  position: relative;
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-select__control:hover:not(:focus-within) {
  border-color: var(--ct-border-strong);
}

.ct-select__control--sm {
  height: 36px;
}
.ct-select__control--md {
  height: 42px;
}
.ct-select__control--lg {
  height: 48px;
}

.ct-select__control:focus-within {
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-select__control.is-error {
  border-color: var(--ct-danger);
}

.ct-select__select {
  flex: 1 1 0%;
  width: 100%;
  min-width: 0;
  max-width: 100%;
  appearance: none;
  background: transparent;
  border: none;
  outline: none;
  padding: 0 var(--ct-space-8) 0 var(--ct-space-3);
  height: 100%;
  min-height: 36px;
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
  cursor: pointer;
  border-radius: inherit;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ct-select__arrow {
  position: absolute;
  right: var(--ct-space-3);
  top: 50%;
  transform: translateY(-50%);
  color: var(--ct-text-muted);
  pointer-events: none;
  font-size: 0.8rem;
  flex-shrink: 0;
}

.ct-select__hint {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ct-select__error {
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
  font-weight: var(--ct-fw-medium);
}

.ct-select__clear {
  position: absolute;
  right: 0;
  bottom: 0;
  padding: 0;
  border: 0;
  background: none;
  font-size: var(--ct-fs-xs);
  color: var(--ct-primary-strong);
  cursor: pointer;
}

/* ---------- Modo buscable ---------- */
.ct-select__anchor {
  position: relative;
  display: block;
  min-width: 0;
}

.ct-select__search {
  flex: 1 1 0%;
  width: 100%;
  min-width: 0;
  height: 100%;
  min-height: 36px;
  border: none;
  outline: none;
  background: transparent;
  padding: 0 var(--ct-space-8) 0 var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
}

.ct-select__search::placeholder {
  color: var(--ct-text-faint);
}

.ct-select__dropdown {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  max-height: 260px;
  overflow-y: auto;
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  box-shadow: var(--ct-shadow-md);
  z-index: 70;
  padding: var(--ct-space-1);
}

.ct-select__group-label {
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  padding: var(--ct-space-2) var(--ct-space-2) var(--ct-space-1);
}

.ct-select__option {
  display: block;
  width: 100%;
  text-align: left;
  padding: 0.45rem var(--ct-space-2);
  border-radius: var(--ct-radius-sm);
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
  cursor: pointer;
}

.ct-select__option:hover:not(:disabled) {
  background: var(--ct-surface-alt);
}

.ct-select__option.is-selected {
  background: var(--ct-primary);
  color: var(--ct-text-invert);
  font-weight: var(--ct-fw-semibold);
}

/* La regla general :hover tiene mayor especificidad y antes devolvía la opción
   seleccionada a un fondo casi blanco. El amarillo semitransparente conserva
   el estado de interacción y se aplica a cada CtSelect de la aplicación. */
.ct-select__option.is-selected:hover:not(:disabled),
.ct-select__option.is-selected:focus-visible {
  background: var(--ct-accent-tint-50);
  color: var(--ct-accent-ink);
}

.ct-select__option:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ct-select__empty {
  padding: var(--ct-space-3) var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}
</style>
