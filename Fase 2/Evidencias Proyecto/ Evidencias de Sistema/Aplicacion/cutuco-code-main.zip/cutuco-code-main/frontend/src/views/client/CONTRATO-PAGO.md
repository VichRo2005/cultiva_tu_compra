# CuTuCo — Contrato de pago Webpay Mall Plus (RF-005)

> Documento vivo del flujo de pago. Describe el modelo **Webpay Mall Plus**
> vigente (las migraciones `20261010010000_webpay_mall_postulaciones.sql` y
> `20261012000000_checkout_mall_backend.sql` eliminaron la custodia/escrow y los
> pedidos se crean DENTRO del commit).
>
> Modelo anterior, **eliminado**: CuTuCo retenía el 100% de la venta
> (`pagos.estado='retenido'`, `pedidos.monto_retenido`), el administrador
> liberaba el payout a mano (`payouts`, RPC `registrar_payout_pagado`) y los
> reembolsos se registraban con `registrar_devolucion_cliente`. Hoy el commit
> confirma la autorización de los cobros Mall: CuTuCo cobra su comisión del 5 %
> como *detail* propio y el resto se asigna al comercio hijo del productor.
> La autorización no acredita el abono bancario; este depende del contrato
> y del calendario de liquidación de Transbank.
> No hay custodia, ni payouts, ni liberación posterior.

## 1. Inicio del pago (`CheckoutView.vue`)

`POST {VITE_API_BASE_URL}/api/webpay/iniciar` con el JWT de Supabase en
`Authorization: Bearer <access_token>` (lo hace `iniciarPago()` de
`@/services/orders`).

```json
{
  "direccion_id": "uuid de public.direcciones del cliente",
  "items": [{ "producto_id": "uuid", "cantidad": 2 }],
  "monto_esperado": 13500,
  "nombre_destinatario": "opcional",
  "telefono_destinatario": "opcional",
  "referencia_entrega": "opcional",
  "documento_tributario": { "tipo": "boleta" }
}
```

`documento_tributario`:
- `{ "tipo": "boleta" }` (default): el backend asigna el RUT genérico
  `66666666-6` automáticamente.
- `{ "tipo": "factura", "rut_empresa", "razon_social", "giro", "direccion_tributaria" }`.

El checkout autocompleta la factura con
`GET {VITE_API_BASE_URL}/api/tributario/empresa/{rut}` (JWT):
200 `{"existe":true,"rut","razon_social","giro"}` · 404 sin datos · 422 RUT
inválido · 502 proveedor caído (mensaje genérico).

Antes de llamar al endpoint, el frontend valida la región del vendedor contra
la región de la dirección de entrega (RF-009); el backend la vuelve a validar.

El navegador envía `monto_esperado` con el total CLP que el comprador aceptó.
El servidor calcula el monto desde los productos bloqueados y las tarifas
vigentes; si no coincide, devuelve 409 antes de reservar stock o llamar a
Webpay. El cliente debe revisar el total actualizado y aceptar sus cambios.
El campo es opcional para conservar compatibilidad con clientes existentes;
nunca sustituye el cálculo del servidor ni permite fijar un precio arbitrario.

Respuesta 200:

```json
{
  "checkout_id": "uuid",
  "buy_order": "CHK-…",
  "token_ws": "01ab…",
  "url": "https://webpay3gint.transbank.cl/webpayserver/initTransaction",
  "monto": 13500
}
```

**Redirección obligatoria por POST** (Webpay recibe el token en el cuerpo):

```html
<form ref="formWebpay" method="post" :action="respuesta.url">
  <input type="hidden" name="token_ws" :value="respuesta.token_ws" />
</form>
```

El carrito se vacía sólo después de confirmar el pago, no al iniciar.

## 2. Retorno: los 4 escenarios de Transbank (`PaymentResultView.vue`)

`TRANSBANK_RETURN_URL` apunta al endpoint público
`/api/webpay/retorno` del backend. Tras confirmar el retorno de Webpay, FastAPI
redirige por GET al historial `/cliente/pedidos`; el router desvía esa ruta a
`/pago/retorno` cuando llega con parámetros de Webpay.

| # | Parámetros | Significado | Acción de la app |
|---|-----------|-------------|------------------|
| 1 | `token_ws` | pago normal | `POST /api/webpay/confirmar` y mostrar resultado |
| 2 | `TBK_ID_SESION` + `TBK_ORDEN_COMPRA` | sesión >10 min expirada | no confirmar; "sesión de pago expirada" |
| 3 | sólo `TBK_TOKEN` | el usuario anuló el pago | no confirmar; "pago anulado" |
| 4 | `token_ws` **y** `TBK_TOKEN` | transacción INVÁLIDA | **NO confirmar nunca**; mensaje de inválido |

Sin parámetros: "pago pendiente" con opción de reintentar.

## 3. `POST /api/webpay/confirmar` — el pedido se crea DENTRO del commit

Body: `{ "token_ws": "01ab…" }`

Respuesta 200:

```json
{
  "ok": true,
  "checkout_id": "uuid",
  "pedidos": [
    { "pedido_id": "uuid", "productor_id": "uuid", "estado_pedido": "pagado", "total": 13500 }
  ],
  "estado": "autorizado",
  "requiere_conciliacion": false,
  "ya_confirmado": false
}
```

Con Mall el pedido **no puede crearse antes del pago** (cada detail del mall es
un productor con su propio monto). El backend:

1. `iniciar`: valida cobertura (RF-009), stock y datos; guarda el **checkout**
   (payload completo) y crea la transacción Mall con un detail por productor
   (monto del productor; el 5 % de CuTuCo va como detail propio del mall).
2. `confirmar` (`tx.commit`): si Transbank autoriza, **dentro de la misma
   operación** crea los pedidos (`estado='pagado'`), sus detalles, los envíos
   (`preparacion`) y las filas de `pagos` (comprobante autorizado), y marca el
   checkout como confirmado.

Campos de la respuesta:

- **`pedidos[]`**: lista de pedidos creados (uno por productor del carrito).
  La vista muestra un enlace "Ver seguimiento" a `/cliente/pedidos/{pedido_id}`
  por cada uno.
- **`estado`**: `autorizado` (todo), `parcial` (sólo algunos comercios hijos)
  o `rechazado` (nada autorizado; no hay cargo).
- **`requiere_conciliacion: true`**: Transbank reportó un dato que no calza
  con el comprobante esperado; el administrador lo revisa en conciliación
  diaria. La vista muestra un aviso honesto.
- **`ya_confirmado: true`** (idempotencia): el token ya se había procesado; la
  respuesta se devuelve igual y no hay doble cargo. La vista muestra el mensaje
  idempotente.

## 4. Idempotencia

- El checkout guarda `token_ws` con UNIQUE: repetir `confirmar` con el mismo
  token devuelve la misma respuesta con `ya_confirmado: true` sin duplicar
  pedidos ni cargos.
- Recargar `/pago/retorno?token_ws=…` es seguro por diseño.

## 5. `GET /api/webpay/estado/{pedido_id}`

```json
{
  "pedido_id": "uuid",
  "codigo_pedido": "CUTU-20261010-AB12CD",
  "estado_pedido": "pagado",
  "estado_pago": "autorizado",
  "monto_productor": 12825,
  "total": 13500,
  "envio": { "estado": "preparacion" }
}
```

`pagos` (PostgREST/RLS) guarda **únicamente el comprobante exitoso**, escrito
por FastAPI con service_role: la fila existe sólo cuando el cobro quedó
autorizado, por eso `services/orders.js` deriva `estado: 'autorizado'` al
leerla. Lectura: participantes del pedido (`pagos_select_participantes`) y
administrador (`pagos_select_admin`; usado por `listPagos()` y la vista
informativa `AdminPaymentsView`).

## 6. Post-entrega: sin liberación de fondos

1. El vendedor marca el envío `en_transito`; el trigger genera el código de
   verificación del pedido (RF-007).
2. **El cliente recibe el código** en su seguimiento y se lo entrega al vendedor.
   El vendedor lo ingresa con `verificar_codigo_entrega_vendedor`; sólo el
   vendedor del pedido (o el servicio interno) puede validarlo. El cliente no
   puede leer la columna `envios.codigo_verificacion` por PostgREST: la obtiene
   con la RPC `obtener_codigo_entrega` (sólo el cliente del pedido o un
   administrador).
3. El vendedor marca el envío `entregado`; el trigger deja el pedido
   `completado`.
4. El cliente confirma la recepción (`confirmar_recepcion_pedido`): queda
   `confirmado_cliente_en` para trazabilidad y puede calificar al vendedor.

**No hay liberación de fondos en este paso**: el commit autoriza los cobros
asignados al productor y a CuTuCo. La entrega no ejecuta una transferencia
bancaria ni demuestra que Transbank haya abonado los fondos.

## 7. Reclamos

Un reclamo abierto (`reclamos` en `abierto`/`en_revision`) **no bloquea
dinero**: la aplicación no mantiene una custodia de fondos. Lo tramita el administrador
y, de proceder, el reembolso se gestiona con el comercio del productor
(RF-025/RF-026).
