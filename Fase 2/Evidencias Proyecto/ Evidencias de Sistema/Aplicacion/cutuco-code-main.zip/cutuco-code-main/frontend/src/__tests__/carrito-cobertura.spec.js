import { beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const geo = vi.hoisted(() => ({ getRegionProductor: vi.fn(), getRegionDeDireccion: vi.fn() }))
vi.mock('@/services/geography', () => geo)
vi.mock('@/stores/auth', () => ({ useAuthStore: () => ({ user: null }) }))
import { useCartStore } from '@/stores/cart'

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  geo.getRegionDeDireccion.mockResolvedValue({ region: { id: 'rm', nombre: 'Metropolitana' } })
})

it('identifica solo la tienda fuera de cobertura y verifica todos los vendedores', async () => {
  const cart = useCartStore()
  for (const id of ['v1', 'v2']) cart.agregar({ id, productor_id: id, stock: 5, precio: 1000, unidad_medida: 'unidad', productor: { nombre_comercial: id } })
  geo.getRegionProductor.mockImplementation(async (id) => ({ id: id === 'v1' ? 'rm' : 'v' }))
  const result = await cart.validarCobertura({ comuna_id: 'c1' })
  expect(result.ok).toBe(false)
  expect(result.productoresFuera).toEqual(['v2'])
  expect(result.motivo).toContain('v2')
  expect(geo.getRegionProductor).toHaveBeenCalledWith('v1')
  expect(geo.getRegionProductor).toHaveBeenCalledWith('v2')
})

it('un fallo de red no conserva una cobertura aprobada anterior', async () => {
  const cart = useCartStore()
  cart.agregar({ id: 'p1', productor_id: 'v1', stock: 5, precio: 1000 })
  cart.cobertura = { ok: true }
  geo.getRegionProductor.mockRejectedValue(new Error('red'))
  await expect(cart.validarCobertura({ comuna_id: 'c1' })).rejects.toThrow('red')
  expect(cart.cobertura).toBeNull()
  expect(cart.validandoCobertura).toBe(false)
})

it.each(['cliente', 'vendedor'])('bloquea cobertura si falta la región del %s', async (origen) => {
  const cart = useCartStore()
  cart.agregar({ id: 'p1', productor_id: 'v1', stock: 5, precio: 1000 })
  cart.cobertura = { ok: true }
  geo.getRegionProductor.mockResolvedValue(origen === 'vendedor' ? null : { id: 'rm' })
  if (origen === 'cliente') geo.getRegionDeDireccion.mockResolvedValue({ region: null })
  const resultado = await cart.validarCobertura({ comuna_id: 'c1' })
  expect(resultado.ok).toBe(false)
  expect(resultado.motivo).toContain('no tiene una región registrada')
  expect(cart.cobertura.ok).toBe(false)
})

it('habilita cobertura cuando todas las tiendas comparten la región del destino', async () => {
  const cart = useCartStore()
  for (const id of ['v1', 'v2']) {
    cart.agregar({ id, productor_id: id, stock: 5, precio: 1000 })
  }
  geo.getRegionProductor.mockResolvedValue({ id: 'rm' })
  expect((await cart.validarCobertura({ comuna_id: 'c1' })).ok).toBe(true)
  expect(cart.cobertura.productoresFuera).toEqual([])
})
