<script setup>
/** CuTuCo — Gráfico de trazabilidad de precios de un producto. */
import { computed } from 'vue'
import CtChart from '@/components/base/CtChart.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import { formatCLP, formatDate, formatDayMonth } from '@/lib/format'

const props = defineProps({
  historial: { type: Array, default: () => [] },
  precioActual: { type: [Number, String], default: null },
  height: { type: Number, default: 260 },
  showReference: { type: Boolean, default: true },
  compact: { type: Boolean, default: false },
})

const rows = computed(() =>
  [...props.historial].sort((a, b) => new Date(a.registrado_en) - new Date(b.registrado_en)),
)

/** Etiquetas alineadas por fecha para mezclar ambas fuentes en un solo eje. */
const labelsAlineados = computed(() =>
  rows.value.map((r) => (r.fuente === 'marketplace' ? formatDayMonth(r.registrado_en) : '')),
)

const datasetsAlineados = computed(() => {
  const marketplace = []
  const referencia = []
  for (const row of rows.value) {
    if (row.fuente === 'marketplace') {
      marketplace.push(Number(row.precio_nuevo))
      referencia.push(null)
    } else {
      marketplace.push(marketplace.length ? marketplace[marketplace.length - 1] : null)
      referencia.push(Number(row.precio_nuevo))
    }
  }
  return [
    { label: 'Precio CuTuCo', data: marketplace, borderColor: '#2E7D32', pointRadius: 3 },
    {
      label: 'Referencia externa',
      data: referencia,
      color: '#FF9800',
      borderDash: [6, 4],
      pointRadius: 4,
      fill: false,
    },
  ]
})

const variaciones = computed(() => {
  const marketplace = rows.value.filter((r) => r.fuente === 'marketplace')
  if (marketplace.length < 2) return null
  const primero = Number(marketplace[0].precio_nuevo)
  const ultimo = Number(marketplace[marketplace.length - 1].precio_nuevo)
  const pct = primero ? Math.round(((ultimo - primero) / primero) * 1000) / 10 : 0
  return { primero, ultimo, pct }
})
</script>

<template>
  <div class="ct-price-history">
    <div v-if="variaciones || precioActual" class="ct-price-history__summary">
      <div v-if="precioActual" class="ct-price-history__stat">
        <span class="ct-price-history__caption">Precio actual</span>
        <strong>{{ formatCLP(precioActual) }}</strong>
      </div>
      <div v-if="variaciones" class="ct-price-history__stat">
        <span class="ct-price-history__caption">Variación del período</span>
        <CtBadge :tone="variaciones.pct >= 0 ? 'danger' : 'success'" size="sm">
          <CtIcon :name="variaciones.pct >= 0 ? 'arrowUp' : 'arrowDown'" :size="12" />
          {{ Math.abs(variaciones.pct) }}%
        </CtBadge>
      </div>
      <div v-if="rows.length" class="ct-price-history__stat">
        <span class="ct-price-history__caption">Registros</span>
        <strong>{{ rows.length }}</strong>
      </div>
      <div v-if="rows.length" class="ct-price-history__stat">
        <span class="ct-price-history__caption">Última actualización</span>
        <strong>{{ formatDate(rows[rows.length - 1].registrado_en) }}</strong>
      </div>
    </div>

    <CtChart
      v-if="rows.length > 1"
      type="line"
      :labels="labelsAlineados"
      :datasets="datasetsAlineados"
      :height="height"
      :fill="!compact"
      currency
    />
    <p v-else class="ct-price-history__empty">
      Aún no hay suficientes registros de precio para graficar este producto.
    </p>
  </div>
</template>

<style scoped>
.ct-price-history {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.ct-price-history__summary {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-6);
}

.ct-price-history__stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ct-price-history__caption {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.04em;
  font-weight: var(--ct-fw-semibold);
}

.ct-price-history__stat strong {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  font-variant-numeric: tabular-nums;
}

.ct-price-history__empty {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
  padding: var(--ct-space-6);
  background: var(--ct-surface-alt);
  border-radius: var(--ct-radius-md);
  text-align: center;
}
</style>
