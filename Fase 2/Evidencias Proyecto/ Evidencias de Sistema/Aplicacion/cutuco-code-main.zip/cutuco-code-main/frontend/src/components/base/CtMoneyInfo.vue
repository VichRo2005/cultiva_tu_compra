<script setup>
/**
 * Detalle bajo demanda del origen de un valor monetario.
 *
 * Por defecto usa `details`, que funciona con mouse, teclado y lector de
 * pantalla. En las tarjetas KPI puede abrirse como diálogo: así la consulta
 * del desglose no altera la altura ni la grilla del tablero.
 */
import { ref } from 'vue'
import CtIcon from './CtIcon.vue'
import CtModal from './CtModal.vue'

const props = defineProps({
  title: { type: String, default: 'Cómo se calcula este monto' },
  mode: { type: String, default: 'inline' }, // inline | modal
})

const abierto = ref(false)
</script>

<template>
  <details v-if="props.mode === 'inline'" class="money-info">
    <summary>
      <CtIcon name="info" :size="15" aria-hidden="true" />
      <span>{{ title }}</span>
    </summary>
    <div class="money-info__body" role="note">
      <slot />
    </div>
  </details>

  <div v-else class="money-info money-info--modal">
    <button type="button" class="money-info__trigger" @click="abierto = true">
      <CtIcon name="info" :size="15" aria-hidden="true" />
      <span>{{ title }}</span>
    </button>

    <CtModal v-model="abierto" :title="title" size="sm" hide-footer>
      <div class="money-info__dialog-body" role="note">
        <slot />
      </div>
    </CtModal>
  </div>
</template>

<style scoped>
.money-info {
  margin-top: var(--ct-space-3);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-xs);
}

.money-info summary {
  align-items: center;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-primary-strong);
  cursor: pointer;
  display: inline-flex;
  font-weight: var(--ct-fw-semibold);
  gap: var(--ct-space-2);
  list-style: none;
  max-width: 100%;
  padding: var(--ct-space-1) var(--ct-space-2);
}

.money-info__trigger {
  align-items: center;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-primary-strong);
  cursor: pointer;
  display: inline-flex;
  font: inherit;
  font-weight: var(--ct-fw-semibold);
  gap: var(--ct-space-2);
  max-width: 100%;
  padding: var(--ct-space-1) var(--ct-space-2);
  text-align: left;
}

.money-info summary::-webkit-details-marker {
  display: none;
}

.money-info summary::after {
  content: '+';
  font-size: var(--ct-fs-base);
  line-height: 1;
  margin-left: var(--ct-space-1);
}

.money-info[open] summary::after {
  content: '−';
}

.money-info summary:hover {
  background: var(--ct-primary-soft);
}

.money-info__trigger:hover {
  background: var(--ct-primary-soft);
}

.money-info summary:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: 2px;
}

.money-info__trigger:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: 2px;
}

.money-info__body {
  background: var(--ct-surface-soft);
  border-left: 3px solid var(--ct-primary);
  border-radius: 0 var(--ct-radius-sm) var(--ct-radius-sm) 0;
  line-height: 1.5;
  margin-top: var(--ct-space-2);
  padding: var(--ct-space-3);
}

.money-info__body :deep(p) {
  margin: 0;
}

.money-info__dialog-body {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
  line-height: 1.55;
}

.money-info__dialog-body :deep(p) {
  margin: 0;
}
</style>
