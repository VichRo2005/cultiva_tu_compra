/**
 * CuTuCo — Router de la aplicación.
 *
 * Alcance ERS vigente: 22 RF. Las rutas de historial de precios (RF-008),
 * alertas de stock (RF-010), evidencia fotográfica (versión antigua de RF-007),
 * reportes/BI y administración de geografía salieron del alcance. Los reclamos
 * (RF-027) y su bandeja administrativa sí están en el alcance vigente.
 *
 * La galería de desarrollo (`VITE_DEV_GALLERY`) sólo se activa de forma
 * explícita para revisar ventanas; en producción queda apagada.
 */

import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { ROL_USUARIO } from '@/lib/constants'
import { autenticarComo, DEV_GALLERY_ENABLED, sesionParaRuta } from '@/dev/devGallery'

const AppShell = () => import('@/layouts/AppShell.vue')

/** Migas de pan: la última es la ventana actual. */
const INICIO = { label: 'Inicio', to: '/' }
const CATALOGO = { label: 'Catálogo', to: '/catalogo' }
const MIS_PEDIDOS = { label: 'Mis Pedidos', to: '/cliente/pedidos' }
const MIS_RECLAMOS = { label: 'Mis Reclamos', to: '/cliente/reclamos' }
const VENDEDOR = { label: 'Panel del Vendedor', to: '/vendedor' }
const ADMIN = { label: 'Panel Admin', to: '/admin' }

const ROLES_CLIENTE = [ROL_USUARIO.CLIENTE]
const ROLES_VENDEDOR = [ROL_USUARIO.VENDEDOR, ROL_USUARIO.ADMIN]
const ROLES_ADMIN = [ROL_USUARIO.ADMIN]

/**
 * Todas las ventanas de producto cuelgan del mismo shell persistente
 * (barra lateral + barra superior + pie), salvo autenticación.
 */
const routes = [
  /* ------------------------- Ventanas de producto ------------------------ */
  {
    path: '/',
    component: AppShell,
    children: [
      {
        path: '',
        name: 'home',
        component: () => import('@/views/public/HomeView.vue'),
        meta: { title: 'Inicio', crumbs: [INICIO] },
      },

      /* ------------------ Catálogo público (RF-022 y RF-002) ------------- */
      {
        path: 'catalogo',
        name: 'catalogo',
        component: () => import('@/views/public/CatalogView.vue'),
        meta: { title: 'Catálogo público', crumbs: [INICIO, CATALOGO] },
      },
      {
        path: 'producto/:id',
        name: 'producto',
        component: () => import('@/views/public/ProductDetailView.vue'),
        meta: { title: 'Detalle de producto', crumbs: [INICIO, CATALOGO] },
      },
      {
        path: 'terminos',
        name: 'terminos',
        component: () => import('@/views/public/LegalView.vue'),
        meta: { title: 'Términos y condiciones', crumbs: [INICIO, { label: 'Términos' }], doc: 'terminos' },
      },
      {
        path: 'privacidad',
        name: 'privacidad',
        component: () => import('@/views/public/LegalView.vue'),
        meta: { title: 'Política de privacidad', crumbs: [INICIO, { label: 'Privacidad' }], doc: 'privacidad' },
      },
      {
        path: 'vendedores/:id',
        name: 'vendedor-publico',
        component: () => import('@/views/public/SellerProfileView.vue'),
        meta: { title: 'Perfil del vendedor', crumbs: [INICIO, CATALOGO] },
      },

      /* --------------------- Carrito y checkout (RF-002) ---------------- */
      {
        path: 'carrito',
        name: 'carrito',
        component: () => import('@/views/client/CartView.vue'),
        meta: { title: 'Tu Carrito', crumbs: [CATALOGO, { label: 'Tu Carrito' }] },
      },
      {
        path: 'checkout',
        name: 'checkout',
        component: () => import('@/views/client/CheckoutView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Finalizar Pedido',
          crumbs: [CATALOGO, { label: 'Finalizar Pedido' }],
        },
      },
      {
        path: 'pago/retorno',
        name: 'pago-retorno',
        component: () => import('@/views/client/PaymentResultView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Resultado del pago',
          crumbs: [CATALOGO, { label: 'Pago' }],
        },
      },

      /* ------------------- Cliente: pedidos y perfil (RF-002) ----------- */
      {
        path: 'cliente/pedidos',
        name: 'cliente-pedidos',
        component: () => import('@/views/client/ClientOrdersView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Historial de Pedidos',
          crumbs: [MIS_PEDIDOS],
        },
      },
      {
        path: 'cliente/reclamos',
        name: 'cliente-reclamos',
        component: () => import('@/views/client/ClientClaimsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Mis Reclamos',
          crumbs: [MIS_RECLAMOS],
        },
      },
      {
        path: 'cliente/reclamos/:id',
        name: 'cliente-reclamo',
        component: () => import('@/views/client/ClientClaimDetailView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Detalle del reclamo',
          crumbs: [MIS_RECLAMOS, { label: 'Detalle' }],
        },
      },
      {
        path: 'cliente/pedidos/:id',
        name: 'cliente-pedido',
        component: () => import('@/views/client/ClientOrderDetailView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Detalle del pedido',
          crumbs: [MIS_PEDIDOS, { label: 'Detalle' }],
        },
      },
      {
        path: 'cliente/perfil',
        name: 'cliente-perfil',
        component: () => import('@/views/client/ClientProfileView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Mi Perfil',
          crumbs: [INICIO, { label: 'Mi Perfil' }],
        },
      },
      { path: 'cliente/catalogo', redirect: { name: 'catalogo' } },

      {
        /* Direcciones compartidas por cliente y vendedor: la tabla `direcciones`
           es la misma y el trigger del esquema aplica la regla del productor
           (una sola dirección activa). */
        path: 'direcciones',
        name: 'direcciones',
        component: () => import('@/views/shared/AddressesView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_CLIENTE,
          title: 'Mis Direcciones',
          crumbs: [INICIO, { label: 'Mis Direcciones' }],
        },
      },

      /* ------------ Postulación de vendedor del propio cliente (RF-021) ---- */
      /* La cuenta nace cliente; su postulación en borrador o rechazada se
         completa y se reenvía aquí (intento++ lo aplica el trigger de BD).
         En en_revision / aprobada la vista queda en solo lectura. */
      {
        path: 'mi-postulacion',
        name: 'mi-postulacion',
        component: () => import('@/views/auth/MiPostulacionView.vue'),
        meta: {
          requiresAuth: true,
          roles: [ROL_USUARIO.CLIENTE, ROL_USUARIO.VENDEDOR],
          title: 'Mi Postulación',
          crumbs: [INICIO, { label: 'Mi Postulación' }],
        },
      },

      /* ----------------- Vendedor: tienda y pedidos (RF-003) ------------ */
      {
        path: 'vendedor',
        name: 'vendedor',
        component: () => import('@/views/seller/SellerDashboardView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Dashboard Vendedor',
          crumbs: [VENDEDOR],
        },
      },
      {
        path: 'vendedor/productos',
        name: 'vendedor-productos',
        component: () => import('@/views/seller/SellerProductsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Gestión de Inventario',
          crumbs: [VENDEDOR, { label: 'Gestión de Inventario' }],
        },
      },
      {
        path: 'vendedor/productos/nuevo',
        name: 'vendedor-producto-nuevo',
        component: () => import('@/views/seller/SellerProductFormView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Agregar Producto',
          crumbs: [
            VENDEDOR,
            { label: 'Gestión de Inventario', to: '/vendedor/productos' },
            { label: 'Agregar Producto' },
          ],
        },
      },
      {
        path: 'vendedor/productos/:id/editar',
        name: 'vendedor-producto-editar',
        component: () => import('@/views/seller/SellerProductFormView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Editar Producto',
          crumbs: [
            VENDEDOR,
            { label: 'Gestión de Inventario', to: '/vendedor/productos' },
            { label: 'Editar Producto' },
          ],
        },
      },
      {
        path: 'vendedor/pedidos',
        name: 'vendedor-pedidos',
        component: () => import('@/views/seller/SellerOrdersView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Pedidos Recibidos',
          crumbs: [VENDEDOR, { label: 'Pedidos Recibidos' }],
        },
      },
      {
        path: 'vendedor/pedidos/:id',
        name: 'vendedor-pedido',
        component: () => import('@/views/seller/SellerOrderDetailView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Detalle y despacho del pedido',
          crumbs: [
            VENDEDOR,
            { label: 'Pedidos Recibidos', to: '/vendedor/pedidos' },
            { label: 'Detalle' },
          ],
        },
      },
      {
        path: 'vendedor/servicio',
        name: 'vendedor-servicio',
        component: () => import('@/views/seller/SellerServiceView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Servicio y pagos',
          crumbs: [VENDEDOR, { label: 'Servicio y pagos' }],
        },
      },
      {
        path: 'vendedor/tienda',
        name: 'vendedor-tienda',
        component: () => import('@/views/seller/SellerStoreProfileView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Perfil de tienda',
          crumbs: [VENDEDOR, { label: 'Perfil de tienda' }],
        },
      },
      /* HAL-VEN-001: ruta /vendedor/perfil con vista dedicada de vendedor (no cliente) */
      {
        path: 'vendedor/perfil',
        name: 'vendedor-perfil',
        component: () => import('@/views/seller/SellerProfileView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Mi Perfil',
          crumbs: [VENDEDOR, { label: 'Mi Perfil' }],
        },
      },
      {
        /* RF-027: bandeja de reclamos recibidos en los pedidos del vendedor. */
        path: 'vendedor/reclamos',
        name: 'vendedor-reclamos',
        component: () => import('@/views/seller/SellerClaimsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Reclamos Recibidos',
          crumbs: [VENDEDOR, { label: 'Reclamos Recibidos' }],
        },
      },
      {
        /* RF-026: sanciones del vendedor y sus apelaciones. */
        path: 'vendedor/sanciones',
        name: 'vendedor-sanciones',
        component: () => import('@/views/seller/SellerSanctionsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Sanciones y Apelaciones',
          crumbs: [VENDEDOR, { label: 'Sanciones y Apelaciones' }],
        },
      },

      /* ------------------------------------------------------------------
       * Ventanas del prototipo anterior — SÓLO GALERÍA DE DESARROLLO
       * ------------------------------------------------------------------
       * NOTA DE MIGRACIÓN (alcance anterior, ya no está en el menú):
       *   Se conservan registradas para poder revisarlas con
       *   `VITE_DEV_GALLERY=true`. Quedan fuera del menú de navegación
       *   (`lib/navigation.js`) porque sus requisitos salieron del ERS vigente:
       *   RF-006 v1 (score 40/40/20), RF-010 (alertas de stock), RF-008
       *   (historial de precios) y los reportes y reclamos del administrador.
       */
      {
        path: 'vendedor/alertas-stock',
        name: 'vendedor-alertas',
        component: () => import('@/views/seller/SellerStockAlertsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Alertas de stock (galería)',
          gallery: true,
          crumbs: [VENDEDOR, { label: 'Alertas de stock' }],
        },
      },
      {
        path: 'vendedor/reputacion',
        name: 'vendedor-reputacion',
        component: () => import('@/views/seller/SellerReputationView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_VENDEDOR,
          title: 'Reputación (galería)',
          gallery: true,
          crumbs: [VENDEDOR, { label: 'Reputación' }],
        },
      },

      /* ------------------ Administración (RF-004 y RF-011) -------------- */
      {
        path: 'admin',
        name: 'admin',
        component: () => import('@/views/admin/AdminDashboardView.vue'),
        meta: { requiresAuth: true, roles: ROLES_ADMIN, title: 'Panel de Administración', crumbs: [ADMIN] },
      },
      {
        path: 'admin/usuarios',
        name: 'admin-usuarios',
        component: () => import('@/views/admin/AdminUsersView.vue'),
        meta: { requiresAuth: true, roles: ROLES_ADMIN, title: 'Gestión de Usuarios', crumbs: [ADMIN, { label: 'Usuarios' }] },
      },
      {
        path: 'admin/productos',
        name: 'admin-productos',
        component: () => import('@/views/admin/AdminCatalogView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_ADMIN,
          title: 'Gestión de Productos',
          crumbs: [ADMIN, { label: 'Productos' }],
        },
      },
      {
        path: 'admin/moderacion',
        name: 'admin-moderacion',
        component: () => import('@/views/admin/AdminModerationView.vue'),
        meta: { requiresAuth: true, roles: ROLES_ADMIN, title: 'Aprobación de vendedores', crumbs: [ADMIN, { label: 'Aprobaciones' }] },
      },
      {
        path: 'admin/pagos',
        name: 'admin-pagos',
        component: () => import('@/views/admin/AdminPaymentsView.vue'),
        meta: { requiresAuth: true, roles: ROLES_ADMIN, title: 'Pagos', crumbs: [ADMIN, { label: 'Pagos' }] },
      },
      {
        path: 'admin/servicios',
        name: 'admin-servicios',
        component: () => import('@/views/admin/AdminServicesView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_ADMIN,
          title: 'Servicio de vendedores',
          crumbs: [ADMIN, { label: 'Servicio de vendedores' }],
        },
      },
      {
        path: 'admin/sanciones',
        name: 'admin-sanciones',
        component: () => import('@/views/admin/AdminSanctionsView.vue'),
        meta: { requiresAuth: true, roles: ROLES_ADMIN, title: 'Sanciones', crumbs: [ADMIN, { label: 'Sanciones' }] },
      },

      /* ------------------------------------------------------------------
       * Ventanas administrativas del prototipo anterior — GALERÍA
       * ------------------------------------------------------------------
       * NOTA DE MIGRACIÓN (alcance anterior, ya no están en el menú):
       *   RF-011 v2.0 dejó el dashboard en los tres pendientes (aprobaciones,
       *   sanciones y pagos) y los reportes analíticos y los reclamos salieron
       *   del alcance, igual que la administración de regiones, comunas y
       *   cobertura por comuna (RF-009 v1). Se conservan registradas para
       *   revisarlas con `VITE_DEV_GALLERY=true`.
       */
      {
        path: 'admin/reportes',
        name: 'admin-reportes',
        component: () => import('@/views/admin/AdminReportsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_ADMIN,
          title: 'Centro de Reportes (galería)',
          gallery: true,
          crumbs: [ADMIN, { label: 'Reportes' }],
        },
      },
      {
        /* RF-027: bandeja del administrador para revisar y resolver reclamos. */
        path: 'admin/reclamos',
        name: 'admin-reclamos',
        component: () => import('@/views/admin/AdminClaimsView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_ADMIN,
          title: 'Reclamos',
          crumbs: [ADMIN, { label: 'Reclamos' }],
        },
      },
      {
        path: 'admin/geografia',
        name: 'admin-geografia',
        component: () => import('@/views/admin/AdminGeographyView.vue'),
        meta: {
          requiresAuth: true,
          roles: ROLES_ADMIN,
          title: 'Regiones y comunas (galería)',
          gallery: true,
          crumbs: [ADMIN, { label: 'Regiones y comunas' }],
        },
      },

      {
        path: ':pathMatch(.*)*',
        name: 'not-found',
        component: () => import('@/views/shared/NotFoundView.vue'),
        meta: { title: 'Página no encontrada', crumbs: [INICIO, { label: 'Página no encontrada' }] },
      },
    ],
  },

  /* --------------------- Autenticación (sin shell) --------------------- */
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/auth/LoginView.vue'),
    meta: { layout: 'auth', title: 'Iniciar Sesión' },
  },
  {
    path: '/registro',
    name: 'registro',
    component: () => import('@/views/auth/RegisterView.vue'),
    meta: { layout: 'auth', title: 'Crear Cuenta' },
  },
  {
    path: '/registro-vendedor',
    name: 'registro-vendedor',
    component: () => import('@/views/auth/RegisterSellerView.vue'),
    meta: { layout: 'auth', title: 'Quiero vender' },
  },
  {
    path: '/recuperar-clave',
    name: 'recuperar-clave',
    component: () => import('@/views/auth/ForgotPasswordView.vue'),
    meta: { layout: 'auth', title: 'Recuperar contraseña' },
  },
  {
    /* Página de apoyo de la galería de desarrollo: cuentas del seed y acceso
       directo con cada rol para revisar todas las ventanas. */
    path: '/cuentas-demo',
    name: 'cuentas-demo',
    component: () => import('@/views/shared/DevAccountsView.vue'),
    meta: { layout: 'auth', title: 'Cuentas de prueba', gallery: true },
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior(to, from, saved) {
    if (saved) return saved
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0 }
  },
})

/**
 * Destino por defecto tras el registro o el inicio de sesión:
 *   - Cuenta eliminada/desactivada/ban permanente: sin acceso.
 *   - Suspensión temporal vigente: sólo amonestaciones.
 *   - Postulación activa/rechazada: /mi-postulacion.
 *   - Cliente: portada (LOG-AUTH-001); administrador: /admin.
 *   - Vendedor activo: /vendedor.
 */
function inicioDeSesion(auth) {
  if (['baneado', 'eliminado', 'desactivado'].includes(auth.estadoCuenta)) return null
  if (auth.estaSuspendido) return { name: 'vendedor-sanciones' }
  if (auth.enPostulacion || auth.postulacionPendiente || auth.postulacionRechazada) {
    return { name: 'mi-postulacion' }
  }
  if (auth.isAdmin) return { name: 'admin' }
  if (auth.isVendedor) return { name: 'vendedor' }
  return { name: 'home' }
}

router.beforeEach(async (to) => {
  /*
   * Retorno de Webpay Plus.
   *
   * Transbank vuelve primero al endpoint público de FastAPI. Ese endpoint
   * confirma el pago y redirige por GET a `/cliente/pedidos`, conservando
   * `token_ws` (pago autorizado) o `TBK_TOKEN` (transacción anulada/expirada).
   * El historial delega los parámetros a `PaymentResultView` para mostrar el
   * resultado sin descartar el token.
   */
  if (
    to.name === 'cliente-pedidos' &&
    (to.query.token_ws || to.query.TBK_TOKEN || to.query.TBK_ORDEN_COMPRA)
  ) {
    return { name: 'pago-retorno', query: to.query, replace: true }
  }

  const auth = useAuthStore()

  if (auth.initializing) await auth.init()

  if (auth.configuracionFaltante) {
    // Sin credenciales de Supabase la aplicación no puede operar: la pantalla de
    // login explica qué variables de entorno faltan.
    return to.name === 'login' ? true : { name: 'login' }
  }

  /*
   * Recuperación de contraseña (RF-023): el enlace del correo abre una sesión de
   * recuperación, así que la vista debe poder mostrarse aunque el usuario esté
   * autenticado. Sin esta excepción el guard lo enviaría a su panel y nunca
   * podría definir la clave nueva.
   *
   * No se marca la recuperación desde la URL: el estado válido lo publica GoTrue
   * con el evento PASSWORD_RECOVERY. Marcar cualquier `?recuperacion=1` permitía
   * cambiar la contraseña desde una sesión normal sin pedir la clave actual.
   */
  if (to.name === 'recuperar-clave' && to.query.recuperacion === '1') {
    return true
  }

  /*
   * Galería de desarrollo (`VITE_DEV_GALLERY=true`): todas las ventanas son
   * accesibles, sin guards de sesión ni de rol. Además, si la ventana exige un
   * rol distinto del que está en sesión, se cambia de cuenta automáticamente
   * con el Administrador Base o la cuenta de prueba correspondiente, para que
   * ninguna pantalla quede bloqueada durante la revisión.
   */
  if (DEV_GALLERY_ENABLED) {
    const sesion = sesionParaRuta(auth.rol, to.meta, to.path)
    if (sesion && sesion.email !== auth.email) {
      try {
        await autenticarComo(sesion)
      } catch {
        // Sin sesión disponible se muestra la ventana igualmente (modo público).
      }
    }
    return true
  }

  if (to.meta.requiresAuth && !auth.isAuthenticated) {
    return { name: 'login', query: { redirect: to.fullPath } }
  }

  /*
   * LOG-NEG-001/002/004 y LOG-NEG-003/005/006: el estado de la cuenta se
   * reevalúa con el contexto ya cargado. Una sesión antigua de una cuenta
   * desactivada/eliminada/baneada se elimina; una suspensión vigente sólo
   * permite amonestaciones; una postulación activa sólo permite su vista.
   * Una suspensión vencida ya no aparece en `estadoCuenta` (se evalúa por fecha).
   */
  if (auth.isAuthenticated) {
    const estado = auth.estadoCuenta
    if (['baneado', 'eliminado', 'desactivado'].includes(estado)) {
      await auth.signOut()
      return { name: 'login', query: { bloqueado: estado } }
    }
    if (estado === 'suspendido' && to.name !== 'vendedor-sanciones') {
      return { name: 'vendedor-sanciones' }
    }
    if (
      ['postulacion', 'postulacion_rechazada'].includes(estado) &&
      !['mi-postulacion', 'login'].includes(to.name) &&
      !String(to.name ?? '').startsWith('vendedor-sanciones')
    ) {
      return { name: 'mi-postulacion' }
    }
  }

  // El alta de productor debe poder abrirse desde el CTA de Inicio aunque la
  // persona ya tenga sesión de cliente. Si ya hay una postulación activa, la
  // regla anterior conserva el envío a «Mi Postulación».
  if (auth.isAuthenticated && ['login', 'registro', 'recuperar-clave'].includes(to.name)) {
    return inicioDeSesion(auth) ?? { name: 'login', query: { bloqueado: auth.estadoCuenta } }
  }

  // «Mi Postulación» sólo representa una solicitud ya iniciada. Una cuenta
  // cliente común debe continuar por el registro de productores, no aterrizar
  // en una pantalla sin contexto ni acceso útil.
  if (auth.isAuthenticated && to.name === 'mi-postulacion' && !auth.postulacion) {
    return { name: 'registro-vendedor' }
  }

  const roles = to.meta.roles
  if (roles && auth.rol && !roles.includes(auth.rol)) {
    // Vendedor intentando acceder a una ruta de cliente: enviar a su perfil de tienda (HAL-VEN-001)
    if (auth.rol === ROL_USUARIO.VENDEDOR) return { name: 'vendedor-tienda' }
    return inicioDeSesion(auth) ?? { name: 'home' }
  }

  return true
})

router.afterEach((to) => {
  const title = to.meta?.title
  document.title = title ? `${title} · CuTuCo` : `CuTuCo · Cultiva tu compra`
})

export default router

