/**
 * CuTuCo — Lote 4: revalidación ejecutable del área "Catálogo público".
 *
 * CK-0049/0050/0051/0059: búsqueda, filtros combinados, limpieza y conservación
 *   del contexto al volver (los filtros viven en la URL: leerFiltrosCatalogo /
 *   construirQueryCatalogo son round-trip y CatalogView los lee al montar).
 * CK-0464: el panel de pagos no usa "Facturas" como contador de pagos autorizados.
 * CK-0475: la pestaña se llama "Notificaciones" y sí tiene controles de preferencia.
 * CK-0479: un solo buscador por vista (Home y Catálogo).
 * CK-0482: un solo botón "Contactar soporte" en el detalle del pedido.
 * CK-0488: DC-18 — sin tope monetario de compra en el MVP (aceptación explícita).
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'
import {
  construirQueryCatalogo,
  leerFiltrosCatalogo,
} from '@/services/catalog'

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0049/0050/0051/0059 · búsqueda, filtros y contexto en la URL', () => {
  it('leerFiltrosCatalogo lee búsqueda, categoría, región, precio y orden desde la query', () => {
    const f = leerFiltrosCatalogo({
      q: '  tomate  ', categoria: 'c1', subcategoria: 's2', region: 'r1',
      productor: 'p1', min: '1000', max: '5000', orden: 'precio_asc', page: '3',
    })
    expect(f).toMatchObject({
      texto: 'tomate', categoriaId: 'c1', subcategoriaId: 's2', regionId: 'r1',
      productorId: 'p1', precioMin: '1000', precioMax: '5000', orden: 'precio_asc', page: 3,
    })
  })

  it('construirQueryCatalogo reconstruye la misma query (volver conserva los filtros)', () => {
    const original = { q: 'tomate', categoria: 'c1', region: 'r1', min: '1000', max: '5000', orden: 'precio_asc', page: '2' }
    const f = leerFiltrosCatalogo(original)
    const reconstruida = construirQueryCatalogo(f, f.page)
    expect(reconstruida).toEqual(original)
  })

  it('limpiar filtros vuelve a la query pública por defecto (sin parámetros vacíos)', () => {
    const vacia = construirQueryCatalogo(leerFiltrosCatalogo({}), 1)
    expect(vacia).toEqual({})
  })

  it('la vista de catálogo muestra estado vacío explícito cuando no hay coincidencias', () => {
    expect(src('views/public/CatalogView.vue')).toContain('No encontramos productos con esos filtros')
  })

  it('CatalogView monta los filtros desde route.query y sincroniza la URL al cambiarlos', () => {
    const vista = src('views/public/CatalogView.vue')
    expect(vista).toContain('leerFiltrosCatalogo(route.query)')
    expect(vista).toContain('sincronizarDesdeUrl')
    expect(vista).toContain('construirQueryCatalogo')
  })
})

describe('CK-0464 · el contador de pagos autorizados no se llama "Facturas"', () => {
  it('AdminPaymentsView etiqueta como pagos/comprobantes autorizados, nunca facturas', () => {
    const vista = src('views/admin/AdminPaymentsView.vue')
    expect(vista).toContain('Comprobantes autorizados')
    expect(vista).not.toMatch(/label="[^"]*Facturas/i)
    expect(vista).not.toMatch(/>Facturas</)
  })

  it('el checkout aclara que CuTuCo no emite facturas', () => {
    expect(src('views/client/CheckoutView.vue')).toContain('no emite ni administra boletas o facturas')
  })
})

describe('Pagos · desglose y filtros administrativos', () => {
  it('permite configurar el IVA de los nuevos pagos y presenta comisión bruta, IVA y neto por período', () => {
    const vista = src('views/admin/AdminPaymentsView.vue')
    expect(vista).toContain('IVA en pagos de productos')
    expect(vista).toContain('Configurar IVA')
    expect(vista).toContain('actualizarIvaHabilitado')
    expect(vista).toContain('CtToggle')
    expect(vista).toContain('Comisión bruta cobrada')
    expect(vista).toContain('IVA de comisión')
    expect(vista).toContain('Ingreso neto de comisión')
    expect(vista).toContain('CtDateRange')
  })
})

describe('CK-0475 · pestaña de notificaciones con controles reales', () => {
  it('cliente y vendedor comparten preferencias de canales que sí se entregan', () => {
    const vista = src('views/client/ClientProfileView.vue')
    expect(vista).toContain("label: 'Notificaciones'")
    expect(vista).toContain('NotificationPreferences')
    expect(src('views/seller/SellerProfileView.vue')).toContain('NotificationPreferences')
    const preferencias = src('components/domain/NotificationPreferences.vue')
    expect(preferencias).toContain('Correo electrónico')
    expect(preferencias).toContain('Avisos dentro de CuTuCo')
    expect(preferencias).toContain('Guardar preferencias')
    expect(preferencias).not.toContain('Notificaciones push')
    expect(preferencias).not.toContain('SMS')
  })
})

describe('CK-0479 · un solo buscador por vista', () => {
  it('Home y Catálogo tienen un único control de búsqueda', () => {
    for (const vista of ['views/public/HomeView.vue', 'views/public/CatalogView.vue']) {
      const s = src(vista)
      const buscadores = s.match(/type="search"|CtSearchInput|CtInput[^>]*buscar/gi) ?? []
      expect(buscadores.length).toBeLessThanOrEqual(1)
    }
    // el filtro de catálogo declara el buscador principal único (HAL-CLI-020)
    expect(src('components/domain/CatalogFilters.vue')).toContain('HAL-CLI-020')
  })
})

describe('CK-0482 · un solo contacto de soporte en el detalle del pedido', () => {
  it('ClientOrderDetailView tiene un único botón «Contactar soporte»', () => {
    const vista = src('views/client/ClientOrderDetailView.vue')
    // un solo botón con ese texto; las menciones en prosa no cuentan
    const bloques = vista.match(/<CtButton\b[\s\S]*?<\/CtButton>/g) ?? []
    const botones = bloques.filter((b) => b.includes('Contactar soporte'))
    expect(botones.length).toBe(1)
    expect(botones[0]).toContain('urlSoporte')
    expect(vista).toContain("mailto:cutucosoporte@gmail.com")
  })
})

describe('CK-0488 · DC-18: sin tope monetario de compra en el MVP (aceptado explícitamente)', () => {
  it('el carrito no impone un tope monetario arbitrario; el precio máximo es por producto (backend)', () => {
    const carrito = src('stores/cart.js')
    expect(carrito).not.toMatch(/MAX_TOTAL|tope.*monto|monto.*max/i)
    const doc = readFileSync('../docs/decisiones-resueltas.md', 'utf8')
    expect(doc).toContain('DC-18')
    expect(doc).toMatch(/sin tope monetario de compra en el MVP/i)
  })
})
