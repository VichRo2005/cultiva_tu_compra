import { execFileSync } from 'node:child_process'
import process from 'node:process'
import { describe, expect, it } from 'vitest'
import { SUPABASE_ANON_KEY, SUPABASE_URL } from '@/lib/supabase'

// Estas solicitudes sólo alcanzan la instancia QA aislada; nunca cuentas externas.
const qa = SUPABASE_URL === 'http://127.0.0.1:55321' &&
  process.env.CUTUCO_TEST_DB_CONTAINER === 'supabase_db_cutuco-checklist-qa'
const correoExistente = 'cutuco.cliente.santiago@example.test'
function identidades() {
  return execFileSync('docker', ['exec', process.env.CUTUCO_TEST_DB_CONTAINER,
    'psql', '-U', 'postgres', '-At', '-c',
    `SELECT count(*) FROM auth.users WHERE email='${correoExistente}';
     SELECT count(*) FROM public.perfiles WHERE id='a0000000-0000-0000-0000-000000000002';`,
  ], { encoding: 'utf8' }).trim()
}
async function alta(email) {
  return fetch(`${SUPABASE_URL}/auth/v1/signup`, {
    method: 'POST', headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'PruebaLocal!2026' }),
    signal: AbortSignal.timeout(8000),
  })
}

describe.skipIf(!qa)('Checklist GoTrue local: entradas directas sin formulario', () => {
  it.each(['sin-arroba', 'usuario@', '@dominio.cl'])('rechaza correo inválido %s', async (correo) => {
    const respuesta = await alta(correo)
    expect([400, 422]).toContain(respuesta.status)
    const cuerpo = await respuesta.json()
    expect(cuerpo.access_token).toBeUndefined()
    expect(cuerpo.error_code).toMatch(/email|validation/)
  })

  it('dos altas simultáneas del correo existente no duplican identidad ni perfil', async () => {
    expect(identidades()).toBe('1\n1')
    const respuestas = await Promise.all([alta(correoExistente), alta(correoExistente)])
    for (const respuesta of respuestas) {
      expect([200, 400, 422]).toContain(respuesta.status)
      expect((await respuesta.json()).access_token).toBeUndefined()
    }
    expect(identidades()).toBe('1\n1')
  })
})

