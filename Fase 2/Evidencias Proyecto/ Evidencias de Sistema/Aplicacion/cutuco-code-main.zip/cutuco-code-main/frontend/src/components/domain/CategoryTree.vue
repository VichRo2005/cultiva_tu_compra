<script setup>
/**
 * CuTuCo — Árbol jerárquico de categorías (administración del catálogo).
 */
import { ref } from 'vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtIcon from '@/components/base/CtIcon.vue'

defineProps({
  nodes: { type: Array, default: () => [] },
  selectedId: { type: String, default: null },
  depth: { type: Number, default: 0 },
  counts: { type: Object, default: () => ({}) },
})

const emit = defineEmits(['select', 'edit', 'delete', 'add-child'])

const expandidos = ref(new Set())

function toggle(id) {
  const next = new Set(expandidos.value)
  if (next.has(id)) next.delete(id)
  else next.add(id)
  expandidos.value = next
}

function isExpanded(id) {
  return expandidos.value.has(id)
}
</script>

<template>
  <ul class="ctree" :style="{ paddingLeft: depth === 0 ? '0' : '1.25rem' }">
    <li v-for="node in nodes" :key="node.id" class="ctree__node">
      <div
        class="ctree__row"
        :class="{ 'is-selected': selectedId === node.id, 'is-deleted': node.eliminado_en }"
      >
        <button
          v-if="node.hijos?.length"
          type="button"
          class="ctree__toggle"
          :aria-label="isExpanded(node.id) ? 'Contraer' : 'Expandir'"
          @click="toggle(node.id)"
        >
          <CtIcon :name="isExpanded(node.id) ? 'chevronDown' : 'chevronRight'" :size="15" />
        </button>
        <span v-else class="ctree__spacer" />

        <button type="button" class="ctree__label" @click="emit('select', node)">
          <span>{{ node.nombre }}</span>
          <CtBadge v-if="node.es_sistema" tone="info" size="sm">Sistema</CtBadge>
          <CtBadge v-if="node.eliminado_en" tone="danger" size="sm">Eliminada</CtBadge>
          <span v-else-if="counts[node.id]" class="ctree__count">{{ counts[node.id] }}</span>
        </button>

        <div class="ctree__actions">
          <button type="button" title="Agregar subcategoría" aria-label="Agregar subcategoría" @click="emit('add-child', node)">
            <CtIcon name="plus" :size="14" />
          </button>
          <button type="button" title="Editar" aria-label="Editar" @click="emit('edit', node)">
            <CtIcon name="edit" :size="14" />
          </button>
          <button
            type="button"
            title="Eliminar"
            :disabled="node.es_sistema || Boolean(node.eliminado_en)"
            @click="emit('delete', node)"
          >
            <CtIcon name="trash" :size="14" />
          </button>
        </div>
      </div>

      <template v-if="node.hijos?.length && isExpanded(node.id)">
        <CategoryTree
          :nodes="node.hijos"
          :selected-id="selectedId"
          :depth="depth + 1"
          :counts="counts"
          @select="emit('select', $event)"
          @edit="emit('edit', $event)"
          @delete="emit('delete', $event)"
          @add-child="emit('add-child', $event)"
        />
      </template>
    </li>
  </ul>
</template>

<style scoped>
.ctree {
  list-style: none;
  margin: 0;
}

.ctree__row {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  padding: var(--ct-space-2) var(--ct-space-2);
  border-radius: var(--ct-radius);
  transition: background-color var(--ct-transition);
}

.ctree__row:hover {
  background: var(--ct-surface-alt);
}

.ctree__row.is-selected {
  background: var(--ct-primary-soft);
}

.ctree__row.is-deleted .ctree__label span:first-child {
  text-decoration: line-through;
  color: var(--ct-text-muted);
}

.ctree__label,
.ctree__toggle {
  min-height: 24px;
}

.ctree__toggle {
  min-width: 24px;
}

.ctree__toggle {
  width: 20px;
  color: var(--ct-text-muted);
  font-size: 0.8rem;
  border-radius: var(--ct-radius-sm);
  transition:
    background var(--ct-transition),
    color var(--ct-transition);
}

.ctree__toggle:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.ctree__spacer {
  width: 20px;
}

.ctree__label {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex: 1;
  min-width: 0;
  text-align: left;
  font-size: var(--ct-fs-md);
  border-radius: var(--ct-radius-sm);
  transition: color var(--ct-transition), background var(--ct-transition);
}

.ctree__label:hover {
  color: var(--ct-primary-strong);
}

.ctree__label:hover .ctree__count {
  color: var(--ct-primary-ink);
}

.ctree__count {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  transition: color var(--ct-transition);
  background: var(--ct-surface-alt);
  border-radius: var(--ct-radius-pill);
  padding: 1px 7px;
}

.ctree__actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity var(--ct-transition);
}

.ctree__row:hover .ctree__actions {
  opacity: 1;
}

.ctree__actions button {
  width: 26px;
  height: 26px;
  border-radius: var(--ct-radius-sm);
  font-size: 0.8rem;
  color: var(--ct-text-soft);
}

.ctree__actions button:hover:not(:disabled) {
  background: var(--ct-surface);
  color: var(--ct-primary-strong);
}

.ctree__actions button:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}
</style>
