<script setup>
/**
 * CuTuCo — Mis Reclamos (RF-027 y RF-026).
 *
 * Historial de reclamos del cliente autenticado. La lista sale de
 * `public.reclamos` con RLS de participante (`reclamos_select_participantes`:
 * `cliente_id = auth.uid()`), así que sólo aparecen los reclamos propios.
 *
 * Permite abrir un reclamo nuevo sobre cualquiera de los pedidos que todavía no
 * tienen uno vigente: el índice único parcial `uq_reclamo_abierto_por_pedido`
 * sólo admite un reclamo abierto o en revisión por pedido.
 *
 * El esquema no guarda una columna `resolucion`: el cierre se lee de `estado`,
 * `respuesta_productor` y `resuelto_en`.
 */
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { MOTIVOS_RECLAMO } from '@/lib/constants'
import { formatCLP, formatDate, pluralize } from '@/lib/format'
import { listPedidos } from '@/services/orders'
import { crearReclamo, listMisReclamos, RECLAMO_VIGENTE } from '@/services/reclamos'
import { useUiStore } from '@/stores/ui'

const PAGE_SIZE_MAX = 500

const router = useRouter()
const ui = useUiStore()

const reclamos = ref([])
const pedidos = ref([])
const cargando = ref(true)
const error = ref(null)

const modalAbierto = ref(false)
const guardando = ref(false)
const errorFormulario = ref(null)
const formulario = ref({ pedidoId: '', motivo: '', descripcion: '' })

const columns = [
  { key: 'pedido', label: 'Pedido', width: '180px' },
  { key: 'creado_en', label: 'Fecha', width: '130px' },
  { key: 'motivo', label: 'Motivo' },
  { key: 'estado', label: 'Estado', width: '160px' },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '120px' },
]

const vigentes = computed(() => reclamos.value.filter((r) => r.vigente))

/** Pedidos que todavía admiten un reclamo (sin uno abierto o en revisión). */
const pedidosReclamables = computed(() => {
  const conReclamo = new Set(vigentes.value.map((r) => r.pedido_id))
  return pedidos.value.filter((p) => !conReclamo.has(p.id))
})

const opcionesPedido = computed(() =>
  pedidosReclamables.value.map((p) => ({
    value: p.id,
    label: `${p.codigo_pedido} · ${formatDate(p.creado_en)} · ${formatCLP(p.total)}`,
  })),
)

const opcionesMotivo = computed(() => MOTIVOS_RECLAMO.map((m) => ({ value: m, label: m })))

const resumen = computed(() => ({
  total: reclamos.value.length,
  abiertos: reclamos.value.filter((r) => r.estado === RECLAMO_VIGENTE[0]).length,
  revision: reclamos.value.filter((r) => r.estado === RECLAMO_VIGENTE[1]).length,
  cerrados: reclamos.value.filter((r) => !r.vigente).length,
}))

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const [misReclamos, listado] = await Promise.all([
      listMisReclamos(),
      listPedidos({ rol: 'cliente', page: 1, pageSize: PAGE_SIZE_MAX }),
    ])
    reclamos.value = misReclamos
    pedidos.value = listado.items
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron cargar tus reclamos'
  } finally {
    cargando.value = false
  }
}

function abrirModal(pedidoId = '') {
  errorFormulario.value = null
  formulario.value = { pedidoId, motivo: '', descripcion: '' }
  modalAbierto.value = true
}

async function guardar() {
  if (guardando.value) return
  errorFormulario.value = null
  if (!formulario.value.pedidoId) {
    errorFormulario.value = 'Selecciona el pedido del reclamo'
    return
  }
  if (!formulario.value.motivo) {
    errorFormulario.value = 'Selecciona el motivo del reclamo'
    return
  }
  if (!formulario.value.descripcion.trim()) {
    errorFormulario.value = 'Describe lo que ocurrió con tu pedido'
    return
  }

  guardando.value = true
  try {
    const creado = await crearReclamo({
      pedidoId: formulario.value.pedidoId,
      motivo: formulario.value.motivo,
      descripcion: formulario.value.descripcion,
    })
    modalAbierto.value = false
    ui.success(
      'Constancia registrada',
      'Coordina la solución directamente con el productor. CuTuCo conserva este registro como respaldo.',
    )
    await cargar()
    if (creado?.id) router.push(`/cliente/reclamos/${creado.id}`)
  } catch (e) {
    errorFormulario.value = e?.message ?? 'No se pudo registrar el reclamo'
  } finally {
    guardando.value = false
  }
}

function verDetalle(reclamo) {
  router.push(`/cliente/reclamos/${reclamo.id}`)
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Mis Reclamos</h1>
        <p class="page-head__subtitle">
          {{ reclamos.length }} {{ pluralize(reclamos.length, 'reclamo', 'reclamos') }} ·
          {{ vigentes.length }} {{ vigentes.length === 1 ? 'vigente' : 'vigentes' }}.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton
          :disabled="!pedidosReclamables.length"
          @click="abrirModal()"
        >
          <template #icon><CtIcon name="alert" :size="16" /></template>
          Abrir un reclamo
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar tus reclamos">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtAlert tone="info" compact title="Qué registra esta sección">
      <p class="linea">
        <CtIcon name="lock" :size="15" />
        <span>
          CuTuCo deja constancia de lo ocurrido y permite que el productor vea tu mensaje. La
          coordinación y la solución se realizan directamente entre tú y el productor, fuera de
          CuTuCo. Este registro no bloquea ni modifica el pago.
        </span>
      </p>
    </CtAlert>

    <CtCard padding="md">
      <div class="grid-kpi">
        <div class="kpi">
          <span class="eyebrow">Total</span>
          <span class="kpi__valor">{{ resumen.total }}</span>
        </div>
        <div class="kpi">
          <span class="eyebrow">Abiertos</span>
          <span class="kpi__valor">{{ resumen.abiertos }}</span>
        </div>
        <div class="kpi">
          <span class="eyebrow">En revisión</span>
          <span class="kpi__valor">{{ resumen.revision }}</span>
        </div>
        <div class="kpi">
          <span class="eyebrow">Cerrados</span>
          <span class="kpi__valor">{{ resumen.cerrados }}</span>
        </div>
      </div>
    </CtCard>

    <CtSpinner v-if="cargando" label="Cargando tus reclamos" />

    <template v-else>
      <CtTable
        :columns="columns"
        :rows="reclamos"
        empty-icon=""
        empty-title="Todavía no tienes reclamos"
        empty-message="Si algo sale mal con un pedido puedes dejar una constancia aquí para respaldar tu conversación con el productor."
        clickable
        row-key="id"
        min-width="820px"
        @row-click="verDetalle"
      >
        <template #empty-action>
          <CtButton :disabled="!pedidosReclamables.length" @click="abrirModal()">
            <template #icon><CtIcon name="alert" :size="16" /></template>
            Abrir un reclamo
          </CtButton>
        </template>

        <template #cell-pedido="{ row }">
          <div class="stack stack--xs">
            <span class="mono font-semibold">{{ row.pedido?.codigo_pedido ?? '—' }}</span>
            <span class="text-xs text-muted">
              {{ row.productor?.nombre_comercial ?? 'Productor CuTuCo' }}
            </span>
          </div>
        </template>

        <template #cell-creado_en="{ row }">
          {{ formatDate(row.creado_en) }}
        </template>

        <template #cell-motivo="{ row }">
          <span class="text-sm">{{ row.motivo }}</span>
        </template>

        <template #cell-estado="{ row }">
          <div class="row row--wrap">
            <StatusBadge type="reclamo" :value="row.estado" />
            <CtBadge v-if="row.pedido" type="pedido" :value="row.pedido.estado" size="sm" />
          </div>
        </template>

        <template #cell-acciones="{ row }">
          <CtButton size="sm" variant="outline" @click.stop="verDetalle(row)">Detalles</CtButton>
        </template>
      </CtTable>

      <p v-if="!pedidosReclamables.length && pedidos.length" class="nota">
        Todos tus pedidos activos ya tienen un reclamo vigente.
      </p>
      <p v-else-if="!pedidos.length" class="nota">
        Aún no tienes pedidos: cuando confirmes tu primera compra podrás reclamar sobre ella.
      </p>
    </template>

    <CtModal v-model="modalAbierto" title="Abrir un reclamo" size="md">
      <div class="stack">
        <CtAlert v-if="errorFormulario" tone="danger">{{ errorFormulario }}</CtAlert>

        <CtSelect
          v-model="formulario.pedidoId"
          label="Pedido"
          :options="opcionesPedido"
          placeholder="Selecciona el pedido"
          required
        />
        <CtSelect
          v-model="formulario.motivo"
          label="Motivo"
          :options="opcionesMotivo"
          placeholder="Selecciona el motivo"
          required
        />
        <CtTextarea
          v-model="formulario.descripcion"
          label="¿Qué ocurrió?"
          placeholder="Cuéntanos con detalle qué pasó con tu pedido"
          :rows="5"
          :maxlength="2500"
          show-count
          required
        />
        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              Un pedido admite un solo reclamo abierto a la vez. El texto no puede contener
              palabras prohibidas por la moderación de la plataforma.
            </span>
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="guardando" @click="modalAbierto = false">
          Cancelar
        </CtButton>
        <CtButton :loading="guardando" @click="guardar">Enviar reclamo</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.grid-kpi {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: var(--ct-space-4);
}

.kpi {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.kpi__valor {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
}

.nota {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

/* HAL-VEN-027: motivos y textos ingresados no desbordan la tabla. */
:deep(.ct-table td) {
  overflow-wrap: anywhere;
  word-break: break-word;
  min-width: 0;
}
</style>
