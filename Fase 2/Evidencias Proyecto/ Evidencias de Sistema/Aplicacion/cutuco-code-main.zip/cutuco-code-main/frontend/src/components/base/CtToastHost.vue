<script setup>
/** CuTuCo — Contenedor de notificaciones temporales (toasts). */
import CtIcon from './CtIcon.vue'
import { iconName } from '@/lib/icons'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const TONE_ICON = {
  success: 'check',
  danger: 'ban',
  warning: 'alert',
  info: 'info',
  accent: 'alert',
}
</script>

<template>
  <Teleport to="body">
    <div class="ct-toasts" aria-live="polite">
      <TransitionGroup name="toast">
        <div
          v-for="toast in ui.toasts"
          :key="toast.id"
          class="ct-toast"
          :class="`ct-toast--${toast.tone}`"
        >
          <span class="ct-toast__icon" aria-hidden="true">
            <CtIcon :name="iconName(TONE_ICON[toast.tone], 'info')" :size="17" />
          </span>
          <div class="ct-toast__content">
            <p class="ct-toast__title">{{ toast.title }}</p>
            <p v-if="toast.message" class="ct-toast__message">{{ toast.message }}</p>
          </div>
          <button
            type="button"
            class="ct-toast__close"
            aria-label="Cerrar notificación"
            @click="ui.dismissToast(toast.id)"
          >
            <CtIcon name="close" :size="15" />
          </button>
        </div>
      </TransitionGroup>
    </div>
  </Teleport>
</template>

<style scoped>
.ct-toasts {
  position: fixed;
  right: var(--ct-space-6);
  bottom: var(--ct-space-6);
  z-index: var(--ct-z-toast);
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  width: min(380px, calc(100vw - 2rem));
}

.ct-toast {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-left-width: 4px;
  border-radius: var(--ct-radius-md);
  box-shadow: var(--ct-shadow-md);
  padding: var(--ct-space-4);
}

.ct-toast--success {
  border-left-color: var(--ct-success);
}
.ct-toast--danger {
  border-left-color: var(--ct-danger);
}
.ct-toast--warning {
  border-left-color: var(--ct-warning);
}
.ct-toast--info {
  border-left-color: var(--ct-info);
}
.ct-toast--accent {
  border-left-color: var(--ct-accent);
}

.ct-toast__icon {
  display: grid;
  place-items: center;
  margin-top: 1px;
}

.ct-toast__content {
  flex: 1;
  min-width: 0;
}

.ct-toast__title {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.ct-toast__message {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  margin-top: 2px;
}

.ct-toast__close {
  color: var(--ct-text-muted);
  display: grid;
  place-items: center;
  align-self: flex-start;
  width: 24px;
  height: 24px;
  margin: -4px -4px 0 0;
  border-radius: var(--ct-radius-sm);
  transition:
    background var(--ct-transition),
    color var(--ct-transition);
}

.ct-toast__close:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.toast-enter-active,
.toast-leave-active {
  transition:
    opacity var(--ct-transition),
    transform var(--ct-transition);
}

.toast-enter-from {
  opacity: 0;
  transform: translateX(24px);
}

.toast-leave-to {
  opacity: 0;
  transform: translateX(24px);
}
</style>
