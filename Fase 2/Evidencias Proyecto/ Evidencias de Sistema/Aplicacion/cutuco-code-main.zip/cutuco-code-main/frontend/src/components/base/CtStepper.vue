<script setup>
/**
 * CuTuCo — Stepper de seguimiento reutilizable.
 * Se usa en el tracking de delivery (cliente y vendedor) y en el alta de
 * postulación de vendedores.
 */
defineProps({
  steps: { type: Array, required: true }, // [{ key, label, description, meta }]
  current: { type: Number, required: true },
  orientation: { type: String, default: 'horizontal' }, // horizontal | vertical
  tone: { type: String, default: 'primary' },
  showDescriptions: { type: Boolean, default: true },
})
</script>

<template>
  <ol class="ct-stepper" :class="[`ct-stepper--${orientation}`, `ct-stepper--${tone}`]">
    <li
      v-for="(step, index) in steps"
      :key="step.key"
      class="ct-stepper__step"
      :class="{
        'is-completed': index < current,
        'is-current': index === current,
        'is-pending': index > current,
        'is-failed': step.failed,
      }"
    >
      <span class="ct-stepper__marker" aria-hidden="true">
        <svg v-if="index < current" viewBox="0 0 16 16" width="12" height="12">
          <path d="M3 8.5l3 3 7-7" fill="none" stroke="currentcolor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
        <span v-else-if="step.failed" class="ct-stepper__x">!</span>
        <span v-else>{{ index + 1 }}</span>
      </span>

      <div class="ct-stepper__content">
        <span class="ct-stepper__label">{{ step.label }}</span>
        <span v-if="showDescriptions && step.description" class="ct-stepper__description">
          {{ step.description }}
        </span>
        <span v-if="step.meta" class="ct-stepper__meta">{{ step.meta }}</span>
      </div>
    </li>
  </ol>
</template>

<style scoped>
.ct-stepper {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  margin: 0;
  padding: 0;
}

.ct-stepper--horizontal {
  flex-direction: row;
  gap: var(--ct-space-2);
}

.ct-stepper--vertical {
  flex-direction: column;
  gap: var(--ct-space-5);
}

.ct-stepper__step {
  display: flex;
  gap: var(--ct-space-3);
  position: relative;
  flex: 1;
  min-width: 0;
}

.ct-stepper--horizontal .ct-stepper__step {
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.ct-stepper--horizontal .ct-stepper__step:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 15px;
  left: calc(50% + 22px);
  width: calc(100% - 44px);
  height: 2px;
  background: var(--ct-border);
}

.ct-stepper--horizontal .ct-stepper__step.is-completed:not(:last-child)::after {
  background: var(--ct-primary);
}

.ct-stepper--vertical .ct-stepper__step:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 34px;
  left: 15px;
  width: 2px;
  height: calc(100% + var(--ct-space-5) - 30px);
  background: var(--ct-border);
}

.ct-stepper--vertical .ct-stepper__step.is-completed:not(:last-child)::after {
  background: var(--ct-primary);
}

.ct-stepper__marker {
  position: relative;
  z-index: 1;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  background: var(--ct-surface);
  color: var(--ct-text-muted);
  border: 2px solid var(--ct-border);
  flex-shrink: 0;
  transition: all var(--ct-transition);
}

.ct-stepper__step.is-completed .ct-stepper__marker {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.ct-stepper__step.is-current .ct-stepper__marker {
  background: var(--ct-surface);
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
  box-shadow: 0 0 0 4px var(--ct-primary-soft);
}

.ct-stepper__step.is-failed .ct-stepper__marker {
  border-color: var(--ct-danger);
  color: var(--ct-danger);
}

.ct-stepper--accent .ct-stepper__step.is-completed .ct-stepper__marker {
  /* --ct-accent-strong con texto invertido: 5.18:1 (accent+accent-ink daba 4.38:1). */
  background: var(--ct-accent-strong);
  border-color: var(--ct-accent-strong);
  color: var(--ct-text-invert);
}

.ct-stepper__content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.ct-stepper__label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-soft);
}

.ct-stepper__step.is-completed .ct-stepper__label,
.ct-stepper__step.is-current .ct-stepper__label {
  color: var(--ct-text);
}

.ct-stepper__description {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ct-stepper__meta {
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
  font-family: var(--ct-font-mono);
}

.ct-stepper__x {
  font-weight: var(--ct-fw-bold);
}
</style>
