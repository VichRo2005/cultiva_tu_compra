<script setup>
/**
 * CuTuCo — Sanciones y apelaciones (módulo secundario del admin).
 * Registro de sanciones con sus efectos sobre el productor y resolución de
 * apelaciones. El trigger `aplicar_efecto_sancion` pausa al productor cuando la
 * sanción queda activa con acción de pausa o suspensión.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { exportExcel } from '@/lib/csv'
import {
  ACCION_SANCION,
  ESTADO_APELACION,
  ESTADO_SANCION,
  LABELS,
  MOTIVOS_SANCION,
  TIPO_SANCION,
} from '@/lib/constants'
import { formatDate, formatDateTime, formatNumber, truncate } from '@/lib/format'
import { listProductores } from '@/services/catalog'
import {
  crearSancion,
  listSanciones,
  resolverSancion,
  reactivarCuentaPermanente,
  validarSancion,
  filtrarSanciones,
} from '@/services/adminSanciones'
import { listApelaciones, resolverApelacion, filtrarApelaciones } from '@/services/adminApelaciones'
import {
  actualizarPalabraProhibida,
  crearPalabraProhibida,
  listCoincidenciasModeradas,
  filtrarPalabras,
} from '@/services/adminModeracion'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const filtros = ref({ texto: '', tipo: '', accion: '', estado: '' })
const filtroApelaciones = ref({ texto: '', estado: '' })
const filtroPalabras = ref({ texto: '', activo: '' })
const pagina = ref(1)
const paginaApelaciones = ref(1)
const tamano = ref(12)
const tamanoApelaciones = ref(12)
const detalle = ref({ abierto: false, sancion: null, apelacion: null })
const confirmarBan = ref(false)
const todas = { value: '', label: 'Todas' }
const opcionesEstado = Object.values(ESTADO_SANCION).map((value) => ({
  value,
  label: LABELS.sancion[value],
}))
const opcionesEstadoApelacion = Object.values(ESTADO_APELACION).map((value) => ({
  value,
  label: LABELS.apelacion[value],
}))
const opcionesActivo = [
  { value: '', label: 'Todas' },
  { value: 'true', label: 'Activas' },
  { value: 'false', label: 'Desactivadas' },
]
const sancionesFiltradas = computed(() => filtrarSanciones(sanciones.value, filtros.value))
const apelacionesFiltradas = computed(() =>
  filtrarApelaciones(apelaciones.value, filtroApelaciones.value),
)
const palabrasFiltradas = computed(() => filtrarPalabras(palabras.value, filtroPalabras.value))
const sancionesPagina = computed(() =>
  sancionesFiltradas.value.slice((pagina.value - 1) * tamano.value, pagina.value * tamano.value),
)
const apelacionesPagina = computed(() =>
  apelacionesFiltradas.value.slice(
    (paginaApelaciones.value - 1) * tamanoApelaciones.value,
    paginaApelaciones.value * tamanoApelaciones.value,
  ),
)
watch(
  [filtros, tamano],
  () => {
    pagina.value = 1
  },
  { deep: true },
)
watch(
  [filtroApelaciones, tamanoApelaciones],
  () => {
    paginaApelaciones.value = 1
  },
  { deep: true },
)

const TABS = [
  { value: 'sanciones', label: 'Sanciones' },
  { value: 'apelaciones', label: 'Apelaciones' },
  { value: 'moderacion', label: 'Moderación' },
]

const route = useRoute()
const pestana = ref(TABS.some((t) => t.value === route.query.tab) ? route.query.tab : 'sanciones')
const sanciones = ref([])
const apelaciones = ref([])
const productores = ref([])
const loading = ref(true)
const error = ref(null)
const guardando = ref(false)

const nuevaAbierto = ref(false)
const formulario = ref({
  productorId: null,
  motivo: '',
  motivoBase: '',
  tipo: TIPO_SANCION.AMONESTACION,
  accion: ACCION_SANCION.NINGUNA,
  duracionDias: '',
})

/**
 * Etiquetas de las acciones del esquema vigente (RF-026): sin acción,
 * suspensión temporal y ban permanente. La amonestación no cambia el estado de
 * la cuenta y la suspensión exige duración.
 */
const ETIQUETAS_ACCION = Object.freeze({
  [ACCION_SANCION.NINGUNA]: 'Sin acción sobre la cuenta',
  [ACCION_SANCION.SUSPENDER]: 'Suspensión temporal',
  [ACCION_SANCION.BAN_PERMANENTE]: 'Ban permanente',
})

/** Mensaje del efecto que la sanción tendrá sobre la tienda (RF-026). */
const efectoSanacion = computed(() => {
  if (formulario.value.tipo === TIPO_SANCION.AMONESTACION) {
    return 'La amonestación queda registrada en el historial del vendedor y no desactiva su tienda.'
  }
  if (formulario.value.accion === ACCION_SANCION.BAN_PERMANENTE) {
    return 'El ban permanente desactiva la cuenta y su tienda. El vendedor no podrá iniciar sesión.'
  }
  if (formulario.value.accion === ACCION_SANCION.SUSPENDER) {
    return 'La suspensión desactiva la tienda del vendedor durante los días indicados.'
  }
  return 'Selecciona una acción que afecte la cuenta o deja la sanción sin efecto operativo.'
})

const resolucion = ref({ abierto: false, apelacion: null, texto: '', decision: null })
const confirmacion = ref({ abierto: false, sancion: null, accion: null })

/* ------------------------- Moderación (RF-004) ------------------------- */

const palabras = ref([])
const coincidencias = ref([])
const moderacion = ref({ cargando: true, error: null, nueva: '', guardando: false })

const columnasSanciones = [
  { key: 'productor', label: 'Productor', width: '24%' },
  { key: 'tipo', label: 'Tipo' },
  { key: 'motivo', label: 'Motivo' },
  { key: 'accion', label: 'Acción' },
  { key: 'estado', label: 'Estado' },
  { key: 'inicio', label: 'Inicio' },
  { key: 'fin', label: 'Fin' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const columnasApelaciones = [
  { key: 'productor', label: 'Productor', width: '24%' },
  { key: 'sancion', label: 'Sanción' },
  { key: 'fundamento', label: 'Fundamento' },
  { key: 'estado', label: 'Estado' },
  { key: 'fecha', label: 'Creada' },
  { key: 'resolucion', label: 'Resolución' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const opcionesProductor = computed(() =>
  productores.value.map((p) => ({ value: p.id, label: p.nombre_comercial })),
)

const opcionesMotivo = computed(() => [
  ...MOTIVOS_SANCION.map((m) => ({ value: m, label: m })),
  { value: '', label: 'Escribir el motivo manualmente' },
])

/** El motivo del catálogo precarga el detalle editable. */
function elegirMotivoBase() {
  formulario.value.motivo = formulario.value.motivoBase ?? ''
}

const opcionesTipo = computed(() =>
  Object.values(TIPO_SANCION).map((t) => ({ value: t, label: LABELS.tipoSancion[t] })),
)

const banExistente = computed(() =>
  sanciones.value.some(
    (s) =>
      s.productor_id === formulario.value.productorId &&
      s.accion === ACCION_SANCION.BAN_PERMANENTE &&
      ['activa', 'apelada'].includes(s.estado),
  ),
)
watch(
  () => formulario.value.tipo,
  (tipo) => {
    formulario.value.accion =
      tipo === TIPO_SANCION.AMONESTACION ? ACCION_SANCION.NINGUNA : ACCION_SANCION.SUSPENDER
  },
)
const opcionesAccionFiltro = Object.values(ACCION_SANCION).map((value) => ({
  value,
  label: ETIQUETAS_ACCION[value],
}))
const opcionesAccion = computed(() =>
  [ACCION_SANCION.NINGUNA, ACCION_SANCION.SUSPENDER, ACCION_SANCION.BAN_PERMANENTE].map((a) => ({
    value: a,
    label: ETIQUETAS_ACCION[a],
    disabled:
      (a === ACCION_SANCION.BAN_PERMANENTE && banExistente.value) ||
      (formulario.value.tipo === TIPO_SANCION.SUSPENSION && a === ACCION_SANCION.NINGUNA),
  })),
)

const columnasPalabras = [
  { key: 'palabra', label: 'Palabra o frase', width: '45%' },
  { key: 'activo', label: 'Estado' },
  { key: 'creado', label: 'Agregada' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const columnasCoincidencias = [
  { key: 'producto', label: 'Producto', width: '30%' },
  { key: 'productor', label: 'Vendedor' },
  { key: 'palabras', label: 'Coincidencias' },
  { key: 'activo', label: 'Publicado' },
]

const kpis = computed(() => ({
  activas: sanciones.value.filter((s) => s.estado === ESTADO_SANCION.ACTIVA).length,
  apeladas: sanciones.value.filter((s) => s.estado === ESTADO_SANCION.APELADA).length,
  resueltas: sanciones.value.filter((s) => s.estado === ESTADO_SANCION.RESUELTA).length,
  apelacionesPendientes: apelaciones.value.filter((a) => a.estado === ESTADO_APELACION.PENDIENTE)
    .length,
}))

function sancionActiva(sancion) {
  return sancion.estado === ESTADO_SANCION.ACTIVA
}

function sancionApelada(sancion) {
  return sancion.estado === ESTADO_SANCION.APELADA
}

async function cargar() {
  loading.value = true
  error.value = null
  try {
    const [listaSanciones, listaApelaciones, listaProductores] = await Promise.all([
      listSanciones(),
      listApelaciones(),
      listProductores(),
    ])
    pagina.value = 1
    paginaApelaciones.value = 1
    sanciones.value = listaSanciones
    apelaciones.value = listaApelaciones
    productores.value = listaProductores
  } catch (e) {
    error.value = e.message
    sanciones.value = []
    apelaciones.value = []
    productores.value = []
  } finally {
    loading.value = false
  }
}

/** RF-004: blacklist de palabras prohibidas revisada con el operador LIKE. */
async function cargarModeracion() {
  moderacion.value.cargando = true
  moderacion.value.error = null
  try {
    const resultado = await listCoincidenciasModeradas()
    palabras.value = resultado.palabras
    coincidencias.value = resultado.coincidencias
  } catch (e) {
    moderacion.value.error = e.message
    palabras.value = []
    coincidencias.value = []
  } finally {
    moderacion.value.cargando = false
  }
}

async function agregarPalabra() {
  const palabra = moderacion.value.nueva.trim()
  if (palabra.length < 2) {
    ui.warning(
      'Palabra muy corta',
      'Ingresa al menos 2 caracteres para evitar coincidencias accidentales.',
    )
    return
  }
  moderacion.value.guardando = true
  try {
    await crearPalabraProhibida(palabra)
    moderacion.value.nueva = ''
    ui.success('Palabra agregada', 'La moderación la revisará en los próximos textos.')
    await cargarModeracion()
  } catch (e) {
    ui.error('No se pudo agregar la palabra', e.message)
  } finally {
    moderacion.value.guardando = false
  }
}

async function alternarPalabra(palabra) {
  try {
    await actualizarPalabraProhibida(palabra.id, { activo: !palabra.activo })
    ui.success(
      palabra.activo ? 'Palabra desactivada' : 'Palabra reactivada',
      'Las palabras inactivas dejan de marcar coincidencias.',
    )
    await cargarModeracion()
  } catch (e) {
    ui.error('No se pudo actualizar la palabra', e.message)
  }
}

// @deprecated - movido a adminSanciones.js - ya no se usa por nuevo consumo
// async function registrarSancion() {
//   if (!formulario.value.productorId) {
//     ui.warning('Selecciona un vendedor', 'La sanción debe identificar al vendedor afectado.')
//     return
//   }
//   const motivo = formulario.value.motivo.trim()
//   if (!motivo) {
//     ui.warning('Motivo requerido', 'Explica el motivo de la sanción.')
//     return
//   }
//   const esSuspension = formulario.value.tipo === TIPO_SANCION.SUSPENSION
//   const duracion = Number(formulario.value.duracionDias)
//   if (
//     esSuspension &&
//     formulario.value.accion === ACCION_SANCION.SUSPENDER &&
//     (!Number.isInteger(duracion) || duracion <= 0)
//   ) {
//     ui.warning('Duración requerida', 'Indica cuántos días durará la suspensión.')
//     return
//   }
//   guardando.value = true
//   try {
//     await crearSancion({
//       productorId: formulario.value.productorId,
//       motivo,
//       tipo: formulario.value.tipo,
//       accion: esSuspension ? formulario.value.accion : ACCION_SANCION.NINGUNA,
//       duracionDias:
//         esSuspension && formulario.value.accion === ACCION_SANCION.SUSPENDER ? duracion : null,
//     })
//     ui.success('Sanción registrada', 'El efecto sobre la cuenta del vendedor se aplicó según la acción elegida.')
//     nuevaAbierto.value = false
//     formulario.value = {
//       productorId: null,
//       motivo: '',
//       motivoBase: '',
//       tipo: TIPO_SANCION.AMONESTACION,
//       accion: ACCION_SANCION.NINGUNA,
//       duracionDias: '',
//     }
//     await cargar()
//   } catch (e) {
//     ui.error('No se pudo registrar la sanción', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
//
async function registrarSancion(confirmado = false) {
  if (guardando.value) return
  try {
    validarSancion(formulario.value)
    if (formulario.value.accion === ACCION_SANCION.BAN_PERMANENTE) {
      if (banExistente.value) throw new Error('Este usuario ya tiene un ban permanente activo.')
      if (confirmado !== true) {
        confirmarBan.value = true
        return
      }
    }
    guardando.value = true
    await crearSancion(formulario.value)
    confirmarBan.value = false
    nuevaAbierto.value = false
    ui.success('Sanción registrada', 'Se aplicó la acción seleccionada.')
    formulario.value = {
      productorId: null,
      motivo: '',
      motivoBase: '',
      tipo: TIPO_SANCION.AMONESTACION,
      accion: ACCION_SANCION.NINGUNA,
      duracionDias: '',
    }
    await cargar()
  } catch (e) {
    ui.error('Revisa la sanción', e.message)
    confirmarBan.value = false
  } finally {
    guardando.value = false
  }
}

function pedirResolucion(sancion, accion) {
  confirmacion.value = { abierto: true, sancion, accion }
}

// @deprecated - movido a adminSanciones.js - ya no se usa por nuevo consumo
// async function confirmarSancion() {
//   const { sancion, accion } = confirmacion.value
//   if (!sancion) return
//   guardando.value = true
//   try {
//     await resolverSancion(sancion.id, accion === 'resolver' ? ESTADO_SANCION.RESUELTA : ESTADO_SANCION.CANCELADA)
//     sancion.estado = accion === 'resolver' ? ESTADO_SANCION.RESUELTA : ESTADO_SANCION.CANCELADA
//     sancion.resuelta_en = new Date().toISOString()
//     ui.success(
//       accion === 'resolver' ? 'Sanción resuelta' : 'Sanción revertida',
//       `${sancion.productor?.nombre_comercial ?? 'El productor'} queda en estado ${LABELS.sancion[sancion.estado]}.`,
//     )
//     confirmacion.value = { abierto: false, sancion: null, accion: null }
//   } catch (e) {
//     ui.error('No se pudo actualizar la sanción', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
//
async function confirmarSancion() {
  const { sancion, accion } = confirmacion.value
  if (!sancion || guardando.value) return
  guardando.value = true
  try {
    if (accion === 'reactivar') await reactivarCuentaPermanente(sancion.id)
    else await resolverSancion(sancion.id, ESTADO_SANCION.CANCELADA)
    ui.success(accion === 'reactivar' ? 'Cuenta reactivada' : 'Sanción cancelada')
    confirmacion.value.abierto = false
    await cargar()
  } catch (e) {
    ui.error('No se pudo actualizar la sanción', e.message)
  } finally {
    guardando.value = false
  }
}

function abrirResolucion(apelacion, decision) {
  resolucion.value = { abierto: true, apelacion, texto: '', decision }
}

// @deprecated - movido a adminApelaciones.js - ya no se usa por nuevo consumo
// async function confirmarResolucion() {
//   const { apelacion, decision, texto } = resolucion.value
//   const textoResolucion = texto.trim()
//   if (!apelacion) return
//   if (!textoResolucion) {
//     ui.warning('Escribe la resolución', 'El productor debe leer el fundamento de la decisión.')
//     return
//   }
//   guardando.value = true
//   try {
//     await resolverApelacion(
//       apelacion.id,
//       decision === 'aprobar' ? ESTADO_APELACION.APROBADA : ESTADO_APELACION.RECHAZADA,
//       textoResolucion,
//     )
//     if (decision === 'aprobar') {
//       await resolverSancion(apelacion.sancion_id, ESTADO_SANCION.CANCELADA)
//       ui.success('Apelación aprobada', 'La sanción asociada quedó cancelada.')
//     } else {
//       ui.success('Apelación rechazada', 'La sanción se mantiene en su estado actual.')
//     }
//     await cargar()
//     resolucion.value = { abierto: false, apelacion: null, texto: '', decision: null }
//   } catch (e) {
//     ui.error('No se pudo resolver la apelación', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
//
async function confirmarResolucion() {
  const { apelacion, decision, texto } = resolucion.value
  if (!apelacion || guardando.value) return
  guardando.value = true
  try {
    const resultado = await resolverApelacion(
      apelacion.id,
      decision === 'aprobar' ? ESTADO_APELACION.APROBADA : ESTADO_APELACION.RECHAZADA,
      texto,
    )
    ui.success(
      decision === 'aprobar' ? 'Apelación aprobada' : 'Apelación rechazada',
      decision === 'aprobar'
        ? resultado.otrasSancionesVigentes
          ? 'La sanción quedó resuelta. Hay otras sanciones vigentes.'
          : 'La sanción quedó resuelta.'
        : 'La sanción vuelve a estar activa y puede apelarse nuevamente.',
    )
    resolucion.value.abierto = false
    await cargar()
  } catch (e) {
    ui.error('No se pudo resolver la apelación', e.message)
  } finally {
    guardando.value = false
  }
}

async function exportarSanciones() {
  if (!sanciones.value.length) {
    ui.warning('Sin datos para exportar', 'No hay sanciones registradas.')
    return
  }
  const ok = await exportExcel(
    sanciones.value.map((s) => ({
      productor: s.productor?.nombre_comercial ?? '—',
      tipo: LABELS.tipoSancion[s.tipo] ?? s.tipo,
      motivo: s.motivo,
      accion: ETIQUETAS_ACCION[s.accion] ?? s.accion,
      estado: LABELS.sancion[s.estado] ?? s.estado,
      amonestacion: s.numero_amonestacion ?? '',
      duracion_dias: s.duracion_dias ?? '',
      inicio: s.inicio_en,
      fin: s.fin_en ?? '',
    })),
    'cutuco-sanciones',
    [
      { key: 'productor', label: 'Vendedor' },
      { key: 'tipo', label: 'Tipo' },
      { key: 'motivo', label: 'Motivo' },
      { key: 'accion', label: 'Acción' },
      { key: 'estado', label: 'Estado' },
      { key: 'amonestacion', label: 'N° amonestación' },
      { key: 'duracion_dias', label: 'Duración (días)' },
      { key: 'inicio', label: 'Inicio' },
      { key: 'fin', label: 'Fin' },
    ],
  )
  if (ok) ui.success('Listado exportado', 'Se descargó el Excel de sanciones.')
  else ui.error('No se pudo exportar', 'No hay filas para exportar.')
}

onMounted(() => {
  cargar()
  cargarModeracion()
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Sanciones y moderación</h1>
        <p class="page-head__subtitle">
          Sanciones manuales al vendedor, respuesta a sus apelaciones y control de la lista de
          palabras prohibidas.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="loading" @click="exportarSanciones">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton :loading="loading" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el módulo">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner
      v-if="loading && !sanciones.length && !apelaciones.length"
      label="Cargando sanciones…"
    />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Sanciones activas"
          :value="formatNumber(kpis.activas)"
          icon="scale"
          tone="danger"
          hint="Productores pausados o suspendidos"
        />
        <CtStatCard
          label="Apeladas"
          :value="formatNumber(kpis.apeladas)"
          icon="doc"
          tone="warning"
          hint="Con recurso presentado por el productor"
        />
        <CtStatCard
          label="Resueltas"
          :value="formatNumber(kpis.resueltas)"
          icon="check"
          tone="success"
          hint="Cerradas por un administrador"
        />
        <CtStatCard
          label="Apelaciones por resolver"
          :value="formatNumber(kpis.apelacionesPendientes)"
          icon="clock"
          tone="info"
          :hint="`${apelaciones.length} recursos registrados`"
        />
      </div>

      <CtAlert tone="neutral" compact title="Efectos de una sanción">
        <p>
          La <strong>amonestación</strong> sólo deja constancia en el historial del vendedor. La
          <strong>suspensión</strong> desactiva la tienda durante los días indicados y el
          <strong>ban permanente</strong> la desactiva sin fecha de término. Toda sanción la decides
          tú: no existen acciones automáticas por reputación.
        </p>
      </CtAlert>

      <CtCard padding="md">
        <CtTabs v-model="pestana" :tabs="TABS" stretch />

        <div v-if="pestana === 'sanciones'" class="panel stack">
          <div class="row row--between row--wrap">
            <h2 class="section-title">Sanciones</h2>
            <CtButton @click="nuevaAbierto = true">Generar sanción</CtButton>
          </div>
          <CtSearchInput
            v-model="filtros.texto"
            placeholder="Buscar por usuario, motivo o ID…"
            aria-label="Buscar sanciones"
          />
          <div class="grid">
            <CtSelect
              v-model="filtros.tipo"
              class="col-4"
              label="Tipo"
              :options="[todas, ...opcionesTipo]"
            />
            <CtSelect
              v-model="filtros.accion"
              class="col-4"
              label="Acción"
              :options="[todas, ...opcionesAccionFiltro]"
            />
            <CtSelect
              v-model="filtros.estado"
              class="col-4"
              label="Estado"
              :options="[todas, ...opcionesEstado]"
            />
          </div>
          <CtTable
            :columns="columnasSanciones"
            :rows="sancionesPagina"
            :loading="loading"
            dense
            min-width="980px"
            empty-icon="scale"
            empty-title="Sin sanciones"
            empty-message="No hay sanciones registradas en la plataforma."
          >
            <template #cell-productor="{ row }">
              <div class="productor">
                <p class="productor__nombre">
                  {{ row.productor?.nombre_comercial ?? 'Vendedor eliminado' }}
                </p>
                <p class="productor__meta">
                  {{
                    [row.perfil?.nombre, row.perfil?.apellido].filter(Boolean).join(' ') ||
                    'Sin perfil'
                  }}
                  <template v-if="row.numero_amonestacion">
                    · amonestación N° {{ row.numero_amonestacion }}
                  </template>
                  <template v-if="row.duracion_dias"> · {{ row.duracion_dias }} día(s)</template>
                </p>
              </div>
            </template>

            <template #cell-tipo="{ row }">
              <CtBadge
                :tone="row.tipo === TIPO_SANCION.SUSPENSION ? 'danger' : 'warning'"
                size="sm"
              >
                {{ LABELS.tipoSancion[row.tipo] ?? row.tipo }}
              </CtBadge>
            </template>

            <template #cell-motivo="{ row }">
              <span class="text-sm clamp-2">{{ row.motivo }}</span>
            </template>

            <template #cell-accion="{ row }">
              <span class="text-sm">{{ ETIQUETAS_ACCION[row.accion] ?? row.accion }}</span>
            </template>

            <template #cell-estado="{ row }">
              <StatusBadge type="sancion" :value="row.estado" />
            </template>

            <template #cell-inicio="{ row }">
              <span class="text-sm text-muted">{{ formatDate(row.inicio_en) }}</span>
            </template>

            <template #cell-fin="{ row }">
              <span class="text-sm text-muted">{{
                row.fin_en ? formatDate(row.fin_en) : 'Indefinida'
              }}</span>
            </template>

            <template #cell-acciones="{ row }">
              <div class="acciones">
                <CtButton
                  size="sm"
                  variant="ghost"
                  @click="detalle = { abierto: true, sancion: row, apelacion: null }"
                  >Ver detalles</CtButton
                >
                <CtButton
                  v-if="sancionActiva(row) && row.accion === ACCION_SANCION.BAN_PERMANENTE"
                  size="sm"
                  variant="ghost"
                  :disabled="guardando"
                  @click="pedirResolucion(row, 'reactivar')"
                  >Reactivar cuenta</CtButton
                >
                <CtButton
                  v-else-if="
                    (sancionActiva(row) || sancionApelada(row)) &&
                    row.accion !== ACCION_SANCION.BAN_PERMANENTE
                  "
                  size="sm"
                  variant="ghost"
                  :disabled="guardando"
                  @click="pedirResolucion(row, 'cancelar')"
                  >Cancelar</CtButton
                >
              </div>
            </template>
          </CtTable>
          <CtPagination
            v-model:page="pagina"
            v-model:page-size="tamano"
            :total="sancionesFiltradas.length"
          />
        </div>

        <div v-else-if="pestana === 'apelaciones'" class="panel stack">
          <div class="admin-sanciones__filtros">
            <CtSearchInput
              v-model="filtroApelaciones.texto"
              label="Buscar apelaciones"
              placeholder="Buscar usuario, fundamento o ID…"
              aria-label="Buscar apelaciones"
            />
            <CtSelect
              v-model="filtroApelaciones.estado"
              label="Estado"
              :options="[todas, ...opcionesEstadoApelacion]"
            />
          </div>
          <CtTable
            :columns="columnasApelaciones"
            :rows="apelacionesPagina"
            :loading="loading"
            dense
            min-width="980px"
            empty-icon="doc"
            empty-title="Sin apelaciones"
            empty-message="Ningún productor ha presentado un recurso contra una sanción."
          >
            <template #cell-productor="{ row }">
              <p class="productor__nombre">
                {{ row.productor?.nombre_comercial ?? 'Productor eliminado' }}
              </p>
            </template>

            <template #cell-sancion="{ row }">
              <span class="mono text-xs" :title="row.sancion_id">{{
                String(row.sancion_id).slice(0, 8)
              }}</span>
            </template>

            <template #cell-fundamento="{ row }">
              <span class="text-sm">{{ truncate(row.fundamento, 70) }}</span>
            </template>

            <template #cell-estado="{ row }">
              <StatusBadge type="apelacion" :value="row.estado" />
            </template>

            <template #cell-fecha="{ row }">
              <span class="text-sm text-muted">{{ formatDate(row.creado_en) }}</span>
            </template>

            <template #cell-resolucion="{ row }">
              <span class="text-sm text-muted">{{
                row.resolucion ? truncate(row.resolucion, 50) : '—'
              }}</span>
            </template>

            <template #cell-acciones="{ row }">
              <div class="acciones">
                <CtButton
                  size="sm"
                  variant="ghost"
                  @click="detalle = { abierto: true, sancion: row.sancion, apelacion: row }"
                  >Ver detalle</CtButton
                >
                <template
                  v-if="
                    row.estado === ESTADO_APELACION.PENDIENTE &&
                    row.sancion?.accion !== ACCION_SANCION.BAN_PERMANENTE &&
                    row.sancion?.estado === ESTADO_SANCION.APELADA
                  "
                >
                  <CtButton size="sm" variant="ghost" @click="abrirResolucion(row, 'aprobar')">
                    Aprobar
                  </CtButton>
                  <CtButton size="sm" variant="ghost" @click="abrirResolucion(row, 'rechazar')">
                    Rechazar
                  </CtButton>
                </template>
                <span v-else class="text-xs text-muted">
                  {{ row.resuelto_en ? formatDateTime(row.resuelto_en) : 'Cerrada' }}
                </span>
              </div>
            </template>
          </CtTable>
          <CtPagination
            v-model:page="paginaApelaciones"
            v-model:page-size="tamanoApelaciones"
            :total="apelacionesFiltradas.length"
          />
        </div>

        <!-- ============ Moderación con palabras prohibidas ============ -->
        <div v-else class="panel">
          <CtAlert v-if="moderacion.error" tone="danger" title="No se pudo cargar la moderación">
            <p>{{ moderacion.error }}</p>
            <CtButton size="sm" variant="secondary" @click="cargarModeracion">Reintentar</CtButton>
          </CtAlert>

          <div class="admin-sanciones__moderacion-barra">
            <CtSearchInput
              v-model="filtroPalabras.texto"
              label="Buscar palabras"
              placeholder="Buscar palabras…"
              aria-label="Buscar palabras prohibidas"
            />
            <CtSelect v-model="filtroPalabras.activo" label="Estado" :options="opcionesActivo" />
            <div class="admin-sanciones__alta">
              <CtInput
                v-model="moderacion.nueva"
                label="Agregar palabra o frase prohibida"
                placeholder="Ej: falsificado"
                @enter="agregarPalabra"
              />
              <CtButton :loading="moderacion.guardando" @click="agregarPalabra">Agregar</CtButton>
            </div>
          </div>
          <p class="admin-sanciones__ayuda text-xs text-muted">
            La revisión de palabras no distingue entre mayúsculas y minúsculas.
          </p>

          <CtSpinner
            v-if="moderacion.cargando && !palabras.length"
            inline
            label="Cargando lista…"
          />

          <CtTable
            :columns="columnasPalabras"
            :rows="palabrasFiltradas"
            :loading="moderacion.cargando"
            dense
            min-width="720px"
            empty-icon="shield"
            empty-title="Sin palabras configuradas"
            empty-message="Agrega la primera palabra para que la moderación marque coincidencias."
          >
            <template #cell-palabra="{ row }">
              <span class="mono">{{ row.palabra }}</span>
            </template>

            <template #cell-activo="{ row }">
              <CtBadge :tone="row.activo ? 'success' : 'neutral'" size="sm" dot>
                {{ row.activo ? 'Activa' : 'Desactivada' }}
              </CtBadge>
            </template>

            <template #cell-creado="{ row }">
              <span class="text-sm text-muted">{{ formatDate(row.creado_en) }}</span>
            </template>

            <template #cell-acciones="{ row }">
              <div class="acciones">
                <CtButton size="sm" variant="ghost" @click="alternarPalabra(row)">
                  {{ row.activo ? 'Desactivar' : 'Reactivar' }}
                </CtButton>
              </div>
            </template>
          </CtTable>

          <h3 class="moderacion__titulo">Productos con coincidencias</h3>
          <CtTable
            :columns="columnasCoincidencias"
            :rows="coincidencias"
            :loading="moderacion.cargando"
            dense
            min-width="820px"
            empty-icon="check"
            empty-title="Sin coincidencias"
            empty-message="Ningún producto publicado contiene una palabra de la lista."
          >
            <template #cell-producto="{ row }">
              <div class="productor">
                <p class="productor__nombre">{{ row.nombre }}</p>
                <p class="productor__meta">
                  {{ truncate(row.descripcion ?? 'Sin descripción', 70) }}
                </p>
              </div>
            </template>

            <template #cell-productor="{ row }">
              <span class="text-sm">{{ row.productor?.nombre_comercial ?? '—' }}</span>
            </template>

            <template #cell-palabras="{ row }">
              <div class="chips">
                <CtBadge v-for="p in row.palabras" :key="p" tone="danger" size="sm">{{
                  p
                }}</CtBadge>
              </div>
            </template>

            <template #cell-activo="{ row }">
              <CtBadge :tone="row.activo ? 'success' : 'neutral'" size="sm">
                {{ row.activo ? 'Publicado' : 'Desactivado' }}
              </CtBadge>
            </template>
          </CtTable>

          <p class="moderacion__nota">
            El administrador decide qué hacer con cada coincidencia: puede desactivar el producto
            desde <router-link to="/admin/productos">Productos y categorías</router-link> o aplicar
            una sanción al vendedor.
          </p>
        </div>
      </CtCard>
    </template>

    <!-- ==================== Nueva sanción ==================== -->
    <CtModal
      v-model="nuevaAbierto"
      title="Nueva sanción"
      subtitle="La acción elegida se aplica sobre la tienda del productor"
      size="md"
    >
      <div class="stack admin-sanciones__formulario">
        <CtSelect
          v-model="formulario.productorId"
          label="Vendedor"
          required
          :options="opcionesProductor"
          placeholder="Seleccionar vendedor…"
        />
        <CtSelect
          v-model="formulario.motivoBase"
          label="Motivo"
          :options="opcionesMotivo"
          @change="elegirMotivoBase"
        />
        <CtTextarea
          v-model="formulario.motivo"
          label="Detalle del motivo"
          :rows="3"
          :maxlength="2500"
          show-count
          placeholder="Describe los hechos que justifican la medida."
        />
        <div class="form__fila">
          <CtSelect v-model="formulario.tipo" label="Tipo de sanción" :options="opcionesTipo" />
          <CtSelect
            v-model="formulario.accion"
            label="Acción sobre la cuenta"
            :title="banExistente ? 'Este usuario ya tiene un ban permanente activo.' : ''"
            :hint="
              banExistente ? 'Ban permanente no disponible: el usuario ya tiene uno vigente.' : null
            "
            :options="opcionesAccion"
            :disabled="formulario.tipo === TIPO_SANCION.AMONESTACION"
          />
        </div>
        <CtInput
          v-if="
            formulario.tipo === TIPO_SANCION.SUSPENSION &&
            formulario.accion === ACCION_SANCION.SUSPENDER
          "
          v-model="formulario.duracionDias"
          type="number"
          min="1"
          max="60"
          step="1"
          label="Duración de la suspensión"
          suffix="días"
          hint="Número entero entre 1 y 60 días."
        />
        <CtAlert tone="info" compact title="Efecto de la sanción">
          <p>{{ efectoSanacion }}</p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="nuevaAbierto = false">Cancelar</CtButton>
        <CtButton :loading="guardando" @click="registrarSancion">Registrar sanción</CtButton>
      </template>
    </CtModal>

    <!-- ==================== Resolución de apelación ==================== -->
    <CtModal
      v-model="resolucion.abierto"
      :title="resolucion.decision === 'aprobar' ? 'Aprobar apelación' : 'Rechazar apelación'"
      :subtitle="resolucion.apelacion?.productor?.nombre_comercial ?? ''"
      size="md"
    >
      <div class="stack">
        <CtAlert
          :tone="resolucion.decision === 'aprobar' ? 'success' : 'warning'"
          compact
          :title="
            resolucion.decision === 'aprobar'
              ? 'La sanción quedará resuelta'
              : 'La sanción se mantiene'
          "
        >
          <p v-if="resolucion.decision === 'aprobar'">
            Al aprobar, la sanción queda resuelta. La tienda solo se reactiva cuando no quedan
            sanciones vigentes y la cuenta está activa.
          </p>
          <p v-else>
            Al rechazar, la sanción vuelve a estar activa y el vendedor puede apelar nuevamente.
          </p>
        </CtAlert>
        <CtTextarea
          v-model="resolucion.texto"
          label="Resolución"
          required
          :rows="5"
          :maxlength="3000"
          show-count
          placeholder="Fundamento de la decisión que leerá el productor."
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="resolucion.abierto = false">Cancelar</CtButton>
        <CtButton :loading="guardando" @click="confirmarResolucion">
          {{ resolucion.decision === 'aprobar' ? 'Aprobar apelación' : 'Rechazar apelación' }}
        </CtButton>
      </template>
    </CtModal>

    <CtModal
      v-model="detalle.abierto"
      :title="detalle.apelacion ? 'Detalle de apelación' : 'Detalle de sanción'"
      size="lg"
    >
      <div class="stack admin-sanciones__detalle">
        <template v-if="detalle.apelacion">
          <h3>Apelación {{ detalle.apelacion.id }}</h3>
          <p>{{ detalle.apelacion.fundamento }}</p>
          <StatusBadge type="apelacion" :value="detalle.apelacion.estado" />
          <p>Resolución: {{ detalle.apelacion.resolucion || 'Pendiente' }}</p>
        </template>
        <template v-if="detalle.sancion">
          <h3>Sanción {{ detalle.sancion.id }}</h3>
          <p>{{ detalle.sancion.productor?.nombre_comercial }}</p>
          <p>{{ detalle.sancion.motivo }}</p>
          <p>
            {{ LABELS.tipoSancion[detalle.sancion.tipo] }} ·
            {{ ETIQUETAS_ACCION[detalle.sancion.accion] }}
          </p>
          <StatusBadge type="sancion" :value="detalle.sancion.estado" />
          <p>
            Inicio: {{ formatDateTime(detalle.sancion.inicio_en) }} · Fin:
            {{ detalle.sancion.fin_en ? formatDateTime(detalle.sancion.fin_en) : 'Indefinido' }}
          </p>
        </template>
      </div>
      <template #footer
        ><CtButton variant="secondary" @click="detalle.abierto = false">Cerrar</CtButton></template
      >
    </CtModal>
    <CtConfirmDialog
      v-model="confirmarBan"
      title="Confirmar ban permanente"
      confirm-label="Aplicar ban permanente"
      tone="danger"
      :loading="guardando"
      message="Esta acción es irreversible y desactivará permanentemente la cuenta. ¿Estás seguro de hacerlo?"
      @confirm="registrarSancion(true)"
    />
    <CtConfirmDialog
      v-model="confirmacion.abierto"
      :title="confirmacion.accion === 'reactivar' ? 'Reactivar cuenta' : 'Cancelar sanción'"
      :confirm-label="confirmacion.accion === 'reactivar' ? 'Reactivar cuenta' : 'Cancelar sanción'"
      tone="danger"
      :loading="guardando"
      :message="
        confirmacion.accion === 'reactivar'
          ? 'Se reactivará la cuenta y su tienda, y el ban quedará resuelto. No debe haber otras sanciones vigentes.'
          : 'La sanción quedará cancelada. La tienda se reactivará solo si no quedan sanciones vigentes.'
      "
      @confirm="confirmarSancion"
    />
  </div>
</template>

<style scoped>
.admin-sanciones__detalle {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.panel {
  margin-top: var(--ct-space-5);
}

.productor__nombre {
  font-weight: var(--ct-fw-semibold);
}

.productor__meta {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.acciones {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: var(--ct-space-2);
}

.form__fila {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
}

.admin-sanciones__filtros,
.admin-sanciones__moderacion-barra,
.admin-sanciones__alta {
  display: grid;
  align-items: end;
  gap: var(--ct-space-3);
  min-width: 0;
}

.admin-sanciones__filtros {
  grid-template-columns: minmax(0, 2fr) minmax(0, 1fr);
}

.admin-sanciones__moderacion-barra {
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.6fr) minmax(0, 1.5fr);
}

.admin-sanciones__alta {
  grid-template-columns: minmax(0, 1fr) auto;
}

/* Los tamaños de CtInput y CtSelect no coinciden; se igualan solo en estas barras. */
.admin-sanciones__filtros :deep(.ct-field__control),
.admin-sanciones__filtros :deep(.ct-select__control),
.admin-sanciones__moderacion-barra :deep(.ct-field__control),
.admin-sanciones__moderacion-barra :deep(.ct-select__control) {
  height: var(--ct-space-10);
  min-height: var(--ct-space-10);
}

.admin-sanciones__ayuda {
  margin-top: var(--ct-space-2);
  margin-bottom: var(--ct-space-4);
}

/* CtSelect no expone ancho: permite encoger las opciones largas dentro del modal móvil. */
.admin-sanciones__formulario :deep(.ct-select__select) {
  min-width: 0;
}

@media (max-width: 980px) {
  .admin-sanciones__moderacion-barra {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .admin-sanciones__alta {
    grid-column: 1 / -1;
  }
}

.moderacion__titulo {
  margin: var(--ct-space-6) 0 var(--ct-space-3);
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
}

.moderacion__nota {
  margin-top: var(--ct-space-4);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-1);
}

@media (max-width: 720px) {
  .form__fila,
  .admin-sanciones__filtros,
  .admin-sanciones__moderacion-barra {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
