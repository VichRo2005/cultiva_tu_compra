/**
 * CuTuCo — Carrito de compras (RF-002, RF-009 y RF-014).
 *
 * Estas pruebas fijan las reglas que el carrito promete cumplir y que hasta
 * ahora no tenía cubiertas: el monocarrito (un pedido = un productor), la
 * validación de stock al agregar y al ajustar cantidades, y el cálculo del
 * resumen (subtotal + tarifa fija de despacho + IVA; el fee de plataforma se
 * descuenta al vendedor, no se suma al comprador).
 *
 * La vista `CartView.vue` consume `porVendedor` / `requiereVariosVendedores` /
 * `vendedorPrincipal`: si esos nombres cambian, estas pruebas lo detectan.
 */
import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import { REGLAS } from '@/lib/constants'
import { useCartStore } from '@/stores/cart'

function producto(overrides = {}) {
  return {
    id: '30000000-0000-0000-0000-000000000101',
    nombre: 'Tomates Roma de Paine',
    precio: 2800,
    stock: 10,
    unidad_medida: 'kg',
    productor_id: '20000000-0000-0000-0000-000000000001',
    productor: { nombre_comercial: 'Huerta Paine' },
    imagenPrincipal: null,
    ...overrides,
  }
}

const OTRO_PRODUCTOR = {
  productor_id: '20000000-0000-0000-0000-000000000002',
  productor: { nombre_comercial: 'Valle Melipilla' },
}

describe('carrito · disponibilidad', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('redondea la comisión por tienda y recarga el IVA al comprador', () => {
    const cart = useCartStore()
    cart.agregar(producto({ precio: 10 }), 1)
    cart.agregar(producto({ id: 'otro', precio: 10, ...OTRO_PRODUCTOR }), 1)
    expect(cart.subtotal).toBe(20)
    expect(cart.comision).toBe(2) // 0,5 -> 1 en cada tienda; no 1 por todo el carrito.
    expect(cart.baseImponible).toBe(7020)
    expect(cart.iva).toBe(1334)
    expect(cart.total).toBe(8354)
  })

  it('rechaza un producto sin stock', () => {
    const cart = useCartStore()
    expect(() => cart.agregar(producto({ stock: 0 }))).toThrow(/no tiene stock/i)
    expect(cart.vacio).toBe(true)
  })

  it('no permite agregar más unidades que el stock disponible', () => {
    const cart = useCartStore()
    expect(() => cart.agregar(producto({ stock: 3 }), 4)).toThrow(/Sólo quedan 3/i)
    expect(cart.vacio).toBe(true)
  })

  it('acumula cantidades del mismo producto y respeta el tope del stock', () => {
    const cart = useCartStore()
    cart.agregar(producto({ stock: 5 }), 3)
    cart.agregar(producto({ stock: 5 }), 2)
    expect(cart.cantidadDe('30000000-0000-0000-0000-000000000101')).toBe(5)
    expect(() => cart.agregar(producto({ stock: 5 }), 1)).toThrow(/Sólo quedan 5/i)
  })

  it('setCantidad acota al stock y quita el ítem con cantidad cero', () => {
    const cart = useCartStore()
    cart.agregar(producto({ stock: 4 }), 1)
    cart.setCantidad('30000000-0000-0000-0000-000000000101', 9)
    expect(cart.cantidadDe('30000000-0000-0000-0000-000000000101')).toBe(4)
    cart.setCantidad('30000000-0000-0000-0000-000000000101', 0)
    expect(cart.vacio).toBe(true)
  })

  it('no aumenta cantidades cuando la sincronización informa stock cero', () => {
    const cart = useCartStore()
    const item = cart.agregar(producto(), 1)
    item.stock = 0
    cart.setCantidad(item.productoId, 3)
    expect(cart.cantidadDe(item.productoId)).toBe(1)
    cart.setCantidad(item.productoId, 0)
    expect(cart.vacio).toBe(true)
  })

  it('conserva el stock vigente al volver a agregar el mismo producto', () => {
    const cart = useCartStore()
    const item = cart.agregar(producto({ stock: 10 }), 1)
    cart.agregar(producto({ stock: 3 }), 1)
    cart.setCantidad(item.productoId, 8)
    expect(cart.cantidadDe(item.productoId)).toBe(3)
  })

  it('quitar elimina sólo el producto indicado', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 1)
    cart.agregar(producto({ id: 'otro', nombre: 'Papas' }), 1)
    cart.quitar('otro')
    expect(cart.cantidadProductos).toBe(1)
    expect(cart.items[0].nombre).toBe('Tomates Roma de Paine')
  })
})

describe('carrito · monocarrito (un pedido = un productor)', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('agrupa los ítems por vendedor', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 2)
    expect(cart.porVendedor).toHaveLength(1)
    expect(cart.vendedorPrincipal.productorNombre).toBe('Huerta Paine')
    expect(cart.requiereVariosVendedores).toBe(false)
  })

  it('marca el carrito cuando hay productos de más de una tienda', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 1)
    cart.agregar(producto({ id: 'ajeno', nombre: 'Naranjas', ...OTRO_PRODUCTOR }), 1)

    expect(cart.porVendedor).toHaveLength(2)
    expect(cart.requiereVariosVendedores).toBe(true)
  })

  it('permite dejar una sola tienda quitando los productos de la otra', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 1)
    cart.agregar(producto({ id: 'ajeno', nombre: 'Naranjas', ...OTRO_PRODUCTOR }), 1)

    for (const item of cart.items.filter((i) => i.productorId !== cart.vendedorPrincipal.productorId)) {
      cart.quitar(item.productoId)
    }

    expect(cart.requiereVariosVendedores).toBe(false)
    expect(cart.vendedorPrincipal.productorNombre).toBe('Huerta Paine')
  })
})

describe('carrito · resumen de compra (RF-014)', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('suma subtotal y despacho, recarga IVA y no recarga el fee al comprador', () => {
    const cart = useCartStore()
    cart.agregar(producto({ precio: 2800, stock: 10 }), 2)

    expect(cart.subtotal).toBe(5600)
    expect(cart.envio).toBe(REGLAS.TARIFAS.deliveryDefecto)
    expect(cart.envio).toBe(3500)
    expect(cart.comision).toBe(280)
    expect(cart.baseImponible).toBe(9100)
    expect(cart.iva).toBe(1729)
    expect(cart.total).toBe(10829)
    // El comprador paga subtotal + despacho + IVA: el fee de 5 % lo retiene
    // CuTuCo del payout del vendedor (ver `calcularLiquidacion`).
    expect(cart.total).toBe(cart.subtotal + cart.envio + cart.iva)
  })

  it('expone los ítems en el formato de FastAPI', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 3)
    expect(cart.toItems()).toEqual([
      { productoId: '30000000-0000-0000-0000-000000000101', cantidad: 3 },
    ])
  })

  it('CK-0071/0104: cobra un despacho por productor y ninguno al vaciar', () => {
    const cart = useCartStore()
    expect(cart.total).toBe(0)
    cart.agregar(producto({ precio: 5000 }), 2)
    cart.agregar(producto({ id: 'otra', precio: 2000, ...OTRO_PRODUCTOR }), 1)
    expect(cart.envio).toBe(7000)
    expect(cart.subtotal).toBe(12000)
    expect(cart.comision).toBe(600)
    expect(cart.baseImponible).toBe(19000)
    expect(cart.iva).toBe(3610)
    expect(cart.total).toBe(22610)
    cart.limpiar()
    expect(cart.total).toBe(0)
  })

  it('persiste el carrito en localStorage', async () => {
    const cart = useCartStore()
    cart.agregar(producto(), 2)
    await new Promise((resolve) => setTimeout(resolve, 0))

    const guardado = JSON.parse(localStorage.getItem('cutuco:carrito'))
    expect(guardado).toHaveLength(1)
    expect(guardado[0].cantidad).toBe(2)
  })

  it('limpiar deja el carrito y el destino vacíos', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 1)
    cart.destino = { direccionId: 'd1', comunaId: 'c1', regionId: 'r1' }
    cart.limpiar()

    expect(cart.vacio).toBe(true)
    expect(cart.destino).toEqual({ direccionId: null, comunaId: null, regionId: null })
  })
})
