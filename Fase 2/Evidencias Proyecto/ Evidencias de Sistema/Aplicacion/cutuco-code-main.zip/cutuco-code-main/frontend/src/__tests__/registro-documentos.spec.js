/**
 * CuTuCo — Validaciones de la iteración de auditoría.
 *
 * Cubre las guardas añadidas al flujo de postulaciones:
 *  - validarDocumentoPostulante (C3): tamaño, extensión, archivos vacíos y
 *    extensiones dobles ANTES de subir al bucket privado;
 *  - validarDatosRegistro (A5/A7): límites del esquema antes de crear registros;
 *  - reiniciarIntentosPostulacion (F): motivo obligatorio (>= 10 caracteres) y
 *    llamada a la RPC 'reiniciar_intentos_postulacion'.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'

const { getClientMock } = vi.hoisted(() => ({ getClientMock: vi.fn() }))

vi.mock('@/lib/supabase', () => ({
  getClient: getClientMock,
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
}))
vi.mock('@/services/geography', () => ({
  createDireccion: vi.fn(),
  listDirecciones: vi.fn(async () => []),
  updateDireccion: vi.fn(),
}))
vi.mock('@/services/seller', () => ({ guardarDatosBancarios: vi.fn() }))

import {
  MAX_BYTES_DOCUMENTO,
  validarDocumentoPostulante,
  validarDatosRegistro,
} from '@/services/registro'
import { reiniciarIntentosPostulacion } from '@/services/admin'

const archivo = (nombre, tamano) => ({ name: nombre, size: tamano, type: 'application/pdf' })

describe('C3 · validarDocumentoPostulante', () => {
  it('acepta un PDF dentro del límite de 10 MB', () => {
    expect(validarDocumentoPostulante(archivo('carnet.pdf', 1024))).toBeNull()
  })

  it('rechaza archivos vacíos, gigantes y con formato no permitido', () => {
    expect(validarDocumentoPostulante(archivo('vacio.pdf', 0))).toMatch(/vacío/i)
    expect(validarDocumentoPostulante(archivo('grande.pdf', MAX_BYTES_DOCUMENTO + 1))).toMatch(/10 MB/i)
    expect(validarDocumentoPostulante(archivo('script.exe', 100))).toMatch(/Formato no permitido/i)
    expect(validarDocumentoPostulante(archivo('sinextension', 100))).toMatch(/no tiene extensión/i)
  })

  it('rechaza extensiones dobles que rompen la ruta exigida por la base', () => {
    expect(validarDocumentoPostulante(archivo('documento.pdf.png', 100))).toMatch(/extensión doble/i)
    expect(validarDocumentoPostulante(archivo('documento.png', 100))).toBeNull()
  })
})

describe('A5/A7 · validarDatosRegistro', () => {
  it('acepta datos dentro de los límites del esquema', () => {
    const errores = validarDatosRegistro({
      nombre: 'Ignacio',
      apellido: 'Fuenzalida',
      calle: 'Calle Larga 123',
      nombreComercial: 'Huerta Los Maitenes',
      descripcion: 'Verduras de estación',
    })
    expect(Object.keys(errores)).toHaveLength(0)
  })

  it('marca el campo exacto que excede el límite de la columna', () => {
    const errores = validarDatosRegistro({ nombre: 'x'.repeat(101) })
    expect(errores.nombre).toMatch(/100 caracteres/)
    const direccion = validarDatosRegistro({ calle: 'x'.repeat(256) })
    expect(direccion.calle).toMatch(/255 caracteres/)
    const tienda = validarDatosRegistro({ nombreComercial: 'x'.repeat(161) })
    expect(tienda.nombreComercial).toMatch(/160 caracteres/)
  })
})

describe('F · reiniciarIntentosPostulacion', () => {
  beforeEach(() => {
    getClientMock.mockReset()
  })

  it('exige un motivo de al menos 10 caracteres', async () => {
    await expect(reiniciarIntentosPostulacion('post-1', 'corto')).rejects.toThrow(/10 caracteres/)
    expect(getClientMock).not.toHaveBeenCalled()
  })

  it('llama a la RPC con el motivo recortado', async () => {
    const rpc = vi.fn(async () => ({ data: { intentos_extra: 3 }, error: null }))
    getClientMock.mockReturnValue({ rpc })
    const resultado = await reiniciarIntentosPostulacion('post-1', '  Error transitorio del sistema; se autoriza reenvío.  ')
    expect(rpc).toHaveBeenCalledWith('reiniciar_intentos_postulacion', {
      p_postulacion_id: 'post-1',
      p_motivo: 'Error transitorio del sistema; se autoriza reenvío.',
    })
    expect(resultado.intentos_extra).toBe(3)
  })
})
