<script setup>
/** CuTuCo — Estado vacío ilustrado. */
import CtIcon from './CtIcon.vue'

defineProps({
  icon: { type: String, default: 'search' },
  title: { type: String, default: 'Nada por aquí' },
  message: { type: String, default: null },
  compact: { type: Boolean, default: false },
})
</script>

<template>
  <div class="ct-empty" :class="{ 'is-compact': compact }">
    <div class="ct-empty__icon" aria-hidden="true">
      <CtIcon :name="icon" :size="compact ? 20 : 26" />
    </div>
    <p class="ct-empty__title">{{ title }}</p>
    <p v-if="message" class="ct-empty__message">{{ message }}</p>
    <div v-if="$slots.default" class="ct-empty__action"><slot /></div>
  </div>
</template>

<style scoped>
.ct-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--ct-space-2);
  text-align: center;
  padding: var(--ct-space-8) var(--ct-space-4);
}

.ct-empty.is-compact {
  padding: var(--ct-space-4);
}

.ct-empty__icon {
  width: 56px;
  height: 56px;
  display: grid;
  place-items: center;
  border-radius: var(--ct-radius-lg);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.ct-empty.is-compact .ct-empty__icon {
  width: 42px;
  height: 42px;
}

.ct-empty__title {
  font-weight: var(--ct-fw-semibold);
  font-size: var(--ct-fs-lg);
}

.ct-empty__message {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-md);
  max-width: 46ch;
}

.ct-empty__action {
  margin-top: var(--ct-space-2);
}
</style>
