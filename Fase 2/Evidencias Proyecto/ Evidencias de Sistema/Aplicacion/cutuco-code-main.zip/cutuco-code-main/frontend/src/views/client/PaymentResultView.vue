<script setup>
/**
 * CuTuCo — Resultado del pago (`/pago/retorno`, RF-005, Webpay Mall Plus).
 *
 * `TRANSBANK_RETURN_URL` apunta al endpoint público de FastAPI. Tras confirmar
 * el pago, FastAPI redirige por GET a `/cliente/pedidos`; el router desvía esa
 * ruta a esta vista cuando llega con los parámetros de Transbank.
 *
 * Transbank entrega cuatro escenarios: `token_ws` (pago normal: se ejecuta el
 * commit en FastAPI), `TBK_ID_SESION` + `TBK_ORDEN_COMPRA` (sesión expirada),
 * `TBK_TOKEN` (pago anulado por el usuario) y `token_ws` + `TBK_TOKEN` a la vez
 * (transacción inválida, que NO debe confirmarse). Con el commit autorizado el
 * pago queda AUTORIZADO por Webpay Mall y se registra el pedido con su envío.
 * La autorización no acredita la liquidación ni el abono bancario al productor.
 *
 * La respuesta de `POST /api/webpay/confirmar` trae la LISTA de pedidos creados
 * en el commit (`checkout_id` + `pedidos[]`, uno por productor del carrito).
 * `ya_confirmado` indica una llamada idempotente (el token ya se había
 * confirmado) y `requiere_conciliacion` avisa que Transbank reportó algo que
 * no coincide con el comprobante y el administrador deberá revisarlo.
 *
 * El detalle completo del contrato está en `CONTRATO-PAGO.md`.
 */
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_ENVIO, LABELS, REGLAS } from '@/lib/constants'
import { formatCLP, formatDateTime, formatTime } from '@/lib/format'
import { estadoActualPedido } from '@/lib/orders'
import { formatearCantidad } from '@/services/catalog'
import { confirmarPago, getPedidoDetalle } from '@/services/orders'
import { useCartStore } from '@/stores/cart'
import { useUiStore } from '@/stores/ui'

const route = useRoute()
const ui = useUiStore()
const cart = useCartStore()

const pedido = ref(null)
const pedidosConfirmados = ref([])
const confirmacion = ref(null)
const cargando = ref(true)
const error = ref(null)
const procesando = ref(false)

/**
 * Parámetros con los que Transbank devuelve el control al comercio.
 *
 * Transbank documenta cuatro escenarios de retorno:
 *   1. Sólo `token_ws`                      -> pago normal: se confirma (commit).
 *   2. `TBK_ID_SESION` + `TBK_ORDEN_COMPRA` -> expiró la sesión de pago (>10 min).
 *   3. Sólo `TBK_TOKEN`                     -> el usuario anuló el pago.
 *   4. `token_ws` y `TBK_TOKEN` a la vez    -> transacción INVÁLIDA: no se confirma.
 */
const tokenWs = computed(() => route.query.token_ws ?? null)
const tokenAnulado = computed(() => route.query.TBK_TOKEN ?? null)
const ordenAnulada = computed(() => route.query.TBK_ORDEN_COMPRA ?? null)
const idSesion = computed(() => route.query.TBK_ID_SESION ?? null)

/** Escenario 4: llegan ambos tokens; la transacción no es válida. */
const pagoInvalido = computed(() => Boolean(tokenWs.value) && Boolean(tokenAnulado.value))
/** Escenario 3: el usuario cerró el formulario de Webpay. */
const pagoAnulado = computed(() => Boolean(tokenAnulado.value) && !tokenWs.value)
/** Escenario 2: la sesión de pago expiró y Transbank revirtió la transacción. */
const sesionExpirada = computed(
  () => !tokenWs.value && !tokenAnulado.value && Boolean(idSesion.value || ordenAnulada.value),
)
/** Retorno sin ningún parámetro de Webpay: no hay transacción que identificar ni confirmar. */
const sinParametros = computed(
  () => !tokenWs.value && !tokenAnulado.value && !idSesion.value && !ordenAnulada.value,
)

const pago = computed(() => pedido.value?.pago ?? null)
const pagoAutorizado = computed(() => confirmacion.value?.estado === 'autorizado')
const pagoParcial = computed(() => confirmacion.value?.estado === 'parcial')
const pagoRechazado = computed(
  () => confirmacion.value?.estado === 'rechazado' || pago.value?.estado === 'rechazado',
)
const fueConfirmado = computed(() => confirmacion.value?.ok === true)
const requiereConciliacion = computed(() => confirmacion.value?.requiere_conciliacion === true)
/**
 * HAL-CLI-016: el backend agenda el aviso al productor en segundo plano. El
 * flag `correo_productor_enviado_en` sólo se escribe cuando el proveedor confirma el
 * envío, así que el mensaje de éxito no puede afirmar que ya lo recibió.
 */
const correoProductorEnviado = computed(() => Boolean(pedido.value?.correo_productor_enviado_en))
const correoCompradorEnviado = computed(() => Boolean(pedido.value?.correo_comprador_enviado_en))

const subtotal = computed(() => Number(pedido.value?.subtotal_productos ?? 0))
const iva = computed(() => Number(pedido.value?.monto_iva ?? 0))
const tasaIva = computed(() => Number(pedido.value?.tasa_iva ?? 0))
const costoEnvio = computed(() =>
  pedido.value?.envio?.tarifa_fija != null
    ? Number(pedido.value.envio.tarifa_fija)
    : Math.max(0, Number(pedido.value?.total ?? 0) - subtotal.value - iva.value),
)
const comision = computed(() => Number(pedido.value?.monto_fee_plataforma ?? 0))
const total = computed(() => Number(pedido.value?.total ?? 0))

const resultado = computed(() => {
  if (cargando.value) return null
  if (pagoInvalido.value) {
    return {
      tono: 'danger',
      icono: 'close',
      titulo: 'El pago es inválido',
      mensaje:
        'Webpay devolvió la transacción y su token de anulación a la vez, así que no se confirmó ningún cargo. No reintentes esta operación desde aquí: vuelve al carrito y crea el pedido de nuevo.',
    }
  }
  if (error.value) {
    return {
      tono: 'danger',
      icono: 'close',
      titulo: 'No pudimos confirmar el pago',
      mensaje: error.value,
    }
  }
  if (pagoAnulado.value) {
    return {
      tono: 'warning',
      icono: 'alert',
      titulo: 'Pago anulado',
      mensaje:
        'Cerraste el formulario de Webpay antes de pagar, así que no se realizó ningún cargo. Puedes volver al carrito e intentarlo otra vez.',
    }
  }
  if (sesionExpirada.value) {
    return {
      tono: 'warning',
      icono: 'alert',
      titulo: 'Sesión de pago expirada',
      mensaje:
        'Pasaron más de 10 minutos sin completar el pago, así que Webpay revirtió la transacción y no hubo cargo. Vuelve al carrito para iniciar un pedido nuevo.',
    }
  }
  if (pagoRechazado.value) {
    return {
      tono: 'danger',
      icono: 'close',
      titulo: 'El pago fue rechazado',
      mensaje:
        'La transacción no pudo autorizarse y no se realizó ningún cargo. Puedes reintentar el pago desde el carrito.',
    }
  }
  if (pagoParcial.value) {
    return {
      tono: 'warning',
      icono: 'alert',
      titulo: 'Pago autorizado de forma parcial',
      mensaje:
        'Webpay confirmó una parte de la compra. Revisa tus pedidos y no repitas la compra completa mientras verificamos los montos.',
    }
  }
  if (pagoAutorizado.value || fueConfirmado.value) {
    return {
      tono: 'success',
      icono: 'check',
      titulo: 'Compra confirmada',
      mensaje:
        'Tu pago fue confirmado y tu pedido ya está en preparación. Puedes seguir su estado a continuación.',
    }
  }
  if (sinParametros.value) {
    return {
      tono: 'danger',
      icono: 'close',
      titulo: 'No se recibió el pago',
      mensaje:
        'Webpay no devolvió un identificador de transacción, así que no se creó ni autorizó ningún pedido. Vuelve al carrito para iniciar una compra nueva.',
    }
  }
  return {
    tono: 'warning',
    icono: 'alert',
    titulo: 'Pago pendiente',
    mensaje:
      'No recibimos la confirmación de Webpay. Si el cargo aparece en tu cartola, reintenta la confirmación; en caso contrario, vuelve a intentar el pago.',
  }
})

/**
 * Los 4 hitos base del seguimiento (los mismos del vendedor). La preparación no
 * muestra `envio.creado_en`: ese timestamp corresponde al pago que creó el
 * envío, no a una acción del vendedor (HAL-CLI-010).
 */
const pasos = computed(() => {
  const envio = pedido.value?.envio ?? null
  const preparadoEn = envio?.preparado_en ?? null
  const prepHecha = Boolean(preparadoEn || (envio && envio.estado !== ESTADO_ENVIO.PREPARACION))
  const enTransito = Boolean(
    envio?.despachado_en ||
    [ESTADO_ENVIO.EN_TRANSITO, ESTADO_ENVIO.ENTREGADO].includes(envio?.estado),
  )
  const entregado = Boolean(envio?.entregado_en || envio?.estado === ESTADO_ENVIO.ENTREGADO)
  return [
    {
      key: 'pago',
      titulo: 'Pago autorizado',
      detalle: 'Webpay confirmó la autorización del cobro.',
      momento: pago.value?.autorizado_en ?? pago.value?.creado_en ?? null,
      hecho: Boolean(pago.value),
    },
    {
      key: 'preparacion',
      titulo: 'Preparación por el productor',
      detalle: 'El vendedor registra la preparación del pedido; la fecha viene de esa acción.',
      momento: preparadoEn,
      hecho: prepHecha,
    },
    {
      key: 'transito',
      titulo: 'El pedido sale a reparto',
      detalle: 'En tránsito: el código de verificación queda disponible.',
      momento: envio?.despachado_en ?? null,
      hecho: enTransito,
    },
    {
      key: 'entrega',
      titulo: 'Entrega con código',
      detalle: 'El vendedor valida el código que le entregas y cierra la entrega.',
      momento: envio?.entregado_en ?? null,
      hecho: entregado,
    },
  ]
})

/** Ejecuta el commit de Webpay con el token devuelto. */
async function confirmarTransaccion(token = tokenWs.value) {
  if (!token) return
  procesando.value = true
  error.value = null
  try {
    const respuesta = await confirmarPago(token)
    confirmacion.value = respuesta

    const lista = Array.isArray(respuesta?.pedidos) ? respuesta.pedidos : []

    // La respuesta del commit es deliberadamente breve. Se hidrata cada pedido
    // para mostrar los identificadores comerciales de los productos que se
    // compraron, incluso cuando el carrito tenía más de una tienda.
    const detalles = await Promise.all(
      lista.map((p) => getPedidoDetalle(p.pedido_id).catch(() => null)),
    )
    pedidosConfirmados.value = lista.map((p, indice) => ({
      ...p,
      codigo_pedido: detalles[indice]?.codigo_pedido ?? p.codigo_pedido ?? null,
      productos: detalles[indice]?.detalles ?? p.productos ?? [],
    }))

    // Compatibilidad: el backend antiguo respondía un único `pedido_id`.
    const primerId = lista[0]?.pedido_id ?? respuesta?.pedido_id ?? null
    if (primerId) {
      pedido.value =
        detalles[0] ??
        (lista.length === 0 ? await getPedidoDetalle(primerId).catch(() => null) : null)
    }

    if (respuesta?.ok) {
      // El pago quedó autorizado: el carrito ya cumplió su función (RF-002).
      cart.limpiar()
      ui.success('Compra confirmada', 'Tu pago fue confirmado y tu pedido quedó registrado.')
    } else if (respuesta?.estado === 'parcial' || respuesta?.requiere_conciliacion) {
      ui.warning(
        'Estamos revisando el pago',
        'No repitas la compra completa; revisa los pedidos registrados.',
      )
    } else {
      ui.error('Pago rechazado', 'La transacción no pudo autorizarse. Puedes reintentar.')
    }
  } catch (e) {
    error.value = e?.message ?? 'No se pudo confirmar el pago'
    ui.error('No se pudo confirmar el pago', error.value)
  } finally {
    procesando.value = false
    cargando.value = false
  }
}

onMounted(async () => {
  // Escenario 4: con ambos tokens la transacción es inválida y no se confirma.
  if (tokenWs.value && !pagoInvalido.value) {
    await confirmarTransaccion(tokenWs.value)
  } else {
    cargando.value = false
  }
})
</script>

<template>
  <div class="container page">
    <CtSpinner v-if="cargando" label="Cargando el resultado del pago" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar el pedido">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton
        v-if="tokenWs && !pagoInvalido"
        size="sm"
        :loading="procesando"
        @click="confirmarTransaccion()"
      >
        Reintentar la confirmación
      </CtButton>
      <CtButton size="sm" variant="secondary" to="/cliente/pedidos">Ver mis pedidos</CtButton>
    </CtAlert>

    <!--
      Retornos sin pedido asociado: el usuario anuló el pago, la sesión de pago
      expiró o la transacción es inválida. Sin esta rama esas pantallas quedaban
      completamente en blanco.
    -->
    <template v-else-if="resultado && !pedido">
      <header class="page-head">
        <div class="page-head__text">
          <h1 class="page-head__title">{{ resultado.titulo }}</h1>
          <p class="page-head__subtitle">
            Webpay Mall Plus<template v-if="ordenAnulada"> · Orden {{ ordenAnulada }}</template>
          </p>
        </div>
        <div class="page-head__actions">
          <CtButton variant="ghost" to="/cliente/pedidos">Ver mis pedidos</CtButton>
        </div>
      </header>

      <section class="resultado" :class="`is-${resultado.tono}`">
        <span class="resultado__icono"><CtIcon :name="resultado.icono" :size="26" /></span>
        <div class="resultado__cuerpo">
          <h2 class="resultado__titulo">{{ resultado.titulo }}</h2>
          <p class="resultado__mensaje">{{ resultado.mensaje }}</p>
          <div v-if="ordenAnulada" class="resultado__chips">
            <CtBadge tone="neutral" size="sm">Orden: {{ ordenAnulada }}</CtBadge>
          </div>
        </div>
      </section>

      <CtCard v-if="pedidosConfirmados.length" title="Pedidos creados en esta compra" padding="md">
        <ul class="pedidos">
          <li v-for="p in pedidosConfirmados" :key="p.pedido_id" class="pedidos__fila">
            <div class="stack stack--xs">
              <span class="font-semibold">{{ p.codigo_pedido ?? 'Pedido CuTuCo' }}</span>
              <span class="text-xs text-muted">
                Estado: {{ LABELS.pedido[p.estado_pedido] ?? p.estado_pedido }} ·
                {{ formatCLP(p.total) }}
              </span>
              <ul v-if="p.productos?.length" class="pedidos__productos">
                <li v-for="detalle in p.productos" :key="detalle.id ?? detalle.producto_id">
                  ID producto:
                  <span class="mono">{{ detalle.codigo_producto ?? detalle.producto_id }}</span>
                  <span class="text-muted"> · {{ detalle.producto_nombre }}</span>
                </li>
              </ul>
            </div>
            <CtButton size="sm" variant="secondary" :to="`/cliente/pedidos/${p.pedido_id}`">
              <template #icon><CtIcon name="truck" :size="15" /></template>
              Ver seguimiento
            </CtButton>
          </li>
        </ul>
      </CtCard>

      <div class="acciones">
        <CtButton size="lg" variant="secondary" to="/carrito">
          <template #icon><CtIcon name="cart" :size="16" /></template>
          Volver al carrito
        </CtButton>
        <CtButton variant="secondary" to="/catalogo">
          <template #icon><CtIcon name="catalog" :size="16" /></template>
          Seguir comprando
        </CtButton>
      </div>
    </template>

    <template v-else-if="pedido && resultado">
      <header class="page-head">
        <div class="page-head__text">
          <h1 class="page-head__title">{{ resultado.titulo }}</h1>
          <p class="page-head__subtitle">
            Pedido <span class="mono">{{ pedido.codigo_pedido }}</span> ·
            {{ formatDateTime(pedido.creado_en) }}
          </p>
        </div>
        <div class="page-head__actions">
          <!-- HAL-VEN-030: un único estado actual derivado (como el resto de la app);
               antes se mostraba el estado crudo del pedido junto al del envío. -->
          <StatusBadge type="actual" :value="estadoActualPedido(pedido)" />
          <CtButton variant="secondary" :to="`/cliente/pedidos/${pedido.id}`">
            <template #icon><CtIcon name="orders" :size="16" /></template>
            Ver detalle del pedido
          </CtButton>
          <CtButton variant="ghost" to="/cliente/pedidos">Ver mis pedidos</CtButton>
        </div>
      </header>

      <section class="resultado" :class="`is-${resultado.tono}`">
        <span class="resultado__icono"><CtIcon :name="resultado.icono" :size="26" /></span>
        <div class="resultado__cuerpo">
          <h2 class="resultado__titulo">{{ resultado.titulo }}</h2>
          <p class="resultado__mensaje">{{ resultado.mensaje }}</p>
          <div class="resultado__chips">
            <CtBadge v-if="pago" type="pago" :value="pago.estado" size="sm">
              {{ LABELS.pago[pago.estado] ?? pago.estado }}
            </CtBadge>
            <CtBadge v-if="confirmacion?.estado" tone="neutral" size="sm">
              Estado Webpay: {{ confirmacion.estado }}
            </CtBadge>
            <CtBadge v-if="pedido.envio" type="envio" :value="pedido.envio.estado" size="sm">
              {{ LABELS.envio[pedido.envio.estado] ?? pedido.envio.estado }}
            </CtBadge>
            <CtBadge v-if="pago?.buy_order" tone="neutral" size="sm">
              Orden: {{ pago.buy_order }}
            </CtBadge>
          </div>
        </div>
      </section>

      <CtAlert v-if="requiereConciliacion" tone="warning" title="Estamos revisando el pago">
        <p class="linea">
          <CtIcon name="alert" :size="16" />
          <span>
            Estamos verificando los montos del pago. Revisa los pedidos registrados en tu historial
            y no repitas la compra completa mientras terminamos esta revisión.
          </span>
        </p>
      </CtAlert>

      <CtAlert
        v-if="
          (pagoAutorizado || fueConfirmado) && (!correoProductorEnviado || !correoCompradorEnviado)
        "
        tone="info"
        title="Correos de la compra"
      >
        <p class="linea">
          <CtIcon name="mail" :size="16" />
          <span>
            Aviso al vendedor:
            <strong>{{ correoProductorEnviado ? 'confirmado' : 'en proceso' }}</strong>. Detalle de
            compra para ti:
            <strong>{{ correoCompradorEnviado ? 'confirmado' : 'en proceso' }}</strong>. Si el envío
            falla, puedes revisar todos los datos en el detalle del pedido; no se afirmará que el
            vendedor recibió el aviso hasta que el envío quede confirmado.
          </span>
        </p>
      </CtAlert>

      <div class="acciones">
        <CtButton
          v-if="tokenWs && !fueConfirmado && !pagoInvalido && !pagoParcial && !requiereConciliacion"
          size="lg"
          :loading="procesando"
          @click="confirmarTransaccion()"
        >
          <template #icon><CtIcon name="lock" :size="16" /></template>
          Reintentar la confirmación
        </CtButton>
        <CtButton
          v-if="pagoRechazado || pagoAnulado || sesionExpirada || pagoInvalido"
          size="lg"
          variant="secondary"
          to="/carrito"
        >
          <template #icon><CtIcon name="cart" :size="16" /></template>
          Volver al carrito
        </CtButton>
        <CtButton variant="secondary" to="/catalogo">
          <template #icon><CtIcon name="catalog" :size="16" /></template>
          Seguir comprando
        </CtButton>
      </div>

      <!-- Pedidos generados por el commit (Webpay Mall: uno por productor). -->
      <CtCard v-if="pedidosConfirmados.length" title="Pedidos creados en esta compra" padding="md">
        <ul class="pedidos">
          <li v-for="p in pedidosConfirmados" :key="p.pedido_id" class="pedidos__fila">
            <div class="stack stack--xs">
              <span class="font-semibold">{{ p.codigo_pedido ?? 'Pedido CuTuCo' }}</span>
              <span class="text-xs text-muted">
                Estado: {{ LABELS.pedido[p.estado_pedido] ?? p.estado_pedido }} ·
                {{ formatCLP(p.total) }}
              </span>
              <ul v-if="p.productos?.length" class="pedidos__productos">
                <li v-for="detalle in p.productos" :key="detalle.id ?? detalle.producto_id">
                  ID producto:
                  <span class="mono">{{ detalle.codigo_producto ?? detalle.producto_id }}</span>
                  <span class="text-muted"> · {{ detalle.producto_nombre }}</span>
                </li>
              </ul>
            </div>
            <CtButton size="sm" variant="secondary" :to="`/cliente/pedidos/${p.pedido_id}`">
              <template #icon><CtIcon name="truck" :size="15" /></template>
              Ver seguimiento
            </CtButton>
          </li>
        </ul>
      </CtCard>

      <div class="pago">
        <div class="pago__principal stack">
          <CtCard title="¿Qué sigue?" padding="md">
            <ol class="pasos">
              <li
                v-for="paso in pasos"
                :key="paso.key"
                class="paso"
                :class="{ 'is-hecho': paso.hecho }"
              >
                <span class="paso__marca" aria-hidden="true">
                  <CtIcon v-if="paso.hecho" name="check" :size="12" />
                  <span v-else class="paso__punto" />
                </span>
                <div class="paso__cuerpo">
                  <p class="paso__titulo">{{ paso.titulo }}</p>
                  <p class="paso__detalle">{{ paso.detalle }}</p>
                  <p v-if="paso.momento" class="paso__fecha">
                    {{ formatDateTime(paso.momento) }} · {{ formatTime(paso.momento) }}
                  </p>
                  <p v-else-if="paso.hecho" class="paso__fecha is-pendiente">Fecha no registrada</p>
                </div>
              </li>
            </ol>
          </CtCard>

          <CtCard
            title="Detalle del pedido"
            :subtitle="`Tienda: ${pedido.productor?.nombre_comercial ?? 'Productor CuTuCo'}`"
            padding="md"
          >
            <ul class="lineas">
              <li v-for="detalle in pedido.detalles" :key="detalle.id" class="linea-item">
                <div class="stack stack--xs">
                  <span class="font-semibold">{{ detalle.producto_nombre }}</span>
                  <span class="text-xs text-muted">
                    {{ formatCLP(detalle.precio_unitario) }} ×
                    {{ formatearCantidad(detalle.cantidad, detalle.unidad) }}
                    {{ LABELS.unidad[detalle.unidad] ?? detalle.unidad ?? '' }}
                  </span>
                </div>
                <span class="font-semibold">{{ formatCLP(detalle.subtotal) }}</span>
              </li>
            </ul>

            <div class="totales">
              <div class="totales__fila">
                <span>Productos (neto)</span>
                <span class="totales__valor">{{ formatCLP(subtotal) }}</span>
              </div>
              <div class="totales__fila">
                <span>Despacho (neto)</span>
                <span class="totales__valor">{{ formatCLP(costoEnvio) }}</span>
              </div>
              <div v-if="iva || tasaIva" class="totales__fila">
                <span>IVA ({{ tasaIva * 100 }}%)</span>
                <span class="totales__valor">{{ formatCLP(iva) }}</span>
              </div>
              <div class="totales__fila is-suave">
                <span>
                  Comisión de CuTuCo ({{ REGLAS.TARIFAS.feePlataforma * 100 }}%, se descuenta al
                  productor y no se suma al total)
                </span>
                <span class="totales__valor">{{ formatCLP(comision) }}</span>
              </div>
              <div class="totales__separador" />
              <div class="totales__fila is-total">
                <span>Total pagado (IVA incluido)</span>
                <span class="totales__total">{{ formatCLP(total) }}</span>
              </div>
            </div>

            <CtMoneyInfo title="Cómo se calcula el total pagado">
              <p>
                El total corresponde a productos y despacho netos más el IVA registrado al confirmar
                el pago. La comisión de CuTuCo se descuenta al productor mediante Webpay Mall; no se
                agrega como un cobro adicional al cliente.
              </p>
            </CtMoneyInfo>
          </CtCard>
        </div>

        <aside class="pago__aside stack">
          <CtCard title="Pago" padding="md">
            <div v-if="pago" class="stack stack--sm">
              <div class="totales__fila">
                <span>Estado</span>
                <StatusBadge type="pago" :value="pago.estado" size="sm" />
              </div>
              <div class="totales__fila">
                <span>Monto pagado</span>
                <span class="totales__valor">
                  {{ formatCLP(Number(pago.monto) + Number(pago.monto_fee_descontado ?? 0)) }}
                </span>
              </div>
              <div class="totales__fila">
                <span>Método</span>
                <span class="totales__valor">Webpay Mall</span>
              </div>
              <div v-if="pago.codigo_autorizacion" class="totales__fila">
                <span>Autorización</span>
                <span class="mono text-xs">{{ pago.codigo_autorizacion }}</span>
              </div>
              <div v-if="pago.creado_en" class="totales__fila">
                <span>Procesado</span>
                <span class="text-xs">{{ formatDateTime(pago.creado_en) }}</span>
              </div>
              <CtAlert tone="neutral" compact>
                <p class="linea">
                  <CtIcon name="info" :size="14" />
                  <span>
                    Pago autorizado por Webpay. Esta confirmación no acredita el abono bancario al
                    productor.
                  </span>
                </p>
              </CtAlert>
            </div>

            <CtEmptyState
              v-else
              icon=""
              compact
              title="Todavía no hay pago"
              message="Autoriza la transacción para activar el pedido."
            />
          </CtCard>

          <CtCard title="Envío" padding="md">
            <div v-if="pedido.envio" class="stack stack--sm">
              <div class="totales__fila">
                <span>Estado</span>
                <StatusBadge type="envio" :value="pedido.envio.estado" size="sm" />
              </div>
              <div class="totales__fila">
                <span>Tarifa</span>
                <span class="totales__valor">{{ formatCLP(pedido.envio.tarifa_fija) }}</span>
              </div>
              <div v-if="pedido.envio.repartidor" class="totales__fila">
                <span>Repartidor</span>
                <span class="text-sm">
                  {{ pedido.envio.repartidor.nombre }} {{ pedido.envio.repartidor.apellido ?? '' }}
                </span>
              </div>
              <div v-if="pedido.envio.creado_en" class="totales__fila">
                <span>Creado</span>
                <span class="text-xs">{{ formatDateTime(pedido.envio.creado_en) }}</span>
              </div>
              <CtBadge
                v-if="pedido.envio.estado === ESTADO_ENVIO.PREPARACION"
                tone="warning"
                size="sm"
              >
                En preparación con el productor
              </CtBadge>
            </div>

            <CtEmptyState
              v-else
              icon=""
              compact
              title="Envío aún no creado"
              message="El envío se crea automáticamente cuando el pago queda confirmado."
            />
          </CtCard>

          <CtCard title="Datos de entrega" padding="md">
            <dl class="datos">
              <div class="dato">
                <dt class="dato__label">Destinatario</dt>
                <dd class="dato__valor">{{ pedido.nombre_destinatario }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Dirección</dt>
                <dd class="dato__valor">{{ pedido.direccion_entrega }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Comuna</dt>
                <dd class="dato__valor">{{ pedido.comuna?.nombre ?? '—' }}</dd>
              </div>
              <div v-if="pedido.referencia_entrega" class="dato">
                <dt class="dato__label">Referencia</dt>
                <dd class="dato__valor">{{ pedido.referencia_entrega }}</dd>
              </div>
            </dl>
          </CtCard>
        </aside>
      </div>
    </template>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.resultado {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-4);
  padding: var(--ct-space-6);
  border-radius: var(--ct-radius-lg);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  box-shadow: var(--ct-shadow-xs);
}

.resultado__icono {
  width: 52px;
  height: 52px;
  flex-shrink: 0;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.resultado.is-danger .resultado__icono {
  background: var(--ct-danger-soft);
  color: var(--ct-danger);
}

.resultado.is-warning .resultado__icono {
  background: var(--ct-warning-soft);
  color: var(--ct-warning-strong);
}

.resultado__cuerpo {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  min-width: 0;
}

.resultado__titulo {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
}

.resultado__mensaje {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
  max-width: 70ch;
}

.resultado__chips {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  margin-top: var(--ct-space-2);
}

.acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.pedidos {
  list-style: none;
  margin: 0;
  padding: 0;
}

.pedidos__fila {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
}

.pedidos__fila:last-child {
  border-bottom: none;
}

.pedidos__productos {
  list-style: none;
  margin: var(--ct-space-1) 0 0;
  padding: 0;
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-2xs);
}

.pago {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

@media (max-width: 1100px) {
  .pago {
    grid-template-columns: minmax(0, 1fr);
  }
}

.pasos {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.paso {
  position: relative;
  display: flex;
  gap: var(--ct-space-4);
  padding-bottom: var(--ct-space-5);
}

.paso:last-child {
  padding-bottom: 0;
}

.paso:not(:last-child)::before {
  content: '';
  position: absolute;
  top: 24px;
  left: 11px;
  width: 2px;
  height: calc(100% - 8px);
  background: var(--ct-border);
}

.paso.is-hecho:not(:last-child)::before {
  background: var(--ct-primary);
}

.paso__marca {
  position: relative;
  z-index: 1;
  width: 24px;
  height: 24px;
  flex-shrink: 0;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-surface);
  border: 2px solid var(--ct-border-strong);
  color: var(--ct-text-muted);
}

.paso.is-hecho .paso__marca {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.paso__punto {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentcolor;
}

.paso__cuerpo {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.paso__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.paso:not(.is-hecho) .paso__titulo {
  color: var(--ct-text-soft);
}

.paso__detalle {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.paso__fecha {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-primary-strong);
}

.paso__fecha.is-pendiente {
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-regular);
}

.lineas {
  list-style: none;
  margin: 0;
  padding: 0;
}

.linea-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
}

.linea-item:last-child {
  border-bottom: none;
}

.totales {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-4);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
}

.totales__fila {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.totales__fila.is-suave {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.totales__valor {
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.totales__separador {
  height: 1px;
  background: var(--ct-border);
  margin: var(--ct-space-2) 0;
}

.totales__fila.is-total {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.totales__total {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  color: var(--ct-primary-strong);
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}
</style>
