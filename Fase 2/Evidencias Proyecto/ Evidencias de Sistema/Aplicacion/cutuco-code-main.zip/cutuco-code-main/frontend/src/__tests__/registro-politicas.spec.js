/**
 * CuTuCo — Políticas del bloque REGISTRO (REG-* y HAL-REG-*).
 *
 * Pruebas unitarias de las reglas que comparten las vistas de registro, el
 * servicio y `lib/validation.js`, sin montar las vistas completas:
 *   - correo ASCII, sin espacios externos y máximo 254 (REG-EMAIL-002..005);
 *   - contraseña fuerte de 8 a 72 caracteres y su traducción desde GoTrue
 *     (REG-PWD-002..013 / HAL-REG-011);
 *   - teléfono OBLIGATORIO normalizado a +56 (REG-TEL-001..007 / HAL-REG-001);
 *   - número de domicilio opcional y complemento `depto_oficina`
 *     (REG-CLI-010..012 / HAL-REG-004/006);
 *   - cuenta bancaria de 7 a 12 dígitos conservada como texto y titular
 *     completo con RUT coincidente (REG-PAG-007..017 / HAL-REG-008/012/014);
 *   - documentos de hasta 10 MiB exactos (REG-DOC-005..014 / HAL-REG-010).
 *
 * Supabase, geografía y el endpoint de datos bancarios se mockean: estas
 * pruebas verifican QUÉ se envía, no la red.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'

const { getClientMock } = vi.hoisted(() => ({ getClientMock: vi.fn() }))

vi.mock('@/lib/supabase', () => ({
  getClient: getClientMock,
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
}))
vi.mock('@/services/geography', () => ({
  createDireccion: vi.fn(async () => ({ id: 'dir-1' })),
  listDirecciones: vi.fn(async () => []),
  updateDireccion: vi.fn(async () => ({ id: 'dir-1' })),
}))
vi.mock('@/services/seller', () => ({ guardarDatosBancarios: vi.fn(async () => ({})) }))

import {
  MAX_BYTES_DOCUMENTO,
  formatearRut,
  mensajeCalle,
  mensajeDeptoOficina,
  mensajeEmail,
  mensajeNombre,
  mensajeNombreComercial,
  mensajeNumeroCuenta,
  mensajeNumeroDireccion,
  mensajePassword,
  mensajeRut,
  mensajeTelefono,
  registrarCliente,
  registrarVendedor,
  guardarDocumentosBorrador,
  sugerirTitularCuenta,
  verificarRutDisponible,
  validarCuentaDeTerceros,
  validarContenidoDocumento,
  validarDocumentoPostulante,
  validarRegistroVendedor,
} from '@/services/registro'
import { createDireccion } from '@/services/geography'
import { guardarDatosBancarios } from '@/services/seller'
import {
  PASSWORD_MAX_LENGTH,
  PASSWORD_MIN_LENGTH,
  PASSWORD_REQUIREMENTS,
  passwordPolicyMessage,
  passwordStrength,
} from '@/lib/validation'
import { readFileSync } from 'node:fs'

const DOC = (nombre = 'carnet.pdf', size = 1024, type = 'application/pdf') => ({
  name: nombre,
  size,
  type,
})

const datosVendedorValidos = () => ({
  nombre: 'Prueba',
  apellido: 'Vendedor',
  email: 'vendedor@cutuco.cl',
  password: 'Clave1234!',
  telefono: '9 1234 5678',
  nombreComercial: 'Huerta Los Maitenes',
  descripcion: 'Verduras de estación',
  regionId: 'r-rm',
  comunaId: 'c-paine',
  calle: 'Camino a Paine km 4',
  numero: '',
  deptoOficina: 'Parcela 4',
  referencia: '',
  tipoPersona: 'natural',
  rutSolicitante: '12.345.678-5',
  datosBancarios: {
    banco: 'BancoEstado',
    tipoCuenta: 'cuenta_rut',
    numeroCuenta: '0001234567',
    titular: 'Prueba Vendedor',
    rutTitular: '12.345.678-5',
  },
  documentos: {
    documentoIdentidad: DOC(),
    certificadoActividadesOCarnet: DOC('actividades.pdf'),
    certificadoTitularidad: DOC('titularidad.pdf'),
    comprobanteDomicilio: DOC('domicilio.pdf'),
  },
})

/** Cliente Supabase mínimo: signUp + cadenas PostgREST que no hacen red. */
function clienteSupabase(resultadoSignUp = { data: { user: { id: 'u-1' }, session: { access_token: 't' } }, error: null }) {
  const cadena = () => {
    const nodo = {
      insert: vi.fn(() => nodo),
      update: vi.fn(() => nodo),
      select: vi.fn(() => nodo),
      eq: vi.fn(() => nodo),
      order: vi.fn(() => nodo),
      limit: vi.fn(() => nodo),
      single: vi.fn(async () => ({ data: {}, error: null })),
      maybeSingle: vi.fn(async () => ({ data: null, error: null })),
    }
    return nodo
  }
  return {
    auth: { signUp: vi.fn(async () => resultadoSignUp) },
    rpc: vi.fn(async () => ({ data: true, error: null })),
    from: vi.fn(() => cadena()),
    storage: { from: vi.fn(() => ({ upload: vi.fn(async () => ({ error: null })) })) },
  }
}

beforeEach(() => {
  vi.clearAllMocks()
  getClientMock.mockReturnValue(clienteSupabase())
})

/* ------------------------------------------------------------------ */
/* Correo                                                              */
/* ------------------------------------------------------------------ */
describe('REG-EMAIL · política de correo', () => {
  const local = 'a'.repeat(64)
  const correoDe = (largo) => {
    const dominio = largo - local.length - 1
    // Dominio con etiquetas de 63 y el resto repartido, siempre válido.
    const etiquetas = ['b'.repeat(63), 'b'.repeat(63)]
    const ultima = dominio - 63 - 1 - 63 - 1 - 1 - 2
    etiquetas.push('b'.repeat(ultima), 'cl')
    return `${local}@${etiquetas.join('.')}`
  }

  it('acepta un correo ASCII válido y rechaza formatos incompletos', () => {
    expect(mensajeEmail('usuario@dominio.cl')).toBeNull()
    for (const invalido of ['usuarioejemplo.cl', 'usuario@', 'usuario@dominio', 'usuario@.cl']) {
      expect(mensajeEmail(invalido)).toMatch(/válido|arroba/i)
    }
    expect(mensajeEmail('')).toMatch(/obligatorio/i)
    expect(mensajeEmail('usuario..prueba@dominio.cl')).not.toBeNull()
  })

  it('rechaza espacios externos sin recortar el valor mostrado', () => {
    expect(mensajeEmail(' usuario@dominio.cl')).toMatch(/espacios/i)
    expect(mensajeEmail('usuario@dominio.cl ')).toMatch(/espacios/i)
  })

  it('rechaza Unicode antes y después de la arroba', () => {
    expect(mensajeEmail('josé@dominio.cl')).toMatch(/ASCII/i)
    expect(mensajeEmail('usuario@dominio.cl')).toBeNull()
    expect(mensajeEmail('usuario@dominio.cl😀')).toMatch(/ASCII/i)
    expect(mensajeEmail('usuário@domínio.cl')).toMatch(/ASCII/i)
  })

  it('acepta exactamente 254 caracteres y rechaza 255', () => {
    const borde = correoDe(254)
    expect(borde).toHaveLength(254)
    expect(mensajeEmail(borde)).toBeNull()
    const excedido = correoDe(255)
    expect(excedido).toHaveLength(255)
    expect(mensajeEmail(excedido)).toMatch(/254/)
  })
})

/* ------------------------------------------------------------------ */
/* Contraseña                                                          */
/* ------------------------------------------------------------------ */
describe('REG-PWD · contraseña fuerte 8-72 ASCII', () => {
  const fuerte = (largo) => 'Aa1!' + 'x'.repeat(largo - 4)

  it('acepta 8 y 72 caracteres y rechaza 7 y 73', () => {
    expect(mensajePassword(fuerte(8))).toBeNull()
    expect(mensajePassword(fuerte(72))).toBeNull()
    expect(mensajePassword(fuerte(7))).toMatch(/al menos 8/)
    expect(mensajePassword(fuerte(73))).toMatch(/72/)
  })

  it('exige mayúscula, minúscula, número y símbolo ASCII', () => {
    expect(mensajePassword('clave1234!')).toMatch(/mayúscula/)
    expect(mensajePassword('CLAVE1234!')).toMatch(/minúscula/)
    expect(mensajePassword('ClaveSegura!')).toMatch(/número/)
    expect(mensajePassword('Clave12345')).toMatch(/símbolo/)
    expect(mensajePassword('Clave1234ñ')).toMatch(/ASCII/)
  })

  it('el indicador nunca dice "Buena" si la longitud no cumple (HAL-REG-003)', () => {
    const valida = passwordStrength(fuerte(72))
    expect(valida.valid).toBe(true)
    const larga = passwordStrength(fuerte(73))
    expect(larga.valid).toBe(false)
    expect(larga.label).not.toBe('Buena')
    const corta = passwordStrength('Clave1!')
    expect(corta.valid).toBe(false)
    expect(corta.label).not.toBe('Buena')
  })

  it('traduce a español el error 400 de GoTrue por contraseña inválida o larga', async () => {
    getClientMock.mockReturnValue(
      clienteSupabase({
        data: { user: null, session: null },
        error: { message: 'Password should be at least 6 characters.' },
      }),
    )
    await expect(
      registrarCliente({
        nombre: 'Ana',
        apellido: 'Pérez',
        email: 'ana@dominio.cl',
        password: 'Clave1234!',
        telefono: '9 1234 5678',
        regionId: 'r-rm',
        comunaId: 'c-paine',
        calle: 'Calle 123',
      }),
    ).rejects.toThrow(/contraseña/i)

    getClientMock.mockReturnValue(
      clienteSupabase({
        data: { user: null, session: null },
        error: { message: 'bcrypt: password length exceeds 72 bytes' },
      }),
    )
    await expect(
      registrarCliente({
        nombre: 'Ana',
        apellido: 'Pérez',
        email: 'ana@dominio.cl',
        password: fuerte(72),
        telefono: '9 1234 5678',
        regionId: 'r-rm',
        comunaId: 'c-paine',
        calle: 'Calle 123',
      }),
    ).rejects.toThrow(/72/)
  })
})

/* ------------------------------------------------------------------ */
/* Teléfono                                                            */
/* ------------------------------------------------------------------ */
describe('REG-TEL · teléfono obligatorio y normalizado', () => {
  it('rechaza vacío, sólo espacios y valores no telefónicos', () => {
    expect(mensajeTelefono('')).toMatch(/obligatorio/i)
    expect(mensajeTelefono('   ')).toMatch(/obligatorio/i)
    expect(mensajeTelefono('abc')).toMatch(/Teléfono chileno no válido/)
    expect(mensajeTelefono('1234')).toMatch(/Teléfono chileno no válido/)
  })

  it('acepta móvil y fijo con o sin +56 y separadores', () => {
    expect(mensajeTelefono('9 1234 5678')).toBeNull()
    expect(mensajeTelefono('+56 9 1234 5678')).toBeNull()
    expect(mensajeTelefono('+56 2 2345 6789')).toBeNull()
  })

  it('no llama a GoTrue sin teléfono y guarda +56 normalizado', async () => {
    const sinTelefono = clienteSupabase()
    getClientMock.mockReturnValue(sinTelefono)
    await expect(
      registrarCliente({
        nombre: 'Ana',
        apellido: 'Pérez',
        email: 'ana@dominio.cl',
        password: 'Clave1234!',
        regionId: 'r-rm',
        comunaId: 'c-paine',
        calle: 'Calle 123',
      }),
    ).rejects.toThrow(/teléfono/i)
    expect(sinTelefono.auth.signUp).not.toHaveBeenCalled()

    const conTelefono = clienteSupabase()
    getClientMock.mockReturnValue(conTelefono)
    await registrarCliente({
      nombre: '  Ana  ',
      apellido: ' Pérez ',
      email: 'Ana@Dominio.CL',
      password: 'Clave1234!',
      telefono: '9 1234 5678',
      regionId: 'r-rm',
      comunaId: 'c-paine',
      calle: ' Calle 123 ',
    })
    const llamada = conTelefono.auth.signUp.mock.calls[0][0]
    expect(llamada.email).toBe('ana@dominio.cl')
    expect(llamada.options.data.telefono).toBe('+56912345678')
    expect(llamada.options.data.nombre).toBe('Ana')
    expect(llamada.options.data.apellido).toBe('Pérez')
  })
})

/* ------------------------------------------------------------------ */
/* Nombres y dirección                                                 */
/* ------------------------------------------------------------------ */
describe('REG-COM / REG-CLI · nombres y dirección', () => {
  it('rechaza HTML y scripts en nombres', () => {
    expect(mensajeNombre('<script>alert(1)</script>', 'El nombre')).toMatch(/HTML/i)
    expect(mensajeNombre('<b>Ana</b>', 'El nombre')).toMatch(/HTML/i)
    expect(mensajeNombre('Ana123', 'El nombre')).toMatch(/Sólo letras/)
    expect(mensajeNombre('  José  ', 'El nombre')).toBeNull()
    expect(mensajeNombre('María José', 'El nombre')).toBeNull()
    expect(mensajeNombre("O'Connor", 'El nombre')).toBeNull()
    expect(mensajeNombre('Ana-María', 'El nombre')).toBeNull()
  })

  it('el número de domicilio es opcional y alfanumérico', () => {
    expect(mensajeNumeroDireccion('')).toBeNull()
    expect(mensajeNumeroDireccion('   ')).toBeNull()
    expect(mensajeNumeroDireccion('123')).toBeNull()
    expect(mensajeNumeroDireccion('123-B')).toBeNull()
    expect(mensajeNumeroDireccion('Casa 3')).toBeNull()
    expect(mensajeNumeroDireccion('x'.repeat(21))).toMatch(/20 caracteres/)
  })

  it('el complemento es opcional, con límite de 50 caracteres', () => {
    expect(mensajeDeptoOficina('')).toBeNull()
    expect(mensajeDeptoOficina('Depto 12')).toBeNull()
    expect(mensajeDeptoOficina('x'.repeat(51))).toMatch(/50 caracteres/)
  })

  it('persiste depto_oficina y no exige número al registrar un cliente', async () => {
    await registrarCliente({
      nombre: 'Ana',
      apellido: 'Pérez',
      email: 'ana@dominio.cl',
      password: 'Clave1234!',
      telefono: '9 1234 5678',
      regionId: 'r-rm',
      comunaId: 'c-paine',
      calle: 'Calle Larga 123',
      numero: '',
      deptoOficina: 'Depto 12',
      referencia: '',
    })
    expect(createDireccion).toHaveBeenCalledTimes(1)
    const direccion = createDireccion.mock.calls[0][0]
    expect(direccion.numero).toBeNull()
    expect(direccion.deptoOficina).toBe('Depto 12')
    expect(direccion.calle).toBe('Calle Larga 123')
  })

  it('rechaza una dirección vacía aunque el número esté presente', () => {
    expect(mensajeCalle('   ')).toMatch(/obligatoria/i)
    expect(mensajeCalle('Calle 123')).toBeNull()
  })
})

/* ------------------------------------------------------------------ */
/* Datos bancarios                                                     */
/* ------------------------------------------------------------------ */
describe('REG-PAG · cuenta bancaria y titular', () => {
  it('acepta 7 y 12 dígitos y rechaza 6 y 13', () => {
    expect(mensajeNumeroCuenta('1234567')).toBeNull()
    expect(mensajeNumeroCuenta('123456789012')).toBeNull()
    expect(mensajeNumeroCuenta('123456')).toMatch(/7 y 12/)
    expect(mensajeNumeroCuenta('1234567890123')).toMatch(/7 y 12/)
    expect(mensajeNumeroCuenta('1234 5678')).toMatch(/sólo puede tener dígitos/)
    expect(mensajeNumeroCuenta('')).toMatch(/Ingresa el número/)
  })

  it('conserva los ceros iniciales como texto al guardar', async () => {
    await registrarVendedor({ ...datosVendedorValidos(), nombreComercial: 'Huerta Los Maitenes' })
    expect(guardarDatosBancarios).toHaveBeenCalledTimes(1)
    const enviado = guardarDatosBancarios.mock.calls[0][0]
    expect(enviado.numeroCuenta).toBe('0001234567')
    expect(typeof enviado.numeroCuenta).toBe('string')
    expect(enviado.rutTitular).toBe('12345678-5')
  })

  it('sugiere el nombre COMPLETO del titular, nunca una inicial (HAL-REG-008)', () => {
    expect(sugerirTitularCuenta('Prueba', 'Vendedor')).toBe('Prueba Vendedor')
    expect(sugerirTitularCuenta('  Prueba ', ' Vendedor  ')).toBe('Prueba Vendedor')
    expect(sugerirTitularCuenta('P', '')).not.toBe('Prueba Vendedor')
  })

  it('exige que el titular y el RUT bancario correspondan al postulante natural', () => {
    const base = {
      tipoPersona: 'natural',
      nombre: 'Prueba',
      apellido: 'Vendedor',
      rutSolicitante: '12345678-5',
    }
    expect(
      validarCuentaDeTerceros({ ...base, titular: 'Prueba Vendedor', rutTitular: '12345678-5' }),
    ).toBeNull()
    expect(
      validarCuentaDeTerceros({ ...base, titular: 'Vendedor Prueba', rutTitular: '12.345.678-5' }),
    ).toBeNull()
    expect(
      validarCuentaDeTerceros({ ...base, titular: 'Prueba Vendedor', rutTitular: '10000005-9' })
        ?.campo,
    ).toBe('rutTitular')
    expect(validarCuentaDeTerceros({ ...base, titular: 'P', rutTitular: '12345678-5' })?.campo).toBe(
      'titular',
    )
  })

  it('para persona jurídica exige el RUT de la empresa y deja la razón social al backend', () => {
    const base = {
      tipoPersona: 'juridica',
      nombre: 'Prueba',
      apellido: 'Vendedor',
      rutSolicitante: '40000000-K',
    }
    expect(
      validarCuentaDeTerceros({ ...base, titular: 'Verduras SpA', rutTitular: '40000000-K' }),
    ).toBeNull()
    expect(
      validarCuentaDeTerceros({ ...base, titular: 'Verduras SpA', rutTitular: '10000005-9' })
        ?.campo,
    ).toBe('rutTitular')
    // Sin RUT suficiente no se inventa una regla: lo decide el servidor.
    expect(
      validarCuentaDeTerceros({ tipoPersona: 'natural', titular: '', rutTitular: '' }),
    ).toBeNull()
  })

  it('valida RUT con puntos, sin puntos y K, y formatea a un valor único', () => {
    expect(mensajeRut('12.345.678-5', 'El RUT')).toBeNull()
    expect(mensajeRut('12345678-5', 'El RUT')).toBeNull()
    expect(mensajeRut('40000000k', 'El RUT')).toBeNull()
    expect(mensajeRut('12345678-9', 'El RUT')).toMatch(/dígito verificador/)
    expect(mensajeRut('', 'El RUT')).toMatch(/obligatorio/i)
    expect(formatearRut('12345678-5')).toBe('12.345.678-5')
    expect(formatearRut('12.345.678-5')).toBe('12.345.678-5')
    expect(formatearRut('40000000k')).toBe('40.000.000-K')
  })

  it('exige banco, tipo de cuenta, titular y RUT válidos antes de crear la cuenta', () => {
    const invalido = validarRegistroVendedor({
      ...datosVendedorValidos(),
      datosBancarios: {
        banco: 'Banco Inexistente',
        tipoCuenta: 'cuenta_inventada',
        numeroCuenta: '123',
        titular: '',
        rutTitular: '10000005-9',
      },
    })
    expect(invalido.banco).toMatch(/catálogo/)
    expect(invalido.tipoCuenta).toMatch(/tipo de cuenta válido/)
    expect(invalido.numeroCuenta).toMatch(/7 y 12/)
    expect(invalido.titular).toMatch(/titular/)
    expect(invalido.rutTitular).toMatch(/RUT/)
  })

  it('neutraliza HTML en el nombre comercial y la descripción', () => {
    expect(mensajeNombreComercial('<script>alert(1)</script>')).toMatch(/HTML/i)
    const errores = validarRegistroVendedor({
      ...datosVendedorValidos(),
      descripcion: '<img src=x onerror=alert(1)>',
    })
    expect(errores.descripcion).toMatch(/HTML/i)
  })
})

/* ------------------------------------------------------------------ */
/* Disponibilidad del RUT de postulación                               */
/* ------------------------------------------------------------------ */
describe('REG-VEN-015 · RUT ya asociado a una postulación', () => {
  it('consulta la RPC pública con p_rut normalizado y respeta su resultado', async () => {
    const cliente = clienteSupabase()
    cliente.rpc.mockResolvedValueOnce({ data: false, error: null })
    getClientMock.mockReturnValue(cliente)

    await expect(verificarRutDisponible('12.345.678-5')).resolves.toEqual({
      disponible: false,
      rut: '12345678-5',
    })
    expect(cliente.rpc).toHaveBeenCalledWith('rut_solicitante_disponible', {
      p_rut: '12345678-5',
    })
  })
})

describe('REG-CONF-005 · recuperación tras confirmar correo', () => {
  it('guarda sólo las rutas recuperadas de documentos sin enviar la postulación', async () => {
    const cadena = {
      update: vi.fn(() => cadena),
      eq: vi.fn(() => cadena),
      select: vi.fn(() => cadena),
      single: vi.fn(async () => ({ data: { id: 'post-1', estado: 'borrador' }, error: null })),
    }
    const cliente = { from: vi.fn(() => cadena) }
    getClientMock.mockReturnValue(cliente)

    await expect(
      guardarDocumentosBorrador('post-1', {
        documentoIdentidad: {
          columna: 'documento_identidad',
          ruta: 'vendedor-documentos/usuario/documento-identidad.pdf',
        },
      }),
    ).resolves.toMatchObject({ id: 'post-1', estado: 'borrador' })

    expect(cadena.update).toHaveBeenCalledWith({
      documento_identidad: 'vendedor-documentos/usuario/documento-identidad.pdf',
    })
  })
})

/* ------------------------------------------------------------------ */
/* Documentos                                                          */
/* ------------------------------------------------------------------ */
describe('REG-DOC · documentos de la postulación', () => {
  it('acepta exactamente 10 MiB (10.485.760 bytes) y rechaza el byte siguiente', () => {
    expect(MAX_BYTES_DOCUMENTO).toBe(10485760)
    expect(validarDocumentoPostulante(DOC('carnet.pdf', MAX_BYTES_DOCUMENTO))).toBeNull()
    expect(validarDocumentoPostulante(DOC('carnet.pdf', MAX_BYTES_DOCUMENTO + 1))).toMatch(/10 MB/)
  })

  it('rechaza archivos vacíos, MIME ejecutable y doble extensión', () => {
    expect(validarDocumentoPostulante(DOC('vacio.pdf', 0))).toMatch(/vacío/i)
    expect(validarDocumentoPostulante(DOC('raro.pdf', 100, 'application/x-msdownload'))).toMatch(
      /Formato no permitido/i,
    )
    expect(validarDocumentoPostulante(DOC('documento.pdf.exe', 100))).toMatch(/Formato no permitido/i)
    expect(validarDocumentoPostulante(DOC('documento.exe.pdf', 100))).toMatch(/ejecutable/i)
    expect(validarDocumentoPostulante(DOC('documento.pdf.png', 100))).toMatch(/extensión doble/i)
    expect(validarDocumentoPostulante(DOC('documento.png', 100, 'image/png'))).toBeNull()
  })

  it('permite el mismo archivo en los cuatro campos y los cuatro de 10 MiB', () => {
    const mismo = DOC('carnet.pdf', MAX_BYTES_DOCUMENTO)
    const errores = validarRegistroVendedor({
      ...datosVendedorValidos(),
      documentos: {
        documentoIdentidad: mismo,
        certificadoActividadesOCarnet: mismo,
        certificadoTitularidad: mismo,
        comprobanteDomicilio: mismo,
      },
    })
    expect(errores.documentoIdentidad).toBeUndefined()
    expect(errores.certificadoActividadesOCarnet).toBeUndefined()
    expect(errores.certificadoTitularidad).toBeUndefined()
    expect(errores.comprobanteDomicilio).toBeUndefined()
  })

  it('identifica cada documento faltante', () => {
    const errores = validarRegistroVendedor({
      ...datosVendedorValidos(),
      documentos: { documentoIdentidad: DOC() },
    })
    expect(errores.certificadoActividadesOCarnet).toMatch(/Adjunta/)
    expect(errores.certificadoTitularidad).toMatch(/Adjunta/)
    expect(errores.comprobanteDomicilio).toMatch(/Adjunta/)
    expect(errores.documentoIdentidad).toBeUndefined()
  })

  it('detecta el PDF corrupto o renombrado por su contenido cuando es legible', async () => {
    const conBytes = (nombre, bytes, type = 'application/pdf') => ({
      name: nombre,
      type,
      size: bytes.length,
      slice: () => ({ arrayBuffer: async () => new Uint8Array(bytes).buffer }),
    })
    const pdfReal = conBytes('carnet.pdf', [
      0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x37, 0x0a,
    ])
    expect(await validarContenidoDocumento(pdfReal)).toBeNull()

    const exeRenombrado = conBytes('carnet.pdf', [0x4d, 0x5a, 0x90, 0x00])
    expect(await validarContenidoDocumento(exeRenombrado)).toMatch(/PDF válido/)

    const png = conBytes('domicilio.png', [0x89, 0x50, 0x4e, 0x47], 'image/png')
    expect(await validarContenidoDocumento(png)).toBeNull()
    const pngFalso = conBytes('domicilio.png', [0x25, 0x50, 0x44, 0x46], 'image/png')
    expect(await validarContenidoDocumento(pngFalso)).toMatch(/PNG válida/)
  })
})

/* ------------------------------------------------------------------ */
/* Metadatos del signUp (REG-CLI-017 / REG-CONF-001)                   */
/* ------------------------------------------------------------------ */
describe('signUp · metadatos para el trigger con confirmación de correo', () => {
  it('envía tipo_registro, dirección y teléfono del cliente', async () => {
    const cliente = clienteSupabase({
      data: { user: { id: 'u-1' }, session: null },
      error: null,
    })
    getClientMock.mockReturnValue(cliente)
    await registrarCliente({
      nombre: 'Ana',
      apellido: 'Pérez',
      email: 'ana@dominio.cl',
      password: 'Clave1234!',
      telefono: '9 1234 5678',
      regionId: 'r-rm',
      comunaId: 'c-paine',
      calle: 'Calle Larga 123',
      numero: '123-B',
      deptoOficina: 'Depto 12',
      referencia: 'Portón verde',
    })
    const metadatos = cliente.auth.signUp.mock.calls[0][0].options.data
    expect(metadatos).toMatchObject({
      tipo_registro: 'cliente',
      region_id: 'r-rm',
      comuna_id: 'c-paine',
      calle: 'Calle Larga 123',
      numero: '123-B',
      depto_oficina: 'Depto 12',
      referencia: 'Portón verde',
      telefono: '+56912345678',
    })
  })

  it('envía los datos de la tienda del vendedor', async () => {
    const cliente = clienteSupabase({
      data: { user: { id: 'u-1' }, session: null },
      error: null,
    })
    getClientMock.mockReturnValue(cliente)
    await registrarVendedor(datosVendedorValidos())
    const metadatos = cliente.auth.signUp.mock.calls[0][0].options.data
    expect(metadatos).toMatchObject({
      tipo_registro: 'vendedor',
      nombre_comercial: 'Huerta Los Maitenes',
      descripcion: 'Verduras de estación',
      rut_solicitante: '12345678-5',
      tipo_persona: 'natural',
      depto_oficina: 'Parcela 4',
    })
  })
})

/* ------------------------------------------------------------------ */
/* CK-0462 / CK-0485 / CK-0484: consistencia entre formularios         */
/* ------------------------------------------------------------------ */

describe('CK-0462 (HAL-CLI-002) y CK-0485 (HAL-CLI-026): misma política e indicador en los 4 formularios', () => {
  // vitest corre con cwd = raíz del frontend
  const vista = (p) => readFileSync(`src/views/${p}`, 'utf8')

  it.each([
    'auth/RegisterView.vue',
    'auth/RegisterSellerView.vue',
    'auth/ForgotPasswordView.vue',
    'client/ClientProfileView.vue',
  ])('%s usa la política única de lib/validation (requisitos visibles + fortaleza)', (archivo) => {
    const src = vista(archivo)
    // una sola fuente de verdad: PASSWORD_REQUIREMENTS y passwordStrength de lib/validation
    expect(src).toMatch(/from '@\/lib\/validation'/)
    expect(src).toContain('PASSWORD_REQUIREMENTS')
    expect(src).toContain('passwordStrength')
    // y la validación de envío pasa por la misma política (8-72, may/min/número/símbolo)
    expect(src).toMatch(/passwordPolicyMessage|mensajePassword/)
  })

  it('la política visible es la aprobada: 8 a 72 caracteres con mayúscula, minúscula, número y símbolo', () => {
    expect(PASSWORD_MIN_LENGTH).toBe(8)
    expect(PASSWORD_MAX_LENGTH).toBe(72)
    const requisitos = PASSWORD_REQUIREMENTS.map((r) => r.label ?? r.id ?? String(r))
    expect(requisitos.join(' ').toLowerCase()).toMatch(/mayúscula/)
    expect(requisitos.join(' ').toLowerCase()).toMatch(/minúscula/)
    expect(requisitos.join(' ').toLowerCase()).toMatch(/número/)
    expect(requisitos.join(' ').toLowerCase()).toMatch(/símbolo/)
  })
})
