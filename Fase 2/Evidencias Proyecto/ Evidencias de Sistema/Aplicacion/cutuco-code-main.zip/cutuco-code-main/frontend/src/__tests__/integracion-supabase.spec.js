/**
 * CuTuCo — Pruebas de integración contra Supabase local (datos reales).
 *
 * Reemplazan al antiguo `demo-flow.spec.js`, que ejercitaba el cliente
 * simulado en memoria. Ahora las consultas van a PostgREST con RLS, así que la
 * batería se ejecuta sólo cuando la instancia local responde (supabase start +
 * frontend/.env.local). Si no está disponible, cada caso se marca como omitido
 * en lugar de simular datos.
 *
 * Cubre los flujos de lectura que sostienen RF-002, RF-006, RF-009, RF-021,
 * RF-022 y RF-025.
 */
import { beforeAll, beforeEach, describe, expect, it } from 'vitest'

import { SUPABASE_ANON_KEY, SUPABASE_URL, getClient, MISSING_ENV } from '@/lib/supabase'
import { listProductos, listCategorias, getProducto, getProductorDetalle } from '@/services/catalog'
import { getJerarquiaGeografica } from '@/services/geography'
import { listPagos } from '@/services/payments'
import { getPendientesAdmin } from '@/services/admin'

/**
 * Cuentas de la galería (`supabase/seeds/gallery_dev.sql`).
 * Son las cuentas propias del proyecto: existen en cualquier entorno con las
 * semillas cargadas (`supabase db reset`).
 */
const CUENTAS = {
  cliente: { email: 'cliente@cutuco.dev', password: 'CutucoDev2026!' },
  vendedor: { email: 'vendedor@cutuco.dev', password: 'CutucoDev2026!' },
  admin: { email: 'admin@cutuco.dev', password: 'CutucoDev2026!' },
  pendiente: { email: 'pendiente@cutuco.dev', password: 'CutucoDev2026!' },
}

/**
 * Cuentas de `supabase/seed.sql`. Son las que tienen pedidos y pagos reales
 * (las de la galería existen para revisar ventanas, no para comprar).
 */
const CUENTAS_SEED = {
  clienteConPedidos: {
    email: 'cutuco.cliente.santiago@example.test',
    password: 'CutucoTest!2026',
  },
}

async function iniciarSesionSeed(cuenta) {
  const client = getClient()
  await client.auth.signOut()
  const { data, error } = await client.auth.signInWithPassword(cuenta)
  if (error) throw new Error(`No se pudo iniciar sesión como ${cuenta.email}: ${error.message}`)
  return data.user
}

/** Comprueba si el stack local responde antes de ejecutar la batería. */
async function disponible() {
  if (MISSING_ENV) return false
  try {
    const respuesta = await fetch(`${SUPABASE_URL}/rest/v1/regiones?select=codigo&limit=1`, {
      headers: { apikey: SUPABASE_ANON_KEY },
    })
    return respuesta.ok
  } catch {
    return false
  }
}

let hayStack = false

beforeAll(async () => {
  hayStack = await disponible()
}, 20000)

/**
 * La sesión se limpia antes de cada caso: las pruebas de RLS inician sesión con
 * distintas cuentas y la sesión quedaría activa para el siguiente caso.
 */
beforeEach(async () => {
  if (!hayStack) return
  await getClient().auth.signOut()
})

async function iniciarSesion(rol) {
  const client = getClient()
  await client.auth.signOut()
  const { data, error } = await client.auth.signInWithPassword(CUENTAS[rol])
  if (error) throw new Error(`No se pudo iniciar sesión como ${rol}: ${error.message}`)
  return data.user
}

describe('integración · catálogo público (RF-022 y RF-002)', () => {
  it('lista productos activos con vendedor, categoría e imagen', async () => {
    if (!hayStack) return
    const { items, total } = await listProductos({ pageSize: 6 })
    expect(total).toBeGreaterThan(0)
    expect(items.length).toBeGreaterThan(0)
    for (const item of items) {
      expect(item.id, `producto sin id: ${item.nombre}`).toBeTruthy()
      expect(item.nombre).toBeTruthy()
      // RF-003: el vendedor es siempre visible; la fotografía es opcional y
      // cuando falta se usa la ilustración de respaldo del catálogo.
      expect(item.productor?.nombre_comercial, `producto sin vendedor: ${item.nombre}`).toBeTruthy()
      // El vendedor debe estar activo: un productor suspendido no publica
      // productos en el catálogo (RF-026).
      expect(item.productor.activo, `vendedor inactivo en catálogo: ${item.nombre}`).toBe(true)
      expect(item.imagenPrincipal?.url, `producto sin imagen ni respaldo: ${item.nombre}`).toBeTruthy()
      expect(item.unidad_medida).toBeTruthy()
      expect(Number(item.precio)).toBeGreaterThan(0)
    }
  })

  it('filtra por texto y por categoría', async () => {
    if (!hayStack) return
    const categorias = await listCategorias()
    expect(categorias.length).toBeGreaterThanOrEqual(50)
    expect(categorias.filter((c) => c.categoria_padre_id === null).length).toBeGreaterThanOrEqual(15)

    const { items } = await listProductos({ categoriaId: categorias[0].id, pageSize: 20 })
    for (const item of items) expect(item.categoria_id).toBe(categorias[0].id)

    const busqueda = await listProductos({ texto: 'tomate', pageSize: 20 })
    expect(busqueda.items.every((p) => p.nombre.toLowerCase().includes('tomate'))).toBe(true)
  })

  it('devuelve el detalle de un producto del catálogo', async () => {
    if (!hayStack) return
    const { items } = await listProductos({ pageSize: 1 })
    const producto = await getProducto(items[0].id)
    expect(producto?.nombre).toBe(items[0].nombre)
    expect(producto?.stock).toBeGreaterThanOrEqual(0)
  })

  it('expone regiones y comunas para los combobox (RF-018)', async () => {
    if (!hayStack) return
    const jerarquia = await getJerarquiaGeografica()
    expect(jerarquia.length).toBe(16)
    expect(jerarquia[0].comunas.length).toBeGreaterThan(0)
  })
})

describe('integración · cobertura regional (RF-009)', () => {
  it('el vendedor tiene su región de cobertura registrada (RF-009)', async () => {
    if (!hayStack) return
    const { items } = await listProductos({ pageSize: 3 })
    for (const item of items) {
      expect(item.productor?.region_id).toBeTruthy()
      expect(item.regionProductor?.id).toBe(item.productor.region_id)
    }
  })

  it('el perfil público del vendedor publica su región sin exponer su dirección', async () => {
    if (!hayStack) return
    const { items } = await listProductos({ pageSize: 1 })
    const detalle = await getProductorDetalle(items[0].productor_id)
    expect(detalle?.region?.id).toBe(items[0].productor.region_id)
    expect(detalle?.direccion).toBeUndefined()
    expect(detalle?.productos.length).toBeGreaterThan(0)
  })
})

describe('integración · autenticación y roles (RF-001 y RF-021)', () => {
  it('inicia sesión con las cuatro cuentas de la galería', async () => {
    if (!hayStack) return
    for (const rol of Object.keys(CUENTAS)) {
      const user = await iniciarSesion(rol)
      expect(user?.email).toBe(CUENTAS[rol].email)
    }
  })

  it('rechaza una contraseña incorrecta', async () => {
    if (!hayStack) return
    const client = getClient()
    await client.auth.signOut()
    const { error } = await client.auth.signInWithPassword({
      email: CUENTAS.cliente.email,
      password: 'clave-incorrecta',
    })
    expect(error).toBeTruthy()
  })

  it('el cliente ve sólo sus propios pedidos (RLS)', async () => {
    if (!hayStack) return
    const user = await iniciarSesion('cliente')
    const client = getClient()
    const { data, error } = await client.from('pedidos').select('id, cliente_id')
    expect(error).toBeNull()
    expect((data ?? []).every((p) => p.cliente_id === user.id)).toBe(true)
  })

  /*
   * Historial de compras (RF-002) y seguimiento del pedido (RF-005): el cliente
   * necesita leer el pago de SUS pedidos por PostgREST. La policy base
   * `pagos_select_admin` lo impedía, así que la migración
   * `20261008000000_pagos_select_participantes.sql` añade la lectura para los
   * participantes del pedido. Estas pruebas fijan ese contrato.
   */
  it('el cliente lee el pago de sus propios pedidos (RLS de participantes)', async () => {
    if (!hayStack) return
    const user = await iniciarSesionSeed(CUENTAS_SEED.clienteConPedidos)
    const client = getClient()

    const { data: pedidos } = await client.from('pedidos').select('id').eq('cliente_id', user.id)
    expect((pedidos ?? []).length).toBeGreaterThan(0)

    // `pagos` ya no tiene columna `estado` (Webpay Mall): la fila existe sólo
    // cuando el cobro quedó autorizado (`codigo_respuesta='0'` = aprobado).
    const { data: pagos, error } = await client.from('pagos').select('id, pedido_id, codigo_respuesta')
    expect(error).toBeNull()
    expect((pagos ?? []).length).toBeGreaterThan(0)

    const propios = new Set((pedidos ?? []).map((p) => p.id))
    expect((pagos ?? []).every((p) => propios.has(p.pedido_id))).toBe(true)
    expect((pagos ?? []).every((p) => p.codigo_respuesta === '0' || p.codigo_respuesta == null)).toBe(true)
  })

  it('un cliente sin pedidos no ve ningún pago ajeno', async () => {
    if (!hayStack) return
    await iniciarSesion('cliente')
    const client = getClient()
    const { data } = await client.from('pagos').select('id, pedido_id')
    expect(data ?? []).toHaveLength(0)
  })
})

describe('integración · panel administrativo (RF-004, RF-005 y RF-011)', () => {
  it('el administrador obtiene los pendientes reales', async () => {
    if (!hayStack) return
    await iniciarSesion('admin')
    const pendientes = await getPendientesAdmin()
    expect(pendientes).toHaveProperty('pendientes')
    // Webpay Mall eliminó custodia y payouts: quedan postulaciones y sanciones.
    expect(Array.isArray(pendientes.postulaciones)).toBe(true)
    expect(Array.isArray(pendientes.sanciones)).toBe(true)
    expect(typeof pendientes.pendientes.productores).toBe('number')
    expect(typeof pendientes.pendientes.sanciones).toBe('number')
    expect(typeof pendientes.operacion.comisiones).toBe('number')
  })

  it('el admin lee los comprobantes autorizados', async () => {
    if (!hayStack) return
    await iniciarSesion('admin')
    // Con Webpay Mall `pagos` guarda sólo comprobantes autorizados (Mall dispersa).
    const lista = await listPagos()
    expect(Array.isArray(lista)).toBe(true)
    expect(lista.length).toBeGreaterThan(0)
    expect(lista.every((p) => Number(p.monto) > 0)).toBe(true)
  })

  it('el cliente no puede leer las postulaciones (RLS por rol)', async () => {
    if (!hayStack) return
    await iniciarSesion('cliente')
    const client = getClient()
    const { data } = await client.from('postulaciones_vendedores').select('id, estado')
    expect(data ?? []).toHaveLength(0)
  })
})

describe('integración · ventas del vendedor (RF-003 y RF-025)', () => {
  it('el vendedor ve sólo sus propios pedidos', async () => {
    if (!hayStack) return
    const user = await iniciarSesion('vendedor')
    const client = getClient()
    const { data: productor } = await client
      .from('productores')
      .select('id')
      .eq('perfil_id', user.id)
      .maybeSingle()
    expect(productor?.id).toBeTruthy()

    const { data: pedidos } = await client.from('pedidos').select('id, productor_id')
    expect((pedidos ?? []).every((p) => p.productor_id === productor.id)).toBe(true)
  })
})
