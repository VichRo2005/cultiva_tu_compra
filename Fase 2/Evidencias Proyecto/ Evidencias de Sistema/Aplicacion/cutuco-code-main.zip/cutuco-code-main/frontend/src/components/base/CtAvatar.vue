<script setup>
/** CuTuCo — Avatar con iniciales o imagen. */
import { computed, ref, watch } from 'vue'
import { avatarImage } from '@/lib/images'

const props = defineProps({
  name: { type: String, default: '' },
  src: { type: String, default: null },
  size: { type: Number, default: 40 },
  tone: { type: String, default: 'primary' },
  square: { type: Boolean, default: false },
})

const imageFallida = ref(false)
const image = computed(() => (!imageFallida.value && props.src) || avatarImage(props.name))

watch(
  () => props.src,
  () => {
    imageFallida.value = false
  },
)

function usarAvatarPorDefecto() {
  imageFallida.value = true
}
</script>

<template>
  <span
    class="ct-avatar"
    :class="[`ct-avatar--${tone}`, { 'is-square': square }]"
    :style="{ width: `${size}px`, height: `${size}px`, fontSize: `${Math.round(size * 0.38)}px` }"
    :title="name"
  >
    <img :src="image" :alt="name" @error="usarAvatarPorDefecto" />
  </span>
</template>

<style scoped>
.ct-avatar {
  display: inline-grid;
  place-items: center;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
  border: 1px solid var(--ct-border);
  background: var(--ct-primary-soft);
  box-shadow: var(--ct-shadow-xs);
}

.ct-avatar.is-square {
  border-radius: var(--ct-radius-md);
}

.ct-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
