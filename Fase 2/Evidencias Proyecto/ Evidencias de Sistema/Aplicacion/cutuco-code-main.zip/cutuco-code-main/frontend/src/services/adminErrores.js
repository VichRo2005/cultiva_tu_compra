// Mensajes legibles compartidos por los servicios de administración.
//
// ORDEN DE REGISTROS: primero las reglas específicas (nombres de constraints
// concretos) y recién al final las genéricas. La regla de moderación usa el
// texto exacto del trigger (validar_texto_moderado: 'El texto contiene una
// palabra prohibida por la moderacion') y NO el nombre de la tabla
// palabras_prohibidas, que aparece en TODOS los errores PostgreSQL de esa
// tabla (duplicados, comodines, longitud) y antes los enmascaraba.
export function adminResult(
  { data, error },
  fallback = 'No se pudo completar la operación. Intenta nuevamente.',
) {
  if (!error) return data
  const message = String(error.message ?? '')
  if (/ck_palabra_sin_wildcards/i.test(message))
    throw new Error('La palabra no puede contener los comodines % ni _.')
  if (/uq_palabra_prohibida_lower/i.test(message))
    throw new Error('Esa palabra ya está en la lista (no distingue mayúsculas).')
  if (/ck_sancion_accion_coherente|amonestacion usa accion/i.test(message)) {
    throw new Error(
      "La acción seleccionada no es coherente con el tipo de sanción. Si el tipo es 'amonestación sin acción', no puedes asignar suspensión o ban.",
    )
  }
  if (/duracion|duración/i.test(message))
    throw new Error('La duración debe ser un número entero entre 1 y 60 días')
  if (/ban permanente activo|uq_ban_permanente/i.test(message))
    throw new Error('Este usuario ya tiene un ban permanente activo.')
  if (/otras sanciones vigentes/i.test(message))
    throw new Error('Primero resuelve las otras sanciones vigentes de este usuario.')
  if (/eliminad/i.test(message))
    throw new Error('Una cuenta eliminada permanentemente no se puede reactivar.')
  if (/palabra prohibida por la moderacion|palabra prohibida por la moderación/i.test(message))
    throw new Error('El texto contiene palabras no permitidas. Revisa su contenido.')
  if (/duplicate key/i.test(message)) throw new Error('Ya existe un registro con esos datos.')
  if (/permission|policy|administrador/i.test(message) || error.code === '42501')
    throw new Error('No tienes permisos para realizar esta operación.')
  throw new Error(fallback)
}
