/**
 * CuTuCo — Dataset de demostración del prototipo anterior.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Este dataset en memoria alimentaba `src/lib/mockSupabase.js` (modo
 *   demostración) y espejaba el esquema `20260924114306_remote_schema.sql`, que
 *   ya fue reemplazado por `supabase/migrations/20261004021917_nuevo_alcance.sql`.
 *   El ERS exige datos reales, así que ninguna vista lo importa: la aplicación
 *   usa Supabase (PostgREST + RLS) y FastAPI. Se conserva sólo como referencia.
 */
import { ESTADO_APELACION, ESTADO_ENVIO, ESTADO_PAGO, ESTADO_PEDIDO, ESTADO_POSTULACION, ESTADO_RECLAMO, ESTADO_SANCION, REGLAS, TIPO_COBERTURA } from '@/lib/constants'
import { documentPlaceholder, escenaImage, placeholderImage } from '@/lib/images'

/* ------------------------------------------------------------------ */
/* Helpers de construcción                                             */
/* ------------------------------------------------------------------ */

let seq = 1000
export function nextId() {
  seq += 1
  return `d0000000-0000-4000-8000-${String(seq).padStart(12, '0')}`
}

const DAY = 86400000

function dayOffset(days, hour = 10) {
  const d = new Date(Date.now() + days * DAY)
  d.setHours(hour, 0, 0, 0)
  return d.toISOString()
}

function dateOnly(days = 0) {
  const d = new Date(Date.now() + days * DAY)
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(d)
}

const round2 = (n) => Math.round(n * 100) / 100

/* ------------------------------------------------------------------ */
/* IDs reutilizados del seed oficial                                  */
/* ------------------------------------------------------------------ */

export const IDS = Object.freeze({
  adminBase: 'a0000000-0000-0000-0000-000000000001',
  clienteDemo: 'a0000000-0000-0000-0000-000000000002',
  adminSec: 'a0000000-0000-0000-0000-000000000003',
  cliente2: 'a0000000-0000-0000-0000-000000000004',
  vendedor1: 'a0000000-0000-0000-0000-000000000101',
  vendedor2: 'a0000000-0000-0000-0000-000000000102',
  vendedor3: 'a0000000-0000-0000-0000-000000000103',
  vendedor4: 'a0000000-0000-0000-0000-000000000104',
  vendedor5: 'a0000000-0000-0000-0000-000000000105',
  vendedor6: 'b0000000-0000-4000-8000-000000000106',
  vendedor7: 'b0000000-0000-4000-8000-000000000107',
  vendedorPend1: 'b0000000-0000-4000-8000-000000000108',
  vendedorPend2: 'b0000000-0000-4000-8000-000000000109',
  vendedorPend3: 'b0000000-0000-4000-8000-000000000110',
  vendedorPend4: 'b0000000-0000-4000-8000-000000000111',
  vendedorPend5: 'b0000000-0000-4000-8000-000000000112',
  vendedorPend6: 'b0000000-0000-4000-8000-000000000113',
  vendedorPend7: 'b0000000-0000-4000-8000-000000000114',
  cliente3: 'b0000000-0000-4000-8000-000000000201',
  cliente4: 'b0000000-0000-4000-8000-000000000202',
  cliente5: 'b0000000-0000-4000-8000-000000000203',
  cliente6: 'b0000000-0000-4000-8000-000000000204',
  cliente7: 'b0000000-0000-4000-8000-000000000205',
  cliente8: 'b0000000-0000-4000-8000-000000000206',

  regionRM: '11000000-0000-0000-0000-000000000001',
  regionVS: '11000000-0000-0000-0000-000000000002',
  regionAP: '11000000-0000-0000-0000-000000000003',
  regionTA: '11000000-0000-0000-0000-000000000004',
  regionAN: '11000000-0000-0000-0000-000000000005',
  regionAT: '11000000-0000-0000-0000-000000000006',
  regionCO: '11000000-0000-0000-0000-000000000007',
  regionOH: '11000000-0000-0000-0000-000000000008',
  regionML: '11000000-0000-0000-0000-000000000009',
  regionNB: '11000000-0000-0000-0000-000000000010',
  regionBI: '11000000-0000-0000-0000-000000000011',
  regionAR: '11000000-0000-0000-0000-000000000012',
  regionLR: '11000000-0000-0000-0000-000000000013',
  regionLL: '11000000-0000-0000-0000-000000000014',
  regionAI: '11000000-0000-0000-0000-000000000015',
  regionMA: '11000000-0000-0000-0000-000000000016',

  productor1: '20000000-0000-0000-0000-000000000001',
  productor2: '20000000-0000-0000-0000-000000000002',
  productor3: '20000000-0000-0000-0000-000000000003',
  productor4: '20000000-0000-0000-0000-000000000004',
  productor5: '20000000-0000-0000-0000-000000000005',
  productor6: 'd0000000-0000-4000-8000-000000001006',
  productor7: 'd0000000-0000-4000-8000-000000001007',

  catHortalizas: '13000000-0000-0000-0000-000000000001',
  catFrutas: '13000000-0000-0000-0000-000000000002',
  catTuberculos: '13000000-0000-0000-0000-000000000003',
  catHierbas: '13000000-0000-0000-0000-000000000004',
  catConservas: '13000000-0000-0000-0000-000000000005',
  catLacteos: '13000000-0000-0000-0000-000000000006',
  catCarnes: '13000000-0000-0000-0000-000000000007',
  catMiel: '13000000-0000-0000-0000-000000000008',
  catGranos: '13000000-0000-0000-0000-000000000009',
  catFrutosSecos: '13000000-0000-0000-0000-000000000010',
  catAceites: '13000000-0000-0000-0000-000000000011',
  catBebidas: '13000000-0000-0000-0000-000000000012',
  catFlores: '13000000-0000-0000-0000-000000000013',
  catArtesanias: '13000000-0000-0000-0000-000000000014',
  catMascotas: '13000000-0000-0000-0000-000000000015',
  catHortalizasHoja: '13000000-0000-0000-0000-000000000101',
  catHortalizasFruto: '13000000-0000-0000-0000-000000000102',
  catFrutasUva: '13000000-0000-0000-0000-000000000202',
  catFrutasCitrinos: '13000000-0000-0000-0000-000000000201',
  catTuberculosPapa: '13000000-0000-0000-0000-000000000301',
  catSinCategoria: '00000000-0000-0000-0000-000000000001',
})

/* ------------------------------------------------------------------ */
/* Fábrica del dataset                                                 */
/* ------------------------------------------------------------------ */

export function createDemoDatabase() {
  seq = 1000
  const storageObjects = new Map()

  const put = (bucket, path, dataUri, contentType = 'image/svg+xml') => {
    storageObjects.set(`${bucket}/${path}`, {
      path,
      url: dataUri,
      contentType,
      size: Math.round(dataUri.length * 0.75),
    })
  }

  /* ---------------- Regiones y comunas ---------------- */
  const regiones = [
    { id: IDS.regionRM, codigo: 'RM13', nombre: 'Región Metropolitana de Santiago' },
    { id: IDS.regionVS, codigo: 'V05', nombre: 'Región de Valparaíso' },
    { id: IDS.regionAP, codigo: 'XV15', nombre: 'Región de Arica y Parinacota' },
    { id: IDS.regionTA, codigo: 'I01', nombre: 'Región de Tarapacá' },
    { id: IDS.regionAN, codigo: 'II02', nombre: 'Región de Antofagasta' },
    { id: IDS.regionAT, codigo: 'III03', nombre: 'Región de Atacama' },
    { id: IDS.regionCO, codigo: 'IV04', nombre: 'Región de Coquimbo' },
    { id: IDS.regionOH, codigo: 'VI06', nombre: 'Región de O’Higgins' },
    { id: IDS.regionML, codigo: 'VII07', nombre: 'Región del Maule' },
    { id: IDS.regionNB, codigo: 'XVI16', nombre: 'Región de Ñuble' },
    { id: IDS.regionBI, codigo: 'VIII08', nombre: 'Región del Biobío' },
    { id: IDS.regionAR, codigo: 'IX09', nombre: 'Región de La Araucanía' },
    { id: IDS.regionLR, codigo: 'XIV14', nombre: 'Región de Los Ríos' },
    { id: IDS.regionLL, codigo: 'X10', nombre: 'Región de Los Lagos' },
    { id: IDS.regionAI, codigo: 'XI11', nombre: 'Región de Aysén' },
    { id: IDS.regionMA, codigo: 'XII12', nombre: 'Región de Magallanes y de la Antártica Chilena' },
  ].map((r) => ({ ...r, creado_en: dayOffset(-420), actualizado_en: dayOffset(-420) }))

  const comunaRows = [
    ['12000000-0000-0000-0000-000000000001', IDS.regionRM, 'RMPAI', 'Paine'],
    ['12000000-0000-0000-0000-000000000002', IDS.regionRM, 'RMBUI', 'Buin'],
    ['12000000-0000-0000-0000-000000000003', IDS.regionRM, 'RMSBE', 'San Bernardo'],
    ['12000000-0000-0000-0000-000000000004', IDS.regionRM, 'RMSAN', 'Santiago'],
    ['12000000-0000-0000-0000-000000000005', IDS.regionRM, 'RMPRO', 'Providencia'],
    ['12000000-0000-0000-0000-000000000006', IDS.regionRM, 'RMMEL', 'Melipilla'],
    ['12000000-0000-0000-0000-000000000007', IDS.regionVS, 'V05QUI', 'Quillota'],
    ['12000000-0000-0000-0000-000000000008', IDS.regionVS, 'V05VAL', 'Valparaíso'],
    ['12000000-0000-0000-0000-000000000009', IDS.regionOH, 'V06SAN', 'San Vicente de Tagua Tagua'],
    ['12000000-0000-0000-0000-000000000010', IDS.regionOH, 'V06RAP', 'Rancagua'],
    ['12000000-0000-0000-0000-000000000011', IDS.regionML, 'V07TEN', 'Tenca'],
    ['12000000-0000-0000-0000-000000000012', IDS.regionML, 'V07CUR', 'Curepto'],
    ['12000000-0000-0000-0000-000000000013', IDS.regionRM, 'RMPIR', 'Pirque'],
    ['12000000-0000-0000-0000-000000000014', IDS.regionVS, 'V05LIM', 'Limache'],
    ['12000000-0000-0000-0000-000000000015', IDS.regionRM, 'RMSJO', 'San José de Maipo'],
    ['12000000-0000-0000-0000-000000000016', IDS.regionRM, 'RMCAL', 'Calera de Tango'],
    ['12000000-0000-0000-0000-000000000017', IDS.regionVS, 'V05LAY', 'Llay-Llay'],
    ['12000000-0000-0000-0000-000000000018', IDS.regionOH, 'V06SFE', 'San Fernando'],
    ['12000000-0000-0000-0000-000000000019', IDS.regionAP, 'XVARI', 'Arica'],
    ['12000000-0000-0000-0000-000000000020', IDS.regionAP, 'XVPUT', 'Putre'],
    ['12000000-0000-0000-0000-000000000021', IDS.regionTA, 'I01IQU', 'Iquique'],
    ['12000000-0000-0000-0000-000000000022', IDS.regionTA, 'I01ALT', 'Alto Hospicio'],
    ['12000000-0000-0000-0000-000000000023', IDS.regionAN, 'II02ANT', 'Antofagasta'],
    ['12000000-0000-0000-0000-000000000024', IDS.regionAN, 'II02CAL', 'Calama'],
    ['12000000-0000-0000-0000-000000000025', IDS.regionAT, 'III03COP', 'Copiapó'],
    ['12000000-0000-0000-0000-000000000026', IDS.regionAT, 'III03VAL', 'Vallenar'],
    ['12000000-0000-0000-0000-000000000027', IDS.regionCO, 'IV04SER', 'La Serena'],
    ['12000000-0000-0000-0000-000000000028', IDS.regionCO, 'IV04COQ', 'Coquimbo'],
    ['12000000-0000-0000-0000-000000000029', IDS.regionCO, 'IV04OVA', 'Ovalle'],
    ['12000000-0000-0000-0000-000000000030', IDS.regionNB, 'XVI16CHI', 'Chillán'],
    ['12000000-0000-0000-0000-000000000031', IDS.regionNB, 'XVI16SCA', 'San Carlos'],
    ['12000000-0000-0000-0000-000000000032', IDS.regionBI, 'VIII08CON', 'Concepción'],
    ['12000000-0000-0000-0000-000000000033', IDS.regionBI, 'VIII08LAN', 'Los Ángeles'],
    ['12000000-0000-0000-0000-000000000034', IDS.regionAR, 'IX09TEM', 'Temuco'],
    ['12000000-0000-0000-0000-000000000035', IDS.regionAR, 'IX09VIL', 'Villarrica'],
    ['12000000-0000-0000-0000-000000000036', IDS.regionLR, 'XIV14VAL', 'Valdivia'],
    ['12000000-0000-0000-0000-000000000037', IDS.regionLR, 'XIV14LUN', 'La Unión'],
    ['12000000-0000-0000-0000-000000000038', IDS.regionLL, 'X10PMO', 'Puerto Montt'],
    ['12000000-0000-0000-0000-000000000039', IDS.regionLL, 'X10OSO', 'Osorno'],
    ['12000000-0000-0000-0000-000000000040', IDS.regionLL, 'X10CAS', 'Castro'],
    ['12000000-0000-0000-0000-000000000041', IDS.regionAI, 'XI11COY', 'Coyhaique'],
    ['12000000-0000-0000-0000-000000000042', IDS.regionAI, 'XI11PAY', 'Puerto Aysén'],
    ['12000000-0000-0000-0000-000000000043', IDS.regionMA, 'XII12PNA', 'Punta Arenas'],
    ['12000000-0000-0000-0000-000000000044', IDS.regionMA, 'XII12NAT', 'Puerto Natales'],
    ['12000000-0000-0000-0000-000000000045', IDS.regionML, 'V07TAL', 'Talca'],
    ['12000000-0000-0000-0000-000000000046', IDS.regionML, 'V07CUR2', 'Curicó'],
    ['12000000-0000-0000-0000-000000000047', IDS.regionML, 'V07LIN', 'Linares'],
    ['12000000-0000-0000-0000-000000000048', IDS.regionVS, 'V05VIN', 'Viña del Mar'],
    ['12000000-0000-0000-0000-000000000049', IDS.regionVS, 'V05QIL', 'Quilpué'],
    ['12000000-0000-0000-0000-000000000050', IDS.regionAN, 'II02TOC', 'Tocopilla'],
    ['12000000-0000-0000-0000-000000000051', IDS.regionBI, 'VIII08TAL', 'Talcahuano'],
    ['12000000-0000-0000-0000-000000000052', IDS.regionAR, 'IX09PUC', 'Pucón'],
    ['12000000-0000-0000-0000-000000000053', IDS.regionLL, 'X10ANC', 'Ancud'],
    ['12000000-0000-0000-0000-000000000054', IDS.regionAI, 'XI11CHC', 'Chile Chico'],
    ['12000000-0000-0000-0000-000000000055', IDS.regionCO, 'IV04ILL', 'Illapel'],
    ['12000000-0000-0000-0000-000000000056', IDS.regionAP, 'XVCAM', 'Camarones'],
    ['12000000-0000-0000-0000-000000000057', IDS.regionTA, 'I01POZ', 'Pozo Almonte'],
    ['12000000-0000-0000-0000-000000000058', IDS.regionAT, 'III03CAL', 'Caldera'],
    ['12000000-0000-0000-0000-000000000059', IDS.regionNB, 'XVI16QUI', 'Quirihue'],
    ['12000000-0000-0000-0000-000000000060', IDS.regionOH, 'V06SCZ', 'Santa Cruz'],
    ['12000000-0000-0000-0000-000000000061', IDS.regionML, 'V07CON', 'Constitución'],
    ['12000000-0000-0000-0000-000000000062', IDS.regionMA, 'XII12POR', 'Porvenir'],
  ]
  const comunas = comunaRows.map(([id, region_id, codigo, nombre]) => ({
    id,
    region_id,
    codigo,
    nombre,
    creado_en: dayOffset(-420),
    actualizado_en: dayOffset(-420),
  }))

  const comunaNombre = (id) => comunas.find((c) => c.id === id)?.nombre ?? '—'
  const regionNombre = (id) => regiones.find((r) => r.id === id)?.nombre ?? '—'

  /* ---------------- Categorías ---------------- */
  const catRows = [
    [IDS.catHortalizas, null, 'Hortalizas', 'hortalizas', false],
    [IDS.catFrutas, null, 'Frutas', 'frutas', false],
    [IDS.catTuberculos, null, 'Tubérculos', 'tuberculos', false],
    [IDS.catHierbas, null, 'Hierbas aromáticas', 'hierbas-aromaticas', false],
    [IDS.catConservas, null, 'Conservas', 'conservas', false],
    [IDS.catLacteos, null, 'Lácteos y huevos', 'lacteos-huevos', false],
    [IDS.catCarnes, null, 'Carnes y embutidos', 'carnes-embutidos', false],
    [IDS.catMiel, null, 'Miel y dulces', 'miel-dulces', false],
    [IDS.catGranos, null, 'Granos y semillas', 'granos-semillas', false],
    [IDS.catFrutosSecos, null, 'Frutos secos', 'frutos-secos', false],
    [IDS.catAceites, null, 'Aceites y condimentos', 'aceites-condimentos', false],
    [IDS.catBebidas, null, 'Bebidas', 'bebidas', false],
    [IDS.catFlores, null, 'Flores y plantas', 'flores-plantas', false],
    [IDS.catArtesanias, null, 'Artesanías', 'artesanias', false],
    [IDS.catMascotas, null, 'Alimentos para mascotas', 'alimentos-mascotas', false],
    [IDS.catHortalizasHoja, IDS.catHortalizas, 'Hojas verdes', 'hortalizas-hojas-verdes', false],
    [IDS.catHortalizasFruto, IDS.catHortalizas, 'Frutos de huerto', 'hortalizas-frutos-huerto', false],
    ['13000000-0000-0000-0000-000000000103', IDS.catHortalizas, 'Raíces y bulbos', 'hortalizas-raices-bulbos', false],
    ['13000000-0000-0000-0000-000000000201', IDS.catFrutas, 'Cítricos', 'frutas-citricos', false],
    [IDS.catFrutasUva, IDS.catFrutas, 'Uvas y berries', 'frutas-uvas-berries', false],
    ['13000000-0000-0000-0000-000000000203', IDS.catFrutas, 'Carozos', 'frutas-carozos', false],
    ['13000000-0000-0000-0000-000000000204', IDS.catFrutas, 'Pomáceas', 'frutas-pomaceas', false],
    ['13000000-0000-0000-0000-000000000205', IDS.catFrutas, 'Tropicales', 'frutas-tropicales', false],
    [IDS.catTuberculosPapa, IDS.catTuberculos, 'Papas', 'tuberculos-papas', false],
    ['13000000-0000-0000-0000-000000000302', IDS.catTuberculos, 'Camotes y otros', 'tuberculos-camotes', false],
    ['13000000-0000-0000-0000-000000000401', IDS.catHierbas, 'Aromáticas frescas', 'hierbas-aromaticas-frescas', false],
    ['13000000-0000-0000-0000-000000000402', IDS.catHierbas, 'Medicinales', 'hierbas-medicinales', false],
    ['13000000-0000-0000-0000-000000000501', IDS.catConservas, 'Mermeladas y dulces', 'conservas-mermeladas', false],
    ['13000000-0000-0000-0000-000000000502', IDS.catConservas, 'Encurtidos y fermentos', 'conservas-encurtidos', false],
    ['13000000-0000-0000-0000-000000000503', IDS.catConservas, 'Salsas y aderezos', 'conservas-salsas', false],
    ['13000000-0000-0000-0000-000000000601', IDS.catLacteos, 'Quesos', 'lacteos-quesos', false],
    ['13000000-0000-0000-0000-000000000602', IDS.catLacteos, 'Leche y yogur', 'lacteos-leche-yogur', false],
    ['13000000-0000-0000-0000-000000000603', IDS.catLacteos, 'Huevos', 'lacteos-huevos-frescos', false],
    ['13000000-0000-0000-0000-000000000701', IDS.catCarnes, 'Pollo y aves', 'carnes-pollo-aves', false],
    ['13000000-0000-0000-0000-000000000702', IDS.catCarnes, 'Cerdo', 'carnes-cerdo', false],
    ['13000000-0000-0000-0000-000000000703', IDS.catCarnes, 'Vacuno', 'carnes-vacuno', false],
    ['13000000-0000-0000-0000-000000000704', IDS.catCarnes, 'Embutidos', 'carnes-embutidos-artesanales', false],
    ['13000000-0000-0000-0000-000000000801', IDS.catMiel, 'Miel', 'miel', false],
    ['13000000-0000-0000-0000-000000000802', IDS.catMiel, 'Dulces y postres', 'miel-dulces-postres', false],
    ['13000000-0000-0000-0000-000000000901', IDS.catGranos, 'Legumbres', 'granos-legumbres', false],
    ['13000000-0000-0000-0000-000000000902', IDS.catGranos, 'Cereales', 'granos-cereales', false],
    ['13000000-0000-0000-0000-000000000903', IDS.catGranos, 'Semillas', 'granos-semillas-varias', false],
    ['13000000-0000-0000-0000-000000001001', IDS.catFrutosSecos, 'Nueces y frutos secos', 'frutos-secos-nueces', false],
    ['13000000-0000-0000-0000-000000001002', IDS.catFrutosSecos, 'Frutas deshidratadas', 'frutos-secos-deshidratadas', false],
    ['13000000-0000-0000-0000-000000001101', IDS.catAceites, 'Aceite de oliva', 'aceites-oliva', false],
    ['13000000-0000-0000-0000-000000001102', IDS.catAceites, 'Vinagres', 'aceites-vinagres', false],
    ['13000000-0000-0000-0000-000000001103', IDS.catAceites, 'Condimentos y especias', 'aceites-condimentos-especias', false],
    ['13000000-0000-0000-0000-000000001201', IDS.catBebidas, 'Jugos y aguas', 'bebidas-jugos-aguas', false],
    ['13000000-0000-0000-0000-000000001202', IDS.catBebidas, 'Vinos y licores', 'bebidas-vinos-licores', false],
    ['13000000-0000-0000-0000-000000001203', IDS.catBebidas, 'Infusiones', 'bebidas-infusiones', false],
    ['13000000-0000-0000-0000-000000001301', IDS.catFlores, 'Flores de corte', 'flores-corte', false],
    ['13000000-0000-0000-0000-000000001302', IDS.catFlores, 'Plantas y vivero', 'plantas-vivero', false],
    ['13000000-0000-0000-0000-000000001401', IDS.catArtesanias, 'Textiles', 'artesanias-textiles', false],
    ['13000000-0000-0000-0000-000000001402', IDS.catArtesanias, 'Madera y cerámica', 'artesanias-madera-ceramica', false],
    ['13000000-0000-0000-0000-000000001403', IDS.catArtesanias, 'Cosmética natural', 'artesanias-cosmetica-natural', false],
    ['13000000-0000-0000-0000-000000001501', IDS.catMascotas, 'Alimentos para mascotas', 'mascotas-alimentos', false],
    ['13000000-0000-0000-0000-000000001502', IDS.catMascotas, 'Snacks y premios', 'mascotas-snacks', false],
    [IDS.catSinCategoria, null, 'Sin Categoría', 'sin-categoria', true],
  ]
  const categorias = catRows.map(([id, categoria_padre_id, nombre, slug, es_sistema]) => ({
    id,
    categoria_padre_id,
    nombre,
    slug,
    es_sistema,
    eliminado_en: null,
    creado_en: dayOffset(-400),
    actualizado_en: dayOffset(-400),
  }))

  /* ---------------- Perfiles ---------------- */
  const perfilRows = [
    [IDS.adminBase, 'Administrador', 'Base', 'admin', '+56900000001', 'Av. Providencia 100, Santiago', '12000000-0000-0000-0000-000000000005', 'cutuco.admin.base@example.test', true, true],
    [IDS.clienteDemo, 'Camila', 'Soto', 'cliente', '+56900000002', 'Calle Compañía 200, Santiago', '12000000-0000-0000-0000-000000000004', 'cutuco.cliente.santiago@example.test', false, false],
    [IDS.adminSec, 'Patricia', 'Muñoz', 'admin', '+56900000003', 'Av. Apoquindo 4500, Las Condes', '12000000-0000-0000-0000-000000000005', 'cutuco.admin.operaciones@example.test', false, false],
    [IDS.cliente2, 'Jorge', 'Pérez', 'cliente', '+56900000004', 'Los Militares 3300, Las Condes', '12000000-0000-0000-0000-000000000005', 'jorge.perez@example.test', false, false],
    [IDS.vendedor1, 'Ana', 'González', 'vendedor', '+56900000101', 'Parcela Los Aromas s/n, Paine', '12000000-0000-0000-0000-000000000001', 'productor.paine@example.test', false, false],
    [IDS.vendedor2, 'Luis', 'Rodríguez', 'vendedor', '+56900000102', 'Camino El Alba 8800, Melipilla', '12000000-0000-0000-0000-000000000006', 'productor.melipilla@example.test', false, false],
    [IDS.vendedor3, 'María', 'Fernández', 'vendedor', '+56900000103', 'Parcela Los Litros, Quillota', '12000000-0000-0000-0000-000000000007', 'productor.quillota@example.test', false, false],
    [IDS.vendedor4, 'Pedro', 'Bustos', 'vendedor', '+56900000104', 'Fundo El Encanto, Providencia', '12000000-0000-0000-0000-000000000005', 'productor.pausado@example.test', false, false],
    [IDS.vendedor5, 'Rosa', 'Vera', 'vendedor', '+56900000105', 'Parcela San Luis, Buin', '12000000-0000-0000-0000-000000000002', 'productor.buin@example.test', false, false],
    [IDS.vendedor6, 'Héctor', 'Molina', 'vendedor', '+56900000106', 'Parcela San Pedro, Tenca', '12000000-0000-0000-0000-000000000011', 'productor.tenca@example.test', false, false],
    [IDS.vendedor7, 'Sofía', 'Castillo', 'vendedor', '+56900000107', 'Camino Lo Errázuriz 1200, Pirque', '12000000-0000-0000-0000-000000000013', 'productor.pirque@example.test', false, false],
    [IDS.vendedorPend1, 'Jorge', 'Alarcón', 'cliente', '+56900000108', 'Calle San Martín 880, San Bernardo', '12000000-0000-0000-0000-000000000003', 'postulante.sanbernardo@example.test', false, false],
    [IDS.vendedorPend2, 'Claudia', 'Reyes', 'cliente', '+56900000109', 'Av. Principal 45, Limache', '12000000-0000-0000-0000-000000000014', 'postulante.limache@example.test', false, false],
    [IDS.vendedorPend3, 'Andrés', 'Figueroa', 'cliente', '+56900000110', 'Camino Interior 1200, Curicó', '12000000-0000-0000-0000-000000000004', 'postulante.curico@example.test', false, false],
    [IDS.vendedorPend4, 'Marisol', 'Carrasco', 'cliente', '+56900000111', 'Ruta 5 Sur km 168, San José de Maipo', '12000000-0000-0000-0000-000000000015', 'postulante.sanjosedemaipo@example.test', false, false],
    [IDS.vendedorPend5, 'Tomás', 'Lagos', 'cliente', '+56900000112', 'Camino Real 640, Calera de Tango', '12000000-0000-0000-0000-000000000016', 'postulante.caleradetango@example.test', false, false],
    [IDS.vendedorPend6, 'Verónica', 'Salazar', 'cliente', '+56900000113', 'Av. Constitución 330, Llay-Llay', '12000000-0000-0000-0000-000000000017', 'postulante.layllay@example.test', false, false],
    [IDS.vendedorPend7, 'Nicolás', 'Bravo', 'cliente', '+56900000114', 'Caminoegas 2100, Rancagua', '12000000-0000-0000-0000-000000000018', 'postulante.rancagua@example.test', false, false],
    [IDS.cliente3, 'Fernanda', 'Contreras', 'cliente', '+56900000201', 'Av. Apoquindo 7210, Las Condes', '12000000-0000-0000-0000-000000000005', 'compras.mayorista.centro@example.test', false, false],
    [IDS.cliente4, 'Sebastián', 'Paredes', 'cliente', '+56900000202', 'Av. San Martín 990, Maipú', '12000000-0000-0000-0000-000000000004', 'compras.feria.poniente@example.test', false, false],
    [IDS.cliente5, 'Camila', 'Araya', 'cliente', '+56900000203', 'Calle Los Robles 45, Viña del Mar', '12000000-0000-0000-0000-000000000014', 'compras.hotel.valparaiso@example.test', false, false],
    [IDS.cliente6, 'Rodrigo', 'Fuentes', 'cliente', '+56900000204', 'Av. España 15, Tenca', '12000000-0000-0000-0000-000000000011', 'abastos.tenca@example.test', false, false],
    [IDS.cliente7, 'María José', 'Ríos', 'cliente', '+56900000205', 'Av. Central 880, Curepto', '12000000-0000-0000-0000-000000000012', 'mayorista.centro.sur@example.test', false, false],
    [IDS.cliente8, 'Felipe', 'Navarro', 'cliente', '+56900000206', 'Los Carrera 700, Rancagua', '12000000-0000-0000-0000-000000000010', 'retail.ohiggins@example.test', false, false],
  ]

  const perfiles = perfilRows.map(([id, nombre, apellido, rol, telefono, direccion_principal, comuna_principal_id, email, es_super_admin, es_protegido], i) => ({
    id,
    nombre,
    apellido,
    telefono,
    direccion_principal,
    comuna_principal_id,
    intentos_login_fallidos: 0,
    bloqueado_hasta: null,
    es_super_admin,
    es_protegido,
    ultimo_acceso_en: dayOffset(-1 - i),
    creado_en: dayOffset(-300 + i),
    actualizado_en: dayOffset(-30 + i),
    rol,
    email,
    user_metadata: { nombre, apellido, rol, email },
  }))

  /* ---------------- Productores ---------------- */
  const productorRows = [
    [IDS.productor1, IDS.vendedor1, 'Huerta Los Aromas', 'Huerta familiar de 1,2 hectáreas especializada en hortalizas de hoja. Certificación INDAP vigente y entrega dentro de Paine, Buin y San Bernardo.', '12000000-0000-0000-0000-000000000001', true, 4.8, 24],
    [IDS.productor2, IDS.vendedor2, 'Valle de Melipilla', 'Producción de tomate y papa en suelo arenoso, con cobertura de toda la Región Metropolitana.', '12000000-0000-0000-0000-000000000006', true, 4.62, 41],
    [IDS.productor3, IDS.vendedor3, 'Quillota del Sol', 'Agricultura familiar de la zona central, especializada en frutas de temporada y hortalizas.', '12000000-0000-0000-0000-000000000007', true, 4.91, 63],
    [IDS.productor4, IDS.vendedor4, 'Fundo El Encanto', 'Productor suspendido por incumplimiento reiterado de plazos de entrega.', '12000000-0000-0000-0000-000000000005', false, 3.1, 12],
    [IDS.productor5, IDS.vendedor5, 'Cosecha del Día Buin', 'Cosechamos cada mañana y despachamos el mismo día. Especializado en verduras de hoja y conservas.', '12000000-0000-0000-0000-000000000002', true, 4.75, 38],
    [IDS.productor6, IDS.vendedor6, 'Tenca Orgánico', 'Producción orgánica en el Maule: frutas, lácteos y conservas de la cosecha familiar.', '12000000-0000-0000-0000-000000000011', true, 4.68, 29],
    [IDS.productor7, IDS.vendedor7, 'Pirque Biodiverso', 'Huerta diversificada en la cordillera de Pirque, con importante presencia de conservas artesanales.', '12000000-0000-0000-0000-000000000013', true, 4.4, 9],
  ]

  const productores = productorRows.map(
    ([id, perfil_id, nombre_comercial, descripcion, comuna_origen_id, activo, puntaje_reputacion, cantidad_evaluaciones], i) => ({
      id,
      perfil_id,
      nombre_comercial,
      descripcion,
      comuna_origen_id,
      activo,
      aprobado_en: dayOffset(-260 + i * 7),
      puntaje_reputacion,
      cantidad_evaluaciones,
      creado_en: dayOffset(-260 + i * 7),
      actualizado_en: dayOffset(-12 + i),
    }),
  )

  /* ---------------- Coberturas ---------------- */
  const coberturaRows = [
    [IDS.productor1, TIPO_COBERTURA.COMUNA, '12000000-0000-0000-0000-000000000001'],
    [IDS.productor1, TIPO_COBERTURA.COMUNA, '12000000-0000-0000-0000-000000000002'],
    [IDS.productor1, TIPO_COBERTURA.COMUNA, '12000000-0000-0000-0000-000000000003'],
    [IDS.productor2, TIPO_COBERTURA.REGION, IDS.regionRM],
    [IDS.productor3, TIPO_COBERTURA.REGION, IDS.regionVS],
    [IDS.productor4, TIPO_COBERTURA.REGION, IDS.regionRM],
    [IDS.productor5, TIPO_COBERTURA.REGION, IDS.regionRM],
    [IDS.productor6, TIPO_COBERTURA.REGION, IDS.regionML],
    [IDS.productor7, TIPO_COBERTURA.COMUNA, '12000000-0000-0000-0000-000000000013'],
    [IDS.productor7, TIPO_COBERTURA.REGION, IDS.regionRM],
  ]
  const coberturas_productor = coberturaRows.map(([productor_id, tipo_cobertura, destino], i) => ({
    id: nextId(),
    productor_id,
    region_id: tipo_cobertura === TIPO_COBERTURA.REGION ? destino : null,
    comuna_id: tipo_cobertura === TIPO_COBERTURA.COMUNA ? destino : null,
    activo: true,
    creado_en: dayOffset(-250 + i),
    actualizado_en: dayOffset(-250 + i),
    tipo_cobertura,
  }))

  /* ---------------- Postulaciones de vendedores ---------------- */
  const postulaciones_vendedores = [
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend1,
      nombre_comercial_solicitado: 'Huerta San Bernardo',
      descripcion: 'Huerta familiar en Av. Los Robles 2400. Vendo hortalizas de hoja y frutas de huerto.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000003',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-6),
      actualizado_en: dayOffset(-6),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend2,
      nombre_comercial_solicitado: 'Limache Orgánico',
      descripcion: 'Productora con certificación orgánica en proceso.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000014',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-3),
      actualizado_en: dayOffset(-3),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend3,
      nombre_comercial_solicitado: 'Agrícola Don Carlos',
      descripcion: 'Familiar dedicada a frutales de carozo en el Maule, con cámara de frío propia.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000004',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-5),
      actualizado_en: dayOffset(-5),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend4,
      nombre_comercial_solicitado: 'Huerto Las Vertientes',
      descripcion: 'Hortalizas de estación y frutas de huerto en San José de Maipo.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000015',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-8),
      actualizado_en: dayOffset(-8),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend5,
      nombre_comercial_solicitado: 'Viña ymesa del Sur',
      descripcion: 'Uvas de mesa y Reds para la región de O’Higgins.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000016',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-11),
      actualizado_en: dayOffset(-11),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend6,
      nombre_comercial_solicitado: 'Cítricos Llay-Llay',
      descripcion: 'Naranjos y limones para el mercado interno yacional.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000017',
      observaciones_admin: 'Documentación incompleta: falta certificado dereuse de Predio.',
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-14),
      actualizado_en: dayOffset(-14),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedorPend7,
      nombre_comercial_solicitado: 'Productores Unidos Limarí',
      descripcion: 'Cooperativa de hortalizas del Itata para venta a mayoristas.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000018',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      creado_en: dayOffset(-17),
      actualizado_en: dayOffset(-17),
      estado: ESTADO_POSTULACION.EN_REVISION,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedor6,
      nombre_comercial_solicitado: 'Tenca Orgánico',
      descripcion: 'Producción orgánica en el Maule.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000011',
      observaciones_admin: 'Documentación revisada y verificada en terreno.',
      revisado_por: IDS.adminSec,
      revisado_en: dayOffset(-120),
      creado_en: dayOffset(-128),
      actualizado_en: dayOffset(-120),
      estado: ESTADO_POSTULACION.APROBADA,
    },
    {
      id: nextId(),
      perfil_id: IDS.vendedor7,
      nombre_comercial_solicitado: 'Pirque Biodiverso',
      descripcion: 'Huerta diversificada de montaña.',
      comuna_origen_id: '12000000-0000-0000-0000-000000000013',
      observaciones_admin: 'Antecedentes incompletos: sin certificación ni documentos de predio.',
      revisado_por: IDS.adminSec,
      revisado_en: dayOffset(-40),
      creado_en: dayOffset(-48),
      actualizado_en: dayOffset(-40),
      estado: ESTADO_POSTULACION.RECHAZADA,
    },
  ]

  const documentos_identidad = postulaciones_vendedores.flatMap((p) =>
    ['frente', 'dorso'].map((tipo, i) => {
      const nombre = perfiles.find((x) => x.id === p.perfil_id)?.nombre ?? ''
      const ruta = `identidad-vendedores/${p.id}/${tipo}.svg`
      const url = documentPlaceholder(tipo, nombre)
      put('identidad-vendedores', ruta, url)
      return {
        id: nextId(),
        postulacion_id: p.id,
        ruta_storage: ruta,
        nombre_archivo: `${tipo}.svg`,
        mime_type: 'image/svg+xml',
        tamano_bytes: Math.round(url.length * 0.75),
        metadatos: { origen: 'carga_postulacion' },
        subido_en: p.creado_en,
        expira_en: dayOffset(REGLAS.MODERATION.expiracionDiasDocumento, 12),
        eliminado_en: null,
        tipo,
        postulacion_ref: i,
      }
    }),
  )

  /* ---------------- Catálogo ---------------- */
  // [nombre, productor, categoria, precio, stock, umbral, unidad, cosechaDiasAtras, descripcion]
  const productoRows = [
    ['Tomates Roma de Paine', IDS.productor1, IDS.catHortalizasFruto, 2800, 48, 5, 'kg', 0, 'Tomates Roma de cultivar, cosechados a mano en la madrugada y embalados en canastillas de 5 kg.'],
    ['Lechugas Hidropónicas de Paine', IDS.productor1, IDS.catHortalizasHoja, 1200, 3, 5, 'unidad', 0, 'Lechuga hidropónica de sistema NFT, fresca y crocante, lista para consumo.'],
    ['Papas Nuevas de Paine', IDS.productor1, IDS.catTuberculosPapa, 1600, 22, 5, 'kg', 0, 'Papas nuevas de la cosecha, lavadas y clasificadas.'],
    ['Miel Multifloral de Paine', IDS.productor1, IDS.catConservas, 8500, 26, 5, 'unidad', -12, 'Miel artesanal multifloral de 500 g, sin refinamiento, en frasco de vidrio.'],

    ['Tomates de Melipilla', IDS.productor2, IDS.catHortalizasFruto, 2900, 62, 5, 'kg', 0, 'Tomates de suelo arenoso, sabor dulce y firme para transporte.'],
    ['Lechugas Hidropónicas de Melipilla', IDS.productor2, IDS.catHortalizasHoja, 1250, 4, 5, 'unidad', 0, 'Lechuga costilla de color intenso, lavado y envasado individual.'],
    ['Papas Nuevas de Melipilla', IDS.productor2, IDS.catTuberculosPapa, 1650, 30, 5, 'kg', 0, 'Papas de la última cosecha, calibre uniforme.'],
    ['Miel Multifloral de Melipilla', IDS.productor2, IDS.catConservas, 8700, 18, 5, 'unidad', -12, 'Miel de invierno con polinización de primavera, 500 g.'],

    ['Tomates de Quillota', IDS.productor3, IDS.catHortalizasFruto, 3000, 74, 5, 'kg', 1, 'Tomates de la zona central, cosecha de selección media carrera.'],
    ['Lechugas Hidropónicas de Quillota', IDS.productor3, IDS.catHortalizasHoja, 1300, 5, 5, 'unidad', 0, 'Lechuga romana de cabeza compacta, ideal para salteados.'],
    ['Papas Nuevas de Quillota', IDS.productor3, IDS.catTuberculosPapa, 1700, 40, 5, 'kg', 0, 'Papas cocineras, buena para horno y puré.'],
    ['Miel Multifloral de Quillota', IDS.productor3, IDS.catConservas, 8900, 22, 5, 'unidad', -12, 'Miel artesanal de la zona central.'],

    ['Tomates del Productor Pausado', IDS.productor4, IDS.catHortalizasFruto, 2750, 30, 5, 'kg', -3, 'Producto de un productor actualmente sancionado (visible solo en administración).'],
    ['Lechugas del Productor Pausado', IDS.productor4, IDS.catHortalizasHoja, 1150, 2, 5, 'unidad', -3, 'Producto en stock crítico de productor sancionado.'],
    ['Papas Nuevas del Productor Pausado', IDS.productor4, IDS.catTuberculosPapa, 1550, 18, 5, 'kg', 0, 'Papas de productor sancionado.'],
    ['Miel del Productor Pausado', IDS.productor4, IDS.catConservas, 8200, 12, 5, 'unidad', -12, 'Miel de productor sancionado.'],

    ['Tomates Cosecha del Día', IDS.productor5, IDS.catHortalizasFruto, 3100, 55, 5, 'kg', 0, 'Cosechado esta mañana, disponible el mismo día en toda la Región Metropolitana.'],
    ['Lechugas del Día', IDS.productor5, IDS.catHortalizasHoja, 1350, 3, 5, 'unidad', 0, 'Hoja verde de cosecha inmediata, stock muy bajo.'],
    ['Papas Cosecha del Día', IDS.productor5, IDS.catTuberculosPapa, 1750, 26, 5, 'kg', 0, 'Cosecha del día, se despacha en menos de 6 horas.'],
    ['Miel Multifloral Cosecha del Día', IDS.productor5, IDS.catConservas, 9000, 20, 5, 'unidad', -12, 'Miel de la temporada, frasco de 500 g.'],

    ['Uvas Thomson Seedless', IDS.productor6, IDS.catFrutasUva, 4900, 32, 5, 'kg', 1, 'Uvas sin semilla de Miaño, racimos seleccionados y enfriados en campo.'],
    ['Naranjas Navel', IDS.productor6, IDS.catFrutasCitrinos, 2400, 88, 5, 'kg', 2, 'Naranjas jugosas de Socompa, calibre export.'],
    ['Queso Fresco de Tenca', IDS.productor6, IDS.catLacteos, 6900, 14, 5, 'unidad', 1, 'Queso fresco de leche cruda, 500 g, de elaboración diaria.'],
    ['Almendras Duchesel', IDS.productor6, IDS.catConservas, 8900, 9, 5, 'kg', -5, 'Almendras selectas en vaina, secadas al natural.'],

    ['Berries Mixto', IDS.productor7, IDS.catFrutasUva, 6900, 20, 5, 'bandeja', 0, 'Mezcla de frutilla, arándano y frambuesa de altura.'],
    ['Acelga Lombarda', IDS.productor7, IDS.catHortalizasHoja, 1500, 16, 5, 'unidad', 0, 'Acelga de penca gruesa, de intenso color verde oscuro.'],
    ['Zanahorias de Montaña', IDS.productor7, IDS.catHortalizasFruto, 1900, 28, 5, 'kg', 1, 'Zanahoria de suelo profundo, lavada a mano.'],
    ['Mermelada de Frambuesa', IDS.productor7, IDS.catConservas, 5600, 7, 5, 'unidad', -8, 'Mermelada artesanal de frutilla y frambuesa, frasco 300 g.'],
  ]

  const productos = productoRows.map(([nombre, productor_id, categoria_id, precio, stock, umbral_bajo, unidad_medida, cosecha, descripcion], i) => {
    const fecha_cosecha = cosecha === 0 ? dateOnly(0) : dateOnly(cosecha)
    return {
      id: `30000000-0000-0000-0000-${String(100 + i).padStart(12, '0')}`,
      productor_id,
      categoria_id,
      nombre,
      descripcion,
      precio,
      stock,
      umbral_bajo,
      fecha_cosecha,
      es_cosecha_mismo_dia: cosecha === 0,
      activo: true,
      eliminado_en: null,
      creado_en: dayOffset(-120 + i),
      actualizado_en: dayOffset(-2 - (i % 9)),
      unidad_medida,
    }
  })

  /* ---------------- Imágenes ---------------- */
  const imagenes_productos = []
  productos.forEach((p, i) => {
    const count = i % 4 === 0 ? 3 : i % 3 === 0 ? 2 : 1
    for (let k = 0; k < count; k += 1) {
      const nombre = `${p.nombre.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 28)}-${k + 1}.svg`
      const ruta = `product-images/${p.id}/${nombre}`
      const url = placeholderImage(`${p.id}-${k}`, count > 1 ? `${p.nombre} ${k + 1}` : p.nombre)
      put('product-images', ruta, url)
      imagenes_productos.push({
        id: nextId(),
        producto_id: p.id,
        ruta_storage: ruta,
        nombre_archivo: nombre,
        mime_type: 'image/svg+xml',
        tamano_bytes: Math.round(url.length * 0.75),
        texto_alternativo: p.nombre,
        posicion: k + 1,
        es_principal: k === 0,
        metadatos: {},
        creado_en: p.creado_en,
        actualizado_en: p.creado_en,
      })
    }
  })

  /* ---------------- Historial de precios ---------------- */
  const historial_precios = []
  productos.forEach((p, i) => {
    const region = (
      [
        IDS.regionRM,
        IDS.regionVS,
        IDS.regionML,
        IDS.regionOH,
        IDS.regionRM,
      ][i % 5]
    )
    const pasos = 3 + (i % 3)
    let precio = round2(p.precio * (0.82 + ((i % 4) * 0.05)))
    historial_precios.push({
      id: nextId(),
      producto_id: p.id,
      region_id: region,
      precio_anterior: null,
      precio_nuevo: precio,
      referencia_externa: null,
      registrado_en: dayOffset(-90 - i),
      fuente: 'marketplace',
    })
    for (let k = 1; k < pasos; k += 1) {
      const variacion = 0.9 + (((i + k) % 5) * 0.045)
      const nuevo = round2(precio * variacion)
      historial_precios.push({
        id: nextId(),
        producto_id: p.id,
        region_id: region,
        precio_anterior: precio,
        precio_nuevo: nuevo,
        referencia_externa: null,
        registrado_en: dayOffset(-90 + k * 21 - i),
        fuente: 'marketplace',
      })
      precio = nuevo
    }
    // Referencia externa de mercado (feria libres / retail)
    historial_precios.push({
      id: nextId(),
      producto_id: p.id,
      region_id: region,
      precio_anterior: null,
      precio_nuevo: round2(p.precio * 1.18),
      referencia_externa: 'Feria Libre de barrio / retail (referencia AFC)',
      registrado_en: dayOffset(-7 - (i % 5)),
      fuente: 'referencia',
    })
  })

  /* ---------------- Alertas de stock ---------------- */
  const alertas_stock = productos
    .filter((p) => Number(p.stock) <= Number(p.umbral_bajo))
    .map((p, i) => ({
      id: nextId(),
      producto_id: p.id,
      stock_actual: p.stock,
      umbral_configurado: p.umbral_bajo,
      generada_en: dayOffset(-1 - i, 8),
      atendida_en: i === 0 ? dayOffset(0, 9) : null,
    }))

  /* ---------------- Sanciones y apelaciones ---------------- */
  const sanciones = [
    {
      id: 'a1000000-0000-0000-0000-000000000004',
      productor_id: IDS.productor4,
      motivo:
        'Amonestación automática: puntaje acumulado 3.10 por entregas fuera de plazo reiteradas (4 de 12 pedidos).',
      puntaje_disparador: 3.1,
      automatica: true,
      impuesta_por: null,
      inicio_en: dayOffset(-30),
      fin_en: null,
      resuelta_en: null,
      creado_en: dayOffset(-30),
      actualizado_en: dayOffset(-30),
      accion: 'pausar_productor',
      estado: ESTADO_SANCION.ACTIVA,
      tipo: 'amonestacion',
    },
    {
      id: nextId(),
      productor_id: IDS.productor7,
      motivo: 'Calidad inferior a lo declarado en dos lotes de verduras de hoja.',
      puntaje_disparador: 4.4,
      automatica: false,
      impuesta_por: IDS.adminSec,
      inicio_en: dayOffset(-20),
      fin_en: dayOffset(10),
      resuelta_en: null,
      creado_en: dayOffset(-20),
      actualizado_en: dayOffset(-20),
      accion: 'pausar_productor',
      estado: ESTADO_SANCION.ACTIVA,
      tipo: 'amonestacion',
    },
    {
      id: nextId(),
      productor_id: IDS.productor2,
      motivo: 'Respuesta tardía a un reclamo de calidad (amonestación resuelta).',
      puntaje_disparador: 4.62,
      automatica: false,
      impuesta_por: IDS.adminSec,
      inicio_en: dayOffset(-60),
      fin_en: dayOffset(-45),
      resuelta_en: dayOffset(-46),
      creado_en: dayOffset(-60),
      actualizado_en: dayOffset(-46),
      accion: 'ninguna',
      estado: ESTADO_SANCION.RESUELTA,
      tipo: 'amonestacion',
    },
  ]

  const apelaciones = [
    {
      id: nextId(),
      sancion_id: sanciones[1].id,
      productor_id: IDS.productor7,
      solicitante_id: IDS.vendedor7,
      fundamento:
        'El lote fue entregado con una diferencia menor de peso frente a lo informado; solicito reconsiderar la amonestación.',
      resolucion: null,
      resuelto_por: null,
      creado_en: dayOffset(-12),
      actualizado_en: dayOffset(-12),
      resuelto_en: null,
      estado: ESTADO_APELACION.PENDIENTE,
    },
    {
      id: nextId(),
      sancion_id: sanciones[2].id,
      productor_id: IDS.productor2,
      solicitante_id: IDS.vendedor2,
      fundamento: 'Ajustamos la ruta de reparto y respondimos el reclamo dentro del plazo.',
      resolucion: 'Apelación aprobada: se levanta la amonestación.',
      resuelto_por: IDS.adminSec,
      creado_en: dayOffset(-58),
      actualizado_en: dayOffset(-47),
      resuelto_en: dayOffset(-47),
      estado: ESTADO_APELACION.APROBADA,
    },
  ]

  /* ---------------- Pedidos, pagos, envíos, evidencias ---------------- */
  const clientes = [IDS.clienteDemo, IDS.cliente2]
  const pedidos = []
  const detalles_pedido = []
  const pagos = []
  const envios = []
  const evidencias_envio = []
  const evaluaciones_reputacion = []
  const reclamos = []

  const pedidoSpecs = [
    { estado: ESTADO_PEDIDO.CREADO, cliente: 0, productor: 1, dias: 0, delivery: REGLAS.TARIFAS.deliveryDefecto, items: [[0, 2], [1, 1]] },
    { estado: ESTADO_PEDIDO.EN_PREPARACION, cliente: 0, productor: 2, dias: -1, items: [[4, 3]] },
    { estado: ESTADO_PEDIDO.EN_PREPARACION, cliente: 1, productor: 5, dias: -1, items: [[20, 1], [21, 2]] },
    { estado: ESTADO_PEDIDO.COMPLETADO, cliente: 0, productor: 5, dias: -3, entregado: true, ev: true, items: [[16, 2]] },
    { estado: ESTADO_PEDIDO.COMPLETADO, cliente: 1, productor: 3, dias: -4, entregado: true, ev: true, evaluada: true, items: [[8, 3], [10, 1]] },
    { estado: ESTADO_PEDIDO.COMPLETADO, cliente: 0, productor: 3, dias: -5, entregado: true, ev: true, evaluada: true, items: [[9, 4]] },
    { estado: ESTADO_PEDIDO.COMPLETADO, cliente: 1, productor: 7, dias: -6, entregado: true, ev: true, items: [[24, 2]] },
    { estado: ESTADO_PEDIDO.COMPLETADO, cliente: 0, productor: 6, dias: -8, entregado: true, ev: true, items: [[22, 1]] },
    { estado: ESTADO_PEDIDO.RECLAMADO, cliente: 0, productor: 2, dias: -9, entregado: true, ev: true, reclamo: true, items: [[5, 2], [6, 1]] },
    { estado: ESTADO_PEDIDO.RECLAMADO, cliente: 1, productor: 7, dias: -12, entregado: true, ev: true, reclamo: true, items: [[26, 3]] },
    { estado: ESTADO_PEDIDO.CANCELADO, cliente: 1, productor: 4, dias: -15, items: [[12, 1]] },
    { estado: ESTADO_PEDIDO.PAGADO, cliente: 0, productor: 5, dias: -2, items: [[17, 1], [18, 2]] },
  ]

  pedidoSpecs.forEach((spec, idx) => {
    // `spec.productor` es un índice 1-based sobre el arreglo de productores del demo.
    const productor = productores[spec.productor - 1]
    if (!productor) throw new Error(`El productor ${spec.productor} no existe en el dataset demo`)
    const clienteId = clientes[spec.cliente]
    const cliente = perfiles.find((p) => p.id === clienteId)
    const items = spec.items.map(([productoIdx, cantidad]) => {
      const prod = productos[productoIdx]
      return { producto: prod, cantidad }
    })
    const subtotal = round2(items.reduce((acc, it) => acc + Number(it.producto.precio) * it.cantidad, 0))
    const delivery = spec.delivery ?? REGLAS.TARIFAS.deliveryDefecto
    const fee = round2(subtotal * REGLAS.TARIFAS.feePlataforma)
    const total = round2(subtotal + delivery)
    const creado = dayOffset(spec.dias, 9)
    const id = `40000000-0000-0000-0000-${String(100 + idx).padStart(12, '0')}`

    const esPagoActivo = [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION, ESTADO_PEDIDO.COMPLETADO, ESTADO_PEDIDO.RECLAMADO].includes(spec.estado)
    const entregado = Boolean(spec.entregado)

    const pedido = {
      id,
      codigo_pedido: `CTC-${dateOnly(spec.dias).slice(2).replace(/-/g, '')}-${1000 + idx}`,
      cliente_id: clienteId,
      productor_id: spec.productor,
      region_entrega_id: cliente.comuna_principal_id
        ? (comunas.find((c) => c.id === cliente.comuna_principal_id)?.region_id ?? IDS.regionRM)
        : IDS.regionRM,
      comuna_entrega_id: cliente.comuna_principal_id,
      nombre_destinatario: `${cliente.nombre} ${cliente.apellido ?? ''}`.trim(),
      telefono_destinatario: cliente.telefono,
      direccion_entrega: cliente.direccion_principal,
      referencia_entrega: 'Portón verde, timbre 3. Entregar en horario de mañana.',
      subtotal_productos: subtotal,
      porcentaje_fee_plataforma: REGLAS.TARIFAS.feePlataforma,
      monto_fee_plataforma: fee,
      total,
      monto_retenido: esPagoActivo ? total : 0,
      monto_liquidar_productor: round2(total - fee),
      confirmado_cliente_en: entregado ? dayOffset(spec.dias + 1, 12) : null,
      liberable_desde_en: entregado ? dayOffset(spec.dias + 1, 12) : null,
      inventario_repuesto_en: spec.estado === ESTADO_PEDIDO.CANCELADO ? dayOffset(spec.dias, 11) : null,
      cancelado_en: spec.estado === ESTADO_PEDIDO.CANCELADO ? dayOffset(spec.dias, 11) : null,
      creado_en: creado,
      actualizado_en: dayOffset(spec.dias, 9),
      estado: spec.estado,
    }

    items.forEach((it) => {
      detalles_pedido.push({
        id: nextId(),
        pedido_id: id,
        producto_id: it.producto.id,
        producto_nombre: it.producto.nombre,
        precio_unitario: it.producto.precio,
        cantidad: it.cantidad,
        subtotal: round2(Number(it.producto.precio) * it.cantidad),
        creado_en: creado,
        actualizado_en: creado,
      })
    })

    if (esPagoActivo) {
      const liberado = entregado && !spec.reclamo
      const pago = {
        id: nextId(),
        pedido_id: id,
        buy_order: `BO-${id.slice(0, 8).toUpperCase()}-${idx}`,
        token_ws: `e6d1b3a2-4c7f-4b19-9f02-${String(1000 + idx)}`,
        monto: total,
        codigo_autorizacion: String(100000 + idx * 137),
        codigo_respuesta: '0',
        respuesta_webpay: { status: 'AUTHORIZED', buy_order: `BO-${id.slice(0, 8).toUpperCase()}-${idx}` },
        creado_en: dayOffset(spec.dias, 9),
        autorizado_en: dayOffset(spec.dias, 9),
        retenido_en: dayOffset(spec.dias, 9),
        liberado_en: liberado ? dayOffset(spec.dias + 1, 12) : null,
        reembolsado_en: null,
        estado: liberado ? ESTADO_PAGO.LIBERADO : ESTADO_PAGO.RETENIDO,
      }
      pagos.push(pago)
      pedido.monto_retenido = liberado ? 0 : total

      if ([ESTADO_PEDIDO.EN_PREPARACION, ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.COMPLETADO, ESTADO_PEDIDO.RECLAMADO].includes(spec.estado)) {
        const envio = {
          id: nextId(),
          pedido_id: id,
          repartidor_id: productor.perfil_id,
          tarifa_fija: delivery,
          despachado_en: dayOffset(spec.dias, 14),
          entregado_en: entregado ? dayOffset(spec.dias, 18) : null,
          fallido_en: null,
          motivo_fallo: null,
          creado_en: dayOffset(spec.dias, 9),
          actualizado_en: dayOffset(spec.dias, 18),
          estado: entregado ? ESTADO_ENVIO.ENTREGADO : ESTADO_ENVIO.PREPARACION,
        }
        envios.push(envio)

        if (spec.ev) {
          ;['armado', 'entregado'].forEach((tipo) => {
            const ruta = `evidencia-envio/${envio.id}/${tipo}.svg`
            const url = escenaImage(tipo, `${envio.id}-${tipo}`)
            put('evidencia-envio', ruta, url)
            evidencias_envio.push({
              id: nextId(),
              envio_id: envio.id,
              ruta_storage: ruta,
              nombre_archivo: `${tipo}.svg`,
              mime_type: 'image/svg+xml',
              tamano_bytes: Math.round(url.length * 0.75),
              metadatos: {},
              cargado_por: productor.perfil_id,
              cargado_en: dayOffset(spec.dias, 17),
              tipo,
            })
          })
        }
      }
    }

    if (spec.evaluada) {
      evaluaciones_reputacion.push({
        id: nextId(),
        pedido_id: id,
        productor_id: spec.productor,
        cliente_id: clienteId,
        entrega_a_tiempo: 1,
        calidad: idx % 2 === 0 ? 5 : 4,
        respuesta_reclamos: 5,
        comentario: 'Producto fresco y bien embalado. Entrega puntual.',
        creado_en: dayOffset(spec.dias + 2, 19),
        actualizado_en: dayOffset(spec.dias + 2, 19),
        puntaje_resultante: 5,
      })
    }

    if (spec.reclamo) {
      reclamos.push({
        id: nextId(),
        pedido_id: id,
        cliente_id: clienteId,
        motivo: idx === 8 ? 'Producto en mal estado' : 'Cantidad incompleta',
        descripcion:
          'Al abrir el despacho, dos unidades del pedido no correspondían a lo facturado y una llegó golpeada. Solicito revisión del administrador.',
        respuesta_productor: idx === 8 ? 'Adjuntamos evidencia de armado; revisaremos el caso.' : null,
        resuelto_por: null,
        creado_en: dayOffset(spec.dias, 20),
        actualizado_en: dayOffset(spec.dias, 20),
        resuelto_en: null,
        estado: idx === 8 ? ESTADO_RECLAMO.EN_REVISION : ESTADO_RECLAMO.ABIERTO,
      })
    }

    pedidos.push(pedido)
  })

  /* ---------------- Configuración logística ---------------- */
  const configuracion_logistica = [
    {
      id: 1,
      tarifa_delivery_defecto: REGLAS.TARIFAS.deliveryDefecto,
      creado_en: dayOffset(-400),
      actualizado_en: dayOffset(-40),
    },
  ]
  const cuenta_transferencia_servicio = [
    {
      id: 1,
      banco: 'BancoEstado',
      tipo_cuenta: 'Cuenta corriente',
      numero_cuenta: '12345678',
      titular: 'CuTuCo SpA',
      rut: '76.543.210-8',
      creado_en: dayOffset(-400),
      actualizado_en: dayOffset(-40),
    },
  ]

  /* ---------------- Usuarios de autenticación ---------------- */
  const authUsers = perfiles.map((p) => ({
    id: p.id,
    email: p.email,
    password: 'CutucoTest!2026',
    created_at: p.creado_en,
    last_sign_in_at: p.ultimo_acceso_en,
    raw_user_meta_data: { nombre: p.nombre, apellido: p.apellido, rol: p.rol },
  }))

  return {
    // Tablas públicas
    regiones,
    comunas,
    categorias,
    perfiles,
    productores,
    coberturas_productor,
    postulaciones_vendedores,
    documentos_identidad,
    productos,
    imagenes_productos,
    historial_precios,
    alertas_stock,
    sanciones,
    apelaciones,
    pedidos,
    detalles_pedido,
    pagos,
    envios,
    evidencias_envio,
    evaluaciones_reputacion,
    reclamos,
    configuracion_logistica,
    cuenta_transferencia_servicio,
    // Tabla auxiliar de autenticación simulada
    authUsers,
    // Utilidades expuestas
    __meta: { storageObjects, comunaNombre, regionNombre },
  }
}

