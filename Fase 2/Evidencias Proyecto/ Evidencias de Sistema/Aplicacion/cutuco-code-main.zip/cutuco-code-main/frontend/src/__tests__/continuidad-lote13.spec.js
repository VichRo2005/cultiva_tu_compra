/**
 * CuTuCo — Lote 13 (Continuidad y desarrollo), lado frontend/documental.
 *
 * CK-0357: colas manuales con antigüedad (postulaciones/sanciones/pagos servicio
 * pendientes ordenados por fecha). CK-0353: manuales presentes y vigentes.
 * CK-0358: procedimiento de alerta con /health documentado. CK-0356: pagos
 * inciertos van a conciliación sin recobro automático (doc + servicio).
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const sdk = vi.hoisted(() => ({ from: vi.fn(), rpc: vi.fn() }))
vi.mock('@/lib/supabase', () => ({
  getClient: () => sdk,
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
}))

const src = (p) => readFileSync(`src/${p}`, 'utf8')
const doc = (p) => readFileSync(`../docs/${p}`, 'utf8')

function cadenaMock(resultado) {
  const consulta = {
    select: () => consulta,
    in: () => consulta,
    eq: () => consulta,
    gte: () => consulta,
    order: vi.fn(() => consulta),
    then: (resolve, reject) => Promise.resolve(resultado).then(resolve, reject),
  }
  return consulta
}

describe('CK-0357 · colas manuales identifican pendientes y antigüedad', () => {
  beforeEach(() => vi.resetAllMocks())

  it('getPendientesAdmin ordena postulaciones por creado_en ascendente (más antiguas primero)', async () => {
    const ordenes = []
    sdk.from.mockImplementation((tabla) => {
      const c = cadenaMock({ data: [], error: null })
      const orderOriginal = c.order.getMockImplementation()
      c.order = vi.fn((campo, opts) => {
        ordenes.push([tabla, campo, opts])
        return orderOriginal ? orderOriginal(campo, opts) : c
      })
      return c
    })
    const { getPendientesAdmin } = await import('@/services/admin')
    await getPendientesAdmin()
    const post = ordenes.find(([t]) => t === 'postulaciones_vendedores')
    expect(post[1]).toBe('creado_en')
    expect(post[2]).toEqual({ ascending: true }) // antigüedad primero
  })

  it('reclamos, apelaciones y pagos de servicio pendientes se listan por fecha', () => {
    expect(src('services/adminReclamos.js')).toMatch(/order\('creado_en'/)
    expect(src('services/adminApelaciones.js')).toMatch(/order\('creado_en'/)
    expect(src('services/payments.js')).toMatch(/order\('creado_en'/)
    const servicio = src('services/servicio.js')
    expect(servicio).toContain('listPagosServicioPendientes')
    expect(servicio).toMatch(/eq\('estado', ESTADO_SERVICIO\.PENDIENTE_REVISION\)/)
    expect(servicio).toMatch(/order\('periodo', \{ ascending: true \}\)/)
  })
})

describe('CK-0356 · pagos inciertos van a conciliación sin recobro automático', () => {
  it('el procedimiento documentado exige consultar el estado ante respuesta incierta', () => {
    const d = doc('servicio-plataforma.md')
    expect(d).toContain('respuesta incierta')
    expect(d).toMatch(/antes de permitir un nuevo cobro/)
    const backend = readFileSync('../backend/app/services/servicio_service.py', 'utf8')
    expect(backend).toContain('pendiente_revision')
    expect(backend).toMatch(/consultando estado/i)
  })
})

describe('CK-0353 · manuales coinciden con la versión vigente', () => {
  it('la guía de arranque documenta los comandos reales de prueba del repo', () => {
    const guia = doc('GUIA-ARRANQUE-Y-PRUEBAS.md')
    expect(guia).toMatch(/python\.exe -m pytest/)
    expect(guia).toMatch(/npx vitest run/)
    expect(guia).toContain('migraciones + semillas')
    expect(doc('gcp-migracion.md')).toMatch(/deploy-backend|Cloud Run/i)
    expect(doc('decisiones-resueltas.md')).toContain('DC-')
  })
})

describe('CK-0358 · procedimiento de alerta ante caída de componente', () => {
  it('existe /health en el backend y el runbook GCP documenta la verificación y responsable', () => {
    const main = readFileSync('../backend/app/main.py', 'utf8')
    expect(main).toContain('@app.get("/health")')
    const estado = doc('gcp-estado-2026-11-05.md')
    expect(estado).toContain('/health')
    expect(estado).toMatch(/200/)
  })
})
