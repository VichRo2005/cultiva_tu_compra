import { getClient } from '@/lib/supabase'
import { currentUserId } from '@/services/session'
import { adminResult as unwrap } from '@/services/adminErrores'
import { getPedidoDetalle } from '@/services/orders'
export { getPedidoDetalle }
export async function listReclamos({ estado = null } = {}) {
  const client = getClient()
  let query = client.from('reclamos').select('*')
  if (estado) query = query.eq('estado', estado)
  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) unwrap({ error })
  if (!data?.length) return []

  const pedidoIds = [...new Set(data.map((r) => r.pedido_id).filter(Boolean))]
  const pedidos = pedidoIds.length
    ? unwrap(await client.from('pedidos').select('*').in('id', pedidoIds))
    : []
  const map = new Map((pedidos ?? []).map((p) => [p.id, p]))
  return data.map((r) => ({ ...r, pedido: map.get(r.pedido_id) ?? null }))
}

export async function resolverReclamo(reclamoId, estado) {
  const adminId = await currentUserId()
  if (!['resuelto', 'rechazado'].includes(estado))
    throw new Error('Selecciona una resolución válida.')
  return unwrap(
    await getClient()
      .from('reclamos')
      .update({ estado, resuelto_por: adminId, resuelto_en: new Date().toISOString() })
      .eq('id', reclamoId)
      .in('estado', ['abierto', 'en_revision'])
      .select()
      .single(),
  )
}
