import { beforeEach, describe, expect, it, vi } from 'vitest'
import { consulta, admin } from './admin-test-utils'
const sdk = vi.hoisted(() => ({
  from: vi.fn(),
  rpc: vi.fn(),
  auth: { getSession: vi.fn(), getUser: vi.fn() },
}))
vi.mock('@/lib/supabase', () => ({ getClient: () => sdk, tryGetClient: () => sdk }))
beforeEach(() => vi.resetAllMocks())
import {
  validarSancion,
  crearSancion,
  resolverSancion,
  reactivarCuentaPermanente,
  filtrarSanciones,
} from '@/services/adminSanciones'
import { adminResult } from '@/services/adminErrores'
const base = {
  productorId: 'p',
  motivo: 'Motivo',
  tipo: 'suspension',
  accion: 'suspender',
  duracionDias: '10',
}
describe('Sanciones administrativas', () => {
  it.each(['', '0', '61', '1.5', '1e1', ' 2 ', '-1', 'NaN'])('rechaza duración %s', (valor) => {
    expect(() => validarSancion({ ...base, duracionDias: valor })).toThrow(
      'número entero entre 1 y 60',
    )
  })
  it.each(['1', '60', 12])('acepta duración %s', (valor) =>
    expect(() => validarSancion({ ...base, duracionDias: valor })).not.toThrow(),
  )
  it('rechaza amonestación con suspensión sin corregirla silenciosamente', () => {
    expect(() => validarSancion({ ...base, tipo: 'amonestacion' })).toThrow('no es coherente')
  })
  it('no crea un ban duplicado', async () => {
    admin(sdk)
    consulta(sdk, { data: [{ id: 'ban' }] })
    await expect(crearSancion({ ...base, accion: 'ban_permanente' })).rejects.toThrow(
      'ya tiene un ban',
    )
    expect(sdk.from).toHaveBeenCalledTimes(1)
  })
  it('inserta suspensión con duración entera y responsable autenticado', async () => {
    admin(sdk)
    const insert = consulta(sdk, { data: { id: 'nueva' } })
    await crearSancion(base)
    expect(insert.insert).toHaveBeenCalledWith(
      expect.objectContaining({ duracion_dias: 10, impuesta_por: 'admin', accion: 'suspender' }),
    )
  })
  it('no permite cancelar un ban', async () => {
    admin(sdk)
    consulta(sdk, { data: { accion: 'ban_permanente', estado: 'activa' } })
    await expect(resolverSancion('ban')).rejects.toThrow('Reactivar cuenta')
  })
  it('reactiva mediante una sola operación atómica', async () => {
    admin(sdk)
    sdk.rpc.mockResolvedValue({ data: { estado: 'resuelta' } })
    expect(await reactivarCuentaPermanente('ban')).toEqual({ estado: 'resuelta' })
    expect(sdk.rpc).toHaveBeenCalledWith('reactivar_cuenta_permanente', { p_sancion_id: 'ban' })
  })
  it('combina búsqueda y los tres enums', () => {
    const rows = [
      {
        id: '1',
        motivo: 'Texto largo',
        tipo: 'suspension',
        accion: 'suspender',
        estado: 'activa',
        perfil: { nombre: 'Ana' },
      },
      { id: '2', tipo: 'amonestacion', estado: 'activa', motivo: 'Ana' },
    ]
    expect(
      filtrarSanciones(rows, {
        texto: 'ana',
        tipo: 'suspension',
        accion: 'suspender',
        estado: 'activa',
      }).map((s) => s.id),
    ).toEqual(['1'])
  })
  it('traduce constraints y oculta detalles desconocidos', () => {
    expect(() =>
      adminResult({ error: { message: 'violates check constraint ck_sancion_accion_coherente' } }),
    ).toThrow('no es coherente')
    expect(() => adminResult({ error: { message: 'violates secret check constraint' } })).toThrow(
      'No se pudo completar',
    )
  })
})
