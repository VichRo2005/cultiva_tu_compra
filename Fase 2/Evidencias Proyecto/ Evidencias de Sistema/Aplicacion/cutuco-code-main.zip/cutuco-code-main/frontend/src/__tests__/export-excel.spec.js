/** CuTuCo - La exportación tabular debe entregar una planilla Excel útil. */
import * as XLSX from 'xlsx-js-style'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { exportExcel } from '@/lib/csv'

const blobOriginal = globalThis.Blob
let blobDescargado = null

afterEach(() => {
  globalThis.Blob = blobOriginal
  blobDescargado = null
  vi.restoreAllMocks()
})

describe('exportExcel', () => {
  it('genera una planilla .xlsx con título, filtro y montos numéricos', async () => {
    globalThis.Blob = class BlobCapturado {
      constructor(partes, opciones) {
        this.partes = partes
        this.type = opciones?.type
        blobDescargado = this
      }
    }
    vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:cutuco-prueba')
    vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => undefined)
    vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined)

    const ok = await exportExcel(
      [
        { pedido: 'CTC-001', total: '$3.500 CLP', fecha: '2026-11-25T12:00:00Z' },
        { pedido: 'CTC-002', total: '$7.000 CLP', fecha: '2026-11-26T12:00:00Z' },
      ],
      'cutuco-pedidos',
      [
        { key: 'pedido', label: 'Pedido' },
        { key: 'total', label: 'Monto total' },
        { key: 'fecha', label: 'Fecha' },
      ],
    )

    expect(ok).toBe(true)
    expect(blobDescargado?.type).toBe(
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )
    const libro = XLSX.read(blobDescargado.partes[0], { type: 'array' })
    const hoja = libro.Sheets.Reporte
    expect(hoja.A1.v).toBe('CuTuCo | Pedidos')
    expect(hoja.A3.v).toBe('Pedido')
    expect(hoja.B4.v).toBe(3500)
    expect(hoja.B4.t).toBe('n')
    expect(hoja['!autofilter']?.ref).toBe('A3:C5')
  })
})
