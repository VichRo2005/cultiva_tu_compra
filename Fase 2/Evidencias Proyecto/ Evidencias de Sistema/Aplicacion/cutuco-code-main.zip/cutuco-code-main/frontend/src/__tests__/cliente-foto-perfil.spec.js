/** Foto de perfil del cliente: carga segura, limpieza y vista conectada. */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({ getClient: vi.fn() }))
const sessionMock = vi.hoisted(() => ({
  unwrap: (respuesta, mensaje) => {
    if (respuesta?.error) throw new Error(mensaje)
    return respuesta?.data
  },
}))

vi.mock('@/lib/supabase', () => supabaseMock)
vi.mock('@/services/session', () => sessionMock)

function clienteOk() {
  const bucket = {
    upload: vi.fn(async () => ({ error: null })),
    remove: vi.fn(async () => ({ error: null })),
  }
  const consulta = {
    update: vi.fn(() => consulta),
    eq: vi.fn(() => consulta),
    select: vi.fn(() => consulta),
    single: vi.fn(async () => ({
      data: { id: 'perfil-1', foto_perfil_storage_path: 'nueva' },
      error: null,
    })),
  }
  return {
    bucket,
    consulta,
    cliente: {
      storage: { from: vi.fn(() => bucket) },
      from: vi.fn(() => consulta),
    },
  }
}

describe('foto de perfil del cliente', () => {
  it('guarda una nueva ruta, usa una versión única y limpia la imagen anterior', async () => {
    const { cliente, bucket, consulta } = clienteOk()
    supabaseMock.getClient.mockReturnValue(cliente)
    const { subirFotoPerfilCliente } = await import('@/services/profile')
    const archivo = new File(['imagen'], 'perfil.png', { type: 'image/png' })

    await expect(
      subirFotoPerfilCliente({
        perfilId: 'perfil-1',
        file: archivo,
        rutaActual: 'perfil-1/avatar-anterior.png',
      }),
    ).resolves.toMatchObject({ id: 'perfil-1' })

    expect(bucket.upload).toHaveBeenCalledWith(
      expect.stringMatching(/^perfil-1\/avatar-[\w-]+\.png$/),
      archivo,
      expect.objectContaining({ upsert: false, contentType: 'image/png' }),
    )
    expect(consulta.update).toHaveBeenCalledWith({
      foto_perfil_storage_path: expect.stringMatching(/^perfil-1\/avatar-[\w-]+\.png$/),
    })
    expect(bucket.remove).toHaveBeenCalledWith(['perfil-1/avatar-anterior.png'])
  })

  it('rechaza formatos no permitidos antes de escribir en Storage', async () => {
    const { cliente, bucket } = clienteOk()
    supabaseMock.getClient.mockReturnValue(cliente)
    const { subirFotoPerfilCliente } = await import('@/services/profile')
    const archivo = new File(['texto'], 'perfil.gif', { type: 'image/gif' })

    await expect(subirFotoPerfilCliente({ perfilId: 'perfil-1', file: archivo })).rejects.toThrow(
      /JPG, PNG o WebP/i,
    )
    expect(bucket.upload).not.toHaveBeenCalled()
  })

  it('elimina el archivo nuevo si no puede persistir la ruta del perfil', async () => {
    const { cliente, bucket, consulta } = clienteOk()
    consulta.single.mockResolvedValue({ data: null, error: { message: 'RLS' } })
    supabaseMock.getClient.mockReturnValue(cliente)
    const { subirFotoPerfilCliente } = await import('@/services/profile')
    const archivo = new File(['imagen'], 'perfil.jpg', { type: 'image/jpeg' })

    await expect(subirFotoPerfilCliente({ perfilId: 'perfil-1', file: archivo })).rejects.toThrow(
      /guardar la foto/i,
    )
    expect(bucket.remove).toHaveBeenCalledWith([
      expect.stringMatching(/^perfil-1\/avatar-.*\.jpg$/),
    ])
  })

  it('la vista ofrece carga, vista previa y el avatar se refleja en la barra superior', () => {
    const perfil = readFileSync('src/views/client/ClientProfileView.vue', 'utf8')
    const topbar = readFileSync('src/components/layout/AppTopbar.vue', 'utf8')
    const migracion = readFileSync(
      '../supabase/migrations/20261118000000_foto_perfil_cliente.sql',
      'utf8',
    )

    expect(perfil).toContain('title="Foto de perfil"')
    expect(perfil).toContain('Cambiar foto de perfil')
    expect(perfil).toContain('onElegirFotoPerfil')
    expect(perfil).toContain('quitarFotoPerfilCliente')
    expect(topbar).toContain('avatarUsuario')
    expect(topbar).toContain('avataresCliente')
    expect(migracion).toContain('foto_perfil_storage_path')
    expect(migracion).toContain("'client-avatars'")
  })

  it('muestra el avatar público y un fallback accesible en cada evaluación de tienda', () => {
    const perfilVendedor = readFileSync('src/views/public/SellerProfileView.vue', 'utf8')
    const migracion = readFileSync(
      '../supabase/migrations/20261121000000_avatar_cliente_evaluaciones_publicas.sql',
      'utf8',
    )

    expect(perfilVendedor).toContain('fotoClienteEvaluacion(evaluacion)')
    expect(perfilVendedor).toContain('nombreClienteEvaluacion(evaluacion)')
    expect(perfilVendedor).toContain('STORAGE_BUCKETS.avataresCliente')
    expect(migracion).toContain('cliente_foto_perfil_storage_path')
    expect(migracion).toContain('cliente_nombre')
    const contratoSalida = migracion.slice(
      migracion.indexOf('returns table'),
      migracion.indexOf('language sql'),
    )
    expect(contratoSalida).not.toMatch(/cliente_(id|email|rut|telefono)/i)
  })

  it('ofrece scroll interno y filtro por estrellas para todas las evaluaciones públicas', () => {
    const perfilVendedor = readFileSync('src/views/public/SellerProfileView.vue', 'utf8')
    const migracion = readFileSync(
      '../supabase/migrations/20261122000000_paginacion_filtro_evaluaciones_publicas.sql',
      'utf8',
    )

    expect(perfilVendedor).toContain('evaluaciones__scroll')
    expect(perfilVendedor).toContain('cargarMasEvaluaciones')
    expect(perfilVendedor).toContain('Filtrar evaluaciones')
    expect(migracion).toContain('p_offset integer default 0')
    expect(migracion).toContain('p_puntaje smallint default null')
    expect(migracion).toContain('e.puntaje = p_puntaje')
  })

  it('expone reglas de cantidad en el formulario del inventario y en la migración', () => {
    const formulario = readFileSync('src/views/seller/SellerProductFormView.vue', 'utf8')
    const migracion = readFileSync(
      '../supabase/migrations/20261123000000_reglas_cantidad_producto.sql',
      'utf8',
    )

    expect(formulario).toContain('label="Incremento de venta"')
    expect(formulario).toContain('label="Compra mínima"')
    expect(formulario).toContain('incrementoVenta')
    expect(formulario).toContain('cantidadMinimaCompra')
    expect(migracion).toContain('incremento_venta numeric(12,3)')
    expect(migracion).toContain('cantidad_minima_compra numeric(12,3)')
    expect(migracion).toContain('ck_producto_minimo_multiplo_incremento')
  })
})
