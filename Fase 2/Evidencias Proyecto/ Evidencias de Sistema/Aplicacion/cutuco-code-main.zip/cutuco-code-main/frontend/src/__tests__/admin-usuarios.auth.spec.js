import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const contexto = vi.hoisted(() => ({
  currentAuth: vi.fn(),
  motivoBloqueoVendedor: vi.fn(),
  sancionVigente: vi.fn(() => false),
  estadoEfectivoCuenta: vi.fn(({ perfil } = {}) => {
    if (!perfil) return 'sin_perfil'
    if (perfil.eliminado_en) return 'eliminado'
    if (perfil.activo === false) return 'desactivado'
    return 'activo'
  }),
}))
const cliente = vi.hoisted(() => ({
  from: vi.fn(),
  auth: {
    getSession: vi.fn(),
    getUser: vi.fn(),
    signInWithPassword: vi.fn(),
    signOut: vi.fn(),
    updateUser: vi.fn(),
    resetPasswordForEmail: vi.fn(),
    resend: vi.fn(),
    onAuthStateChange: vi.fn(),
  },
}))
vi.mock('@/services/session', () => contexto)
vi.mock('@/lib/supabase', () => ({
  getClient: () => cliente,
  tryGetClient: () => cliente,
  MISSING_ENV: false,
  MODO_DEMO: { value: false },
}))
import { useAuthStore } from '@/stores/auth.js'

beforeEach(() => {
  vi.resetAllMocks()
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, status: 204 }))
  setActivePinia(createPinia())
  contexto.currentAuth.mockResolvedValue({
    user: null,
    perfil: null,
    productor: null,
    postulacion: null,
  })
  cliente.auth.getSession.mockResolvedValue({ data: { session: null }, error: null })
  cliente.auth.onAuthStateChange.mockReturnValue({
    data: { subscription: { unsubscribe: vi.fn() } },
  })
  cliente.auth.signInWithPassword.mockResolvedValue({ error: null })
  cliente.auth.resend.mockResolvedValue({ error: null })
})

describe('auth · destinos de correo controlados', () => {
  it('construye recuperación y verificación sólo desde el origen de la aplicación', async () => {
    const auth = useAuthStore()
    await auth.sendPasswordReset('cliente@example.com')
    await auth.reenviarVerificacion('cliente@example.com')
    const recoveryRequest = fetch.mock.calls[0]
    const reset = new URL(recoveryRequest[0])
    const recoveryPayload = JSON.parse(recoveryRequest[1].body)
    const verificacion = new URL(cliente.auth.resend.mock.calls[0][0].options.emailRedirectTo)
    expect(reset.pathname).toBe('/api/auth/password-recovery')
    expect(recoveryRequest[1].method).toBe('POST')
    expect(recoveryPayload).toEqual({ email: 'cliente@example.com' })
    expect(verificacion.origin).toBe(window.location.origin)
    expect(verificacion.pathname).toBe('/login')
  })
})

describe('admin-usuarios · login existente', () => {
  it('CK-0017: si falla el perfil y el cierre remoto, no conserva identidad anterior', async () => {
    contexto.currentAuth.mockRejectedValue(new Error('Consulta fallida'))
    cliente.auth.signOut.mockRejectedValue(new Error('Red no disponible'))
    const auth = useAuthStore()
    auth.user = { id: 'anterior' }
    auth.perfil = { rol: 'admin', activo: true }
    await expect(auth.signIn({ email: 'qa@example.test', password: 'Clave123!' })).rejects.toThrow(
      'No pudimos verificar el estado',
    )
    expect(auth.user).toBeNull()
    expect(auth.isAdmin).toBe(false)
    expect(auth.perfil).toBeNull()
  })
  it('CK-0018: una consulta fallida de sanciones no concede acceso como vendedor', async () => {
    contexto.currentAuth.mockResolvedValue({
      user: { id: 'vendedor' }, perfil: { rol: 'vendedor', activo: true },
      productor: { id: 'tienda' }, postulacion: null,
    })
    const consulta = {
      select: () => consulta, eq: () => consulta,
      order: async () => ({ data: null, error: { message: 'Consulta fallida' } }),
    }
    cliente.from.mockReturnValue(consulta)
    const auth = useAuthStore()
    await expect(auth.refresh()).rejects.toThrow('restricciones de tu cuenta')
    expect(auth.user).toBeNull()
    expect(auth.productor).toBeNull()
    expect(auth.isVendedor).toBe(false)
  })
  it('CK-0008: renovar token vuelve a consultar el rol fuera del callback', async () => {
    vi.useFakeTimers()
    const auth = useAuthStore()
    try {
      await auth.init()
      contexto.currentAuth.mockResolvedValue({ user: { id: 'c1' }, perfil: { rol: 'cliente', activo: true } })
      const callback = cliente.auth.onAuthStateChange.mock.calls[0][0]
      const llamadas = contexto.currentAuth.mock.calls.length
      callback('TOKEN_REFRESHED')
      expect(contexto.currentAuth).toHaveBeenCalledTimes(llamadas)
      await vi.runAllTimersAsync()
      expect(auth.rol).toBe('cliente')
      expect(auth.isAdmin).toBe(false)
    } finally {
      auth.detenerEscucha()
      vi.useRealTimers()
    }
  })

  it('CK-0015: el cierre cancela un refresco programado', async () => {
    vi.useFakeTimers()
    const auth = useAuthStore()
    try {
      await auth.init()
      const callback = cliente.auth.onAuthStateChange.mock.calls[0][0]
      const llamadas = contexto.currentAuth.mock.calls.length
      callback('TOKEN_REFRESHED')
      callback('SIGNED_OUT')
      await vi.runAllTimersAsync()
      expect(contexto.currentAuth).toHaveBeenCalledTimes(llamadas)
      expect(auth.user).toBeNull()
    } finally {
      auth.detenerEscucha()
      vi.useRealTimers()
    }
  })
  it('CK-0015: limpia estado aunque falle el cierre remoto', async () => {
    const auth = useAuthStore()
    auth.user = { id: 'cliente' }
    auth.perfil = { rol: 'cliente' }
    auth.recuperacionPendiente = true
    cliente.auth.signOut.mockRejectedValue(new Error('red'))
    await expect(auth.signOut()).rejects.toThrow('red')
    expect(auth.user).toBeNull()
    expect(auth.perfil).toBeNull()
    expect(auth.recuperacionPendiente).toBe(false)
  })

  it('CK-0015: una consulta tardía no recupera sesión después del cierre', async () => {
    let completar
    contexto.currentAuth.mockReturnValue(new Promise((resolve) => { completar = resolve }))
    const auth = useAuthStore()
    const pendiente = auth.refresh()
    await auth.signOut()
    completar({ user: { id: 'anterior' }, perfil: { rol: 'cliente' } })
    await pendiente
    expect(auth.user).toBeNull()
  })

  it('CK-0039: exige contraseña actual sin llamar al proveedor', async () => {
    const auth = useAuthStore()
    await expect(auth.updatePassword('', 'ClaveNueva1!')).rejects.toThrow('contraseña actual')
    expect(cliente.auth.signInWithPassword).not.toHaveBeenCalled()
  })
  it('CK-0040: una clave actual incorrecta impide enviar la nueva', async () => {
    cliente.auth.signInWithPassword.mockResolvedValue({ error: { message: 'Invalid credentials' } })
    const auth = useAuthStore()
    auth.user = { id: 'cliente', email: 'cliente@example.test' }
    await expect(auth.updatePassword('Incorrecta1!', 'NuevaClave1!')).rejects.toThrow(
      'La contraseña actual no es correcta',
    )
    expect(cliente.auth.updateUser).not.toHaveBeenCalled()
  })
  it('al iniciar no crea una sesión ni rellena una identidad de administrador', async () => {
    const auth = useAuthStore()
    await auth.init()
    expect(auth.isAuthenticated).toBe(false)
    expect(auth.isAdmin).toBe(false)
    expect(auth.user).toBeNull()
    expect(cliente.auth.signInWithPassword).not.toHaveBeenCalled()
    auth.detenerEscucha()
  })

  it('rechaza el login de una cuenta eliminada y cierra su sesión', async () => {
    contexto.currentAuth.mockResolvedValue({
      user: { id: 'eliminado' },
      perfil: { activo: false, eliminado_en: '2026-10-09T15:00:00Z' },
    })
    const auth = useAuthStore()
    await expect(auth.signIn({ email: 'prueba@example.test', password: 'clave' })).rejects.toThrow(
      'eliminada permanentemente',
    )
    expect(cliente.auth.signOut).toHaveBeenCalled()
    expect(auth.isAuthenticated).toBe(false)
  })

  it('una sesión persistida no recupera una cuenta eliminada', async () => {
    contexto.currentAuth.mockResolvedValue({
      user: { id: 'eliminado' },
      perfil: { activo: false, eliminado_en: '2026-10-09T15:00:00Z' },
    })
    const auth = useAuthStore()
    await auth.init()
    expect(cliente.auth.signOut).toHaveBeenCalled()
    expect(auth.user).toBeNull()
    auth.detenerEscucha()
  })
})


it('CK-0046: reautenticación incorrecta no solicita cambio de correo', async () => {
  const auth = useAuthStore()
  auth.user = { id: 'cliente-1', email: 'actual@example.test' }
  cliente.auth.signInWithPassword.mockResolvedValue({ error: { message: 'Invalid login credentials' } })
  await expect(auth.updateEmail('nuevo@example.test', 'incorrecta')).rejects.toThrow('contraseña actual')
  expect(cliente.auth.updateUser).not.toHaveBeenCalled()
})

it('CK-0041: el cambio de contraseña envía sólo { password }, nunca el correo', async () => {
  const auth = useAuthStore()
  auth.user = { id: 'cliente-1', email: 'actual@example.test' }
  cliente.auth.signInWithPassword.mockResolvedValue({ error: null })
  cliente.auth.updateUser.mockResolvedValue({ error: null })
  await expect(auth.updatePassword('Actual1!x', 'NuevaClave1!')).resolves.toBe(true)
  expect(cliente.auth.updateUser).toHaveBeenCalledTimes(1)
  const payload = cliente.auth.updateUser.mock.calls[0][0]
  expect(Object.keys(payload)).toEqual(['password'])
  expect(payload).toEqual({ password: 'NuevaClave1!' })
})

it('CK-0033/0034: la recuperación responde igual para correo existente e inexistente', async () => {
  const auth = useAuthStore()
  // El servidor preserva una respuesta genérica para ambos casos; el cliente
  // no recibe información sobre si el correo existe en Supabase.
  await expect(auth.sendPasswordReset('existe@example.test')).resolves.toBe(true)
  await expect(auth.sendPasswordReset('noexiste@example.test')).resolves.toBe(true)
  expect(fetch).toHaveBeenCalledTimes(2)
  expect(JSON.parse(fetch.mock.calls[0][1].body)).toEqual({ email: 'existe@example.test' })
  expect(JSON.parse(fetch.mock.calls[1][1].body)).toEqual({ email: 'noexiste@example.test' })
})


describe('recuperación exige identidad y perfil verificados', () => {
  it.each([
    { data: { user: null }, error: null },
    { data: { user: { id: 'cliente-1' } }, error: { message: 'fallo de red' } },
  ])('no envía la contraseña si falla la identidad', async (respuesta) => {
    const auth = useAuthStore()
    auth.marcarRecuperacion()
    cliente.auth.getUser.mockResolvedValue(respuesta)
    cliente.auth.signOut.mockRejectedValue(new Error('sin red'))
    await expect(auth.completarRecuperacion('NuevaClave!2026')).rejects.toThrow('sesión de recuperación')
    expect(cliente.auth.updateUser).not.toHaveBeenCalled()
    expect(auth.recuperacionPendiente).toBe(false)
    expect(auth.isAuthenticated).toBe(false)
  })

  it.each([
    { data: null, error: null },
    { data: null, error: { message: 'fallo de red' } },
  ])('no envía la contraseña sin perfil verificado', async (respuesta) => {
    const auth = useAuthStore()
    auth.marcarRecuperacion()
    cliente.auth.getUser.mockResolvedValue({ data: { user: { id: 'cliente-1' } }, error: null })
    const query = { select: () => query, eq: () => query, maybeSingle: async () => respuesta }
    cliente.from.mockReturnValue(query)
    await expect(auth.completarRecuperacion('NuevaClave!2026')).rejects.toThrow('estado de tu cuenta')
    expect(cliente.auth.updateUser).not.toHaveBeenCalled()
  })
})
