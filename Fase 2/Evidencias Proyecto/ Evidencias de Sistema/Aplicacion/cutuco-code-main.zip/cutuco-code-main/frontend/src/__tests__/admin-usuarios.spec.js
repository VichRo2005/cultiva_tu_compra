/**
 * CuTuCo — Gestión de usuarios (RF-004, RF-017 y RF-019).
 *
 * Regresión: la vista usaba `useGeographyStore()` sin importarlo, así que el
 * componente lanzaba `ReferenceError` al montarse y la página quedaba en blanco
 * (y el `Transition mode="out-in"` del shell se quedaba atascado hasta recargar).
 *
 * ACTUALIZACIÓN: la vista migró de `services/admin` (lista completa con KPIs) a
 * `services/adminUsuarios.js` (listado paginado con filtros en PostgREST). Este
 * spec mockea ese servicio; el filtrado por rol/estado se resuelve en el
 * servicio, así que el mock replica ese contrato.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

const adminUsuariosMock = vi.hoisted(() => ({
  listarUsuarios: vi.fn(),
  obtenerDetalle: vi.fn(),
  toggleActivo: vi.fn(),
  eliminar: vi.fn(),
}))

vi.mock('@/services/adminUsuarios.js', () => adminUsuariosMock)

import AdminUsersView from '@/views/admin/AdminUsersView.vue'

const USUARIOS = [
  {
    id: 'u-1',
    nombre: 'Camila',
    apellido: 'Rojas',
    nombreCompleto: 'Camila Rojas',
    rol: 'cliente',
    activo: true,
    telefono: '+56900000002',
    bloqueado_hasta: null,
    bloqueado: false,
    es_protegido: false,
    es_super_admin: false,
    protegido: false,
    eliminado_en: null,
    eliminado: false,
    creado_en: '2026-10-01T12:00:00Z',
  },
  {
    id: 'u-2',
    nombre: 'Verónica',
    apellido: 'Del Campo',
    nombreCompleto: 'Verónica Del Campo',
    rol: 'vendedor',
    activo: false,
    telefono: '+56900000101',
    bloqueado_hasta: null,
    bloqueado: false,
    es_protegido: false,
    es_super_admin: false,
    protegido: false,
    eliminado_en: null,
    eliminado: false,
    creado_en: '2026-09-15T12:00:00Z',
  },
]

/** Replica el contrato del servicio: filtros aplicados en PostgREST. */
function listadoSegun({ texto = '', rol = '', activo = null, page = 1, pageSize = 12 } = {}) {
  let items = [...USUARIOS]
  if (rol) items = items.filter((u) => u.rol === rol)
  if (activo !== null) items = items.filter((u) => u.activo === activo)
  if (texto.trim()) {
    const t = texto.trim().toLowerCase()
    items = items.filter((u) => `${u.nombre} ${u.apellido} ${u.telefono}`.toLowerCase().includes(t))
  }
  const desde = (page - 1) * pageSize
  return { items: items.slice(desde, desde + pageSize), total: items.length, page, pageSize }
}

const stubs = {
  RouterLink: { template: '<a><slot /></a>' },
}

function montar() {
  return mount(AdminUsersView, { global: { stubs } })
}

beforeEach(() => {
  setActivePinia(createPinia())
  vi.clearAllMocks()
  adminUsuariosMock.listarUsuarios.mockImplementation(async (filtros) => listadoSegun(filtros))
  adminUsuariosMock.obtenerDetalle.mockImplementation(
    async (id) => USUARIOS.find((u) => u.id === id) ?? null,
  )
  adminUsuariosMock.toggleActivo.mockResolvedValue({})
  adminUsuariosMock.eliminar.mockResolvedValue({})
})

describe('Admin · Gestión de usuarios', () => {
  it('se monta y muestra el listado (antes lanzaba ReferenceError y dejaba la página en blanco)', async () => {
    const wrapper = montar()
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Gestión de usuarios')
    expect(texto).toContain('Camila Rojas')
    expect(texto).toContain('Verónica Del Campo')
    expect(texto).toContain('Desactivado')
    expect(texto).toContain('2 resultados')
  })

  it('carga los usuarios desde el servicio administrativo', async () => {
    const wrapper = montar()
    await flushPromises()

    expect(adminUsuariosMock.listarUsuarios).toHaveBeenCalled()
    const texto = wrapper.text()
    expect(texto).toContain('Actualizar')
    expect(texto).toContain('Aprobación de vendedores')
    expect(texto).toContain('Cliente')
    expect(texto).toContain('Vendedor')
  })

  it('seleccionar un usuario para desactivarlo abre el diálogo sin romper la vista', async () => {
    const wrapper = montar()
    await flushPromises()

    // Botón de desactivar de la primera fila (Camila Rojas está activa).
    const boton = wrapper
      .findAll('button')
      .find((b) => (b.attributes('aria-label') ?? '').includes('Desactivar a Camila Rojas'))
    expect(boton, 'no se encontró el botón de desactivar').toBeTruthy()

    await boton.trigger('click')
    await flushPromises()

    // El diálogo de confirmación se teletransporta a <body>: aparece con el usuario.
    expect(document.body.textContent).toContain('Desactivar cuenta')
    expect(document.body.textContent).toContain('Camila Rojas quedará desactivado')

    // Y la vista sigue viva: se puede cambiar un filtro.
    const selectRol = wrapper.findAll('select')
    expect(selectRol.length).toBeGreaterThan(0)
    wrapper.unmount()
  })

  it('filtra por rol sin errores', async () => {
    const wrapper = montar()
    await flushPromises()

    const selects = wrapper.findAll('select')
    await selects[0].setValue('vendedor')
    await flushPromises()

    expect(adminUsuariosMock.listarUsuarios).toHaveBeenCalledWith(
      expect.objectContaining({ rol: 'vendedor' }),
    )
    const texto = wrapper.text()
    expect(texto).toContain('Verónica Del Campo')
    expect(texto).not.toContain('Camila Rojas')
  })
})
