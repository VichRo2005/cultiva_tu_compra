<script setup>
/** CuTuCo — Página no encontrada. */
import CtButton from '@/components/base/CtButton.vue'
import CtIcon from '@/components/base/CtIcon.vue'
</script>

<template>
  <div class="container container--narrow page nf">
    <p class="nf__code" aria-hidden="true">404</p>
    <h1 class="page-head__title">No encontramos esta ventana</h1>
    <p class="page-head__subtitle">
      El enlace puede estar equivocado o el producto fue retirado del catálogo. Te dejamos volver a
      los caminos principales de CuTuCo.
    </p>

    <div class="nf__actions">
      <CtButton to="/">
        <CtIcon name="home" :size="16" />
        Ir al inicio
      </CtButton>
      <CtButton variant="secondary" to="/catalogo">
        <CtIcon name="catalog" :size="16" />
        Ver el catálogo
      </CtButton>
      <CtButton variant="ghost" to="/cliente/pedidos">
        <CtIcon name="orders" :size="16" />
        Mis pedidos
      </CtButton>
    </div>
  </div>
</template>

<style scoped>
.nf {
  align-items: center;
  text-align: center;
  gap: var(--ct-space-4);
  padding-block: var(--ct-space-16) var(--ct-space-12);
}

.nf__code {
  font-size: clamp(4rem, 14vw, 7rem);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.05em;
  line-height: 1;
  color: var(--ct-primary-strong);
}

.nf__actions {
  display: flex;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
  justify-content: center;
  margin-top: var(--ct-space-4);
}
</style>
