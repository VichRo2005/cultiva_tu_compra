<script setup>
/**
 * CuTuCo — Filtros del catálogo.
 *
 * Un solo patrón de filtrado (HAL-VEN-007): categoría/subcategoría en dos
 * selectores dependientes, región y vendedor en selectores, y rango de precio.
 * No incluye buscador propio porque el buscador global de la barra superior es
 * el único buscador principal (HAL-CLI-020).
 *
 * HAL-VEN-006: categorías y subcategorías no se mezclan en el mismo nivel y
 * "Sin categoría"/"Sin Categoría" se normaliza sin duplicados.
 * HAL-CLI-021: "Alimentos para mascotas" y sus descendientes no se ofrecen.
 */
import { computed, ref, watch } from 'vue'
import CtInput from '@/components/base/CtInput.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtButton from '@/components/base/CtButton.vue'
import {
  filtrarCategoriasVisibles,
  normalizarNombreCategoria,
} from '@/services/catalog'
import { useGeographyStore } from '@/stores/geography'

const props = defineProps({
  categorias: { type: Array, default: () => [] },
  regiones: { type: Array, default: () => [] },
  /** Vendedores de la región activa; opcional. */
  productores: { type: Array, default: () => [] },
  filters: { type: Object, required: true },
  compact: { type: Boolean, default: false },
})

const emit = defineEmits(['update:filters', 'change'])

const geo = useGeographyStore()
const local = ref({ ...props.filters })

watch(
  () => props.filters,
  (value) => {
    local.value = { ...value }
  },
  { deep: true },
)

const arbolVisible = computed(() => filtrarCategoriasVisibles(props.categorias))

/** Categorías de primer nivel; si el árbol no trae jerarquía, se usan todas. */
const categoriasRaiz = computed(() => {
  const nodos = arbolVisible.value
  const conJerarquia = nodos.some((nodo) => nodo.hijos?.length || nodo.categoria_padre_id)
  if (!conJerarquia) return nodos
  const idsPresentes = new Set(nodos.map((nodo) => String(nodo.id)))
  return nodos.filter(
    (nodo) => !nodo.categoria_padre_id || !idsPresentes.has(String(nodo.categoria_padre_id)),
  )
})

const opcionesCategoriaPadre = computed(() => [
  { value: '', label: 'Todas las categorías' },
  ...categoriasRaiz.value.map((categoria) => ({
    value: String(categoria.id),
    label: normalizarNombreCategoria(categoria.nombre ?? categoria.label),
  })),
])

const categoriaSeleccionada = computed(() => {
  if (!local.value.categoriaId) return null
  const buscar = (nodos) => {
    for (const nodo of nodos) {
      if (String(nodo.id) === String(local.value.categoriaId)) return nodo
      const hijo = buscar(nodo.hijos ?? [])
      if (hijo) return hijo
    }
    return null
  }
  return buscar(arbolVisible.value)
})

const opcionesSubcategoria = computed(() => {
  const padre = categoriaSeleccionada.value
  if (!padre?.hijos?.length) return []
  return [
    { value: '', label: 'Todas las subcategorías' },
    ...padre.hijos.map((nodo) => ({
      value: String(nodo.id),
      label: normalizarNombreCategoria(nodo.nombre ?? nodo.label),
    })),
  ]
})

const opcionesRegion = computed(() => [
  { value: '', label: 'Todas las regiones' },
  ...(props.regiones.length ? props.regiones : geo.regionesOrdenadas).map((r) => ({
    value: String(r.id),
    label: r.nombre,
  })),
])

const opcionesProductor = computed(() => [
  { value: '', label: 'Todos los vendedores' },
  ...props.productores.map((p) => ({ value: String(p.id), label: p.nombre_comercial })),
])

function apply(patch) {
  local.value = { ...local.value, ...patch }
  emit('update:filters', { ...local.value })
  emit('change', { ...local.value })
}

function elegirCategoria(categoriaId) {
  apply({ categoriaId: categoriaId ? String(categoriaId) : '', subcategoriaId: '' })
}

function limpiar() {
  local.value = {
    ...local.value,
    categoriaId: '',
    subcategoriaId: '',
    regionId: '',
    productorId: '',
    precioMin: '',
    precioMax: '',
  }
  emit('update:filters', { ...local.value })
  emit('change', { ...local.value })
}

function hayFiltros() {
  return Boolean(
    local.value.categoriaId ||
      local.value.subcategoriaId ||
      local.value.regionId ||
      local.value.productorId ||
      local.value.precioMin ||
      local.value.precioMax,
  )
}
</script>

<template>
  <div class="ct-filters" :class="{ 'is-compact': compact }">
    <CtSelect
      :model-value="local.categoriaId ?? ''"
      :options="opcionesCategoriaPadre"
      label="Categoría"
      @update:model-value="elegirCategoria"
    />

    <CtSelect
      v-if="opcionesSubcategoria.length"
      :model-value="local.subcategoriaId ?? ''"
      :options="opcionesSubcategoria"
      label="Subcategoría"
      @update:model-value="apply({ subcategoriaId: $event })"
    />

    <CtSelect
      :model-value="local.regionId ?? ''"
      :options="opcionesRegion"
      label="Región"
      @update:model-value="apply({ regionId: $event ? String($event) : '', productorId: '' })"
    />

    <CtSelect
      v-if="local.regionId && productores.length"
      :model-value="local.productorId ?? ''"
      :options="opcionesProductor"
      label="Vendedor"
      @update:model-value="apply({ productorId: $event ? String($event) : '' })"
    />

    <div class="ct-filters__range">
      <span class="ct-filters__range-label">Rango de precio</span>
      <div class="ct-filters__range-fields">
        <CtInput
          :model-value="local.precioMin ?? ''"
          type="number"
          min="0"
          placeholder="Mín"
          prefix="$"
          aria-label="Precio mínimo"
          @update:model-value="apply({ precioMin: $event })"
        />
        <CtInput
          :model-value="local.precioMax ?? ''"
          type="number"
          min="0"
          placeholder="Máx"
          prefix="$"
          aria-label="Precio máximo"
          @update:model-value="apply({ precioMax: $event })"
        />
      </div>
    </div>

    <CtButton v-if="hayFiltros()" variant="ghost" size="sm" @click="limpiar">
      <template #icon><CtIcon name="close" :size="15" /></template>
      Limpiar filtros
    </CtButton>
  </div>
</template>

<style scoped>
.ct-filters {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
  gap: var(--ct-space-3);
  align-items: end;
}

.ct-filters.is-compact {
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
}

/* Rango de precio: dos campos en una celda propia. */
.ct-filters__range {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  min-width: 0;
}

.ct-filters__range-label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.ct-filters__range-fields {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-2);
}

@media (max-width: 1100px) {
  .ct-filters {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 620px) {
  .ct-filters {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
