<script setup>
/**
 * CuTuCo — Aprobación de vendedores (RF-021 y RF-004).
 *
 * El administrador revisa los antecedentes de cada solicitante y aprueba o
 * rechaza la solicitud. Al aprobar, el trigger `activar_productor_aprobado`
 * crea el productor y cambia el rol del perfil, y exige exactamente una
 * dirección activa y los datos bancarios para la dispersión de Webpay Mall.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): la revisión documental con
 * cédula frontal y dorsal (RF-015) y la verificación automática por lote
 * salieron del alcance; la revisión es manual.
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_POSTULACION, LABELS, POSTULACIONES_PENDIENTES } from '@/lib/constants'
import { formatDate, formatDateTime, formatNumber, truncate } from '@/lib/format'
import {
  listPostulaciones,
  listarRevisionesPostulacion,
  MAX_OBSERVACIONES,
  MIN_MOTIVO_REINICIO,
  MIN_OBSERVACIONES,
  reiniciarIntentosPostulacion,
  revisarPostulacion,
  urlFirmadaDocumentoPostulacion,
} from '@/services/admin'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const pestana = ref('pendientes')
const texto = ref('')
const loading = ref(true)
const error = ref(null)
const postulaciones = ref([])

const revision = ref({
  abierto: false,
  postulacion: null,
  observaciones: '',
})
const guardando = ref(false)
const confirmacion = ref({ abierto: false, pendientes: [], accion: null })
const lote = ref({ abierto: false, seleccionados: [] })
/** D4 — historial de revisiones anteriores de la postulación abierta. */
const historial = ref({ cargando: false, filas: [] })
/** F — reinicio administrativo del límite de 3 intentos. */
const reinicio = ref({ abierto: false, postulacion: null, motivo: '', error: null })
/** C1 — descarga de documentos en curso (clave → boolean). */
const descargando = ref({})

const columnas = [
  { key: 'productor', label: 'Productor', width: '24%' },
  { key: 'representante', label: 'Representante' },
  { key: 'ubicacion', label: 'Ubicación' },
  { key: 'fecha', label: 'Fecha' },
  { key: 'intento', label: 'Intento' },
  { key: 'documentos', label: 'Documentos' },
  { key: 'estado', label: 'Estado' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

/**
 * C1/C3 — Documentos KYB de la postulación (bucket privado vendedor-
 * documentos). Las etiquetas dependen del tipo de persona declarado (RF-021).
 */
const DOCS_POSTULACION = [
  {
    clave: 'documentoIdentidad',
    columna: 'documento_identidad',
    natural: 'Cédula de identidad',
    juridica: 'E-RUT de la empresa',
  },
  {
    clave: 'certificadoActividadesOCarnet',
    columna: 'certificado_inicio_actividades_o_carnet_representante',
    natural: 'Certificado de inicio de actividades (SII)',
    juridica: 'Cédula del representante legal',
  },
  {
    clave: 'certificadoTitularidad',
    columna: 'certificado_titularidad_bancaria',
    natural: 'Certificado de titularidad bancaria',
    juridica: 'Certificado de titularidad bancaria de la empresa',
  },
  {
    clave: 'comprobanteDomicilio',
    columna: 'comprobante_domicilio',
    natural: 'Comprobante de domicilio',
    juridica: 'Comprobante de domicilio tributario',
  },
]

/** Lista de documentos con ruta, etiqueta y tipo MIME declarado. */
function documentosDe(postulacion) {
  const esJuridica = postulacion?.tipo_de_persona === 'juridica'
  return DOCS_POSTULACION.map((doc) => {
    const ruta = postulacion?.[doc.columna] ?? null
    const extension = ruta ? String(ruta).split('.').pop().toLowerCase() : null
    return {
      clave: doc.clave,
      etiqueta: esJuridica ? doc.juridica : doc.natural,
      ruta,
      formato: extension ? extension.toUpperCase() : null,
      disponible: Boolean(ruta),
    }
  })
}

function contarDocumentos(postulacion) {
  return documentosDe(postulacion).filter((d) => d.disponible).length
}

/** C1/C2 — abre el documento con una URL firmada de 60 s en una pestaña nueva. */
async function abrirDocumento(postulacion, doc) {
  if (!doc.disponible || descargando.value[doc.clave]) return
  descargando.value = { ...descargando.value, [doc.clave]: true }
  try {
    const url = await urlFirmadaDocumentoPostulacion(doc.ruta)
    window.open(url, '_blank', 'noopener')
  } catch (e) {
    ui.error('Documento no disponible', e.message)
  } finally {
    descargando.value = { ...descargando.value, [doc.clave]: false }
  }
}

/** D2 — sólo las postulaciones en revisión admiten aprobar o rechazar. */
function puedeResolver(postulacion) {
  return Boolean(postulacion) && POSTULACIONES_PENDIENTES.includes(postulacion.estado)
}

/** D4 — carga el historial de revisiones de la postulación abierta. */
async function cargarHistorial(postulacionId) {
  historial.value = { cargando: true, filas: [] }
  try {
    historial.value = { cargando: false, filas: await listarRevisionesPostulacion(postulacionId) }
  } catch {
    // El historial es complementario: no bloquea la revisión.
    historial.value = { cargando: false, filas: [] }
  }
}

/** F — abre el reinicio del límite de intentos (sólo rechazadas). */
function pedirReinicio(postulacion) {
  reinicio.value = { abierto: true, postulacion, motivo: '', error: null }
}

async function aplicarReinicio() {
  const postulacion = reinicio.value.postulacion
  if (!postulacion) return
  try {
    const actualizada = await reiniciarIntentosPostulacion(postulacion.id, reinicio.value.motivo)
    postulacion.intentos_extra = actualizada?.intentos_extra ?? (postulacion.intentos_extra ?? 0) + 3
    reinicio.value = { abierto: false, postulacion: null, motivo: '', error: null }
    ui.success(
      'Intentos reiniciados',
      `${postulacion.nombre_comercial_solicitado} puede volver a enviar su solicitud (quedó registrada tu decisión y su motivo).`,
    )
  } catch (e) {
    reinicio.value = { ...reinicio.value, error: e.message }
  }
}

/**
 * RF-021: el administrador revisa los antecedentes a mano. El esquema exige que
 * el solicitante tenga exactamente una dirección activa antes de aprobar la
 * cuenta (el trigger `activar_productor_aprobado` la usa para la cobertura
 * regional de RF-009).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): la aprobación exigía
 * cédula frontal y dorsal vigentes (RF-015); la retención del carnet salió del
 * alcance y el respaldo documental ya no forma parte del flujo.
 */
function direccionLista(postulacion) {
  return Boolean(postulacion?.direccion?.id)
}

/**
 * Datos bancarios descifrados por FastAPI sólo para un administrador
 * autenticado. Son necesarios para contrastar la solicitud antes de aprobar.
 */
function datosBancariosListos(postulacion) {
  return Boolean(postulacion?.datosBancarios?.banco)
}

/** Una postulación está lista para aprobar cuando tiene dirección y datos de pago. */
function listaParaAprobar(postulacion) {
  return direccionLista(postulacion) && datosBancariosListos(postulacion)
}

function pendientesDeDatos(postulacion) {
  const faltan = []
  if (!direccionLista(postulacion)) faltan.push('dirección activa')
  if (!datosBancariosListos(postulacion)) faltan.push('datos bancarios para Webpay Mall')
  return faltan
}

function representante(postulacion) {
  const perfil = postulacion.perfil
  return [perfil?.nombre, perfil?.apellido].filter(Boolean).join(' ') || 'Sin perfil asociado'
}

const hoy = () => new Date().toISOString().slice(0, 10)

const esHoy = (fecha) => Boolean(fecha) && new Date(fecha).toISOString().slice(0, 10) === hoy()

const esDelMes = (fecha) => {
  if (!fecha) return false
  const d = new Date(fecha)
  const ahora = new Date()
  return d.getFullYear() === ahora.getFullYear() && d.getMonth() === ahora.getMonth()
}

const esPendiente = (p) => POSTULACIONES_PENDIENTES.includes(p.estado)

const kpis = computed(() => {
  const lista = postulaciones.value
  const pendientes = lista.filter(esPendiente)
  return {
    pendientes: pendientes.length,
    enRevision: pendientes.filter(listaParaAprobar).length,
    aprobadosHoy: lista.filter(
      (p) => p.estado === ESTADO_POSTULACION.APROBADA && esHoy(p.revisado_en),
    ).length,
    rechazadosMes: lista.filter(
      (p) => p.estado === ESTADO_POSTULACION.RECHAZADA && esDelMes(p.revisado_en),
    ).length,
  }
})

const filas = computed(() => {
  const lista = postulaciones.value
  if (pestana.value === 'pendientes') {
    return lista.filter(esPendiente)
  }
  if (pestana.value === 'revision') {
    return lista.filter((p) => esPendiente(p) && listaParaAprobar(p))
  }
  return lista
})

const filtrados = computed(() => {
  const busqueda = texto.value.trim().toLowerCase()
  if (!busqueda) return filas.value
  return filas.value.filter((p) =>
    [p.nombre_comercial_solicitado, representante(p)].some((valor) =>
      (valor ?? '').toLowerCase().includes(busqueda),
    ),
  )
})

const tabs = computed(() => [
  { value: 'pendientes', label: 'Pendientes de Aprobación', count: kpis.value.pendientes },
  { value: 'revision', label: 'En Revisión', count: kpis.value.enRevision },
  { value: 'todos', label: 'Todos los Productores', count: postulaciones.value.length },
])

/** Pendientes listas para aprobar por lote (con dirección y datos bancarios). */
const candidatasLote = computed(() =>
  postulaciones.value.filter((p) => esPendiente(p) && listaParaAprobar(p)),
)

function abrirRevision(postulacion) {
  revision.value = {
    abierto: true,
    postulacion,
    observaciones: postulacion.observaciones_admin ?? '',
  }
  cargarHistorial(postulacion.id)
}

function cerrarRevision() {
  revision.value = {
    abierto: false,
    postulacion: null,
    observaciones: '',
  }
}

function errorObservaciones(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto.length) return null
  if (texto.length < MIN_OBSERVACIONES || texto.length > MAX_OBSERVACIONES) {
    return `Las observaciones deben tener entre ${MIN_OBSERVACIONES} y ${MAX_OBSERVACIONES} caracteres.`
  }
  return null
}

function pedirAccion(postulacion, accion) {
  // D2: las transiciones sólo aplican a postulaciones en revisión; una
  // aprobada/rechazada no puede resolverse de nuevo (la BD también lo bloquea).
  if (!puedeResolver(postulacion)) return
  // Si se escriben observaciones, respetan 10..2500. Cuando quedan vacías,
  // el correo de decisión informa una respuesta automática según el resultado.
  const errorObs = errorObservaciones(revision.value.observaciones)
  if (errorObs) {
    ui.error('Observaciones inválidas', errorObs)
    return
  }
  confirmacion.value = { abierto: true, pendientes: [postulacion], accion }
}

function pedirVerificacionLote() {
  lote.value = {
    abierto: true,
    seleccionados: candidatasLote.value.map((p) => p.id),
  }
}

function alternarSeleccion(id) {
  const actuales = lote.value.seleccionados
  lote.value = {
    ...lote.value,
    seleccionados: actuales.includes(id) ? actuales.filter((x) => x !== id) : [...actuales, id],
  }
}

async function aplicarAccion() {
  const { pendientes, accion } = confirmacion.value
  const postulacion = pendientes[0]
  if (!postulacion) return
  guardando.value = true
  try {
    const actualizada = await revisarPostulacion({
      postulacionId: postulacion.id,
      estado: accion === 'aprobar' ? ESTADO_POSTULACION.APROBADA : ESTADO_POSTULACION.RECHAZADA,
      observaciones: revision.value.observaciones.trim() || null,
    })
    postulacion.estado =
      accion === 'aprobar' ? ESTADO_POSTULACION.APROBADA : ESTADO_POSTULACION.RECHAZADA
    postulacion.observaciones_admin = revision.value.observaciones.trim() || null
    if (accion === 'aprobar') {
      postulacion.codigo_comercio_mall = actualizada.codigo_comercio_mall
    }
    postulacion.revisado_en = new Date().toISOString()
    // D4: la decisión queda archivada; se recarga el historial si el modal
    // sigue abierto para otra revisión.
    cargarHistorial(postulacion.id)
    ui.success(
      accion === 'aprobar' ? 'Productor verificado' : 'Postulación rechazada',
      `${postulacion.nombre_comercial_solicitado} quedó en estado ${LABELS.postulacion[postulacion.estado]}.`,
    )
    cerrarRevision()
  } catch (e) {
    ui.error('No se pudo guardar la revisión', e.message)
  } finally {
    guardando.value = false
    confirmacion.value = { abierto: false, pendientes: [], accion: null }
  }
}

/**
 * Aprobación por lote: el backend asigna el comercio hijo Mall configurado a
 * cada aprobación; el administrador sólo confirma qué solicitudes revisar.
 */
async function verificarLote() {
  const seleccionadas = postulaciones.value.filter((p) => lote.value.seleccionados.includes(p.id))
  guardando.value = true
  let ok = 0
  const fallidas = []
  for (const postulacion of seleccionadas) {
    try {
      const actualizada = await revisarPostulacion({
        postulacionId: postulacion.id,
        estado: ESTADO_POSTULACION.APROBADA,
        observaciones: 'Verificación por lote desde moderación.',
      })
      postulacion.estado = ESTADO_POSTULACION.APROBADA
      postulacion.codigo_comercio_mall = actualizada.codigo_comercio_mall
      postulacion.revisado_en = new Date().toISOString()
      ok += 1
    } catch (e) {
      fallidas.push(`${postulacion.nombre_comercial_solicitado}: ${e.message}`)
    }
  }
  guardando.value = false
  lote.value = { abierto: false, seleccionados: [] }
  if (ok) ui.success('Verificación por lote completada', `${ok} postulación(es) aprobadas.`)
  if (fallidas.length) {
    ui.error('Algunas postulaciones no se pudieron aprobar', fallidas.join(' · '))
  }
  if (!ok && !fallidas.length)
    ui.warning('No seleccionaste postulaciones', 'Elige al menos una candidata.')
}

async function cargar() {
  loading.value = true
  error.value = null
  try {
    postulaciones.value = await listPostulaciones()
  } catch (e) {
    error.value = e.message
    postulaciones.value = []
  } finally {
    loading.value = false
  }
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Moderación de Vendedores</h1>
        <p class="page-head__subtitle">
          Valida la identidad de los productores antes de que publiquen en el catálogo.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" to="/admin/sanciones?tab=moderacion"
          >Palabras prohibidas</CtButton
        >
        <CtButton
          variant="secondary"
          :disabled="!candidatasLote.length"
          @click="pedirVerificacionLote"
        >
          <template #icon><CtIcon name="check" :size="16" /></template>
          Verificar Lote
        </CtButton>
        <CtButton :loading="loading" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar las postulaciones">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-if="loading && !postulaciones.length" label="Cargando postulaciones…" />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Pendientes"
          :value="formatNumber(kpis.pendientes)"
          icon="clock"
          tone="warning"
          hint="Esperando decisión administrativa"
        />
        <CtStatCard
          label="Listas para aprobar"
          :value="formatNumber(kpis.enRevision)"
          icon="shield"
          tone="info"
          hint="Con dirección activa y datos bancarios registrados"
        />
        <CtStatCard
          label="Aprobados hoy"
          :value="formatNumber(kpis.aprobadosHoy)"
          icon="check"
          tone="success"
          hint="Verificados en la jornada"
        />
        <CtStatCard
          label="Rechazados mes"
          :value="formatNumber(kpis.rechazadosMes)"
          icon="ban"
          tone="danger"
          hint="Rechazados en el mes en curso"
        />
      </div>

      <CtAlert tone="neutral" compact title="Cómo se revisa cada solicitud">
        <p>
          El administrador revisa los antecedentes del solicitante a mano. Antes de aprobar se exige
          que tenga exactamente una dirección activa y sus datos bancarios para Webpay Mall: sin ellos
          la aprobación falla en la base de datos. No se pide ni se guarda el carnet ( quedó
          fuera del alcance).
        </p>
      </CtAlert>

      <CtCard padding="md">
        <div class="barra">
          <CtTabs v-model="pestana" :tabs="tabs" stretch />
          <CtSearchInput
            v-model="texto"
            class="barra__buscador"
            placeholder="Buscar por nombre comercial o representante…"
            aria-label="Buscar postulaciones"
          />
        </div>

        <CtTable
          :columns="columnas"
          :rows="filtrados"
          :loading="loading"
          dense
          min-width="980px"
          empty-icon="shield"
          empty-title="Sin postulaciones"
          empty-message="No hay postulaciones que coincidan con la pestaña y la búsqueda actuales."
        >
          <template #cell-productor="{ row }">
            <div class="productor">
              <CtAvatar :name="row.nombre_comercial_solicitado" :size="34" square />
              <div class="productor__texto">
                <p class="productor__nombre">{{ row.nombre_comercial_solicitado }}</p>
                <p class="productor__detalle">
                  {{ truncate(row.descripcion ?? '', 46) || 'Sin descripción' }}
                </p>
              </div>
            </div>
          </template>

          <template #cell-representante="{ row }">
            <span class="text-sm">{{ representante(row) }}</span>
          </template>

          <template #cell-ubicacion="{ row }">
            <span class="text-sm">
              {{ row.comuna?.nombre ?? 'Sin comuna' }}
              <span v-if="row.region" class="text-muted"> · {{ row.region.nombre }}</span>
            </span>
          </template>

          <template #cell-fecha="{ row }">
            <span class="text-sm text-muted">{{ formatDate(row.creado_en) }}</span>
          </template>

          <!-- D3: "Intento" muestra el contador de postulaciones (1..3 + extra);
               el estado vive en su propia columna, sin duplicar datos. -->
          <template #cell-intento="{ row }">
            <span class="text-sm">
              Intento {{ row.intento ?? 1 }}
              <span class="text-muted">de {{ 3 + (row.intentos_extra ?? 0) }}</span>
            </span>
          </template>

          <template #cell-documentos="{ row }">
            <!-- C1: el conteo de documentos KYB reales de la postulación. -->
            <div class="documentos-celda">
              <span
                :class="contarDocumentos(row) === 4 ? 'documentos-ok' : 'documentos-falta'"
              >
                <CtIcon :name="contarDocumentos(row) === 4 ? 'check' : 'alert'" :size="14" />
                {{ contarDocumentos(row) }}/4 documentos
              </span>
              <span v-if="!listaParaAprobar(row)" class="documentos-falta">
                <CtIcon name="alert" :size="14" />
                Falta {{ pendientesDeDatos(row).join(' y ') }}
              </span>
            </div>
          </template>

          <template #cell-estado="{ row }">
            <StatusBadge type="postulacion" :value="row.estado" />
          </template>

          <template #cell-acciones="{ row }">
            <CtButton size="sm" variant="secondary" @click="abrirRevision(row)">Revisar</CtButton>
          </template>
        </CtTable>

        <p class="resumen">
          Mostrando {{ filtrados.length }} de {{ filas.length }}
          {{ filas.length === 1 ? 'postulación' : 'postulaciones' }} en la pestaña seleccionada.
        </p>
      </CtCard>
    </template>

    <!-- ==================== Revisión individual ==================== -->
    <CtModal
      v-model="revision.abierto"
      :title="revision.postulacion?.nombre_comercial_solicitado ?? 'Revisar postulación'"
      :subtitle="`Postulada ${formatDateTime(revision.postulacion?.creado_en)}`"
      size="lg"
    >
      <template v-if="revision.postulacion">
        <div class="detalle">
          <div class="detalle__identidad">
            <CtAvatar :name="representante(revision.postulacion)" :size="48" />
            <div>
              <p class="detalle__nombre">
                {{ representante(revision.postulacion) }}
              </p>
              <p class="detalle__meta">
                {{ revision.postulacion.region?.nombre ?? 'Sin región' }} ·
                {{ revision.postulacion.comuna?.nombre ?? 'Sin comuna' }}
              </p>
            </div>
            <StatusBadge
              type="postulacion"
              :value="revision.postulacion.estado"
              class="detalle__estado"
            />
          </div>

          <p v-if="revision.postulacion.descripcion" class="detalle__descripcion">
            {{ revision.postulacion.descripcion }}
          </p>

          <!--
            Datos que el administrador revisa a mano. No hay documentos
            de identidad: (retención del carnet) salió del alcance.
          -->
          <section class="documentos">
            <h3 class="eyebrow">Antecedentes de la solicitud</h3>
            <dl class="campos">
              <div class="campo">
                <dt>Representante</dt>
                <dd>{{ representante(revision.postulacion) }}</dd>
              </div>
              <div class="campo">
                <dt>Teléfono de contacto</dt>
                <dd>{{ revision.postulacion.perfil?.telefono ?? 'Sin teléfono registrado' }}</dd>
              </div>
              <div class="campo">
                <dt>Nombre comercial</dt>
                <dd>{{ revision.postulacion.nombre_comercial_solicitado }}</dd>
              </div>
              <!-- E2: identidad declarada por el solicitante, para contrastar
                   con los documentos adjuntos. -->
              <div class="campo">
                <dt>RUT del solicitante</dt>
                <dd class="mono">{{ revision.postulacion.rut_solicitante ?? 'Sin RUT registrado' }}</dd>
              </div>
              <div class="campo">
                <dt>Tipo de persona</dt>
                <dd>
                  {{ revision.postulacion.tipo_de_persona === 'juridica'
                    ? 'Persona jurídica (empresa)'
                    : revision.postulacion.tipo_de_persona === 'natural'
                      ? 'Persona natural'
                      : 'Sin declarar' }}
                </dd>
              </div>
              <div class="campo">
                <dt>Intento</dt>
                <dd>
                  {{ revision.postulacion.intento ?? 1 }} de
                  {{ 3 + (revision.postulacion.intentos_extra ?? 0) }} permitidos
                </dd>
              </div>
              <div class="campo">
                <dt>Dirección activa</dt>
                <dd>
                  <template v-if="revision.postulacion.direccion">
                    {{ revision.postulacion.direccion.calle }}
                    {{ revision.postulacion.direccion.numero ?? '' }} ·
                    {{ revision.postulacion.comuna?.nombre ?? 'Sin comuna' }}
                  </template>
                  <template v-else>Sin dirección activa</template>
                </dd>
              </div>
              <div class="campo">
                <dt>Región de cobertura</dt>
                <dd>{{ revision.postulacion.region?.nombre ?? 'Sin región registrada' }}</dd>
              </div>
              <div class="campo">
                <dt>Datos bancarios (Webpay Mall)</dt>
                <dd>
                  <template v-if="revision.postulacion.datosBancarios">
                    {{ revision.postulacion.datosBancarios.banco }} ·
                    {{ revision.postulacion.datosBancarios.tipo_cuenta }} ·
                    {{ revision.postulacion.datosBancarios.titular }} ·
                    {{ revision.postulacion.datosBancarios.rut_titular }}
                    <template v-if="revision.postulacion.datosBancarios.numeroCuenta">
                      · cuenta {{ revision.postulacion.datosBancarios.numeroCuenta }}
                    </template>
                  </template>
                  <template v-else-if="revision.postulacion.datosBancariosError">
                    No se pudieron consultar los datos bancarios:
                    {{ revision.postulacion.datosBancariosError }}. No apruebes hasta verificarlos.
                  </template>
                  <template v-else>Sin datos bancarios registrados</template>
                </dd>
              </div>
              <div class="campo" v-if="revision.postulacion.codigo_comercio_mall">
                <dt>Código de comercio Mall asignado</dt>
                <dd class="mono">{{ revision.postulacion.codigo_comercio_mall }}</dd>
              </div>
            </dl>
            <p class="detalle__meta">
              Verifica estos datos con el certificado bancario adjunto antes de aprobar la
              postulación.
            </p>
          </section>

          <!-- C1/C2: documentos KYB con descarga segura (URL firmada) y
               previsualización en pestaña nueva; el formato se lee de la ruta
               guardada en la BD, nunca del navegador del solicitante. -->
          <section class="documentos">
            <h3 class="eyebrow">Documentos de la postulación (KYB ·)</h3>
            <p class="detalle__meta">
              Se abren con una URL firmada de 60 segundos; nada queda publicado.
              Formatos aceptados por el bucket privado: PDF, JPG o PNG.
            </p>
            <ul class="documentos__lista">
              <li
                v-for="doc in documentosDe(revision.postulacion)"
                :key="doc.clave"
                class="documento"
              >
                <div class="documento__texto">
                  <span class="documento__tipo">{{ doc.etiqueta }}</span>
                  <span v-if="doc.disponible" class="documento__detalle">
                    {{ doc.formato }} · {{ (doc.ruta ?? '').split('/').pop() }}
                  </span>
                  <span v-else class="documento__detalle documento__falta">
                    Sin documento adjunto
                  </span>
                </div>
                <CtButton
                  size="sm"
                  variant="secondary"
                  :disabled="!doc.disponible || descargando[doc.clave]"
                  :loading="descargando[doc.clave]"
                  @click="abrirDocumento(revision.postulacion, doc)"
                >
                  <template #icon><CtIcon name="download" :size="14" /></template>
                  Ver / descargar
                </CtButton>
              </li>
            </ul>
          </section>

          <CtAlert
            v-if="!listaParaAprobar(revision.postulacion)"
            tone="warning"
            compact
            title="Falta información obligatoria para aprobar"
          >
            <p>
              La base de datos exige exactamente una dirección activa y los datos bancarios antes de
              activar la cuenta del vendedor. Falta:
              {{ pendientesDeDatos(revision.postulacion).join(' y ') }}. Puedes rechazar la
              solicitud. Puedes agregar un motivo; si lo dejas vacío, CuTuCo enviará una respuesta automática.
            </p>
          </CtAlert>

          <CtAlert tone="info" compact title="Comercio Mall asignado automáticamente">
            <p>
              Al aprobar, el backend asigna el comercio hijo configurado de Webpay Mall. Este
              código no se ingresa ni se decide en este formulario.
            </p>
          </CtAlert>

          <CtTextarea
            v-model="revision.observaciones"
            label="Observaciones para el productor"
            :maxlength="2500"
            show-count
            :rows="3"
            :hint="`Opcionales; si escribes un mensaje debe tener entre 10 y 2500 caracteres. Quedan archivadas en el historial de revisiones.`"
            placeholder="Explica el motivo de la decisión o las correcciones solicitadas."
          />

          <p v-if="revision.postulacion.revisado_en" class="detalle__revisado">
            Última revisión: {{ formatDateTime(revision.postulacion.revisado_en) }}
          </p>

          <!-- D4: decisiones anteriores de esta misma postulación, archivadas
               en postulaciones_revisiones con su intento y observaciones. -->
          <section v-if="historial.filas.length || historial.cargando" class="documentos">
            <h3 class="eyebrow">Historial de revisiones anteriores</h3>
            <CtSpinner v-if="historial.cargando" :size="20" label="Cargando historial…" />
            <table v-else class="historial">
              <thead>
                <tr>
                  <th>Intento</th>
                  <th>Decisión</th>
                  <th>Observaciones</th>
                  <th>Fecha</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="rev in historial.filas" :key="rev.id">
                  <td class="mono">#{{ rev.intento }}</td>
                  <td>
                    <CtBadge :tone="rev.estado === 'aprobada' ? 'success' : 'danger'" size="sm">
                      {{ LABELS.postulacion[rev.estado] ?? rev.estado }}
                    </CtBadge>
                  </td>
                  <td>{{ rev.observaciones_admin ?? '—' }}</td>
                  <td class="text-sm text-muted">{{ formatDateTime(rev.revisado_en) }}</td>
                </tr>
              </tbody>
            </table>
          </section>
        </div>
      </template>

      <template #footer>
        <CtButton variant="secondary" @click="cerrarRevision">Cerrar</CtButton>
        <!-- D2: una postulación aprobada o rechazada no admite una nueva
             decisión; los botones se ocultan y queda el detalle + reinicio. -->
        <template v-if="puedeResolver(revision.postulacion)">
          <CtButton variant="danger" @click="pedirAccion(revision.postulacion, 'rechazar')">
            <template #icon><CtIcon name="ban" :size="16" /></template>
            Rechazar
          </CtButton>
          <CtButton
            :disabled="!listaParaAprobar(revision.postulacion)"
            @click="pedirAccion(revision.postulacion, 'aprobar')"
          >
            <template #icon><CtIcon name="check" :size="16" /></template>
            Aprobar vendedor
          </CtButton>
        </template>
        <CtButton
          v-else-if="revision.postulacion?.estado === ESTADO_POSTULACION.RECHAZADA"
          variant="secondary"
          @click="pedirReinicio(revision.postulacion)"
        >
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Reiniciar intentos
        </CtButton>
      </template>
    </CtModal>

    <!-- ==================== Reinicio del límite de intentos (F) ==================== -->
    <CtModal
      v-model="reinicio.abierto"
      title="Reiniciar límite de intentos"
      subtitle="Autoriza un bloque extra de 3 envíos para esta postulación rechazada"
      size="md"
    >
      <CtAlert tone="info" compact title="Queda registro administrativo">
        <p>
          La decisión se guarda con tu usuario, la fecha y el motivo; el solicitante conserva el
          historial completo de revisiones. El límite normal de 3 intentos no se elimina.
        </p>
      </CtAlert>
      <p v-if="reinicio.postulacion" class="text-sm">
        Postulación: <strong>{{ reinicio.postulacion.nombre_comercial_solicitado }}</strong> ·
        intentos usados: {{ reinicio.postulacion.intento ?? 1 }} de
        {{ 3 + (reinicio.postulacion.intentos_extra ?? 0) }}.
      </p>
      <CtTextarea
        v-model="reinicio.motivo"
        label="Motivo de la autorización"
        :rows="3"
        :maxlength="1000"
        :hint="'Mínimo ' + MIN_MOTIVO_REINICIO + ' caracteres. Queda registrado en la auditoría.'"
        :error="reinicio.error"
        placeholder="Ej.: error transitorio del sistema impidió la carga de documentos; se autoriza reenvío."
      />
      <template #footer>
        <CtButton variant="secondary" @click="reinicio.abierto = false">Cancelar</CtButton>
        <CtButton
          :disabled="(reinicio.motivo ?? '').trim().length < MIN_MOTIVO_REINICIO"
          @click="aplicarReinicio"
        >
          Reiniciar intentos
        </CtButton>
      </template>
    </CtModal>

    <!-- ==================== Confirmación de decisión ==================== -->
    <CtConfirmDialog
      v-model="confirmacion.abierto"
      :title="confirmacion.accion === 'aprobar' ? 'Aprobar vendedor' : 'Rechazar postulación'"
      :confirm-label="confirmacion.accion === 'aprobar' ? 'Aprobar' : 'Rechazar'"
      :tone="confirmacion.accion === 'aprobar' ? 'primary' : 'danger'"
      :loading="guardando"
      :message="
        confirmacion.accion === 'aprobar'
          ? `Se creará el perfil de productor de ${confirmacion.pendientes[0]?.nombre_comercial_solicitado ?? ''} y podrá publicar en el catálogo.`
          : `La postulación de ${confirmacion.pendientes[0]?.nombre_comercial_solicitado ?? ''} quedará marcada como rechazada y el productor podrá leer tus observaciones.`
      "
      @confirm="aplicarAccion"
    />

    <!-- ==================== Verificación por lote ==================== -->
    <CtModal
      v-model="lote.abierto"
      title="Aprobar lote"
      subtitle="Aprobación agrupada de solicitudes con dirección y datos bancarios completos"
      size="md"
    >
      <CtAlert tone="info" compact title="Comercio Mall automático">
        <p>
          Cada aprobación usa el comercio hijo configurado de Webpay Mall en el backend. No debes
          copiar ni ingresar códigos de Transbank para este lote.
        </p>
      </CtAlert>

      <CtAlert v-if="!candidatasLote.length" tone="warning" compact title="Sin candidatas">
        <p>
          No hay solicitudes pendientes con dirección activa y datos bancarios registrados. Pídele
          al vendedor que complete esos datos antes de aprobar su cuenta.
        </p>
      </CtAlert>

      <ul v-else class="lote">
        <li v-for="postulacion in candidatasLote" :key="postulacion.id" class="lote__item">
          <label class="lote__check">
            <input
              type="checkbox"
              :checked="lote.seleccionados.includes(postulacion.id)"
              @change="alternarSeleccion(postulacion.id)"
            />
            <span>
              <span class="lote__nombre">{{ postulacion.nombre_comercial_solicitado }}</span>
              <span class="lote__meta">
                {{ representante(postulacion) }} ·
                {{ postulacion.comuna?.nombre ?? 'Sin comuna' }} ·
                {{ formatDate(postulacion.creado_en) }}
              </span>
            </span>
          </label>
        </li>
      </ul>

      <template #footer>
        <CtButton variant="secondary" @click="lote.abierto = false">Cancelar</CtButton>
        <CtButton
          :loading="guardando"
          :disabled="!lote.seleccionados.length"
          @click="verificarLote"
        >
          Verificar {{ lote.seleccionados.length }} postulación(es)
        </CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.barra {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-4);
}

.barra__buscador {
  max-width: 420px;
}

.productor {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.productor__texto {
  min-width: 0;
}

.productor__nombre {
  font-weight: var(--ct-fw-semibold);
}

.productor__detalle {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.documentos-celda {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.historial {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--ct-fs-sm);
}

.historial th,
.historial td {
  text-align: left;
  padding: var(--ct-space-2) var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
  vertical-align: top;
}

.documentos__lista .documento {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.documento__falta {
  color: var(--ct-text-muted);
  font-style: italic;
}

.documentos-ok,
.documentos-falta {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-1);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-medium);
}

.documentos-ok {
  color: var(--ct-success-ink);
}

.documentos-falta {
  color: var(--ct-danger-strong);
}

.resumen {
  margin-top: var(--ct-space-4);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.detalle {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.detalle__identidad {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.detalle__identidad > div {
  flex: 1;
  min-width: 0;
}

.detalle__nombre {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
}

.detalle__meta,
.detalle__revisado {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.detalle__descripcion {
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
}

.documentos__lista {
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--ct-space-4);
  margin-top: var(--ct-space-3);
}

.documento {
  display: flex;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
}

.documento__vista {
  width: 72px;
  height: 92px;
  object-fit: cover;
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface-alt);
  flex-shrink: 0;
}

.documento__texto {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.documento__tipo {
  font-weight: var(--ct-fw-semibold);
  font-size: var(--ct-fs-md);
}

.documento__detalle,
.documento__vencimiento {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.documento__vencimiento {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.lote {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  max-height: 340px;
  overflow-y: auto;
}

.lote__item {
  padding: var(--ct-space-2);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
}

.lote__check {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  cursor: pointer;
}

.lote__check input {
  width: 16px;
  height: 16px;
  margin-top: 3px;
  accent-color: var(--ct-primary-strong);
}

.lote__nombre {
  display: block;
  font-weight: var(--ct-fw-semibold);
}

.lote__meta {
  display: block;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}
</style>
