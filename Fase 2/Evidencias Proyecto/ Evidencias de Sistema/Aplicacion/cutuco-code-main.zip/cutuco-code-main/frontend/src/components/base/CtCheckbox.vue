<script setup>
/** CuTuCo — Casilla de verificación. */
const props = defineProps({
  modelValue: { type: Boolean, default: false },
  label: { type: String, default: null },
  description: { type: String, default: null },
  disabled: { type: Boolean, default: false },
  error: { type: String, default: null },
  value: { type: [String, Number], default: null },
})

const emit = defineEmits(['update:modelValue'])

function toggle() {
  if (props.disabled) return
  emit('update:modelValue', !props.modelValue)
}
</script>

<template>
  <label class="ct-check" :class="{ 'is-disabled': disabled }">
    <input
      type="checkbox"
      class="ct-check__input"
      :checked="modelValue"
      :disabled="disabled"
      @change="toggle"
    />
    <span class="ct-check__box" aria-hidden="true">
      <svg viewBox="0 0 16 16" width="12" height="12">
        <path d="M3 8.5l3 3 7-7" fill="none" stroke="currentcolor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" />
      </svg>
    </span>
    <span class="ct-check__text">
      <span v-if="label" class="ct-check__label">{{ label }}</span>
      <span v-if="description" class="ct-check__description">{{ description }}</span>
      <span v-if="error" class="ct-check__error">{{ error }}</span>
    </span>
  </label>
</template>

<style scoped>
.ct-check {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  cursor: pointer;
  user-select: none;
}

.ct-check.is-disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.ct-check__input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.ct-check__box {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: var(--ct-radius-sm);
  border: 1.5px solid var(--ct-border-strong);
  background: var(--ct-surface);
  color: transparent;
  flex-shrink: 0;
  margin-top: 1px;
  transition:
    background-color var(--ct-transition),
    border-color var(--ct-transition),
    color var(--ct-transition);
}

.ct-check__input:checked + .ct-check__box {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

/* Previsualiza el estado marcado al pasar el puntero sin marcar. */
.ct-check__input:not(:checked):hover + .ct-check__box {
  border-color: var(--ct-primary);
}

.ct-check__input:focus-visible + .ct-check__box {
  box-shadow: var(--ct-shadow-focus);
}

.ct-check__text {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ct-check__label {
  font-size: var(--ct-fs-md);
  line-height: 1.4;
}

.ct-check__description {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.ct-check__error {
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
}
</style>
