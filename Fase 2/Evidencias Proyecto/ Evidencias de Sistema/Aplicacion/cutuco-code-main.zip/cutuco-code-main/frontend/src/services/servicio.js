import { apiFetch, getClient } from '@/lib/supabase'
import { ESTADO_SERVICIO, ESTADO_TIENDA_SERVICIO, REGLAS_SERVICIO } from '@/lib/constants'
import { mensajeSeguro } from '@/services/errores'
import { unwrap } from '@/services/session'

/* ------------------------------------------------------------------ */
/* Servicio mensual de la plataforma                                   */
/* ------------------------------------------------------------------ */

function normalizarObjeto(data) {
  if (Array.isArray(data)) return data[0] ?? null
  return data ?? null
}

function normalizarLista(data) {
  if (!data) return []
  if (Array.isArray(data)) return data
  return [data]
}

export const DATOS_TRANSFERENCIA_CUTUCO_VACIOS = Object.freeze({
  banco: '',
  tipoCuenta: '',
  numeroCuenta: '',
  titular: '',
  rut: '',
  actualizadoEn: null,
})

function textoSeguro(valor) {
  return String(valor ?? '').trim()
}

/** Normaliza la fila singleton para no propagar nulls a las vistas. */
export function normalizarDatosTransferenciaCutuco(fila) {
  return {
    banco: textoSeguro(fila?.banco),
    tipoCuenta: textoSeguro(fila?.tipo_cuenta),
    numeroCuenta: textoSeguro(fila?.numero_cuenta),
    titular: textoSeguro(fila?.titular),
    rut: textoSeguro(fila?.rut),
    actualizadoEn: fila?.actualizado_en ?? null,
  }
}

/**
 * Cuenta de destino para la cuota mensual. RLS permite la lectura sólo a
 * vendedores activos y a administración; una cuenta aún sin configurar se
 * representa con todos sus campos vacíos.
 */
export async function obtenerDatosTransferenciaCutuco() {
  const client = getClient()
  const { data, error } = await client
    .from('cuenta_transferencia_servicio')
    .select('banco, tipo_cuenta, numero_cuenta, titular, rut, actualizado_en')
    .eq('id', 1)
    .maybeSingle()
  if (error) {
    throw new Error(
      mensajeSeguro(error, 'No se pudieron cargar los datos bancarios para la transferencia.'),
    )
  }
  return normalizarDatosTransferenciaCutuco(data)
}

/** Actualiza la cuenta de destino. La autorización queda resguardada por RLS. */
export async function actualizarDatosTransferenciaCutuco(datos) {
  const client = getClient()
  const payload = {
    banco: textoSeguro(datos?.banco) || null,
    tipo_cuenta: textoSeguro(datos?.tipoCuenta) || null,
    numero_cuenta: textoSeguro(datos?.numeroCuenta) || null,
    titular: textoSeguro(datos?.titular) || null,
    rut: textoSeguro(datos?.rut) || null,
  }
  const { data, error } = await client
    .from('cuenta_transferencia_servicio')
    .update(payload)
    .eq('id', 1)
    .select('banco, tipo_cuenta, numero_cuenta, titular, rut, actualizado_en')
    .single()
  if (error) {
    throw new Error(
      mensajeSeguro(error, 'No se pudieron guardar los datos bancarios para la transferencia.'),
    )
  }
  return normalizarDatosTransferenciaCutuco(data)
}

export async function getMiServicio() {
  const client = getClient()
  const { data, error } = await client.rpc('mi_servicio')
  if (error) throw new Error('No se pudo cargar el estado del servicio')
  const servicio = normalizarObjeto(data)
  if (!servicio || servicio.estado === ESTADO_TIENDA_SERVICIO.SIN_PRODUCTOR) {
    return { estado: ESTADO_TIENDA_SERVICIO.SIN_PRODUCTOR, cuota: null, historial: [] }
  }
  return {
    ...servicio,
    historial: normalizarLista(servicio.historial),
  }
}

export async function listPagosServicio() {
  const client = getClient()
  const { data, error } = await client
    .from('pagos_servicio')
    .select('*')
    .order('periodo', { ascending: false })
  return unwrap({ data, error }, 'No se pudo cargar el historial de pagos del servicio')
}

/** Historial completo de cobros del servicio para administración (RLS admin). */
export async function listPagosServicioAdmin() {
  return listPagosServicio()
}

export async function registrarTransferenciaServicio({ referencia, observaciones = '' }) {
  const referenciaLimpia = String(referencia ?? '').trim()
  if (!referenciaLimpia) {
    throw new Error('Ingresa el número de operación de la transferencia.')
  }
  const client = getClient()
  const { data, error } = await client.rpc('registrar_transferencia_servicio', {
    p_referencia: referenciaLimpia,
    p_observaciones: String(observaciones ?? '').trim() || null,
  })
  if (error) throw new Error('No se pudo registrar la transferencia')
  return normalizarObjeto(data)
}

export async function iniciarPagoServicioWebpay() {
  return apiFetch('/api/servicio/iniciar', { method: 'POST' })
}

export async function listServiciosAdmin() {
  const client = getClient()
  const { data, error } = await client.rpc('admin_servicio_resumen')
  if (error) throw new Error('No se pudo cargar el estado del servicio de los vendedores')
  return normalizarLista(data)
}

export async function listPagosServicioPendientes() {
  const client = getClient()
  const { data, error } = await client
    .from('pagos_servicio')
    .select('*')
    .eq('estado', ESTADO_SERVICIO.PENDIENTE_REVISION)
    .order('periodo', { ascending: true })
  return unwrap({ data, error }, 'No se pudieron cargar los pagos pendientes de revisión')
}

export async function resolverPagoServicio(pagoId, estado, observaciones = '') {
  const client = getClient()
  const { data, error } = await client.rpc('resolver_pago_servicio', {
    p_pago_id: pagoId,
    p_estado: estado,
    p_observaciones: String(observaciones ?? '').trim() || null,
  })
  if (error) throw new Error('No se pudo resolver el pago del servicio')
  return normalizarObjeto(data)
}

export async function actualizarMorosidadServicio() {
  const client = getClient()
  const { data, error } = await client.rpc('actualizar_morosidad_servicio')
  if (error) throw new Error('No se pudo actualizar la morosidad del servicio')
  return Number(data ?? 0)
}

export function etiquetaEstadoServicio(estado) {
  const etiquetas = {
    [ESTADO_TIENDA_SERVICIO.AL_DIA]: 'Al día',
    [ESTADO_TIENDA_SERVICIO.PENDIENTE]: 'Pago pendiente',
    [ESTADO_TIENDA_SERVICIO.PENDIENTE_REVISION]: 'Pago en revisión',
    [ESTADO_TIENDA_SERVICIO.VENCIDO]: 'Vencido / suspendido',
    [ESTADO_TIENDA_SERVICIO.SIN_PRODUCTOR]: 'Sin tienda',
    [ESTADO_SERVICIO.PAGADO]: 'Pagado',
    [ESTADO_SERVICIO.PENDIENTE]: 'Pendiente',
    [ESTADO_SERVICIO.PENDIENTE_REVISION]: 'Pendiente de revisión',
    [ESTADO_SERVICIO.RECHAZADO]: 'Rechazado',
  }
  return etiquetas[estado] ?? String(estado ?? 'Sin estado')
}

export function tonoEstadoServicio(estado) {
  if (estado === ESTADO_TIENDA_SERVICIO.AL_DIA || estado === ESTADO_SERVICIO.PAGADO)
    return 'success'
  if (
    estado === ESTADO_TIENDA_SERVICIO.PENDIENTE_REVISION ||
    estado === ESTADO_SERVICIO.PENDIENTE_REVISION ||
    estado === ESTADO_SERVICIO.PENDIENTE
  )
    return 'warning'
  if (estado === ESTADO_TIENDA_SERVICIO.VENCIDO || estado === ESTADO_SERVICIO.RECHAZADO)
    return 'danger'
  return 'neutral'
}

/** Días restantes antes de la suspensión (puede ser negativo). */
export function diasHastaSuspension(cuota) {
  if (!cuota?.vence_en) return null
  const vence = parseFechaISO(cuota.vence_en)
  if (!vence) return null
  const partes = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date())
  const parte = (tipo) => partes.find((p) => p.type === tipo)?.value
  const hoy = parseFechaISO(`${parte('year')}-${parte('month')}-${parte('day')}`)
  return (vence - hoy) / 86400000 + REGLAS_SERVICIO.diasGracia
}

/* ------------------------------------------------------------------ */
/* Plazos de la cuota (HAL-VEN-019)                                    */
/* ------------------------------------------------------------------ */

/**
 * Interpreta una fecha `YYYY-MM-DD` como día calendario, sin hora ni zona.
 * Se usa UTC para que la aritmética no cambie con el horario de verano.
 */
function parseFechaISO(fecha) {
  const coincidencia = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(fecha ?? ''))
  if (!coincidencia) return null
  const [, anio, mes, dia] = coincidencia.map(Number)
  const fechaUTC = new Date(Date.UTC(anio, mes - 1, dia))
  return Number.isNaN(fechaUTC.getTime()) ? null : fechaUTC
}

function sumarDiasISO(fecha, dias) {
  const base = parseFechaISO(fecha)
  if (!base) return null
  base.setUTCDate(base.getUTCDate() + Number(dias))
  return base.toISOString().slice(0, 10)
}

/**
 * Deriva las fechas de la cuota desde la única fecha que expone `mi_servicio()`:
 * `vence_en`.
 *
 * Regla implementada por la migración 20261029000000:
 *   * la cuota se emite y su `vence_en` se fija 10 días después de la emisión;
 *   * hay 5 días de gracia posteriores al vencimiento;
 *   * la tienda se suspende desde el día siguiente al último día de gracia
 *     (`vence_en + 5 < current_date` en `private.estado_servicio`).
 *
 * `mi_servicio()` no devuelve `creado_en`; por eso la emisión se deriva
 * restando los 10 días al vencimiento. Si el backend agrega `creado_en`, basta
 * con preferirlo aquí sin cambiar la vista.
 *
 * @param {object|null} cuota fila de `pagos_servicio`
 * @param {{diasVencimiento?:number,diasGracia?:number}} reglas
 * @returns {{emision:string,vence:string,graciaHasta:string,suspensionDesde:string,periodo:string|null,diasVencimiento:number,diasGracia:number}|null}
 */
export function fechasCuotaServicio(cuota, reglas = REGLAS_SERVICIO) {
  const diasVencimiento = Number(reglas?.diasVencimiento ?? REGLAS_SERVICIO.diasVencimiento)
  const diasGracia = Number(reglas?.diasGracia ?? REGLAS_SERVICIO.diasGracia)
  const vence = parseFechaISO(cuota?.vence_en)
  if (!vence) return null

  const emision = cuota?.emitido_en
    ? String(cuota.emitido_en).slice(0, 10)
    : sumarDiasISO(cuota.vence_en, -diasVencimiento)

  return {
    periodo: cuota?.periodo ?? null,
    emision,
    vence: String(cuota.vence_en).slice(0, 10),
    graciaHasta: sumarDiasISO(cuota.vence_en, diasGracia),
    suspensionDesde: sumarDiasISO(cuota.vence_en, diasGracia + 1),
    diasVencimiento,
    diasGracia,
  }
}
