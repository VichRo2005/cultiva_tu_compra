import { mensajeSeguro } from '@/services/errores'
import { subtotalCLP } from '@/lib/pricing'
/**
 * CuTuCo — Servicio de catálogo público (RF-002 y RF-022).
 *
 * El visitante explora el catálogo sin sesión: buscador, filtros por categoría
 * y región, ficha de producto con su precio. Las consultas van directo a
 * PostgREST (RLS pública sobre productos/productores activos).
 */

import { getClient, storageUrl } from '@/lib/supabase'
import { STORAGE_BUCKETS, UNIDAD_MEDIDA, UNIDADES_FRACCIONABLES } from '@/lib/constants'
import { placeholderImage } from '@/lib/images'
import { unwrap } from '@/services/session'
import { listComunas, listRegiones } from '@/services/geography'

/* ---------------------------------------------------------------- */
/* Reglas de presentación del catálogo                               */
/* ---------------------------------------------------------------- */

/** Límite de la búsqueda pública (HAL-CLI-019): se recorta, nunca se envía cruda. */
export const TEXTO_BUSQUEDA_MAX = 100

/**
 * Categorías fuera del alcance vigente (HAL-CLI-021). La limpieza definitiva la
 * hace el catálogo maestro; mientras tanto la UI las oculta, junto con sus
 * subcategorías y productos, para no ofrecer algo que el proyecto no contempla.
 */
const CATEGORIAS_FUERA_DE_ALCANCE = Object.freeze(['alimentos para mascotas'])

/**
 * Unidades que se venden por peso o volumen y admiten fracciones.
 * Vive en `@/lib/constants` (UNIDADES_FRACCIONABLES) para que el carrito, el
 * stepper de cantidad y el catálogo usen exactamente la misma lista.
 */

/** Texto comparable: minúsculas, sin tildes, sin espacios repetidos ni externos. */
export function normalizarTextoComparable(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim()
}

/** Texto de búsqueda legible: conserva mayúsculas/acentos y recorta los extremos. */
export function limpiarTextoBusqueda(value) {
  return String(value ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, TEXTO_BUSQUEDA_MAX)
}

/** Texto de búsqueda normalizado para comparar. */
export function normalizarBusqueda(value) {
  return normalizarTextoComparable(limpiarTextoBusqueda(value))
}

/**
 * Búsqueda por nombre parcial, sin distinguir mayúsculas ni tildes. El texto se
 * compara como literal: un `<script>` nunca se interpreta como HTML.
 */
export function coincideBusqueda(producto, texto) {
  const termino = normalizarBusqueda(texto)
  if (!termino) return true
  return normalizarTextoComparable(producto?.nombre).includes(termino)
}

/** ¿La categoría (nodo u objeto) está fuera de alcance? */
export function esCategoriaFueraDeAlcance(categoria) {
  const nombre =
    typeof categoria === 'string' ? categoria : categoria?.nombre ?? categoria?.label ?? ''
  return CATEGORIAS_FUERA_DE_ALCANCE.includes(normalizarTextoComparable(nombre))
}

/** Unifica "Sin categoría" / "Sin Categoría" y evita duplicados visuales. */
export function normalizarNombreCategoria(nombre) {
  const texto = String(nombre ?? '').trim()
  if (!texto) return 'Sin categoría'
  if (normalizarTextoComparable(texto) === 'sin categoria') return 'Sin categoría'
  return texto
}

/**
 * Filtra el árbol de categorías: quita las categorías fuera de alcance con sus
 * descendientes, normaliza "Sin categoría"/"Sin Categoría" y elimina duplicados
 * entre hermanos (HAL-VEN-006 y HAL-CLI-021).
 */
export function filtrarCategoriasVisibles(nodos = []) {
  const filtrarNivel = (lista) => {
    const vistos = new Set()
    return (Array.isArray(lista) ? lista : []).flatMap((nodo) => {
      if (!nodo || esCategoriaFueraDeAlcance(nodo)) return []
      const nombre = nodo.nombre ?? nodo.label ?? ''
      const clave = normalizarTextoComparable(nombre)
      if (!clave || vistos.has(clave)) return []
      vistos.add(clave)
      return [
        {
          ...nodo,
          ...(nodo.nombre != null ? { nombre: normalizarNombreCategoria(nodo.nombre) } : {}),
          ...(nodo.label != null ? { label: normalizarNombreCategoria(nodo.label) } : {}),
          hijos: filtrarNivel(nodo.hijos ?? []),
        },
      ]
    })
  }
  return filtrarNivel(nodos)
}

/** ¿El producto pertenece a una categoría (o subcategoría) fuera de alcance? */
export function esProductoDeCategoriaOculta(producto) {
  return [producto?.categoria, producto?.categoriaPadre].some(esCategoriaFueraDeAlcance)
}

/** Descarta productos de categorías fuera de alcance (HAL-CLI-021). */
export function filtrarProductosVisibles(productos = []) {
  return (Array.isArray(productos) ? productos : []).filter(
    (producto) => !esProductoDeCategoriaOculta(producto),
  )
}

/** ¿La unidad comercial admite fracciones? (HAL-CLI-008 y HAL-CLI-009) */
export function esUnidadFraccionable(unidad) {
  return UNIDADES_FRACCIONABLES.includes(String(unidad ?? '').toLowerCase())
}

/** Redondeo decimal estable para cantidades. */
export function redondearCantidad(value, decimales = 1) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 0
  const factor = 10 ** Math.max(0, Math.min(6, Number(decimales) || 0))
  return Math.round((n + Number.EPSILON) * factor) / factor
}

function cantidadPositiva(value, fallback) {
  const cantidad = Number(value)
  return Number.isFinite(cantidad) && cantidad > 0 ? cantidad : fallback
}

/** Determina si una cantidad es múltiplo de su incremento comercial. */
export function esMultiploDeIncremento(cantidad, incremento) {
  const cantidadEscalada = Math.round(Number(cantidad) * 10)
  const incrementoEscalado = Math.round(Number(incremento) * 10)
  if (!Number.isFinite(cantidadEscalada) || incrementoEscalado <= 0) return false
  return cantidadEscalada % incrementoEscalado === 0
}

/**
 * Cantidad mínima, paso, inicial y máximo real de un producto.
 *
 * Cada publicación puede definir su `incremento_venta` y
 * `cantidad_minima_compra`. Los productos anteriores a esta regla conservan
 * el paso histórico (0,1 en unidades fraccionables y 1 en discretas).
 *
 * Las cantidades comerciales se almacenan con hasta un decimal. Así el mismo
 * límite se aplica a stock, compra mínima, incrementos y checkout.
 */
export function configuracionCantidadProducto(producto = {}) {
  const unidad = String(producto?.unidad_medida ?? 'unidad')
  const fraccionable = esUnidadFraccionable(unidad)
  const pasoHistorico = fraccionable ? 0.1 : 1
  const decimales = fraccionable ? 1 : 0
  const paso = redondearCantidad(
    cantidadPositiva(producto?.incremento_venta, pasoHistorico),
    decimales,
  )
  const minimo = redondearCantidad(
    cantidadPositiva(producto?.cantidad_minima_compra, paso),
    decimales,
  )
  // Una respuesta antigua aún podría traer más precisión que la permitida.
  // Se trunca el disponible para no prometer una fracción que el inventario
  // real no puede cubrir; los datos persistidos ya quedan normalizados a una
  // décima mediante la migración y las validaciones.
  const stockBruto = Number(producto?.stock ?? 0)
  const factorStock = 10 ** decimales
  const stock = Number.isFinite(stockBruto)
    ? Math.floor((stockBruto + Number.EPSILON) * factorStock) / factorStock
    : 0
  const hayStock = Number.isFinite(stock) && stock > 0
  // Trabajar en enteros evita que 2,3 / 0,1 se evalúe como 22,999… y se
  // oculte una décima que el cliente sí puede comprar.
  const stockEscalado = Math.floor((stock + Number.EPSILON) * factorStock)
  const pasoEscalado = Math.round(paso * factorStock)
  const max = hayStock && pasoEscalado > 0
    ? Math.floor(stockEscalado / pasoEscalado) * pasoEscalado / factorStock
    : 0
  const agotado = !hayStock || max + 1e-9 < minimo
  return {
    unidad,
    fraccionable,
    paso,
    decimales,
    min: minimo,
    max,
    inicial: minimo,
    agotado,
  }
}

/** Valida una cantidad contra mínimo, máximo, unidad discreta y paso comercial. */
export function esCantidadValida(cantidad, configuracion = {}) {
  if (cantidad === null || cantidad === undefined || cantidad === '') return false
  const n = Number(cantidad)
  if (!Number.isFinite(n) || n <= 0) return false
  const min = Number(configuracion.min ?? 1)
  const max = Number(configuracion.max ?? 0)
  const paso = Number(configuracion.paso ?? 1)
  const decimales = Number(configuracion.decimales ?? 0)
  if (n + 1e-9 < min || n - 1e-9 > max) return false
  if (Math.abs(n - redondearCantidad(n, decimales)) > 1e-9) return false
  if (paso > 0 && !esMultiploDeIncremento(n, paso)) return false
  return true
}

/** Total de la línea con el precio por unidad comercial (CLP entero). */
export function calcularTotalProducto(precio, cantidad) {
  const n = Number(cantidad)
  if (!Number.isFinite(n) || n <= 0) return 0
  return subtotalCLP(precio ?? 0, n)
}

/**
 * Formatea una cantidad conservando la unidad comercial y sus decimales reales
 * (HAL-CLI-008): 10 kg, 0,5 kg, 3 unidades. Las unidades fraccionables
 * muestran hasta un decimal; las discretas, sólo enteros.
 */
export function formatearCantidad(valor, unidad) {
  const n = Number(valor)
  if (!Number.isFinite(n)) return '0'
  const maximoDecimales = esUnidadFraccionable(unidad) ? 1 : 0
  return new Intl.NumberFormat('es-CL', {
    maximumFractionDigits: maximoDecimales,
  }).format(n)
}

/**
 * Estado de reputación: un resumen con calificación o el estado vacío, nunca
 * ambos (HAL-CLI-005). La lista detallada puede venir vacía aunque el resumen
 * tenga evaluaciones; en ese caso sigue habiendo resumen.
 */
export function estadoCalificacion({
  cantidadEvaluaciones = 0,
  evaluaciones = [],
} = {}) {
  // `puntaje_reputacion` arranca en 5.00 por defecto en el esquema: por sí solo
  // no acredita que existan evaluaciones. La fuente de verdad es la cantidad
  // registrada o la lista de evaluaciones.
  const total = Number(cantidadEvaluaciones ?? 0)
  const detalle = Array.isArray(evaluaciones) ? evaluaciones.length : 0
  const tieneResumen = (Number.isFinite(total) && total > 0) || detalle > 0
  return tieneResumen ? 'resumen' : 'vacio'
}

/** Filtra productos de una región comparando la región derivada del vendedor. */
export function filtrarProductosPorRegion(items = [], regionPorProductor = new Map(), regionId) {
  if (!regionId) return Array.isArray(items) ? items : []
  const objetivo = String(regionId)
  return (Array.isArray(items) ? items : []).filter(
    (producto) =>
      String(regionPorProductor?.get?.(producto?.productor_id)?.id ?? '') === objetivo,
  )
}

/** Filtros del catálogo leídos desde la URL (región, búsqueda, categoría, etc.). */
export function leerFiltrosCatalogo(query = {}) {
  const texto = (valor) => (valor == null ? '' : String(valor))
  return {
    texto: limpiarTextoBusqueda(texto(query.q)),
    categoriaId: texto(query.categoria),
    subcategoriaId: texto(query.subcategoria),
    regionId: texto(query.region),
    productorId: texto(query.productor),
    precioMin: query.min == null || query.min === '' ? '' : String(query.min),
    precioMax: query.max == null || query.max === '' ? '' : String(query.max),
    fechaCosecha: texto(query.cosecha),
    orden: texto(query.orden) || 'relevancia',
    page: Math.max(1, Number.parseInt(query.page, 10) || 1),
  }
}

/** Query string del catálogo, sin parámetros vacíos ni valores por defecto. */
export function construirQueryCatalogo(filters = {}, page = 1) {
  const query = {}
  const texto = limpiarTextoBusqueda(filters.texto)
  if (texto) query.q = texto
  if (filters.categoriaId) query.categoria = String(filters.categoriaId)
  if (filters.subcategoriaId) query.subcategoria = String(filters.subcategoriaId)
  if (filters.regionId) query.region = String(filters.regionId)
  if (filters.productorId) query.productor = String(filters.productorId)
  if (filters.precioMin !== '' && filters.precioMin != null) query.min = String(filters.precioMin)
  if (filters.precioMax !== '' && filters.precioMax != null) query.max = String(filters.precioMax)
  if (filters.fechaCosecha) query.cosecha = String(filters.fechaCosecha)
  if (filters.orden && filters.orden !== 'relevancia') query.orden = filters.orden
  if (Number(page) > 1) query.page = String(page)
  return query
}

/* ---------------------------------------------------------------- */
/* Categorías                                                        */
/* ---------------------------------------------------------------- */

export async function listCategorias({ includeDeleted = false } = {}) {
  const client = getClient()
  let query = client.from('categorias').select('*')
  if (!includeDeleted) query = query.is('eliminado_en', null)
  const { data, error } = await query.order('nombre', { ascending: true })
  return unwrap({ data, error }, 'No se pudieron cargar las categorías')
}

/** Árbol de categorías (categoría padre -> subcategorías). */
export async function getArbolCategorias({ includeDeleted = false } = {}) {
  const categorias = await listCategorias({ includeDeleted })
  const nodos = new Map(categorias.map((c) => [c.id, { ...c, hijos: [] }]))
  const raices = []
  for (const nodo of nodos.values()) {
    if (nodo.categoria_padre_id && nodos.has(nodo.categoria_padre_id)) {
      nodos.get(nodo.categoria_padre_id).hijos.push(nodo)
    } else {
      raices.push(nodo)
    }
  }
  // HAL-CLI-021: el árbol público nunca ofrece "Alimentos para mascotas".
  return filtrarCategoriasVisibles(raices)
}

/**
 * Convierte una lista plana de categorías (con `categoria_padre_id`) en árbol
 * padre → hijos. Si el padre no está en la lista, el nodo pasa a ser raíz.
 */
export function arbolDesdeListaPlana(lista = []) {
  const nodos = new Map((Array.isArray(lista) ? lista : []).map((c) => [c.id, { ...c, hijos: [] }]))
  const raices = []
  for (const nodo of nodos.values()) {
    const padreId = nodo.categoria_padre_id ?? nodo.parent_id ?? null
    if (padreId && nodos.has(padreId)) nodos.get(padreId).hijos.push(nodo)
    else raices.push(nodo)
  }
  return raices
}

/**
 * HAL-VEN-006: opciones jerárquicas para `CtSelect` (soporta `group`/optgroup).
 *
 * Las categorías padre van como opciones de primer nivel y cada subcategoría
 * queda agrupada bajo el nombre de su padre, así el combobox no mezcla niveles.
 * Se reutiliza `filtrarCategoriasVisibles` para quitar las fuera de alcance
 * (HAL-CLI-021), normalizar "Sin categoría"/"Sin Categoría" y evitar duplicados.
 */
export function opcionesCategoriasJerarquicas(nodos = []) {
  const opciones = []
  for (const nodo of filtrarCategoriasVisibles(Array.isArray(nodos) ? nodos : [])) {
    const nombrePadre = normalizarNombreCategoria(nodo.nombre ?? nodo.label)
    opciones.push({ value: nodo.id, label: nombrePadre })
    for (const hijo of nodo.hijos ?? []) {
      opciones.push({
        value: hijo.id,
        label: normalizarNombreCategoria(hijo.nombre ?? hijo.label),
        group: nombrePadre,
      })
    }
  }
  return opciones
}

export async function getCategoria(categoriaId) {
  if (!categoriaId) return null
  const client = getClient()
  const { data, error } = await client.from('categorias').select('*').eq('id', categoriaId).maybeSingle()
  if (error) throw new Error('No se pudo consultar la categoría. Inténtalo de nuevo.')
  return data
}

export async function createCategoria({ nombre, slug, categoriaPadreId = null, esSistema = false }) {
  const client = getClient()
  return unwrap(
    await client
      .from('categorias')
      .insert({
        nombre,
        slug: slug || slugify(nombre),
        categoria_padre_id: categoriaPadreId,
        es_sistema: esSistema,
      })
      .select()
      .single(),
    'No se pudo crear la categoría',
  )
}

export async function updateCategoria(id, patch) {
  const client = getClient()
  return unwrap(
    await client.from('categorias').update(patch).eq('id', id).select().single(),
    'No se pudo actualizar la categoría',
  )
}

/** RF-017: baja lógica de categoría (el trigger reasigna a "Sin Categoría"). */
export async function eliminarCategoria(id) {
  const client = getClient()
  return unwrap(
    await client.from('categorias').update({ eliminado_en: new Date().toISOString() }).eq('id', id),
    'No se pudo eliminar la categoría',
  )
}

export function slugify(text) {
  return String(text)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

/* ---------------------------------------------------------------- */
/* Productores                                                       */
/* ---------------------------------------------------------------- */

export async function listProductores({ onlyActive = false } = {}) {
  const client = getClient()
  let query = client.from('productores').select('*')
  if (onlyActive) query = query.eq('activo', true).eq('servicio_suspendido', false)
  const { data, error } = await query.order('nombre_comercial', { ascending: true })
  return unwrap({ data, error }, 'No se pudieron cargar los vendedores')
}

export async function getProductor(productorId) {
  if (!productorId) return null
  const client = getClient()
  const { data, error } = await client.from('productores').select('*').eq('id', productorId).maybeSingle()
  if (error) throw new Error('No se pudo consultar el vendedor. Inténtalo de nuevo.')
  return data
}

/**
 * Vendedores activos de una región (RF-009).
 *
 * Se apoya en la columna derivada `productores.region_id`, que mantiene el
 * trigger `trg_sincronizar_region_productor` a partir de la dirección activa del
 * vendedor. No se consulta `direcciones`: su RLS la expone sólo a su dueño o a un
 * administrador, así que un join público no es posible ni necesario.
 * @returns {Promise<Array>} productores activos de la región, por nombre
 */
export async function listProductoresPorRegion(regionId) {
  if (!regionId) return []
  const client = getClient()
  const { data, error } = await client
    .from('productores')
    .select('*')
    .eq('region_id', regionId)
    .eq('activo', true)
    .eq('servicio_suspendido', false)
    .order('nombre_comercial', { ascending: true })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/**
 * Detalle público del vendedor: perfil, región de cobertura, catálogo activo y
 * primeras calificaciones (RF-006 y RF-009).
 *
 * La dirección concreta del vendedor NO es pública (RLS): se publica su región
 * de cobertura y la comuna de referencia.
 */
export async function getProductorDetalle(productorId) {
  const client = getClient()
  const productor = await getProductor(productorId)
  if (!productor) return null

  /*
   * HAL-CLI-005/006: el perfil público y sus reseñas se leen por RPC.
   * `perfiles` y `evaluaciones_reputacion` tienen RLS de propietario/admin; una
   * consulta directa como anon devolvía 401 y dejaba el perfil sin nombre,
   * teléfono ni calificaciones. Las RPC exponen sólo los campos públicos del
   * productor activo.
   */
  const [perfilRes, productosRes, evaluacionesRes] = await Promise.all([
    client.rpc('perfil_publico_productor', { p_productor_id: productorId }),
    client
      .from('productos')
      .select('*')
      .eq('productor_id', productorId)
      .eq('activo', true)
      .is('eliminado_en', null)
      .order('nombre', { ascending: true }),
    client.rpc('evaluaciones_publicas_productor', {
      p_productor_id: productorId,
      // Diez visibles y una adicional para saber si el contenedor debe cargar
      // otra página al llegar al final de su scroll.
      p_limit: 11,
      p_offset: 0,
      p_puntaje: null,
    }),
  ])

  if (perfilRes.error || productosRes.error || evaluacionesRes.error) {
    throw new Error('No se pudo cargar la información del vendedor. Inténtalo de nuevo.')
  }

  const perfilPublico = Array.isArray(perfilRes.data)
    ? (perfilRes.data[0] ?? null)
    : (perfilRes.data ?? null)
  const evaluacionesPublicas = Array.isArray(evaluacionesRes.data)
    ? evaluacionesRes.data
    : []

  /*
   * HAL-CLI-006: se usa la misma resolución de región que el catálogo
   * (`getRegionPorProductor`), no sólo `productores.region_id`, para que ficha y
   * perfil nunca discrepen cuando la columna derivada aún no está sincronizada.
   */
  const regionPorProductor = await getRegionPorProductor([productor.id])
  const region = regionPorProductor.get(productor.id) ?? null
  const comunas = region ? await listComunas({ regionId: region.id }) : []
  /*
   * HAL-CLI-006: el producto y el perfil deben publicar la misma comuna. El
   * catálogo usa `getComunaPorPerfil` (comuna de referencia pública derivada de
   * la región del vendedor); el perfil resuelve exactamente la misma fuente.
   */
  const comunaPorPerfil = await getComunaPorPerfil([productor.perfil_id])
  const comuna = comunaPorPerfil.get(productor.perfil_id) ?? null

  return {
    ...productor,
    perfil: perfilPublico,
    region,
    comuna,
    comunasRegion: comunas,
    productos: productosRes.data ?? [],
    evaluaciones: evaluacionesPublicas,
  }
}

/**
 * Página pública de evaluaciones de un productor activo. La RPC aplica el
 * filtro en la base para que una calificación concreta no dependa de las
 * reseñas ya cargadas en el navegador.
 */
export async function listEvaluacionesPublicasProductor(
  productorId,
  { limit = 11, offset = 0, puntaje = null } = {},
) {
  if (!productorId) return []

  const limite = Math.min(Math.max(Number(limit) || 11, 1), 20)
  const desplazamiento = Math.max(Number(offset) || 0, 0)
  const puntajeNormalizado = [1, 2, 3, 4, 5].includes(Number(puntaje))
    ? Number(puntaje)
    : null
  const client = getClient()
  const { data, error } = await client.rpc('evaluaciones_publicas_productor', {
    p_productor_id: productorId,
    p_limit: limite,
    p_offset: desplazamiento,
    p_puntaje: puntajeNormalizado,
  })

  if (error) {
    throw new Error('No se pudieron cargar las evaluaciones del vendedor. Inténtalo de nuevo.')
  }
  return Array.isArray(data) ? data : []
}

/* ---------------------------------------------------------------- */
/* Imágenes                                                          */
/* ---------------------------------------------------------------- */

export async function listImagenesProducto(productoId) {
  const client = getClient()
  const { data, error } = await client
    .from('imagenes_productos')
    .select('*')
    .eq('producto_id', productoId)
    .order('posicion', { ascending: true })
  if (error) return []
  return data.map((img) => ({
    ...img,
    url: storageUrl(img.ruta_storage, { bucket: STORAGE_BUCKETS.productos }),
  }))
}

export async function listImagenesProductos(productoIds) {
  const client = getClient()
  const map = new Map()
  if (!productoIds?.length) return map
  const { data } = await client
    .from('imagenes_productos')
    .select('*')
    .in('producto_id', productoIds)
    .order('posicion', { ascending: true })
  for (const img of data ?? []) {
    if (!map.has(img.producto_id)) map.set(img.producto_id, [])
    map.get(img.producto_id).push({
      ...img,
      url: storageUrl(img.ruta_storage, { bucket: STORAGE_BUCKETS.productos }),
    })
  }
  return map
}

/* ---------------------------------------------------------------- */
/* Catálogo público                                                  */
/* ---------------------------------------------------------------- */

const ORDENES = {
  // La portada y el catálogo comienzan por las publicaciones más recientes.
  // Los demás órdenes siguen disponibles desde el selector de la interfaz.
  relevancia: { column: 'creado_en', ascending: false },
  precio_asc: { column: 'precio', ascending: true, numeric: true },
  precio_desc: { column: 'precio', ascending: false, numeric: true },
  cosecha: { column: 'fecha_cosecha', ascending: false, nullsFirst: false },
  stock: { column: 'stock', ascending: false, numeric: true },
}

/**
 * Lista productos del catálogo público.
 * RF-009: cuando se filtra por región se muestran sólo los vendedores cuya
 * región activa coincide con la seleccionada.
 * @returns {Promise<{items: Array, total: number}>}
 */
export async function listProductos({
  texto = '',
  categoriaId = null,
  categoriaIds = null,
  regionId = null,
  productorId = null,
  soloStock = false,
  orden = 'relevancia',
  page = 1,
  pageSize = 12,
} = {}) {
  const client = getClient()

  let query = client.from('productos').select('*').eq('activo', true).is('eliminado_en', null)
  const idsCategoria = Array.isArray(categoriaIds)
    ? [...new Set(categoriaIds.filter(Boolean).map(String))]
    : []
  if (idsCategoria.length) query = query.in('categoria_id', idsCategoria)
  else if (categoriaId) query = query.eq('categoria_id', categoriaId)
  if (productorId) query = query.eq('productor_id', productorId)
  if (soloStock) query = query.gt('stock', 0)

  const { data: base, error } = await query.order('creado_en', { ascending: false })
  if (error) throw new Error('No se pudo cargar el catálogo. Inténtalo de nuevo.')

  /*
   * HAL-CLI-012..020: la comparación se hace sobre el nombre normalizado
   * (mayúsculas, tildes y espacios externos no cambian el resultado) y el
   * término se trata siempre como texto literal.
   */
  const termino = normalizarBusqueda(texto)
  let items = base ?? []
  if (termino) items = items.filter((p) => coincideBusqueda(p, termino))

  if (regionId) {
    const productorIds = [...new Set(items.map((p) => p.productor_id))]
    const regionPorProductor = await getRegionPorProductor(productorIds)
    items = filtrarProductosPorRegion(items, regionPorProductor, regionId)
  }

  const enriched = (await enrichProducts(items)).filter((p) => !soloStock || p.disponible)

  const cfg = ORDENES[orden] ?? ORDENES.relevancia
  enriched.sort((a, b) => {
    const av = a[cfg.column]
    const bv = b[cfg.column]
    if (av === bv) return String(a.id).localeCompare(String(b.id))
    if (av === null || av === undefined) return cfg.nullsFirst ? -1 : 1
    if (bv === null || bv === undefined) return cfg.nullsFirst ? 1 : -1
    if (cfg.numeric) {
      const an = Number(av)
      const bn = Number(bv)
      if (Number.isFinite(an) && Number.isFinite(bn)) {
        return cfg.ascending ? an - bn : bn - an
      }
    }
    return cfg.ascending
      ? String(av).localeCompare(String(bv), 'es')
      : String(bv).localeCompare(String(av), 'es')
  })

  const total = enriched.length
  const pagina = Math.max(1, Math.floor(Number(page) || 1))
  const tamano = Math.max(1, Math.floor(Number(pageSize) || 12))
  const start = (pagina - 1) * tamano
  return { items: enriched.slice(start, start + tamano), total }
}

/**
 * Región de cobertura de cada vendedor (RF-009).
 * La columna derivada `productores.region_id` la mantiene el trigger
 * `trg_sincronizar_region_productor`; sólo se resuelve por dirección activa
 * cuando aún no está poblada.
 * @returns {Promise<Map<string, object>>} productorId -> región
 */
export async function getRegionPorProductor(productorIds = []) {
  const client = getClient()
  const map = new Map()
  const ids = [...new Set(productorIds.filter(Boolean))]
  if (!ids.length) return map

  const { data: productores } = await client
    .from('productores')
    .select('id, perfil_id, region_id')
    .in('id', ids)
  if (!productores?.length) return map

  const regiones = await listRegiones()
  const regionMap = new Map(regiones.map((r) => [r.id, r]))

  for (const productor of productores) {
    const region = productor.region_id ? regionMap.get(productor.region_id) : null
    if (region) map.set(productor.id, region)
  }

  // Respaldo: vendedores sin `region_id` sincronizada todavía.
  const pendientes = productores.filter((p) => !map.has(p.id))
  if (!pendientes.length) return map

  const { data: direcciones } = await client
    .from('direcciones')
    .select('*')
    .in(
      'perfil_id',
      pendientes.map((p) => p.perfil_id),
    )
    .eq('activo', true)
  const { data: comunas } = await client.from('comunas').select('*')
  const comunaMap = new Map((comunas ?? []).map((c) => [c.id, c]))

  for (const productor of pendientes) {
    const direccion = (direcciones ?? []).find((d) => d.perfil_id === productor.perfil_id)
    const comuna = direccion ? comunaMap.get(direccion.comuna_id) : null
    const region = comuna ? regionMap.get(comuna.region_id) : null
    if (region) map.set(productor.id, region)
  }
  return map
}

/** Comuna pública real. La RPC no expone calle, número ni referencia. */
export async function getComunaPorPerfil(perfilIds = []) {
  const ids = [...new Set(perfilIds.filter(Boolean))]
  const map = new Map()
  if (!ids.length) return map
  const { data, error } = await getClient().rpc('ubicaciones_publicas_productores', {
    p_perfil_ids: ids,
  })
  // Un esquema todavía no migrado deja la ubicación desconocida, nunca inventada.
  if (error) return map
  for (const row of data ?? []) {
    map.set(row.perfil_id, { id: row.comuna_id, nombre: row.nombre, region_id: row.region_id })
  }
  return map
}

/** Enriquece productos con vendedor, ubicación, categoría e imagen principal. */
export async function enrichProducts(productos) {
  if (!productos?.length) return []
  const client = getClient()
  const ids = productos.map((p) => p.id)
  const productorIds = [...new Set(productos.map((p) => p.productor_id))]

  const [imagenes, productoresRes, categoriasRes] = await Promise.all([
    listImagenesProductos(ids),
    client.from('productores').select('*').in('id', productorIds),
    client.from('categorias').select('*'),
  ])

  if (productoresRes.error || categoriasRes.error) {
    throw new Error('No se pudo cargar la información del catálogo. Inténtalo de nuevo.')
  }

  const productores = productoresRes.data ?? []
  const regionPorProductor = await getRegionPorProductor(productorIds)
  const comunaPorPerfil = await getComunaPorPerfil(productores.map((p) => p.perfil_id))

  const productorMap = new Map(productores.map((p) => [p.id, p]))
  const categoriaMap = new Map((categoriasRes.data ?? []).map((c) => [c.id, c]))

  const categoriaDe = (producto) => categoriaMap.get(producto.categoria_id) ?? null
  const padreDe = (categoria) =>
    categoria?.categoria_padre_id ? categoriaMap.get(categoria.categoria_padre_id) ?? null : null

  /**
   * Un vendedor suspendido, con ban permanente o inactivo no puede vender
   * (RF-026), y las políticas RLS dejan de exponer su fila pública. Por eso los
   * productos de un vendedor no visible no entran al catálogo.
   *
   * HAL-CLI-021: tampoco se publican productos de "Alimentos para mascotas" ni
   * de sus subcategorías mientras la categoría esté fuera de alcance.
   */
  const visibles = productos.filter((p) => {
    const productor = productorMap.get(p.productor_id)
    if (p.activo === false || p.eliminado_en) return false
    if (!productor || productor.activo === false || productor.servicio_suspendido) return false
    const categoria = categoriaDe(p)
    return !esProductoDeCategoriaOculta({ categoria, categoriaPadre: padreDe(categoria) })
  })

  return visibles.map((p) => {
    const productor = productorMap.get(p.productor_id) ?? null
    const regionProductor = regionPorProductor.get(p.productor_id) ?? null
    const comunaProductor = productor ? comunaPorPerfil.get(productor.perfil_id) ?? null : null
    const galeria = imagenes.get(p.id) ?? []
    const categoriaOriginal = categoriaDe(p)
    const padreOriginal = padreDe(categoriaOriginal)
    const categoria = categoriaOriginal
      ? { ...categoriaOriginal, nombre: normalizarNombreCategoria(categoriaOriginal.nombre) }
      : null
    const categoriaPadre = padreOriginal
      ? { ...padreOriginal, nombre: normalizarNombreCategoria(padreOriginal.nombre) }
      : null
    // Un producto sin fotografías nunca queda sin imagen: se ilustra su familia.
    const ilustracion = {
      url: placeholderImage(p.id, p.nombre),
      nombre_archivo: 'ilustracion.svg',
      texto_alternativo: `Ilustración de ${p.nombre}`,
      es_principal: true,
      simulada: true,
    }

    // Las fotos guardadas son la fuente real; usar ilustración solo si no hay URL.
    const galeriaValida = galeria.filter((img) => img.url)
    const principalValida =
      galeriaValida.find((i) => i.es_principal) ?? galeriaValida[0] ?? ilustracion

    return {
      ...p,
      stock_total: Number(p.stock),
      // El stock disponible se redondea hacia abajo a décimas para no ofrecer
      // una fracción que una reserva histórica de mayor precisión impediría.
      stock: Math.max(
        0,
        Math.floor(
          (Number(p.stock) - Number(p.stock_reservado ?? 0) + Number.EPSILON) * 10,
        ) / 10,
      ),
      imagenPrincipal: principalValida,
      imagenes: galeriaValida,
      productor,
      comunaProductor,
      regionProductor,
      categoria,
      categoriaPadre,
      /** RF-003: sin umbral de stock; sólo se informa si hay o no disponibilidad. */
      disponible: Number(p.stock) - Number(p.stock_reservado ?? 0) > 0,
    }
  })
}

export async function getProducto(productoId) {
  const client = getClient()
  const { data, error } = await client.from('productos').select('*').eq('id', productoId).maybeSingle()
  if (error) throw new Error('No se pudo consultar el producto. Inténtalo de nuevo.')
  if (!data) return null
  const [enriquecido] = await enrichProducts([data])
  return enriquecido ?? null
}

/** Resumen del catálogo público para la portada. */
export async function getResumenCatalogo() {
  const client = getClient()
  const [productosRes, productoresRes, categoriasRes] = await Promise.all([
    client.from('productos').select('id, categoria_id, productor_id, precio').eq('activo', true).is('eliminado_en', null),
    client.from('productores').select('id').eq('activo', true),
    client.from('categorias').select('id, nombre').is('eliminado_en', null),
  ])
  const productos = productosRes.data ?? []
  return {
    productos: productos.length,
    vendedores: (productoresRes.data ?? []).length,
    categorias: (categoriasRes.data ?? []).length,
    precios: productos.map((p) => Number(p.precio)).filter((n) => Number.isFinite(n)),
  }
}

/**
 * Historial de precios por producto y región (RF-008, fuera del MVP vigente).
 * Estas funciones son stubs de galería de desarrollo: si se activa la galería
 * con `VITE_DEV_GALLERY=true` y se entra a la ventana de trazabilidad, no
 * rompen el runtime; devuelven datos vacíos y advierten por consola.
 * El alcance vigente no almacena historial de precios (RF-008 eliminado).
 */
export async function getTrazabilidadPrecios({ productoId, regionId } = {}) {
  console.warn('[getTrazabilidadPrecios] RF-008 fuera del alcance MVP; devolviendo vacío')
  return {
    producto: { id: productoId, nombre: '', precio: 0, productor: {} },
    region: null,
    serie: [],
    reputacion: null,
  }
}

export async function getPreciosPorRegion({ productoId, categoriaId } = {}) {
  console.warn('[getPreciosPorRegion] RF-008 fuera del alcance MVP; devolviendo vacío')
  return []
}

export { UNIDAD_MEDIDA, listComunas, listRegiones }

