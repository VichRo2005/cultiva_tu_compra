import { afterEach, describe, expect, it, vi } from 'vitest'

const supabaseMock = vi.hoisted(() => ({ getClient: vi.fn() }))
const sessionMock = vi.hoisted(() => ({ currentUserId: vi.fn() }))

vi.mock('@/lib/supabase', () => supabaseMock)
vi.mock('@/services/session', () => sessionMock)

import {
  guardarPreferenciasNotificacion,
  normalizarPreferenciasNotificacion,
  obtenerPreferenciasNotificacion,
} from '@/services/notificationPreferences'

afterEach(() => vi.resetAllMocks())

describe('preferencias de notificación', () => {
  it('mantiene ambos canales activos cuando la cuenta todavía no guardó una preferencia', () => {
    expect(normalizarPreferenciasNotificacion()).toEqual({ email: true, inApp: true })
    expect(normalizarPreferenciasNotificacion(null)).toEqual({ email: true, inApp: true })
  })

  it('usa los valores predeterminados cuando Supabase no encuentra la fila de la cuenta', async () => {
    const maybeSingle = vi.fn().mockResolvedValue({ data: null, error: null })
    const eq = vi.fn(() => ({ maybeSingle }))
    const select = vi.fn(() => ({ eq }))
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => ({ select })) })
    sessionMock.currentUserId.mockResolvedValue('perfil-sin-preferencias')

    await expect(obtenerPreferenciasNotificacion()).resolves.toEqual({ email: true, inApp: true })
  })

  it('lee los canales guardados de la cuenta autenticada', async () => {
    const maybeSingle = vi.fn().mockResolvedValue({
      data: { recibir_correo: false, recibir_en_plataforma: true },
      error: null,
    })
    const eq = vi.fn(() => ({ maybeSingle }))
    const select = vi.fn(() => ({ eq }))
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => ({ select })) })
    sessionMock.currentUserId.mockResolvedValue('perfil-cliente')

    await expect(obtenerPreferenciasNotificacion()).resolves.toEqual({ email: false, inApp: true })
    expect(eq).toHaveBeenCalledWith('perfil_id', 'perfil-cliente')
  })

  it('guarda ambos canales con conflicto por perfil para que no duplique preferencias', async () => {
    const single = vi.fn().mockResolvedValue({
      data: { recibir_correo: true, recibir_en_plataforma: false },
      error: null,
    })
    const select = vi.fn(() => ({ single }))
    const upsert = vi.fn(() => ({ select }))
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => ({ upsert })) })
    sessionMock.currentUserId.mockResolvedValue('perfil-vendedor')

    await expect(
      guardarPreferenciasNotificacion({ email: true, inApp: false }),
    ).resolves.toEqual({ email: true, inApp: false })
    expect(upsert).toHaveBeenCalledWith(
      {
        perfil_id: 'perfil-vendedor',
        recibir_correo: true,
        recibir_en_plataforma: false,
      },
      { onConflict: 'perfil_id' },
    )
  })
})
