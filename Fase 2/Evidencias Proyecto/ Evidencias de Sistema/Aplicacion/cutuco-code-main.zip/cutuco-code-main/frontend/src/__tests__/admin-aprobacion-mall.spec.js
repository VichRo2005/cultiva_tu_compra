/**
 * La aprobación no acepta un código Mall desde el navegador: FastAPI toma el
 * comercio hijo desde el entorno privado y ejecuta la RPC administrativa.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'

const { apiFetchMock, getClientMock } = vi.hoisted(() => ({
  apiFetchMock: vi.fn(),
  getClientMock: vi.fn(),
}))

vi.mock('@/lib/supabase', () => ({
  apiFetch: apiFetchMock,
  getClient: getClientMock,
  storageUrl: vi.fn(),
}))
vi.mock('@/services/session', () => ({
  currentUserId: vi.fn(),
  unwrap: ({ data, error }, fallback = 'Ocurrió un error inesperado') => {
    if (error) throw new Error(error.message ?? fallback)
    return data
  },
}))

import { revisarPostulacion } from '@/services/admin'

beforeEach(() => {
  vi.clearAllMocks()
  apiFetchMock.mockResolvedValue({
    id: 'post-1',
    estado: 'aprobada',
    codigo_comercio_mall: '597055555536',
  })
})

describe('revisarPostulacion · comercio Mall automático', () => {
  it('aprueba mediante el endpoint protegido sin incluir un código Mall', async () => {
    const resultado = await revisarPostulacion({
      postulacionId: 'post-1',
      aprobar: true,
      observaciones: 'Antecedentes revisados y aprobados.',
      // Compatibilidad con llamadas antiguas: este valor debe ignorarse.
      codigoComercioMall: '111111111111',
    })

    expect(apiFetchMock).toHaveBeenCalledWith('/api/admin/postulaciones/post-1/resolver', {
      method: 'POST',
      body: {
        estado: 'aprobada',
        observaciones: 'Antecedentes revisados y aprobados.',
      },
    })
    expect(JSON.stringify(apiFetchMock.mock.calls[0][1].body)).not.toContain('111111111111')
    expect(resultado.codigo_comercio_mall).toBe('597055555536')
  })

  it('permite un rechazo sin observaciones para que el backend envíe el texto automático', async () => {
    await revisarPostulacion({ postulacionId: 'post-1', aprobar: false })
    expect(apiFetchMock).toHaveBeenCalledWith('/api/admin/postulaciones/post-1/resolver', {
      method: 'POST',
      body: { estado: 'rechazada', observaciones: null },
    })
  })

  it('envía un rechazo con las observaciones normalizadas y sin código Mall', async () => {
    await revisarPostulacion({
      postulacionId: 'post-1',
      aprobar: false,
      observaciones: '  Falta certificado tributario vigente.  ',
    })

    expect(apiFetchMock).toHaveBeenCalledWith('/api/admin/postulaciones/post-1/resolver', {
      method: 'POST',
      body: {
        estado: 'rechazada',
        observaciones: 'Falta certificado tributario vigente.',
      },
    })
  })

  it('traduce el error de configuración sin exponer detalles de Transbank', async () => {
    apiFetchMock.mockRejectedValue(
      new Error('Falta TRANSBANK_MALL_SELLER_COMMERCE_CODE en el backend.'),
    )

    await expect(revisarPostulacion({ postulacionId: 'post-1', aprobar: true })).rejects.toThrow(
      /aprobación automática.*configurada/i,
    )
  })

  it('traduce la postulación que otra sesión ya resolvió', async () => {
    apiFetchMock.mockRejectedValue(
      new Error('No existe una postulacion en revision con ese ID'),
    )

    await expect(revisarPostulacion({ postulacionId: 'post-1', aprobar: true })).rejects.toThrow(
      /ya no está en revisión/i,
    )
  })
})
