/**
 * CuTuCo — Lote 6: Stock/concurrencia, Calificaciones y Webpay Mall.
 *
 * CK-0390 (UI): createEvaluacion rechaza 0, 6 y no enteros antes de tocar la BD.
 * CK-0384 (UI): límites de stock del formulario (LIMITES_PRODUCTO) coherentes
 *   con el máximo del backend.
 * CK-0091: el checkout envía al navegador a la URL de Webpay con token_ws por POST.
 * CK-0120: la separación de ambientes vive en TRANSBANK_ENV (integration por
 *   defecto en el repo; production sólo con credenciales reales verificadas).
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)
const sessionMock = vi.hoisted(() => ({
  currentUserId: vi.fn(async () => 'u-cliente'),
  unwrap: (r, msg) => { if (r?.error) throw new Error(msg); return r?.data },
}))
vi.mock('@/services/session.js', () => sessionMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')
const backend = (p) => readFileSync(`../backend/${p}`, 'utf8')

function pedidoMock(estado = 'completado') {
  const q = {}
  for (const m of ['select', 'eq', 'single', 'maybeSingle', 'insert', 'update', 'order', 'limit'])
    q[m] = vi.fn(() => q)
  q.maybeSingle = vi.fn(async () => ({ data: { id: 'ped-1', estado, productor_id: 'prod-1' }, error: null }))
  q.single = vi.fn(async () => ({ data: { id: 'ped-1', estado, productor_id: 'prod-1' }, error: null }))
  q.insert = vi.fn(() => q)
  supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => q) })
  return q
}

describe('CK-0390 · calificación validada en interfaz (1 a 5 entero)', () => {
  it.each([0, 6, 2.5, 'texto'])('rechaza puntaje %s antes de llamar a la BD', async (puntaje) => {
    const q = pedidoMock()
    const { createEvaluacion } = await import('@/services/orders.js')
    await expect(createEvaluacion({ pedidoId: 'ped-1', puntaje })).rejects.toThrow(/entre 1 y 5/)
    expect(q.insert).not.toHaveBeenCalled()
  })

  it('acepta 1..5 enteros y envía sólo el pedido propio', async () => {
    const q = pedidoMock()
    const { createEvaluacion } = await import('@/services/orders.js')
    await createEvaluacion({ pedidoId: 'ped-1', puntaje: 5 })
    expect(q.insert).toHaveBeenCalledTimes(1)
    const fila = q.insert.mock.calls[0][0]
    expect(fila).toMatchObject({ pedido_id: 'ped-1', productor_id: 'prod-1', cliente_id: 'u-cliente', puntaje: 5 })
  })

  it('rechaza calificar un pedido que no está entregado/reclamado', async () => {
    pedidoMock('en_transito')
    const { createEvaluacion } = await import('@/services/orders.js')
    await expect(createEvaluacion({ pedidoId: 'ped-1', puntaje: 4 })).rejects.toThrow(/entregado o reclamado/)
  })
})

describe('CK-0384 · stock validado en interfaz con los mismos límites del backend', () => {
  it('LIMITES_PRODUCTO.stockMax coincide con el máximo del validador del backend', async () => {
    const { LIMITES_PRODUCTO } = await import('@/services/seller.js')
    const validadores = backend('app/schemas/validators.py')
    const maxBackend = Number(validadores.match(/STOCK_MAXIMO\s*=\s*Decimal\("([\d.]+)"\)/)?.[1])
    expect(Number.isFinite(maxBackend)).toBe(true)
    // el límite del formulario no supera el del esquema del backend
    expect(LIMITES_PRODUCTO.stockMax).toBeLessThanOrEqual(maxBackend)
    // HAL-VEN-026: el tope es de negocio (escala campesina), no el técnico 999.999.999 de la columna
    expect(LIMITES_PRODUCTO.stockMax).toBe(999999)
    expect(LIMITES_PRODUCTO.stockMax).toBeLessThan(Math.floor(maxBackend))
    // el formulario usa min/max del mismo objeto
    const form = src('views/seller/SellerProductFormView.vue')
    expect(form).toContain(':min="LIMITES_PRODUCTO.stockMin"')
    expect(form).toContain(':max="LIMITES_PRODUCTO.stockMax"')
  })
})

describe('CK-0091 · redirección a Webpay con token_ws por POST', () => {
  it('CheckoutView envía un formulario oculto POST a la URL devuelta con token_ws', () => {
    const vista = src('views/client/CheckoutView.vue')
    expect(vista).toContain(':action="webpay.url"')
    expect(vista).toContain('method="post"')
    expect(vista).toContain('name="token_ws"')
    expect(vista).toContain(':value="webpay.token"')
  })
})

describe('CK-0120 · separación de ambientes test/real', () => {
  it('TRANSBANK_ENV=integration por defecto; production exige credenciales verificadas', () => {
    const config = backend('app/core/config.py')
    expect(config).toMatch(/TRANSBANK_ENV:\s*Literal\["integration",\s*"production"\]\s*=\s*"integration"/)
    const servicio = backend('app/services/servicio_service.py')
    expect(servicio).toContain('if settings.TRANSBANK_ENV == "production":')
    // el deploy fija integration explícitamente (pagos simulados aprobados)
    const deploy = readFileSync('../gcp/deploy-backend.sh', 'utf8')
    expect(deploy).toContain('TRANSBANK_ENV=integration')
  })
})
