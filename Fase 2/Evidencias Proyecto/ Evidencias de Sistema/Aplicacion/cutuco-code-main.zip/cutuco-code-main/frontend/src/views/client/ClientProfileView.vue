<script setup>
/**
 * CuTuCo — Mi Perfil del cliente (página 10 del diseño oficial).
 *
 * `perfiles` guarda nombre, apellido, telefono y la ruta de su foto. El correo
 * se lee de la sesión de autenticación y la región se deriva de la comuna.
 * RUT y código postal no existen en el esquema. Las preferencias de
 * notificación se guardan por cuenta y definen los canales operativos.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtFileUpload from '@/components/base/CtFileUpload.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import NotificationPreferences from '@/components/domain/NotificationPreferences.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { exportExcel } from '@/lib/csv'
import { ESTADO_PEDIDO, LABELS, STORAGE_BUCKETS } from '@/lib/constants'
import { formatCLP, formatDate, formatDateTime } from '@/lib/format'
import { estadoActualPedido } from '@/lib/orders'
import { storageUrl } from '@/lib/supabase'
import {
  emailPolicyMessage,
  isEmail,
  LIMITES,
  normalizarTelefonoChileno,
  PASSWORD_REQUIREMENTS,
  passwordChecks,
  passwordPolicyMessage,
  passwordStrength,
  validate,
} from '@/lib/validation'
import { createDireccion, listDirecciones, updateDireccion } from '@/services/geography'
import { getResumenCliente, listPedidos } from '@/services/orders'
import { quitarFotoPerfilCliente, subirFotoPerfilCliente } from '@/services/profile'
import { useAuthStore } from '@/stores/auth'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const PAGE_SIZE_MAX = 500

const PESTANAS = [
  { value: 'personal', label: 'Información Personal' },
  { value: 'seguridad', label: 'Seguridad' },
  { value: 'facturacion', label: 'Pagos y comprobantes' },
  { value: 'notificaciones', label: 'Notificaciones' },
]

const router = useRouter()
const auth = useAuthStore()
const geo = useGeographyStore()
const ui = useUiStore()

const pestana = ref('personal')
const guardando = ref(false)
const errorGlobal = ref(null)
const subiendoFoto = ref(false)
const fotoTemporal = ref(null)
const fotoVersion = ref(Date.now())

const formulario = ref({
  nombre: '',
  apellido: '',
  telefono: '',
  direccion_principal: '',
  regionId: null,
  comunaId: null,
})
const errores = ref({})

/**
 * Clave del usuario autenticado (RF-024): se pide la contraseña actual para
 * confirmar la identidad antes del cambio.
 */
const clave = ref({ actual: '', nueva: '', repetir: '' })
const erroresClave = ref({})
const guardandoClave = ref(false)

/** HAL-CLI-026: mismo indicador de fortaleza y requisitos que el registro. */
const fuerzaClave = computed(() => passwordStrength(clave.value.nueva))
const requisitosClave = computed(() => passwordChecks(clave.value.nueva))

/**
 * Cambio de correo (RF-001 y RF-020). El correo vive en Supabase Auth, no en
 * `perfiles`. Con `double_confirm_changes = true` GoTrue pide confirmar el
 * cambio en la dirección antigua y en la nueva antes de aplicarlo.
 */
const modalCorreo = ref(false)
const nuevoCorreo = ref('')
const claveCorreo = ref('')
const errorCorreo = ref(null)
const errorClaveCorreo = ref(null)
const guardandoCorreo = ref(false)
const correoPendiente = ref(null)

/** Dirección principal del cliente (tabla `direcciones`, RF-009). */
const direccionPrincipal = ref(null)

const resumen = ref(null)
const pedidos = ref([])
const cargandoResumen = ref(true)
const errorResumen = ref(null)

const ESQUEMA = {
  nombre: { required: true, minLength: 2, maxLength: 100, nombrePropio: true },
  apellido: { required: true, minLength: 2, maxLength: 100 },
  telefono: { required: true, phone: true },
  direccion_principal: { required: true, minLength: 5, maxLength: 255 },
  comunaId: { required: true },
}

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)
const opcionesComuna = computed(() =>
  geo.comunasDeRegion(formulario.value.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

const correo = computed(() => auth.user?.email ?? '—')
const regionActual = computed(() =>
  formulario.value.comunaId ? geo.regionDeComuna(formulario.value.comunaId) : null,
)
const nombreRegionActual = computed(() =>
  regionActual.value ? geo.nombreRegion(regionActual.value) : '—',
)
const nombreCompleto = computed(
  () => [auth.perfil?.nombre, auth.perfil?.apellido].filter(Boolean).join(' ') || 'Cliente CuTuCo',
)
const fotoPerfil = computed(() => {
  if (fotoTemporal.value) return fotoTemporal.value
  const ruta = auth.perfil?.foto_perfil_storage_path
  const base = ruta ? storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresCliente }) : null
  if (!base || base.startsWith('data:') || base.startsWith('offline:')) return base
  return `${base}${base.includes('?') ? '&' : '?'}v=${fotoVersion.value}`
})
const correoVerificado = computed(() => Boolean(auth.user?.email_confirmed_at))
const ultimaActividad = computed(() => pedidos.value[0] ?? null)
const vendedoresSeguidos = computed(
  () => new Set(pedidos.value.map((p) => p.productor_id).filter(Boolean)).size,
)
const conPago = computed(() => pedidos.value.filter((p) => p.pago))
/** El resumen del servicio no expone `activos`; se calcula con el estado actual. */
const pendientesActividad = computed(
  () =>
    pedidos.value.filter((p) =>
      [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(estadoActualPedido(p)),
    ).length,
)

const columnasPagos = [
  { key: 'codigo_pedido', label: 'Pedido', width: '170px' },
  { key: 'estado_pago', label: 'Estado del pago', width: '170px' },
  { key: 'monto', label: 'Monto', align: 'right', width: '130px' },
  { key: 'creado_en', label: 'Fecha', width: '160px' },
]

const filasPagos = computed(() =>
  conPago.value.map((p) => ({
    id: p.id,
    codigo_pedido: p.codigo_pedido,
    estado_pago: p.pago.estado,
    // `pagos.monto` es el neto al productor; el cliente pagó el total del
    // pedido (neto + comisión de CuTuCo).
    monto: Number(p.total ?? Number(p.pago.monto) + Number(p.pago.monto_fee_descontado ?? 0)),
    creado_en: p.pago.creado_en,
  })),
)

/** Rellena el formulario con el perfil y su dirección activa (`direcciones`). */
async function rellenarFormulario() {
  const perfil = auth.perfil
  if (!perfil) return
  const direcciones = await listDirecciones({ perfilId: perfil.id })
  direccionPrincipal.value = direcciones.find((d) => d.es_principal) ?? direcciones[0] ?? null
  const comunaId = direccionPrincipal.value?.comuna_id ?? null
  formulario.value = {
    nombre: perfil.nombre ?? '',
    apellido: perfil.apellido ?? '',
    telefono: perfil.telefono ?? '',
    direccion_principal: direccionPrincipal.value?.calle ?? '',
    regionId: comunaId ? geo.regionDeComuna(comunaId) : null,
    comunaId,
  }
}

function cambiarRegion(regionId) {
  formulario.value.regionId = regionId
  formulario.value.comunaId = null
}

async function guardar() {
  if (guardando.value) return
  errorGlobal.value = null
  const { valid, errors } = validate(formulario.value, ESQUEMA)
  errores.value = errors
  if (!valid) {
    ui.warning('Revisa el formulario', 'Hay campos obligatorios o con formato inválido')
    return
  }

  const perfil = auth.perfil
  const nombre = formulario.value.nombre.trim()
  const apellido = formulario.value.apellido.trim()
  const telefono = normalizarTelefonoChileno(formulario.value.telefono)
  const cambiaPerfil =
    !perfil ||
    nombre !== String(perfil.nombre ?? '').trim() ||
    apellido !== String(perfil.apellido ?? '').trim() ||
    telefono !== normalizarTelefonoChileno(perfil.telefono)
  const direccionActual = direccionPrincipal.value
  const cambiaDireccion =
    !direccionActual ||
    formulario.value.comunaId !== direccionActual.comuna_id ||
    formulario.value.direccion_principal.trim() !== String(direccionActual.calle ?? '').trim()

  if (!cambiaPerfil && !cambiaDireccion) {
    ui.info('Sin cambios', 'Tus datos ya estaban guardados')
    return
  }

  guardando.value = true
  try {
    // Los datos personales viven en `perfiles`; la dirección, en `direcciones`.
    if (cambiaPerfil) {
      await auth.updatePerfil({
        nombre,
        apellido,
        telefono: formulario.value.telefono.trim(),
      })
    }

    if (direccionActual) {
      if (cambiaDireccion) {
        await updateDireccion(direccionActual.id, {
          comuna_id: formulario.value.comunaId,
          calle: formulario.value.direccion_principal.trim(),
        })
      }
    } else {
      await createDireccion({
        perfilId: auth.perfil.id,
        etiqueta: 'Principal',
        comunaId: formulario.value.comunaId,
        calle: formulario.value.direccion_principal.trim(),
        esPrincipal: true,
      })
      await rellenarFormulario()
    }

    ui.success('Perfil actualizado', 'Tus datos y tu dirección de entrega quedaron guardados')
  } catch (e) {
    errorGlobal.value = e?.message ?? 'No se pudo guardar el perfil'
    ui.error('No se pudo guardar el perfil', e?.message)
  } finally {
    guardando.value = false
  }
}

async function descartar() {
  errores.value = {}
  errorGlobal.value = null
  await rellenarFormulario()
}

/* ---------- Foto de perfil ---------- */
async function onElegirFotoPerfil(filesRecibidos) {
  const filesArray = Array.isArray(filesRecibidos) ? filesRecibidos : [filesRecibidos]
  const fileObj = filesArray?.[0]
  const file = fileObj?.file ?? fileObj
  const perfilId = auth.perfil?.id
  if (!file || !perfilId) return

  subiendoFoto.value = true
  fotoTemporal.value = fileObj?.preview ?? URL.createObjectURL(file)
  try {
    const perfilActualizado = await subirFotoPerfilCliente({
      perfilId,
      file,
      rutaActual: auth.perfil?.foto_perfil_storage_path,
    })
    auth.perfil = perfilActualizado
    fotoTemporal.value = null
    fotoVersion.value = Date.now()
    ui.success('Foto de perfil actualizada', 'Tu nueva foto ya está guardada')
  } catch (e) {
    fotoTemporal.value = null
    ui.error('No se pudo subir la foto', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoFoto.value = false
  }
}

async function onQuitarFotoPerfil() {
  const perfilId = auth.perfil?.id
  const rutaActual = auth.perfil?.foto_perfil_storage_path
  if (!perfilId || !rutaActual) return

  subiendoFoto.value = true
  try {
    const perfilActualizado = await quitarFotoPerfilCliente({ perfilId, rutaActual })
    auth.perfil = perfilActualizado
    fotoTemporal.value = null
    fotoVersion.value = Date.now()
    ui.info('Foto eliminada', 'Se muestra el avatar con tus iniciales')
  } catch (e) {
    ui.error('No se pudo quitar la foto', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoFoto.value = false
  }
}

function onErrorCargaFoto(message) {
  ui.error('No se pudo seleccionar la foto', message)
}

async function guardarClave() {
  if (guardandoClave.value) return
  erroresClave.value = {}
  if (!clave.value.actual) {
    erroresClave.value.actual = 'Ingresa tu contraseña actual'
  }
  // HAL-CLI-024: la política local valida el máximo de GoTrue (72) y muestra
  // el mensaje en español antes de llamar a Auth.
  const politica = passwordPolicyMessage(clave.value.nueva)
  if (politica) erroresClave.value.nueva = politica
  if (!clave.value.repetir) {
    erroresClave.value.repetir = 'Repite la contraseña nueva'
  } else if (clave.value.nueva !== clave.value.repetir) {
    erroresClave.value.repetir = 'Las contraseñas no coinciden'
  }
  if (Object.keys(erroresClave.value).length) {
    ui.warning('Revisa la contraseña', 'La nueva clave no cumple los requisitos de seguridad')
    return
  }

  guardandoClave.value = true
  try {
    await auth.updatePassword(clave.value.actual, clave.value.nueva)
    clave.value = { actual: '', nueva: '', repetir: '' }
    ui.success(
      'Contraseña actualizada',
      'Por seguridad cerramos tu sesión. Ingresa nuevamente con tu contraseña nueva.',
    )
    await auth.signOut()
    router.push({ name: 'login' })
  } catch (e) {
    ui.error(
      'No se pudo actualizar la contraseña',
      e?.message ?? 'Verifica tu contraseña actual e intenta de nuevo.',
    )
  } finally {
    guardandoClave.value = false
  }
}

/**
 * RF-001 y RF-020 / HAL-CLI-025 y HAL-CLI-027: un único campo de correo nuevo,
 * contraseña actual y validación local del máximo de 254 antes de enviar.
 */
async function cambiarCorreo() {
  if (guardandoCorreo.value) return
  errorCorreo.value = null
  errorClaveCorreo.value = null
  const destino = String(nuevoCorreo.value ?? '')
  // No se recorta antes de validar: los espacios externos deben informarse.
  const mensajeCorreo = emailPolicyMessage(destino)
  if (mensajeCorreo) {
    errorCorreo.value = mensajeCorreo
    return
  }
  if (!isEmail(destino)) {
    errorCorreo.value = 'Ingresa un correo válido'
    return
  }
  if (!claveCorreo.value) {
    errorClaveCorreo.value = 'Ingresa tu contraseña actual para confirmar el cambio'
    return
  }

  guardandoCorreo.value = true
  try {
    // La firma del store exige la contraseña actual para reautenticar.
    const solicitado = await auth.updateEmail(destino, claveCorreo.value)
    correoPendiente.value = solicitado
    modalCorreo.value = false
    nuevoCorreo.value = ''
    claveCorreo.value = ''
    ui.success(
      'Confirmación enviada',
      `Revisa ${solicitado} y tu correo actual: el cambio se aplica cuando confirmes en ambos.`,
    )
  } catch (e) {
    errorCorreo.value = e?.message ?? 'No se pudo solicitar el cambio de correo'
  } finally {
    guardandoCorreo.value = false
  }
}

watch(modalCorreo, (abierto) => {
  if (!abierto) {
    claveCorreo.value = ''
    errorClaveCorreo.value = null
  }
})

async function cerrarSesion() {
  await auth.signOut()
  router.push('/login')
}

async function sincronizarNotificaciones() {
  try {
    await ui.syncNotifications({ rol: auth.rol })
  } catch (e) {
    ui.error('No se pudieron cargar tus notificaciones', e?.message)
  }
}

async function exportarPagos() {
  const ok = await exportExcel(filasPagos.value, 'cutuco-pagos', [
    { label: 'Pedido', get: (f) => f.codigo_pedido },
    { label: 'Estado del pago', get: (f) => LABELS.pago[f.estado_pago] ?? f.estado_pago },
    { label: 'Monto', get: (f) => f.monto },
    { label: 'Fecha', get: (f) => formatDateTime(f.creado_en) },
  ])
  if (!ok) ui.warning('Sin pagos para exportar', 'Todavía no tienes transacciones registradas')
}

function marcarTodasLeidas() {
  ui.marcarTodasLeidas()
  ui.success('Notificaciones marcadas como leídas')
}

async function cargarResumen() {
  cargandoResumen.value = true
  errorResumen.value = null
  try {
    const [resumenCliente, listado] = await Promise.all([
      getResumenCliente(),
      listPedidos({ rol: 'cliente', page: 1, pageSize: PAGE_SIZE_MAX }),
    ])
    resumen.value = resumenCliente
    pedidos.value = listado.items
  } catch (e) {
    errorResumen.value = e?.message ?? 'No se pudo cargar tu actividad'
  } finally {
    cargandoResumen.value = false
  }
}

onMounted(async () => {
  void geo.load()
  await rellenarFormulario()
  await Promise.all([cargarResumen(), sincronizarNotificaciones()])
})

watch(() => auth.perfil, rellenarFormulario, { deep: true })
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Mi Perfil</h1>
        <p class="page-head__subtitle">
          Mantén tus datos al día para que los productores puedan entregar sin problemas.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton :loading="guardando" @click="guardar">
          <template #icon><CtIcon name="check" :size="16" /></template>
          Guardar Cambios
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="errorGlobal" tone="danger" title="No se pudo guardar el perfil">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ errorGlobal }}</span>
      </p>
    </CtAlert>

    <div class="perfil">
      <div class="perfil__principal stack">
        <CtCard padding="none">
          <div class="cabecera">
            <CtAvatar :name="nombreCompleto" :src="fotoPerfil" :size="56" />
            <div class="cabecera__datos">
              <p class="cabecera__nombre">{{ nombreCompleto }}</p>
              <p class="cabecera__correo">{{ correo }}</p>
              <div class="cabecera__chips">
                <StatusBadge v-if="auth.rol" type="rol" :value="auth.rol" size="sm" />
                <CtBadge :tone="correoVerificado ? 'success' : 'warning'" size="sm" dot>
                  {{ correoVerificado ? 'Cuenta verificada' : 'Cuenta sin verificar' }}
                </CtBadge>
              </div>
            </div>
          </div>
        </CtCard>

        <CtCard title="Foto de perfil" subtitle="Sube o actualiza la imagen de tu cuenta">
          <div class="perfil-foto">
            <CtAvatar
              class="perfil-foto__preview"
              :name="nombreCompleto"
              :src="fotoPerfil"
              :size="120"
            />
            <div class="perfil-foto__acciones">
              <CtFileUpload
                :model-value="[]"
                accept="image/jpeg,image/png,image/webp"
                :multiple="false"
                :max="1"
                :disabled="subiendoFoto"
                :loading="subiendoFoto"
                label="Cambiar foto de perfil"
                hint="JPG, PNG o WebP · máximo 5 MB"
                @update:model-value="onElegirFotoPerfil"
                @error="onErrorCargaFoto"
              />
              <CtButton
                v-if="auth.perfil?.foto_perfil_storage_path"
                variant="ghost"
                size="sm"
                :disabled="subiendoFoto"
                @click="onQuitarFotoPerfil"
              >
                <template #icon><CtIcon name="trash" :size="14" /></template>
                Quitar y usar avatar por defecto
              </CtButton>
            </div>
          </div>
        </CtCard>

        <CtCard padding="none">
          <div class="pestanas">
            <CtTabs v-model="pestana" :tabs="PESTANAS" />
          </div>

          <div class="pestanas__cuerpo">
            <!-- ========== Información personal ========== -->
            <div v-show="pestana === 'personal'" class="stack">
              <section class="bloque">
                <h2 class="bloque__titulo">Datos del Titular</h2>
                <div class="formulario">
                  <div class="formulario__fila">
                    <CtInput
                      v-model="formulario.nombre"
                      label="Nombre"
                      required
                      :error="errores.nombre ?? null"
                    />
                    <CtInput
                      v-model="formulario.apellido"
                      label="Apellido"
                      required
                      :error="errores.apellido ?? null"
                    />
                  </div>

                  <div class="formulario__fila">
                    <CtInput
                      :model-value="correo"
                      label="Correo Electrónico"
                      disabled
                      hint="Para cambiarlo, usa «Cambiar correo electrónico»: deberás confirmar el cambio en tu bandeja."
                    />
                    <CtInput
                      v-model="formulario.telefono"
                      label="Teléfono de Contacto"
                      placeholder="+56912345678"
                      required
                      :error="errores.telefono ?? null"
                    />
                  </div>

                  <!-- y: el correo se cambia en Supabase Auth. -->
                  <div class="acciones">
                    <CtButton variant="secondary" @click="modalCorreo = true">
                      <template #icon><CtIcon name="mail" :size="15" /></template>
                      Cambiar correo electrónico
                    </CtButton>
                    <span v-if="correoPendiente" class="text-xs text-muted">
                      Cambio pendiente de confirmación en {{ correoPendiente }}
                    </span>
                  </div>

                  <div class="formulario__fila">
                    <CtInput
                      :model-value="
                        auth.perfil?.creado_en ? formatDate(auth.perfil.creado_en) : '—'
                      "
                      label="Miembro desde"
                      disabled
                    />
                  </div>
                </div>
              </section>

              <section class="bloque">
                <h2 class="bloque__titulo">Dirección de Despacho</h2>
                <div class="formulario">
                  <CtInput
                    v-model="formulario.direccion_principal"
                    label="Calle"
                    placeholder="Calle Compañía"
                    required
                    :error="errores.direccion_principal ?? null"
                    hint="Para cambiar número, depto o referencia, usa Mis Direcciones."
                  />

                  <div class="formulario__fila">
                    <CtSelect
                      :model-value="formulario.regionId"
                      label="Región"
                      :options="opcionesRegion"
                      :disabled="geo.cargando"
                      @update:model-value="cambiarRegion"
                    />
                    <CtSelect
                      v-model="formulario.comunaId"
                      label="Comuna"
                      required
                      :options="opcionesComuna"
                      :error="errores.comunaId ?? null"
                      :hint="formulario.regionId ? undefined : 'Selecciona primero una región'"
                    />
                  </div>

                  <CtAlert tone="info" compact>
                    <p class="linea">
                      <CtIcon name="info" :size="15" />
                      <span>
                        Tu región de entrega se determina por la comuna de esta dirección ({{
                          nombreRegionActual
                        }}). Los productores sólo venden dentro de su región.
                      </span>
                    </p>
                  </CtAlert>
                </div>
              </section>

              <div class="acciones">
                <CtButton :loading="guardando" @click="guardar">
                  <template #icon><CtIcon name="check" :size="16" /></template>
                  Guardar Cambios
                </CtButton>
                <CtButton variant="ghost" :disabled="guardando" @click="descartar">
                  Descartar
                </CtButton>
              </div>
            </div>

            <!-- ================== Seguridad ================== -->
            <div v-show="pestana === 'seguridad'" class="stack">
              <section class="bloque">
                <h2 class="bloque__titulo">Cambiar contraseña</h2>
                <p class="bloque__texto">
                  Entre 8 y 72 caracteres ASCII (sin tildes, ñ ni emojis), con al menos una
                  mayúscula, una minúscula, un número y un símbolo. La fortaleza se mide mientras
                  escribes; al cambiarla cerraremos tu sesión y deberás ingresar otra vez con la
                  contraseña nueva.
                </p>
                <div class="formulario">
                  <CtInput
                    v-model="clave.actual"
                    label="Contraseña actual"
                    type="password"
                    prevent-autofill
                    :maxlength="LIMITES.password"
                    :error="erroresClave.actual ?? null"
                  />
                  <div class="formulario__fila">
                    <CtInput
                      v-model="clave.nueva"
                      label="Nueva contraseña"
                      type="password"
                      prevent-autofill
                      :maxlength="LIMITES.password"
                      :error="erroresClave.nueva ?? null"
                    />
                    <CtInput
                      v-model="clave.repetir"
                      label="Repetir contraseña"
                      type="password"
                      prevent-autofill
                      :maxlength="LIMITES.password"
                      :error="erroresClave.repetir ?? null"
                    />
                  </div>
                  <CtProgressBar
                    v-if="clave.nueva"
                    :value="fuerzaClave.score"
                    :max="4"
                    :tone="fuerzaClave.tone"
                    show-label
                    :label="fuerzaClave.label"
                    class="seguridad__fuerza"
                  />
                  <ul
                    v-if="clave.nueva"
                    class="seguridad__requisitos"
                    aria-label="Requisitos de la contraseña"
                  >
                    <li
                      v-for="req in PASSWORD_REQUIREMENTS"
                      :key="req.key"
                      :class="{ 'is-ok': requisitosClave[req.key] }"
                    >
                      <CtIcon
                        :name="requisitosClave[req.key] ? 'check' : 'close'"
                        :size="13"
                        aria-hidden="true"
                      />
                      <span>{{ req.label }}</span>
                    </li>
                  </ul>
                  <div class="row">
                    <CtButton
                      :loading="guardandoClave"
                      :disabled="guardandoClave"
                      @click="guardarClave"
                    >
                      <template #icon><CtIcon name="lock" :size="16" /></template>
                      Actualizar contraseña
                    </CtButton>
                  </div>
                </div>
              </section>

              <section class="bloque">
                <h2 class="bloque__titulo">Estado de la cuenta</h2>
                <dl class="datos">
                  <div class="dato">
                    <dt class="dato__label">Correo verificado</dt>
                    <dd class="dato__valor">
                      {{ correoVerificado ? 'Sí' : 'Pendiente de confirmación' }}
                    </dd>
                  </div>
                  <div class="dato">
                    <dt class="dato__label">Rol</dt>
                    <dd class="dato__valor">{{ auth.rol }}</dd>
                  </div>
                </dl>
              </section>

              <CtAlert tone="info" compact title="Cierre de sesión">
                <p class="linea">
                  <CtIcon name="logout" :size="15" />
                  <span>
                    CuTuCo no expone un servicio para cerrar sesiones en todos los dispositivos a la
                    vez: usa "Cerrar sesión" en este dispositivo y cambia la contraseña si sospechas
                    de un acceso.
                  </span>
                </p>
                <CtButton size="sm" variant="secondary" @click="cerrarSesion">
                  <template #icon><CtIcon name="logout" :size="15" /></template>
                  Cerrar sesión
                </CtButton>
              </CtAlert>
            </div>

            <!-- ================ Pagos y comprobantes ================ -->
            <div v-show="pestana === 'facturacion'" class="stack">
              <CtAlert tone="info" title="Pagos y comprobantes">
                <p class="linea">
                  <CtIcon name="doc" :size="16" />
                  <span>
                    La plataforma no emite factura electrónica. Cada pago queda registrado con su
                    orden Webpay y su estado de autorización, y puedes exportar el detalle en Excel.
                  </span>
                </p>
              </CtAlert>

              <section class="bloque">
                <div class="bloque__cabecera">
                  <h2 class="bloque__titulo">Tus pagos</h2>
                  <CtButton
                    size="sm"
                    variant="secondary"
                    :disabled="!filasPagos.length"
                    @click="exportarPagos"
                  >
                    <template #icon><CtIcon name="download" :size="15" /></template>
                    Exportar Excel
                  </CtButton>
                </div>

                <CtTable
                  :columns="columnasPagos"
                  :rows="filasPagos"
                  empty-icon=""
                  empty-title="Sin transacciones"
                  empty-message="Cuando confirmes un pago con Webpay aparecerá aquí con su estado."
                  min-width="640px"
                >
                  <template #cell-codigo_pedido="{ row }">
                    <router-link :to="`/cliente/pedidos/${row.id}`" class="mono font-semibold">
                      {{ row.codigo_pedido }}
                    </router-link>
                  </template>
                  <template #cell-estado_pago="{ row }">
                    <StatusBadge type="pago" :value="row.estado_pago" size="sm" />
                  </template>
                  <template #cell-monto="{ row }">
                    <span class="font-semibold">{{ formatCLP(row.monto) }}</span>
                  </template>
                  <template #cell-creado_en="{ row }">
                    {{ formatDateTime(row.creado_en) }}
                  </template>
                </CtTable>
              </section>
            </div>

            <!-- ================== Notificaciones ================== -->
            <div v-show="pestana === 'notificaciones'" class="stack">
              <NotificationPreferences :rol="auth.rol" @saved="sincronizarNotificaciones" />

              <section class="bloque">
                <div class="bloque__cabecera">
                  <h2 class="bloque__titulo">
                    Alertas de tu cuenta
                    <CtBadge v-if="ui.noLeidas" tone="accent" size="sm">{{ ui.noLeidas }}</CtBadge>
                  </h2>
                  <div class="row row--wrap">
                    <CtButton size="sm" variant="ghost" @click="sincronizarNotificaciones">
                      <template #icon><CtIcon name="refresh" :size="15" /></template>
                      Actualizar
                    </CtButton>
                    <CtButton
                      size="sm"
                      variant="secondary"
                      :disabled="!ui.noLeidas"
                      @click="marcarTodasLeidas"
                    >
                      Marcar todas como leídas
                    </CtButton>
                  </div>
                </div>

                <ul v-if="ui.notifications.length" class="notificaciones">
                  <li
                    v-for="alerta in ui.notifications"
                    :key="alerta.id"
                    class="notificacion"
                    :class="{ 'is-leida': alerta.leida }"
                  >
                    <div class="notificacion__cuerpo">
                      <p class="notificacion__titulo">{{ alerta.titulo }}</p>
                      <p class="notificacion__mensaje">{{ alerta.mensaje }}</p>
                    </div>
                    <CtButton v-if="alerta.enlace" size="sm" variant="ghost" :to="alerta.enlace">
                      Ver
                      <template #trailing><CtIcon name="chevronRight" :size="14" /></template>
                    </CtButton>
                    <CtButton
                      v-else-if="!alerta.leida"
                      size="sm"
                      variant="ghost"
                      @click="ui.marcarLeida(alerta.id)"
                    >
                      Marcar leída
                    </CtButton>
                  </li>
                </ul>

                <p v-else class="text-sm text-muted">No tienes alertas pendientes por ahora.</p>
              </section>
            </div>
          </div>
        </CtCard>
      </div>

      <aside class="perfil__aside stack">
        <CtSpinner v-if="cargandoResumen" label="Cargando tu actividad" />

        <CtAlert v-else-if="errorResumen" tone="danger" title="No se pudo cargar tu actividad">
          <p class="linea">
            <CtIcon name="alert" :size="16" />
            <span>{{ errorResumen }}</span>
          </p>
          <CtButton size="sm" variant="secondary" @click="cargarResumen">Reintentar</CtButton>
        </CtAlert>

        <template v-else>
          <CtCard title="Resumen de Actividad" padding="md">
            <div class="grid-kpi">
              <CtStatCard
                label="Pedidos totales"
                :value="resumen?.total ?? 0"
                tone="primary"
                hint="Históricos"
              />
              <CtStatCard
                label="Vendedores distintos"
                :value="vendedoresSeguidos"
                tone="info"
                hint="Productores de tus pedidos"
              />
            </div>

            <dl class="datos datos--compactas">
              <div class="dato">
                <dt class="dato__label">Completados</dt>
                <dd class="dato__valor">{{ resumen?.completados ?? 0 }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Pendientes</dt>
                <dd class="dato__valor">{{ pendientesActividad }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Total gastado</dt>
                <dd class="dato__valor">{{ formatCLP(resumen?.gastado ?? 0) }}</dd>
              </div>
            </dl>

            <div v-if="ultimaActividad" class="ultima">
              <span class="eyebrow">Último pedido</span>
              <div class="row row--wrap">
                <router-link
                  :to="`/cliente/pedidos/${ultimaActividad.id}`"
                  class="mono font-semibold"
                >
                  {{ ultimaActividad.codigo_pedido }}
                </router-link>
                <StatusBadge type="pedido" :value="ultimaActividad.estado" size="sm" />
              </div>
              <p class="text-xs text-muted">
                {{ formatDate(ultimaActividad.creado_en) }} ·
                {{ formatCLP(ultimaActividad.total) }}
              </p>
            </div>

            <CtButton block variant="secondary" to="/cliente/pedidos" class="aside-boton">
              Ver historial completo
            </CtButton>
          </CtCard>

          <CtCard title="Pago seguro con Webpay" padding="md" flat>
            <p class="text-sm text-soft">
              Cuando confirmas un pedido, pagas de forma segura con Webpay y el productor recibe el
              pago de su venta. CuTuCo no retiene el dinero de tus compras.
            </p>
            <div class="chips chips--compactas">
              <CtBadge tone="success" size="sm">
                {{ pedidos.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO).length }} entregados
              </CtBadge>
              <CtBadge tone="warning" size="sm">
                {{ pedidos.filter((p) => p.estado === ESTADO_PEDIDO.EN_PREPARACION).length }} en
                preparación
              </CtBadge>
            </div>
          </CtCard>
        </template>
      </aside>
    </div>

    <!-- ============ Cambio de correo ============ -->
    <CtModal v-model="modalCorreo" title="Cambiar correo electrónico" size="sm">
      <div class="stack">
        <CtAlert v-if="errorCorreo" tone="danger">{{ errorCorreo }}</CtAlert>

        <CtAlert
          v-if="correoPendiente"
          tone="info"
          compact
          title="Cambio pendiente de confirmación"
        >
          <p class="linea">
            <CtIcon name="mail" :size="15" />
            <span>
              Pediste cambiar tu correo a <strong>{{ correoPendiente }}</strong>. Revisa esa bandeja
              y la de <strong>{{ correo }}</strong>: el cambio se aplica cuando confirmes en ambas
              direcciones.
            </span>
          </p>
        </CtAlert>

        <CtInput
          v-model="nuevoCorreo"
          label="Correo nuevo"
          type="email"
          placeholder="tucorreo@ejemplo.cl"
          autocomplete="email"
          :maxlength="LIMITES.email"
          hint="Te enviaremos un enlace de confirmación a esta dirección y a la actual."
          required
        />

        <CtInput
          v-model="claveCorreo"
          label="Contraseña actual"
          type="password"
          prevent-autofill
          hint="La exigimos para reautenticar el cambio de correo."
          :error="errorClaveCorreo"
          required
        />

        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              El cambio de correo no altera tus pedidos ni tu historial. Debes confirmarlo en la
              dirección nueva y en la actual antes de que se aplique.
            </span>
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="guardandoCorreo" @click="modalCorreo = false">
          Cancelar
        </CtButton>
        <CtButton :loading="guardandoCorreo" :disabled="guardandoCorreo" @click="cambiarCorreo">
          Enviar confirmación
        </CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.linea code {
  font-family: var(--ct-font-mono);
  font-size: 0.92em;
  background: var(--ct-surface-alt);
  border-radius: var(--ct-radius-sm);
  padding: 0 4px;
}

.perfil {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

@media (max-width: 1100px) {
  .perfil {
    grid-template-columns: minmax(0, 1fr);
  }
}

.cabecera {
  display: flex;
  align-items: center;
  gap: var(--ct-space-4);
  padding: var(--ct-space-5);
}

.cabecera__datos {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.cabecera__nombre {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
}

.cabecera__correo {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.cabecera__chips {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  margin-top: var(--ct-space-2);
}

.perfil-foto {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: var(--ct-space-6);
}

.perfil-foto__preview {
  box-shadow: var(--ct-shadow-md);
}

.perfil-foto__acciones {
  min-width: 0;
}

@media (max-width: 560px) {
  .perfil-foto {
    grid-template-columns: 1fr;
    justify-items: center;
  }

  .perfil-foto__acciones {
    width: 100%;
  }
}

.pestanas {
  padding: 0 var(--ct-space-5);
}

.pestanas__cuerpo {
  padding: var(--ct-space-6) var(--ct-space-5);
}

.bloque {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.bloque__cabecera {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.bloque__titulo {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
}

.bloque__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.formulario {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.seguridad__fuerza {
  margin-top: calc(-1 * var(--ct-space-2));
}

.seguridad__requisitos {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
  gap: var(--ct-space-1) var(--ct-space-3);
  margin: 0;
  padding: 0;
  list-style: none;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.seguridad__requisitos li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.seguridad__requisitos li.is-ok {
  color: var(--ct-success);
}

.formulario__fila {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--ct-space-4);
}

.acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.datos--compactas {
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-4);
}

.dato {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  text-align: right;
}

.ultima {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
  margin-top: var(--ct-space-4);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
}

.aside-boton {
  margin-top: var(--ct-space-4);
}

.chips {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.chips--compactas {
  margin-top: var(--ct-space-3);
}

.notificaciones {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.notificacion {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
}

.notificacion:last-child {
  border-bottom: none;
}

.notificacion.is-leida {
  opacity: 0.65;
}

.notificacion__cuerpo {
  min-width: 0;
}

.notificacion__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.notificacion__mensaje {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  overflow-wrap: anywhere;
  word-break: break-word;
}
</style>
