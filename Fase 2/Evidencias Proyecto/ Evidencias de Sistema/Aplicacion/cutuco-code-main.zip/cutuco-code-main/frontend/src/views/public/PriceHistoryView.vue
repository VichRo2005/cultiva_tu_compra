<script setup>
/**
 * CuTuCo — Trazabilidad de precios (público).
 * Historial por producto y comparativo regional, con el estilo del diseño.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import PriceHistoryChart from '@/components/domain/PriceHistoryChart.vue'
import ReputationGauge from '@/components/domain/ReputationGauge.vue'
import {
  getArbolCategorias,
  getPreciosPorRegion,
  getTrazabilidadPrecios,
  listProductos,
} from '@/services/catalog'
import { useGeographyStore } from '@/stores/geography'
import { formatCLP, formatDate, formatPercent, pluralize } from '@/lib/format'
import { LABELS, FUENTE_PRECIO } from '@/lib/constants'

const route = useRoute()
const geo = useGeographyStore()

const PESTANAS = [
  { value: 'producto', label: 'Por producto' },
  { value: 'comparativo', label: 'Comparativo regional' },
]

const tab = ref('producto')
const categorias = ref([])
const productoId = ref(route.query.producto ? String(route.query.producto) : '')
const categoriaId = ref('')
const regionId = ref('')

const cargando = ref(false)
const error = ref(null)
const trazabilidad = ref(null)
const porRegion = ref([])
const opcionesProducto = ref([])

const opcionesCategoria = computed(() => {
  const planas = []
  const walk = (nodos) => {
    for (const nodo of nodos) {
      planas.push({ value: nodo.id, label: nodo.nombre })
      walk(nodo.hijos ?? [])
    }
  }
  walk(categorias.value)
  return [{ value: '', label: 'Todas las categorías' }, ...planas]
})

const opcionesRegion = computed(() => [
  { value: '', label: 'Todas las regiones' },
  ...geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
])

const columnasRegion = [
  { key: 'regionNombre', label: 'Región' },
  { key: 'precio', label: 'Precio CuTuCo', align: 'right', format: (v) => (v == null ? '—' : formatCLP(v)) },
  {
    key: 'referencia',
    label: 'Referencia externa',
    align: 'right',
    format: (v) => (v == null ? '—' : formatCLP(v)),
  },
  { key: 'variacion', label: 'Diferencia', align: 'right' },
]

const eventos = computed(() => [...(trazabilidad.value?.serie ?? [])].reverse().slice(0, 12))

async function cargar() {
  if (tab.value === 'producto' && !productoId.value) return
  cargando.value = true
  error.value = null
  try {
    if (tab.value === 'producto') {
      trazabilidad.value = await getTrazabilidadPrecios({
        productoId: productoId.value,
        regionId: regionId.value || null,
      })
      porRegion.value = []
    } else {
      trazabilidad.value = null
      porRegion.value = await getPreciosPorRegion({
        productoId: categoriaId.value ? null : productoId.value,
        categoriaId: categoriaId.value || null,
      })
    }
  } catch (e) {
    error.value = e.message
    trazabilidad.value = null
    porRegion.value = []
  } finally {
    cargando.value = false
  }
}

onMounted(async () => {
  void geo.load()
  categorias.value = await getArbolCategorias()
  if (!productoId.value) {
    const { items } = await listProductos({ pageSize: 24, soloStock: true })
    opcionesProducto.value = items.map((p) => ({ value: p.id, label: p.nombre }))
    if (items.length) productoId.value = items[0].id
  }
  await cargar()
})

watch([productoId, regionId, categoriaId, tab], cargar)

function tonoVariacion(valor) {
  if (valor == null) return 'muted'
  if (valor <= -5) return 'success'
  if (valor >= 5) return 'danger'
  return 'warning'
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Trazabilidad de precios</h1>
        <p class="page-head__subtitle">
          Cada cambio de precio queda registrado con fecha y zona, junto a la referencia externa de
          la región. Así comparas antes de comprar.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" to="/catalogo">Explorar el catálogo</CtButton>
      </div>
    </header>

    <CtCard padding="sm">
      <div class="precios__controles">
        <CtTabs v-model="tab" :tabs="PESTANAS" />

        <CtSelect
          v-if="tab === 'producto'"
          v-model="productoId"
          class="precios__control"
          label="Producto"
          :options="opcionesProducto"
          placeholder="Selecciona un producto"
        />
        <CtSelect
          v-else
          v-model="categoriaId"
          class="precios__control"
          label="Categoría"
          :options="opcionesCategoria"
        />
        <CtSelect v-model="regionId" class="precios__control" label="Región" :options="opcionesRegion" />
      </div>
    </CtCard>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el historial">
      {{ error }}
      <CtButton variant="secondary" size="sm" type="button" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-else-if="cargando" label="Calculando historial…" />

    <!-- ==================== POR PRODUCTO ==================== -->
    <template v-else-if="tab === 'producto'">
      <CtEmptyState
        v-if="!trazabilidad"
        title="Sin historial disponible"
        message="Este producto todavía no tiene registros de precio publicados."
      >
        <CtButton variant="secondary" to="/catalogo">Volver al catálogo</CtButton>
      </CtEmptyState>

      <div v-else class="precios">
        <CtCard
          class="precios__grafico"
          :title="trazabilidad.producto.nombre"
          :subtitle="`${trazabilidad.producto.productor?.nombre_comercial ?? 'Productor CuTuCo'} · ${trazabilidad.region?.nombre ?? 'Chile'}`"
        >
          <div class="precios__resumen">
            <div>
              <p class="eyebrow">Precio actual</p>
              <p class="precios__actual">{{ formatCLP(trazabilidad.producto.precio) }}</p>
            </div>
            <CtBadge v-if="trazabilidad.reputacion" tone="neutral" size="sm">
              {{ Number(trazabilidad.reputacion.puntaje_reputacion ?? 0).toFixed(1) }} de 5.0 ·
              {{ trazabilidad.reputacion.cantidad_evaluaciones }} {{ pluralize(trazabilidad.reputacion.cantidad_evaluaciones, 'evaluación', 'evaluaciones') }}
            </CtBadge>
          </div>

          <PriceHistoryChart
            :historial="trazabilidad.serie"
            :precio-actual="trazabilidad.producto.precio"
            :height="300"
          />
        </CtCard>

        <div class="precios__lateral">
          <CtCard v-if="trazabilidad.reputacion" title="Reputación del productor" padding="md">
            <ReputationGauge
              size="md"
              :puntaje="Number(trazabilidad.reputacion.puntaje_reputacion ?? 0)"
              :cantidad="Number(trazabilidad.reputacion.cantidad_evaluaciones ?? 0)"
            />
          </CtCard>

          <CtCard title="Últimos registros" padding="sm">
            <ol v-if="eventos.length" class="registros">
              <li v-for="evento in eventos" :key="evento.id" class="registros__item">
                <span class="registros__fecha">{{ formatDate(evento.registrado_en) }}</span>
                <span class="registros__valor">{{ formatCLP(evento.precio_nuevo) }}</span>
                <CtBadge
                  :tone="evento.fuente === FUENTE_PRECIO.MARKETPLACE ? 'primary' : 'accent'"
                  size="sm"
                >
                  {{ LABELS.fuentePrecio[evento.fuente] ?? evento.fuente }}
                </CtBadge>
              </li>
            </ol>
            <CtEmptyState
              v-else
              compact
              title="Sin registros"
              message="Aún no hay movimientos de precio para este producto."
            />
          </CtCard>

          <CtCard title="Cómo leer esto" padding="sm">
            <ul class="lectura">
              <li>
                <strong>Referencia externa</strong> es el precio promedio de feria de la región para
                el mismo producto.
              </li>
              <li><strong>Precio CuTuCo</strong> es lo que fija el productor desde su cosecha.</li>
              <li>Una diferencia negativa indica que compras más barato que en feria.</li>
            </ul>
            <CtButton variant="secondary" block size="sm" :to="`/producto/${trazabilidad.producto.id}`">
              Ver el producto
            </CtButton>
          </CtCard>
        </div>
      </div>
    </template>

    <!-- ==================== COMPARATIVO ==================== -->
    <template v-else>
      <CtEmptyState
        v-if="!porRegion.length"
        title="Sin datos comparativos"
        message="Selecciona una categoría o un producto con historial para comparar entre regiones."
      >
        <CtButton variant="secondary" to="/catalogo">Explorar el catálogo</CtButton>
      </CtEmptyState>

      <CtCard v-else title="Precio por región" subtitle="Último valor registrado por zona" padding="none">
        <CtTable :columns="columnasRegion" :rows="porRegion" row-key="regionId" empty-title="Sin regiones con datos">
          <template #variacion="{ row }">
            <CtBadge :tone="tonoVariacion(row.variacion)" size="sm">
              {{ row.variacion == null ? 'Sin referencia' : `${formatPercent(row.variacion)} vs. referencia` }}
            </CtBadge>
          </template>
        </CtTable>
      </CtCard>

      <CtAlert tone="info" compact>
        <CtIcon name="info" :size="16" class="precios__info-icon" />
        La comparación usa el último precio publicado en cada región. Las regiones sin cobertura de
        ningún productor no aparecen en el listado.
      </CtAlert>
    </template>
  </div>
</template>

<style scoped>
.precios__controles {
  display: grid;
  grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--ct-space-4);
  align-items: end;
}

.precios__control {
  min-width: 0;
}

.precios {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-6);
  align-items: start;
}

.precios__resumen {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-4);
  margin-bottom: var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
}

.precios__actual {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  color: var(--ct-primary-strong);
}

.precios__lateral {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.registros {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.registros__item {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  padding-block: var(--ct-space-2);
  border-bottom: 1px solid var(--ct-border);
  font-size: var(--ct-fs-sm);
}

.registros__item:last-child {
  border-bottom: none;
}

.registros__fecha {
  flex: 1;
  min-width: 0;
  color: var(--ct-text-soft);
}

.registros__valor {
  font-weight: var(--ct-fw-semibold);
}

.lectura {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  margin-bottom: var(--ct-space-4);
}

.lectura strong {
  color: var(--ct-text);
}

.precios__info-icon {
  display: inline-block;
  vertical-align: -3px;
  margin-right: var(--ct-space-1);
}

@media (max-width: 1024px) {
  .precios,
  .precios__controles {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
