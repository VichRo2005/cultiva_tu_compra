<script setup>
/**
 * CuTuCo — Tarjeta de indicador (KPI).
 *
 * El desglose monetario es una segunda vista de la misma tarjeta: se muestra
 * dentro de un panel superpuesto, de tamaño estable, en vez de expandir la
 * grilla del dashboard o abrir un detalle que compita con otros KPI.
 */
import { computed, nextTick, ref } from 'vue'
import CtCard from './CtCard.vue'
import CtIcon from './CtIcon.vue'
import { resolveIconName } from '@/lib/icons'

const props = defineProps({
  label: { type: String, required: true },
  value: { type: [String, Number], required: true },
  unit: { type: String, default: null },
  hint: { type: String, default: null },
  icon: { type: String, default: null },
  tone: { type: String, default: 'primary' }, // primary | accent | success | warning | danger | info
  delta: { type: Number, default: null },
  deltaLabel: { type: String, default: 'vs. período anterior' },
  progress: { type: Number, default: null },
  to: { type: [String, Object], default: null },
  /** Explicación opcional para indicadores que representan dinero. */
  calculation: { type: String, default: null },
})

const icono = computed(() => resolveIconName(props.icon))
const mostrandoCalculo = ref(false)
const botonDetalle = ref(null)
const botonCerrarDetalle = ref(null)

async function abrirDetalle() {
  mostrandoCalculo.value = true
  await nextTick()
  botonCerrarDetalle.value?.focus()
}

async function cerrarDetalle() {
  mostrandoCalculo.value = false
  await nextTick()
  botonDetalle.value?.focus()
}
</script>

<template>
  <CtCard
    padding="md"
    hover
    class="kpi"
    :class="[
      `kpi--${tone}`,
      { 'kpi--con-detalle': calculation, 'kpi--mostrando-detalle': mostrandoCalculo },
    ]"
  >
    <component
      :is="to ? 'router-link' : 'div'"
      class="kpi__inner"
      :to="to ?? undefined"
      :aria-hidden="mostrandoCalculo || undefined"
      :tabindex="mostrandoCalculo && to ? -1 : undefined"
    >
      <div class="kpi__head">
        <span class="kpi__label">{{ label }}</span>
        <span v-if="icono" class="kpi__icon" aria-hidden="true">
          <CtIcon :name="icono" :size="17" />
        </span>
      </div>

      <div class="kpi__value">
        {{ value }}<span v-if="unit" class="kpi__unit">{{ unit }}</span>
      </div>

      <div class="kpi__foot">
        <span v-if="delta !== null" class="kpi__delta" :class="delta >= 0 ? 'is-up' : 'is-down'">
          <CtIcon :name="delta >= 0 ? 'arrowUp' : 'arrowDown'" :size="12" />
          {{ Math.abs(delta) }}%
        </span>
        <span v-if="hint || delta !== null" class="kpi__hint">
          {{ delta !== null ? deltaLabel : hint }}
        </span>
      </div>

      <div v-if="progress !== null" class="kpi__progress">
        <span
          class="kpi__progress-bar"
          :style="{ width: `${Math.min(100, Math.max(0, progress))}%` }"
        />
      </div>
    </component>

    <button
      v-if="calculation && !mostrandoCalculo"
      ref="botonDetalle"
      type="button"
      class="kpi__detail-trigger"
      :aria-label="`Ver cómo se calcula ${label}`"
      :aria-expanded="mostrandoCalculo"
      @click="abrirDetalle"
    >
      <CtIcon name="info" :size="15" aria-hidden="true" />
      Cómo se calcula
    </button>

    <Transition name="kpi-detail">
      <section
        v-if="calculation && mostrandoCalculo"
        class="kpi__detail"
        :aria-label="`Cómo se calcula ${label}`"
        role="region"
      >
        <div class="kpi__detail-head">
          <span class="kpi__detail-title">Cómo se calcula</span>
          <button
            ref="botonCerrarDetalle"
            type="button"
            class="kpi__detail-close"
            aria-label="Volver al indicador"
            @click="cerrarDetalle"
          >
            <CtIcon name="close" :size="16" aria-hidden="true" />
            <span>Volver</span>
          </button>
        </div>
        <p class="kpi__detail-text">{{ calculation }}</p>
      </section>
    </Transition>
  </CtCard>
</template>

<style scoped>
.kpi {
  min-height: 176px;
  overflow: hidden;
}

.kpi--con-detalle {
  min-height: 204px;
}

.kpi :deep(.ct-card__body) {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  position: relative;
}

.kpi__inner {
  color: inherit;
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: var(--ct-space-2);
  min-height: 0;
  text-decoration: none;
}

.kpi__inner:hover {
  text-decoration: none;
}

a.kpi__inner:hover {
  color: var(--ct-primary-strong);
}

a.kpi__inner:hover .kpi__value {
  color: var(--ct-primary-strong);
}

a.kpi__inner:hover .kpi__icon {
  transform: scale(1.08);
}

a.kpi__inner:hover .kpi__label {
  color: var(--ct-text-soft);
}

.kpi__head {
  align-items: flex-start;
  display: flex;
  gap: var(--ct-space-2);
  justify-content: space-between;
}

.kpi__label {
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: var(--ct-tracking-wide);
  text-transform: uppercase;
  transition: color var(--ct-transition);
}

.kpi__icon {
  align-items: center;
  background: var(--ct-primary-soft);
  border-radius: var(--ct-radius);
  color: var(--ct-primary-strong);
  display: grid;
  flex-shrink: 0;
  height: 32px;
  place-items: center;
  transition: transform var(--ct-transition);
  width: 32px;
}

.kpi--accent .kpi__icon {
  background: var(--ct-accent-soft);
  color: var(--ct-accent-strong);
}
.kpi--success .kpi__icon {
  background: var(--ct-success-soft);
  color: var(--ct-success-ink);
}
.kpi--warning .kpi__icon {
  background: var(--ct-warning-soft);
  color: var(--ct-warning-ink);
}
.kpi--danger .kpi__icon {
  background: var(--ct-danger-soft);
  color: var(--ct-danger-strong);
}
.kpi--info .kpi__icon {
  background: var(--ct-info-soft);
  color: var(--ct-info);
}

.kpi__value {
  color: var(--ct-text);
  font-size: var(--ct-fs-3xl);
  font-variant-numeric: tabular-nums;
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: 1.1;
  transition: color var(--ct-transition);
}

.kpi__unit {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-medium);
  margin-left: 2px;
}

.kpi__foot {
  align-items: center;
  display: flex;
  gap: var(--ct-space-2);
  margin-top: auto;
  min-height: 20px;
}

.kpi__delta {
  border-radius: var(--ct-radius-sm);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  padding: 2px 6px;
}

.kpi__delta.is-up {
  background: var(--ct-success-soft);
  color: var(--ct-success-ink);
}

.kpi__delta.is-down {
  background: var(--ct-danger-soft);
  color: var(--ct-danger-strong);
}

.kpi__hint {
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-xs);
}

.kpi__progress {
  background: var(--ct-border);
  border-radius: var(--ct-radius-pill);
  height: 4px;
  margin-top: var(--ct-space-1);
  overflow: hidden;
}

.kpi__progress-bar {
  background: var(--ct-primary);
  border-radius: inherit;
  display: block;
  height: 100%;
}

.kpi__detail-trigger {
  align-items: center;
  align-self: flex-start;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-primary-strong);
  display: inline-flex;
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-3);
  padding: var(--ct-space-1) var(--ct-space-2);
}

.kpi__detail-trigger:hover,
.kpi__detail-close:hover {
  background: var(--ct-primary-soft);
}

.kpi__detail-trigger:focus-visible,
.kpi__detail-close:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: 2px;
}

.kpi__detail {
  background: var(--ct-surface);
  display: flex;
  flex-direction: column;
  inset: 0;
  overflow: auto;
  padding: var(--ct-space-6);
  position: absolute;
  z-index: 1;
}

.kpi__detail-head {
  align-items: center;
  border-bottom: 1px solid var(--ct-border);
  display: flex;
  gap: var(--ct-space-2);
  justify-content: space-between;
  padding-bottom: var(--ct-space-2);
}

.kpi__detail-title {
  color: var(--ct-text);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
}

.kpi__detail-close {
  align-items: center;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-primary-strong);
  display: inline-flex;
  flex-shrink: 0;
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  gap: 4px;
  padding: var(--ct-space-1) var(--ct-space-2);
}

.kpi__detail-text {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
  line-height: 1.5;
  margin-top: var(--ct-space-3);
  overflow-wrap: anywhere;
}

.kpi-detail-enter-active,
.kpi-detail-leave-active {
  transition: opacity 160ms ease;
}

.kpi-detail-enter-from,
.kpi-detail-leave-to {
  opacity: 0;
}

@media (prefers-reduced-motion: reduce) {
  .kpi-detail-enter-active,
  .kpi-detail-leave-active {
    transition: none;
  }
}
</style>
