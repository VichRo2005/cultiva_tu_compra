/**
 * CuTuCo — Reclamos del cliente (RF-025 y RF-026).
 *
 * El reclamo es la vía del cliente para dejar constancia de un problema con un
 * pedido. Vive en `public.reclamos` y lo escribe el propio cliente:
 *
 *   * `reclamos_insert_cliente` (RLS) exige `cliente_id = auth.uid()` y que el
 *     pedido sea suyo.
 *   * `uq_reclamo_abierto_por_pedido` (índice único parcial) permite un solo
 *     reclamo abierto o en revisión por pedido.
 *   * `trg_moderar_reclamo` valida `motivo` y `descripcion` contra
 *     `palabras_prohibidas` y `trg_validar_reclamo` exige que el cliente del
 *     reclamo coincida con el del pedido.
 *
 * Con Webpay Mall el reclamo NO bloquea dinero: el pago ya quedó autorizado y
 * Transbank dispersó el cobro al comercio del productor. El reclamo lo tramita
 * el administrador y puede derivar en un reembolso que el comercio gestiona.
 *
 * El esquema NO tiene columna `resolucion`: la respuesta del vendedor queda en
 * `respuesta_productor`, el cierre en `estado` + `resuelto_en` y el
 * administrador que resolvió en `resuelto_por`.
 */

import { mensajeSeguro } from '@/services/errores'
import { getClient } from '@/lib/supabase'
import { ESTADO_RECLAMO } from '@/lib/constants'
import { currentUserId } from '@/services/session'

/** Estados que mantienen el reclamo vigente (avisos en la interfaz; no bloquean dinero). */
export const RECLAMO_VIGENTE = Object.freeze([ESTADO_RECLAMO.ABIERTO, ESTADO_RECLAMO.EN_REVISION])

/** Mensaje claro para los errores del esquema al abrir un reclamo. */
function limpiarErrorReclamo(mensaje = '') {
  const texto = String(mensaje).replace(/^.*?ERROR:\s*/i, '').replace(/CONTEXT:.*$/s, '').trim()
  if (/uq_reclamo_abierto_por_pedido|duplicate key/i.test(texto)) {
    return 'Este pedido ya tiene un reclamo abierto. Puedes revisarlo en «Mis Reclamos».'
  }
  if (/palabra|moderad|prohibid/i.test(texto)) {
    return 'El texto del reclamo contiene palabras no permitidas. Reescríbelo con tus propias palabras.'
  }
  return mensajeSeguro(texto, 'No se pudo registrar el reclamo')
}

/**
 * Abre un reclamo sobre un pedido del cliente autenticado.
 * @param {{pedidoId: string, motivo: string, descripcion: string}} payload
 */
export async function crearReclamo({ pedidoId, motivo, descripcion }) {
  const client = getClient()
  const clienteId = await currentUserId()
  if (!clienteId) throw new Error('Debes iniciar sesión para abrir un reclamo')
  const motivoLimpio = String(motivo ?? '').trim()
  const descripcionLimpia = String(descripcion ?? '').trim()
  if (!motivoLimpio) throw new Error('Selecciona el motivo del reclamo')
  if (!descripcionLimpia) throw new Error('Describe lo que ocurrió con tu pedido')

  const { data, error } = await client
    .from('reclamos')
    .insert({
      pedido_id: pedidoId,
      cliente_id: clienteId,
      motivo: motivoLimpio,
      descripcion: descripcionLimpia,
    })
    .select()
    .single()
  if (error) throw new Error(limpiarErrorReclamo(error.message))
  return data
}

/** Historial de reclamos del cliente autenticado, con el pedido asociado. */
export async function listMisReclamos() {
  const client = getClient()
  const clienteId = await currentUserId()
  if (!clienteId) return []

  const { data, error } = await client
    .from('reclamos')
    .select('*')
    .eq('cliente_id', clienteId)
    .order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const reclamos = data ?? []
  if (!reclamos.length) return []

  const pedidoIds = [...new Set(reclamos.map((r) => r.pedido_id).filter(Boolean))]
  const { data: pedidos } = await client
    .from('pedidos')
    .select('id, codigo_pedido, estado, total, productor_id, creado_en, nombre_destinatario')
    .in('id', pedidoIds)

  const productorIds = [...new Set((pedidos ?? []).map((p) => p.productor_id).filter(Boolean))]
  const { data: productores } = productorIds.length
    ? await client.from('productores').select('id, nombre_comercial').in('id', productorIds)
    : { data: [] }

  const pedidoMap = new Map((pedidos ?? []).map((p) => [p.id, p]))
  const productorMap = new Map((productores ?? []).map((p) => [p.id, p]))

  return reclamos.map((reclamo) => {
    const pedido = pedidoMap.get(reclamo.pedido_id) ?? null
    return {
      ...reclamo,
      pedido,
      productor: pedido ? (productorMap.get(pedido.productor_id) ?? null) : null,
      vigente: RECLAMO_VIGENTE.includes(reclamo.estado),
    }
  })
}

/** Reclamo con su pedido, el vendedor y el administrador que lo resolvió. */
export async function getReclamoDetalle(reclamoId) {
  const client = getClient()
  const { data: reclamo, error } = await client
    .from('reclamos')
    .select('*')
    .eq('id', reclamoId)
    .maybeSingle()
  if (error || !reclamo) return null

  const { data: pedido } = await client.from('pedidos').select('*').eq('id', reclamo.pedido_id).maybeSingle()
  const { data: productor } = pedido
    ? await client.from('productores').select('*').eq('id', pedido.productor_id).maybeSingle()
    : { data: null }
  const { data: revisor } = reclamo.resuelto_por
    ? await client
        .from('perfiles')
        .select('id, nombre, apellido')
        .eq('id', reclamo.resuelto_por)
        .maybeSingle()
    : { data: null }

  return {
    ...reclamo,
    pedido: pedido ?? null,
    productor: productor ?? null,
    revisor: revisor ?? null,
    vigente: RECLAMO_VIGENTE.includes(reclamo.estado),
  }
}

/**
 * Reclamo vigente de un pedido, si existe. La RLS sólo deja ver los reclamos
 * propios, así que sirve para decidir si mostrar el botón «Abrir reclamo».
 */
export async function getReclamoVigenteDePedido(pedidoId) {
  const client = getClient()
  const { data } = await client
    .from('reclamos')
    .select('*')
    .eq('pedido_id', pedidoId)
    .in('estado', RECLAMO_VIGENTE)
    .maybeSingle()
  return data ?? null
}

/**
 * Helpers de presentación del cliente en la bandeja del vendedor. Viven en
 * `lib/orders.js` para que las vistas no dependan del mock del servicio y para
 * compartirlos con las pruebas puras (HAL-VEN-032).
 */
export { identificadorClienteReclamo, nombreClienteReclamo } from '@/lib/orders'

/* ---------------------------------------------------------------- */
/* Bandeja del vendedor (RF-025 y RF-026)                             */
/* ---------------------------------------------------------------- */

/**
 * Reclamos recibidos en los pedidos del productor autenticado.
 *
 * La RLS `reclamos_select_participantes` ya deja ver al productor propietario los
 * reclamos de sus pedidos; aquí se resuelven explícitamente sus pedidos para
 * hidratar el reclamo con el pedido y el cliente.
 */
export async function listReclamosProductor(productorId) {
  if (!productorId) return []
  const client = getClient()

  const { data: pedidos, error: pedidosError } = await client
    .from('pedidos')
    .select('id, codigo_pedido, estado, total, cliente_id, nombre_destinatario, creado_en')
    .eq('productor_id', productorId)
    .order('creado_en', { ascending: false })
  if (pedidosError) throw new Error(mensajeSeguro(pedidosError))
  if (!pedidos?.length) return []

  const { data: reclamos, error } = await client
    .from('reclamos')
    .select('*')
    .in(
      'pedido_id',
      pedidos.map((p) => p.id),
    )
    .order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const pedidoMap = new Map(pedidos.map((p) => [p.id, p]))
  const clienteIds = [...new Set((reclamos ?? []).map((r) => r.cliente_id).filter(Boolean))]
  const { data: perfiles } = clienteIds.length
    ? await client.from('perfiles').select('id, nombre, apellido, telefono').in('id', clienteIds)
    : { data: [] }
  const perfilMap = new Map((perfiles ?? []).map((p) => [p.id, p]))

  return (reclamos ?? []).map((reclamo) => ({
    ...reclamo,
    pedido: pedidoMap.get(reclamo.pedido_id) ?? null,
    cliente: perfilMap.get(reclamo.cliente_id) ?? null,
    vigente: RECLAMO_VIGENTE.includes(reclamo.estado),
  }))
}

/**
 * RF-027: el vendedor responde un reclamo de su pedido mientras siga abierto.
 *
 * La policy `reclamos_update_productor_admin` deja actualizar al productor
 * propietario, y el trigger `proteger_campos_reclamo` le permite escribir
 * únicamente `respuesta_productor`: el estado y la resolución siguen siendo del
 * administrador.
 */
export async function responderReclamo({ reclamoId, respuesta }) {
  const client = getClient()
  const texto = String(respuesta ?? '').trim()
  if (!texto) throw new Error('Escribe una respuesta para el cliente')

  const { data, error } = await client
    .from('reclamos')
    .update({ respuesta_productor: texto })
    .eq('id', reclamoId)
    .in('estado', ['abierto', 'en_revision'])
    .select()
    .single()
  if (error) throw new Error(limpiarErrorReclamo(error.message))
  return data
}
