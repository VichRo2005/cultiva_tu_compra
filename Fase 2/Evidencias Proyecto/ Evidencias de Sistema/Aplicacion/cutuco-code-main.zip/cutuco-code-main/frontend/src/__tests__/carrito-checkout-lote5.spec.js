/**
 * CuTuCo — Lote 5: Carrito y cobertura + Checkout y datos tributarios.
 *
 * Revalidación ejecutable de CK-0063/0067/0078/0079/0081/0374/0388-relacionados:
 * comportamiento del carrito (agregar válido, rechazar inválido, checkout vacío
 * bloqueado en UI) y verificaciones de fuente de los contratos de checkout
 * (snapshot de entrega, documento tributario, región desde tabla controlada).
 */
import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { readFileSync } from 'node:fs'

import { useCartStore } from '@/stores/cart'

const src = (p) => readFileSync(`src/${p}`, 'utf8')

function producto(overrides = {}) {
  return {
    id: '30000000-0000-0000-0000-000000000101',
    nombre: 'Tomates Roma de Paine',
    precio: 2800,
    stock: 10,
    unidad_medida: 'kg',
    productor_id: '20000000-0000-0000-0000-000000000001',
    productor: { nombre_comercial: 'Huerta Paine' },
    imagenPrincipal: null,
    ...overrides,
  }
}

describe('CK-0063 · agregar producto con cantidad válida', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it('registra producto, cantidad, subtotal y productor correcto', () => {
    const cart = useCartStore()
    cart.agregar(producto(), 3)
    expect(cart.items).toHaveLength(1)
    expect(cart.items[0]).toMatchObject({
      productoId: producto().id,
      cantidad: 3,
      precio: 2800,
      productorId: producto().productor_id,
      productorNombre: 'Huerta Paine',
    })
    expect(cart.subtotal).toBe(8400) // 2800 x 3
    expect(cart.toItems()).toEqual([{ productoId: producto().id, cantidad: 3 }])
  })
})

describe('CK-0067 · rechazar cantidades inválidas', () => {
  beforeEach(() => {
    localStorage.clear()
    setActivePinia(createPinia())
  })

  it.each([0, -2, Number.NaN, 'texto'])('rechaza cantidad %s (lanza y no agrega)', (cantidad) => {
    const cart = useCartStore()
    expect(() => cart.agregar(producto(), cantidad)).toThrow()
    expect(cart.items).toHaveLength(0)
  })

  it('rechaza decimales en unidad entera (unidad)', () => {
    const cart = useCartStore()
    expect(() => cart.agregar(producto({ unidad_medida: 'unidad', stock: 10 }), 1.5)).toThrow(/entera/)
    expect(cart.items).toHaveLength(0)
  })

  it('no supera el stock disponible', () => {
    const cart = useCartStore()
    expect(() => cart.agregar(producto({ stock: 2 }), 5)).toThrow(/Sólo quedan 2/)
    expect(cart.items).toHaveLength(0)
  })
})

describe('CK-0078 · checkout vacío no llama a la pasarela', () => {
  it('la vista deshabilita el pago cuando el carrito está vacío', () => {
    const vista = src('views/client/CartView.vue')
    expect(vista).toContain(':disabled="cart.vacio"')
    expect(vista).toContain('if (!destinoComuna.value || cart.vacio)')
  })

  it('el contrato del backend exige al menos un ítem (min_length=1)', () => {
    const esquema = readFileSync('../backend/app/schemas/webpay.py', 'utf8')
    expect(esquema).toMatch(/items:\s*list\[ItemRequest\]\s*=\s*Field\(min_length=1/)
  })
})

describe('Dirección del carrito · visitante', () => {
  it('no intenta escribir una dirección sin perfil y ofrece crear cuenta de cliente', () => {
    const vista = src('views/client/CartView.vue')
    expect(vista).toContain('requiereCuentaParaDireccion')
    expect(vista).toContain('Crea una cuenta para guardar tu dirección')
    expect(vista).toContain('Crear cuenta de cliente')
    expect(vista).toContain('to="/registro"')
    expect(vista).toContain('if (requiereCuentaParaDireccion.value)')
  })
})

describe('CK-0079 · recuperar el carrito tras pago fallido', () => {
  it('el resultado de pago rechazado ofrece volver al carrito sin limpiar', () => {
    const spec = src('__tests__/payment-result.spec.js')
    expect(spec).toMatch(/rechazado: informa el rechazo y ofrece volver al carrito/)
  })

  it('el carrito persiste en localStorage (no se pierde al volver)', () => {
    const spec = src('__tests__/carrito.spec.js')
    expect(spec).toMatch(/persiste el carrito en localStorage/)
    const store = src('stores/cart.js')
    expect(store).toContain('localStorage')
  })
})

describe('CK-0081/0088 · destinatario y snapshot inmutable de entrega', () => {
  it('el pedido congela nombre, teléfono, dirección y referencia del destinatario', () => {
    const repo = readFileSync('../backend/app/repositories/pedidos_repo.py', 'utf8')
    for (const campo of ['nombre_destinatario', 'telefono_destinatario', 'direccion_entrega', 'referencia_entrega'])
      expect(repo).toContain(campo)
    // y el schema exige la dirección de entrega como snapshot
    const esquema = readFileSync('../backend/app/schemas/webpay.py', 'utf8')
    expect(esquema).toContain('direccion_id: UUID')
  })
})

describe('CK-0374 · región desde tabla controlada (UI)', () => {
  it('los selectores de región/comuna se alimentan sólo de regiones/comunas reales', () => {
    const geo = src('services/geography.js')
    expect(geo).toContain(".from('regiones')")
    expect(geo).toContain(".from('comunas')")
    const direcciones = src('views/shared/AddressesView.vue')
    expect(direcciones).toMatch(/getOpcionesComunas|listRegiones|regionesOrdenadas/)
  })
})
