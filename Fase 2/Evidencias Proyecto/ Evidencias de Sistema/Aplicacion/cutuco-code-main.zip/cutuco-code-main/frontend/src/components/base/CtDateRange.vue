<script setup>
/** CuTuCo — Selector de rango de fechas para filtros y reportes. */
import { computed } from 'vue'

const props = defineProps({
  desde: { type: String, default: null },
  hasta: { type: String, default: null },
  presets: { type: Boolean, default: true },
  label: { type: String, default: 'Período' },
})

const emit = defineEmits(['update:desde', 'update:hasta', 'change'])

const PRESETS = [
  { key: '7', label: '7 días', days: 7 },
  { key: '30', label: '30 días', days: 30 },
  { key: '90', label: '90 días', days: 90 },
  { key: '365', label: '12 meses', days: 365 },
]

const rango = computed(() => {
  if (!props.desde || !props.hasta) return null
  return PRESETS.find((p) => {
    const inicio = daysAgo(p.days)
    return inicio === props.desde
  })
})

function daysAgo(days) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(d)
}

function applyPreset(preset) {
  const inicio = daysAgo(preset.days)
  const fin = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(new Date())
  emit('update:desde', inicio)
  emit('update:hasta', fin)
  emit('change', { desde: inicio, hasta: fin })
}
</script>

<template>
  <div class="ct-range">
    <div class="ct-range__fields">
      <label class="ct-range__field">
        <span class="ct-range__caption">Desde</span>
        <input
          type="date"
          class="ct-range__input"
          :value="desde ?? ''"
          @change="emit('update:desde', $event.target.value); emit('change', { desde: $event.target.value, hasta })"
        />
      </label>
      <span class="ct-range__separator" aria-hidden="true">→</span>
      <label class="ct-range__field">
        <span class="ct-range__caption">Hasta</span>
        <input
          type="date"
          class="ct-range__input"
          :value="hasta ?? ''"
          @change="emit('update:hasta', $event.target.value); emit('change', { desde, hasta: $event.target.value })"
        />
      </label>
    </div>

    <div v-if="presets" class="ct-range__presets">
      <span class="ct-range__caption">{{ label }}</span>
      <button
        v-for="preset in PRESETS"
        :key="preset.key"
        type="button"
        class="ct-range__chip"
        :class="{ 'is-active': rango?.key === preset.key }"
        @click="applyPreset(preset)"
      >
        {{ preset.label }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.ct-range {
  display: flex;
  align-items: flex-end;
  gap: var(--ct-space-6);
  flex-wrap: wrap;
}

.ct-range__fields {
  display: flex;
  align-items: flex-end;
  gap: var(--ct-space-2);
}

.ct-range__field {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
}

.ct-range__caption {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  font-weight: var(--ct-fw-medium);
}

.ct-range__input {
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  padding: 0.45rem var(--ct-space-3);
  font-size: var(--ct-fs-sm);
  background: var(--ct-surface);
  color: var(--ct-text);
  min-height: 38px;
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-range__input:hover {
  border-color: var(--ct-border-strong);
}

.ct-range__input:focus {
  outline: none;
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-range__separator {
  color: var(--ct-text-muted);
  padding-bottom: 10px;
}

.ct-range__presets {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.ct-range__chip {
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  border-radius: var(--ct-radius-pill);
  padding: 0.3rem 0.75rem;
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
  transition: all var(--ct-transition);
}

.ct-range__chip:hover {
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.ct-range__chip.is-active {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}
</style>
