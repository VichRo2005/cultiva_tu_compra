/**
 * CuTuCo — Lote 12 (Postulación y KYB), lado frontend.
 *
 * CK-0217 formulario "Quiero vender" completo; CK-0218 sin correo confirmado no
 * hay postulación (DC-05); CK-0233 aceptación de términos obligatoria.
 * HAL-REG-005 (CK-0448) complemento dirección comercial; HAL-REG-007 (CK-0450)
 * el archivo elegido muestra su nombre; HAL-REG-008 (CK-0451) titular con nombre
 * completo; HAL-REG-009 (CK-0452) sin "detail del Mall"; HAL-REG-010 (CK-0453)
 * 10 MiB = 10.485.760 bytes; HAL-REG-014 (CK-0457) sin cuentas de terceros;
 * HAL-REG-015 (CK-0458) notificación admin fuera del MVP (bandeja de pendientes);
 * HAL-REG-016 (CK-0459) 3 intentos post-login con reinicio auditado;
 * HAL-VEN-008 (CK-0496) postulación aprobada = historial, datos bancarios bloqueados.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0217 · Quiero vender presenta todos los bloques', () => {
  it('RegisterSellerView incluye datos personales, tienda, ubicación, banco y documentos por tipo de persona', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    for (const campo of ['nombreComercial', 'descripcion', 'regionId', 'comunaId', 'banco', 'titular', 'rutTitular', 'documentoIdentidad', 'certificadoTitularidad', 'comprobanteDomicilio']) {
      expect(v).toContain(campo)
    }
    expect(v).toContain('Persona natural') // KYB PN
    expect(v).toContain('jurídica') // KYB PJ
  })

  it('devuelve al paso de documentos cuando el RUT ya pertenece a otra postulación', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    const verificacionRut = v.slice(v.indexOf('const rutCheck'), v.indexOf('enviando.value = true'))
    expect(verificacionRut).toContain("errores.rutSolicitante")
    expect(verificacionRut).toContain('paso.value = 3')
  })

  it('formatea el RUT cargado y el editado al formato visible chileno', () => {
    const v = src('views/auth/MiPostulacionView.vue')
    expect(v).toContain('rutSolicitante: formatearRut(p?.rut_solicitante)')
    expect(v).toContain("@blur=\"formatearRutVisible('rutSolicitante')\"")
    expect(v).toContain("@blur=\"formatearRutVisible('rutTitular')\"")
  })
})

describe('CK-0218 (DC-05) · sin correo confirmado no hay postulación activa', () => {
  it('el alta conserva el borrador, los documentos y los datos bancarios hasta confirmar el correo', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('confirma tu correo')
    expect(v).toContain('guardarBorradorLocal')
    expect(v).toContain('guardarBorradorProtegidoLocal')
    expect(v).toMatch(/restauraremos y guardaremos automáticamente los documentos y los datos bancarios/)
  })

  it('la cuenta de vendedor muestra la misma pantalla final de confirmación, reenvío e inicio de sesión', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('requiereConfirmacionPantalla')
    expect(v).toContain('reenviarVerificacion')
    expect(v).toContain('Reenviar enlace de verificación')
    expect(v).toContain('Ir a iniciar sesión')
  })
})

describe('CK-0233 · aceptación de términos obligatoria', () => {
  it('no se envía la postulación sin aceptar términos y privacidad', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain("if (!aceptado.value)")
    expect(v).toContain('Debes aceptar los términos')
    expect(v).toContain('v-model="aceptado"')
  })
})

describe('CK-0448 (HAL-REG-005) · complemento en dirección comercial', () => {
  it('el formulario de vendedor incluye deptoOficina como campo definido', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('deptoOficina')
    expect(v).toContain('mensajeDeptoOficina')
  })
})

describe('CK-0450 (HAL-REG-007) · archivo elegido muestra nombre real', () => {
  it('no queda el texto falso de archivo no elegido y se muestra el nombre', () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('documentos[clave].name')
    expect(v).toContain('nunca aparezca "No se eligió ningún archivo"')
  })
})

describe('CK-0451 (HAL-REG-008) · titular autocompletado con nombre completo', () => {
  it('la sugerencia usa el nombre completo, no iniciales', async () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('HAL-REG-008')
    expect(v).toContain('titularSugerido')
    const pol = src('__tests__/registro-politicas.spec.js')
    expect(pol).toContain('HAL-REG-008')
    expect(pol).toContain('COMPLETO')
  })
})

describe('CK-0452 (HAL-REG-009) · lenguaje comprensible en alta bancaria', () => {
  it('ninguna vista de postulación contiene la frase técnica "detail del Mall"', () => {
    for (const p of ['views/auth/RegisterSellerView.vue', 'views/seller/SellerStoreProfileView.vue']) {
      expect(src(p).toLowerCase()).not.toContain('detail del mall')
    }
  })
})

describe('CK-0453 (HAL-REG-010) · límite 10 MiB por archivo', () => {
  it('el servicio fija 10 MiB = 10.485.760 bytes y el formulario lo muestra', async () => {
    const s = src('services/registro.js')
    expect(s).toContain('10.485.760')
    expect(s).toContain('HAL-REG-010')
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('10 MiB')
    const pol = src('__tests__/registro-politicas.spec.js')
    expect(pol).toContain('10.485.760')
  })
})

describe('CK-0457 (HAL-REG-014) · sin cuentas de terceros', () => {
  it('el RUT del titular debe coincidir con el postulante y el servicio lo valida', async () => {
    const v = src('views/auth/RegisterSellerView.vue')
    expect(v).toContain('no se aceptan cuentas de terceros')
    expect(v).toContain('HAL-REG-014')
    const s = await import('@/services/registro.js')
    expect(typeof s.mensajeCuentaDeTerceros).toBe('function')
    expect(
      s.mensajeCuentaDeTerceros({ tipoPersona: 'natural', titular: 'Otra Persona', nombre: 'Postulante', apellido: 'Lote12', rutTitular: '99999999-9', rutSolicitante: '12345678-5' })
    ).toBeTruthy()
    expect(
      s.mensajeCuentaDeTerceros({ tipoPersona: 'natural', titular: 'Postulante Lote12', nombre: 'Postulante', apellido: 'Lote12', rutTitular: '12345678-5', rutSolicitante: '12345678-5' })
    ).toBeNull()
  })
})

describe('CK-0458 (HAL-REG-015) · notificación admin fuera del MVP', () => {
  it('la bandeja de pendientes del admin sigue disponible', () => {
    const router = src('router/index.js')
    expect(router).toMatch(/pendientes/i)
    const spec = src('__tests__/admin-pendientes.spec.js')
    expect(spec).toContain('Pendientes')
  })
})

describe('CK-0459 (HAL-REG-016) · 3 intentos post-login con reinicio auditado', () => {
  it('la creación de cuenta se distingue de los intentos de postulación y recupera el registro confirmado', () => {
    const docs = src('__tests__/registro-documentos.spec.js')
    expect(docs).toContain('reiniciarIntentosPostulacion')
    const v = src('views/auth/MiPostulacionView.vue')
    expect(v).toContain('restaurarBorradorProtegido')
    expect(v).toContain('guardarDocumentosBorrador')
  })
})

describe('CK-0496 (HAL-VEN-008) · postulación aprobada como historial', () => {
  it('tras la aprobación los datos bancarios quedan bloqueados en el perfil de tienda', () => {
    const v = src('views/seller/SellerStoreProfileView.vue')
    expect(v).toContain('HAL-VEN-008')
    expect(v).toContain('datos bancarios están bloqueados')
    expect(v).toContain('Solicitud aprobada')
  })
})

describe('Datos bancarios al revisar o corregir una postulación', () => {
  it('precarga el número de cuenta propio y el administrador revisa el número completo', () => {
    const postulacion = src('views/auth/MiPostulacionView.vue')
    const moderacion = src('views/admin/AdminModerationView.vue')
    const admin = src('services/admin.js')
    expect(postulacion).toContain('numeroCuenta: datosBancarios.value?.numero_cuenta')
    expect(moderacion).toContain('datosBancarios.numeroCuenta')
    expect(admin).toContain('numeroCuenta: datos.numero_cuenta')
  })
})
