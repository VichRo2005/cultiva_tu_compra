import { describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia } from 'pinia'
import ProductDetailView from '@/views/public/ProductDetailView.vue'

const api = vi.hoisted(() => ({ getProducto: vi.fn() }))
vi.mock('vue-router', () => ({
  useRoute: () => ({ params: { id: 'producto-qa' }, query: {} }),
  useRouter: () => ({ push: vi.fn() }),
}))
vi.mock('@/services/catalog', async (importOriginal) => ({
  ...(await importOriginal()), getProducto: api.getProducto,
}))

describe('CK-0061: error público distinguible de producto inexistente', () => {
  it('muestra error de consulta y vuelve a consultar al reintentar', async () => {
    api.getProducto.mockRejectedValueOnce(new Error('No se pudo consultar el producto. Inténtalo de nuevo.'))
      .mockResolvedValueOnce(null)
    const wrapper = mount(ProductDetailView, {
      global: { plugins: [createPinia()], stubs: { RouterLink: true, NotFoundView: { template: '<p>Producto inexistente</p>' } } },
    })
    try {
      await flushPromises()
      expect(wrapper.text()).toContain('No se pudo cargar el producto')
      expect(wrapper.text()).not.toContain('Producto inexistente')
      await wrapper.findAll('button').find((button) => button.text() === 'Reintentar').trigger('click')
      await flushPromises()
      expect(api.getProducto).toHaveBeenCalledTimes(2)
      expect(wrapper.text()).toContain('Producto inexistente')
      expect(wrapper.text()).not.toContain('Reintentar')
    } finally {
      wrapper.unmount()
    }
  })
})
