// Mensaje de error seguro para la interfaz (CK-0296):
// nunca se muestran detalles de SQL, nombres de constraints/relaciones,
// códigos SQLSTATE ni detalles de PostgreSQL; tampoco secretos.
const fallbackDefault = 'No se pudo completar la operación. Intenta nuevamente.'

/** Corta el detalle técnico que PostgreSQL adjunta tras el mensaje principal. */
function sinDetalleTecnico(texto) {
  return String(texto)
    .replace(/\s*(DETAIL|CONTEXT|HINT|STATEMENT|SQLSTATE)\s*:.*$/is, '')
    .replace(/^.*?ERROR:\s*/i, '')
    .trim()
}

const REGLAS = [
  [
    /cannot read propert|is not a function|undefined|null \(reading|network changed|failed to fetch|networkerror|request failed|typeerror|referenceerror|syntaxerror|postgrest|supabase|graphql|rpc/i,
    'Tuvimos un problema al procesar tu solicitud. Inténtalo nuevamente.',
  ],
  [/duplicate key|unique constraint|uq_/i, 'Ya existe un registro con esos datos.'],
  [/foreign key|is not present in table|no existe en/i, 'La referencia indicada no existe.'],
  [/check constraint|ck_|check \(/i, 'Los datos no cumplen las reglas de validación.'],
  [/row-level security|permission denied|42501|insufficient_privilege/i, 'No tienes permisos para realizar esta operación.'],
  [/invalid input value for enum/i, 'Algún campo tiene un valor no permitido.'],
  [/value too long|excede/i, 'Algún campo excede la longitud permitida.'],
  [/null value in column|not-null/i, 'Falta completar un campo obligatorio.'],
  [/palabra prohibida|moderacion|moderación/i, 'El texto contiene palabras no permitidas. Revisa su contenido.'],
]

/**
 * Devuelve un mensaje presentable al usuario a partir de un error de Supabase/PostgREST.
 * Quita comillas de identificadores internos y, si queda algo técnico, usa el fallback.
 */
export function mensajeSeguro(error, fallback = fallbackDefault) {
  if (Number(error?.status ?? 0) === 429 || /rate limit|too many/i.test(String(error?.message ?? ''))) {
    return 'Demasiados intentos en poco tiempo. Espera unos segundos antes de volver a intentar.'
  }
  const crudo = sinDetalleTecnico(error?.message ?? error ?? '')
  if (!crudo) return fallback
  for (const [patron, mensaje] of REGLAS) {
    if (patron.test(crudo)) return mensaje
  }
  // sin comillas de identificadores internos (tablas, constraints)
  const limpio = crudo.replace(/"[^"]*"/g, '').replace(/\s{2,}/g, ' ').trim()
  if (!limpio || limpio.length > 160) return fallback
  if (/constraint|relation|table|column|SQLSTATE|pg_|pg_catalog/i.test(limpio)) return fallback
  return limpio
}
