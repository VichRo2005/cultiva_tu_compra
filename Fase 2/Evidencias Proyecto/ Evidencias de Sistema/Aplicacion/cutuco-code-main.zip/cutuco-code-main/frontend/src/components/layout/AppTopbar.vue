<script setup>
/**
 * CuTuCo — Barra superior: ruta, búsqueda global, ubicación (RF-009) y sesión
 * del usuario con su rol (RF-001).
 */
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtIcon from '@/components/base/CtIcon.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import NotificationBell from '@/components/domain/NotificationBell.vue'
import { LABELS, STORAGE_BUCKETS } from '@/lib/constants'
import { storageUrl } from '@/lib/supabase'
import { useAuthStore } from '@/stores/auth'
import { useCartStore } from '@/stores/cart'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const cart = useCartStore()
const geo = useGeographyStore()
const ui = useUiStore()

const busqueda = ref('')
const menuUbicacion = ref(false)
const rootUbicacion = ref(null)
const avatarVersion = ref(Date.now())

const avatarUsuario = computed(() => {
  const esVendedor = Boolean(auth.productor?.foto_perfil_storage_path)
  const ruta = esVendedor
    ? auth.productor?.foto_perfil_storage_path
    : auth.perfil?.foto_perfil_storage_path
  if (!ruta) return null
  const bucket = esVendedor ? STORAGE_BUCKETS.avataresVendedor : STORAGE_BUCKETS.avataresCliente
  const url = storageUrl(ruta, { bucket })
  return url ? `${url}${url.includes('?') ? '&' : '?'}v=${avatarVersion.value}` : null
})

const crumbs = computed(() => {
  if (Array.isArray(route.meta?.crumbs) && route.meta.crumbs.length) return route.meta.crumbs
  return route.meta?.title ? [{ label: route.meta.title }] : []
})

/**
 * RF-009: la ubicación del chip es siempre una región (la del vendedor con la
 * que se filtra el catálogo) o "Todo Chile". La comuna no participa del filtro.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): antes el chip mostraba la
 * comuna del destino del carrito (`cart.destino.comunaId`) y la comuna principal
 * del perfil (`auth.perfil.comuna_principal_id`, campo que no existe en el
 * esquema vigente). La cobertura se compara por región.
 */
const etiquetaUbicacion = computed(() => {
  if (geo.regionSeleccionada) return geo.regionSeleccionada.nombre
  if (cart.destino.regionId) return geo.nombreRegion(cart.destino.regionId)
  return 'Todo Chile'
})

/**
 * HAL-VEN-002: el vendedor y el administrador no operan el flujo de compra.
 * El buscador global, el filtro regional, el carrito y sus accesos sólo se
 * muestran a visitantes y clientes; en los paneles internos se conserva
 * únicamente la sesión y las notificaciones.
 */
const esComprador = computed(() => (!auth.rol || auth.isCliente) && !auth.enPostulacion)

watch(
  () => route.query.q,
  (valor) => {
    busqueda.value = valor ?? ''
  },
  { immediate: true },
)

watch(
  () => [auth.productor?.foto_perfil_storage_path, auth.perfil?.foto_perfil_storage_path],
  () => {
    avatarVersion.value = Date.now()
  },
)

function buscar() {
  const q = busqueda.value.trim()
  if (!q) return
  router.push({ path: '/catalogo', query: { ...route.query, q } })
}

function elegirRegion(regionId) {
  geo.setRegionSeleccionada(regionId)
  menuUbicacion.value = false
  router.push({
    path: '/catalogo',
    query: { ...route.query, region: regionId ?? undefined, q: busqueda.value.trim() || undefined },
  })
}

function cerrarUbicacion(event) {
  if (!rootUbicacion.value?.contains(event.target)) menuUbicacion.value = false
}

onMounted(() => document.addEventListener('click', cerrarUbicacion))
onBeforeUnmount(() => document.removeEventListener('click', cerrarUbicacion))
</script>

<template>
  <header class="ct-bar">
    <div class="ct-bar__left">
      <button
        type="button"
        class="ct-bar__menu"
        :aria-expanded="ui.sidebarAbierto"
        aria-label="Abrir navegación"
        @click="ui.toggleSidebar()"
      >
        <CtIcon name="menu" :size="20" />
      </button>

      <nav class="ct-bar__crumbs" aria-label="Ruta">
        <template v-for="(crumb, index) in crumbs" :key="crumb.label">
          <span v-if="index > 0" class="ct-bar__crumb-sep" aria-hidden="true">/</span>
          <router-link
            v-if="crumb.to && index < crumbs.length - 1"
            :to="crumb.to"
            class="ct-bar__crumb"
            :title="crumb.label"
          >
            {{ crumb.label }}
          </router-link>
          <span
            v-else
            class="ct-bar__crumb"
            :class="{ 'is-current': index === crumbs.length - 1 }"
            :aria-current="index === crumbs.length - 1 ? 'page' : undefined"
            :title="crumb.label"
          >
            {{ crumb.label }}
          </span>
        </template>
      </nav>
    </div>

    <form v-if="esComprador" class="ct-bar__search" role="search" @submit.prevent="buscar">
      <CtIcon name="search" :size="17" class="ct-bar__search-icon" />
      <input
        v-model="busqueda"
        type="search"
        class="ct-bar__search-input"
        placeholder="Buscar productos en CuTuCo..."
        aria-label="Buscar productos en CuTuCo"
      />
      <button type="submit" class="ct-bar__search-go">Buscar</button>
    </form>

    <div class="ct-bar__right">
      <div v-if="esComprador" ref="rootUbicacion" class="ct-bar__place">
        <button
          type="button"
          class="ct-bar__place-btn"
          :aria-expanded="menuUbicacion"
          :aria-label="`Filtrar por región. Región actual: ${etiquetaUbicacion}`"
          @click.stop="menuUbicacion = !menuUbicacion"
        >
          <CtIcon name="pin" :size="16" />
          <span class="ct-bar__place-label">{{ etiquetaUbicacion }}</span>
          <CtIcon name="chevronDown" :size="14" />
        </button>

        <div v-if="menuUbicacion" class="ct-bar__place-menu">
          <p class="eyebrow">Filtrar por región</p>
          <button
            type="button"
            class="ct-bar__place-item"
            :class="{ 'is-active': !geo.regionSeleccionadaId }"
            @click="elegirRegion(null)"
          >
            Todo Chile
          </button>
          <button
            v-for="region in geo.regionesOrdenadas"
            :key="region.id"
            type="button"
            class="ct-bar__place-item"
            :class="{ 'is-active': geo.regionSeleccionadaId === region.id }"
            @click="elegirRegion(region.id)"
          >
            {{ region.nombre }}
          </button>
        </div>
      </div>

      <router-link v-if="esComprador" to="/carrito" class="ct-bar__cart" aria-label="Carrito">
        <CtIcon name="cart" :size="18" />
        <span v-if="cart.totalItems" class="ct-bar__cart-count">{{ cart.totalItems > 9 ? '9+' : cart.totalItems }}</span>
      </router-link>

      <NotificationBell />

      <div class="ct-bar__user">
        <CtAvatar :name="auth.nombreCompleto || 'Invitado'" :src="avatarUsuario" :size="44" />
        <div class="ct-bar__user-text">
          <strong>{{ auth.nombreCompleto || 'Invitado' }}</strong>
          <span>{{
            auth.rol
              ? (LABELS.rol[auth.rol] ?? auth.rol)
              : auth.isAuthenticated
                ? 'Sesión iniciada'
                : 'Sin sesión'
          }}</span>
        </div>
      </div>
    </div>
  </header>
</template>

<style scoped>
.ct-bar {
  position: sticky;
  top: 0;
  z-index: var(--ct-z-header);
  min-height: var(--ct-header-height);
  display: flex;
  align-items: center;
  gap: var(--ct-space-6);
  padding-inline: var(--ct-gutter);
  background: #ececee;
  border-bottom: 1px solid var(--ct-border);
  box-shadow: var(--ct-shadow-xs);
}

.ct-bar__logo-img {
  width: 36px;
  height: 36px;
  border-radius: var(--ct-radius-md);
  object-fit: contain;
  flex-shrink: 0;
  background: var(--ct-white);
  padding: 2px;
}

.ct-bar__left {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  min-width: 0;
}

.ct-bar__menu {
  display: none;
  width: 38px;
  height: 38px;
  border-radius: var(--ct-radius);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
  place-items: center;
}

.ct-bar__crumbs {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-muted);
  min-width: 0;
  flex: 1 1 auto;
  overflow: hidden;
}

.ct-bar__crumb {
  position: relative;
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  min-width: 0;
  max-width: min(32ch, 100%);
  padding-inline: 2px;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-text-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 1;
}

/* Subrayado que se dibuja al hover en las migas navegables. */
.ct-bar__crumb::after {
  content: '';
  position: absolute;
  left: 2px;
  right: 2px;
  bottom: 0;
  height: 2px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-primary);
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform var(--ct-transition);
}

.ct-bar__crumb:hover {
  color: var(--ct-primary-strong);
  text-decoration: none;
}

.ct-bar__crumb:hover::after {
  transform: scaleX(1);
}

.ct-bar__crumb.is-current {
  color: var(--ct-text);
  font-weight: var(--ct-fw-semibold);
}

.ct-bar__crumb.is-current::after {
  display: none;
}

.ct-bar__crumb-sep {
  color: var(--ct-text-muted);
  user-select: none;
}

.ct-bar__search {
  position: relative;
  flex: 1;
  max-width: 420px;
  display: flex;
  align-items: center;
}

.ct-bar__search-icon {
  position: absolute;
  left: 14px;
  color: var(--ct-text-muted);
  pointer-events: none;
}

.ct-bar__search-input {
  width: 100%;
  height: 40px;
  padding: 0 88px 0 40px;
  border-radius: var(--ct-radius-pill);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  font-size: var(--ct-fs-md);
  color: var(--ct-text);
}

.ct-bar__search-input::placeholder {
  color: var(--ct-text-faint);
}

.ct-bar__search-input:focus {
  outline: none;
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}

.ct-bar__search-go {
  position: absolute;
  right: 5px;
  height: 30px;
  padding-inline: var(--ct-space-4);
  border-radius: var(--ct-radius-pill);
  background: var(--ct-primary-fill);
  color: var(--ct-text-invert);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  transition:
    background-color var(--ct-transition),
    box-shadow var(--ct-transition),
    transform var(--ct-transition);
}

.ct-bar__search-go:hover {
  background: var(--ct-primary-fill-hover);
  box-shadow: var(--ct-shadow-sm);
}

.ct-bar__search-go:active {
  background: var(--ct-primary-fill-active);
  transform: translateY(1px);
}

.ct-bar__right {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  margin-left: auto;
}

.ct-bar__place {
  position: relative;
}

.ct-bar__place-btn {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  height: 36px;
  padding-inline: var(--ct-space-3);
  border-radius: var(--ct-radius-pill);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  white-space: nowrap;
  transition:
    border-color var(--ct-transition),
    background var(--ct-transition),
    color var(--ct-transition);
}

.ct-bar__place-label {
  max-width: 130px;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ct-bar__place-btn:hover {
  border-color: var(--ct-border-strong);
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.ct-bar__place-btn:active {
  background: var(--ct-neutral-soft);
}

.ct-bar__place-menu {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  width: 240px;
  max-height: 320px;
  overflow-y: auto;
  padding: var(--ct-space-3);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  box-shadow: var(--ct-shadow-lg);
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ct-bar__place-menu .eyebrow {
  padding: 0 var(--ct-space-2) var(--ct-space-2);
}

.ct-bar__place-item {
  text-align: left;
  padding: 0.4rem var(--ct-space-2);
  border-radius: var(--ct-radius-sm);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.ct-bar__place-item:hover {
  background: var(--ct-surface-alt);
}

.ct-bar__place-item.is-active {
  background: var(--ct-primary);
  color: var(--ct-text-invert);
  font-weight: var(--ct-fw-semibold);
}

.ct-bar__cart {
  position: relative;
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: var(--ct-radius-pill);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
}

.ct-bar__cart:hover {
  text-decoration: none;
  color: var(--ct-primary-strong);
}

/* Indicador igual al de notificaciones (ct-bell__count): pastilla roja con
   el total de unidades, centrada sobre el ícono del carrito. */
.ct-bar__cart-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding-inline: 4px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-danger);
  color: var(--ct-text-invert);
  font-size: 0.625rem;
  font-weight: var(--ct-fw-bold);
  display: grid;
  place-items: center;
}

.ct-bar__user {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  padding-left: var(--ct-space-3);
  border-left: 1px solid var(--ct-border);
}

.ct-bar__user-text {
  display: flex;
  flex-direction: column;
  line-height: 1.25;
  max-width: 150px;
}

.ct-bar__user-text strong {
  font-size: var(--ct-fs-sm);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ct-bar__user-text span {
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

@media (max-width: 1180px) {
  .ct-bar__search {
    max-width: 260px;
  }

  .ct-bar__search-go {
    display: none;
  }

  .ct-bar__search-input {
    padding-right: 16px;
  }
}

@media (max-width: 1024px) {
  .ct-bar__menu {
    display: grid;
  }
}

@media (max-width: 860px) {
  .ct-bar {
    gap: var(--ct-space-3);
    padding-inline: var(--ct-space-4);
  }

  .ct-bar__search,
  .ct-bar__user-text {
    display: none;
  }

  /* Las migas compiten con ubicación, carrito, alertas y avatar. En móvil se
     muestra sólo la ventana actual, sin el prefijo que quedaba cortado. */
  .ct-bar__crumbs {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
  }

  .ct-bar__crumb:not(.is-current),
  .ct-bar__crumb-sep {
    display: none;
  }

  .ct-bar__crumb.is-current {
    display: block;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .ct-bar__user {
    padding-left: var(--ct-space-2);
  }
}

@media (max-width: 520px) {
  /* En pantallas muy angostas el filtro de región del catálogo ya está en la
     propia página; se libera el ancho para que se lea la miga actual. */
  .ct-bar__place {
    display: none;
  }
}
</style>
