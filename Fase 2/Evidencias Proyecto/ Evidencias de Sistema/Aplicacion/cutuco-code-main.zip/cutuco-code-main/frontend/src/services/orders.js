/**
 * CuTuCo — Servicio de pedidos, pagos (Webpay Mall), delivery y calificaciones.
 *
 * Cubre:
 *   RF-002  compra del cliente y su historial de pedidos
 *   RF-005  pago con Webpay Mall (iniciar -> redirección -> token_ws -> commit);
 *           Transbank dispersa el cobro por Mall (CuTuCo no retiene fondos)
 *   RF-007  código de verificación de entrega
 *   RF-009  validación de cobertura por región antes de crear el pago
 *   RF-025  estados de delivery Preparación -> En Tránsito -> Entregado
 *   RF-006  calificación de 1 a 5 y promedio del vendedor
 *
 * La creación del pedido y el pago pasan por FastAPI (`/api/webpay/*`) porque
 * requieren la service_role, idempotencia por buy_order/token_ws y las
 * credenciales de Transbank. Las consultas y los cambios de estado del envío
 * usan PostgREST con RLS.
 */

import { mensajeSeguro } from '@/services/errores'
import { apiFetch, getClient, storageUrl } from '@/lib/supabase'
import {
  ESTADO_ENVIO,
  ESTADO_PAGO,
  ESTADO_PEDIDO,
  REGLAS,
  STORAGE_BUCKETS,
} from '@/lib/constants'
import {
  LONGITUD_CODIGO_ENTREGA,
  esCodigoEntregaValido,
  esFuncionRpcNoDisponible,
  normalizarCodigoEntrega,
  traducirErrorCancelacion,
  traducirErrorCodigoEntrega,
  traducirErrorJustificacion,
  traducirErrorPreparacion,
  validarJustificacion,
} from '@/lib/orders'
import { currentUserId, unwrap } from '@/services/session'
import { getRegionProductor, getRegionDeDireccion } from '@/services/geography'

/* ---------------------------------------------------------------- */
/* Proyección del envío (HAL-VEN-018)                                  */
/* ---------------------------------------------------------------- */

/**
 * Columnas seguras de `envios`: la migración 20261101020000 revoca el SELECT de
 * `codigo_verificacion` a `authenticated`, así que NINGUNA consulta PostgREST
 * puede pedirla (ni con `select('*')`). El código del cliente se obtiene con la
 * RPC `obtener_codigo_entrega`; el vendedor nunca lo recibe.
 */
const COLUMNAS_ENVIO = Object.freeze([
  'id',
  'pedido_id',
  'repartidor_id',
  'estado',
  'tarifa_fija',
  'preparado_en',
  'codigo_verificado_en',
  'despachado_en',
  'entregado_en',
  'fallido_en',
  'motivo_fallo',
  'cancelado_en',
  'motivo_cancelacion',
  'creado_en',
  'actualizado_en',
])

export function columnasEnvio() {
  return COLUMNAS_ENVIO.join(', ')
}

/** RPC que expone el código sólo al cliente del pedido (o al administrador). */
async function obtenerCodigoEntregaRpc(client, envioId) {
  const { data, error } = await client.rpc('obtener_codigo_entrega', {
    p_envio_id: envioId,
  })
  if (error) throw new Error('No se pudo consultar el código de entrega. Intenta nuevamente.')
  return typeof data === 'string' ? data : (data?.codigo_verificacion ?? null)
}

/* ---------------------------------------------------------------- */
/* Checkout y pago (RF-002, RF-005 y RF-009)                          */
/* ---------------------------------------------------------------- */

/**
 * Valida la cobertura regional antes de crear el pago (RF-009).
 * Compara la región de la dirección de entrega del cliente con la región del
 * vendedor del producto.
 * @returns {Promise<{ok: boolean, motivo?: string, regionCliente?: object, regionVendedor?: object}>}
 */
export async function validarCoberturaRegional({ direccion, productorId }) {
  const regionVendedor = await getRegionProductor(productorId)
  if (!regionVendedor) {
    return { ok: false, motivo: 'El vendedor no tiene una región registrada.' }
  }
  const regionCliente = (await getRegionDeDireccion(direccion))?.region ?? null
  if (!regionCliente) {
    return { ok: false, motivo: 'Tu dirección no tiene región registrada.', regionVendedor }
  }
  if (regionCliente.id !== regionVendedor.id) {
    return {
      ok: false,
      motivo: `El vendedor sólo entrega en la región ${regionVendedor.nombre}. Tu dirección está en ${regionCliente.nombre}.`,
      regionCliente,
      regionVendedor,
    }
  }
  return { ok: true, regionCliente, regionVendedor }
}

/**
 * Crea el pedido en estado `creado` y la transacción de Webpay Plus.
 *
 * Los campos opcionales que van vacíos se omiten del cuerpo en lugar de enviarse
 * como `null`: el backend distingue «no enviado» de «enviado nulo» para decidir
 * si hereda la referencia de la dirección de entrega (`referencia_entrega` en
 * `iniciar_checkout`).
 * `documentoTributario` selecciona el comprobante: `{tipo:'boleta'}` (default;
 * el backend asigna el RUT genérico 66666666-6) o `{tipo:'factura', rut_empresa,
 * razon_social, giro, direccion_tributaria}`.
 * @param {{direccionId: string, items: Array<{productoId: string, cantidad: number}>, nombreDestinatario?: string, telefonoDestinatario?: string, referenciaEntrega?: string, documentoTributario?: {tipo: 'boleta'|'factura', rut_empresa?: string, razon_social?: string, giro?: string, direccion_tributaria?: string}}} payload
 */
export async function iniciarPago(payload) {
  const doc = payload.documentoTributario
  const documento =
    doc?.tipo === 'factura'
      ? {
          tipo: 'factura',
          rut_empresa: String(doc.rut_empresa ?? '').trim(),
          razon_social: String(doc.razon_social ?? '').trim(),
          giro: String(doc.giro ?? '').trim(),
          direccion_tributaria: String(doc.direccion_tributaria ?? '').trim(),
        }
      : doc?.tipo === 'boleta'
        ? { tipo: 'boleta' }
        : null
  return apiFetch('/api/webpay/iniciar', {
    method: 'POST',
    body: {
      direccion_id: payload.direccionId,
      ...(payload.montoEsperado !== undefined ? { monto_esperado: payload.montoEsperado } : {}),
      items: payload.items.map((item) => ({
        producto_id: item.productoId,
        cantidad: Number(item.cantidad),
      })),
      ...(payload.nombreDestinatario?.trim()
        ? { nombre_destinatario: payload.nombreDestinatario.trim() }
        : {}),
      ...(payload.telefonoDestinatario?.trim()
        ? { telefono_destinatario: payload.telefonoDestinatario.trim() }
        : {}),
      ...(payload.referenciaEntrega?.trim()
        ? { referencia_entrega: payload.referenciaEntrega.trim() }
        : {}),
      ...(documento ? { documento_tributario: documento } : {}),
    },
  })
}

/**
 * Autocompleta los datos tributarios de una empresa a partir de su RUT
 * (`GET /api/tributario/empresa/{rut}`, JWT).
 * Respuestas: 200 {"existe":true, rut, razon_social, giro} · 404 sin datos ·
 * 422 RUT inválido · 502 proveedor caído (mensaje genérico).
 */
export async function getEmpresaTributaria(rut) {
  const limpio = String(rut ?? '').trim()
  return apiFetch(`/api/tributario/empresa/${encodeURIComponent(limpio)}`)
}

/** Ejecuta tx.commit con el token devuelto por Webpay. */
export async function confirmarPago(tokenWs) {
  try {
    return await apiFetch('/api/webpay/confirmar', { method: 'POST', body: { token_ws: tokenWs } })
  } catch (e) {
    const mensaje = String(e?.message ?? '')
    // Nunca se filtran detalles internos (pila, SQL, credenciales) al cliente del pago.
    if (/token|inv[aá]lido|ya (confirm|usad)|no se encontr|transacci/i.test(mensaje)) {
      throw new Error('El token de pago no es válido o ya no se puede usar.', { cause: e })
    }
    throw new Error('No se pudo confirmar el pago. Intenta nuevamente.', { cause: e })
  }
}

/** Estado del pedido, su comprobante de pago y su envío (`GET /api/webpay/estado/:id`). */
export async function getEstadoPago(pedidoId) {
  return apiFetch(`/api/webpay/estado/${pedidoId}`)
}

/**
 * `pagos` ya no tiene columna `estado` (Webpay Mall): la fila existe sólo si el
 * cobro quedó autorizado. Se deriva `estado: 'autorizado'` para que los badges
 * y las vistas sigan resolviendo un estado legible.
 */
function conEstadoDerivado(pago) {
  if (!pago) return null
  return { ...pago, estado: pago.estado ?? ESTADO_PAGO.AUTORIZADO }
}

/* ---------------------------------------------------------------- */
/* Lectura de pedidos                                                  */
/* ---------------------------------------------------------------- */

export async function getPedido(pedidoId) {
  const client = getClient()
  const { data, error } = await client.from('pedidos').select('*').eq('id', pedidoId).maybeSingle()
  if (error) throw new Error('No se pudo cargar el estado completo del pedido. Intenta nuevamente.')
  return data
}

/**
 * Busca un pedido por su identificador o por su código visible
 * (`codigo_pedido`, por ejemplo CUTU-20261006-AB12CD). Lo usa el administrador
 * para registrar reembolsos y revisar casos a mano.
 */
export async function buscarPedidoPorCodigo(codigoOId) {
  const termino = String(codigoOId ?? '').trim()
  if (!termino) return null
  const esUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(termino)
  const client = getClient()
  const { data } = await client
    .from('pedidos')
    .select('*')
    .eq(esUuid ? 'id' : 'codigo_pedido', termino)
    .maybeSingle()
  if (!data) return null
  return getPedidoDetalle(data.id)
}

/**
 * Pedido con sus ítems, pago, envío, contrapartes y evaluación.
 *
 * El envío se consulta SIEMPRE sin `codigo_verificacion` (la columna está
 * revocada para `authenticated` desde la migración 20261101020000). Cuando
 * `incluirCodigo` es true —cliente o administrador— el código se obtiene con la
 * RPC `obtener_codigo_entrega`; el vendedor llama con `incluirCodigo:false` y
 * nunca lo recibe (HAL-VEN-018).
 */
export async function getPedidoDetalle(pedidoId, { incluirCodigo = true } = {}) {
  const client = getClient()
  const pedido = await getPedido(pedidoId)
  if (!pedido) return null

  const [detallesRes, pagoRes, envioRes, productorRes, comunaRes, evaluacionRes] = await Promise.all([
    client.from('detalles_pedido').select('*').eq('pedido_id', pedidoId).order('creado_en', { ascending: true }),
    client.from('pagos').select('*').eq('pedido_id', pedidoId).maybeSingle(),
    client
      .from('envios')
      .select(columnasEnvio())
      .eq('pedido_id', pedidoId)
      .maybeSingle(),
    client.from('productores').select('*').eq('id', pedido.productor_id).maybeSingle(),
    client.from('comunas').select('*').eq('id', pedido.comuna_entrega_id).maybeSingle(),
    client.from('evaluaciones_reputacion').select('*').eq('pedido_id', pedidoId).maybeSingle(),
  ])

  if ([detallesRes, pagoRes, envioRes, productorRes, comunaRes, evaluacionRes].some((r) => r.error)) {
    throw new Error('No se pudo cargar el estado completo del pedido. Intenta nuevamente.')
  }

  const envio = envioRes.data ?? null
  if (envio && incluirCodigo) {
    const codigo = await obtenerCodigoEntregaRpc(client, envio.id)
    if (codigo) envio.codigo_verificacion = codigo
  }
  const cliente = await getPerfilPedido(pedido.cliente_id)
  const repartidor = envio?.repartidor_id ? await getPerfilPedido(envio.repartidor_id) : null

  return {
    ...pedido,
    detalles: detallesRes.data ?? [],
    pago: conEstadoDerivado(pagoRes.data),
    envio,
    productor: productorRes.data ?? null,
    comuna: comunaRes.data ?? null,
    cliente,
    repartidor,
    evaluacion: evaluacionRes.data ?? null,
  }
}

export async function getPerfilPedido(perfilId) {
  if (!perfilId) return null
  const client = getClient()
  const { data } = await client
    .from('perfiles')
    .select('id, nombre, apellido, telefono, rol, activo')
    .eq('id', perfilId)
    .maybeSingle()
  if (!data) return null
  const { data: auth } = await client.auth.getUser()
  // El correo vive en Supabase Auth; sólo se expone el del propio usuario.
  return { ...data, email: auth?.user?.id === perfilId ? auth.user.email : null }
}

/**
 * Pedidos del usuario según su rol.
 *
 * `all: true` devuelve el conjunto completo (el panel del vendedor y sus
 * indicadores lo necesitan); en el resto de las vistas se pagina en el cliente
 * con `page`/`pageSize` sobre la consulta ya traída.
 *
 * Los listados NUNCA piden `codigo_verificacion`: la columna está revocada para
 * `authenticated` y el cliente la obtiene sólo en el detalle con la RPC
 * `obtener_codigo_entrega` (HAL-VEN-018).
 * @param {{rol?: 'cliente'|'productor', estado?: string|null, page?: number, pageSize?: number, all?: boolean}} opciones
 */
export async function listPedidos({
  rol = 'cliente',
  estado = null,
  page = 1,
  pageSize = 10,
  all = false,
} = {}) {
  const client = getClient()
  const userId = await currentUserId()
  if (!userId) return { items: [], total: 0 }

  let query = client.from('pedidos').select('*')

  if (rol === 'cliente') {
    query = query.eq('cliente_id', userId)
  } else if (rol === 'productor') {
    const { data: productor } = await client
      .from('productores')
      .select('id')
      .eq('perfil_id', userId)
      .maybeSingle()
    if (!productor) return { items: [], total: 0 }
    query = query.eq('productor_id', productor.id)
  }

  if (estado) query = query.eq('estado', estado)

  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))

  const total = (data ?? []).length
  const items = await hydratePedidos(
    all ? (data ?? []) : (data ?? []).slice((page - 1) * pageSize, page * pageSize),
  )
  return { items, total }
}

export async function hydratePedidos(pedidos) {
  if (!pedidos.length) return []
  const client = getClient()
  const ids = pedidos.map((p) => p.id)
  const [detallesRes, pagosRes, enviosRes, productoresRes] = await Promise.all([
    client.from('detalles_pedido').select('*').in('pedido_id', ids),
    client.from('pagos').select('*').in('pedido_id', ids),
    client
      .from('envios')
      .select(columnasEnvio())
      .in('pedido_id', ids),
    client
      .from('productores')
      .select('id, nombre_comercial, puntaje_reputacion, cantidad_evaluaciones')
      .in('id', [...new Set(pedidos.map((p) => p.productor_id))]),
  ])

  if ([detallesRes, pagosRes, enviosRes, productoresRes].some((r) => r.error)) {
    throw new Error('No se pudo cargar el estado de tus pedidos. Intenta nuevamente.')
  }

  const detalles = detallesRes.data ?? []
  const productoIds = [...new Set(detalles.map((d) => d.producto_id).filter(Boolean))]
  const { data: imagenes } = productoIds.length
    ? await client.from('imagenes_productos').select('*').in('producto_id', productoIds)
    : { data: [] }

  const productorMap = new Map((productoresRes.data ?? []).map((p) => [p.id, p]))
  const pagoMap = new Map((pagosRes.data ?? []).map((p) => [p.pedido_id, p]))
  const envioMap = new Map((enviosRes.data ?? []).map((e) => [e.pedido_id, e]))
  const imagenMap = new Map()
  for (const img of imagenes ?? []) {
    if (!imagenMap.has(img.producto_id)) imagenMap.set(img.producto_id, img)
  }

  return pedidos.map((p) => {
    const items = detalles.filter((d) => d.pedido_id === p.id)
    const portada = items.map((d) => imagenMap.get(d.producto_id)).find(Boolean)
    return {
      ...p,
      detalles: items,
      pago: conEstadoDerivado(pagoMap.get(p.id) ?? null),
      envio: envioMap.get(p.id) ?? null,
      productor: productorMap.get(p.productor_id) ?? null,
      imagenPortada: portada
        ? { ...portada, url: storageUrl(portada.ruta_storage, { bucket: STORAGE_BUCKETS.productos }) }
        : null,
    }
  })
}

/* ---------------------------------------------------------------- */
/* Delivery (RF-025 y RF-007)                                          */
/* ---------------------------------------------------------------- */

/**
 * Avanza el envío a `en_transito`. El trigger del esquema genera entonces el
 * código de verificación del pedido (RF-007).
 */
export async function marcarEnTransito(envioId) {
  const client = getClient()
  return unwrap(
    await client
      .from('envios')
      .update({ estado: ESTADO_ENVIO.EN_TRANSITO })
      .eq('id', envioId)
      .select(columnasEnvio())
      .single(),
    'No se pudo marcar el pedido en tránsito',
  )
}

/**
 * RF-025: el vendedor confirma que terminó de preparar el pedido.
 *
 * El envío se crea automáticamente en `preparacion` al autorizarse el pago,
 * pero el hito «Preparación» sólo queda cerrado cuando existe
 * `envios.preparado_en`. La RPC security definer valida la propiedad del pedido
 * y registra la fecha; el vendedor no tiene UPDATE directo sobre `pedidos`.
 */
export async function marcarPedidoEnPreparacion(pedidoId) {
  const client = getClient()
  const { error } = await client.rpc('marcar_pedido_en_preparacion', {
    p_pedido_id: pedidoId,
  })
  if (error) throw new Error(traducirErrorPreparacion(error.message))
  return true
}

/**
 * Compatibilidad con el flujo anterior: el cliente YA NO valida el código.
 *
 * El modelo vigente es: el cliente recibe el código, se lo entrega al vendedor
 * y el vendedor lo valida en su panel. La RPC `verificar_codigo_entrega` quedó
 * redefinida como alias del vendedor; llamarla desde la vista del cliente sería
 * un error de rol. Se conserva la función exportada para no romper imports
 * antiguos, pero falla con un mensaje funcional en español.
 */
export async function verificarCodigoEntrega() {
  throw new Error(
    'El código de entrega lo valida el vendedor cuando se lo entregas. No necesitas ingresarlo en tu panel.',
  )
}

/**
 * HAL-VEN-018: el vendedor ingresa el código que le entregó el cliente.
 *
 * El servidor valida que el envío pertenezca a un pedido del productor
 * autenticado, que esté `en_transito` y que el código coincida. La UI nunca
 * recibe `codigo_verificacion`: sólo muestra si ya fue validado y permite
 * cerrar la entrega.
 *
 * La migración 20261101020000 redefine `verificar_codigo_entrega` como alias
 * del vendedor; se intenta primero el nombre explícito y, si no existe en el
 * entorno, se usa el alias.
 */
export async function verificarCodigoEntregaVendedor({ envioId, codigo }) {
  if (!envioId) throw new Error('No encontramos el envío asociado a este pedido')
  const limpio = normalizarCodigoEntrega(codigo)
  if (!esCodigoEntregaValido(limpio)) {
    throw new Error(
      `Escribe los ${LONGITUD_CODIGO_ENTREGA} dígitos que te entregó el cliente`,
    )
  }
  const client = getClient()
  const args = { p_envio_id: envioId, p_codigo: limpio }
  let { error } = await client.rpc('verificar_codigo_entrega_vendedor', args)
  if (error && esFuncionRpcNoDisponible(error.message)) {
    const alias = await client.rpc('verificar_codigo_entrega', args)
    error = alias.error
  }
  if (error) throw new Error(traducirErrorCodigoEntrega(error.message))
  return true
}

/**
 * HAL-VEN-018: único camino de lectura del código para el cliente.
 *
 * La migración 20261101020000 revoca `envios.codigo_verificacion` para
 * `authenticated`. La vista del cliente obtiene el código con esta RPC, que
 * valida `pedidos.cliente_id = auth.uid()` y el estado `en_transito`. El
 * vendedor no puede llamarla.
 */
export async function obtenerCodigoEntregaCliente(envioId) {
  if (!envioId) throw new Error('No encontramos el envío asociado a este pedido')
  const client = getClient()
  const { data, error } = await client.rpc('obtener_codigo_entrega', {
    p_envio_id: envioId,
  })
  if (error) throw new Error(traducirErrorCodigoEntrega(error.message))
  return typeof data === 'string' ? data : (data?.codigo_verificacion ?? null)
}

/**
 * RF-007 y RF-025: el vendedor cierra la entrega marcando el envío como
 * `entregado`.
 *
 * Sólo funciona si el código ya fue validado: el trigger
 * `validar_transicion_envio` rechaza el cambio con «El codigo de entrega debe
 * verificarse antes de marcar el envio como entregado». Al confirmarse, el
 * trigger `sincronizar_envio_entregado` deja el pedido en `completado`. Con
 * Webpay Mall el cobro ya se dispersó en el commit: no hay liberación posterior.
 */
export async function marcarEnvioEntregado(envioId) {
  const client = getClient()
  return unwrap(
    await client
      .from('envios')
      .update({ estado: ESTADO_ENVIO.ENTREGADO })
      .eq('id', envioId)
      .select(columnasEnvio())
      .single(),
    'No se pudo marcar la entrega como entregada',
  )
}

/**
 * Marca la entrega como fallida con la justificación obligatoria (RF-025).
 *
 * El límite de 1.000 caracteres se valida aquí y en el servidor
 * (`envios.motivo_fallo varchar(1000)`); el error técnico de PostgreSQL se
 * traduce a español (HAL-VEN-028).
 */
export async function marcarEnvioFallido(envioId, motivo) {
  const justificacion = String(motivo ?? '').trim()
  const validacion = validarJustificacion(justificacion, {
    campo: 'La justificación de la entrega fallida',
  })
  if (!validacion.valida) throw new Error(validacion.error)

  const client = getClient()
  const { data, error } = await client
    .from('envios')
    .update({ estado: ESTADO_ENVIO.FALLIDO, motivo_fallo: justificacion })
    .eq('id', envioId)
    .select(columnasEnvio())
    .single()
  if (error) throw new Error(traducirErrorJustificacion(error.message))
  return data
}

/**
 * El cliente confirma la recepción del pedido entregado.
 * El trigger `sincronizar_envio_entregado` ya dejó el pedido en `completado`;
 * esta confirmación registra `confirmado_cliente_en` para trazabilidad.
 */
export async function confirmarRecepcion(pedidoId) {
  const client = getClient()
  const { error } = await client.rpc('confirmar_recepcion_pedido', { p_pedido_id: pedidoId })
  if (error) throw new Error(limpiarError(error.message))
  return getPedidoDetalle(pedidoId)
}

/**
 * HAL-VEN-029: cancelación del pedido con motivo.
 *
 * El vendedor no tiene UPDATE directo sobre `pedidos` (`pedidos_update_admin`),
 * así que el camino vigente es la RPC security definer
 * `cancelar_pedido_vendedor(p_pedido_id, p_motivo)`, que valida la propiedad y
 * los estados permitidos y guarda `motivo_cancelacion` + `cancelado_en`. El
 * trigger existente repone el stock.
 *
 * Si la RPC todavía no existe (modo demo o entorno sin migrar) se intenta el
 * update directo como compatibilidad; en producción el vendedor recibirá el
 * mensaje funcional que pide avisar al administrador.
 */
export async function cancelarPedido(pedidoId, motivo = '') {
  const texto = String(motivo ?? '').trim()
  const validacion = validarJustificacion(texto, {
    requerido: false,
    campo: 'El motivo de la cancelación',
  })
  if (!validacion.valida) throw new Error(validacion.error)

  const client = getClient()
  const { data, error } = await client.rpc('cancelar_pedido_vendedor', {
    p_pedido_id: pedidoId,
    p_motivo: texto,
  })
  if (!error) {
    const pedido = data && typeof data === 'object' ? data : { id: pedidoId }
    const motivoRegistrado = Boolean(pedido.motivo_cancelacion ?? texto)
    return {
      ...pedido,
      id: pedido.id ?? pedidoId,
      estado: ESTADO_PEDIDO.CANCELADO,
      motivo_cancelacion: pedido.motivo_cancelacion ?? (texto || null),
      motivo_registrado: motivoRegistrado,
    }
  }

  if (!esFuncionRpcNoDisponible(error.message)) {
    throw new Error(traducirErrorCancelacion(error.message))
  }

  return cancelarPedidoDirecto(client, pedidoId, texto)
}

/** Compatibilidad con entornos sin `cancelar_pedido_vendedor` (demo/admin). */
async function cancelarPedidoDirecto(client, pedidoId, motivo) {
  const base = {
    estado: ESTADO_PEDIDO.CANCELADO,
    cancelado_en: new Date().toISOString(),
  }
  const conMotivo = motivo ? { ...base, motivo_cancelacion: motivo } : base
  let respuesta = await client
    .from('pedidos')
    .update(conMotivo)
    .eq('id', pedidoId)
    .select()
    .single()

  // Entornos anteriores a la columna: se cancela igual y se informa que el
  // motivo no quedó persistido.
  let motivoPersistido = Boolean(respuesta.data?.motivo_cancelacion)
  if (respuesta.error && motivo && esColumnaAusente(respuesta.error, 'motivo_cancelacion')) {
    respuesta = await client
      .from('pedidos')
      .update(base)
      .eq('id', pedidoId)
      .select()
      .single()
    motivoPersistido = false
  }

  if (respuesta.error) throw new Error(traducirErrorCancelacion(respuesta.error.message))
  return {
    ...respuesta.data,
    id: respuesta.data?.id ?? pedidoId,
    estado: ESTADO_PEDIDO.CANCELADO,
    motivo_cancelacion: respuesta.data?.motivo_cancelacion ?? (motivo || null),
    motivo_registrado: motivoPersistido,
  }
}

function esColumnaAusente(error, columna) {
  const texto = `${error?.message ?? ''} ${error?.details ?? ''} ${error?.hint ?? ''}`
  return (
    error?.code === 'PGRST204' ||
    (texto.includes(columna) && /schema cache|does not exist|Could not find/i.test(texto))
  )
}

/* ---------------------------------------------------------------- */
/* Calificaciones (RF-006)                                             */
/* ---------------------------------------------------------------- */

/**
 * Calificación simple de 1 a 5 asociada al pedido entregado.
 * El trigger `actualizar_reputacion_productor` recalcula el promedio.
 */
export async function createEvaluacion({ pedidoId, puntaje, comentario = null }) {
  const client = getClient()
  const userId = await currentUserId()
  const pedido = await getPedido(pedidoId)
  if (!pedido) throw new Error('Pedido inexistente')

  const nota = Number(puntaje)
  if (!Number.isInteger(nota) || nota < 1 || nota > 5) {
    throw new Error('La calificación debe ser un número entero entre 1 y 5')
  }
  // La RLS `evaluaciones_insert_cliente` admite pedidos `completado` o
  // `reclamado`: un pedido reclamado también se puede calificar.
  if (![ESTADO_PEDIDO.COMPLETADO, ESTADO_PEDIDO.RECLAMADO].includes(pedido.estado)) {
    throw new Error('Sólo puedes calificar un pedido entregado o reclamado')
  }

  return unwrap(
    await client
      .from('evaluaciones_reputacion')
      .insert({
        pedido_id: pedidoId,
        productor_id: pedido.productor_id,
        cliente_id: userId,
        puntaje: nota,
        comentario: comentario?.trim() ? comentario.trim() : null,
      })
      .select()
      .single(),
    'No se pudo guardar la calificación',
  )
}

export async function getEvaluacion(pedidoId) {
  const client = getClient()
  const { data } = await client
    .from('evaluaciones_reputacion')
    .select('*')
    .eq('pedido_id', pedidoId)
    .maybeSingle()
  return data ?? null
}

/** Promedio y total de calificaciones del vendedor (RF-006). */
export async function getReputacionProductor(productorId) {
  const client = getClient()
  const { data } = await client
    .from('productores')
    .select('id, puntaje_reputacion, cantidad_evaluaciones')
    .eq('id', productorId)
    .maybeSingle()
  const { data: evaluaciones } = await client
    .from('evaluaciones_reputacion')
    .select('puntaje, comentario, creado_en')
    .eq('productor_id', productorId)
    .order('creado_en', { ascending: false })
    .limit(10)
  const cantidad = Number(data?.cantidad_evaluaciones ?? 0)
  return {
    // El esquema arranca con 5.00 por defecto; sin evaluaciones no hay nota
    // real que mostrar (el perfil diría "5,0" y "0 evaluaciones" a la vez).
    puntaje:
      cantidad > 0 && data?.puntaje_reputacion != null
        ? Number(data.puntaje_reputacion)
        : null,
    cantidad,
    evaluaciones: evaluaciones ?? [],
  }
}

/* ---------------------------------------------------------------- */
/* Resumen para el cliente                                             */
/* ---------------------------------------------------------------- */

export async function getResumenCliente() {
  const client = getClient()
  const userId = await currentUserId()
  if (!userId) return null
  const { data } = await client
    .from('pedidos')
    .select('*')
    .eq('cliente_id', userId)
    .order('creado_en', { ascending: false })

  const items = data ?? []
  const ids = items.map((p) => p.id)
  const { data: envios } = ids.length
    ? await client.from('envios').select('pedido_id, estado').in('pedido_id', ids)
    : { data: [] }
  const envioMap = new Map((envios ?? []).map((e) => [e.pedido_id, e]))
  const gastado = items
    .filter((p) => p.estado !== ESTADO_PEDIDO.CANCELADO)
    .reduce((acc, p) => acc + Number(p.total), 0)

  return {
    total: items.length,
    enPreparacion: items.filter((p) => p.estado === ESTADO_PEDIDO.EN_PREPARACION).length,
    // CLI-PED-006: el contador «en ruta» cuenta envíos En tránsito, no pagos.
    enTransito: items.filter(
      (p) => envioMap.get(p.id)?.estado === ESTADO_ENVIO.EN_TRANSITO,
    ).length,
    entregados: items.filter((p) => p.estado === ESTADO_PEDIDO.COMPLETADO).length,
    cancelados: items.filter((p) => p.estado === ESTADO_PEDIDO.CANCELADO).length,
    gastado: Math.round(gastado * 100) / 100,
    ultimo: items[0] ?? null,
  }
}

/** Mensaje legible y seguro para los errores de Postgres/PLpgSQL (sin SQL interno). */
function limpiarError(mensaje = '') {
  return mensajeSeguro(mensaje, 'No se pudo completar la operación del pedido')
}

/* ==================================================================
 * SERVICIOS HEREDADOS — SÓLO GALERÍA DE DESARROLLO
 * ==================================================================
 * NOTA DE MIGRACIÓN (alcance anterior, ya se usan sólo en la ventana
 * "Reclamos abiertos" de la galería):
 *   Los reclamos y la evidencia fotográfica por pedido salieron del alcance
 *   vigente: RF-007 usa el código de verificación y el caso de una entrega
 *   fallida se gestiona como reembolso (RF-005). La tabla `reclamos` se
 *   conserva como HERRAMIENTA DE DESARROLLO (migración
 *   `20261006100000_add_gallery_legacy_tables.sql`). Las funciones de
 *   evidencias fotográficas se retiraron de este servicio (HAL-CLI-022).
 * ================================================================ */

/** Reclamos de un pedido (heredado). */
export async function listReclamosPedido(pedidoId) {
  const client = getClient()
  const { data } = await client
    .from('reclamos')
    .select('*')
    .eq('pedido_id', pedidoId)
    .order('creado_en', { ascending: false })
  return data ?? []
}

/** Cierre de un reclamo por parte del administrador (heredado). */
export async function resolverReclamo(reclamoId, estado, resueltoPor) {
  const client = getClient()
  return unwrap(
    await client
      .from('reclamos')
      .update({ estado, resuelto_por: resueltoPor, resuelto_en: new Date().toISOString() })
      .eq('id', reclamoId)
      .select()
      .single(),
    'No se pudo resolver el reclamo',
  )
}

export { REGLAS }
