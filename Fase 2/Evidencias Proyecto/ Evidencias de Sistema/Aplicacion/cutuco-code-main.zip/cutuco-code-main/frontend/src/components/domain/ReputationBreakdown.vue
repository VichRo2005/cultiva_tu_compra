<script setup>
/**
 * CuTuCo — Calificaciones recibidas por el vendedor (RF-006).
 *
 * Muestra el promedio simple de las notas de 1 a 5 y el historial de comentarios
 * de los clientes. Reemplaza al desglose ponderado 40/40/20 del ERS inicial.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): los criterios "entregas a
 * tiempo", "calidad" y "respuesta a reclamos" con sus pesos salieron del
 * alcance; el esquema sólo guarda `puntaje` (1 a 5) y `comentario`.
 */
import { computed } from 'vue'
import CtCard from '@/components/base/CtCard.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import { formatDate, formatNumber } from '@/lib/format'

const props = defineProps({
  evaluaciones: { type: Array, default: () => [] },
  mostrarHistorial: { type: Boolean, default: true },
})

const lista = computed(() => props.evaluaciones ?? [])

const promedio = computed(() => {
  if (!lista.value.length) return 0
  return lista.value.reduce((acc, e) => acc + Number(e.puntaje ?? 0), 0) / lista.value.length
})

/** Distribución de notas 5..1 para el gráfico de barras. */
const distribucion = computed(() =>
  [5, 4, 3, 2, 1].map((nota) => {
    const total = lista.value.filter((e) => Number(e.puntaje) === nota).length
    return {
      key: `nota-${nota}`,
      label: `${nota} ${nota === 1 ? 'estrella' : 'estrellas'}`,
      nota,
      total,
      porcentaje: lista.value.length ? (total / lista.value.length) * 100 : 0,
    }
  }),
)

function tone(valor) {
  const n = Number(valor)
  if (n >= 4) return 'success'
  if (n >= 3) return 'warning'
  return 'danger'
}
</script>

<template>
  <CtCard
    title="Calificaciones de clientes"
    subtitle="Promedio simple de las notas de 1 a 5"
    padding="md"
  >
    <CtEmptyState
      v-if="!lista.length"
      compact
      icon="star"
      title="Todavía no hay calificaciones"
      message="Cuando un cliente confirme la entrega de su pedido podrá calificarte de 1 a 5."
    />

    <template v-else>
      <div class="rb__cabecera">
        <div class="rb__promedio">
          <span class="rb__valor">{{ formatNumber(promedio, 2) }}</span>
          <CtRatingStars :model-value="promedio" :size="16" />
          <span class="rb__total">
            {{ lista.length }} {{ lista.length === 1 ? 'calificación' : 'calificaciones' }}
          </span>
        </div>

        <ul class="rb__distribucion">
          <li v-for="fila in distribucion" :key="fila.key" class="rb__fila">
            <span class="rb__nota">{{ fila.label }}</span>
            <CtProgressBar :value="fila.porcentaje" :max="100" :tone="tone(fila.nota)" size="sm" />
            <span class="rb__cantidad">{{ fila.total }}</span>
          </li>
        </ul>
      </div>

      <template v-if="mostrarHistorial">
        <h3 class="rb__titulo">Últimas calificaciones</h3>
        <ul class="rb__historial">
          <li v-for="(evaluacion, indice) in lista" :key="evaluacion.id ?? indice" class="rb__item">
            <CtAvatar :name="String(evaluacion.puntaje)" :size="30" tone="accent" />
            <div class="rb__texto">
              <div class="rb__meta">
                <CtRatingStars :model-value="Number(evaluacion.puntaje)" :size="13" />
                <CtBadge :tone="tone(evaluacion.puntaje)" size="sm">
                  {{ evaluacion.puntaje }}/5
                </CtBadge>
                <span class="rb__fecha">{{ formatDate(evaluacion.creado_en) }}</span>
              </div>
              <p class="rb__comentario">
                {{ evaluacion.comentario || 'El cliente no dejó comentarios.' }}
              </p>
            </div>
          </li>
        </ul>
      </template>
    </template>
  </CtCard>
</template>

<style scoped>
.rb__cabecera {
  display: grid;
  grid-template-columns: minmax(0, 200px) minmax(0, 1fr);
  gap: var(--ct-space-6);
  align-items: center;
}

.rb__promedio {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  align-items: flex-start;
}

.rb__valor {
  font-size: var(--ct-fs-4xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: 1;
}

.rb__total {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.rb__distribucion {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.rb__fila {
  display: grid;
  grid-template-columns: 96px minmax(0, 1fr) 32px;
  align-items: center;
  gap: var(--ct-space-3);
}

.rb__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.rb__cantidad {
  font-size: var(--ct-fs-xs);
  text-align: right;
  color: var(--ct-text-muted);
}

.rb__titulo {
  margin: var(--ct-space-5) 0 var(--ct-space-3);
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
}

.rb__historial {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.rb__item {
  display: flex;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.rb__item:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.rb__texto {
  min-width: 0;
}

.rb__meta {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

.rb__fecha {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.rb__comentario {
  margin-top: var(--ct-space-1);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

@media (max-width: 720px) {
  .rb__cabecera {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
