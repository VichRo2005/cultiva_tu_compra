<script setup>
/**
 * CuTuCo — Registro de Vendedor / Productor AFC (RF-021, RF-018 y RF-019).
 *
 * Solicita datos personales, datos de la tienda, región y comuna desde combobox
 * (RF-018), el tipo de persona y el RUT del solicitante, los cuatro documentos
 * de la postulación (bucket privado `vendedor-documentos`) y los datos
 * bancarios del comercio para su identificación en Transbank (RF-014).
 *
 * La postulación se crea como `borrador` y se envía a `en_revision` con un solo
 * UPDATE que incluye las 4 rutas de documentos (`crearPostulacion` +
 * `enviarPostulacion` en services/registro.js). El administrador resuelve vía
 * `resolver_postulacion_vendedor`: hasta entonces el vendedor no puede vender.
 */
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtStepper from '@/components/base/CtStepper.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import { useGeographyStore } from '@/stores/geography'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import {
  TELEFONO_AYUDA,
  formatearRut,
  guardarBorradorLocal,
  guardarBorradorProtegidoLocal,
  mensajeCalle,
  mensajeConfirmacion,
  mensajeDeptoOficina,
  mensajeDescripcion,
  mensajeEmail,
  mensajeNombre,
  mensajeNombreComercial,
  mensajeNumeroCuenta,
  mensajeNumeroDireccion,
  mensajePassword,
  mensajeReferencia,
  mensajeRut,
  mensajeTelefono,
  mensajeTitular,
  normalizarNombre,
  obtenerMiPostulacion,
  registrarVendedor,
  sugerirTitularCuenta,
  verificarNombreComercialDisponible,
  verificarRutDisponible,
  validarContenidoDocumento,
  validarCuentaDeTerceros,
  validarDocumentoPostulante,
} from '@/services/registro'
import { BANCOS_DISPONIBLES, TIPOS_CUENTA_BANCARIA } from '@/lib/constants'
import { PASSWORD_REQUIREMENTS, passwordChecks, passwordStrength } from '@/lib/validation'

const router = useRouter()
const geo = useGeographyStore()
const auth = useAuthStore()
const ui = useUiStore()

const TOTAL_PASOS = 4
const paso = ref(1)
const enviando = ref(false)
const aceptado = ref(false)
const error = ref(null)
const errores = reactive({})
const requiereConfirmacionPantalla = ref(false)
const emailParaConfirmar = ref('')

const form = reactive({
  nombre: '',
  apellido: '',
  email: '',
  telefono: '',
  password: '',
  confirmacion: '',
  nombreComercial: '',
  descripcion: '',
  regionId: '',
  comunaId: '',
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
  tipoPersona: 'natural',
  rutSolicitante: '',
  banco: '',
  tipoCuenta: 'cuenta_vista',
  numeroCuenta: '',
  titular: '',
  rutTitular: '',
})

/**
 * Documentos de la postulación (RF-021). Los nombres y cantidad son exactos
 * porque `validar_postulacion_estado` exige las cuatro rutas al enviar.
 * Natural: cédula, inicio de actividades SII, titularidad bancaria, comprobante
 * de domicilio. Jurídica: E-RUT, cédula del representante, titularidad de la
 * empresa, comprobante de domicilio tributario.
 */
const documentos = reactive({
  documentoIdentidad: null,
  certificadoActividadesOCarnet: null,
  certificadoTitularidad: null,
  comprobanteDomicilio: null,
})

const opcionesTipoPersona = [
  { value: 'natural', label: 'Persona natural' },
  { value: 'juridica', label: 'Persona jurídica (empresa)' },
]

const etiquetasDocumentos = computed(() =>
  form.tipoPersona === 'juridica'
    ? {
        documentoIdentidad: 'E-RUT de la empresa',
        certificadoActividadesOCarnet: 'Cédula del representante legal',
        certificadoTitularidad: 'Certificado de titularidad bancaria de la empresa',
        comprobanteDomicilio: 'Comprobante de domicilio tributario',
      }
    : {
        documentoIdentidad: 'Cédula de identidad',
        certificadoActividadesOCarnet: 'Certificado de inicio de actividades (SII)',
        certificadoTitularidad: 'Certificado de titularidad bancaria',
        comprobanteDomicilio: 'Comprobante de domicilio',
      },
)

async function subirDocumento(clave, event) {
  const input = event?.target
  const file = input?.files?.[0] ?? null
  if (!file) return
  await validarYGuardarDocumento(clave, file)
}

/** Evita que una lectura lenta pise un archivo elegido después (REG-DOC-013). */
const versionDocumento = {}

/** REG-DOC-005/006/011: formato, tamaño y contenido real antes de aceptar el archivo. */
async function validarYGuardarDocumento(clave, file) {
  const version = (versionDocumento[clave] ?? 0) + 1
  versionDocumento[clave] = version
  const rechazo = validarDocumentoPostulante(file)
  if (rechazo) {
    errores[clave] = rechazo
    documentos[clave] = null
    limpiarInput(clave)
    return
  }
  const contenido = await validarContenidoDocumento(file)
  if (versionDocumento[clave] !== version) return
  if (contenido) {
    errores[clave] = contenido
    documentos[clave] = null
    limpiarInput(clave)
    return
  }
  delete errores[clave]
  // El nombre vigente se muestra desde este estado (REG-DOC-014) y el input
  // nativo queda oculto para que nunca aparezca "No se eligió ningún archivo".
  documentos[clave] = file
}

const inputsDocumento = {}

function registrarInput(clave, el) {
  if (el) inputsDocumento[clave] = el
}

function limpiarInput(clave) {
  const input = inputsDocumento[clave]
  if (input) input.value = ''
}

/** Abre el selector y permite volver a elegir el MISMO archivo (REG-DOC-013). */
function abrirSelector(clave) {
  const input = inputsDocumento[clave]
  if (!input) return
  input.value = ''
  input.click()
}

function limpiarDocumento(clave) {
  documentos[clave] = null
  delete errores[clave]
  limpiarInput(clave)
}

function formatearBytes(bytes) {
  const valor = Number(bytes ?? 0)
  if (!Number.isFinite(valor) || valor <= 0) return '0 bytes'
  return `${(valor / (1024 * 1024)).toFixed(1)} MiB`
}

/**
 * Los datos bancarios se guardan por FastAPI (`POST /datos-bancarios`): la
 * migración `20261007004557_datos_bancarios_fastapi_only.sql` revoca
 * `public.datos_bancarios` a `anon` y `authenticated`. Estos valores son el
 * espejo de `backend/app/schemas/datos_bancarios.py`; si no coinciden, el
 * endpoint responde 422.
 */
const TIPOS_CUENTA = TIPOS_CUENTA_BANCARIA
const opcionesBanco = BANCOS_DISPONIBLES.map((b) => ({ value: b, label: b }))

const pasos = computed(() => [
  { key: 'cuenta', label: 'Tu cuenta', description: 'Datos personales y contraseña' },
  { key: 'tienda', label: 'Tu tienda', description: 'Nombre comercial y región' },
  { key: 'documentos', label: 'Documentos', description: 'Identidad y situación tributaria' },
  { key: 'banco', label: 'Pago', description: 'Datos bancarios del comercio' },
])

/**
 * REG-PAG-016 / HAL-REG-008 — El titular se sugiere con el NOMBRE COMPLETO del
 * solicitante, nunca con una inicial. Se recuerda el último valor sugerido: si
 * la persona editó el campo manualmente, no se vuelve a sobrescribir.
 */
const titularSugerido = ref('')

function sugerirTitular() {
  const completo = sugerirTitularCuenta(form.nombre, form.apellido)
  if (!completo) return
  if (!normalizarNombre(form.titular) || form.titular === titularSugerido.value) {
    form.titular = completo
    titularSugerido.value = completo
  }
}

watch(() => [form.nombre, form.apellido], sugerirTitular)
// Al entrar a la etapa Pago el campo se muestra completo aunque los nombres se
// hayan escrito antes de que existiera la sugerencia.
watch(
  () => paso.value,
  (nuevo) => {
    if (nuevo === 4) sugerirTitular()
  },
)

// Banco -> tipo/número dependientes: al cambiarlo se limpian ambos para no
// guardar una combinación de banco y cuenta que no corresponda.
watch(
  () => form.banco,
  (nuevo, anterior) => {
    if (!anterior || nuevo === anterior) return
    form.tipoCuenta = ''
    form.numeroCuenta = ''
  },
)

const fuerza = computed(() => passwordStrength(form.password))
/** Misma regla para indicador, requisitos y permiso de avance (REG-PWD-013). */
const requisitosPassword = computed(() => {
  const checks = passwordChecks(form.password)
  return PASSWORD_REQUIREMENTS.map((requisito) => ({
    ...requisito,
    cumplido: Boolean(checks[requisito.key]),
  }))
})
const etiquetaFuerza = computed(() =>
  fuerza.value.valid ? fuerza.value.label : 'Aún no cumple la política',
)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)

const opcionesComuna = computed(() =>
  geo.comunasDeRegion(form.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

onMounted(async () => {
  void geo.load()
  // A2 (RF-021): si el usuario ya tiene una postulación (borrador, en revisión
  // o rechazada) debe reutilizar ESA única fila; la edición y el reenvío viven
  // en /mi-postulacion y crear otra fallaría en el trigger del esquema.
  const existente = await obtenerMiPostulacion()
  if (existente) router.replace('/mi-postulacion')
})

watch(
  () => form.regionId,
  () => {
    form.comunaId = ''
  },
)

/** Errores de UNA etapa: todos sus campos se validan antes de avanzar. */
function erroresDePaso(n) {
  const e = {}
  const asignar = (clave, mensaje) => {
    if (mensaje) e[clave] = mensaje
  }
  if (n === 1) {
    asignar('nombre', mensajeNombre(form.nombre, 'El nombre'))
    asignar('apellido', mensajeNombre(form.apellido, 'El apellido'))
    asignar('email', mensajeEmail(form.email))
    asignar('telefono', mensajeTelefono(form.telefono))
    asignar('password', mensajePassword(form.password))
    asignar('confirmacion', mensajeConfirmacion(form.password, form.confirmacion))
  }
  if (n === 2) {
    // A3/A7 + REG-VEN: límites y neutralización de HTML antes de crear registros.
    asignar('nombreComercial', mensajeNombreComercial(form.nombreComercial))
    asignar('descripcion', mensajeDescripcion(form.descripcion))
    if (!form.regionId) e.regionId = 'Selecciona la región de tu tienda'
    if (!form.comunaId) e.comunaId = 'Selecciona la comuna de tu tienda'
    asignar('calle', mensajeCalle(form.calle, 'La dirección comercial'))
    asignar('numero', mensajeNumeroDireccion(form.numero))
    asignar('deptoOficina', mensajeDeptoOficina(form.deptoOficina))
    asignar('referencia', mensajeReferencia(form.referencia))
  }
  if (n === 3) {
    if (!['natural', 'juridica'].includes(form.tipoPersona)) {
      e.tipoPersona = 'Selecciona el tipo de persona'
    }
    asignar('rutSolicitante', mensajeRut(form.rutSolicitante, 'El RUT del solicitante'))
    for (const [clave, etiqueta] of Object.entries(etiquetasDocumentos.value)) {
      if (!documentos[clave]) {
        e[clave] = `Adjunta: ${etiqueta}`
        continue
      }
      const rechazo = validarDocumentoPostulante(documentos[clave])
      if (rechazo) e[clave] = rechazo
    }
  }
  if (n === 4) {
    if (!form.banco) e.banco = 'Selecciona el banco'
    else if (!BANCOS_DISPONIBLES.includes(form.banco)) {
      e.banco = 'Selecciona un banco del catálogo'
    }
    if (!form.tipoCuenta) e.tipoCuenta = 'Selecciona el tipo de cuenta'
    asignar('numeroCuenta', mensajeNumeroCuenta(form.numeroCuenta))
    asignar('titular', mensajeTitular(form.titular))
    asignar('rutTitular', mensajeRut(form.rutTitular, 'El RUT del titular'))
    // HAL-REG-014: sólo se cruza con los datos disponibles en el formulario.
    const tercero = validarCuentaDeTerceros({
      tipoPersona: form.tipoPersona,
      titular: form.titular,
      rutTitular: form.rutTitular,
      nombre: form.nombre,
      apellido: form.apellido,
      rutSolicitante: form.rutSolicitante,
    })
    if (tercero) e[tercero.campo] = tercero.mensaje
    if (!aceptado.value) e.aceptado = 'Debes aceptar los términos y la política de privacidad'
  }
  return e
}

function limpiarErrores() {
  Object.keys(errores).forEach((clave) => delete errores[clave])
}

/** HAL-REG-017: la revisión final cubre también las etapas ya completadas. */
function erroresDeTodasLasEtapas() {
  const todos = {}
  for (let n = 1; n <= TOTAL_PASOS; n += 1) Object.assign(todos, erroresDePaso(n))
  return todos
}

function primerPasoConError(todos) {
  for (let n = 1; n <= TOTAL_PASOS; n += 1) {
    if (Object.keys(erroresDePaso(n)).some((clave) => clave in todos)) return n
  }
  return null
}

function validarPaso(n) {
  limpiarErrores()
  Object.assign(errores, erroresDePaso(n))
  return Object.keys(errores).length === 0
}

/** Recorta espacios externos antes de validar/guardar (REG-COM-004). */
function recortar(campo) {
  form[campo] = normalizarNombre(form[campo])
}

/** HAL-REG-017: valida un campo individual en tiempo real (blur/change). */
function validarCampo(clave, fn) {
  const msg = fn()
  if (msg) errores[clave] = msg
  else delete errores[clave]
}

/** Normaliza el RUT visible a un único formato (REG-VEN-013 / REG-PAG-017). */
function normalizarRutVisible(campo) {
  form[campo] = formatearRut(form[campo])
}

function siguiente() {
  if (enviando.value) return
  if (!validarPaso(paso.value)) return
  paso.value = Math.min(TOTAL_PASOS, paso.value + 1)
}

function anterior() {
  if (enviando.value) return
  limpiarErrores()
  paso.value = Math.max(1, paso.value - 1)
}

async function registrar() {
  if (enviando.value || requiereConfirmacionPantalla.value) return
  // REG-NAV-006: una sola creación mientras la operación está pendiente.
  if (enviando.value) return
  const todos = erroresDeTodasLasEtapas()
  limpiarErrores()
  Object.assign(errores, todos)
  if (Object.keys(todos).length) {
    const destino = primerPasoConError(todos)
    if (destino) paso.value = destino
    error.value = 'Revisa los campos marcados: hay datos inválidos o pendientes.'
    return
  }

  /*
   * REG-VEN-002 / REG-VEN-015: verificaciones previas al alta. Un fallo de estas
   * consultas se muestra en el formulario; antes quedaba como rechazo no
   * controlado y la cuenta nunca llegaba a crearse.
   */
  try {
    // REG-VEN-002: nombre comercial no puede duplicar una tienda ya aprobada.
    const nombreCheck = await verificarNombreComercialDisponible(form.nombreComercial)
    if (!nombreCheck.disponible) {
      errores.nombreComercial =
        'Ese nombre comercial ya está registrado por otra tienda. Elige otro.'
      paso.value = 2
      error.value = 'Revisa los campos marcados: hay datos inválidos o pendientes.'
      return
    }

    // REG-VEN-015: el RUT no puede estar asociado a otra postulación.
    const rutCheck = await verificarRutDisponible(form.rutSolicitante)
    if (!rutCheck.disponible) {
      errores.rutSolicitante =
        'Este RUT ya está asociado a otra postulación de vendedor.'
      // El RUT se corrige junto con los antecedentes, no en la etapa Tienda.
      // Llevar al paso 2 ocultaba el campo que acabamos de marcar con error.
      paso.value = 3
      error.value = 'Revisa los campos marcados: hay datos inválidos o pendientes.'
      return
    }
  } catch (e) {
    error.value = e.message
    return
  }

  enviando.value = true
  error.value = null
  try {
    const { userId, requiereConfirmacion, advertencias = [] } = await registrarVendedor({
      nombre: form.nombre,
      apellido: form.apellido,
      email: form.email,
      password: form.password,
      telefono: form.telefono,
      nombreComercial: form.nombreComercial,
      descripcion: form.descripcion,
      regionId: form.regionId,
      comunaId: form.comunaId,
      calle: form.calle,
      numero: form.numero,
      deptoOficina: form.deptoOficina,
      referencia: form.referencia,
      rutSolicitante: form.rutSolicitante,
      tipoPersona: form.tipoPersona,
      documentos: { ...documentos },
      datosBancarios: {
        banco: form.banco,
        tipoCuenta: form.tipoCuenta,
        numeroCuenta: form.numeroCuenta,
        titular: form.titular,
        rutTitular: form.rutTitular,
      },
    })

    if (requiereConfirmacion) {
      // REG-CONF-005: sin sesión, GoTrue impide subir documentos y cifrar la
      // cuenta en el servidor. La solicitud queda en metadata/borrador y los
      // valores sensibles se resguardan temporalmente cifrados para moverlos a
      // /mi-postulacion al confirmar el correo en este mismo navegador.
      guardarBorradorLocal({
        nombreComercial: form.nombreComercial,
        descripcion: form.descripcion,
        rutSolicitante: form.rutSolicitante,
        tipoPersona: form.tipoPersona,
        email: form.email,
        guardadoEn: new Date().toISOString(),
      })
      const respaldoProtegido = await guardarBorradorProtegidoLocal({
        userId,
        datosBancarios: {
          banco: form.banco,
          tipoCuenta: form.tipoCuenta,
          numeroCuenta: form.numeroCuenta,
          titular: form.titular,
          rutTitular: form.rutTitular,
        },
        documentos: { ...documentos },
      })
      ui.warning(
        'Cuenta creada: confirma tu correo',
        respaldoProtegido
          ? 'Te enviamos el enlace de verificación. Cuando confirmes el correo, tu perfil y postulación se crearán; restauraremos y guardaremos automáticamente los documentos y los datos bancarios que ingresaste en este navegador.'
          : 'Te enviamos el enlace de verificación. Cuando confirmes el correo, tu perfil y postulación se crearán con los datos que ingresaste. Este navegador no pudo resguardar temporalmente los documentos y los datos bancarios; deberás adjuntarlos de nuevo al iniciar sesión.',
      )
      emailParaConfirmar.value = form.email
      requiereConfirmacionPantalla.value = true
      return
    }

    // B1 (RF-021): con sesión, el solicitante llega directo al estado de SU
    // postulación (nunca a la pantalla de login). Hay que refrescar el store:
    // `signUp` abrió sesión en GoTrue, pero Pinia todavía no conoce al usuario y
    // el guard de `/mi-postulacion` lo expulsaría al login.
    await auth.refresh()
    router.push({ name: 'mi-postulacion' })

    if (advertencias.length) {
      ui.warning('Cuenta creada con pendientes', advertencias.join(' '))
      return
    }
    ui.success(
      'Solicitud enviada',
      'El administrador revisará tus antecedentes antes de activar tu tienda.',
    )
  } catch (e) {
    error.value = e.message
  } finally {
    enviando.value = false
  }
}

/** Permite recuperar un enlace vencido sin obligar a reiniciar el registro. */
async function reenviarVerificacion() {
  if (enviando.value) return
  enviando.value = true
  error.value = null
  try {
    await auth.reenviarVerificacion(emailParaConfirmar.value)
    ui.success('Enlace reenviado', 'Revisa tu correo y confirma tu cuenta de vendedor.')
  } catch (e) {
    error.value = e?.message ?? 'No se pudo reenviar el enlace. Inténtalo de nuevo.'
  } finally {
    enviando.value = false
  }
}
</script>

<template>
  <AuthLayout
    title="Quiero vender"
    subtitle="Publica tus productos en CuTuCo. La cuenta queda pendiente hasta que validemos tus antecedentes."
  >
    <CtStepper v-if="!requiereConfirmacionPantalla" :steps="pasos" :current="paso" />

    <form
      v-if="!requiereConfirmacionPantalla"
      class="stack stack--lg"
      novalidate
      @submit.prevent="paso === 4 ? registrar() : siguiente()"
    >
      <CtAlert v-if="error" tone="danger">{{ error }}</CtAlert>

      <!-- ============ PASO 1 · CUENTA ============ -->
      <section v-if="paso === 1" class="stack">
        <div class="ven__pares">
          <CtInput
            v-model="form.nombre"
            label="Nombre"
            :error="errores.nombre"
            autocomplete="given-name"
            hint="Se aceptan tildes, ñ y guiones; sin números ni símbolos."
            required
            @blur="recortar('nombre')"
          />
          <CtInput
            v-model="form.apellido"
            label="Apellido"
            :error="errores.apellido"
            autocomplete="family-name"
            required
            @blur="recortar('apellido')"
          />
        </div>

        <CtInput
          v-model="form.email"
          label="Correo Electrónico"
          type="email"
          placeholder="tucorreo@ejemplo.cl"
          :error="errores.email"
          hint="Debe ser único y sólo admite caracteres ASCII, sin espacios al inicio ni al final (máximo 254)."
          autocomplete="email"
          required
          @blur="validarCampo('email', () => mensajeEmail(form.email))"
        />

        <CtInput
          v-model="form.telefono"
          label="Teléfono de Contacto"
          type="tel"
          placeholder="+56 9 1234 5678"
          :error="errores.telefono"
          :hint="TELEFONO_AYUDA"
          autocomplete="tel"
          required
          @blur="validarCampo('telefono', () => mensajeTelefono(form.telefono))"
        />

        <div>
          <CtInput
            v-model="form.password"
            label="Contraseña"
            type="password"
            :error="errores.password"
            hint="Entre 8 y 72 caracteres ASCII, con mayúscula, minúscula, número y símbolo."
            autocomplete="new-password"
            required
            @blur="validarCampo('password', () => mensajePassword(form.password))"
          />
          <template v-if="form.password">
            <CtProgressBar
              :value="fuerza.score"
              :max="4"
              :tone="fuerza.tone"
              show-label
              :label="etiquetaFuerza"
              class="ven__fuerza"
            />
            <ul class="ven__requisitos" aria-label="Requisitos de la contraseña">
              <li
                v-for="requisito in requisitosPassword"
                :key="requisito.key"
                :class="{ 'is-ok': requisito.cumplido }"
              >
                <CtIcon :name="requisito.cumplido ? 'check' : 'close'" :size="12" aria-hidden="true" />
                {{ requisito.label }}
              </li>
            </ul>
          </template>
        </div>

        <CtInput
          v-model="form.confirmacion"
          label="Confirmar contraseña"
          type="password"
          :error="errores.confirmacion"
          hint="Debe coincidir exactamente con la contraseña."
          autocomplete="new-password"
          required
          @blur="validarCampo('confirmacion', () => mensajeConfirmacion(form.password, form.confirmacion))"
        />
      </section>

      <!-- ============ PASO 2 · TIENDA ============ -->
      <section v-else-if="paso === 2" class="stack">
        <CtInput
          v-model="form.nombreComercial"
          label="Nombre comercial"
          placeholder="Huerta Los Maitenes"
          :error="errores.nombreComercial"
          hint="Así te verán los clientes en el catálogo."
          required
          @blur="validarCampo('nombreComercial', () => mensajeNombreComercial(form.nombreComercial))"
        />
        <CtTextarea
          v-model="form.descripcion"
          label="Descripción de tu actividad"
          :rows="3"
          placeholder="Qué produces, cómo lo cultivas, desde cuándo trabajas la tierra…"
          :maxlength="2000"
          :error="errores.descripcion"
          hint="Máximo 2000 caracteres. No se permite HTML ni scripts."
          show-count
          @blur="validarCampo('descripcion', () => mensajeDescripcion(form.descripcion))"
        />

        <CtAlert tone="info" compact title="Tu región define tu cobertura">
          <p>
            Sólo podrás vender a clientes de tu misma región. La comparación la hace el sistema
            antes de cada pago, sin geolocalización.
          </p>
        </CtAlert>

        <CtAlert v-if="geo.error" tone="danger" title="No pudimos cargar regiones y comunas">
          <p>{{ geo.error }}</p>
          <CtButton
            size="sm"
            variant="secondary"
            type="button"
            :loading="geo.cargando"
            @click="geo.load({ force: true })"
          >
            Reintentar
          </CtButton>
        </CtAlert>

        <CtSelect
          v-model="form.regionId"
          label="Región"
          :options="opcionesRegion"
          :error="errores.regionId"
          :disabled="geo.cargando || !geo.cargado"
          placeholder="Selecciona tu región"
          required
        />
        <CtSelect
          v-model="form.comunaId"
          label="Comuna"
          :options="opcionesComuna"
          :error="errores.comunaId"
          :disabled="!form.regionId"
          :placeholder="form.regionId ? 'Selecciona tu comuna' : 'Primero elige la región'"
          required
        />
        <CtInput
          v-model="form.calle"
          label="Dirección del predio o tienda"
          placeholder="Camino a Paine km 4"
          :error="errores.calle"
          hint="Indica la calle o camino principal del domicilio."
          required
          @blur="recortar('calle')"
        />
        <div class="ven__pares">
          <CtInput
            v-model="form.numero"
            label="Altura de la calle"
            placeholder="1200 o 123-B"
            :error="errores.numero"
              hint="Opcional para domicilios sin numeración. Admite letras y guiones."
            @blur="recortar('numero')"
          />
          <CtInput
            v-model="form.deptoOficina"
            label="Complemento (opcional)"
            placeholder="Local B, parcela 4, oficina 402"
            :error="errores.deptoOficina"
            hint="Se guarda separado de la calle y del número."
            @blur="recortar('deptoOficina')"
          />
        </div>
        <CtInput
          v-model="form.referencia"
          label="Referencia (opcional)"
          placeholder="Portón azul, frente a la escuela"
          :error="errores.referencia"
          @blur="recortar('referencia')"
        />
      </section>

      <!-- ============ PASO 3 · DOCUMENTOS DE LA POSTULACIÓN ============ -->
      <section v-else-if="paso === 3" class="stack">
        <CtAlert tone="info" compact title="Documentos requeridos">
          <p>
            Tus cuatro documentos se guardan de forma segura y sólo los revisa el equipo de
            CuTuCo. Sin ellos tu solicitud no puede pasar a revisión.
          </p>
        </CtAlert>

        <CtSelect
          v-model="form.tipoPersona"
          label="Tipo de persona"
          :options="opcionesTipoPersona"
          :error="errores.tipoPersona"
          required
        />
        <CtInput
          v-model="form.rutSolicitante"
          label="RUT del solicitante"
          placeholder="12.345.678-9"
          :error="errores.rutSolicitante"
          hint="Persona natural: tu RUT. Persona jurídica: RUT de la empresa. Se valida el dígito verificador."
          required
          @blur="normalizarRutVisible('rutSolicitante')"
        />

        <div v-for="clave in Object.keys(documentos)" :key="clave" class="doc">
          <span class="doc__etiqueta">
            {{ etiquetasDocumentos[clave] }}
            <span class="doc__obligatorio">(obligatorio)</span>
          </span>
          <p v-if="errores[clave]" class="doc__error" role="alert">{{ errores[clave] }}</p>
          <div class="doc__fila">
            <!-- El input nativo queda oculto: así nunca aparece el texto
                 "No se eligió ningún archivo" y el nombre vigente lo muestra
                 el estado de la aplicación (REG-DOC-013/014). -->
            <button
              type="button"
              class="doc__seleccionar"
              :aria-label="`Seleccionar ${etiquetasDocumentos[clave]}`"
              @click="abrirSelector(clave)"
            >
              {{ documentos[clave] ? 'Reemplazar archivo' : 'Seleccionar archivo' }}
            </button>
            <input
              :ref="(el) => registrarInput(clave, el)"
              type="file"
              class="doc__input"
              accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"
              tabindex="-1"
              :aria-label="etiquetasDocumentos[clave]"
              @change="subirDocumento(clave, $event)"
            />
            <span v-if="documentos[clave]" class="doc__nombre">
              <CtIcon name="doc" :size="14" aria-hidden="true" />
              {{ documentos[clave].name }}
              <span class="doc__tamano">({{ formatearBytes(documentos[clave].size) }})</span>
              <button type="button" class="doc__quitar" @click="limpiarDocumento(clave)">
                Quitar
              </button>
            </span>
            <span v-else class="doc__vacio">
              Ningún archivo seleccionado · PDF, JPG o PNG de hasta 10 MiB
            </span>
          </div>
        </div>
      </section>

      <!-- ============ PASO 4 · DATOS BANCARIOS ============ -->
      <section v-else class="stack">
        <CtAlert tone="info" compact title="¿Para qué necesitamos estos datos?">
          <p>
            Sirven para identificar tu cuenta y enviar el pago de cada venta. CuTuCo descuenta su
            comisión del 5 % y tus datos se guardan de forma segura.
          </p>
        </CtAlert>

        <CtSelect
          v-model="form.banco"
          label="Banco"
          :options="opcionesBanco"
          placeholder="Selecciona tu banco"
          :error="errores.banco"
          required
          @blur="validarCampo('banco', () => { if (!form.banco) return 'Selecciona el banco'; if (!BANCOS_DISPONIBLES.includes(form.banco)) return 'Selecciona un banco del catálogo'; return null })"
        />
        <CtSelect
          v-model="form.tipoCuenta"
          label="Tipo de cuenta"
          :options="TIPOS_CUENTA"
          :error="errores.tipoCuenta"
          required
          @blur="validarCampo('tipoCuenta', () => { if (!form.tipoCuenta) return 'Selecciona el tipo de cuenta'; if (!TIPOS_CUENTA_BANCARIA.some((t) => t.value === form.tipoCuenta)) return 'Selecciona un tipo de cuenta válido'; return null })"
        />
        <CtInput
          v-model="form.numeroCuenta"
          label="Número de cuenta"
          placeholder="00012345678"
          inputmode="numeric"
          autocomplete="off"
          :error="errores.numeroCuenta"
          hint="Entre 7 y 12 dígitos, sin puntos ni espacios. Se guarda como texto para conservar los ceros iniciales y de forma cifrada."
          required
          @blur="validarCampo('numeroCuenta', () => mensajeNumeroCuenta(form.numeroCuenta))"
        />
        <CtInput
          v-model="form.titular"
          label="Titular de la cuenta"
          :error="errores.titular"
          hint="Nombre completo de la persona natural o razón social de la empresa. Se autocompleta con tu nombre y puedes corregirlo."
          required
          @blur="recortar('titular')"
        />
        <CtInput
          v-model="form.rutTitular"
          label="RUT del titular"
          placeholder="12.345.678-9"
          :error="errores.rutTitular"
          hint="Debe coincidir con el RUT del postulante: no se aceptan cuentas de terceros."
          required
          @blur="normalizarRutVisible('rutTitular')"
        />

        <CtAlert v-if="form.tipoPersona === 'juridica'" tone="info" compact>
          <p>
            La cuenta debe estar a nombre de la empresa postulante. Si el banco rechaza la
            titularidad, la revisión administrativa lo informará con el motivo.
          </p>
        </CtAlert>

        <CtCheckbox
          v-model="aceptado"
          label="Declaro que los datos son correctos y acepto los términos y la política de privacidad de CuTuCo"
          :error="errores.aceptado"
        />
      </section>

      <div class="ven__acciones">
        <CtButton v-if="paso > 1" variant="ghost" type="button" :disabled="enviando" @click="anterior">
          Atrás
        </CtButton>
        <span v-else class="spacer" />
        <CtButton type="submit" :loading="enviando" :disabled="enviando">
          {{ paso === TOTAL_PASOS ? 'Enviar solicitud' : 'Continuar' }}
        </CtButton>
      </div>
    </form>

    <section v-if="requiereConfirmacionPantalla" class="stack stack--lg ven__confirm">
      <CtAlert tone="warning" title="Cuenta creada: confirma tu correo">
        <p>
          Enviamos un enlace de verificación a <strong>{{ emailParaConfirmar }}</strong>. Confírmalo
          para activar tu perfil y continuar con tu postulación de vendedor.
        </p>
      </CtAlert>
      <div class="ven__acciones">
        <CtButton variant="ghost" type="button" :disabled="enviando" @click="reenviarVerificacion">
          Reenviar enlace de verificación
        </CtButton>
        <span class="spacer" />
        <CtButton to="/login" type="button">Ir a iniciar sesión</CtButton>
      </div>
      <p class="ven__pie">
        Si el enlace venció o no llegó, puedes reenviarlo desde esta misma pantalla.
      </p>
    </section>

    <CtAlert tone="neutral" compact title="Qué pasa después">
      <p>
        El administrador revisa tus antecedentes y aprueba o rechaza la solicitud. Si la aprueba,
        podrás publicar productos con su foto y gestionar tus pedidos; si la rechaza, te avisamos por
        correo con el motivo.
      </p>
    </CtAlert>

    <p class="ven__pie">
      <router-link to="/registro">
        <CtIcon name="arrowLeft" :size="14" aria-hidden="true" />
        Quiero comprar en CuTuCo
      </router-link>
    </p>
  </AuthLayout>
</template>

<style scoped>
.ven__pares {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
}

.doc {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
}

.doc__etiqueta {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
}

.doc__obligatorio {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-regular);
  color: var(--ct-text-muted);
}

.doc__error {
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
}

.doc__fila {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
}

/* Input nativo oculto, pero presente: el botón visible abre el selector y el
   nombre vigente se muestra desde el estado de la aplicación (REG-DOC-014). */
.doc__input {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}

.doc__seleccionar {
  display: inline-flex;
  align-items: center;
  min-height: 40px;
  padding: 0 var(--ct-space-4);
  border: 1.5px solid var(--ct-border-strong);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
  cursor: pointer;
}

.doc__seleccionar:hover {
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.doc__seleccionar:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: 2px;
}

.doc__nombre {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  word-break: break-word;
}

.doc__tamano {
  color: var(--ct-text-muted);
}

.doc__vacio {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ven__requisitos {
  display: grid;
  gap: 2px;
  margin-top: var(--ct-space-2);
  padding: 0;
  list-style: none;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ven__requisitos li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.ven__requisitos li.is-ok {
  color: var(--ct-success);
}

.doc__quitar {
  margin-left: var(--ct-space-2);
  color: var(--ct-danger);
  font-size: var(--ct-fs-xs);
  text-decoration: underline;
}

.ven__fuerza {
  margin-top: var(--ct-space-2);
}

.ven__acciones {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.ven__pie {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  text-align: center;
}

.ven__pie a {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-1);
  min-height: 24px;
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

@media (max-width: 560px) {
  .ven__pares {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
