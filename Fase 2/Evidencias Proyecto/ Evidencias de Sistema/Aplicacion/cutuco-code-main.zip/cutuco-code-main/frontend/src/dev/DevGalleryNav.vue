<script setup>
/**
 * CuTuCo — Barra lateral temporal de navegación de todas las ventanas (TEMPORAL).
 *
 * ⚠️ Se elimina junto con la carpeta `src/dev/` antes del release.
 * No forma parte del diseño de "CuTuCo Vistas": es una herramienta de revisión
 * que permite abrir cualquier ventana sin autenticarse y saltar de rol.
 *
 * Montaje: un botón flotante (fijo, esquina inferior derecha) más el aviso
 * "Vistas en Desarrollo". No modifica el shell del producto.
 */
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtIcon from '@/components/base/CtIcon.vue'
import { useAuthStore } from '@/stores/auth'
import { autenticarComo, DEV_GROUPS, DEV_SESSIONS, DEV_VIEW_COUNT, habilitarSesionAutomatica } from '@/dev/devGallery'

const ruta = useRoute()
const router = useRouter()
const auth = useAuthStore()

const model = defineModel({ type: Boolean, default: false })
const activo = ref('general')
const cambiando = ref(false)
const error = ref('')

const grupos = DEV_GROUPS
const actual = computed(() => ruta.fullPath)
const sesionActual = computed(() => auth.user?.email ?? null)

async function ir(path) {
  model.value = false
  if (actual.value === path) return
  await router.push(path)
}

/**
 * Cambia la sesión de revisión y navega a la ventana de inicio del rol, para que
 * los paneles que exigen sesión muestren los datos reales de esa cuenta.
 */
async function cambiarRol(sesion) {
  if (cambiando.value || auth.user?.email === sesion.email) return
  model.value = false
  cambiando.value = true
  error.value = ''
  try {
    // Al usar la galería el acceso automático vuelve a quedar habilitado, aunque
    // el revisor haya cerrado sesión a mano antes.
    habilitarSesionAutomatica()
    await autenticarComo(sesion)
    await router.push(sesion.home ?? '/')
  } catch (e) {
    error.value = e?.message ?? 'No se pudo cambiar la sesión de revisión'
  } finally {
    cambiando.value = false
  }
}

watch(() => ruta.fullPath, () => {
  model.value = false
})
</script>

<template>
  <div class="dev-gallery">
    <!-- Botón flotante: abre la galería -->
    <button
      type="button"
      class="dev-gallery__toggle"
      :class="{ 'is-open': model }"
      :aria-expanded="model"
      aria-label="Galería de vistas en desarrollo"
      @click="model = !model"
    >
      <CtIcon :name="model ? 'close' : 'grid'" :size="20" />
      <span class="dev-gallery__toggle-text">Vistas</span>
    </button>

    <div v-if="model" class="dev-gallery__scrim" @click="model = false" />

    <aside v-if="model" class="dev-gallery__panel">
      <header class="dev-gallery__head">
        <div>
          <p class="dev-gallery__kicker">Galería temporal</p>
          <h2 class="dev-gallery__title">Vistas en Desarrollo</h2>
          <p class="dev-gallery__sub">{{ DEV_VIEW_COUNT }} ventanas navegables sin autenticación.</p>
        </div>
        <button type="button" class="dev-gallery__close" aria-label="Cerrar galería" @click="model = false">
          <CtIcon name="close" :size="18" />
        </button>
      </header>

      <div class="dev-gallery__roles">
        <span class="dev-gallery__roles-label">Ver como</span>
        <div class="dev-gallery__roles-list">
          <button
            v-for="sesion in DEV_SESSIONS"
            :key="sesion.key"
            type="button"
            class="dev-gallery__role"
            :class="{ 'is-active': sesionActual === sesion.email }"
            :disabled="cambiando"
            @click="cambiarRol(sesion.email)"
          >
            <CtIcon :name="sesion.icon" :size="15" />
            {{ sesion.label }}
          </button>
        </div>
        <p v-if="error" class="dev-gallery__error">{{ error }}</p>
      </div>

      <nav class="dev-gallery__groups">
        <section
          v-for="grupo in grupos"
          :key="grupo.key"
          class="dev-gallery__group"
          :class="{ 'is-open': activo === grupo.key }"
        >
          <button type="button" class="dev-gallery__group-head" @click="activo = activo === grupo.key ? '' : grupo.key">
            <span class="dev-gallery__group-title">
              <CtIcon :name="grupo.icon" :size="15" />
              {{ grupo.label }}
              <span class="dev-gallery__count">{{ grupo.views.length }}</span>
            </span>
            <CtIcon name="chevronDown" :size="15" class="dev-gallery__chevron" />
          </button>

          <ul v-if="activo === grupo.key" class="dev-gallery__list">
            <li v-for="vista in grupo.views" :key="vista.path">
              <button
                type="button"
                class="dev-gallery__link"
                :class="{ 'is-current': actual === vista.path }"
                @click="ir(vista.path)"
              >
                <span class="dev-gallery__link-label">{{ vista.label }}</span>
                <span v-if="vista.desc" class="dev-gallery__link-desc">{{ vista.desc }}</span>
                <code class="dev-gallery__link-path">{{ vista.path }}</code>
              </button>
            </li>
          </ul>
        </section>
      </nav>

      <footer class="dev-gallery__foot">
        <CtIcon name="info" :size="14" />
        <span>Acceso directo a datos del modo demo. Se elimina antes del release.</span>
      </footer>
    </aside>
  </div>
</template>

<style scoped>
.dev-gallery__toggle {
  position: fixed;
  right: 20px;
  bottom: 20px;
  z-index: calc(var(--ct-z-drawer) + 1);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 16px;
  border: none;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-ink);
  color: var(--ct-text-invert);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  box-shadow: var(--ct-shadow-lg);
  cursor: pointer;
}

.dev-gallery__toggle:hover,
.dev-gallery__toggle.is-open {
  background: var(--ct-primary-strong);
}

.dev-gallery__scrim {
  position: fixed;
  inset: 0;
  z-index: var(--ct-z-drawer);
  background: var(--ct-overlay);
}

.dev-gallery__panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: calc(var(--ct-z-drawer) + 2);
  width: min(392px, 100vw);
  display: flex;
  flex-direction: column;
  background: var(--ct-surface);
  border-left: 1px solid var(--ct-border);
  box-shadow: var(--ct-shadow-lg);
}

.dev-gallery__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding: var(--ct-space-5) var(--ct-space-5) var(--ct-space-4);
  background: var(--ct-warning-soft);
  border-bottom: 1px solid var(--ct-border);
}

.dev-gallery__kicker {
  margin: 0;
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-wide);
  text-transform: uppercase;
  color: var(--ct-warning-ink);
}

.dev-gallery__title {
  margin: 2px 0 4px;
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-bold);
  color: var(--ct-text);
}

.dev-gallery__sub {
  margin: 0;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.dev-gallery__close {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
  cursor: pointer;
}

.dev-gallery__close:hover {
  border-color: var(--ct-border-strong);
  color: var(--ct-text);
}

.dev-gallery__roles {
  padding: var(--ct-space-4) var(--ct-space-5);
  border-bottom: 1px solid var(--ct-border);
}

.dev-gallery__roles-label {
  display: block;
  margin-bottom: var(--ct-space-2);
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: var(--ct-tracking-wide);
  text-transform: uppercase;
  color: var(--ct-text-muted);
}

.dev-gallery__roles-list {
  display: flex;
  gap: var(--ct-space-2);
}

.dev-gallery__role {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 7px 8px;
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  cursor: pointer;
}

.dev-gallery__role:hover:not(:disabled) {
  border-color: var(--ct-accent-border);
  background: var(--ct-accent-tint-50);
  color: var(--ct-accent-ink);
}

.dev-gallery__role.is-active {
  background: var(--ct-primary-soft);
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.dev-gallery__role:disabled {
  opacity: 0.6;
  cursor: progress;
}

.dev-gallery__error {
  margin: var(--ct-space-2) 0 0;
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger-strong);
}

.dev-gallery__groups {
  flex: 1;
  overflow-y: auto;
  padding: var(--ct-space-3) var(--ct-space-3) var(--ct-space-5);
}

.dev-gallery__group + .dev-gallery__group {
  margin-top: var(--ct-space-2);
}

.dev-gallery__group-head {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-2);
  padding: 9px 10px;
  border: none;
  border-radius: var(--ct-radius-sm);
  background: transparent;
  color: var(--ct-text);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  cursor: pointer;
}

.dev-gallery__group-head:hover {
  background: var(--ct-surface-alt);
}

.dev-gallery__group-title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.dev-gallery__count {
  padding: 1px 7px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-neutral-soft);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-2xs);
}

.dev-gallery__chevron {
  transition: transform var(--ct-transition);
}

.dev-gallery__group.is-open .dev-gallery__chevron {
  transform: rotate(180deg);
}

.dev-gallery__list {
  list-style: none;
  margin: var(--ct-space-1) 0 var(--ct-space-3);
  padding: 0 0 0 var(--ct-space-2);
  border-left: 1px solid var(--ct-border);
}

.dev-gallery__link {
  width: 100%;
  display: block;
  text-align: left;
  padding: 7px 10px;
  border: none;
  border-radius: var(--ct-radius-sm);
  background: transparent;
  cursor: pointer;
}

.dev-gallery__link:hover {
  background: var(--ct-primary-softer);
}

.dev-gallery__link.is-current {
  background: var(--ct-primary-soft);
}

.dev-gallery__link-label {
  display: block;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.dev-gallery__link.is-current .dev-gallery__link-label {
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

.dev-gallery__link.is-current:hover {
  background: var(--ct-accent-tint-50);
}

.dev-gallery__link.is-current:hover .dev-gallery__link-label {
  color: var(--ct-accent-ink);
}

.dev-gallery__link-desc {
  display: block;
  margin-top: 1px;
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
  line-height: var(--ct-lh-normal);
}

.dev-gallery__link-path {
  display: block;
  margin-top: 2px;
  font-family: var(--ct-font-mono);
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-faint);
  word-break: break-all;
}

.dev-gallery__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: var(--ct-space-3) var(--ct-space-5);
  border-top: 1px solid var(--ct-border);
  background: var(--ct-surface-sunken);
  font-size: var(--ct-fs-2xs);
  color: var(--ct-text-muted);
}

@media (max-width: 640px) {
  .dev-gallery__toggle-text {
    display: none;
  }
}
</style>
