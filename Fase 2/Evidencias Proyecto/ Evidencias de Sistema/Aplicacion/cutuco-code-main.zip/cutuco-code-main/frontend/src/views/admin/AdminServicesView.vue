<script setup>
/**
 * Administración del servicio mensual de vendedores.
 *
 * Permite ver el estado por vendedor, revisar transferencias pendientes y
 * ejecutar la sincronización de morosidad. La regla vigente está en
 * docs/servicio-plataforma.md y en la migración 20261029000000.
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtDateRange from '@/components/base/CtDateRange.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import { ESTADO_SERVICIO, ESTADO_TIENDA_SERVICIO, REGLAS_SERVICIO } from '@/lib/constants'
import { formatCLP, formatDate, formatDateTime } from '@/lib/format'
import { TASA_IVA_CHILE } from '@/lib/taxes'
import {
  actualizarMorosidadServicio,
  actualizarDatosTransferenciaCutuco,
  DATOS_TRANSFERENCIA_CUTUCO_VACIOS,
  etiquetaEstadoServicio,
  listPagosServicioAdmin,
  listServiciosAdmin,
  obtenerDatosTransferenciaCutuco,
  resolverPagoServicio,
  tonoEstadoServicio,
} from '@/services/servicio'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const cargando = ref(true)
const errorCarga = ref(null)
const servicios = ref([])
const pendientes = ref([])
const pagos = ref([])
const fechaDesde = ref('')
const fechaHasta = ref('')
const estadoFiltro = ref('')
const ventaFiltro = ref('')
const productorFiltro = ref('')
const actualizando = ref(false)
const modalRevision = ref(false)
const pagoSeleccionado = ref(null)
const observaciones = ref('')
const resolviendo = ref(false)
const datosTransferencia = ref({ ...DATOS_TRANSFERENCIA_CUTUCO_VACIOS })
const erroresDatosTransferencia = ref({})
const guardandoDatosTransferencia = ref(false)
const editandoDatosTransferencia = ref(false)

const datosTransferenciaConfigurados = computed(() =>
  ['banco', 'tipoCuenta', 'numeroCuenta', 'titular', 'rut'].every((campo) =>
    Boolean(String(datosTransferencia.value[campo] ?? '').trim()),
  ),
)

const resumen = computed(() => {
  const base = {
    [ESTADO_TIENDA_SERVICIO.AL_DIA]: 0,
    [ESTADO_TIENDA_SERVICIO.PENDIENTE]: 0,
    [ESTADO_TIENDA_SERVICIO.PENDIENTE_REVISION]: 0,
    [ESTADO_TIENDA_SERVICIO.VENCIDO]: 0,
  }
  for (const servicio of serviciosFiltrados.value) {
    if (servicio.estado in base) base[servicio.estado] += 1
  }
  return base
})

const columnas = [
  { key: 'nombre_comercial', label: 'Vendedor' },
  { key: 'estado', label: 'Estado' },
  { key: 'periodo', label: 'Período' },
  { key: 'monto', label: 'Cuota', align: 'right' },
  { key: 'vence_en', label: 'Vence' },
  { key: 'suspendido', label: 'Venta' },
  { key: 'acciones', label: 'Consulta', align: 'right' },
]

const columnasHistorial = [
  { key: 'nombre', label: 'Vendedor' },
  { key: 'periodo', label: 'Período' },
  { key: 'estado', label: 'Estado de pago' },
  { key: 'monto', label: 'Monto', align: 'right' },
  { key: 'pagado_en', label: 'Pago registrado' },
]

const columnasPendientes = [
  { key: 'nombre', label: 'Vendedor' },
  { key: 'periodo', label: 'Período' },
  { key: 'monto', label: 'Monto', align: 'right' },
  { key: 'referencia', label: 'N° operación' },
  { key: 'creado_en', label: 'Registrado' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const opcionesEstado = [
  { value: '', label: 'Todos los estados del servicio' },
  { value: ESTADO_TIENDA_SERVICIO.PENDIENTE, label: 'Pendiente' },
  { value: ESTADO_TIENDA_SERVICIO.AL_DIA, label: 'Al día' },
]
const opcionesVenta = [
  { value: '', label: 'Todas las tiendas' },
  { value: 'habilitada', label: 'Venta habilitada' },
  { value: 'suspendida', label: 'Venta suspendida' },
]
const opcionesProductor = computed(() => [
  { value: '', label: 'Todos los vendedores' },
  ...servicios.value
    .map((servicio) => ({ value: servicio.productor_id, label: servicio.nombre_comercial }))
    .sort((a, b) => a.label.localeCompare(b.label, 'es')),
])

const serviciosFiltrados = computed(() =>
  servicios.value.filter((servicio) => {
    if (estadoFiltro.value && servicio.estado !== estadoFiltro.value) return false
    if (ventaFiltro.value === 'habilitada' && servicio.suspendido) return false
    if (ventaFiltro.value === 'suspendida' && !servicio.suspendido) return false
    if (productorFiltro.value && servicio.productor_id !== productorFiltro.value) return false
    return true
  }),
)

const filas = computed(() =>
  serviciosFiltrados.value.map((s) => ({
    ...s,
    periodo: s.cuota ? formatDate(s.cuota.periodo) : '—',
    monto: s.cuota ? formatCLP(s.cuota.monto) : '—',
    vence_en: s.cuota ? formatDate(s.cuota.vence_en) : '—',
    suspendido: s.suspendido ? 'Suspendida' : 'Habilitada',
  })),
)

function nombreProductor(productorId) {
  return servicios.value.find((s) => s.productor_id === productorId)?.nombre_comercial ?? 'Vendedor'
}

const filasPendientes = computed(() =>
  pendientes.value
    .filter((p) => !productorFiltro.value || p.productor_id === productorFiltro.value)
    .map((p) => ({
    ...p,
    nombre: nombreProductor(p.productor_id),
    periodo: formatDate(p.periodo),
    monto: formatCLP(p.monto),
    referencia: p.referencia || 'Sin referencia',
    creado_en: formatDateTime(p.creado_en),
    })),
)

const pagosFiltrados = computed(() =>
  pagos.value.filter((pago) => {
    const periodo = String(pago.periodo ?? '').slice(0, 10)
    if ((fechaDesde.value && periodo < fechaDesde.value) || (fechaHasta.value && periodo > fechaHasta.value)) return false
    const servicio = servicios.value.find((item) => item.productor_id === pago.productor_id)
    if (estadoFiltro.value && servicio?.estado !== estadoFiltro.value) return false
    if (ventaFiltro.value === 'habilitada' && servicio?.suspendido) return false
    if (ventaFiltro.value === 'suspendida' && !servicio?.suspendido) return false
    if (productorFiltro.value && pago.productor_id !== productorFiltro.value) return false
    return true
  }),
)

const filasHistorial = computed(() =>
  pagosFiltrados.value.map((pago) => ({
    ...pago,
    nombre: nombreProductor(pago.productor_id),
    periodo: formatDate(pago.periodo),
    monto: formatCLP(pago.monto),
    pagado_en: pago.pagado_en ? formatDateTime(pago.pagado_en) : '—',
  })),
)

const pagosCobrados = computed(() => pagosFiltrados.value.filter((pago) => pago.estado === ESTADO_SERVICIO.PAGADO))
const cobroBruto = computed(() => pagosCobrados.value.reduce((total, pago) => total + Number(pago.monto ?? 0), 0))
const ivaCobro = computed(() => Math.round(cobroBruto.value * (TASA_IVA_CHILE / (1 + TASA_IVA_CHILE))))
const ingresoNeto = computed(() => cobroBruto.value - ivaCobro.value)

async function cargar() {
  cargando.value = true
  errorCarga.value = null
  try {
    const [estado, historial, datosBancarios] = await Promise.all([
      listServiciosAdmin(),
      listPagosServicioAdmin(),
      obtenerDatosTransferenciaCutuco(),
    ])
    servicios.value = estado
    pagos.value = historial
    pendientes.value = historial.filter((pago) => pago.estado === ESTADO_SERVICIO.PENDIENTE_REVISION)
    datosTransferencia.value = datosBancarios
  } catch (e) {
    errorCarga.value = e?.message ?? 'No se pudo cargar el servicio de los vendedores'
  } finally {
    cargando.value = false
  }
}

function validarDatosTransferencia() {
  const errores = {}
  const campos = [
    ['banco', 'Banco', 120],
    ['tipoCuenta', 'Tipo de cuenta', 80],
    ['numeroCuenta', 'Número de cuenta', 40],
    ['titular', 'Titular', 160],
    ['rut', 'RUT', 16],
  ]
  for (const [campo, etiqueta, maximo] of campos) {
    const valor = String(datosTransferencia.value[campo] ?? '').trim()
    if (!valor) errores[campo] = `${etiqueta} es obligatorio.`
    else if (valor.length > maximo) errores[campo] = `${etiqueta} no puede superar ${maximo} caracteres.`
  }
  erroresDatosTransferencia.value = errores
  return Object.keys(errores).length === 0
}

async function guardarDatosTransferencia() {
  if (!validarDatosTransferencia()) return
  guardandoDatosTransferencia.value = true
  try {
    datosTransferencia.value = await actualizarDatosTransferenciaCutuco(datosTransferencia.value)
    ui.success(
      'Datos bancarios publicados',
      'Los vendedores verán estos datos al abrir Registrar transferencia.',
    )
  } catch (e) {
    ui.error('No se pudieron guardar los datos bancarios', e?.message)
  } finally {
    guardandoDatosTransferencia.value = false
  }
}

function alternarEdicionDatosTransferencia() {
  editandoDatosTransferencia.value = !editandoDatosTransferencia.value
  if (!editandoDatosTransferencia.value) erroresDatosTransferencia.value = {}
}

async function actualizarMorosidad() {
  actualizando.value = true
  try {
    const total = await actualizarMorosidadServicio()
    await cargar()
    ui.success('Morosidad actualizada', `Se revisaron ${total} vendedores.`)
  } catch (e) {
    ui.error('No se pudo actualizar la morosidad', e.message)
  } finally {
    actualizando.value = false
  }
}

function abrirRevision(pago) {
  pagoSeleccionado.value = pago
  observaciones.value = ''
  modalRevision.value = true
}

async function resolver(estado) {
  if (!pagoSeleccionado.value) return
  resolviendo.value = true
  try {
    await resolverPagoServicio(pagoSeleccionado.value.id, estado, observaciones.value)
    modalRevision.value = false
    await cargar()
    ui.success(
      estado === 'pagado' ? 'Pago aprobado' : 'Pago rechazado',
      estado === 'pagado'
        ? 'El vendedor queda al día y su venta se reactiva.'
        : 'El vendedor deberá regularizar el pago.',
    )
  } catch (e) {
    ui.error('No se pudo resolver el pago', e.message)
  } finally {
    resolviendo.value = false
  }
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Servicio de vendedores</h1>
        <p class="page-head__subtitle">
          Cuota mensual de {{ formatCLP(REGLAS_SERVICIO.montoMensual) }}, vencimiento a los
          {{ REGLAS_SERVICIO.diasVencimiento }} días y {{ REGLAS_SERVICIO.diasGracia }} días de
          gracia antes de suspender la venta.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :loading="actualizando" @click="actualizarMorosidad">
          Actualizar morosidad
        </CtButton>
        <CtButton :loading="cargando" @click="cargar">Actualizar</CtButton>
      </div>
    </header>

    <CtAlert v-if="errorCarga" tone="danger" title="No pudimos cargar el servicio">
      <p>{{ errorCarga }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-else-if="cargando" label="Cargando servicios…" />

    <template v-else>
      <CtCard padding="md">
        <div class="servicio-admin__encabezado-seccion">
          <div>
            <h2 class="eyebrow">Datos bancarios de CuTuCo para transferencias</h2>
            <p class="text-sm text-muted">
              Esta es la cuenta que copiarán los vendedores al registrar el pago de su cuota. Completa
              los cinco campos antes de publicar cualquier dato.
            </p>
          </div>
          <div class="servicio-admin__encabezado-acciones">
            <CtBadge :tone="datosTransferenciaConfigurados ? 'success' : 'warning'" size="sm">
              {{ datosTransferenciaConfigurados ? 'Configurados' : 'Sin configurar' }}
            </CtBadge>
            <CtButton
              size="sm"
              variant="secondary"
              :aria-expanded="editandoDatosTransferencia"
              aria-controls="datos-transferencia-cutuco"
              @click="alternarEdicionDatosTransferencia"
            >
              {{
                editandoDatosTransferencia
                  ? 'Ocultar edición'
                  : datosTransferenciaConfigurados
                    ? 'Editar datos bancarios'
                    : 'Configurar datos bancarios'
              }}
            </CtButton>
          </div>
        </div>
        <p v-if="!editandoDatosTransferencia" class="servicio-admin__resumen-datos text-sm text-muted">
          <template v-if="datosTransferenciaConfigurados">
            Los datos están publicados para vendedores. Ábrelos sólo cuando necesites revisarlos o
            actualizarlos.
          </template>
          <template v-else>
            Aún no hay datos bancarios completos publicados. Abre la edición para configurarlos.
          </template>
        </p>
        <form
          v-else
          id="datos-transferencia-cutuco"
          class="servicio-admin__datos-transferencia"
          @submit.prevent="guardarDatosTransferencia"
        >
          <CtInput
            v-model="datosTransferencia.banco"
            label="Banco"
            placeholder="Ej. BancoEstado"
            autocomplete="organization"
            :error="erroresDatosTransferencia.banco"
            required
          />
          <CtInput
            v-model="datosTransferencia.tipoCuenta"
            label="Tipo de cuenta"
            placeholder="Ej. Cuenta corriente"
            :error="erroresDatosTransferencia.tipoCuenta"
            required
          />
          <CtInput
            v-model="datosTransferencia.numeroCuenta"
            label="Número de cuenta"
            inputmode="numeric"
            autocomplete="off"
            :error="erroresDatosTransferencia.numeroCuenta"
            required
          />
          <CtInput
            v-model="datosTransferencia.titular"
            label="Titular"
            placeholder="Ej. CuTuCo SpA"
            autocomplete="organization"
            :error="erroresDatosTransferencia.titular"
            required
          />
          <CtInput
            v-model="datosTransferencia.rut"
            label="RUT"
            placeholder="Ej. 76.543.210-8"
            autocomplete="off"
            :error="erroresDatosTransferencia.rut"
            required
          />
          <div class="servicio-admin__datos-acciones">
            <CtButton type="submit" :loading="guardandoDatosTransferencia">
              Guardar y publicar datos
            </CtButton>
            <p class="text-xs text-muted">Sólo administración puede modificar esta cuenta.</p>
          </div>
        </form>
      </CtCard>

      <CtCard padding="md">
        <div class="servicio-admin__filtros">
          <CtDateRange
            v-model:desde="fechaDesde"
            v-model:hasta="fechaHasta"
            label="Rango del período"
          />
          <CtSelect v-model="estadoFiltro" label="Estado del servicio" :options="opcionesEstado" />
          <CtSelect v-model="ventaFiltro" label="Venta en plataforma" :options="opcionesVenta" />
          <CtSelect v-model="productorFiltro" label="Consultar vendedor" :options="opcionesProductor" />
        </div>
        <CtButton
          v-if="fechaDesde || fechaHasta || estadoFiltro || ventaFiltro || productorFiltro"
          size="sm"
          variant="ghost"
          @click="fechaDesde = ''; fechaHasta = ''; estadoFiltro = ''; ventaFiltro = ''; productorFiltro = ''"
        >
          Limpiar filtros
        </CtButton>
      </CtCard>

      <div class="grid-kpi servicio-admin__montos">
        <CtStatCard
          label="Cantidad bruta cobrada"
          :value="formatCLP(cobroBruto)"
          icon="scale"
          tone="accent"
          hint="Pagos de servicio aprobados en el período"
        />
        <CtStatCard
          label="IVA correspondiente"
          :value="formatCLP(ivaCobro)"
          icon="scale"
          tone="warning"
          hint="IVA incluido en el cobro bruto"
        />
        <CtStatCard
          label="Ganancia neta"
          :value="formatCLP(ingresoNeto)"
          icon="check"
          tone="success"
          hint="Cobro bruto menos IVA"
        />
      </div>

      <div class="servicio-admin__kpis">
        <CtCard padding="sm">
          <p class="eyebrow">Al día</p>
          <p class="servicio-admin__numero">{{ resumen[ESTADO_TIENDA_SERVICIO.AL_DIA] }}</p>
        </CtCard>
        <CtCard padding="sm">
          <p class="eyebrow">Pendientes</p>
          <p class="servicio-admin__numero">{{ resumen[ESTADO_TIENDA_SERVICIO.PENDIENTE] }}</p>
        </CtCard>
        <CtCard padding="sm">
          <p class="eyebrow">En revisión</p>
          <p class="servicio-admin__numero">{{ resumen[ESTADO_TIENDA_SERVICIO.PENDIENTE_REVISION] }}</p>
        </CtCard>
        <CtCard padding="sm">
          <p class="eyebrow">Vencidos</p>
          <p class="servicio-admin__numero text-danger">{{ resumen[ESTADO_TIENDA_SERVICIO.VENCIDO] }}</p>
        </CtCard>
      </div>

      <CtCard padding="md">
        <h2 class="eyebrow">Transferencias pendientes de revisión</h2>
        <p class="text-sm text-muted">
          Revisa el número de operación contra el banco. Aprobar deja al vendedor al día; rechazar
          mantiene la deuda y permite un nuevo pago.
        </p>
        <CtTable
          :columns="columnasPendientes"
          :rows="filasPendientes"
          row-key="id"
          empty-message="No hay transferencias pendientes de revisión."
        >
          <template #cell-acciones="{ row }">
            <CtButton size="sm" variant="secondary" @click="abrirRevision(row)">Revisar</CtButton>
          </template>
        </CtTable>
      </CtCard>

      <CtCard padding="md">
        <h2 class="eyebrow">Estado por vendedor</h2>
        <CtTable
          :columns="columnas"
          :rows="filas"
          row-key="productor_id"
          empty-message="Aún no hay vendedores con servicio."
        >
          <template #cell-estado="{ row }">
            <CtBadge :tone="tonoEstadoServicio(row.estado)">
              {{ etiquetaEstadoServicio(row.estado) }}
            </CtBadge>
          </template>
          <template #cell-suspendido="{ row }">
            <CtBadge :tone="row.suspendido === 'Suspendida' ? 'danger' : 'success'">
              {{ row.suspendido }}
            </CtBadge>
          </template>
          <template #cell-acciones="{ row }">
            <CtButton size="sm" variant="secondary" @click="productorFiltro = row.productor_id">
              Ver detalle
            </CtButton>
          </template>
        </CtTable>
      </CtCard>

      <CtCard padding="md">
        <h2 class="eyebrow">Historial de cobros del servicio</h2>
        <p class="text-sm text-muted">
          Por defecto se muestran todos los registros. El rango de fechas usa el período cobrado.
        </p>
        <CtTable
          :columns="columnasHistorial"
          :rows="filasHistorial"
          row-key="id"
          empty-message="No hay cobros de servicio para los filtros seleccionados."
        >
          <template #cell-estado="{ row }">
            <CtBadge :tone="tonoEstadoServicio(row.estado)">{{ etiquetaEstadoServicio(row.estado) }}</CtBadge>
          </template>
        </CtTable>
      </CtCard>

      <CtEmptyState
        v-if="!servicios.length"
        icon="store"
        title="Sin vendedores"
        message="Cuando se apruebe un vendedor aparecerá aquí su servicio mensual."
      />
    </template>

    <CtModal
      v-model="modalRevision"
      title="Revisar transferencia"
      subtitle="Confirma el pago sólo si el número de operación coincide con el abono recibido."
      size="sm"
    >
      <div v-if="pagoSeleccionado" class="stack">
        <dl class="servicio-admin__detalle">
          <div>
            <dt>Vendedor</dt>
            <dd>{{ nombreProductor(pagoSeleccionado.productor_id) }}</dd>
          </div>
          <div>
            <dt>Período</dt>
            <dd>{{ formatDate(pagoSeleccionado.periodo) }}</dd>
          </div>
          <div>
            <dt>Monto</dt>
            <dd>{{ formatCLP(pagoSeleccionado.monto) }}</dd>
          </div>
          <div>
            <dt>N° de operación</dt>
            <dd class="mono">{{ pagoSeleccionado.referencia || 'Sin referencia' }}</dd>
          </div>
        </dl>
        <CtTextarea
          v-model="observaciones"
          label="Observaciones de la revisión"
          hint="Obligatorio al rechazar; útil también al aprobar."
          :rows="3"
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="modalRevision = false">Cancelar</CtButton>
        <CtButton
          variant="danger"
          :loading="resolviendo"
          :disabled="!observaciones.trim()"
          @click="resolver('rechazado')"
        >
          Rechazar
        </CtButton>
        <CtButton :loading="resolviendo" @click="resolver('pagado')">Aprobar pago</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.servicio-admin__kpis {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: var(--ct-space-3);
}
.servicio-admin__montos {
  gap: var(--ct-space-3);
}
.servicio-admin__encabezado-seccion {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-4);
}
.servicio-admin__encabezado-seccion h2,
.servicio-admin__encabezado-seccion p {
  margin-top: 0;
}
.servicio-admin__encabezado-acciones {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--ct-space-2);
}
.servicio-admin__resumen-datos {
  margin: 0;
}
.servicio-admin__datos-transferencia {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
}
.servicio-admin__datos-acciones {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
}
.servicio-admin__datos-acciones p {
  margin: 0;
}
.servicio-admin__filtros {
  display: grid;
  grid-template-columns: minmax(260px, 1.5fr) repeat(3, minmax(180px, 1fr));
  align-items: end;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-3);
}
.servicio-admin__numero {
  margin: 4px 0 0;
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
}
.servicio-admin__detalle {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
  margin: 0 0 var(--ct-space-4);
}
.servicio-admin__detalle dt {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  text-transform: uppercase;
}
.servicio-admin__detalle dd {
  margin: 2px 0 0;
  font-weight: var(--ct-fw-semibold);
}
@media (max-width: 760px) {
  .servicio-admin__kpis {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .servicio-admin__filtros {
    grid-template-columns: 1fr;
  }
  .servicio-admin__datos-transferencia {
    grid-template-columns: 1fr;
  }
  .servicio-admin__encabezado-seccion {
    align-items: stretch;
    flex-direction: column;
  }
  .servicio-admin__encabezado-acciones {
    justify-content: space-between;
  }
}
</style>
