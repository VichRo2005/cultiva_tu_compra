import { describe, expect, it, beforeEach } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { subtotalCLP } from '@/lib/pricing'
import { formatMontoCompra } from '@/lib/format'
import { calcularTotalProducto } from '@/services/catalog'
import { useCartStore } from '@/stores/cart'

beforeEach(() => { localStorage.clear(); setActivePinia(createPinia()) })
const producto = (id, productor_id, precio) => ({ id, productor_id, precio, stock: 10, unidad_medida: 'kg' })

describe('CK-0117: precisión de cantidades y subtotales', () => {
  it.each([[1, 1.005, 1.01], [1001, 0.5, 500.5], [2800, 0.5, 1400], [1, 0.004, 0]])(
    '%s CLP por %s conserva redondeo HALF_UP de backend', (precio, cantidad, esperado) => {
      expect(subtotalCLP(precio, cantidad)).toBe(esperado)
      expect(calcularTotalProducto(precio, cantidad)).toBe(esperado)
    },
  )
  it('muestra centésimas sin aparentar otro monto', () => {
    expect(formatMontoCompra(500.5)).toBe('$500,50')
    expect(formatMontoCompra(1400)).toBe('$1.400')
    expect(formatMontoCompra(NaN)).toBe('—')
  })
  it('exige subtotal entero por tienda aunque la suma global sea entera', () => {
    const cart = useCartStore()
    cart.agregar(producto('a', 'v1', 1001), 0.5)
    cart.agregar(producto('b', 'v2', 1001), 0.5)
    expect(cart.subtotal).toBe(1001)
    expect(cart.errorMontos).toContain('cada tienda')
    cart.setCantidad('a', 1)
    cart.setCantidad('b', 1)
    expect(cart.errorMontos).toBeNull()
  })
  it('permite dos líneas fraccionadas cuyo subtotal de tienda es entero', () => {
    const cart = useCartStore()
    cart.agregar(producto('a', 'v1', 1001), 0.5)
    cart.agregar(producto('b', 'v1', 1001), 0.5)
    expect(cart.errorMontos).toBeNull()
    expect(cart.total).toBe(5356)
  })
  it('sumar cantidades fraccionarias no incorpora residuos binarios (HAL-CLI-008: hasta 1 decimal)', () => {
    const cart = useCartStore()
    cart.agregar(producto('a', 'v1', 1000), 0.1)
    cart.agregar(producto('a', 'v1', 1000), 0.2)
    expect(cart.cantidadDe('a')).toBe(0.3)
    expect(cart.subtotal).toBe(300)
    cart.ajustar('a', 0.1)
    expect(cart.cantidadDe('a')).toBe(0.4)
    expect(cart.subtotal).toBe(400)
    // más de un decimal ya no se acepta en unidades fraccionables
    expect(() => cart.agregar(producto('b', 'v1', 1), 0.01)).toThrow('un decimal')
    expect(() => cart.agregar(producto('b', 'v1', 1), 0.0001)).toThrow('un decimal')
  })
})
