/**
 * CuTuCo — Registro de cuentas.
 *
 *   RF-020  registro de Cliente: nombre, apellidos, correo único, contraseña
 *           con confirmación, región y comuna. Se asigna sólo el rol Cliente.
 *   RF-021  registro de Vendedor (Productor AFC): datos personales, tienda,
 *           ubicación y datos bancarios. La cuenta queda pendiente hasta que el
 *           administrador revise los antecedentes; no se pide carnet.
 *
 * El perfil lo crea el trigger `manejar_nuevo_usuario` con rol `cliente`; un
 * visitante nunca puede auto-registrarse como vendedor ni administrador. La
 * solicitud de vendedor se guarda en `postulaciones_vendedores` y la aprobación
 * del administrador es la que crea el productor y cambia el rol (RF-004).
 */

import { mensajeSeguro } from '@/services/errores'
import { getClient } from '@/lib/supabase'
import {
  BANCOS_DISPONIBLES,
  ESTADO_POSTULACION,
  ROL_USUARIO,
  STORAGE_BUCKETS,
  TIPOS_CUENTA_BANCARIA,
} from '@/lib/constants'
import {
  LIMITES,
  emailPolicyMessage,
  isDeptoOficina,
  isEmail,
  isNombrePropio,
  isNumeroCuentaBancaria,
  isNumeroDireccion,
  isPhone,
  isReferenciaDireccion,
  isRut,
  isTitularCuenta,
  normalizarEmail,
  normalizarTelefonoChileno,
  passwordPolicyMessage,
} from '@/lib/validation'
import { createDireccion, listDirecciones, updateDireccion } from '@/services/geography'
import { guardarDatosBancarios } from '@/services/seller'

/**
 * A5 — Validación ANTES de crear registros: si un campo excede los límites de
 * la base de datos, el formulario falla aquí y no se crea la cuenta ni queda
 * ningún registro parcial (A7: "value too long for type character varying").
 */
export function validarDatosRegistro(datos = {}) {
  const errores = {}
  const campo = (clave, etiqueta, limite) => {
    const valor = datos[clave]
    if (typeof valor === 'string' && valor.length > limite) {
      errores[clave] = `El campo ${etiqueta} no puede superar ${limite} caracteres (límite del sistema).`
    }
  }
  campo('nombre', 'nombre', LIMITES.nombre)
  campo('apellido', 'apellido', LIMITES.apellido)
  campo('calle', 'dirección', LIMITES.calle)
  campo('numero', 'número / depto', LIMITES.numero)
  campo('deptoOficina', 'complemento de dirección', LIMITES.deptoOficina)
  campo('referencia', 'referencia', LIMITES.referencia)
  campo('nombreComercial', 'nombre comercial', LIMITES.nombreComercial)
  campo('descripcion', 'descripción', LIMITES.descripcion)
  return errores
}

/** ¿Hay errores de límites? Lanza el primer mensaje de campo específico. */
export function exigirDatosRegistroValidos(datos = {}) {
  const errores = validarDatosRegistro(datos)
  const primero = Object.entries(errores)[0]
  if (primero) throw new Error(primero[1])
}

/**
 * Traduce los mensajes de GoTrue y del esquema a español funcional.
 *
 * La contraseña es la única validación que el frontend no puede evaluar
 * exactamente igual que el servidor (p. ej. contraseñas filtradas), así que un
 * 400 de Auth por contraseña se muestra en español y nunca como texto técnico
 * en inglés (REG-PWD-010 / HAL-REG-011).
 */
export function traducirErrorRegistro(mensaje = '') {
  const texto = String(mensaje)
  if (/already registered|already exists|user already/i.test(texto)) {
    return 'Ese correo ya está asociado a una cuenta. Usa otro correo o inicia sesión.'
  }
  if (/password/i.test(texto)) {
    if (/(exceed|too long|longer than|at most|maximum|max\.?\s*[0-9]|more than|\b72\b)|bcrypt/i.test(texto)) {
      return `La contraseña no puede superar ${LIMITES.password} caracteres.`
    }
    if (/(at least|minimum|too short|should be at least)/i.test(texto)) {
      return `La contraseña debe tener al menos 8 caracteres y cumplir la política (mayúscula, minúscula, número y símbolo).`
    }
    return 'La contraseña no cumple la política de seguridad: 8 a 72 caracteres ASCII con mayúscula, minúscula, número y símbolo.'
  }
  if (/invalid.*email|email.*invalid|unable to validate email/i.test(texto)) {
    return 'El correo electrónico no es válido. Revisa el formato (nombre@dominio.cl) e inténtalo de nuevo.'
  }
  if (/value too long|character varying/i.test(texto)) {
    return 'Alguno de los campos excede la longitud máxima permitida. Revisa nombre, apellido y dirección.'
  }
  if (/Database error saving new user/i.test(texto)) {
    return 'No se pudo crear la cuenta en este momento. Verifica tus datos e inténtalo de nuevo; si persiste, contacta al soporte.'
  }
  if (/rate limit|too many requests/i.test(texto)) {
    return 'Se hicieron demasiados intentos seguidos. Espera unos minutos y vuelve a intentarlo.'
  }
  return mensajeSeguro(texto, 'No se pudo crear la cuenta')
}

/* ==================================================================
 * Mensajes de validación de los formularios de registro (REG-*).
 *
 * La regla vive en `lib/validation.js`; aquí sólo se traduce a mensajes en
 * español que las vistas muestran junto a cada campo. Así la vista, el
 * servicio y el indicador de contraseña usan exactamente la MISMA regla.
 * ================================================================== */

/** Recorta espacios externos y conserva los internos (REG-COM-004). */
export function normalizarNombre(valor) {
  return String(valor ?? '').trim()
}

const HTML_PELIGROSO_RE = /<\s*\/?\s*[a-z!?][^<>]*>|javascript:|data:text\/html/i

/** ¿El texto contiene etiquetas HTML, scripts o URI ejecutables? (REG-COM-008 / REG-VEN-006) */
export function contieneHtmlPeligroso(valor) {
  return HTML_PELIGROSO_RE.test(String(valor ?? ''))
}

/** Ayuda visible del teléfono, compartida por ambos formularios. */
export const TELEFONO_AYUDA =
  'Obligatorio. Móvil +56 9 1234 5678 o fijo +56 2 2345 6789; se guarda normalizado como +56...'

/** Nombre o apellido (REG-COM-001..008): obligatorio, Unicode y sin HTML. */
export function mensajeNombre(valor, etiqueta = 'El nombre') {
  const texto = normalizarNombre(valor)
  if (!texto) return `${etiqueta} es obligatorio`
  if (contieneHtmlPeligroso(texto)) {
    return `${etiqueta} no puede contener etiquetas HTML ni scripts`
  }
  if (!isNombrePropio(texto)) {
    return 'Sólo letras, espacios, apóstrofes o guiones (sin números ni símbolos)'
  }
  if (texto.length > LIMITES.nombre) {
    return `${etiqueta} no puede superar ${LIMITES.nombre} caracteres`
  }
  return null
}

/** Correo ASCII válido (REG-EMAIL-001..006). */
export function mensajeEmail(valor) {
  if (isEmail(valor)) return null
  return emailPolicyMessage(valor)
}

/** Teléfono OBLIGATORIO y chileno (REG-TEL-001..009 / HAL-REG-001). */
export function mensajeTelefono(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return 'El teléfono de contacto es obligatorio'
  if (!isPhone(texto)) {
    return 'Teléfono chileno no válido. Usa +56 9 1234 5678 (móvil) o +56 2 2345 6789 (fijo)'
  }
  return null
}

/** Contraseña fuerte 8-72 ASCII (REG-PWD-001..010). */
export function mensajePassword(valor) {
  return passwordPolicyMessage(valor)
}

/** Confirmación de contraseña (REG-PWD-011). */
export function mensajeConfirmacion(password, confirmacion) {
  if (!String(confirmacion ?? '').length) return 'Confirma tu contraseña'
  if (String(password ?? '') !== String(confirmacion ?? '')) return 'Las contraseñas no coinciden'
  return null
}

/** Calle o dirección: obligatoria, admite acentos, números y signos (REG-CLI-007..009). */
export function mensajeCalle(valor, etiqueta = 'La dirección') {
  const texto = String(valor ?? '').trim()
  if (!texto) return `${etiqueta} es obligatoria`
  if (texto.length > LIMITES.calle) {
    return `${etiqueta} no puede superar ${LIMITES.calle} caracteres`
  }
  if (contieneHtmlPeligroso(texto)) {
    return `${etiqueta} no puede contener etiquetas HTML ni scripts`
  }
  return null
}

/** Número opcional y alfanumérico, conforme a la migración 20261101010000. */
export function mensajeNumeroDireccion(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return null
  if (!isNumeroDireccion(texto)) {
    return `El número de domicilio debe ser alfanumérico y no superar ${LIMITES.numero} caracteres`
  }
  return null
}

/** Complemento (depto, oficina, parcela, local): opcional (REG-CLI-012 / REG-VEN-009). */
export function mensajeDeptoOficina(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return null
  if (!isDeptoOficina(texto)) {
    return `El complemento debe tener letras o números y no superar ${LIMITES.deptoOficina} caracteres`
  }
  return null
}

/** Referencia de entrega: opcional (REG-CLI-013). */
export function mensajeReferencia(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return null
  if (!isReferenciaDireccion(texto)) {
    return `La referencia debe tener al menos una letra o número y no superar ${LIMITES.referencia} caracteres`
  }
  return null
}

/** Nombre comercial de la tienda (REG-VEN-001/003). */
export function mensajeNombreComercial(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return 'Ingresa el nombre de tu tienda'
  if (contieneHtmlPeligroso(texto)) {
    return 'El nombre comercial no puede contener etiquetas HTML ni scripts'
  }
  if (texto.length > LIMITES.nombreComercial) {
    return `El nombre comercial no puede superar ${LIMITES.nombreComercial} caracteres`
  }
  return null
}

/** Descripción de la actividad: máximo 2000 y sin HTML (REG-VEN-004..006). */
export function mensajeDescripcion(valor) {
  const texto = String(valor ?? '')
  if (texto.length > LIMITES.descripcion) {
    return `La descripción no puede superar ${LIMITES.descripcion} caracteres`
  }
  if (contieneHtmlPeligroso(texto)) {
    return 'La descripción no puede contener etiquetas HTML ni scripts'
  }
  return null
}

/** RUT del solicitante/titular: formato y dígito verificador (REG-VEN-012..014). */
export function mensajeRut(valor, etiqueta = 'El RUT') {
  const texto = String(valor ?? '').trim()
  if (!texto) return `${etiqueta} es obligatorio`
  // Se acepta el RUT con o sin puntos/guion y con K minúscula: se normaliza
  // antes de validar y se guarda en el formato único del esquema.
  if (!isRut(formatearRut(texto))) {
    return 'RUT inválido: revisa el formato (12.345.678-9) y el dígito verificador'
  }
  return null
}

/**
 * Formatea un RUT al formato visible único `12.345.678-9` (REG-VEN-013).
 * Acepta entradas con o sin puntos, con o sin guion y con K minúscula. Si el
 * valor no tiene forma de RUT, lo devuelve recortado sin inventar dígitos.
 */
export function formatearRut(valor) {
  const limpio = String(valor ?? '')
    .trim()
    .replace(/[\s.]/g, '')
    .toUpperCase()
  if (!/^\d{1,8}-?[\dK]$/.test(limpio)) return String(valor ?? '').trim()
  const sinGuion = limpio.replace('-', '')
  const cuerpo = sinGuion.slice(0, -1)
  const dv = sinGuion.slice(-1)
  return `${cuerpo.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}-${dv}`
}

/** Número de cuenta: sólo dígitos, 7 a 12, conservado como texto (REG-PAG-007..013). */
export function mensajeNumeroCuenta(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return 'Ingresa el número de cuenta'
  if (!/^\d+$/.test(texto)) {
    return 'El número de cuenta sólo puede tener dígitos (sin espacios, puntos, guiones ni letras)'
  }
  if (!isNumeroCuentaBancaria(texto)) return 'El número de cuenta debe tener entre 7 y 12 dígitos'
  return null
}

/** Titular de la cuenta: obligatorio, con letras (REG-PAG-014/015). */
export function mensajeTitular(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return 'Ingresa el nombre o razón social del titular'
  if (texto.length < 3) return 'El nombre del titular debe tener al menos 3 caracteres'
  if (!isTitularCuenta(texto)) return 'El titular debe incluir letras y no superar 160 caracteres'
  return null
}

/**
 * REG-PAG-016 / HAL-REG-008 — Titular sugerido a partir del nombre y apellido:
 * SIEMPRE el nombre completo, nunca una inicial ni un valor parcial.
 */
export function sugerirTitularCuenta(nombre, apellido) {
  return [normalizarNombre(nombre), normalizarNombre(apellido)].filter(Boolean).join(' ')
}

/** Normaliza un texto para comparar nombres: sin tildes, minúsculas y sin signos. */
function normalizarComparacion(valor) {
  return String(valor ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function clavesDeNombre(valor) {
  return normalizarComparacion(valor).split(' ').filter(Boolean).sort().join(' ')
}

/**
 * Prohibición de cuentas de terceros (REG-PAG-021 / HAL-REG-014).
 *
 * Sólo se cruza con los datos disponibles en el formulario: para persona
 * natural, el titular y el RUT bancario deben coincidir con el postulante; para
 * persona jurídica, el RUT bancario debe ser el de la empresa postulante. La
 * razón social no se captura en este formulario, así que ese cruce (certificado
 * bancario vs. empresa) queda en el backend. Si faltan datos, no se inventa una
 * regla: devuelve null y la revisión sigue en el servidor.
 *
 * @returns {{campo: string, mensaje: string}|null}
 */
export function validarCuentaDeTerceros({
  tipoPersona,
  titular,
  rutTitular,
  nombre,
  apellido,
  rutSolicitante,
} = {}) {
  const rutPostulante = normalizarRut(rutSolicitante)
  const rutBanco = normalizarRut(rutTitular)
  if (!rutPostulante || !rutBanco) return null

  if (tipoPersona === 'natural') {
    if (rutPostulante !== rutBanco) {
      return {
        campo: 'rutTitular',
        mensaje:
          'La cuenta debe estar a nombre del postulante: el RUT del titular no coincide con tu RUT.',
      }
    }
    const nombrePostulante = clavesDeNombre(`${nombre ?? ''} ${apellido ?? ''}`)
    const nombreTitular = clavesDeNombre(titular)
    if (nombrePostulante && nombreTitular && nombrePostulante !== nombreTitular) {
      return {
        campo: 'titular',
        mensaje:
          'La cuenta debe estar a nombre del postulante: el titular no coincide con tu nombre completo.',
      }
    }
    return null
  }

  if (tipoPersona === 'juridica') {
    if (rutPostulante !== rutBanco) {
      return {
        campo: 'rutTitular',
        mensaje:
          'La cuenta debe estar a nombre de la empresa: el RUT del titular no coincide con el RUT de la empresa postulante.',
      }
    }
    return null
  }

  return null
}

/** Mensaje (o null) de la regla de cuentas de terceros. */
export function mensajeCuentaDeTerceros(datos = {}) {
  return validarCuentaDeTerceros(datos)?.mensaje ?? null
}

/** Documentos que el trigger de la postulación exige (nombres de campo del formulario). */
export const DOCUMENTOS_POSTULANTE = Object.freeze({
  documentoIdentidad: 'documento de identidad',
  certificadoActividadesOCarnet: 'certificado de inicio de actividades (o cédula del representante)',
  certificadoTitularidad: 'certificado de titularidad bancaria',
  comprobanteDomicilio: 'comprobante de domicilio',
})

const lanzarPrimerError = (errores = {}) => {
  const primero = Object.values(errores)[0]
  if (primero) throw new Error(primero)
}

/**
 * Validación COMPLETA del registro de Cliente, ejecutada antes de llamar a
 * GoTrue: nombres (Unicode, sin HTML), correo ASCII, contraseña fuerte, teléfono
 * chileno obligatorio y dirección con número opcional (REG-COM, REG-EMAIL,
 * REG-TEL, REG-PWD, REG-CLI).
 * @returns {Record<string, string>} errores por campo (vacío si todo es válido)
 */
export function validarRegistroCliente(datos = {}) {
  const errores = { ...validarDatosRegistro(datos) }
  const asignar = (clave, mensaje) => {
    if (mensaje) errores[clave] = mensaje
  }
  asignar('nombre', mensajeNombre(datos.nombre, 'El nombre'))
  asignar('apellido', mensajeNombre(datos.apellido, 'El apellido'))
  asignar('email', mensajeEmail(datos.email))
  asignar('password', mensajePassword(datos.password))
  asignar('telefono', mensajeTelefono(datos.telefono))
  asignar('calle', mensajeCalle(datos.calle, 'La dirección de entrega'))
  asignar('numero', mensajeNumeroDireccion(datos.numero))
  asignar('deptoOficina', mensajeDeptoOficina(datos.deptoOficina))
  asignar('referencia', mensajeReferencia(datos.referencia))
  if (!datos.regionId) errores.regionId = 'Selecciona tu región'
  if (!datos.comunaId) errores.comunaId = 'Selecciona tu comuna'
  return errores
}

/** Igual que `validarRegistroCliente`, pero lanza el primer mensaje encontrado. */
export function exigirRegistroClienteValido(datos = {}) {
  lanzarPrimerError(validarRegistroCliente(datos))
}

/**
 * Validación COMPLETA del registro de Vendedor antes de llamar a GoTrue:
 * datos personales, tienda (nombre/descripción sin HTML y con límites), RUT con
 * dígito verificador, los cuatro documentos y los datos bancarios obligatorios
 * (REG-VEN, REG-DOC y REG-PAG).
 */
export function validarRegistroVendedor(datos = {}) {
  const errores = { ...validarDatosRegistro(datos) }
  const asignar = (clave, mensaje) => {
    if (mensaje) errores[clave] = mensaje
  }
  asignar('nombre', mensajeNombre(datos.nombre, 'El nombre'))
  asignar('apellido', mensajeNombre(datos.apellido, 'El apellido'))
  asignar('email', mensajeEmail(datos.email))
  asignar('password', mensajePassword(datos.password))
  asignar('telefono', mensajeTelefono(datos.telefono))
  asignar('nombreComercial', mensajeNombreComercial(datos.nombreComercial))
  asignar('descripcion', mensajeDescripcion(datos.descripcion))
  if (!datos.regionId) errores.regionId = 'Selecciona la región de tu tienda'
  if (!datos.comunaId) errores.comunaId = 'Selecciona la comuna de tu tienda'
  asignar('calle', mensajeCalle(datos.calle, 'La dirección comercial'))
  asignar('numero', mensajeNumeroDireccion(datos.numero))
  asignar('deptoOficina', mensajeDeptoOficina(datos.deptoOficina))
  asignar('referencia', mensajeReferencia(datos.referencia))
  if (!['natural', 'juridica'].includes(datos.tipoPersona)) {
    errores.tipoPersona = 'Selecciona el tipo de persona'
  }
  asignar('rutSolicitante', mensajeRut(datos.rutSolicitante, 'El RUT del solicitante'))
  const banco = datos.datosBancarios ?? {}
  if (!banco.banco) errores.banco = 'Selecciona el banco'
  else if (!BANCOS_DISPONIBLES.includes(banco.banco)) {
    errores.banco = 'Selecciona un banco del catálogo'
  }
  if (!banco.tipoCuenta) errores.tipoCuenta = 'Selecciona el tipo de cuenta'
  else if (!TIPOS_CUENTA_BANCARIA.some((t) => t.value === banco.tipoCuenta)) {
    errores.tipoCuenta = 'Selecciona un tipo de cuenta válido'
  }
  asignar('numeroCuenta', mensajeNumeroCuenta(banco.numeroCuenta))
  asignar('titular', mensajeTitular(banco.titular))
  asignar('rutTitular', mensajeRut(banco.rutTitular, 'El RUT del titular'))
  const tercero = validarCuentaDeTerceros({
    tipoPersona: datos.tipoPersona,
    titular: banco.titular,
    rutTitular: banco.rutTitular,
    nombre: datos.nombre,
    apellido: datos.apellido,
    rutSolicitante: datos.rutSolicitante,
  })
  if (tercero) errores[tercero.campo] = tercero.mensaje

  for (const [clave, etiqueta] of Object.entries(DOCUMENTOS_POSTULANTE)) {
    const archivo = datos.documentos?.[clave]
    if (!archivo) {
      errores[clave] = `Adjunta: ${etiqueta}`
      continue
    }
    const rechazo = validarDocumentoPostulante(archivo)
    if (rechazo) errores[clave] = rechazo
  }

  return errores
}

/** Igual que `validarRegistroVendedor`, pero lanza el primer mensaje encontrado. */
export function exigirRegistroVendedorValido(datos = {}) {
  lanzarPrimerError(validarRegistroVendedor(datos))
}

/**
 * Crea la cuenta de Cliente y su dirección principal.
 * @returns {Promise<{userId: string|null, requiereConfirmacion: boolean}>}
 */
export async function registrarCliente({
  nombre,
  apellido,
  email,
  password,
  regionId,
  comunaId,
  calle,
  numero = null,
  deptoOficina = null,
  referencia = null,
  telefono = null,
}) {
  const client = getClient()
  const correo = normalizarEmail(email)
  const nombreLimpio = normalizarNombre(nombre)
  const apellidoLimpio = normalizarNombre(apellido)
  const calleLimpia = String(calle ?? '').trim()
  const numeroLimpio = String(numero ?? '').trim()
  const deptoLimpio = String(deptoOficina ?? '').trim()
  const referenciaLimpia = String(referencia ?? '').trim()
  // A6 / REG-TEL: el teléfono es obligatorio y se normaliza a +56XXXXXXXXX.
  const telefonoCanonico = normalizarTelefonoChileno(telefono)

  exigirRegistroClienteValido({
    nombre: nombreLimpio,
    apellido: apellidoLimpio,
    email,
    password,
    regionId,
    comunaId,
    calle: calleLimpia,
    numero: numeroLimpio,
    deptoOficina: deptoLimpio,
    referencia: referenciaLimpia,
    telefono,
  })

  const { data, error } = await client.auth.signUp({
    email: correo,
    password,
    options: {
      data: {
        nombre: nombreLimpio,
        apellido: apellidoLimpio || null,
        telefono: telefonoCanonico,
        // El esquema asigna siempre el rol Cliente en el registro público.
        rol: ROL_USUARIO.CLIENTE,
        /*
         * REG-CLI-017 / REG-CONF-001 — Con la confirmación de correo activa,
         * `signUp` no devuelve sesión y el frontend no puede escribir el perfil
         * ni la dirección. Estos metadatos viajan en `raw_user_meta_data` para
         * que el trigger `manejar_nuevo_usuario` cree perfil y dirección al
         * confirmarse la cuenta. No se usa service_role en el frontend.
         */
        tipo_registro: 'cliente',
        region_id: regionId,
        comuna_id: comunaId,
        calle: calleLimpia,
        numero: numeroLimpio || null,
        depto_oficina: deptoLimpio || null,
        referencia: referenciaLimpia || null,
      },
    },
  })
  if (error) throw new Error(traducirErrorRegistro(error.message))

  const userId = data?.user?.id ?? null
  const requiereConfirmacion = !data?.session

  /**
   * A5 — Pasos posteriores al alta tolerantes: la cuenta YA existe en GoTrue,
   * así que un fallo al guardar el teléfono o la dirección no debe dejar al
   * usuario atrapado con un error genérico ni reintentos que dupliquen datos.
   * Se informa con precisión qué quedó pendiente y se completa desde
   * "Mi Perfil" o "Mis Direcciones".
   */
  const advertencias = []
  if (userId && data?.session) {
    if (telefonoCanonico) {
      try {
        await guardarTelefonoPerfil({ perfilId: userId, telefono: telefonoCanonico })
      } catch {
        advertencias.push(
          'Tu cuenta ya está creada, pero el teléfono no se guardó. Actualízalo en "Mi Perfil".',
        )
      }
    }
    try {
      await guardarDireccionPrincipal({
        perfilId: userId,
        regionId,
        comunaId,
        calle: calleLimpia,
        numero: numeroLimpio || null,
        deptoOficina: deptoLimpio || null,
        referencia: referenciaLimpia || null,
      })
    } catch {
      advertencias.push(
        'Tu cuenta ya está creada, pero la dirección no se guardó. Agrégala en "Mis Direcciones".',
      )
    }
  }

  return { userId, requiereConfirmacion, email: correo, advertencias }
}

/**
 * Crea la cuenta de Vendedor en estado pendiente y registra su postulación.
 * El perfil nace como `cliente` (regla del esquema) y la postulación es la que
 * habilita la aprobación del administrador (RF-021). La postulación nace como
 * `borrador` y, con los 4 documentos subidos, pasa a `en_revision`.
 * Los datos bancarios se guardan cifrados para la identificación del comercio
 * en Transbank (Webpay Mall; RF-014).
 */
export async function registrarVendedor({
  nombre,
  apellido,
  email,
  password,
  telefono = null,
  nombreComercial,
  descripcion = null,
  regionId,
  comunaId,
  calle,
  numero = null,
  deptoOficina = null,
  referencia = null,
  datosBancarios = null,
  rutSolicitante = null,
  tipoPersona = null,
  documentos = null,
}) {
  const client = getClient()
  const correo = normalizarEmail(email)
  const nombreLimpio = normalizarNombre(nombre)
  const apellidoLimpio = normalizarNombre(apellido)
  const nombreComercialLimpio = normalizarNombre(nombreComercial)
  const descripcionLimpia = String(descripcion ?? '').trim()
  const calleLimpia = String(calle ?? '').trim()
  const numeroLimpio = String(numero ?? '').trim()
  const deptoLimpio = String(deptoOficina ?? '').trim()
  const referenciaLimpia = String(referencia ?? '').trim()
  const rutLimpio = normalizarRut(rutSolicitante)
  // A6 / REG-TEL: el teléfono es obligatorio y se normaliza a +56XXXXXXXXX.
  const telefonoCanonico = normalizarTelefonoChileno(telefono)
  // REG-PAG-012/013: la cuenta se conserva como texto (nunca como número) para
  // no perder ceros iniciales, y así viaja al endpoint de FastAPI.
  const bancoLimpio = datosBancarios
    ? {
        banco: String(datosBancarios.banco ?? '').trim(),
        tipoCuenta: String(datosBancarios.tipoCuenta ?? '').trim(),
        numeroCuenta: String(datosBancarios.numeroCuenta ?? '').trim(),
        titular: normalizarNombre(datosBancarios.titular),
        rutTitular: normalizarRut(datosBancarios.rutTitular),
      }
    : null

  exigirRegistroVendedorValido({
    nombre: nombreLimpio,
    apellido: apellidoLimpio,
    email,
    password,
    telefono,
    nombreComercial: nombreComercialLimpio,
    descripcion: descripcionLimpia,
    regionId,
    comunaId,
    calle: calleLimpia,
    numero: numeroLimpio,
    deptoOficina: deptoLimpio,
    referencia: referenciaLimpia,
    tipoPersona,
    rutSolicitante: rutLimpio,
    datosBancarios: bancoLimpio,
    documentos,
  })

  const { data, error } = await client.auth.signUp({
    email: correo,
    password,
    options: {
      data: {
        nombre: nombreLimpio,
        apellido: apellidoLimpio || null,
        telefono: telefonoCanonico,
        rol: ROL_USUARIO.CLIENTE,
        /*
         * REG-CONF-001 — Los metadatos permiten al trigger
         * `manejar_nuevo_usuario` crear perfil (con teléfono), dirección y la
         * postulación en borrador cuando el correo se confirma y todavía no hay
         * sesión. El frontend nunca usa service_role.
         */
        tipo_registro: 'vendedor',
        region_id: regionId,
        comuna_id: comunaId,
        calle: calleLimpia,
        numero: numeroLimpio || null,
        depto_oficina: deptoLimpio || null,
        referencia: referenciaLimpia || null,
        nombre_comercial: nombreComercialLimpio,
        descripcion: descripcionLimpia || null,
        rut_solicitante: rutLimpio || null,
        tipo_persona: tipoPersona,
      },
    },
  })
  if (error) throw new Error(traducirErrorRegistro(error.message))

  const userId = data?.user?.id ?? null
  const requiereConfirmacion = !data?.session
  if (!userId) return { userId: null, requiereConfirmacion, email: correo }

  /**
   * A5 — Con la sesión recién creada cada paso se registra por separado y un
   * fallo tardío NO se propaga como error fatal: la cuenta existe y el
   * solicitante puede completar la postulación, los documentos y los datos
   * bancarios desde /mi-postulacion sin duplicados (la postulación es UNA fila
   * y los documentos se suben con upsert por perfil).
   */
  const advertencias = []
  if (data?.session) {
    if (telefonoCanonico) {
      try {
        await guardarTelefonoPerfil({ perfilId: userId, telefono: telefonoCanonico })
      } catch {
        advertencias.push('El teléfono no se guardó; actualízalo después en "Mi Perfil".')
      }
    }
    try {
      await guardarDireccionPrincipal({
        perfilId: userId,
        regionId,
        comunaId,
        calle: calleLimpia,
        numero: numeroLimpio || null,
        deptoOficina: deptoLimpio || null,
        referencia: referenciaLimpia || null,
      })
    } catch {
      advertencias.push(
        'La dirección no se guardó: regístrala en "Mis Direcciones" (es requisito para aprobar tu cuenta).',
      )
    }
    try {
      const postulacion = await crearPostulacion({
        perfilId: userId,
        nombreComercial: nombreComercialLimpio,
        descripcion: descripcionLimpia,
        rutSolicitante: rutLimpio,
        tipoPersona,
      })
      // Si llegan los documentos, se suben y la postulación pasa a `en_revision`.
      if (postulacion?.id && documentos?.documentoIdentidad) {
        await enviarPostulacion({
          perfilId: userId,
          postulacionId: postulacion.id,
          documentos,
        })
      }
    } catch (e) {
      // La postulación se crea desde /mi-postulacion con estos mismos datos.
      // El formato del borrador local no cambia (REG-NAV-003).
      guardarBorradorLocal({
        nombreComercial: nombreComercialLimpio,
        descripcion: descripcionLimpia,
        rutSolicitante: rutLimpio,
        tipoPersona,
        email: correo,
        guardadoEn: new Date().toISOString(),
      })
      advertencias.push(
        `Tu cuenta quedó creada, pero la postulación no se pudo enviar (${mensajeSeguro(e)}). Continúala en "Mi Postulación": los datos ya están guardados.`,
      )
    }
    if (bancoLimpio?.numeroCuenta) {
      try {
        // `perfil_id` no viaja: FastAPI lo deriva del JWT de la sesión recién creada.
        await guardarDatosBancarios(bancoLimpio)
      } catch (e) {
        // REG-PAG-025: el error del endpoint se muestra tal cual (en español),
        // sin ocultarlo detrás de un mensaje genérico.
        advertencias.push(
          `Los datos bancarios no se guardaron: ${mensajeSeguro(e)}. Regístralos desde "Mi Postulación" o tu perfil de tienda (requisito para recibir pagos).`,
        )
      }
    }
  }

  return { userId, requiereConfirmacion, email: correo, rol: ROL_USUARIO.CLIENTE, advertencias }
}

/**
 * Copia el teléfono a `perfiles`.
 *
 * El trigger `manejar_nuevo_usuario` sólo lee `nombre` y `apellido` de
 * `raw_user_meta_data`, así que el teléfono que se pide en el registro no llega
 * solo al perfil. La RLS `perfiles_update_propio_admin` y el trigger
 * `validar_cambios_seguridad_perfil` permiten que cada usuario actualice su
 * propio teléfono.
 */
export async function guardarTelefonoPerfil({ perfilId, telefono }) {
  const limpio = String(telefono ?? '').trim()
  if (!perfilId || !limpio) return null
  const client = getClient()
  const { data, error } = await client
    .from('perfiles')
    .update({ telefono: limpio })
    .eq('id', perfilId)
    .select()
    .single()
  if (error) throw new Error(mensajeSeguro(error))
  return data
}

/** Normaliza un RUT al formato del esquema: `12345678-9` (sin puntos ni espacios). */
export function normalizarRut(rut) {
  const limpio = String(rut ?? '')
    .trim()
    .toUpperCase()
    .replace(/[\s.]/g, '')
    .replace(/-/g, '')
  if (!/^\d{1,8}[\dK]$/.test(limpio)) return ''
  return `${limpio.slice(0, -1)}-${limpio.slice(-1)}`
}

/** Mensajes del trigger `validar_postulacion_estado` convertidos a lenguaje claro. */
function traducirErrorPostulacion(mensaje = '') {
  const texto = String(mensaje).replace(/^.*?ERROR:\s*/i, '').replace(/CONTEXT:.*$/s, '').trim()
  if (texto.includes('maximo de 3 postulaciones')) {
    return 'Alcanzaste el máximo de 3 postulaciones permitidas. Si tienes dudas, escríbenos por el canal de soporte.'
  }
  if (texto.includes('Complete RUT, tipo de persona y los cuatro documentos')) {
    return 'Para enviar la solicitud debes completar tu RUT, el tipo de persona y adjuntar los cuatro documentos requeridos.'
  }
  if (texto.includes('Debe reutilizar su postulacion anterior')) {
    return 'Ya tienes una postulación en curso: edita tu solicitud anterior en lugar de crear una nueva.'
  }
  if (texto.includes('Documento fuera de la carpeta del solicitante')) {
    return 'Uno de los documentos no se subió correctamente. Vuelve a adjuntarlo e inténtalo otra vez.'
  }
  if (texto.includes('Solo una cuenta cliente activa puede postular')) {
    return 'Tu cuenta no puede postular en este momento. Contacta al administrador.'
  }
  return mensajeSeguro(texto, 'No se pudo procesar la postulación')
}

/**
 * Registra la postulación de vendedor como BORRADOR (migración
 * 20261010020000): el INSERT sólo acepta `estado='borrador'`, `intento=1` y sin
 * campos de revisión; guarda el RUT del solicitante y el tipo de persona.
 * RLS `postulaciones_insert_borrador` exige que el perfil solicitante sea
 * `cliente` activo y que no exista otra postulación abierta.
 */
export async function crearPostulacion({
  perfilId,
  nombreComercial,
  descripcion = null,
  rutSolicitante = null,
  tipoPersona = null,
}) {
  const client = getClient()
  const rut = normalizarRut(rutSolicitante)
  const tipo = ['natural', 'juridica'].includes(tipoPersona) ? tipoPersona : null
  const { data, error } = await client
    .from('postulaciones_vendedores')
    .insert({
      perfil_id: perfilId,
      nombre_comercial_solicitado: nombreComercial?.trim(),
      descripcion: descripcion?.trim() ? descripcion.trim() : null,
      rut_solicitante: rut || null,
      tipo_de_persona: tipo,
      estado: ESTADO_POSTULACION.BORRADOR,
    })
    .select()
    .single()
  if (error) throw new Error(traducirErrorPostulacion(error.message))
  return data
}

/**
 * Sube los cuatro documentos requeridos y envía la postulación a `en_revision`.
 *
 * Ruta exacta que valida `private.ruta_documento_valida`:
 *   `vendedor-documentos/{perfil_id}/{archivo}.{pdf|jpg|jpeg|png}`
 * (en Storage el `name` es `{perfil_id}/{archivo}.ext` dentro del bucket
 * `vendedor-documentos`; en la tabla se guarda la ruta completa con el prefijo
 * del bucket).
 *
 * El UPDATE va en UNA sola escritura con las 4 rutas de documentos y el estado
 * `en_revision`, porque el trigger `validar_postulacion_estado` exige RUT,
 * tipo de persona y los 4 documentos completos al enviar.
 */
export async function enviarPostulacion({
  perfilId,
  postulacionId,
  documentos = {},
}) {
  const client = getClient()
  const bucket = STORAGE_BUCKETS.documentosPostulante

  const archivos = [
    ['documentoIdentidad', 'documento_identidad', 'documento-identidad'],
    ['certificadoActividadesOCarnet', 'certificado_inicio_actividades_o_carnet_representante', 'certificado-inicio-actividades'],
    ['certificadoTitularidad', 'certificado_titularidad_bancaria', 'certificado-titularidad'],
    ['comprobanteDomicilio', 'comprobante_domicilio', 'comprobante-domicilio'],
  ]

  const rutas = {}
  const subidos = [] // rutas ya subidas, para limpiar si el UPDATE falla (REG-DOC-017)

  for (const [clave, columna, base] of archivos) {
    const file = documentos[clave]
    if (!file) {
      // REG-DOC-017: limpiar lo ya subido antes de fallar.
      await limpiarDocumentosSubidos(Object.values(subidos))
      throw new Error('Faltan documentos: adjunta los cuatro archivos requeridos antes de enviar.')
    }
    const rechazo = validarDocumentoPostulante(file)
    if (rechazo) {
      await limpiarDocumentosSubidos(Object.values(subidos))
      throw new Error(rechazo)
    }
    const ext = (file.name?.split('.').pop() ?? file.type?.split('/').pop() ?? 'pdf')
      .toLowerCase()
      .replace('jpeg', 'jpeg')
    const nombreObjeto = `${perfilId}/${base}.${ext}`
    const { error: upError } = await client.storage.from(bucket).upload(nombreObjeto, file, {
      contentType: file.type || undefined,
      upsert: true,
    })
    if (upError) {
      await limpiarDocumentosSubidos(Object.values(subidos))
      throw new Error(`No se pudo subir ${base}: ${upError.message}`)
    }
    const rutaCompleta = `${bucket}/${nombreObjeto}`
    rutas[columna] = rutaCompleta
    subidos.push(rutaCompleta)
  }

  // Un único UPDATE con todas las rutas y el estado: el trigger valida todo junto.
  const { data, error } = await client
    .from('postulaciones_vendedores')
    .update({ ...rutas, estado: ESTADO_POSTULACION.EN_REVISION })
    .eq('id', postulacionId)
    .select()
    .single()
  if (error) {
    // REG-DOC-017: si el UPDATE falla, borrar los documentos ya subidos.
    await limpiarDocumentosSubidos(Object.values(subidos))
    throw new Error(traducirErrorPostulacion(error.message))
  }
  return data
}

/**
 * Guarda la dirección principal del usuario. El esquema exige que un vendedor
 * conserve exactamente una dirección activa, por eso se reutiliza la principal
 * existente antes de crear una nueva. La región se deduce de la comuna.
 *
 * `numero` y `depto_oficina` son OPCIONALES (REG-CLI-010..012 / REG-VEN-008/009);
 * `depto_oficina` viaja como campo propio de `direcciones` y nunca se mezcla con
 * la calle ni con la referencia.
 */
export async function guardarDireccionPrincipal({
  perfilId,
  comunaId,
  calle,
  numero = null,
  deptoOficina = null,
  referencia = null,
}) {
  const calleLimpia = String(calle ?? '').trim()
  const numeroLimpio = String(numero ?? '').trim() || null
  const deptoLimpio = String(deptoOficina ?? '').trim() || null
  const referenciaLimpia = String(referencia ?? '').trim() || null

  const existentes = await listDirecciones({ perfilId })
  const principal = existentes.find((d) => d.es_principal)
  const mismaDireccion =
    principal?.comuna_id === comunaId &&
    principal?.calle === calleLimpia &&
    (principal?.numero ?? null) === numeroLimpio &&
    (principal?.depto_oficina ?? null) === deptoLimpio &&
    (principal?.referencia ?? null) === referenciaLimpia
  if (mismaDireccion) return principal

  if (principal) {
    await updateDireccion(principal.id, {
      comuna_id: comunaId,
      calle: calleLimpia,
      numero: numeroLimpio,
      depto_oficina: deptoLimpio,
      referencia: referenciaLimpia,
    })
    return principal
  }
  return createDireccion({
    perfilId,
    etiqueta: 'Principal',
    comunaId,
    calle: calleLimpia,
    numero: numeroLimpio,
    deptoOficina: deptoLimpio,
    referencia: referenciaLimpia,
    esPrincipal: existentes.length === 0,
  })
}

/* ==================================================================
 * Postulación del propio usuario (borrador / rechazada): completar,
 * reemplazar documentos y reenviar (RF-021, migración 20261010020000).
 * ================================================================== */

/** Estados que el solicitante puede seguir editando. */
export function postulacionEditable(postulacion) {
  return Boolean(postulacion) && ['borrador', ESTADO_POSTULACION.RECHAZADA].includes(postulacion.estado)
}

/** Postulación propia (RLS `postulaciones_select_propia`). */
export async function obtenerMiPostulacion() {
  const client = getClient()
  const { data } = await client.auth.getUser()
  const perfilId = data?.user?.id
  if (!perfilId) return null
  const { data: postulacion } = await client
    .from('postulaciones_vendedores')
    .select('*')
    .eq('perfil_id', perfilId)
    .order('creado_en', { ascending: false })
    .limit(1)
    .maybeSingle()
  return postulacion ?? null
}

/** Historial íntegro de revisiones de la postulación propia (§6.2). */
export async function listarMisRevisiones(postulacionId) {
  if (!postulacionId) return []
  const client = getClient()
  const { data, error } = await client
    .from('postulaciones_revisiones')
    .select('id, postulacion_id, intento, estado, observaciones_admin, revisado_en')
    .eq('postulacion_id', postulacionId)
    .order('intento', { ascending: true })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/**
 * Guarda los datos editables del borrador o de la rechazada. El trigger de BD
 * impide tocar id/perfil/intento y la RLS sólo permite UPDATE en
 * borrador/rechazada; en_revision falla con mensaje traducido.
 */
export async function actualizarPostulacion(
  postulacionId,
  { nombreComercial, descripcion, rutSolicitante, tipoPersona },
) {
  const client = getClient()
  const rut = normalizarRut(rutSolicitante)
  const tipo = ['natural', 'juridica'].includes(tipoPersona) ? tipoPersona : null
  const { data, error } = await client
    .from('postulaciones_vendedores')
    .update({
      nombre_comercial_solicitado: nombreComercial?.trim(),
      descripcion: descripcion?.trim() ? descripcion.trim() : null,
      rut_solicitante: rut || null,
      tipo_de_persona: tipo,
    })
    .eq('id', postulacionId)
    .select()
    .single()
  if (error) throw new Error(traducirErrorPostulacion(error.message))
  return data
}

/**
 * Persiste únicamente las rutas de documentos de un borrador. A diferencia de
 * `enviarPostulacion`, no cambia el estado a `en_revision`: permite recuperar
 * de forma segura los archivos elegidos antes de confirmar el correo y dejar
 * que el postulante revise el resultado antes del envío definitivo.
 */
export async function guardarDocumentosBorrador(postulacionId, rutas = {}) {
  const columnas = Object.fromEntries(
    Object.entries(rutas)
      .filter(([, resultado]) => resultado?.columna && resultado?.ruta)
      .map(([, resultado]) => [resultado.columna, resultado.ruta]),
  )
  if (!postulacionId || !Object.keys(columnas).length) return null

  const client = getClient()
  const { data, error } = await client
    .from('postulaciones_vendedores')
    .update(columnas)
    .eq('id', postulacionId)
    .select()
    .single()
  if (error) throw new Error(traducirErrorPostulacion(error.message))
  return data
}

/* ------------------------------------------------------------------
 * C3 / REG-DOC — Validación segura de documentos del postulante (cliente).
 * Espeja las restricciones reales del bucket privado vendedor-documentos
 * (migración 20261010020000): 10 MiB por archivo, MIME pdf/jpeg/png y rutas
 * con un único punto de extensión. El servidor VUELVE a validar (allowed_mime_
 * types, file_size_limit y ruta_documento_valida), esto evita el envío inútil.
 * ------------------------------------------------------------------ */

/** Límite operativo aprobado: 10 MiB exactos (HAL-REG-010). */
export const MAX_BYTES_DOCUMENTO = 10 * 1024 * 1024
export const EXTENSIONES_DOCUMENTO = ['pdf', 'jpg', 'jpeg', 'png']
export const MIME_DOCUMENTO = ['application/pdf', 'image/jpeg', 'image/png']
/** Extensiones ejecutables o de script que nunca corresponden a un documento. */
const EXTENSIONES_PELIGROSAS = [
  'exe', 'bat', 'cmd', 'com', 'scr', 'js', 'mjs', 'cjs', 'jsx', 'vbs', 'ps1', 'sh',
  'bash', 'jar', 'msi', 'dll', 'apk', 'html', 'htm', 'svg', 'xml', 'php', 'py',
  'zip', 'rar', '7z', 'tar', 'gz', 'iso', 'lnk',
]

/** Mensaje de rechazo para un archivo inválido, o null si es aceptable. */
export function validarDocumentoPostulante(file) {
  if (!file) return 'Selecciona un archivo.'
  if (file.size === 0) return 'El archivo está vacío: sube una versión legible del documento.'
  if (file.size > MAX_BYTES_DOCUMENTO) {
    // REG-DOC-007/008: se acepta hasta 10.485.760 bytes y se rechaza el siguiente.
    return 'El documento supera el tamaño máximo permitido (10 MB = 10 MiB = 10.485.760 bytes).'
  }
  // REG-DOC-005: el tipo declarado por el navegador también debe ser de documento.
  const tipo = String(file.type ?? '').toLowerCase()
  if (tipo && tipo !== 'application/octet-stream' && !MIME_DOCUMENTO.includes(tipo)) {
    return 'Formato no permitido: el archivo debe ser PDF, JPG o PNG (no se aceptan ejecutables ni archivos renombrados).'
  }
  const partes = String(file.name ?? '').toLowerCase().split('.')
  if (partes.length < 2) return 'El archivo no tiene extensión (PDF, JPG o PNG).'
  const ext = partes.pop()
  if (!EXTENSIONES_DOCUMENTO.includes(ext)) {
    return 'Formato no permitido: sólo PDF, JPG o PNG.'
  }
  // REG-DOC-011: rechaza "documento.pdf.exe" y variantes como "documento.exe.pdf"
  // aunque el nombre termine en una extensión permitida.
  if (partes.some((p) => EXTENSIONES_PELIGROSAS.includes(p))) {
    return 'El nombre del archivo contiene una extensión ejecutable: renómbralo antes de subirlo.'
  }
  // Extensiones dobles (documento.pdf.png) rompen la ruta que exige la BD:
  // la ruta válida sólo admite UN punto de extensión al final.
  if (partes.some((p) => EXTENSIONES_DOCUMENTO.includes(p))) {
    return 'El nombre del archivo tiene una extensión doble: renómbralo antes de subirlo.'
  }
  return null
}

const FIRMAS_DOCUMENTO = {
  pdf: [0x25, 0x50, 0x44, 0x46], // %PDF
  png: [0x89, 0x50, 0x4e, 0x47],
  jpg: [0xff, 0xd8, 0xff],
}

async function leerCabecera(file, bytes = 8) {
  if (!file || typeof file.slice !== 'function') return null
  try {
    const trozo = file.slice(0, bytes)
    if (typeof trozo.arrayBuffer !== 'function') return null
    return new Uint8Array(await trozo.arrayBuffer())
  } catch {
    return null
  }
}

/**
 * REG-DOC-006 — Detección de PDF corrupto o archivo renombrado por su contenido.
 *
 * Se leen los primeros bytes y se comparan con la firma real del formato. En
 * PDF se busca la marca `%PDF-` dentro del primer KiB (la especificación admite
 * bytes previos), de modo que un archivo renombrado o truncado se rechaza sin
 * falsos negativos. No reemplaza la validación del servidor (que además revisa
 * el PDF completo): es el control viable en el cliente antes de subir. Si el
 * archivo no se puede leer (por ejemplo un mock sin Blob), no se inventa un
 * rechazo.
 * @returns {Promise<string|null>} mensaje de rechazo o null
 */
export async function validarContenidoDocumento(file) {
  if (!file) return 'Selecciona un archivo.'
  const cabecera = await leerCabecera(file, 1024)
  if (!cabecera || !cabecera.length) return null
  const empiezaCon = (firma) => firma.every((byte, i) => cabecera[i] === byte)
  const contiene = (firma) =>
    cabecera.some((_, inicio) => firma.every((byte, i) => cabecera[inicio + i] === byte))
  const nombre = String(file.name ?? '').toLowerCase()
  const ext = nombre.split('.').pop() ?? ''
  const tipo = String(file.type ?? '').toLowerCase()

  if (ext === 'pdf' || tipo === 'application/pdf') {
    if (!contiene(FIRMAS_DOCUMENTO.pdf)) {
      return 'El archivo no es un PDF válido: está dañado o fue renombrado desde otro formato.'
    }
    return null
  }
  if (ext === 'png' || tipo === 'image/png') {
    if (!empiezaCon(FIRMAS_DOCUMENTO.png)) {
      return 'El archivo no es una imagen PNG válida: está dañado o fue renombrado desde otro formato.'
    }
    return null
  }
  if (['jpg', 'jpeg'].includes(ext) || tipo === 'image/jpeg') {
    if (!empiezaCon(FIRMAS_DOCUMENTO.jpg)) {
      return 'El archivo no es una imagen JPG válida: está dañada o fue renombrada desde otro formato.'
    }
    return null
  }
  return null
}

/** Sube (o reemplaza) un documento y devuelve la ruta completa. */
export async function subirDocumentoPostulacion(perfilId, campo, file) {
  const rechazo = validarDocumentoPostulante(file)
  if (rechazo) throw new Error(rechazo)
  const bases = {
    documentoIdentidad: 'documento-identidad',
    certificadoActividadesOCarnet: 'certificado-inicio-actividades',
    certificadoTitularidad: 'certificado-titularidad',
    comprobanteDomicilio: 'comprobante-domicilio',
  }
  const columnas = {
    documentoIdentidad: 'documento_identidad',
    certificadoActividadesOCarnet: 'certificado_inicio_actividades_o_carnet_representante',
    certificadoTitularidad: 'certificado_titularidad_bancaria',
    comprobanteDomicilio: 'comprobante_domicilio',
  }
  if (!bases[campo] || !file) throw new Error('Documento inválido.')
  const client = getClient()
  const bucket = STORAGE_BUCKETS.documentosPostulante
  const ext = (file.name?.split('.').pop() ?? file.type?.split('/').pop() ?? 'pdf').toLowerCase()
  const nombreObjeto = perfilId + '/' + bases[campo] + '.' + ext
  const { error: upError } = await client.storage.from(bucket).upload(nombreObjeto, file, {
    contentType: file.type || undefined,
    upsert: true,
  })
  if (upError) throw new Error('No se pudo subir ' + bases[campo] + ': ' + upError.message)
  return { campo, columna: columnas[campo], ruta: bucket + '/' + nombreObjeto }
}

/**
 * Reenvía la postulación a `en_revision` reemplazando los documentos indicados.
 * Si venía `rechazada`, el trigger suma intento += 1 y limpia la revisión
 * anterior (el historial queda intacto en postulaciones_revisiones); si venía
 * `borrador` mantiene intento = 1.
 */
export async function reenviarPostulacion({ perfilId: _perfilId, postulacionId, rutasNuevas = {} }) {
  const client = getClient()
  const cambios = { estado: ESTADO_POSTULACION.EN_REVISION }
  for (const { columna, ruta } of Object.values(rutasNuevas)) cambios[columna] = ruta
  const { data, error } = await client
    .from('postulaciones_vendedores')
    .update(cambios)
    .eq('id', postulacionId)
    .select()
    .single()
  if (error) throw new Error(traducirErrorPostulacion(error.message))
  return data
}

/**
 * C2 — Previsualización segura de un documento YA guardado de la propia
 * postulación. El bucket es privado: se pide una URL firmada de corta duración
 * (60 s) y se abre en una pestaña nueva; jamás se construyen URLs públicas ni
 * se confía en la extensión del archivo.
 */
export async function verDocumentoPostulacion(ruta) {
  if (!ruta) throw new Error('Ese documento todavía no fue subido.')
  const [bucket, ...resto] = String(ruta).split('/')
  const objeto = resto.join('/')
  const client = getClient()
  const { data, error } = await client.storage.from(bucket).createSignedUrl(objeto, 60)
  if (error || !data?.signedUrl) {
    throw new Error('No se pudo abrir el documento: inténtalo de nuevo en unos segundos.')
  }
  window.open(data.signedUrl, '_blank', 'noopener')
  return data.signedUrl
}

/** Borrador local no sensible cuando GoTrue exige confirmar el correo antes de sesion. */
const CLAVE_BORRADOR_POSTULACION = 'cutuco:postulacion-pendiente'

/*
 * REG-CONF-005 — `signUp` no entrega una sesión mientras el correo requiere
 * confirmación. Los campos de tienda sí caben en metadata, pero ni los
 * documentos ni la cuenta bancaria deben viajar en `raw_user_meta_data` ni en
 * localStorage. Se guardan sólo de forma TEMPORAL, cifrada y por usuario en
 * IndexedDB; al primer inicio de sesión se suben al bucket privado y al
 * endpoint que cifra los datos bancarios en el servidor.
 *
 * La clave AES no es exportable y también vive en IndexedDB. Esto evita que el
 * número de cuenta y los bytes de identidad queden en texto plano en el
 * almacenamiento web. El respaldo expira a los 7 días y se elimina después de
 * transferirse correctamente. No se guarda ninguna contraseña.
 */
const NOMBRE_BD_BORRADOR_PROTEGIDO = 'cutuco-registro-protegido'
const VERSION_BD_BORRADOR_PROTEGIDO = 1
const ALMACEN_BORRADORES_PROTEGIDOS = 'borradores'
const ALMACEN_CLAVES_BORRADOR = 'claves'
const DURACION_BORRADOR_PROTEGIDO_MS = 7 * 24 * 60 * 60 * 1000

function soporteBorradorProtegido() {
  return Boolean(
    typeof indexedDB !== 'undefined' &&
      globalThis.crypto?.subtle &&
      typeof TextEncoder !== 'undefined' &&
      typeof TextDecoder !== 'undefined' &&
      typeof File !== 'undefined',
  )
}

function abrirBdBorradorProtegido() {
  return new Promise((resolve, reject) => {
    const solicitud = indexedDB.open(NOMBRE_BD_BORRADOR_PROTEGIDO, VERSION_BD_BORRADOR_PROTEGIDO)
    solicitud.onupgradeneeded = () => {
      const db = solicitud.result
      if (!db.objectStoreNames.contains(ALMACEN_BORRADORES_PROTEGIDOS)) {
        db.createObjectStore(ALMACEN_BORRADORES_PROTEGIDOS, { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains(ALMACEN_CLAVES_BORRADOR)) {
        db.createObjectStore(ALMACEN_CLAVES_BORRADOR, { keyPath: 'id' })
      }
    }
    solicitud.onsuccess = () => resolve(solicitud.result)
    solicitud.onerror = () => reject(solicitud.error ?? new Error('No se pudo abrir el almacenamiento temporal.'))
  })
}

function leerIdb(db, almacen, id) {
  return new Promise((resolve, reject) => {
    const solicitud = db.transaction(almacen, 'readonly').objectStore(almacen).get(id)
    solicitud.onsuccess = () => resolve(solicitud.result ?? null)
    solicitud.onerror = () => reject(solicitud.error ?? new Error('No se pudo leer el respaldo temporal.'))
  })
}

function escribirIdb(db, almacen, valor) {
  return new Promise((resolve, reject) => {
    const solicitud = db.transaction(almacen, 'readwrite').objectStore(almacen).put(valor)
    solicitud.onsuccess = () => resolve()
    solicitud.onerror = () => reject(solicitud.error ?? new Error('No se pudo guardar el respaldo temporal.'))
  })
}

function eliminarIdb(db, almacen, id) {
  return new Promise((resolve, reject) => {
    const solicitud = db.transaction(almacen, 'readwrite').objectStore(almacen).delete(id)
    solicitud.onsuccess = () => resolve()
    solicitud.onerror = () => reject(solicitud.error ?? new Error('No se pudo eliminar el respaldo temporal.'))
  })
}

async function claveBorradorProtegido(db, userId) {
  const existente = await leerIdb(db, ALMACEN_CLAVES_BORRADOR, userId)
  if (existente?.clave) return existente.clave
  const clave = await globalThis.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  )
  await escribirIdb(db, ALMACEN_CLAVES_BORRADOR, { id: userId, clave })
  return clave
}

async function cifrarBorrador(clave, contenido) {
  const iv = globalThis.crypto.getRandomValues(new Uint8Array(12))
  const cifrado = await globalThis.crypto.subtle.encrypt({ name: 'AES-GCM', iv }, clave, contenido)
  return { iv, cifrado }
}

async function descifrarBorrador(clave, registro) {
  return globalThis.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: registro.iv },
    clave,
    registro.cifrado,
  )
}

async function cifrarJsonBorrador(clave, valor) {
  return cifrarBorrador(clave, new TextEncoder().encode(JSON.stringify(valor)))
}

async function descifrarJsonBorrador(clave, registro) {
  return JSON.parse(new TextDecoder().decode(await descifrarBorrador(clave, registro)))
}

async function serializarDocumentoProtegido(clave, file) {
  if (!file) return null
  if (typeof file.arrayBuffer !== 'function') throw new Error('No se pudo leer uno de los documentos.')
  return {
    nombre: String(file.name ?? 'documento'),
    tipo: String(file.type ?? 'application/octet-stream'),
    modificadoEn: Number(file.lastModified ?? Date.now()),
    contenido: await cifrarBorrador(clave, await file.arrayBuffer()),
  }
}

async function restaurarDocumentoProtegido(clave, documento) {
  if (!documento?.contenido) return null
  const bytes = await descifrarBorrador(clave, documento.contenido)
  return new File([bytes], documento.nombre, {
    type: documento.tipo,
    lastModified: documento.modificadoEn,
  })
}

/**
 * Respalda los archivos y los datos bancarios justo después de crear la cuenta
 * sin sesión. Devuelve `false` si el navegador no ofrece almacenamiento cifrado
 * para que la vista pueda informar honestamente qué datos deberán reingresarse.
 */
export async function guardarBorradorProtegidoLocal({ userId, datosBancarios, documentos = {} }) {
  if (!userId || !soporteBorradorProtegido()) return false
  let db = null
  try {
    db = await abrirBdBorradorProtegido()
    const clave = await claveBorradorProtegido(db, userId)
    const documentosCifrados = {}
    for (const [campo, file] of Object.entries(documentos)) {
      documentosCifrados[campo] = await serializarDocumentoProtegido(clave, file)
    }
    await escribirIdb(db, ALMACEN_BORRADORES_PROTEGIDOS, {
      id: userId,
      creadoEn: Date.now(),
      expiraEn: Date.now() + DURACION_BORRADOR_PROTEGIDO_MS,
      datosBancarios: await cifrarJsonBorrador(clave, datosBancarios),
      documentos: documentosCifrados,
    })
    return true
  } catch {
    return false
  } finally {
    db?.close()
  }
}

/** Recupera en memoria el respaldo cifrado del mismo usuario recién autenticado. */
export async function leerBorradorProtegidoLocal(userId) {
  if (!userId || !soporteBorradorProtegido()) return null
  let db = null
  try {
    db = await abrirBdBorradorProtegido()
    const borrador = await leerIdb(db, ALMACEN_BORRADORES_PROTEGIDOS, userId)
    if (!borrador) return null
    if (!borrador.expiraEn || borrador.expiraEn < Date.now()) {
      await eliminarIdb(db, ALMACEN_BORRADORES_PROTEGIDOS, userId)
      await eliminarIdb(db, ALMACEN_CLAVES_BORRADOR, userId)
      return null
    }
    const clave = await claveBorradorProtegido(db, userId)
    const documentos = {}
    for (const [campo, documento] of Object.entries(borrador.documentos ?? {})) {
      documentos[campo] = await restaurarDocumentoProtegido(clave, documento)
    }
    return {
      datosBancarios: await descifrarJsonBorrador(clave, borrador.datosBancarios),
      documentos,
    }
  } catch {
    return null
  } finally {
    db?.close()
  }
}

/** Elimina el respaldo temporal una vez que la cuenta y los documentos llegaron al servidor. */
export async function limpiarBorradorProtegidoLocal(userId) {
  if (!userId || !soporteBorradorProtegido()) return
  let db = null
  try {
    db = await abrirBdBorradorProtegido()
    await eliminarIdb(db, ALMACEN_BORRADORES_PROTEGIDOS, userId)
    await eliminarIdb(db, ALMACEN_CLAVES_BORRADOR, userId)
  } catch {
    /* Si la limpieza falla, la vigencia máxima elimina el borrador al leerlo. */
  } finally {
    db?.close()
  }
}

/** Borrador local de registro de Cliente (REG-NAV-003): se recupera al recargar. */
const CLAVE_BORRADOR_CLIENTE = 'cutuco:registro-cliente-pendiente'

export function guardarBorradorLocal(draft) {
  try {
    localStorage.setItem(CLAVE_BORRADOR_POSTULACION, JSON.stringify(draft))
  } catch {
    /* localStorage lleno o bloqueado: no rompe el registro. */
  }
}

export function leerBorradorLocal() {
  try {
    const raw = localStorage.getItem(CLAVE_BORRADOR_POSTULACION)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function limpiarBorradorLocal() {
  try {
    localStorage.removeItem(CLAVE_BORRADOR_POSTULACION)
  } catch {
    /* noop */
  }
}

/* ---------- REG-NAV-003 · borrador de registro de Cliente ---------- */

const CAMPOS_BORRADOR_CLIENTE = [
  'nombre', 'apellido', 'email', 'telefono', 'regionId', 'comunaId',
  'calle', 'numero', 'deptoOficina', 'referencia', 'paso',
]

function borradorClienteSinCredenciales(draft) {
  if (!draft || typeof draft !== 'object' || Array.isArray(draft)) return null
  return Object.fromEntries(CAMPOS_BORRADOR_CLIENTE
    .filter((campo) => Object.hasOwn(draft, campo))
    .map((campo) => [campo, draft[campo]]))
}

export function guardarBorradorClienteLocal(draft) {
  try {
    localStorage.setItem(CLAVE_BORRADOR_CLIENTE, JSON.stringify(borradorClienteSinCredenciales(draft)))
  } catch {
    /* localStorage lleno o bloqueado: no rompe el registro. */
  }
}

export function leerBorradorClienteLocal() {
  try {
    const raw = localStorage.getItem(CLAVE_BORRADOR_CLIENTE)
    if (!raw) return null
    const draft = JSON.parse(raw)
    const seguro = borradorClienteSinCredenciales(draft)
    if (seguro && (Object.hasOwn(draft, 'password') || Object.hasOwn(draft, 'confirmacion'))) {
      guardarBorradorClienteLocal(seguro)
    }
    return seguro
  } catch {
    return null
  }
}

export function limpiarBorradorClienteLocal() {
  try {
    localStorage.removeItem(CLAVE_BORRADOR_CLIENTE)
  } catch {
    /* noop */
  }
}

/* ---------- REG-VEN-002 · nombre comercial duplicado ---------- */

export async function verificarNombreComercialDisponible(nombreComercial) {
  if (!nombreComercial || !nombreComercial.trim()) return { disponible: true }
  const { listProductores } = await import('@/services/catalog')
  const productores = await listProductores({ onlyActive: true })
  const normalizado = String(nombreComercial).trim().toLowerCase()
  const duplicado = productores.some(
    (p) => String(p.nombre_comercial ?? '').trim().toLowerCase() === normalizado,
  )
  return { disponible: !duplicado, nombreComercial }
}

/* ---------- REG-VEN-015 · RUT ya asociado ---------- */

export async function verificarRutDisponible(rutSolicitante) {
  const rut = normalizarRut(rutSolicitante)
  if (!rut) return { disponible: true }
  const client = getClient()
  /*
   * REG-VEN-015: `postulaciones_vendedores` no es legible como anon (RLS: SELECT
   * sólo para authenticated), así que un SELECT directo devolvía 401/42501 y el
   * registro público abortaba antes de crear la cuenta. La verificación usa la
   * RPC pública `rut_solicitante_disponible`, que devuelve sólo un booleano.
   */
  const { data, error } = await client.rpc('rut_solicitante_disponible', { p_rut: rut })
  if (error) throw new Error(mensajeSeguro(error))
  return { disponible: data !== false, rut }
}

/* ---------- REG-DOC-017 · limpiar documentos subidos cuando falla ---------- */

/**
 * Elimina de Storage los documentos de postulación que ya se subieron pero cuya
 * registro falló después (REG-DOC-017). Recibe las rutas completas
 * (`bucket/nombreObjeto`) que se persistieron en la tabla.
 */
export async function limpiarDocumentosSubidos(rutas = []) {
  const client = getClient()
  const errores = []
  for (const ruta of rutas) {
    const [bucket, ...resto] = String(ruta).split('/')
    const objeto = resto.join('/')
    const { error } = await client.storage.from(bucket).remove([objeto])
    if (error) errores.push(`${objeto}: ${error.message}`)
  }
  return errores
}
