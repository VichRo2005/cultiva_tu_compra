<script setup>
/**
 * CuTuCo — Finalizar pedido (RF-002, RF-005, RF-009 y RF-014).
 *
 * Pasos DESPACHO · PAGO · REVISIÓN. El cliente elige una de sus direcciones
 * guardadas (tabla `direcciones`) y confirma el destinatario. Antes de crear el
 * pago se valida la región del vendedor contra la de la dirección (RF-009) y
 * luego se llama a FastAPI (`/api/webpay/iniciar`), que crea el pedido y la
 * transacción de Webpay Mall. Con el commit autorizado Transbank dispersa el
 * cobro al comercio del productor (menos el 5% de CuTuCo en el Mall): CuTuCo no
 * retiene fondos (RF-005).
 *
 * El navegador se envía a Webpay con un POST que lleva `token_ws` en el cuerpo
 * (ver `CONTRATO-PAGO.md`); el commit y el resultado se resuelven en
 * `/pago/retorno` (PaymentResultView).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el pedido se creaba desde
 * el navegador (`createPedido`), el pago se simulaba en `services/payments.js` y
 * la cobertura se validaba por comuna.
 */
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStepper from '@/components/base/CtStepper.vue'
import { LABELS, REGLAS } from '@/lib/constants'
import { formatMontoCompra as formatCLP } from '@/lib/format'
import { formatearCantidad } from '@/services/catalog'
import {
  isDeptoOficina,
  isNumeroDireccion,
  isPhone,
  isReferenciaDireccion,
  isRut,
  LIMITES,
  maxLength,
  required,
  validate,
} from '@/lib/validation'
import { getEmpresaTributaria, iniciarPago } from '@/services/orders'
import { createDireccion, listDirecciones } from '@/services/geography'
import { useAuthStore } from '@/stores/auth'
import { useCartStore } from '@/stores/cart'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const PASOS = [
  { key: 'despacho', label: 'Despacho', description: 'Dirección y contacto' },
  { key: 'pago', label: 'Pago', description: 'Documento tributario y Webpay' },
  { key: 'revision', label: 'Revisión', description: 'Confirma y paga tu pedido' },
]

const router = useRouter()
const auth = useAuthStore()
const cart = useCartStore()
const geo = useGeographyStore()
const ui = useUiStore()

/* ------------------------------- direcciones ------------------------------ */

const direcciones = ref([])
const direccionId = ref(null)
const cargandoDirecciones = ref(false)
const mostrarNuevaDireccion = ref(false)
const guardandoDireccion = ref(false)

function direccionVacia() {
  return {
    etiqueta: 'Entrega',
    regionId: null,
    comunaId: null,
    calle: '',
    numero: '',
    deptoOficina: '',
    referencia: '',
  }
}

const nuevaDireccion = ref(direccionVacia())

const direccionSeleccionada = computed(
  () => direcciones.value.find((d) => d.id === direccionId.value) ?? null,
)

const opcionesDireccion = computed(() =>
  direcciones.value.map((d) => ({
    value: d.id,
    label: `${d.etiqueta} · ${[d.calle, d.numero, d.depto_oficina].filter(Boolean).join(' ')}`,
  })),
)

/* -------------------------------- formulario ------------------------------ */

const formulario = ref({
  nombre: '',
  apellido: '',
  referencia: '',
  telefono: '',
})
const errores = ref({})
const submitting = ref(false)
const sincronizando = ref(false)
const errorGlobal = ref(null)
const pasoActual = ref(0)

/** HAL-CLI-013: consentimiento expreso de los términos, no implícito. */
const aceptaTerminos = ref(false)
const errorTerminos = ref(null)

/** HAL-CLI-020: el cliente debe aceptar un cambio de precio antes de pagar. */
const modalPrecios = ref(false)
const cambiosPrecio = ref([])
const preciosConfirmados = ref(null)
const sinStockProductos = ref([])

const ESQUEMA = {
  nombre: { required: true, minLength: 2, maxLength: 100 },
  apellido: { required: true, minLength: 2, maxLength: 100 },
  telefono: { required: true, phone: true },
  referencia: {
    custom: (value) =>
      isReferenciaDireccion(value)
        ? null
        : `La referencia es opcional; si la ingresas, usa hasta ${LIMITES.referencia} caracteres`,
  },
}

const nombreVendedor = computed(() => cart.porVendedor.map((g) => g.productorNombre).join(', ') || 'Vendedor')
const regionVendedor = computed(() => cart.cobertura?.regionVendedor ?? null)

const subtotal = computed(() => cart.subtotal)
const costoEnvio = computed(() => cart.envio)
const baseImponible = computed(() => cart.baseImponible)
const iva = computed(() => cart.iva)
const tasaIva = computed(() => cart.tasaIva)
const comision = computed(() => cart.comision)
const total = computed(() => cart.total)
const despachosPorProductor = computed(() =>
  cart.porVendedor.map((grupo) => ({
    productorId: grupo.productorId,
    productorNombre: grupo.productorNombre,
    monto: REGLAS.TARIFAS.deliveryDefecto,
  })),
)

/** HAL-CLI-008: cantidad real con la unidad del ítem (0,5 kg, no «0»). */
function formatCantidad(valor, unidad) {
  return formatearCantidad(valor, unidad)
}

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)
const opcionesComunaNueva = computed(() =>
  geo.comunasDeRegion(nuevaDireccion.value.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

const nombreRegion = computed(() =>
  direccionSeleccionada.value
    ? geo.nombreRegion(direccionSeleccionada.value.region_id ?? geo.regionDeComuna(direccionSeleccionada.value.comuna_id))
    : '—',
)
const nombreComuna = computed(() =>
  direccionSeleccionada.value ? geo.nombreComuna(direccionSeleccionada.value.comuna_id) : '—',
)

const bloqueos = computed(() => {
  const lista = []
  if (cart.vacio) lista.push('Tu carrito está vacío.')
  if (cart.errorMontos) lista.push(cart.errorMontos)
  if (!direccionId.value) lista.push('Selecciona o registra una dirección de entrega.')
  if (cart.cobertura && cart.cobertura.ok === false) {
    lista.push(cart.cobertura.motivo ?? 'El vendedor no entrega en la región de tu dirección.')
  }
  return lista
})

/** Validación silenciosa para habilitar el avance al siguiente paso. */
const despachoCompleto = computed(
  () =>
    Boolean(direccionId.value) &&
    required(formulario.value.nombre) &&
    required(formulario.value.apellido) &&
    isPhone(formulario.value.telefono),
)

const formularioValido = computed(
  () => despachoCompleto.value && Object.keys(errores.value).length === 0 && bloqueos.value.length === 0,
)

const coberturaOk = computed(() => cart.cobertura?.ok === true)

function validar() {
  const { valid, errors } = validate(formulario.value, ESQUEMA)
  errores.value = errors
  if (!valid) ui.warning('Revisa el despacho', 'Hay campos obligatorios o con formato inválido')
  return valid
}

const puedePagar = computed(
  () => formularioValido.value && facturaCompleta.value && aceptaTerminos.value && !submitting.value,
)

function irAPaso(indice) {
  if (indice === 0) pasoActual.value = 0
  if (indice === 1 && validar()) pasoActual.value = 1
  if (indice === 2 && validar() && validarFactura()) pasoActual.value = 2
}

/* --------------------------------- datos --------------------------------- */

async function cargarDirecciones() {
  cargandoDirecciones.value = true
  try {
    const lista = await listDirecciones({ perfilId: auth.perfil?.id })
    direcciones.value = lista
    if (!direccionId.value || !lista.some((d) => d.id === direccionId.value)) {
      direccionId.value = (lista.find((d) => d.es_principal) ?? lista[0])?.id ?? null
    }
    await validarCobertura()
  } catch (e) {
    errorGlobal.value = e?.message ?? 'No se pudieron cargar tus direcciones'
  } finally {
    cargandoDirecciones.value = false
  }
}

/** RF-009: valida la región antes de crear el pago. */
async function validarCobertura() {
  if (!direccionSeleccionada.value || cart.vacio) {
    cart.cobertura = null
    return null
  }
  const resultado = await cart.validarCobertura(direccionSeleccionada.value)
  if (resultado?.ok) {
    cart.destino = {
      direccionId: direccionSeleccionada.value.id,
      comunaId: direccionSeleccionada.value.comuna_id,
      regionId: cart.cobertura?.regionCliente?.id ?? null,
    }
  }
  return resultado
}

async function guardarNuevaDireccion() {
  if (guardandoDireccion.value) return
  if (!auth.user?.id || !auth.perfil?.id) {
    ui.error(
      'Inicia sesión para guardar una dirección',
      'Las direcciones de entrega sólo se guardan dentro de una cuenta de cliente.',
    )
    return
  }
  const nueva = nuevaDireccion.value
  const calle = String(nueva.calle ?? '').trim()
  const numero = String(nueva.numero ?? '').trim()
  const deptoOficina = String(nueva.deptoOficina ?? '').trim()
  const referencia = String(nueva.referencia ?? '').trim()

  if (!nueva.comunaId) {
    ui.warning('Falta la comuna', 'Selecciona la comuna de la nueva dirección')
    return
  }
  if (!required(calle)) {
    ui.warning('Falta la calle', 'Escribe la calle de la nueva dirección')
    return
  }
  if (!maxLength(calle, LIMITES.calle)) {
    ui.warning('Calle demasiado larga', `La calle no puede superar ${LIMITES.calle} caracteres`)
    return
  }
  if (!isNumeroDireccion(numero)) {
    ui.warning('Número inválido', `El número es opcional; usa hasta ${LIMITES.numero} caracteres alfanuméricos`)
    return
  }
  if (!isDeptoOficina(deptoOficina)) {
    ui.warning('Depto u oficina inválido', `Usa hasta ${LIMITES.deptoOficina} caracteres o déjalo vacío`)
    return
  }
  if (!isReferenciaDireccion(referencia)) {
    ui.warning('Referencia inválida', `La referencia es opcional; usa hasta ${LIMITES.referencia} caracteres`)
    return
  }

  guardandoDireccion.value = true
  try {
    const creada = await createDireccion({
      perfilId: auth.perfil.id,
      etiqueta: nueva.etiqueta || 'Entrega',
      comunaId: nueva.comunaId,
      calle,
      numero: numero || null,
      deptoOficina: deptoOficina || null,
      referencia: referencia || null,
      esPrincipal: direcciones.value.length === 0,
    })
    mostrarNuevaDireccion.value = false
    nuevaDireccion.value = direccionVacia()
    await cargarDirecciones()
    direccionId.value = creada.id
    await validarCobertura()
    ui.success('Dirección agregada', 'Ya puedes usarla en este pedido')
  } catch (e) {
    ui.error('No se pudo guardar la dirección', e?.message)
  } finally {
    guardandoDireccion.value = false
  }
}

/* ------------------------- documento tributario --------------------------- */

/**
 * Si el cliente elige factura debe completar los datos de su empresa y puede
 * autocompletarlos a partir del RUT consultando `GET /api/tributario/empresa`.
 */
const documento = ref({
  tipo: 'boleta',
  rut_empresa: '',
  razon_social: '',
  giro: '',
  direccion_tributaria: '',
})
const buscandoRut = ref(false)
const mostrarErroresFactura = ref(false)

const opcionesDocumento = [
  { value: 'boleta', label: 'Boleta' },
  { value: 'factura', label: 'Factura (la genera el productor)' },
]

/** Errores locales de la factura antes de enviar el checkout al backend. */
const erroresFactura = computed(() => {
  const errores = {}
  if (documento.value.tipo !== 'factura') return errores
  const rut = String(documento.value.rut_empresa ?? '').trim()
  const razon = String(documento.value.razon_social ?? '').trim()
  const giro = String(documento.value.giro ?? '').trim()
  const direccion = String(documento.value.direccion_tributaria ?? '').trim()

  if (!rut) errores.rut_empresa = 'Ingresa el RUT de la empresa'
  else if (!isRut(rut)) errores.rut_empresa = 'RUT inválido: revisa el formato y el dígito verificador'
  if (!razon) errores.razon_social = 'Ingresa la razón social'
  else if (!maxLength(razon, 200)) errores.razon_social = 'La razón social no puede superar 200 caracteres'
  if (!giro) errores.giro = 'Ingresa el giro'
  else if (!maxLength(giro, 200)) errores.giro = 'El giro no puede superar 200 caracteres'
  if (!direccion) errores.direccion_tributaria = 'Ingresa la dirección tributaria'
  else if (!maxLength(direccion, LIMITES.calle)) {
    errores.direccion_tributaria = `La dirección tributaria no puede superar ${LIMITES.calle} caracteres`
  }
  return errores
})

const facturaCompleta = computed(() => Object.keys(erroresFactura.value).length === 0)

function validarFactura() {
  mostrarErroresFactura.value = true
  if (facturaCompleta.value) return true
  pasoActual.value = 1
  ui.warning('Datos de factura incompletos', 'Revisa el RUT, la razón social, el giro y la dirección tributaria.')
  return false
}

/** Rellena razón social y giro desde el servicio tributario del backend. */
async function autocompletarEmpresa() {
  const rutRaw = String(documento.value.rut_empresa ?? '').trim()
  // HAL-CLI-028: normaliza el RUT (quita puntos y espacios) antes de consultar,
  // así "76.123.456-7" y "76123456-7" resuelven al mismo servicio tributario.
  const rut = rutRaw.replace(/[.\s]/g, '')
  if (!rut) {
    ui.warning('Falta el RUT', 'Escribe el RUT de la empresa antes de autocompletar.')
    return
  }
  if (!isRut(rut)) {
    ui.warning('RUT inválido', 'Revisa el formato y el dígito verificador (ej: 76123456-7).')
    return
  }
  buscandoRut.value = true
  try {
    const empresa = await getEmpresaTributaria(rut)
    if (!empresa?.existe) {
      ui.warning('Sin datos tributarios', 'No encontramos datos para ese RUT; completa los campos a mano.')
      return
    }
    documento.value.rut_empresa = empresa.rut ?? rut
    documento.value.razon_social = empresa.razon_social ?? documento.value.razon_social
    documento.value.giro = empresa.giro ?? documento.value.giro
    ui.success('Datos cargados', 'Rellenamos la razón social y el giro de la empresa.')
  } catch (e) {
    const status = Number(e?.status ?? 0)
    if (status === 422) {
      ui.warning('RUT inválido', 'El RUT ingresado no tiene un formato válido (ej: 76123456-7).')
    } else if (status === 404) {
      ui.warning('Sin datos tributarios', 'No encontramos datos para ese RUT; completa los campos a mano.')
    } else if (status === 502) {
      ui.error('Servicio tributario no disponible', 'El proveedor de datos no responde; intenta más tarde o completa los campos a mano.')
    } else {
      ui.error('No se pudo consultar el RUT', e?.message ?? 'Error inesperado')
    }
  } finally {
    buscandoRut.value = false
  }
}

/* ------------------------------- pago Webpay ------------------------------ */

const webpay = ref({ url: '', token: '' })
const formWebpay = ref(null)

/**
 * Crea el pedido y la transacción en FastAPI y envía al cliente a Webpay.
 * El carrito se vacía cuando el pago queda confirmado, no antes.
 */
function detectarCambiosPrecio(preciosAntes) {
  const referencia = preciosConfirmados.value ?? Object.fromEntries(preciosAntes)
  return cart.items
    .map((item) => {
      const nuevo = Number(item.precio)
      const anterior = Number(referencia[item.productoId] ?? nuevo)
      if (!Number.isFinite(nuevo) || nuevo === anterior) return null
      return {
        productoId: item.productoId,
        nombre: item.nombre,
        anterior,
        nuevo,
      }
    })
    .filter(Boolean)
}

function aceptarPreciosActualizados() {
  // Se confirma el total vigente y se reintenta el pago; si el catálogo vuelve
  // a cambiar, se pedirá una nueva aceptación en lugar de cobrar en silencio.
  preciosConfirmados.value = Object.fromEntries(
    cart.items.map((item) => [item.productoId, Number(item.precio)]),
  )
  modalPrecios.value = false
  continuarAlPago()
}

async function continuarAlPago() {
  if (submitting.value) return
  errorTerminos.value = null
  errorGlobal.value = null
  sinStockProductos.value = []

  if (!validar()) {
    pasoActual.value = 0
    return
  }
  if (bloqueos.value.length) {
    pasoActual.value = 0
    return
  }
  if (!validarFactura()) return
  if (!aceptaTerminos.value) {
    pasoActual.value = 2
    errorTerminos.value = 'Debes aceptar los términos de CuTuCo para continuar con el pago'
    ui.warning('Falta aceptar los términos', 'Marca la casilla de aceptación antes de pagar.')
    return
  }

  submitting.value = true
  try {
    sincronizando.value = true
    const preciosAntes = new Map(cart.items.map((item) => [item.productoId, Number(item.precio)]))
    const sinStock = await cart.sincronizar()
    if (sinStock?.length) {
      sinStockProductos.value = sinStock
      throw new Error(`No hay stock suficiente para: ${sinStock.join(', ')}. Revisa las cantidades del carrito para continuar.`)
    }

    if (cart.errorMontos) throw new Error(cart.errorMontos)

    const cambios = detectarCambiosPrecio(preciosAntes)
    if (cambios.length) {
      cambiosPrecio.value = cambios
      modalPrecios.value = true
      // Se detiene sin crear la transacción hasta que el cliente acepte el nuevo total.
      return
    }
    preciosConfirmados.value = Object.fromEntries(
      cart.items.map((item) => [item.productoId, Number(item.precio)]),
    )

    // El backend vuelve a validar la región; aquí se avisa antes de crear nada.
    await validarCobertura()
    if (cart.cobertura && cart.cobertura.ok === false) {
      throw new Error(cart.cobertura.motivo ?? 'El vendedor no entrega en la región de tu dirección.')
    }

    const respuesta = await iniciarPago({
      direccionId: direccionId.value,
      montoEsperado: total.value,
      items: cart.toItems(),
      nombreDestinatario: `${formulario.value.nombre} ${formulario.value.apellido}`.trim(),
      telefonoDestinatario: formulario.value.telefono.trim(),
      referenciaEntrega: formulario.value.referencia.trim() || null,
      documentoTributario:
        documento.value.tipo === 'factura'
          ? {
              tipo: 'factura',
              rut_empresa: String(documento.value.rut_empresa).trim(),
              razon_social: String(documento.value.razon_social).trim(),
              giro: String(documento.value.giro).trim(),
              direccion_tributaria: String(documento.value.direccion_tributaria).trim(),
            }
          : { tipo: 'boleta' },
    })

    // Webpay exige recibir el token en el cuerpo del POST.
    webpay.value = { url: respuesta.url, token: respuesta.token_ws }
    await nextTick()
    formWebpay.value?.submit()
  } catch (e) {
    errorGlobal.value = e?.message ?? 'No se pudo iniciar el pago'
    ui.error('No se pudo iniciar el pago', e?.message)
  } finally {
    sincronizando.value = false
    submitting.value = false
  }
}

onMounted(async () => {
  // La jerarquía geográfica es auxiliar: no debe inmovilizar el checkout ni
  // impedir cargar las direcciones que ya tiene la cuenta.
  void geo.load()
  // La tasa inicial es la legal; la configuración puede terminar después sin
  // posponer la carga de direcciones ni el primer render del checkout.
  void cart.cargarConfiguracionIva()

  if (cart.vacio) {
    ui.info('Carrito vacío', 'Agrega productos antes de continuar')
    router.replace('/carrito')
    return
  }

  formulario.value = {
    nombre: auth.perfil?.nombre ?? '',
    apellido: auth.perfil?.apellido ?? '',
    telefono: auth.perfil?.telefono ?? '',
    referencia: '',
  }

  await cargarDirecciones()
})

watch(direccionId, () => {
  if (!cart.vacio) validarCobertura()
})

watch(aceptaTerminos, (valor) => {
  if (valor) errorTerminos.value = null
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <CtButton to="/carrito" variant="ghost" size="sm" class="volver">
          <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
          Volver al carrito
        </CtButton>
        <h1 class="page-head__title">Finalizar Pedido</h1>
        <p class="page-head__subtitle">
          Confirma los datos de despacho y paga de forma segura con Webpay Mall.
        </p>
      </div>
      <div class="page-head__actions">
        <CtBadge tone="neutral" dot>
          <template #icon><CtIcon name="store" :size="13" /></template>
          {{ nombreVendedor }}
        </CtBadge>
      </div>
    </header>

    <CtStepper :steps="PASOS" :current="pasoActual" orientation="horizontal" />

    <CtAlert v-for="bloqueo in bloqueos" :key="bloqueo" tone="warning" compact>
      <p class="linea">
        <CtIcon name="alert" :size="15" />
        <span>{{ bloqueo }}</span>
      </p>
    </CtAlert>

    <CtAlert v-if="errorGlobal" tone="danger" title="No se pudo completar el pedido">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ errorGlobal }}</span>
      </p>
    </CtAlert>

    <div class="checkout">
      <div class="checkout__principal stack">
        <!-- ================= DESPACHO ================= -->
        <CtCard
          title="Información de Despacho"
          subtitle="Completa los datos de quien recibe el pedido."
        >
          <template #actions>
            <CtButton
              variant="ghost"
              size="sm"
              :disabled="pasoActual !== 0"
              @click="irAPaso(0)"
            >
              Editar
            </CtButton>
          </template>

          <div v-show="pasoActual === 0" class="formulario">
            <CtSpinner v-if="cargandoDirecciones" inline label="Cargando tus direcciones" />

            <template v-else>
              <CtSelect
                v-if="direcciones.length"
                v-model="direccionId"
                label="Dirección de entrega"
                :options="opcionesDireccion"
                placeholder="Selecciona una dirección"
                required
              />

              <CtAlert v-if="!direcciones.length" tone="warning" compact title="Sin direcciones registradas">
                <p>Registra tu dirección de entrega para continuar con el pago.</p>
              </CtAlert>

              <CtButton
                v-if="!mostrarNuevaDireccion"
                variant="secondary"
                size="sm"
                class="formulario__continuar"
                @click="mostrarNuevaDireccion = true"
              >
                <template #icon><CtIcon name="plus" :size="15" /></template>
                Agregar una dirección
              </CtButton>

              <div v-else class="stack">
                <div class="formulario__fila">
                  <CtSelect
                    v-model="nuevaDireccion.regionId"
                    label="Región"
                    :options="opcionesRegion"
                    :disabled="geo.cargando"
                    placeholder="Selecciona la región"
                    @change="nuevaDireccion.comunaId = null"
                  />
                  <CtSelect
                    v-model="nuevaDireccion.comunaId"
                    label="Comuna"
                    :options="opcionesComunaNueva"
                    :disabled="!nuevaDireccion.regionId"
                    placeholder="Selecciona la comuna"
                    required
                  />
                </div>
                <div class="formulario__fila">
                  <CtInput v-model="nuevaDireccion.calle" label="Calle" required placeholder="Calle Compañía" />
                  <CtInput
                    v-model="nuevaDireccion.numero"
                    label="Nro./Altura de calle (opcional)"
                    placeholder="123-B, Casa 3"
                    :hint="`Opcional y alfanumérico (máx. ${LIMITES.numero} caracteres)`"
                  />
                </div>
                <div class="formulario__fila">
                  <CtInput
                    v-model="nuevaDireccion.deptoOficina"
                    label="Depto u oficina (opcional)"
                    placeholder="Depto 402, Local B"
                  />
                  <CtInput v-model="nuevaDireccion.etiqueta" label="Etiqueta" placeholder="Casa" />
                </div>
                <CtInput
                  v-model="nuevaDireccion.referencia"
                  label="Referencia"
                  placeholder="Portón verde, timbre 3"
                  hint="Opcional: ayuda al repartidor a ubicar el domicilio"
                />
                <div class="revision__acciones">
                  <CtButton variant="ghost" size="sm" @click="mostrarNuevaDireccion = false">Cancelar</CtButton>
                  <CtButton size="sm" :loading="guardandoDireccion" @click="guardarNuevaDireccion">
                    Guardar dirección
                  </CtButton>
                </div>
              </div>

              <div class="formulario__fila">
                <CtInput
                  v-model="formulario.nombre"
                  label="Nombre de quien recibe"
                  required
                  :error="errores.nombre ?? null"
                />
                <CtInput
                  v-model="formulario.apellido"
                  label="Apellido"
                  required
                  :error="errores.apellido ?? null"
                />
              </div>

              <div class="formulario__fila">
                <CtInput
                  v-model="formulario.telefono"
                  label="Teléfono de contacto"
                  placeholder="+56912345678"
                  required
                  :error="errores.telefono ?? null"
                />
                <CtInput
                  v-model="formulario.referencia"
                  label="Referencias de despacho"
                  placeholder="Portón verde, timbre 3"
                  hint="Opcional: ayuda al repartidor a ubicar el domicilio"
                />
              </div>

              <CtAlert v-if="coberturaOk" tone="success" compact title="Cobertura confirmada">
                <p>
                  Tu dirección está en la región {{ regionVendedor?.nombre ?? nombreRegion }}, la misma
                  del vendedor.
                </p>
              </CtAlert>

              <CtButton
                size="lg"
                :disabled="!despachoCompleto"
                class="formulario__continuar"
                @click="irAPaso(1)"
              >
                Revisar el pago
                <template #trailing><CtIcon name="chevronRight" :size="16" /></template>
              </CtButton>
            </template>
          </div>

          <!-- ================= PAGO ================= -->
          <div v-show="pasoActual === 1" class="revision">
            <div class="revision__bloque">
              <span class="eyebrow">Destinatario</span>
              <p class="revision__valor">
                {{ formulario.nombre }} {{ formulario.apellido }} · {{ formulario.telefono }}
              </p>
            </div>
            <div class="revision__bloque">
              <span class="eyebrow">Dirección de entrega</span>
              <p class="revision__valor">
                {{
                  [
                    direccionSeleccionada?.calle,
                    direccionSeleccionada?.numero,
                    direccionSeleccionada?.depto_oficina,
                  ]
                    .filter(Boolean)
                    .join(' ')
                }}
                — {{ nombreComuna }}, {{ nombreRegion }}
              </p>
              <p v-if="formulario.referencia" class="revision__nota">
                Referencia: {{ formulario.referencia }}
              </p>
            </div>
            <div class="revision__bloque">
              <span class="eyebrow">Tienda</span>
              <p class="revision__valor">
                {{ nombreVendedor }}{{ regionVendedor ? ` · Región ${regionVendedor.nombre}` : '' }}
              </p>
            </div>
            <CtAlert tone="info" compact title="Despacho por productor">
              <p class="linea">
                <CtIcon name="truck" :size="15" />
                <span>
                  Se cobra {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }} por cada productor de tu compra:
                  {{ despachosPorProductor.length }} despacho{{ despachosPorProductor.length === 1 ? '' : 's' }} en total.
                </span>
              </p>
              <ul class="checkout__despachos">
                <li v-for="despacho in despachosPorProductor" :key="despacho.productorId">
                  <span>{{ despacho.productorNombre }}</span><strong>{{ formatCLP(despacho.monto) }}</strong>
                </li>
              </ul>
            </CtAlert>
            <CtCard title="Documento tributario" padding="md" class="documento">
              <CtAlert tone="info" compact title="El documento lo genera el productor">
                <p class="linea">
                  <CtIcon name="doc" :size="15" />
                  <span>
                    CuTuCo no emite ni administra boletas o facturas electrónicas. Guardamos tu
                    selección y la enviamos al productor junto con el pedido para que genere el
                    documento que corresponda; la plataforma enviará el detalle de la compra a tu
                    correo.
                  </span>
                </p>
              </CtAlert>

              <CtSelect
                v-model="documento.tipo"
                label="¿Boleta o factura?"
                :options="opcionesDocumento"
              />

              <template v-if="documento.tipo === 'factura'">
                <div class="formulario__fila documento__rut">
                  <CtInput
                    v-model="documento.rut_empresa"
                    label="RUT de la empresa"
                    placeholder="76123456-7"
                    required
                    :error="mostrarErroresFactura ? erroresFactura.rut_empresa : null"
                  />
                  <CtButton
                    variant="secondary"
                    size="sm"
                    :loading="buscandoRut"
                    @click="autocompletarEmpresa"
                  >
                    <template #icon><CtIcon name="search" :size="15" /></template>
                    Autocompletar con RUT
                  </CtButton>
                </div>
                <div class="formulario__fila">
                  <CtInput
                    v-model="documento.razon_social"
                    label="Razón social"
                    required
                    maxlength="200"
                    :error="mostrarErroresFactura ? erroresFactura.razon_social : null"
                  />
                  <CtInput
                    v-model="documento.giro"
                    label="Giro"
                    required
                    maxlength="200"
                    :error="mostrarErroresFactura ? erroresFactura.giro : null"
                  />
                </div>
                <CtInput
                  v-model="documento.direccion_tributaria"
                  label="Dirección tributaria"
                  placeholder="Av. Ejemplo 1234, Santiago"
                  required
                  :maxlength="LIMITES.calle"
                  :error="mostrarErroresFactura ? erroresFactura.direccion_tributaria : null"
                />
              </template>
            </CtCard>

            <CtAlert tone="info" compact title="Pago seguro con Webpay Mall">
              <p class="linea">
                <CtIcon name="lock" :size="15" />
                <span>
                  Pagas de forma segura con Webpay. El productor recibe el pago de su venta y la
                  comisión de CuTuCo se descuenta al productor, sin aumentar tu total.
                </span>
              </p>
            </CtAlert>
            <div class="revision__acciones">
              <CtButton variant="ghost" @click="irAPaso(0)">
                <template #icon><CtIcon name="chevronLeft" :size="15" /></template>
                Volver al despacho
              </CtButton>
              <CtButton @click="irAPaso(2)">
                Ir a la revisión final
                <template #trailing><CtIcon name="chevronRight" :size="16" /></template>
              </CtButton>
            </div>
          </div>

          <!-- ================= REVISIÓN ================= -->
          <div v-show="pasoActual === 2" class="revision">
            <div class="revision__lista">
               <div v-for="item in cart.items" :key="item.productoId" class="revision__item">
                <div class="stack stack--xs">
                  <span class="font-semibold">{{ item.nombre }}</span>
                  <span class="text-xs text-muted">
                    {{ formatCLP(item.precio) }} / {{ LABELS.unidad[item.unidad] ?? item.unidad }} ×
                    {{ formatCantidad(item.cantidad, item.unidad) }}
                  </span>
                </div>
                <span class="font-semibold">{{ formatCLP(item.precio * item.cantidad) }}</span>
              </div>
            </div>

            <div class="revision__bloque">
              <span class="eyebrow">Documento solicitado</span>
              <p class="revision__valor">
                {{ documento.tipo === 'factura' ? 'Factura' : 'Boleta' }} · el productor genera el
                documento; CuTuCo no emite factura electrónica.
              </p>
            </div>

            <CtAlert v-if="sinStockProductos.length" tone="danger" title="Hay productos sin stock">
              <p class="linea">
                <CtIcon name="alert" :size="16" />
                <span>
                  No pudimos continuar con
                  {{ sinStockProductos.join(', ') }}. Ajusta tu carrito antes de pagar.
                </span>
              </p>
              <CtButton size="sm" variant="secondary" to="/carrito">Revisar el carrito</CtButton>
            </CtAlert>

            <CtAlert tone="neutral" compact title="Términos y condiciones">
              <p class="linea">
                <CtIcon name="doc" :size="15" />
                <span>
                  Confirmas que los datos de despacho son correctos y aceptas los términos de CuTuCo
                  y el pago seguro con Webpay Mall.
                </span>
              </p>
              <router-link to="/terminos" class="revision__enlace">Ver términos y condiciones</router-link>
            </CtAlert>

            <CtCheckbox
              v-model="aceptaTerminos"
              label="Acepto los términos y condiciones de CuTuCo"
              description="La aceptación es obligatoria y se registra antes de iniciar el pago."
              :error="errorTerminos"
            />

            <div class="revision__acciones">
              <CtButton variant="ghost" :disabled="submitting" @click="irAPaso(1)">
                <template #icon><CtIcon name="chevronLeft" :size="15" /></template>
                Volver
              </CtButton>
              <CtButton
                size="lg"
                :loading="submitting"
                :disabled="!puedePagar"
                @click="continuarAlPago"
              >
                <template #icon><CtIcon name="lock" :size="16" /></template>
                Continuar al Pago
              </CtButton>
            </div>
          </div>
        </CtCard>

        <CtCard title="Despacho logístico" padding="md">
          <div class="logistica">
            <div class="logistica__item">
              <span class="logistica__icono"><CtIcon name="truck" :size="18" /></span>
              <div>
                <p class="logistica__titulo">Seguimiento con estados</p>
                <p class="logistica__texto">
                  Preparación, En tránsito y Entregado, con la fecha de cada cambio.
                </p>
              </div>
            </div>
            <div class="logistica__item">
              <span class="logistica__icono"><CtIcon name="shieldCheck" :size="18" /></span>
              <div>
                <p class="logistica__titulo">Entrega con código</p>
                <p class="logistica__texto">
                  El vendedor valida el código que le entregas al recibir el pedido y cierra la
                  entrega.
                </p>
              </div>
            </div>
            <div class="logistica__item">
              <span class="logistica__icono"><CtIcon name="pin" :size="18" /></span>
              <div>
                <p class="logistica__titulo">Cobertura por región</p>
                <p class="logistica__texto">
                  Comparamos tu región con la del vendedor antes de crear el pago.
                </p>
              </div>
            </div>
          </div>
        </CtCard>
      </div>

      <!-- ================= Resumen de compra ================= -->
      <aside class="checkout__aside stack">
        <CtCard title="Resumen de Compra" padding="md">
          <div class="resumen">
            <div v-for="item in cart.items" :key="item.productoId" class="resumen__item">
              <div class="resumen__datos">
                <span class="resumen__nombre">{{ item.nombre }}</span>
                <span class="resumen__meta">
                  {{ formatCantidad(item.cantidad, item.unidad) }}
                  {{ LABELS.unidad[item.unidad] ?? item.unidad }} ×
                  {{ formatCLP(item.precio) }}
                </span>
              </div>
              <span class="resumen__subtotal">{{ formatCLP(item.precio * item.cantidad) }}</span>
            </div>
          </div>

          <div class="totales">
            <div class="totales__fila">
              <span>Productos (neto)</span>
              <span class="totales__valor">{{ formatCLP(subtotal) }}</span>
            </div>
            <div class="totales__fila">
              <span>Despacho ({{ despachosPorProductor.length }} × {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }})</span>
              <span class="totales__valor">{{ formatCLP(costoEnvio) }}</span>
            </div>
            <div
              v-for="despacho in despachosPorProductor"
              :key="despacho.productorId"
              class="totales__fila is-suave"
            >
              <span>Despacho · {{ despacho.productorNombre }}</span>
              <span class="totales__valor">{{ formatCLP(despacho.monto) }}</span>
            </div>
            <div v-if="tasaIva" class="totales__fila">
              <span>IVA ({{ tasaIva * 100 }}% sobre {{ formatCLP(baseImponible) }})</span>
              <span class="totales__valor">{{ formatCLP(iva) }}</span>
            </div>
            <div class="totales__fila is-suave">
              <span>
                Comisión de CuTuCo ({{ REGLAS.TARIFAS.feePlataforma * 100 }}%, se descuenta al
                productor y no se suma al total)
              </span>
              <span class="totales__valor">{{ formatCLP(comision) }}</span>
            </div>
            <div class="totales__separador" />
            <div class="totales__fila is-total">
              <span>{{ tasaIva ? 'Total a pagar (IVA incluido)' : 'Total a pagar' }}</span>
              <span class="totales__total">{{ formatCLP(total) }}</span>
            </div>
          </div>

          <p class="resumen__nota">
            <CtIcon name="shieldCheck" :size="14" />
            <span>Compra protegida por CuTuCo: el pago se procesa de forma segura con Webpay Mall.</span>
          </p>

          <CtBadge tone="primary" class="resumen__badge">
            <template #icon><CtIcon name="lock" :size="13" /></template>
            Pago seguro con Webpay Mall
          </CtBadge>

          <CtAlert tone="info" compact>
            <p class="linea">
              <CtIcon name="info" :size="15" />
              <span>
                El despacho total es {{ formatCLP(costoEnvio) }}: {{ despachosPorProductor.length }}
                despacho{{ despachosPorProductor.length === 1 ? '' : 's' }} de
                {{ formatCLP(REGLAS.TARIFAS.deliveryDefecto) }} por productor.
                Del pago se asignan {{ formatCLP(total - comision) }} a los vendedores,
                descontada la comisión del 5% de CuTuCo sobre los productos.
                Este detalle explica cómo se distribuye el pago entre las tiendas de tu compra.
              </span>
            </p>
          </CtAlert>

          <CtSpinner v-if="sincronizando" inline :size="18" label="Sincronizando precios y stock" />
        </CtCard>
      </aside>
    </div>

    <!-- Formulario oculto: Webpay exige recibir token_ws por POST. -->
    <form ref="formWebpay" :action="webpay.url" method="post" class="webpay">
      <input type="hidden" name="token_ws" :value="webpay.token" />
    </form>

    <!-- El precio del catálogo cambió: no se cobra hasta que el cliente acepte. -->
    <CtModal v-model="modalPrecios" title="Los precios cambiaron" size="md">
      <div class="stack">
        <CtAlert tone="warning" compact title="Revisa el total actualizado">
          <p>
            El productor actualizó el precio mientras revisabas tu pedido. Acepta el nuevo total
            para continuar con el pago o vuelve al carrito.
          </p>
        </CtAlert>
        <ul class="cambios">
          <li v-for="cambio in cambiosPrecio" :key="cambio.productoId" class="cambio">
            <span class="cambio__nombre">{{ cambio.nombre }}</span>
            <span class="cambio__precios">
              {{ formatCLP(cambio.anterior) }} → <strong>{{ formatCLP(cambio.nuevo) }}</strong>
            </span>
          </li>
        </ul>
        <div class="totales__fila is-total">
          <span>Nuevo total a pagar</span>
          <span class="totales__total">{{ formatCLP(total) }}</span>
        </div>
      </div>
      <template #footer>
        <CtButton variant="secondary" to="/carrito">Volver al carrito</CtButton>
        <CtButton @click="aceptarPreciosActualizados">Aceptar y continuar</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.webpay {
  display: none;
}

.volver {
  margin-bottom: var(--ct-space-2);
  margin-inline-start: calc(-1 * var(--ct-space-3));
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.checkout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

@media (max-width: 1100px) {
  .checkout {
    grid-template-columns: minmax(0, 1fr);
  }
}

.formulario {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.formulario__fila {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--ct-space-4);
}

.formulario__continuar {
  align-self: flex-start;
}

.documento {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.documento__rut {
  align-items: flex-end;
}

.revision {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.revision__bloque {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.revision__valor {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.revision__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.checkout__despachos {
  display: grid;
  gap: var(--ct-space-1);
  margin: var(--ct-space-2) 0 0 24px;
  padding: 0;
  list-style: none;
  font-size: var(--ct-fs-sm);
}

.checkout__despachos li {
  display: flex;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.revision__enlace {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-primary-strong);
}

.revision__lista {
  display: flex;
  flex-direction: column;
}

.revision__item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-3) 0;
  border-bottom: 1px solid var(--ct-border);
}

.revision__item:last-child {
  border-bottom: none;
}

.revision__acciones {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.logistica {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--ct-space-5);
}

.logistica__item {
  display: flex;
  gap: var(--ct-space-3);
}

.logistica__icono {
  width: 36px;
  height: 36px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  display: grid;
  place-items: center;
}

.logistica__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.logistica__texto {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
  margin-top: 2px;
}

.resumen {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
}

.resumen__item {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.resumen__datos {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.resumen__nombre {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.resumen__meta {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.resumen__subtotal {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  white-space: nowrap;
}

.totales {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding-top: var(--ct-space-4);
}

.totales__fila {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
}

.totales__fila.is-suave {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-muted);
}

.totales__valor {
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text);
}

.totales__separador {
  height: 1px;
  background: var(--ct-border);
  margin: var(--ct-space-2) 0;
}

.totales__fila.is-total {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.totales__total {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
  color: var(--ct-primary-strong);
}

.resumen__nota {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  margin: var(--ct-space-4) 0;
  padding: var(--ct-space-2) var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  /* El mensaje usa texto e icono blancos; el fondo debe darles contraste. */
  background: var(--ct-primary-fill);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-invert);
}

.resumen__badge {
  margin-bottom: var(--ct-space-4);
}

.cambios {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.cambio {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-2);
  border-bottom: 1px solid var(--ct-border);
}

.cambio__nombre {
  min-width: 0;
  overflow-wrap: anywhere;
  font-weight: var(--ct-fw-medium);
}

.cambio__precios {
  white-space: nowrap;
  color: var(--ct-text-soft);
}
</style>
