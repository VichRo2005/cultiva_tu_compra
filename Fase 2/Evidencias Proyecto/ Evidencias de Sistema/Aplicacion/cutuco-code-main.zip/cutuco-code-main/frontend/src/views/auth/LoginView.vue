<script setup>
/** CuTuCo — Inicio de sesión (página 3 del diseño). */
import { computed, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import { emailPolicyMessage, isEmail, LIMITES } from '@/lib/validation'
import { DEV_GALLERY_ENABLED, DEV_PASSWORD, DEV_SESSIONS } from '@/dev/devGallery'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const ui = useUiStore()

const form = reactive({ email: '', password: '' })
const errores = reactive({ email: null, password: null })
const enviando = ref(false)

/**
 * Cuentas de prueba del seed local (`supabase/seed.sql`). Sólo se muestran
 * cuando la galería de desarrollo está activa (`VITE_DEV_GALLERY=true`); en
 * operación normal el usuario ingresa con su propia cuenta.
 */
const CUENTAS_DEMO = DEV_SESSIONS.map((s) => ({ rol: s.label, email: s.email, icon: s.icon }))
const PASSWORD_DEMO = DEV_PASSWORD

/**
 * B1 (RF-021): un vendedor cuya postulación no está aprobada llega, al iniciar
 * sesión, a la pantalla coherente con su estado (/mi-postulacion) en lugar del
 * catálogo; el router aplica la misma regla para accesos directos.
 */
const destinoSegunEstado = computed(() => {
  if (auth.estaSuspendido) return '/vendedor/sanciones'
  if (auth.enPostulacion || auth.postulacionPendiente || auth.postulacionRechazada) {
    return '/mi-postulacion'
  }
  return null
})

/** Mensaje visible cuando el guard cerró una sesión por estado de cuenta. */
const mensajeBloqueo = computed(() => {
  const estado = route.query.bloqueado
  if (estado === 'baneado') {
    return 'Tu cuenta tiene un ban permanente y no puede iniciar sesión.'
  }
  if (estado === 'eliminado') {
    return 'Tu cuenta fue eliminada permanentemente y no se puede reactivar.'
  }
  if (estado === 'desactivado') {
    return 'Tu cuenta está desactivada. Contacta al administrador.'
  }
  return null
})

/** LOG-FRM-014/015: en login no se exige complejidad, sólo el máximo y ASCII. */
function passwordLoginMessage(valor) {
  const s = String(valor ?? '')
  if (!s.trim()) return 'Ingresa tu contraseña'
  if (s.length > LIMITES.password) {
    return `La contraseña no puede superar ${LIMITES.password} caracteres`
  }
  if (!/^[\x20-\x7e]+$/.test(s)) {
    return 'La contraseña sólo puede usar caracteres ASCII (sin tildes, ñ, emojis ni símbolos Unicode)'
  }
  return null
}

function validar() {
  errores.email = null
  errores.password = null
  if (!String(form.email ?? '').trim()) errores.email = 'Ingresa tu correo'
  else if (!isEmail(form.email)) errores.email = emailPolicyMessage(form.email)
  errores.password = passwordLoginMessage(form.password)
  return !errores.email && !errores.password
}

/** Sólo se acepta un destino interno: nunca una URL absoluta ni `//host`. */
function destinoSeguro(valor) {
  const ruta = typeof valor === 'string' ? valor.trim() : ''
  return ruta.startsWith('/') && !ruta.startsWith('//') ? ruta : null
}

async function enviar() {
  if (enviando.value) return
  if (!validar()) return
  enviando.value = true
  try {
    await auth.signIn({ email: form.email, password: form.password })
    ui.success(`Bienvenido, ${auth.nombreCompleto || 'a CuTuCo'}`)
    const destino = destinoSeguro(route.query.redirect)
    if (destino) router.push(destino)
    else if (destinoSegunEstado.value) router.push(destinoSegunEstado.value)
    else if (auth.isAdmin) router.push('/admin')
    else if (auth.isVendedor) router.push('/vendedor')
    else router.push('/')
  } catch {
    /* el error queda en auth.error */
  } finally {
    enviando.value = false
  }
}

function usarDemo(cuenta) {
  form.email = cuenta.email
  form.password = PASSWORD_DEMO
  errores.email = null
  errores.password = null
}
</script>

<template>
  <AuthLayout title="Bienvenido de nuevo" subtitle="Inicia sesión para comprar y vender en CuTuCo.">
    <nav class="login__tabs" aria-label="Acceso a la plataforma">
      <span class="login__tab is-active" aria-current="page">Iniciar Sesión</span>
      <router-link to="/registro" class="login__tab">Crear Cuenta</router-link>
    </nav>

    <form class="stack stack--lg" novalidate @submit.prevent="enviar">
      <CtAlert v-if="mensajeBloqueo" tone="warning" :title="mensajeBloqueo" />
      <CtAlert v-if="auth.error" tone="danger" :title="auth.error">
        <p v-if="DEV_GALLERY_ENABLED">
          Estas son cuentas de prueba para este equipo. Puedes entrar con cualquiera de ellas desde
          <router-link to="/cuentas-demo">Cuentas de prueba</router-link> sin escribir la
          contraseña.
        </p>
      </CtAlert>

      <CtInput
        v-model="form.email"
        label="Correo Electrónico"
        type="email"
        placeholder="tucorreo@ejemplo.cl"
        :error="errores.email"
        :disabled="enviando"
        :maxlength="LIMITES.email"
        autocomplete="email"
        required
      />

      <CtInput
        v-model="form.password"
        label="Contraseña"
        type="password"
        placeholder="Tu contraseña"
        :error="errores.password"
        :disabled="enviando"
        :maxlength="LIMITES.password"
        autocomplete="current-password"
        required
      />

      <div class="login__row">
        <router-link to="/recuperar-clave" class="login__recuperar">¿Olvidaste tu contraseña?</router-link>
      </div>

      <CtButton type="submit" block size="lg" :loading="enviando">
        Acceder a la Plataforma
      </CtButton>

      <p class="login__pie">
        ¿No tienes una cuenta?
        <router-link to="/registro">Regístrate como Cliente</router-link>
      </p>

      <p class="login__pie">
        ¿Quieres vender en CuTuCo?
        <router-link to="/registro-vendedor">Postula tu tienda</router-link>
      </p>

      <p class="login__pie">
        ¿Sólo quieres mirar?
        <router-link to="/catalogo">Explorar el catálogo sin cuenta</router-link>
      </p>
    </form>

    <CtCard v-if="DEV_GALLERY_ENABLED" padding="sm" class="login__demo">
      <template #header>
        <div class="row row--between">
          <strong class="text-md">Cuentas de prueba locales</strong>
          <CtBadge tone="info" size="sm">Desarrollo</CtBadge>
        </div>
      </template>
      <p class="text-sm text-soft">
        Estas cuentas existen sólo en este entorno de prueba. Selecciona un perfil para
        completar el formulario o entra directo desde
        <router-link to="/cuentas-demo">Cuentas de prueba</router-link>.
      </p>
      <div class="login__demo-list">
        <button
          v-for="cuenta in CUENTAS_DEMO"
          :key="cuenta.email"
          type="button"
          class="login__demo-item"
          @click="usarDemo(cuenta)"
        >
          <span class="login__demo-icon" aria-hidden="true">
            <CtIcon :name="cuenta.icon" :size="16" />
          </span>
          <span class="login__demo-rol">{{ cuenta.rol }}</span>
          <span class="login__demo-email">{{ cuenta.email }}</span>
        </button>
      </div>
      <p class="text-xs text-muted">Contraseña para todas las cuentas: {{ PASSWORD_DEMO }}</p>
    </CtCard>
  </AuthLayout>
</template>

<style scoped>
.login__tabs {
  display: flex;
  gap: var(--ct-space-6);
  border-bottom: 1px solid var(--ct-border);
}

.login__tab {
  padding-bottom: var(--ct-space-3);
  margin-bottom: -1px;
  border-bottom: 2px solid transparent;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
}

.login__tab:hover {
  color: var(--ct-text);
  text-decoration: none;
}

.login__tab.is-active {
  color: var(--ct-primary-strong);
  border-bottom-color: var(--ct-primary);
  font-weight: var(--ct-fw-semibold);
}

.login__row {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
}

.login__recuperar {
  font-size: var(--ct-fs-md);
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-medium);
}

.login__recuperar:hover {
  color: var(--ct-primary-ink);
}

.login__social {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.login__social-line {
  flex: 1;
  height: 1px;
  background: var(--ct-border);
}

.login__social-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
  margin-top: calc(-1 * var(--ct-space-4));
}

.login__recuperar {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
}

.login__pie a,
.login__recuperar {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
}

.login__pie {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  text-align: center;
}

.login__pie a {
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

.login__demo {
  margin-top: var(--ct-space-2);
}

.login__demo-list {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  margin-block: var(--ct-space-3);
}

.login__demo-item {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 2px var(--ct-space-3);
  align-items: center;
  text-align: left;
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-sunken);
  transition:
    border-color var(--ct-transition),
    background-color var(--ct-transition);
}

.login__demo-item:hover {
  border-color: var(--ct-primary);
  background: var(--ct-primary-softer);
}

.login__demo-icon {
  grid-row: span 2;
  width: 32px;
  height: 32px;
  border-radius: var(--ct-radius-sm);
  display: grid;
  place-items: center;
  background: var(--ct-primary-fill);
  color: var(--ct-text-invert);
}

.login__demo-rol {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
}

.login__demo-email {
  grid-column: 2;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

@media (max-width: 520px) {
  .login__social-grid {
    grid-template-columns: minmax(0, 1fr);
    margin-top: 0;
  }
}
</style>
