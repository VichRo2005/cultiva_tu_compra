<script setup>
/**
 * CuTuCo — Tabla de datos reutilizable.
 * `columns`: [{ key, label, align, width, sortable, format }]
 * Se usan slots con nombre `cell-<key>` para contenido enriquecido.
 */
import CtEmptyState from './CtEmptyState.vue'
import CtIcon from './CtIcon.vue'
import CtSpinner from './CtSpinner.vue'

defineProps({
  columns: { type: Array, required: true },
  rows: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  emptyTitle: { type: String, default: 'Sin resultados' },
  emptyMessage: { type: String, default: 'No hay registros para mostrar con los filtros aplicados.' },
  emptyIcon: { type: String, default: 'inventory' },
  rowKey: { type: String, default: 'id' },
  clickable: { type: Boolean, default: false },
  dense: { type: Boolean, default: false },
  stickyHeader: { type: Boolean, default: true },
  minWidth: { type: String, default: '760px' },
  sortBy: { type: String, default: null },
  sortDirection: { type: String, default: 'asc' },
})

const emit = defineEmits(['row-click', 'sort'])

function cell(row, column) {
  if (column.format) return column.format(row[column.key], row)
  return row[column.key] ?? '—'
}
</script>

<template>
  <div class="ct-table__wrapper">
    <div v-if="loading" class="ct-table__loading"><CtSpinner label="Cargando datos" /></div>

    <div v-else-if="!rows.length" class="ct-table__empty">
      <CtEmptyState :icon="emptyIcon" :title="emptyTitle" :message="emptyMessage">
        <slot name="empty-action" />
      </CtEmptyState>
    </div>

    <div v-else class="ct-table__scroll">
      <table class="ct-table" :class="{ 'is-dense': dense, 'is-sticky': stickyHeader }" :style="{ minWidth }">
        <thead>
          <tr>
            <th
              v-for="column in columns"
              :key="column.key"
              :style="{ width: column.width, textAlign: column.align || 'left' }"
              :class="[{ 'is-sortable': column.sortable }, column.headerClass]"
            >
              <button
                v-if="column.sortable"
                type="button"
                class="ct-table__sort"
                @click="emit('sort', column.key)"
              >
                {{ column.label }}
                <span v-if="sortBy === column.key" class="ct-table__sort-icon">
                  <CtIcon :name="sortDirection === 'asc' ? 'arrowUp' : 'arrowDown'" :size="13" />
                </span>
              </button>
              <template v-else>{{ column.label }}</template>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in rows"
            :key="row[rowKey]"
            :class="{ 'is-clickable': clickable }"
            :tabindex="clickable ? 0 : undefined"
            :aria-label="clickable ? 'Abrir detalle de la fila' : undefined"
            @click="clickable && emit('row-click', row)"
            @keydown.enter="clickable && emit('row-click', row)"
            @keydown.space.prevent="clickable && emit('row-click', row)"
          >
            <td v-for="column in columns" :key="column.key" :style="{ textAlign: column.align || 'left' }">
              <slot :name="`cell-${column.key}`" :row="row" :value="cell(row, column)">
                {{ cell(row, column) }}
              </slot>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.ct-table__wrapper {
  position: relative;
  width: 100%;
}

.ct-table__scroll {
  overflow-x: auto;
  border-radius: var(--ct-radius-lg);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
}

.ct-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  font-size: var(--ct-fs-md);
}

.ct-table th {
  text-align: left;
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--ct-text-soft);
  background: var(--ct-surface-alt);
  padding: var(--ct-space-3) var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}

.ct-table.is-sticky th {
  position: sticky;
  top: 0;
  z-index: 2;
}

.ct-table td {
  padding: var(--ct-space-3) var(--ct-space-4);
  border-bottom: 1px solid var(--ct-border);
  vertical-align: middle;
  color: var(--ct-text);
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}

.ct-table.is-dense td {
  padding: var(--ct-space-2) var(--ct-space-3);
}

.ct-table tbody tr:last-child td {
  border-bottom: none;
}

.ct-table tbody tr {
  transition: background-color var(--ct-transition);
}

.ct-table tbody tr:hover {
  background: var(--ct-primary-softer);
}

.ct-table tbody tr.is-clickable {
  cursor: pointer;
}

.ct-table tbody tr.is-clickable:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: -2px;
}

.ct-table__sort {
  min-height: 24px;
  padding-block: 2px;
  padding-inline: 2px;
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-1);
  color: inherit;
  font: inherit;
  text-transform: inherit;
  letter-spacing: inherit;
  white-space: nowrap;
}

.ct-table__sort-icon {
  display: inline-flex;
  flex-shrink: 0;
}

.ct-table__sort:hover {
  color: var(--ct-primary-strong);
}

.ct-table__loading,
.ct-table__empty {
  padding: var(--ct-space-10) var(--ct-space-4);
  display: grid;
  place-items: center;
}
</style>
