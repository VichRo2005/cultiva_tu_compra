import { getClient } from '@/lib/supabase'
import { currentUserId } from '@/services/session'
import { adminResult as unwrap } from '@/services/adminErrores'
import { ACCION_SANCION, ESTADO_SANCION, TIPO_SANCION } from '@/lib/constants'
export async function listSanciones({
  estado = null,
  productorId = null,
  tipo = null,
  accion = null,
  texto = '',
} = {}) {
  const client = getClient()
  let query = client.from('sanciones').select('*')
  if (tipo) query = query.eq('tipo', tipo)
  if (accion) query = query.eq('accion', accion)
  if (estado) query = query.eq('estado', estado)
  if (productorId) query = query.eq('productor_id', productorId)
  const { data, error } = await query.order('inicio_en', { ascending: false })
  if (error) unwrap({ error })
  return filtrarSanciones(await hidratarSanciones(data ?? []), { texto })
}

export async function hidratarSanciones(sanciones) {
  if (!sanciones.length) return []
  const client = getClient()
  const ids = [...new Set(sanciones.map((s) => s.productor_id))]
  const productores = unwrap(await client.from('productores').select('*').in('id', ids))
  const perfilIds = (productores ?? []).map((p) => p.perfil_id)
  const perfiles = perfilIds.length
    ? unwrap(await client.from('perfiles').select('id, nombre, apellido').in('id', perfilIds))
    : []
  const apelaciones = unwrap(await client.from('apelaciones').select('*').in('productor_id', ids))

  const productorMap = new Map((productores ?? []).map((p) => [p.id, p]))
  const perfilMap = new Map((perfiles ?? []).map((p) => [p.id, p]))

  return sanciones.map((sancion) => {
    const productor = productorMap.get(sancion.productor_id) ?? null
    return {
      ...sancion,
      productor,
      perfil: productor ? (perfilMap.get(productor.perfil_id) ?? null) : null,
      apelacion: (apelaciones ?? []).find((a) => a.sancion_id === sancion.id) ?? null,
    }
  })
}

/** Conteo de amonestaciones vigentes del vendedor (RF-026). */
export async function contarAmonestaciones(productorId) {
  const client = getClient()
  const result = await client
    .from('sanciones')
    .select('id, numero_amonestacion')
    .eq('productor_id', productorId)
    .eq('tipo', TIPO_SANCION.AMONESTACION)
    .in('estado', [ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA])
  const data = unwrap(result)
  const numeros = (data ?? []).map((s) => Number(s.numero_amonestacion ?? 0)).filter(Boolean)
  return {
    total: (data ?? []).length,
    ultimoNumero: numeros.length ? Math.max(...numeros) : 0,
  }
}

/**
 * Registra una sanción manual (RF-026).
 *  - amonestación: número correlativo y duración opcional en días
 *  - suspensión: duración obligatoria en días
 *  - ban permanente: suspensión sin fecha de término
 * El trigger `aplicar_efecto_sancion` desactiva la cuenta del vendedor cuando
 * corresponde.
 */
export async function crearSancion({ productorId, tipo, accion, motivo, duracionDias = null }) {
  const client = getClient()
  const adminId = await currentUserId()
  validarSancion({ productorId, tipo, accion, motivo, duracionDias })
  if (accion === ACCION_SANCION.BAN_PERMANENTE && (await tieneBanPermanente(productorId))) {
    throw new Error('Este usuario ya tiene un ban permanente activo.')
  }

  if (!motivo?.trim()) throw new Error('La sanción requiere un motivo')

  const payload = {
    productor_id: productorId,
    tipo,
    accion,
    estado: ESTADO_SANCION.ACTIVA,
    motivo: motivo.trim(),
    duracion_dias: duracionDias ? Number(duracionDias) : null,
    impuesta_por: adminId,
    numero_amonestacion: null,
  }

  if (tipo === TIPO_SANCION.AMONESTACION) {
    const { ultimoNumero } = await contarAmonestaciones(productorId)
    payload.numero_amonestacion = ultimoNumero + 1
    payload.accion = ACCION_SANCION.NINGUNA
    payload.duracion_dias = null
  }

  if (tipo === TIPO_SANCION.SUSPENSION) {
    if (accion === ACCION_SANCION.SUSPENDER && !payload.duracion_dias) {
      throw new Error('La suspensión necesita una duración en días')
    }
    if (accion === ACCION_SANCION.BAN_PERMANENTE) payload.duracion_dias = null
  }

  return unwrap(
    await client.from('sanciones').insert(payload).select().single(),
    'No se pudo registrar la sanción',
  )
}

/** Cierra, cancela o expira una sanción. */
export async function resolverSancion(sancionId, estado = ESTADO_SANCION.CANCELADA) {
  if (estado !== ESTADO_SANCION.CANCELADA)
    throw new Error('Resuelve la sanción desde su apelación o mediante Reactivar cuenta.')
  const client = getClient()
  const sancion = unwrap(await client.from('sanciones').select('*').eq('id', sancionId).single())
  if (sancion.accion === ACCION_SANCION.BAN_PERMANENTE)
    throw new Error('Usa Reactivar cuenta para levantar un ban permanente.')
  if (!['activa', 'apelada'].includes(sancion.estado))
    throw new Error('Esta sanción ya está cerrada.')
  return unwrap(
    await client
      .from('sanciones')
      .update({ estado, resuelta_en: new Date().toISOString() })
      .eq('id', sancionId)
      .select()
      .single(),
    'No se pudo actualizar la sanción',
  )
}

/** Apelaciones del vendedor: revisión manual del administrador (RF-026). */

// Valores verificados contra 20261004021917_nuevo_alcance.sql.
export function filtrarSanciones(rows, { texto = '', tipo = '', accion = '', estado = '' } = {}) {
  const term = texto.trim().toLocaleLowerCase('es')
  return rows.filter(
    (s) =>
      (!tipo || s.tipo === tipo) &&
      (!accion || s.accion === accion) &&
      (!estado || s.estado === estado) &&
      [s.id, s.motivo, s.productor?.nombre_comercial, s.perfil?.nombre, s.perfil?.apellido].some(
        (v) =>
          String(v ?? '')
            .toLocaleLowerCase('es')
            .includes(term),
      ),
  )
}
export function validarSancion({ productorId, tipo, accion, motivo, duracionDias }) {
  if (!productorId) throw new Error('Selecciona un vendedor.')
  if (!motivo?.trim()) throw new Error('La sanción requiere un motivo')
  if (
    !Object.values(TIPO_SANCION).includes(tipo) ||
    !Object.values(ACCION_SANCION).includes(accion) ||
    (tipo === TIPO_SANCION.AMONESTACION) !== (accion === ACCION_SANCION.NINGUNA)
  ) {
    unwrap({ error: { message: 'ck_sancion_accion_coherente' } })
  }
  if (
    accion === ACCION_SANCION.SUSPENDER &&
    (!/^\d+$/.test(String(duracionDias)) ||
      !Number.isInteger(Number(duracionDias)) ||
      Number(duracionDias) < 1 ||
      Number(duracionDias) > 60)
  ) {
    throw new Error('La duración debe ser un número entero entre 1 y 60 días')
  }
}
export async function contarSancionesVigentes(productorId) {
  const result = await getClient()
    .from('sanciones')
    .select('id', { count: 'exact', head: true })
    .eq('productor_id', productorId)
    .in('estado', ['activa', 'apelada'])
  unwrap(result)
  return result.count
}
export async function tieneBanPermanente(productorId) {
  if (!productorId) return false
  const rows = unwrap(
    await getClient()
      .from('sanciones')
      .select('id')
      .eq('productor_id', productorId)
      .eq('accion', 'ban_permanente')
      .in('estado', ['activa', 'apelada']),
  )
  return rows.length > 0
}
export async function reactivarCuentaPermanente(sancionId) {
  return unwrap(await getClient().rpc('reactivar_cuenta_permanente', { p_sancion_id: sancionId }))
}
