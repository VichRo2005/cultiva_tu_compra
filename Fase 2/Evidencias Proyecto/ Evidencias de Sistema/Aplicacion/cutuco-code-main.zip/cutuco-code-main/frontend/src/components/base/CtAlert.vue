<script setup>
/** CuTuCo — Alerta / mensaje informativo con tonos semánticos. */
import { computed } from 'vue'
import CtIcon from './CtIcon.vue'
import { resolveIconName } from '@/lib/icons'

const props = defineProps({
  tone: { type: String, default: 'info' }, // info | success | warning | danger | neutral
  title: { type: String, default: null },
  icon: { type: String, default: null },
  compact: { type: Boolean, default: false },
  dismissible: { type: Boolean, default: false },
})

const emit = defineEmits(['dismiss'])

const ICONS = {
  info: 'info',
  success: 'check',
  warning: 'alert',
  danger: 'ban',
  neutral: 'info',
}

const nombreIcono = () => resolveIconName(props.icon) ?? ICONS[props.tone] ?? 'info'

/** Los errores se anuncian de inmediato; el resto, cuando el lector termina. */
const rolAnuncio = computed(() => (props.tone === 'danger' ? 'alert' : 'status'))
</script>

<template>
  <div class="ct-alert" :class="[`ct-alert--${tone}`, { 'is-compact': compact }]" :role="rolAnuncio">
    <span class="ct-alert__icon" aria-hidden="true">
      <CtIcon :name="nombreIcono()" :size="18" />
    </span>
    <div class="ct-alert__content">
      <p v-if="title" class="ct-alert__title">{{ title }}</p>
      <div class="ct-alert__body"><slot /></div>
    </div>
    <button
      v-if="dismissible"
      type="button"
      class="ct-alert__close"
      aria-label="Cerrar"
      @click="emit('dismiss')"
    >
      <CtIcon name="close" :size="15" />
    </button>
  </div>
</template>

<style scoped>
.ct-alert {
  display: flex;
  gap: var(--ct-space-3);
  align-items: flex-start;
  padding: var(--ct-space-4);
  border-radius: var(--ct-radius-md);
  border: 1px solid transparent;
  font-size: var(--ct-fs-md);
}

.ct-alert.is-compact {
  padding: var(--ct-space-2) var(--ct-space-3);
  font-size: var(--ct-fs-sm);
}

.ct-alert--info {
  background: var(--ct-info-soft);
  border-color: var(--ct-info-border);
  color: var(--ct-info-ink);
}
.ct-alert--success {
  background: var(--ct-success-soft);
  border-color: var(--ct-success-border);
  color: var(--ct-success-ink);
}
.ct-alert--warning {
  background: var(--ct-warning-soft);
  border-color: var(--ct-warning-border);
  color: var(--ct-warning-ink);
}
.ct-alert--danger {
  background: var(--ct-danger-soft);
  border-color: var(--ct-danger-border);
  color: var(--ct-danger-strong);
}
.ct-alert--neutral {
  background: var(--ct-surface-alt);
  border-color: var(--ct-border);
  color: var(--ct-text-soft);
}

.ct-alert :deep(a),
.ct-alert a {
  color: inherit;
  text-decoration: underline;
  font-weight: var(--ct-fw-medium);
}

.ct-alert__content {
  flex: 1;
  min-width: 0;
}

.ct-alert__title {
  font-weight: var(--ct-fw-semibold);
  margin-bottom: 2px;
}

.ct-alert__body :deep(p) {
  margin: 0;
  line-height: 1.5;
}

.ct-alert__icon {
  display: grid;
  place-items: center;
  flex-shrink: 0;
  margin-top: 1px;
}
</style>
