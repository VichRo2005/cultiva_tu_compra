/**
 * CuTuCo — Perfil de tienda del vendedor (RF-021, RF-009 y RF-024).
 *
 * Regresión: `watch([productor, tienda], hidratar, { immediate: true })` se
 * declaraba ANTES que las refs que `hidratar` escribe (`banco`, `direccionForm`,
 * `telefono`). Con un vendedor ya autenticado (`auth.productor` cargado) el watch
 * inmediato ejecutaba `hidratar()` durante el `setup` y lanzaba
 * «Cannot access 'banco' before initialization» → la página quedaba en blanco.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

const sellerMock = vi.hoisted(() => ({
  getMiProductor: vi.fn(),
  getMiPostulacion: vi.fn(),
  getTiendaConUbicacion: vi.fn(),
  getDatosBancarios: vi.fn(),
  guardarDatosBancarios: vi.fn(),
  updateTienda: vi.fn(),
  listSancionesDeProductor: vi.fn(),
}))

const geoMock = vi.hoisted(() => ({
  getJerarquiaGeografica: vi.fn(),
  getComuna: vi.fn(),
  getRegion: vi.fn(),
  updateDireccion: vi.fn(),
  listRegiones: vi.fn(),
  listComunas: vi.fn(),
}))

const ordersMock = vi.hoisted(() => ({
  getReputacionProductor: vi.fn(),
}))

vi.mock('@/services/seller', () => sellerMock)
vi.mock('@/services/geography', () => geoMock)
vi.mock('@/services/orders', () => ordersMock)

import SellerStoreProfileView from '@/views/seller/SellerStoreProfileView.vue'
import { useAuthStore } from '@/stores/auth'

const REGION = { id: 'r-rm', nombre: 'Región Metropolitana de Santiago' }
const COMUNA = { id: 'c-paine', nombre: 'Paine', region_id: REGION.id }
const PRODUCTOR = {
  id: 'p-1',
  perfil_id: 'u-1',
  nombre_comercial: 'Huerta del Desarrollador',
  descripcion: 'Productos de la zona',
  activo: true,
}

const stubs = { RouterLink: { template: '<a><slot /></a>' } }

/** Deja la sesión como la de un vendedor con tienda: es lo que dispara el fallo. */
function sesionDeVendedor() {
  const auth = useAuthStore()
  auth.productor = { ...PRODUCTOR }
  auth.perfil = { id: 'u-1', nombre: 'Verónica', apellido: 'Del Campo', telefono: '+56900000101' }
  return auth
}

function montar() {
  return mount(SellerStoreProfileView, { global: { stubs } })
}

beforeEach(() => {
  setActivePinia(createPinia())
  vi.clearAllMocks()
  sellerMock.getMiProductor.mockResolvedValue({ ...PRODUCTOR })
  sellerMock.getMiPostulacion.mockResolvedValue(null)
  sellerMock.listSancionesDeProductor.mockResolvedValue([])
  sellerMock.getDatosBancarios.mockResolvedValue({
    id: 'db-1',
    banco: 'Santander',
    tipo_cuenta: 'cuenta_corriente',
    numero_cuenta_enmascarado: '****0101',
    titular_cuenta: 'Verónica Del Campo',
    rut_titular: '11000002-2',
    activo: true,
  })
  sellerMock.getTiendaConUbicacion.mockResolvedValue({
    productor: { ...PRODUCTOR },
    direccion: {
      id: 'd-1',
      etiqueta: 'Predio Paine',
      comuna_id: COMUNA.id,
      calle: 'Camino Rural',
      numero: '10',
      referencia: 'Portón verde',
      es_principal: true,
      activo: true,
      region: REGION,
    },
  })
  ordersMock.getReputacionProductor.mockResolvedValue({ puntaje: 5, cantidad: 1 })
  geoMock.getJerarquiaGeografica.mockResolvedValue([{ ...REGION, comunas: [COMUNA] }])
  geoMock.getComuna.mockResolvedValue(COMUNA)
  geoMock.getRegion.mockResolvedValue(REGION)
})

describe('Vendedor · Perfil de tienda', () => {
  it('se monta con un vendedor autenticado (antes dejaba la página en blanco)', async () => {
    sesionDeVendedor()
    const wrapper = montar()
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Huerta del Desarrollador')
    // Las tres pestañas existen
    expect(texto).toContain('Información de Tienda')
    expect(texto).toContain('Datos bancarios y ubicación')
    expect(texto).toContain('Contraseña y solicitud')
  })

  it('recorre las tres pestañas sin romperse', async () => {
    sesionDeVendedor()
    const wrapper = montar()
    await flushPromises()

    const tab = (etiqueta) =>
      wrapper.findAll('[role="tab"]').find((b) => b.text().includes(etiqueta))

    // Pestaña 2: ubicación y datos bancarios
    await tab('Datos bancarios y ubicación').trigger('click')
    await flushPromises()
    let texto = wrapper.text()
    expect(texto).toContain('Ubicación de despacho')
    expect(texto).toContain('Datos bancarios')
    expect(texto).toContain('Santander')

    // Pestaña 3: contraseña y solicitud
    await tab('Contraseña y solicitud').trigger('click')
    await flushPromises()
    texto = wrapper.text()
    expect(texto).toContain('Cambio de contraseña')
    expect(texto).toContain('Solicitud de vendedor')

    // Y volver a la primera sigue funcionando
    await tab('Información de Tienda').trigger('click')
    await flushPromises()
    expect(wrapper.text()).toContain('Huerta del Desarrollador')
  })

  it('hidrata la ubicación y el teléfono del vendedor', async () => {
    sesionDeVendedor()
    const wrapper = montar()
    await flushPromises()

    const tab = (etiqueta) =>
      wrapper.findAll('[role="tab"]').find((b) => b.text().includes(etiqueta))
    await tab('Datos bancarios y ubicación').trigger('click')
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Región Metropolitana de Santiago')
    expect(texto).toContain('Paine')
    expect(texto).toContain('Dirección principal')
  })

  it('no revienta si el perfil todavía no tiene productor', async () => {
    const auth = useAuthStore()
    auth.productor = null
    auth.perfil = { id: 'u-2', telefono: null }
    sellerMock.getMiProductor.mockResolvedValue(null)

    const wrapper = montar()
    await flushPromises()

    // Sin tienda aprobada la vista muestra el estado vacío, no las pestañas.
    expect(wrapper.text()).toContain('Todavía no tienes tienda')
  })
})
