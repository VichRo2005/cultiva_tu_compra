<script setup>
/**
 * CuTuCo — Barra lateral persistente. Secciones General / Vendedor /
 * Administración según el rol del usuario (RF-001) y pie con el perfil y el
 * cierre de sesión; todo sale de `@/lib/navigation`.
 */
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtIcon from '@/components/base/CtIcon.vue'
import { isItemActive, footerPara, inicioPorRol, visibleSections } from '@/lib/navigation'
import { useAuthStore } from '@/stores/auth'
import { bloquearSesionAutomatica, DEV_GALLERY_ENABLED } from '@/dev/devGallery'
import { useUiStore } from '@/stores/ui'

defineProps({
  open: { type: Boolean, default: true },
})

const emit = defineEmits(['navigate'])

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const ui = useUiStore()
const accesoSoloPostulacion = computed(() => auth.enPostulacion || auth.postulacionRechazada)

const secciones = computed(() => {
  const visibles = visibleSections(auth.rol, { isAuthenticated: auth.isAuthenticated }).map((seccion) => ({
    ...seccion,
    // La solicitud no es una función general de una cuenta cliente o vendedor:
    // se muestra únicamente después de que la persona inició su postulación.
    items: seccion.items.filter((item) => item.to !== '/mi-postulacion' || Boolean(auth.postulacion)),
  }))
  // LOG-NEG-003/005: la suspensión sólo habilita amonestaciones y una
  // postulación activa sólo su pantalla; no se muestran accesos que el router
  // va a rechazar.
  const permitidas = auth.estaSuspendido
    ? ['/vendedor/sanciones']
    : accesoSoloPostulacion.value
      ? ['/mi-postulacion']
      : null
  if (!permitidas) return visibles.filter((seccion) => seccion.items.length > 0)
  return visibles
    .map((seccion) => ({
      ...seccion,
      items: seccion.items.filter((item) => permitidas.includes(item.to)),
    }))
    .filter((seccion) => seccion.items.length > 0)
})

const inicio = computed(() => {
  if (auth.estaSuspendido) return '/vendedor/sanciones'
  if (accesoSoloPostulacion.value) return '/mi-postulacion'
  return inicioPorRol(auth.rol)
})
const pie = computed(() => {
  if (auth.estaSuspendido || accesoSoloPostulacion.value) {
    return [{ action: 'signout', label: 'Cerrar sesión', icon: 'logout' }]
  }
  return footerPara(auth.rol, { isAuthenticated: auth.isAuthenticated })
})

/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el pie estaba escrito a
 * mano en la plantilla (perfil + cerrar sesión). Ahora se recorre `NAV_FOOTER`
 * de `@/lib/navigation` para no duplicar la estructura de navegación.
 */

function cerrar() {
  emit('navigate')
  if (ui.sidebarAbierto) ui.sidebarAbierto = false
}

/**
 * Acciones del pie de la barra lateral. Al cerrar sesión se marca el cierre para
 * que la galería de desarrollo no vuelva a entrar sola y se pueda revisar la
 * aplicación como visitante.
 */
async function onAccion(item) {
  cerrar()
  if (item.action === 'signout') {
    if (DEV_GALLERY_ENABLED) bloquearSesionAutomatica()
    await auth.signOut()
    router.push({ name: 'home' })
  }
}
</script>

<template>
  <aside class="ct-nav" :class="{ 'is-open': open }" aria-label="Navegación principal">
    <router-link :to="inicio" class="ct-nav__brand" @click="cerrar">
      <img
        class="ct-nav__brand-mark"
        src="@/assets/logos/Isotipo_bg.png"
        alt="CuTuCo"
      />
      <strong>CuTuCo</strong>
    </router-link>

    <nav class="ct-nav__scroll" aria-label="Navegación principal">
      <div v-for="seccion in secciones" :key="seccion.key" class="ct-nav__group">
        <p class="ct-nav__label">{{ seccion.label }}</p>
        <router-link
          v-for="item in seccion.items"
          :key="item.to"
          :to="item.to"
          class="ct-nav__link"
          :class="{ 'is-active': isItemActive(item, route.path) }"
          @click="cerrar"
        >
          <CtIcon :name="item.icon" :size="17" />
          <span>{{ item.label }}</span>
        </router-link>
      </div>
    </nav>

    <div class="ct-nav__foot">
      <template v-if="auth.isAuthenticated">
        <template v-for="item in pie" :key="item.label">
          <router-link
            v-if="item.to"
            :to="item.to"
            class="ct-nav__link"
            :class="{ 'is-active': isItemActive(item, route.path) }"
            @click="cerrar"
          >
            <CtIcon :name="item.icon" :size="17" />
            <span>{{ item.label }}</span>
          </router-link>
          <button
            v-else
            type="button"
            class="ct-nav__link ct-nav__link--action"
            @click="onAccion(item)"
          >
            <CtIcon :name="item.icon" :size="17" />
            <span>{{ item.label }}</span>
          </button>
        </template>
      </template>
      <template v-else>
        <router-link to="/login" class="ct-nav__link" @click="cerrar">
          <CtIcon name="user" :size="17" />
          <span>Iniciar sesión</span>
        </router-link>
        <router-link to="/registro" class="ct-nav__link" @click="cerrar">
          <CtIcon name="plus" :size="17" />
          <span>Crear cuenta</span>
        </router-link>
      </template>
    </div>
  </aside>
</template>

<style scoped>
.ct-nav {
  width: var(--ct-sidebar-width);
  flex-shrink: 0;
  background: var(--ct-gradient-sidebar);
  border-right: 1px solid rgba(255, 255, 255, 0.15);
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
  height: 100vh;
  height: 100dvh;
  overflow: hidden;
}

.ct-nav__brand {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  height: var(--ct-header-height);
  padding-inline: var(--ct-space-6);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  color: var(--ct-text-invert);
  flex-shrink: 0;
}

.ct-nav__brand:hover {
  text-decoration: none;
  color: var(--ct-text-invert);
}

.ct-nav__brand-mark {
  width: 32px;
  height: 32px;
  border-radius: var(--ct-radius-md);
  object-fit: contain;
  background: var(--ct-white);
  padding: 2px;
  flex-shrink: 0;
  box-shadow: var(--ct-shadow-sm);
  transform: scale(1.32);
  transform-origin: center;
}

.ct-nav__brand:hover .ct-nav__brand-mark {
  transform: scale(1.05);
}

.ct-nav__brand strong {
  font-size: var(--ct-fs-xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  color: var(--ct-text-invert);
}

.ct-nav__scroll {
  flex: 1;
  overflow-y: auto;
  padding: var(--ct-space-5) var(--ct-space-4) var(--ct-space-4);
}

.ct-nav__group + .ct-nav__group {
  margin-top: var(--ct-space-5);
}

.ct-nav__label {
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-on-dark-muted);
  padding: 0 var(--ct-space-3) var(--ct-space-2);
}

.ct-nav__link {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  width: 100%;
  padding: 0.55rem var(--ct-space-3);
  border-radius: var(--ct-radius);
  color: var(--ct-text-on-dark-soft);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  text-align: left;
  transition:
    background-color var(--ct-transition),
    color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-nav__link:hover {
  background: rgba(255, 255, 255, 0.12);
  color: var(--ct-text-invert);
  text-decoration: none;
}

.ct-nav__link.is-active {
  background: var(--ct-accent);
  color: var(--ct-accent-ink);
  font-weight: var(--ct-fw-semibold);
  box-shadow: inset 3px 0 0 var(--ct-accent-ink);
}

.ct-nav__link.is-active:hover {
  background: var(--ct-accent-hover);
  color: var(--ct-accent-ink);
}

.ct-nav__link--action {
  color: var(--ct-danger);
}

.ct-nav__link--action:hover {
  background: var(--ct-danger-soft);
  color: var(--ct-danger);
}

.ct-nav__foot {
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding: var(--ct-space-3) var(--ct-space-4) var(--ct-space-5);
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex-shrink: 0;
}

@media (max-width: 1024px) {
  .ct-nav {
    position: fixed;
    inset: 0 auto 0 0;
    z-index: var(--ct-z-sidebar);
    transform: translateX(-100%);
    transition: transform var(--ct-transition-slow);
    box-shadow: var(--ct-shadow-lg);
  }

  .ct-nav.is-open {
    transform: translateX(0);
  }
}
</style>

