/**
 * CuTuCo — Correcciones del módulo Vendedor.
 *
 * Cubre los hallazgos HAL-VEN-003/004/005/009/010/013/014/015/016/017/019/026
 * y HAL-REG-008 con pruebas de servicio y de montaje, sin backend:
 *   - pausa con justificación válida (UI + payload + triggers simulados);
 *   - límites técnicos de stock y precio del esquema;
 *   - slug comercial funcional, vacío y con colisión;
 *   - resumen de ventas con poblaciones explícitas (autorizadas/entregadas/neto);
 *   - fechas de cuota derivadas de la regla 10 días + 5 de gracia;
 *   - ubicación única, depto_oficina y titular completo;
 *   - detalle de producto en modo lectura;
 *   - datos de transferencia de CuTuCo y confirmación de copia.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { createMemoryHistory, createRouter } from 'vue-router'

/* ------------------------------------------------------------------ */
/* Mocks                                                               */
/* ------------------------------------------------------------------ */

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
}))

vi.mock('@/lib/supabase', async (importOriginal) => ({
  ...(await importOriginal()),
  ...supabaseMock,
}))

const geoMock = vi.hoisted(() => ({
  getJerarquiaGeografica: vi.fn(),
  getComuna: vi.fn(),
  getRegion: vi.fn(),
  updateDireccion: vi.fn(),
}))

vi.mock('@/services/geography', async (importOriginal) => ({
  ...(await importOriginal()),
  ...geoMock,
}))

const catalogMock = vi.hoisted(() => ({
  listCategorias: vi.fn(),
}))

vi.mock('@/services/catalog', async (importOriginal) => ({
  ...(await importOriginal()),
  ...catalogMock,
}))

const ordersMock = vi.hoisted(() => ({
  getReputacionProductor: vi.fn(),
  listPedidos: vi.fn(),
}))

vi.mock('@/services/orders', () => ordersMock)

const sellerMock = vi.hoisted(() => ({
  getMiProductor: vi.fn(),
  getMiPostulacion: vi.fn(),
  getTiendaConUbicacion: vi.fn(),
  getDatosBancarios: vi.fn(),
  guardarDatosBancarios: vi.fn(),
  listProductosVendedor: vi.fn(),
  getProductoVendedor: vi.fn(),
  listSancionesDeProductor: vi.fn(),
}))

vi.mock('@/services/seller', async (importOriginal) => ({
  ...(await importOriginal()),
  ...sellerMock,
}))

const servicioMock = vi.hoisted(() => ({
  obtenerDatosTransferenciaCutuco: vi.fn(),
  getMiServicio: vi.fn(),
  listPagosServicio: vi.fn(),
  registrarTransferenciaServicio: vi.fn(),
  iniciarPagoServicioWebpay: vi.fn(),
}))

vi.mock('@/services/servicio', async (importOriginal) => ({
  ...(await importOriginal()),
  ...servicioMock,
}))

import SellerDashboardView from '@/views/seller/SellerDashboardView.vue'
import SellerProductFormView from '@/views/seller/SellerProductFormView.vue'
import SellerProductsView from '@/views/seller/SellerProductsView.vue'
import SellerStoreProfileView from '@/views/seller/SellerStoreProfileView.vue'
import {
  desactivarProducto,
  getResumenVentas,
  LIMITES_PRODUCTO,
  mensajeErrorProducto,
  mensajeErrorTienda,
  MOTIVO_PAUSA_POR_DEFECTO,
  MOTIVO_PRODUCTO_MAX,
  reactivarProducto,
  slugTiendaBase,
  slugUnicoTienda,
  updateProducto,
  updateTienda,
  validarMotivoProducto,
} from '@/services/seller'
import { fechasCuotaServicio } from '@/services/servicio'
import { useAuthStore } from '@/stores/auth'
import { formatDate } from '@/lib/format'

/* ------------------------------------------------------------------ */
/* Fixtures y cliente PostgREST simulado                               */
/* ------------------------------------------------------------------ */

const REGION = { id: 'r-v', nombre: 'Valparaíso', codigo: 'V' }
const COMUNA = { id: 'c-quillota', nombre: 'Quillota', region_id: 'r-v' }
const PRODUCTOR = {
  id: 'p1',
  perfil_id: 'u1',
  nombre_comercial: 'Huerta del Sur',
  descripcion: 'Hortalizas de la zona',
  activo: true,
  aprobado_en: '2026-09-01T12:00:00Z',
  servicio_suspendido: false,
}
const PRODUCTO = {
  id: 'prod1',
  productor_id: 'p1',
  categoria_id: 'c1',
  nombre: 'Tomate italiano',
  slug: 'tomate-italiano',
  descripcion: 'Tomate de temporada',
  precio: 2800,
  stock: 10,
  unidad_medida: 'kg',
  activo: true,
  eliminado_en: null,
  motivo_pausa: null,
  motivo_eliminacion: null,
  fecha_cosecha: '2026-10-01',
  creado_en: '2026-09-01T12:00:00Z',
  actualizado_en: '2026-10-01T12:00:00Z',
  imagenes: [
    {
      id: 'img1',
      url: 'https://example.test/tomate.webp',
      ruta_storage: 'prod1/tomate.webp',
      es_principal: true,
      texto_alternativo: 'Tomate',
      nombre_archivo: 'tomate.webp',
    },
  ],
  imagenPrincipal: {
    id: 'img1',
    url: 'https://example.test/tomate.webp',
    es_principal: true,
    texto_alternativo: 'Tomate',
  },
}
const PAUSADO = {
  ...PRODUCTO,
  id: 'prod2',
  nombre: 'Lechuga',
  slug: 'lechuga',
  activo: false,
  motivo_pausa: 'Pausado por falta de stock',
  imagenPrincipal: null,
  imagenes: [],
}

let db
let actualizaciones

function coincide(fila, filtros) {
  return filtros.every((filtro) => {
    if (filtro.tipo === 'neq') return fila[filtro.campo] !== filtro.valor
    return fila[filtro.campo] === filtro.valor
  })
}

function ejecutar(consulta, single) {
  const tabla = consulta.tabla
  const filas = db[tabla] ?? []
  const filtros = consulta.filtros

  if (consulta.operacion === 'update') {
    if (tabla === 'productos' && db.errorProductoUpdate) {
      return { data: null, error: { message: db.errorProductoUpdate, code: 'PGRST116' } }
    }
    if (tabla === 'productores' && db.errorProductorUpdate) {
      return { data: null, error: { message: db.errorProductorUpdate } }
    }
    const indice = filas.findIndex((fila) => coincide(fila, filtros))
    if (indice < 0) return { data: null, error: null }
    filas[indice] = { ...filas[indice], ...consulta.payload }
    actualizaciones.push({ tabla, payload: { ...consulta.payload } })
    return { data: { ...filas[indice] }, error: null }
  }

  const resultado = filas.filter((fila) => coincide(fila, filtros))
  if (single) return { data: resultado[0] ?? null, error: null }
  return { data: resultado, error: null }
}

function crearConsulta(tabla) {
  const consulta = {
    tabla,
    operacion: 'select',
    filtros: [],
    payload: null,
    select() {
      return this
    },
    insert(payload) {
      this.operacion = 'insert'
      this.payload = payload
      return this
    },
    update(payload) {
      this.operacion = 'update'
      this.payload = payload
      return this
    },
    delete() {
      this.operacion = 'delete'
      return this
    },
    eq(campo, valor) {
      this.filtros.push({ tipo: 'eq', campo, valor })
      return this
    },
    neq(campo, valor) {
      this.filtros.push({ tipo: 'neq', campo, valor })
      return this
    },
    ilike(campo, valor) {
      this.filtros.push({ tipo: 'eq', campo, valor })
      return this
    },
    is() {
      return this
    },
    in() {
      return this
    },
    order() {
      return this
    },
    limit() {
      return this
    },
    maybeSingle() {
      return Promise.resolve(ejecutar(this, true))
    },
    single() {
      return Promise.resolve(ejecutar(this, true))
    },
    then(resolve, reject) {
      return Promise.resolve(ejecutar(this, false)).then(resolve, reject)
    },
  }
  return consulta
}

function crearRouter(path = '/vendedor/productos') {
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [
      { path: '/vendedor', component: { template: '<div />' } },
      { path: '/vendedor/productos', component: { template: '<div />' } },
      { path: '/vendedor/productos/nuevo', component: { template: '<div />' } },
      { path: '/vendedor/productos/:id/editar', component: { template: '<div />' } },
      { path: '/vendedor/tienda', component: { template: '<div />' } },
      { path: '/vendedor/servicio', component: { template: '<div />' } },
      { path: '/vendedor/pedidos', component: { template: '<div />' } },
    ],
  })
  router.push(path)
  return router
}

async function montar(componente, path) {
  const router = crearRouter(path)
  await router.isReady()
  return mount(componente, { global: { plugins: [router] } })
}

function sesionVendedor() {
  const auth = useAuthStore()
  auth.user = { id: 'u1', email: 'vendedor@cutuco.dev' }
  auth.perfil = {
    id: 'u1',
    rol: 'vendedor',
    activo: true,
    nombre: 'Verónica',
    apellido: 'Del Campo',
    telefono: '+56900000101',
  }
  auth.productor = { ...PRODUCTOR }
  auth.postulacion = { estado: 'aprobada' }
  auth.sanciones = []
  return auth
}

beforeEach(() => {
  setActivePinia(createPinia())
  vi.clearAllMocks()
  actualizaciones = []
  db = {
    productos: [
      { id: PRODUCTO.id, productor_id: PRODUCTOR.id },
      { id: PAUSADO.id, productor_id: PRODUCTOR.id },
    ],
    productores: [
      { id: 'p1', slug: 'huerta-del-sur' },
      { id: 'p2', slug: 'otra-tienda' },
    ],
    pedidos: [],
    errorProductoUpdate: null,
    errorProductorUpdate: null,
  }
  supabaseMock.getClient.mockReturnValue({ from: crearConsulta })
  supabaseMock.apiFetch.mockResolvedValue(null)

  sellerMock.getMiProductor.mockResolvedValue({ ...PRODUCTOR })
  sellerMock.getMiPostulacion.mockResolvedValue({ estado: 'aprobada' })
  sellerMock.getDatosBancarios.mockResolvedValue(null)
  sellerMock.guardarDatosBancarios.mockResolvedValue(null)
  sellerMock.listSancionesDeProductor.mockResolvedValue([])
  sellerMock.listProductosVendedor.mockResolvedValue([{ ...PRODUCTO }, { ...PAUSADO }])
  sellerMock.getProductoVendedor.mockResolvedValue({ ...PRODUCTO })
  sellerMock.getTiendaConUbicacion.mockResolvedValue({
    ...PRODUCTOR,
    direccion: {
      id: 'd1',
      comuna_id: COMUNA.id,
      calle: 'Camino a Quillota',
      numero: '12B',
      depto_oficina: 'Depto 402',
      referencia: 'Portón verde',
      es_principal: true,
      activo: true,
    },
    comuna: COMUNA,
    region: REGION,
  })
  ordersMock.getReputacionProductor.mockResolvedValue({
    puntaje: 4.5,
    cantidad: 2,
    evaluaciones: [],
  })
  ordersMock.listPedidos.mockResolvedValue({ items: [], total: 0 })
  catalogMock.listCategorias.mockResolvedValue([{ id: 'c1', nombre: 'Hortalizas' }])
  geoMock.getJerarquiaGeografica.mockResolvedValue([{ ...REGION, comunas: [COMUNA] }])
  geoMock.getComuna.mockResolvedValue(COMUNA)
  geoMock.getRegion.mockResolvedValue(REGION)
  geoMock.updateDireccion.mockResolvedValue({})
})

afterEach(() => {
  document.body.innerHTML = ''
  vi.unstubAllEnvs()
})

/* ------------------------------------------------------------------ */
/* Servicio: pausa, propiedad y límites                                */
/* ------------------------------------------------------------------ */

describe('servicio vendedor · pausa y propiedad', () => {
  it('desactivar guarda la justificación por defecto válida (10..1000)', async () => {
    await desactivarProducto(PRODUCTO.id)
    expect(actualizaciones).toHaveLength(1)
    expect(actualizaciones[0]).toMatchObject({
      tabla: 'productos',
      payload: { activo: false },
    })
    expect(actualizaciones[0].payload.motivo_pausa).toBe(MOTIVO_PAUSA_POR_DEFECTO)
    expect(actualizaciones[0].payload.motivo_pausa.length).toBeGreaterThanOrEqual(10)
    expect(actualizaciones[0].payload.motivo_pausa.length).toBeLessThanOrEqual(MOTIVO_PRODUCTO_MAX)
  })

  it('rechaza una justificación vacía o demasiado larga antes de llamar a la BD', async () => {
    await expect(desactivarProducto(PRODUCTO.id, '   ')).rejects.toThrow(/justificación/i)
    await expect(
      desactivarProducto(PRODUCTO.id, 'x'.repeat(MOTIVO_PRODUCTO_MAX + 1)),
    ).rejects.toThrow(/1000/)
    expect(actualizaciones).toHaveLength(0)
    expect(validarMotivoProducto(MOTIVO_PAUSA_POR_DEFECTO)).toBeNull()
  })

  it('reactivar limpia la pausa sin exigir justificación', async () => {
    await reactivarProducto(PRODUCTO.id)
    expect(actualizaciones[0].payload).toMatchObject({ activo: true, motivo_pausa: null })
  })

  it('traduce el error de serialización de PostgREST al editar un producto ajeno', async () => {
    db.errorProductoUpdate = 'Cannot coerce the result to a single JSON object'
    await expect(updateProducto(PRODUCTO.id, { stock: 5 })).rejects.toThrow(
      /no pertenece a tu tienda/i,
    )
    const traducido = mensajeErrorProducto('Cannot coerce the result to a single JSON object')
    expect(traducido).not.toMatch(/Cannot coerce|JSON object|PGRST/i)
  })

  it('valida los límites técnicos de stock y precio del esquema', async () => {
    // HAL-VEN-026: tope de negocio a escala campesina, no el técnico de la columna
    expect(LIMITES_PRODUCTO.stockMax).toBe(999999)
    expect(LIMITES_PRODUCTO.precioMax).toBe(999999)
    await expect(
      updateProducto(PRODUCTO.id, { stock: LIMITES_PRODUCTO.stockMax + 1 }),
    ).rejects.toThrow(/stock/i)
    await expect(
      updateProducto(PRODUCTO.id, { precio: LIMITES_PRODUCTO.precioMax + 1 }),
    ).rejects.toThrow(/precio/i)
    expect(actualizaciones).toHaveLength(0)
  })

  it('valida las reglas de incremento y compra mínima antes de guardar', async () => {
    await expect(
      updateProducto(PRODUCTO.id, {
        unidad_medida: 'kg',
        incremento_venta: 0.5,
        cantidad_minima_compra: 1.2,
      }),
    ).rejects.toThrow(/múltiplo/i)
    await expect(
      updateProducto(PRODUCTO.id, {
        unidad_medida: 'unidad',
        incremento_venta: 0.5,
        cantidad_minima_compra: 1,
      }),
    ).rejects.toThrow(/entera/i)
    await expect(
      updateProducto(PRODUCTO.id, {
        stock: 2,
        unidad_medida: 'kg',
        incremento_venta: 1,
        cantidad_minima_compra: 3,
      }),
    ).rejects.toThrow(/stock publicado/i)
    expect(actualizaciones).toHaveLength(0)
  })
})

/* ------------------------------------------------------------------ */
/* Servicio: tienda/slug y métricas                                    */
/* ------------------------------------------------------------------ */

describe('servicio vendedor · tienda y métricas', () => {
  it('normaliza el slug y resuelve colisiones con sufijos', () => {
    expect(slugTiendaBase('Símbolos y Ñandú')).toBe('simbolos-y-nandu')
    expect(slugTiendaBase('!!!')).toBe('')
    expect(slugUnicoTienda('otra-tienda', ['otra-tienda', 'otra-tienda-2'])).toBe('otra-tienda-3')
  })

  it('rechaza un nombre comercial sin letras ni números con mensaje funcional', async () => {
    await expect(
      updateTienda({ productorId: 'p1', nombreComercial: '!!!', descripcion: '' }),
    ).rejects.toThrow(/al menos una letra o número/i)
    expect(actualizaciones).toHaveLength(0)
  })

  it('guarda un slug válido y deduplica contra otras tiendas', async () => {
    await updateTienda({ productorId: 'p1', nombreComercial: 'Otra Tienda', descripcion: '' })
    expect(actualizaciones[0]).toMatchObject({
      tabla: 'productores',
      payload: { nombre_comercial: 'Otra Tienda', slug: 'otra-tienda-2' },
    })
    expect(
      mensajeErrorTienda('duplicate key value violates unique constraint uq_productor_slug'),
    ).toMatch(/Ya existe una tienda/i)
  })

  it('calcula ventas autorizadas, entregadas y neto con la misma población', async () => {
    db.pedidos = [
      {
        id: '1',
        productor_id: 'p1',
        estado: 'creado',
        total: 1000,
        monto_fee_plataforma: 50,
        creado_en: '2026-10-01',
      },
      {
        id: '2',
        productor_id: 'p1',
        estado: 'pagado',
        total: 2000,
        monto_fee_plataforma: 100,
        creado_en: '2026-10-02',
      },
      {
        id: '3',
        productor_id: 'p1',
        estado: 'completado',
        total: 3000,
        monto_fee_plataforma: 150,
        creado_en: '2026-10-03',
      },
      {
        id: '4',
        productor_id: 'p1',
        estado: 'cancelado',
        total: 4000,
        monto_fee_plataforma: 200,
        creado_en: '2026-10-04',
      },
      {
        id: '5',
        productor_id: 'p1',
        estado: 'reclamado',
        total: 1000,
        monto_fee_plataforma: 50,
        creado_en: '2026-10-05',
      },
    ]
    const resumen = await getResumenVentas('p1')
    expect(resumen.ventasAutorizadas).toBe(6000)
    expect(resumen.ventasEntregadas).toBe(3000)
    expect(resumen.comisionesAutorizadas).toBe(300)
    expect(resumen.netoEntregado).toBe(2850)
    expect(resumen.netoAutorizado).toBe(5700)
    expect(resumen.pedidosEntregados).toBe(1)
  })
})

/* ------------------------------------------------------------------ */
/* Vista: dashboard (fallback de tienda y sin códigos internos)        */
/* ------------------------------------------------------------------ */

describe('SellerDashboardView · producto de sesión y textos', () => {
  it('no muestra "Sin tienda" si el store ya tiene productor aunque falle la consulta', async () => {
    sesionVendedor()
    sellerMock.getMiProductor.mockResolvedValue(null)
    sellerMock.listProductosVendedor.mockResolvedValue([])
    const router = crearRouter('/vendedor')
    await router.isReady()
    const wrapper = mount(SellerDashboardView, {
      global: { plugins: [router], stubs: { CtChart: true } },
    })
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).not.toContain('Sin tienda de productor')
    expect(texto).not.toContain('Tu tienda aún no está activa')
    expect(texto).toContain('Ventas autorizadas')
    expect(texto).not.toMatch(/RF-\d{3}/)
  })
})

/* ------------------------------------------------------------------ */
/* Servicio: fechas de la cuota                                        */
/* ------------------------------------------------------------------ */

describe('servicio mensual · plazos', () => {
  it('deriva emisión, vencimiento, gracia y suspensión con la regla 10 + 5', () => {
    const plazos = fechasCuotaServicio({ periodo: '2026-10-01', vence_en: '2026-11-04' })
    expect(plazos).toMatchObject({
      emision: '2026-10-25',
      vence: '2026-11-04',
      graciaHasta: '2026-11-09',
      suspensionDesde: '2026-11-10',
      diasVencimiento: 10,
      diasGracia: 5,
    })
  })

  it('resuelve bordes de mes, año y año bisiesto', () => {
    expect(fechasCuotaServicio({ vence_en: '2026-01-05' })).toMatchObject({
      emision: '2025-12-26',
      graciaHasta: '2026-01-10',
      suspensionDesde: '2026-01-11',
    })
    expect(fechasCuotaServicio({ vence_en: '2028-03-01' })).toMatchObject({
      emision: '2028-02-20',
      graciaHasta: '2028-03-06',
    })
  })
})

/* ------------------------------------------------------------------ */
/* Vista: productos (detalle, pausa y stock)                           */
/* ------------------------------------------------------------------ */

describe('SellerProductsView · detalle, pausa y stock', () => {
  it('abre el detalle de sólo lectura y muestra la justificación vigente', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerProductsView, '/vendedor/productos')
    await flushPromises()

    const filas = wrapper.findAll('tbody tr')
    expect(filas.length).toBe(2)
    const filaLechuga = filas.find((fila) => fila.text().includes('Lechuga'))
    const botonDetalle = filaLechuga
      .findAll('button')
      .find((boton) => boton.text().includes('Ver detalle'))
    expect(botonDetalle).toBeTruthy()
    await botonDetalle.trigger('click')
    await flushPromises()

    expect(document.body.textContent).toContain('Lechuga')
    expect(document.body.textContent).toContain('Justificación de pausa')
    expect(document.body.textContent).toContain('Pausado por falta de stock')
  })

  it('exige justificación antes de pausar y guarda el motivo editado', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerProductsView, '/vendedor/productos')
    await flushPromises()

    const fila = wrapper.findAll('tbody tr').find((item) => item.text().includes('Tomate italiano'))
    const desactivar = fila.findAll('button').find((boton) => boton.text().includes('Desactivar'))
    await desactivar.trigger('click')
    await flushPromises()

    const textarea = document.body.querySelector('textarea')
    expect(textarea).toBeTruthy()
    textarea.value = 'corto'
    textarea.dispatchEvent(new Event('input', { bubbles: true }))
    await flushPromises()

    const confirmar = [...document.body.querySelectorAll('button')].find((boton) =>
      boton.textContent.includes('Pausar producto'),
    )
    confirmar.click()
    await flushPromises()
    expect(document.body.textContent).toContain('al menos 10')
    expect(actualizaciones).toHaveLength(0)

    textarea.value = 'Pausado para revisar la calidad del lote'
    textarea.dispatchEvent(new Event('input', { bubbles: true }))
    await flushPromises()
    confirmar.click()
    await flushPromises()

    expect(actualizaciones).toHaveLength(1)
    expect(actualizaciones[0].payload).toMatchObject({
      activo: false,
      motivo_pausa: 'Pausado para revisar la calidad del lote',
    })
  })

  it('valida el máximo de stock antes de guardar', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerProductsView, '/vendedor/productos')
    await flushPromises()

    const fila = wrapper.findAll('tbody tr')[0]
    const editarStock = fila.findAll('button').find((boton) => boton.text().includes('Editar'))
    await editarStock.trigger('click')
    await flushPromises()

    const input = fila.find('input')
    expect(input.attributes('max')).toBe(String(LIMITES_PRODUCTO.stockMax))
    await input.setValue(String(LIMITES_PRODUCTO.stockMax + 1))
    const guardar = fila.findAll('button').find((boton) => boton.text().includes('Guardar'))
    await guardar.trigger('click')
    await flushPromises()
    expect(fila.text()).toContain('no puede superar')

    await input.setValue(String(LIMITES_PRODUCTO.stockMax))
    await guardar.trigger('click')
    await flushPromises()
    expect(actualizaciones.at(-1).payload).toMatchObject({ stock: LIMITES_PRODUCTO.stockMax })
  })
})

/* ------------------------------------------------------------------ */
/* Vista: formulario de producto (límites y pausa)                     */
/* ------------------------------------------------------------------ */

describe('SellerProductFormView · límites y pausa', () => {
  it('muestra los máximos del esquema y exige justificación al despublicar', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerProductFormView, '/vendedor/productos/prod1/editar')
    await flushPromises()

    const numeros = wrapper.findAll('input[type="number"]')
    expect(numeros[0].attributes('max')).toBe(String(LIMITES_PRODUCTO.precioMax))
    expect(numeros[1].attributes('max')).toBe(String(LIMITES_PRODUCTO.stockMax))
    expect(wrapper.text()).toContain('Máximo 999.999')

    const activo = wrapper.find('input[type="checkbox"]')
    await activo.setValue(false)
    await flushPromises()

    const motivo = wrapper
      .findAll('textarea')
      .find((item) => item.attributes('placeholder')?.includes('pausas este producto'))
    expect(motivo).toBeTruthy()
    await motivo.setValue('corto')
    const guardar = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Actualizar Producto'))
    await guardar.trigger('click')
    await flushPromises()
    expect(wrapper.text()).toContain('al menos 10')
    expect(actualizaciones).toHaveLength(0)

    await motivo.setValue('Pausado para revisar la calidad del lote')
    await guardar.trigger('click')
    await flushPromises()
    expect(actualizaciones).toHaveLength(1)
    expect(actualizaciones[0].payload).toMatchObject({
      activo: false,
      motivo_pausa: 'Pausado para revisar la calidad del lote',
    })
  })
})

/* ------------------------------------------------------------------ */
/* Vista: perfil de tienda (ubicación, depto y titular)                */
/* ------------------------------------------------------------------ */

describe('SellerStoreProfileView · ubicación única y titular', () => {
  it('muestra la región/comuna de la misma dirección y conserva depto_oficina', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerStoreProfileView, '/vendedor/tienda')
    await flushPromises()

    const tab = wrapper
      .findAll('[role="tab"]')
      .find((boton) => boton.text().includes('Datos bancarios y ubicación'))
    await tab.trigger('click')
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain('Valparaíso')
    expect(texto).toContain('Quillota')
    expect(texto).toContain('Depto 402')
    expect(texto).not.toMatch(/payout|liquidar|dispersión/i)

    const depto = wrapper
      .findAll('input')
      .find((input) => input.attributes('placeholder')?.includes('Depto 402'))
    expect(depto.element.value).toBe('Depto 402')

    const titular = wrapper
      .findAll('input')
      .find((input) => input.attributes('placeholder')?.includes('Nombre completo del titular'))
    expect(titular.element.value).toBe('Verónica Del Campo')

    await depto.setValue('Depto 9')
    const guardar = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Guardar dirección'))
    await guardar.trigger('click')
    await flushPromises()
    expect(geoMock.updateDireccion).toHaveBeenCalledWith(
      'd1',
      expect.objectContaining({
        depto_oficina: 'Depto 9',
        calle: 'Camino a Quillota',
        numero: '12B',
      }),
    )
  })

  it('valida el nombre comercial sin letras antes de guardar la tienda', async () => {
    sesionVendedor()
    const wrapper = await montar(SellerStoreProfileView, '/vendedor/tienda')
    await flushPromises()

    const nombre = wrapper
      .findAll('input')
      .find((input) => input.element.value === 'Huerta del Sur')
    await nombre.setValue('¡¡¡!!!')
    const guardar = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Guardar nombre y descripción'))
    await guardar.trigger('click')
    await flushPromises()

    expect(wrapper.text()).toContain('al menos una letra o número')
    expect(actualizaciones.filter((item) => item.tabla === 'productores')).toHaveLength(0)
  })
})

/* ------------------------------------------------------------------ */
/* Vista: servicio mensual (fechas y transferencia)                    */
/* ------------------------------------------------------------------ */

describe('SellerServiceView · fechas y datos de transferencia', () => {
  it('muestra las fechas derivadas y los datos de CuTuCo con copia', async () => {
    vi.resetModules()
    const { default: SellerServiceView } = await import('@/views/seller/SellerServiceView.vue')

    servicioMock.getMiServicio.mockResolvedValue({
      estado: 'pendiente',
      cuota: {
        periodo: '2026-10-01',
        vence_en: '2026-11-04',
        monto: 9900,
        estado: 'pendiente',
      },
      historial: [],
    })
    servicioMock.listPagosServicio.mockResolvedValue([])
    servicioMock.obtenerDatosTransferenciaCutuco.mockResolvedValue({
      banco: 'BancoEstado',
      tipoCuenta: 'Cuenta corriente',
      numeroCuenta: '12345678',
      titular: 'CuTuCo SpA',
      rut: '76.543.210-8',
      actualizadoEn: '2026-11-01T12:00:00Z',
    })
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText },
    })

    const wrapper = await montar(SellerServiceView, '/vendedor/servicio')
    await flushPromises()

    const texto = wrapper.text()
    expect(texto).toContain(formatDate('2026-10-25'))
    expect(texto).toContain(formatDate('2026-11-09'))
    expect(texto).toContain(formatDate('2026-11-10'))

    const abrir = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Registrar transferencia'))
    await abrir.trigger('click')
    await flushPromises()

    const modal = document.body.textContent
    expect(modal).toContain('BancoEstado')
    expect(modal).toContain('Cuenta corriente')
    expect(modal).toContain('12345678')
    expect(modal).toContain('CuTuCo SpA')
    expect(modal).toContain('76.543.210-8')

    const copiarTodos = [...document.body.querySelectorAll('button')].find((boton) =>
      boton.textContent.includes('Copiar todos los datos'),
    )
    copiarTodos.click()
    await flushPromises()
    expect(writeText).toHaveBeenCalledOnce()
    expect(writeText.mock.calls[0][0]).toContain('BancoEstado')
    expect(document.body.textContent).toContain('Datos de transferencia copiado')
  })

  it('muestra un placeholder explícito cuando la cuenta no está configurada', async () => {
    vi.resetModules()
    const { default: SellerServiceView } = await import('@/views/seller/SellerServiceView.vue')

    servicioMock.getMiServicio.mockResolvedValue({
      estado: 'pendiente',
      cuota: { periodo: '2026-10-01', vence_en: '2026-11-04', monto: 9900, estado: 'pendiente' },
      historial: [],
    })
    servicioMock.listPagosServicio.mockResolvedValue([])
    servicioMock.obtenerDatosTransferenciaCutuco.mockResolvedValue({
      banco: '', tipoCuenta: '', numeroCuenta: '', titular: '', rut: '', actualizadoEn: null,
    })

    const wrapper = await montar(SellerServiceView, '/vendedor/servicio')
    await flushPromises()
    const abrir = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Registrar transferencia'))
    await abrir.trigger('click')
    await flushPromises()

    expect(document.body.textContent).toContain('Datos bancarios de CuTuCo no configurados')
    expect(document.body.textContent).toContain('No configurado')
    const copiarTodos = [...document.body.querySelectorAll('button')].find((boton) =>
      boton.textContent.includes('Copiar todos los datos'),
    )
    expect(copiarTodos.disabled).toBe(true)
  })

  it('exige el número de operación antes de registrar una transferencia', async () => {
    vi.resetModules()
    const { default: SellerServiceView } = await import('@/views/seller/SellerServiceView.vue')

    servicioMock.getMiServicio.mockResolvedValue({
      estado: 'pendiente',
      cuota: { periodo: '2026-10-01', vence_en: '2026-11-04', monto: 9900, estado: 'pendiente' },
      historial: [],
    })
    servicioMock.listPagosServicio.mockResolvedValue([])
    servicioMock.obtenerDatosTransferenciaCutuco.mockResolvedValue({
      banco: 'BancoEstado', tipoCuenta: 'Cuenta corriente', numeroCuenta: '12345678',
      titular: 'CuTuCo SpA', rut: '76.543.210-8', actualizadoEn: '2026-11-01T12:00:00Z',
    })

    const wrapper = await montar(SellerServiceView, '/vendedor/servicio')
    await flushPromises()
    const abrir = wrapper
      .findAll('button')
      .find((boton) => boton.text().includes('Registrar transferencia'))
    await abrir.trigger('click')
    await flushPromises()

    const registrar = [...document.body.querySelectorAll('button')].find((boton) =>
      boton.textContent.includes('Registrar pago'),
    )
    registrar.click()
    await flushPromises()

    expect(servicioMock.registrarTransferenciaServicio).not.toHaveBeenCalled()
    expect(document.body.textContent).toContain('Ingresa el número de operación de la transferencia.')
  })
})
