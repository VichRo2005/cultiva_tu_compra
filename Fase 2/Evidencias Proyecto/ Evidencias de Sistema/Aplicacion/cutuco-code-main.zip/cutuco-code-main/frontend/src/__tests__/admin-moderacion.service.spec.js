import { beforeEach, describe, expect, it, vi } from 'vitest'
import { consulta, admin } from './admin-test-utils'
const sdk = vi.hoisted(() => ({
  from: vi.fn(),
  rpc: vi.fn(),
  auth: { getSession: vi.fn(), getUser: vi.fn() },
}))
vi.mock('@/lib/supabase', () => ({ getClient: () => sdk, tryGetClient: () => sdk }))
beforeEach(() => vi.resetAllMocks())
import { actualizarPalabraProhibida, listCoincidenciasModeradas } from '@/services/adminModeracion'
describe('Moderación', () => {
  it('impide editar una palabra desactivada', async () => {
    admin(sdk)
    consulta(sdk, { data: { id: 'p', activo: false } })
    await expect(actualizarPalabraProhibida('p', { palabra: 'otra' })).rejects.toThrow(
      'solo se puede reactivar',
    )
  })
  it('permite reactivar', async () => {
    admin(sdk)
    consulta(sdk, { data: { id: 'p', activo: false } })
    const q = consulta(sdk, { data: { id: 'p', activo: true } })
    await actualizarPalabraProhibida('p', { activo: true })
    expect(q.update).toHaveBeenCalledWith({ activo: true })
  })
  it('lista desactivadas pero no las usa para marcar productos', async () => {
    const palabras = [
      { palabra: 'rojo', activo: true },
      { palabra: 'azul', activo: false },
    ]
    consulta(sdk, { data: palabras })
    consulta(sdk, { data: [{ nombre: 'Azul', id: 'p' }] })
    consulta(sdk, { data: [] })
    expect(await listCoincidenciasModeradas()).toEqual({ palabras, coincidencias: [] })
  })
})
