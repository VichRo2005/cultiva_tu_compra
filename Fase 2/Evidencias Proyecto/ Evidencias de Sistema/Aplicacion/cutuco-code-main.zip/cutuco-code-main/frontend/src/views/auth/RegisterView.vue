<script setup>
/**
 * CuTuCo — Crear cuenta de Cliente (RF-020 y RF-019).
 *
 * Pide nombre, apellidos, correo único, contraseña con confirmación, región y
 * comuna desde combobox (RF-018) y la dirección de entrega. La cuenta se crea
 * con Supabase Auth y el sistema asigna exclusivamente el rol Cliente: el
 * visitante no puede auto-registrarse como Vendedor ni Administrador. Para
 * vender existe `/registro-vendedor`, que queda pendiente de aprobación.
 */
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtStepper from '@/components/base/CtStepper.vue'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import {
  TELEFONO_AYUDA,
  limpiarBorradorClienteLocal,
  leerBorradorClienteLocal,
  guardarBorradorClienteLocal,
  mensajeCalle,
  mensajeConfirmacion,
  mensajeDeptoOficina,
  mensajeEmail,
  mensajeNombre,
  mensajeNumeroDireccion,
  mensajePassword,
  mensajeReferencia,
  mensajeTelefono,
  normalizarNombre,
  registrarCliente,
} from '@/services/registro'
import { PASSWORD_REQUIREMENTS, passwordChecks, passwordStrength } from '@/lib/validation'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const geo = useGeographyStore()
const ui = useUiStore()
const auth = useAuthStore()

const TOTAL_PASOS = 3
const paso = ref(1)
const enviando = ref(false)
const aceptado = ref(false)
const error = ref(null)
const errores = reactive({})
const requiereConfirmacionPantalla = ref(false)
const emailParaConfirmar = ref('')

const form = reactive({
  nombre: '',
  apellido: '',
  email: '',
  telefono: '',
  password: '',
  confirmacion: '',
  regionId: '',
  comunaId: '',
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
})

const pasos = computed(() => [
  { key: 'datos', label: 'Tus datos', description: 'Nombre, correo y contraseña' },
  { key: 'zona', label: 'Tu región', description: 'Región y comuna' },
  { key: 'entrega', label: 'Tu dirección', description: 'Dónde recibes tus pedidos' },
])

const INSIGNIAS = [
  { icon: 'leaf', label: 'Producto local' },
  { icon: 'shieldCheck', label: 'Compra protegida' },
  { icon: 'lock', label: 'Pago seguro con Webpay' },
  { icon: 'truck', label: 'Entrega con código' },
]

const fuerza = computed(() => passwordStrength(form.password))

/**
 * Indicador y requisitos usan EXACTAMENTE la misma regla que el permiso para
 * avanzar (`passwordPolicyMessage`), así no puede decir "Buena" con un error
 * de longitud visible (REG-PWD-013 / HAL-REG-003).
 */
const requisitosPassword = computed(() => {
  const checks = passwordChecks(form.password)
  return PASSWORD_REQUIREMENTS.map((requisito) => ({
    ...requisito,
    cumplido: Boolean(checks[requisito.key]),
  }))
})
const etiquetaFuerza = computed(() =>
  fuerza.value.valid ? fuerza.value.label : 'Aún no cumple la política',
)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)

const opcionesComuna = computed(() =>
  geo.comunasDeRegion(form.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

onMounted(async () => {
  void geo.load()
  restaurarBorrador()
})

/** REG-NAV-003: guarda el estado del formulario para recuperar tras recargar. */
function guardarBorrador() {
  guardarBorradorClienteLocal({
    nombre: form.nombre,
    apellido: form.apellido,
    email: form.email,
    telefono: form.telefono,
    regionId: form.regionId,
    comunaId: form.comunaId,
    calle: form.calle,
    numero: form.numero,
    deptoOficina: form.deptoOficina,
    referencia: form.referencia,
    paso: paso.value,
  })
}

/** REG-NAV-003: restaura el borrador si existe tras una recarga de página. */
function restaurarBorrador() {
  const draft = leerBorradorClienteLocal()
  if (!draft) return
  Object.assign(form, {
    nombre: draft.nombre ?? '',
    apellido: draft.apellido ?? '',
    email: draft.email ?? '',
    telefono: draft.telefono ?? '',
    password: '',
    confirmacion: '',
    regionId: draft.regionId ?? '',
    comunaId: draft.comunaId ?? '',
    calle: draft.calle ?? '',
    numero: draft.numero ?? '',
    deptoOficina: draft.deptoOficina ?? '',
    referencia: draft.referencia ?? '',
  })
  // La contraseña sólo vive en memoria y debe ingresarse de nuevo tras recargar.
  paso.value = 1
}

watch(
  () => form.regionId,
  () => {
    form.comunaId = ''
  },
)

/** REG-NAV-003: persiste el borrador en cada cambio relevante del formulario. */
watch(
  () => ({
    nombre: form.nombre,
    apellido: form.apellido,
    email: form.email,
    telefono: form.telefono,
    regionId: form.regionId,
    comunaId: form.comunaId,
    calle: form.calle,
    numero: form.numero,
    deptoOficina: form.deptoOficina,
    referencia: form.referencia,
    paso: paso.value,
  }),
  guardarBorrador,
  { deep: true },
)

/** Errores de UNA etapa: cada campo de la etapa se valida antes de avanzar. */
function erroresDePaso(n) {
  const e = {}
  const asignar = (clave, mensaje) => {
    if (mensaje) e[clave] = mensaje
  }
  if (n === 1) {
    asignar('nombre', mensajeNombre(form.nombre, 'El nombre'))
    asignar('apellido', mensajeNombre(form.apellido, 'El apellido'))
    asignar('email', mensajeEmail(form.email))
    asignar('telefono', mensajeTelefono(form.telefono))
    asignar('password', mensajePassword(form.password))
    asignar('confirmacion', mensajeConfirmacion(form.password, form.confirmacion))
  }
  if (n === 2) {
    if (!form.regionId) e.regionId = 'Selecciona tu región'
    if (!form.comunaId) e.comunaId = 'Selecciona tu comuna'
  }
  if (n === 3) {
    asignar('calle', mensajeCalle(form.calle, 'La dirección de entrega'))
    asignar('numero', mensajeNumeroDireccion(form.numero))
    asignar('deptoOficina', mensajeDeptoOficina(form.deptoOficina))
    asignar('referencia', mensajeReferencia(form.referencia))
    if (!aceptado.value) e.aceptado = 'Debes aceptar los términos y la política de privacidad'
  }
  return e
}

function limpiarErrores() {
  Object.keys(errores).forEach((clave) => delete errores[clave])
}

/** HAL-REG-017: al llegar al final se revisan TAMBIÉN las etapas anteriores. */
function erroresDeTodasLasEtapas() {
  const todos = {}
  for (let n = 1; n <= TOTAL_PASOS; n += 1) Object.assign(todos, erroresDePaso(n))
  return todos
}

function primerPasoConError(todos) {
  for (let n = 1; n <= TOTAL_PASOS; n += 1) {
    if (Object.keys(erroresDePaso(n)).some((clave) => clave in todos)) return n
  }
  return null
}

function validarPaso(n) {
  limpiarErrores()
  Object.assign(errores, erroresDePaso(n))
  return Object.keys(errores).length === 0
}

/** Recorta los espacios externos antes de validar/guardar (REG-COM-004). */
function recortar(campo) {
  form[campo] = normalizarNombre(form[campo])
}

/** HAL-REG-017: valida un campo individual en tiempo real (blur/change). */
function validarCampo(clave, fn) {
  const msg = fn()
  if (msg) errores[clave] = msg
  else delete errores[clave]
}

function siguiente() {
  if (enviando.value) return
  if (!validarPaso(paso.value)) return
  paso.value = Math.min(TOTAL_PASOS, paso.value + 1)
}

function anterior() {
  if (enviando.value) return
  limpiarErrores()
  paso.value = Math.max(1, paso.value - 1)
}

async function registrar() {
  // REG-NAV-006: una sola creación mientras la operación está pendiente.
  // Cuando GoTrue exige verificar el correo, el alta ya terminó: impedir una
  // segunda llamada aunque se dispare el handler desde un DOM desactualizado.
  if (enviando.value || requiereConfirmacionPantalla.value) return
  const todos = erroresDeTodasLasEtapas()
  limpiarErrores()
  Object.assign(errores, todos)
  if (Object.keys(todos).length) {
    const destino = primerPasoConError(todos)
    if (destino) paso.value = destino
    error.value = 'Revisa los campos marcados: hay datos inválidos o pendientes.'
    return
  }

  enviando.value = true
  error.value = null
  try {
    const { requiereConfirmacion, advertencias = [] } = await registrarCliente({
      nombre: form.nombre,
      apellido: form.apellido,
      email: form.email,
      password: form.password,
      telefono: form.telefono,
      regionId: form.regionId,
      comunaId: form.comunaId,
      calle: form.calle,
      numero: form.numero,
      deptoOficina: form.deptoOficina,
      referencia: form.referencia,
    })

    if (requiereConfirmacion) {
      // REG-CONF-007 / REG-CONF-008: en lugar de redirigir a ciegas, se muestra
      // una pantalla con la opción de reenviar el enlace si expiró o fue alterado.
      limpiarBorradorClienteLocal()
      requiereConfirmacionPantalla.value = true
      emailParaConfirmar.value = form.email
      ui.warning(
        'Cuenta creada: confirma tu correo',
        'Te enviamos el enlace de verificación. Cuando confirmes el correo, tu perfil y tu dirección se crearán automáticamente con los datos que ingresaste.',
      )
      return
    }

    // A4: la sesión ya existe (signUp la devolvió); se carga el perfil en el
    // store para que la app reconozca al usuario sin pedirle iniciar sesión.
    await auth.refresh()

    if (advertencias.length) {
      limpiarBorradorClienteLocal()
      ui.warning('Cuenta creada con pendientes', advertencias.join(' '))
      router.push({ name: 'direcciones' })
      return
    }

    limpiarBorradorClienteLocal()
    ui.success('¡Cuenta creada!', 'Ya puedes comprar en CuTuCo.')
    router.push({ name: 'catalogo' })
  } catch (e) {
    error.value = e.message
  } finally {
    enviando.value = false
  }
}

/** REG-CONF-007 / REG-CONF-008: reenvía el enlace de verificación si expiró o fue alterado. */
async function reenviarVerificacion() {
  if (enviando.value) return
  enviando.value = true
  error.value = null
  try {
    await auth.reenviarVerificacion(emailParaConfirmar.value)
    ui.success('Enlace reenviado', 'Revisa tu correo y confirma tu cuenta.')
  } catch (e) {
    error.value = e.message || 'No se pudo reenviar el enlace. Inténtalo de nuevo.'
  } finally {
    enviando.value = false
  }
}
</script>

<template>
  <AuthLayout
    title="Crear Cuenta"
    subtitle="Compra directo a los productores de tu región, con pago seguro vía Webpay y entrega con código."
  >
    <CtStepper v-if="!requiereConfirmacionPantalla" :steps="pasos" :current="paso" />

    <form
      v-if="!requiereConfirmacionPantalla"
      class="stack stack--lg"
      novalidate
      @submit.prevent="paso === 3 ? registrar() : siguiente()"
    >
      <CtAlert v-if="error" tone="danger">{{ error }}</CtAlert>

      <!-- ============ PASO 1 · DATOS ============ -->
      <section v-if="paso === 1" class="stack">
        <div class="reg__pares">
          <CtInput
            v-model="form.nombre"
            label="Nombre"
            :error="errores.nombre"
            autocomplete="given-name"
            hint="Se aceptan tildes, ñ y guiones; sin números ni símbolos."
            required
            @blur="recortar('nombre')"
          />
          <CtInput
            v-model="form.apellido"
            label="Apellido"
            :error="errores.apellido"
            autocomplete="family-name"
            required
            @blur="recortar('apellido')"
          />
        </div>

        <CtInput
          v-model="form.email"
          label="Correo Electrónico"
          type="email"
          placeholder="tucorreo@ejemplo.cl"
          :error="errores.email"
          hint="Debe ser único y sólo admite caracteres ASCII, sin espacios al inicio ni al final (máximo 254)."
          autocomplete="email"
          required
          @blur="validarCampo('email', () => mensajeEmail(form.email))"
        />

        <CtInput
          v-model="form.telefono"
          label="Teléfono de Contacto"
          type="tel"
          placeholder="+56 9 1234 5678"
          :error="errores.telefono"
          :hint="TELEFONO_AYUDA"
          autocomplete="tel"
          required
          @blur="validarCampo('telefono', () => mensajeTelefono(form.telefono))"
        />

        <div>
          <CtInput
            v-model="form.password"
            label="Contraseña"
            type="password"
            :error="errores.password"
            hint="Entre 8 y 72 caracteres ASCII, con mayúscula, minúscula, número y símbolo."
            autocomplete="new-password"
            required
            @blur="validarCampo('password', () => mensajePassword(form.password))"
          />
          <template v-if="form.password">
            <CtProgressBar
              :value="fuerza.score"
              :max="4"
              :tone="fuerza.tone"
              show-label
              :label="etiquetaFuerza"
              class="reg__fuerza"
            />
            <ul class="reg__requisitos" aria-label="Requisitos de la contraseña">
              <li
                v-for="requisito in requisitosPassword"
                :key="requisito.key"
                :class="{ 'is-ok': requisito.cumplido }"
              >
                <CtIcon :name="requisito.cumplido ? 'check' : 'close'" :size="12" aria-hidden="true" />
                {{ requisito.label }}
              </li>
            </ul>
          </template>
        </div>

        <CtInput
          v-model="form.confirmacion"
          label="Confirmar contraseña"
          type="password"
          :error="errores.confirmacion"
          hint="Debe coincidir exactamente con la contraseña."
          autocomplete="new-password"
          required
          @blur="validarCampo('confirmacion', () => mensajeConfirmacion(form.password, form.confirmacion))"
        />
      </section>

      <!-- ============ PASO 2 · ZONA ============ -->
      <section v-else-if="paso === 2" class="stack">
        <CtAlert tone="info" compact title="¿Por qué pedimos la región?">
          <p>
            Los vendedores de CuTuCo entregan sólo dentro de su región, así que comparamos tu región
            con la suya antes de dejar avanzar el pago.
          </p>
        </CtAlert>

        <CtAlert v-if="geo.error" tone="danger" title="No pudimos cargar regiones y comunas">
          <p>{{ geo.error }}</p>
          <CtButton
            size="sm"
            variant="secondary"
            type="button"
            :loading="geo.cargando"
            @click="geo.load({ force: true })"
          >
            Reintentar
          </CtButton>
        </CtAlert>

        <CtSelect
          v-model="form.regionId"
          label="Región"
          :options="opcionesRegion"
          :error="errores.regionId"
          :disabled="geo.cargando || !geo.cargado"
          placeholder="Selecciona tu región"
          required
        />
        <CtSelect
          v-model="form.comunaId"
          label="Comuna"
          :options="opcionesComuna"
          :error="errores.comunaId"
          :disabled="!form.regionId"
          :placeholder="form.regionId ? 'Selecciona tu comuna' : 'Primero elige la región'"
          required
        />
      </section>

      <!-- ============ PASO 3 · ENTREGA ============ -->
      <section v-else class="stack">
        <CtInput
          v-model="form.calle"
          label="Dirección de entrega"
          placeholder="Calle y número"
          :error="errores.calle"
          hint="La calle es obligatoria. Se aceptan números, puntos, guiones, acentos y ñ."
          required
          @blur="recortar('calle')"
        />
        <div class="reg__pares">
          <CtInput
            v-model="form.numero"
            label="Nro./Altura de calle"
            placeholder="123-B"
            :error="errores.numero"
            hint="Opcional para domicilios sin numeración. Admite letras (123-B, Casa 3)."
            @blur="recortar('numero')"
          />
          <CtInput
            v-model="form.deptoOficina"
            label="Complemento (opcional)"
            placeholder="Depto 12, oficina 402, parcela 4"
            :error="errores.deptoOficina"
            hint="Depto, oficina, parcela o local, separado de la calle."
            @blur="recortar('deptoOficina')"
          />
        </div>
        <CtInput
          v-model="form.referencia"
          label="Referencia (opcional)"
          placeholder="Portón verde, frente a la plaza"
          :error="errores.referencia"
          @blur="recortar('referencia')"
        />

        <CtCheckbox
          v-model="aceptado"
          label="Acepto los términos y condiciones y la política de privacidad de CuTuCo"
          :error="errores.aceptado"
        />
      </section>

      <div class="reg__acciones">
        <CtButton v-if="paso > 1" variant="ghost" type="button" :disabled="enviando" @click="anterior">
          Atrás
        </CtButton>
        <span v-else class="spacer" />
        <CtButton type="submit" :loading="enviando" :disabled="enviando">
          {{ paso === TOTAL_PASOS ? 'Crear mi cuenta' : 'Continuar' }}
        </CtButton>
      </div>
    </form>

    <!-- REG-CONF-007 / REG-CONF-008: pantalla de confirmación de correo con reenvío. -->
    <section v-if="requiereConfirmacionPantalla" class="stack stack--lg reg__confirm">
      <CtAlert tone="warning" title="Cuenta creada: confirma tu correo">
        <p>
          Te enviamos un enlace de verificación a <strong>{{ emailParaConfirmar }}</strong>.
          Revisa tu bandeja de entrada y confirma para activar tu perfil y dirección.
        </p>
      </CtAlert>
      <div class="reg__acciones">
        <CtButton variant="ghost" type="button" :disabled="enviando" @click="reenviarVerificacion">
          Reenviar enlace de verificación
        </CtButton>
        <span class="spacer" />
        <CtButton to="/login" type="button">Ir a iniciar sesión</CtButton>
      </div>
      <p class="reg__pie">
        ¿El enlace expiró o no funciona? Haz clic en "Reenviar enlace de verificación" para
        recibir uno nuevo.
      </p>
    </section>

    <section class="reg__insignias" aria-label="Beneficios de la plataforma">
      <span v-for="insignia in INSIGNIAS" :key="insignia.label" class="reg__insignia">
        <CtIcon :name="insignia.icon" :size="14" aria-hidden="true" />
        {{ insignia.label }}
      </span>
    </section>

    <p class="reg__pie">
      ¿Quieres vender en CuTuCo?
      <router-link to="/registro-vendedor">Registra tu tienda aquí</router-link>
    </p>

    <p class="reg__pie">
      ¿Ya tienes una cuenta?
      <router-link to="/login">Inicia sesión aquí</router-link>
    </p>
  </AuthLayout>
</template>

<style scoped>
.reg__pregunta {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.reg__modos {
  display: grid;
  gap: var(--ct-space-3);
}

.reg__modo {
  position: relative;
  display: grid;
  grid-template-columns: auto 1fr;
  grid-template-areas:
    'icon label'
    'icon text';
  gap: 2px var(--ct-space-4);
  text-align: left;
  padding: var(--ct-space-4) var(--ct-space-5);
  border: 1.5px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface);
  transition:
    border-color var(--ct-transition),
    background-color var(--ct-transition);
}

.reg__modo:hover {
  border-color: var(--ct-primary);
}

.reg__modo.is-active {
  border-color: var(--ct-primary);
  background: var(--ct-primary-softer);
  box-shadow: var(--ct-shadow-focus);
}

.reg__modo.is-active:hover {
  border-color: var(--ct-primary-strong);
  background: var(--ct-primary-soft);
}

.reg__modo:hover .reg__modo-icon {
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.reg__modo-icon {
  grid-area: icon;
  align-self: center;
  width: 42px;
  height: 42px;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-primary-fill);
  color: var(--ct-text-invert);
}

.reg__modo-label {
  grid-area: label;
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.reg__modo-text {
  grid-area: text;
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.reg__modo-check {
  position: absolute;
  top: var(--ct-space-4);
  right: var(--ct-space-4);
  width: 22px;
  height: 22px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  border: 1.5px solid var(--ct-border-strong);
  color: transparent;
}

.reg__modo.is-active .reg__modo-check {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.reg__pares {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
}

.reg__fuerza {
  margin-top: var(--ct-space-2);
}

.reg__requisitos {
  display: grid;
  gap: 2px;
  margin-top: var(--ct-space-2);
  padding: 0;
  list-style: none;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.reg__requisitos li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.reg__requisitos li.is-ok {
  color: var(--ct-success);
}

.reg__acciones {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
}

.reg__insignias {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-2);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
}

.reg__insignia {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  padding: 0.3rem 0.7rem;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-surface-alt);
  border: 1px solid var(--ct-border);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
}

.reg__pie {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  text-align: center;
}

.reg__pie a {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

@media (max-width: 560px) {
  .reg__pares {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
