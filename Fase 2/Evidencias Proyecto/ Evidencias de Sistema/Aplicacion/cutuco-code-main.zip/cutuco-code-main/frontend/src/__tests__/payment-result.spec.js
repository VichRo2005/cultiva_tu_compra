/**
 * CuTuCo — PaymentResultView (Webpay Mall, RF-005).
 *
 * Cubre los cuatro escenarios de retorno de Transbank y el contrato actual de
 * `POST /api/webpay/confirmar`: respuesta con lista de pedidos
 * (`checkout_id` + `pedidos[]`), estados autorizado/parcial/rechazado,
 * `requiere_conciliacion` y la idempotencia (`ya_confirmado`).
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import { createMemoryHistory, createRouter } from 'vue-router'

const servicios = vi.hoisted(() => ({
  confirmarPago: vi.fn(),
  getPedidoDetalle: vi.fn(),
}))
const carrito = vi.hoisted(() => ({ limpiar: vi.fn() }))
const toasts = vi.hoisted(() => ({ success: vi.fn(), error: vi.fn(), warning: vi.fn(), info: vi.fn() }))

vi.mock('@/services/orders', () => servicios)
vi.mock('@/stores/cart', () => ({ useCartStore: () => ({ limpiar: carrito.limpiar }) }))
vi.mock('@/stores/ui', () => ({ useUiStore: () => toasts }))

import PaymentResultView from '@/views/client/PaymentResultView.vue'

const PEDIDO = {
  id: 'ped-1',
  codigo_pedido: 'CUTU-20261001-AAA111',
  estado: 'pagado',
  creado_en: '2026-10-01T10:00:00Z',
  subtotal_productos: 10000,
  monto_fee_plataforma: 500,
  total: 13500,
  nombre_destinatario: 'Ana',
  direccion_entrega: 'Calle 1',
  referencia_entrega: null,
  detalles: [{ id: 'd1', producto_id: 'prod-item-1', codigo_producto: 'PRD-000201', producto_nombre: 'Tomates', precio_unitario: 5000, cantidad: 2, subtotal: 10000 }],
  pago: {
    estado: 'autorizado',
    monto: 13500,
    buy_order: 'BO-1',
    codigo_autorizacion: '777',
    creado_en: '2026-10-01T10:01:00Z',
  },
  envio: { estado: 'preparacion', tarifa_fija: 3500, creado_en: '2026-10-01T10:02:00Z' },
  productor: { nombre_comercial: 'Huerta Sur' },
  comuna: { nombre: 'Paine' },
}

function crearRouter(query = '') {
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [
      { path: '/pago/retorno', name: 'pago-retorno', component: PaymentResultView },
      { path: '/cliente/pedidos', name: 'cliente-pedidos', component: { template: '<div />' } },
      { path: '/cliente/pedidos/:id', name: 'cliente-pedido-detalle', component: { template: '<div />' } },
      { path: '/carrito', name: 'carrito', component: { template: '<div />' } },
      { path: '/catalogo', name: 'catalogo', component: { template: '<div />' } },
    ],
  })
  router.push(`/pago/retorno${query}`)
  return router
}

let wrapper
async function montar(query = '') {
  const router = crearRouter(query)
  await router.isReady()
  wrapper = mount(PaymentResultView, {
    global: {
      plugins: [router],
      stubs: { RouterLink: { template: '<a><slot /></a>' } },
    },
  })
  await flushPromises()
  return wrapper
}

beforeEach(() => {
  vi.resetAllMocks()
  servicios.getPedidoDetalle.mockResolvedValue(PEDIDO)
})

afterEach(() => {
  wrapper?.unmount()
  document.body.innerHTML = ''
})

describe('PaymentResultView · retorno Webpay Mall', () => {
  it('autorizado con 1 pedido: confirma, limpia el carrito y muestra enlace de seguimiento', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: true,
      checkout_id: 'chk-1',
      pedidos: [{
        pedido_id: 'ped-1',
        codigo_pedido: 'CTC-20261119-ABC123',
        productor_id: 'prod-1',
        estado_pedido: 'pagado',
        total: 13500,
        productos: [{ producto_id: 'prod-item-1', codigo_producto: 'PRD-000201', producto_nombre: 'Tomates' }],
      }],
      estado: 'autorizado',
      requiere_conciliacion: false,
      ya_confirmado: false,
    })

    await montar('?token_ws=tok-123')

    expect(servicios.confirmarPago).toHaveBeenCalledWith('tok-123')
    expect(servicios.getPedidoDetalle).toHaveBeenCalledWith('ped-1')
    expect(carrito.limpiar).toHaveBeenCalled()
    expect(toasts.success).toHaveBeenCalled()
    expect(wrapper.text()).toContain('Pago autorizado por Webpay')
    expect(wrapper.text()).toContain('CUTU-20261001-AAA111')
    expect(wrapper.text()).toContain('PRD-000201')
    expect(wrapper.text()).toContain('Ver seguimiento')
    expect(wrapper.text()).not.toContain('retenido por CuTuCo')
  })

  it('mantiene el identificador del producto si la sesión aún no se restauró', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: true,
      checkout_id: 'chk-1',
      pedidos: [{
        pedido_id: 'ped-1',
        codigo_pedido: 'CTC-20261119-ABC123',
        productor_id: 'prod-1',
        estado_pedido: 'pagado',
        total: 13500,
        productos: [{ producto_id: 'prod-item-1', codigo_producto: 'PRD-000201', producto_nombre: 'Tomates' }],
      }],
      estado: 'autorizado',
      requiere_conciliacion: false,
      ya_confirmado: false,
    })
    servicios.getPedidoDetalle.mockRejectedValue(new Error('Sesión restaurándose'))

    await montar('?token_ws=tok-123')

    expect(wrapper.text()).toContain('CTC-20261119-ABC123')
    expect(wrapper.text()).toContain('PRD-000201')
    expect(wrapper.text()).toContain('Tomates')
  })

  it('TBK_TOKEN (sin token_ws): pago anulado y NO llama confirmar', async () => {
    await montar('?TBK_TOKEN=tok-anulado&TBK_ORDEN_COMPRA=BO-9')

    expect(servicios.confirmarPago).not.toHaveBeenCalled()
    expect(wrapper.text()).toContain('Pago anulado')
    expect(wrapper.text()).toContain('BO-9')
  })

  it('TBK_ID_SESION: sesión de pago expirada y NO llama confirmar', async () => {
    await montar('?TBK_ID_SESION=ses-1&TBK_ORDEN_COMPRA=BO-10')

    expect(servicios.confirmarPago).not.toHaveBeenCalled()
    expect(wrapper.text()).toContain('Sesión de pago expirada')
  })

  it('token_ws + TBK_TOKEN juntos: transacción inválida y NO confirma', async () => {
    await montar('?token_ws=tok-123&TBK_TOKEN=tok-anulado')

    expect(servicios.confirmarPago).not.toHaveBeenCalled()
    expect(wrapper.text()).toContain('El pago es inválido')
  })

  it('ya_confirmado: presenta la confirmación normal de compra', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: true,
      checkout_id: 'chk-1',
      pedidos: [{ pedido_id: 'ped-1', productor_id: 'prod-1', estado_pedido: 'pagado', total: 13500 }],
      estado: 'autorizado',
      requiere_conciliacion: false,
      ya_confirmado: true,
    })

    await montar('?token_ws=tok-123')

    expect(servicios.confirmarPago).toHaveBeenCalledTimes(1)
    expect(wrapper.text()).toContain('Compra confirmada')
    expect(wrapper.text()).not.toContain('ya estaba confirmado')
    expect(toasts.success).toHaveBeenCalledWith(
      'Compra confirmada',
      expect.stringContaining('pago'),
    )
  })

  it('parcial: aviso de cobro parcial con la lista de pedidos', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: true,
      checkout_id: 'chk-1',
      pedidos: [{ pedido_id: 'ped-1', productor_id: 'prod-1', estado_pedido: 'pagado', total: 13500 }],
      estado: 'parcial',
      requiere_conciliacion: false,
      ya_confirmado: false,
    })

    await montar('?token_ws=tok-123')

    expect(wrapper.text()).toContain('Pago autorizado de forma parcial')
    expect(carrito.limpiar).toHaveBeenCalled()
  })

  it('rechazado: informa el rechazo y ofrece volver al carrito', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: false,
      checkout_id: null,
      pedidos: [],
      estado: 'rechazado',
      requiere_conciliacion: false,
      ya_confirmado: false,
    })

    await montar('?token_ws=tok-123')

    expect(wrapper.text()).toContain('El pago fue rechazado')
    expect(carrito.limpiar).not.toHaveBeenCalled()
    expect(toasts.error).toHaveBeenCalled()
  })

  it('requiere_conciliacion: explica la revisión sin lenguaje técnico', async () => {
    servicios.confirmarPago.mockResolvedValue({
      ok: true,
      checkout_id: 'chk-1',
      pedidos: [{ pedido_id: 'ped-1', productor_id: 'prod-1', estado_pedido: 'pagado', total: 13500 }],
      estado: 'autorizado',
      requiere_conciliacion: true,
      ya_confirmado: false,
    })

    await montar('?token_ws=tok-123')

    expect(wrapper.text()).toContain('Estamos revisando el pago')
  })
})
