<script setup>
/** CuTuCo — Paginación. */
import CtButton from './CtButton.vue'
import { computed } from 'vue'

const props = defineProps({
  page: { type: Number, default: 1 },
  total: { type: Number, default: 0 },
  pageSize: { type: Number, default: 12 },
  label: { type: String, default: 'resultados' },
})

const emit = defineEmits(['update:page', 'update:pageSize'])

const totalPages = computed(() => Math.max(1, Math.ceil(props.total / props.pageSize)))
const from = computed(() => (props.total === 0 ? 0 : (props.page - 1) * props.pageSize + 1))
const to = computed(() => Math.min(props.total, props.page * props.pageSize))

const pages = computed(() => {
  const out = []
  const start = Math.max(1, Math.min(props.page - 2, totalPages.value - 4))
  const end = Math.min(totalPages.value, start + 4)
  for (let i = start; i <= end; i += 1) out.push(i)
  return out
})

function go(page) {
  if (page < 1 || page > totalPages.value || page === props.page) return
  emit('update:page', page)
}
</script>

<template>
  <div v-if="total > pageSize || pageSize !== 12" class="ct-pagination">
    <span class="ct-pagination__info">
      Mostrando <strong>{{ from }}–{{ to }}</strong> de <strong>{{ total }}</strong> {{ label }}
    </span>

    <div class="ct-pagination__controls">
      <CtButton
        variant="secondary"
        size="sm"
        :disabled="page <= 1"
        @click="go(page - 1)"
      >
        Anterior
      </CtButton>

      <button
        v-for="p in pages"
        :key="p"
        type="button"
        class="ct-pagination__page"
        :class="{ 'is-active': p === page }"
        @click="go(p)"
      >
        {{ p }}
      </button>

      <CtButton
        variant="secondary"
        size="sm"
        :disabled="page >= totalPages"
        @click="go(page + 1)"
      >
        Siguiente
      </CtButton>
    </div>

    <select
      class="ct-pagination__size"
      :value="pageSize"
      @change="emit('update:pageSize', Number($event.target.value))"
    >
      <option :value="6">6 por página</option>
      <option :value="12">12 por página</option>
      <option :value="24">24 por página</option>
      <option :value="48">48 por página</option>
    </select>
  </div>
</template>

<style scoped>
.ct-pagination {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
  padding-top: var(--ct-space-4);
}

.ct-pagination__info {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.ct-pagination__controls {
  display: flex;
  align-items: center;
  gap: var(--ct-space-1);
}

.ct-pagination__page {
  min-width: 34px;
  height: 34px;
  border-radius: var(--ct-radius);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
  transition: all var(--ct-transition);
}

.ct-pagination__page:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.ct-pagination__page.is-active {
  background: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.ct-pagination__page.is-active:hover {
  background: var(--ct-primary-ink);
  color: var(--ct-text-invert);
}

.ct-pagination__size {
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  padding: 0.4rem var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  background: var(--ct-surface);
  color: var(--ct-text);
  transition:
    border-color var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-pagination__size:hover {
  border-color: var(--ct-border-strong);
}

.ct-pagination__size:focus {
  outline: none;
  border-color: var(--ct-primary);
  box-shadow: var(--ct-shadow-focus);
}
</style>
