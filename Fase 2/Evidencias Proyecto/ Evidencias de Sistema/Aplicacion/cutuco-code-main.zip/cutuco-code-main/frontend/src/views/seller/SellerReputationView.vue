<script setup>
/**
 * CuTuCo — Reputación y sanciones del productor.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no está en el menú del producto):
 *   Esta ventana se conserva para la GALERÍA DE DESARROLLO
 *   (`VITE_DEV_GALLERY=true`): muestra el score ponderado 40/40/20, la pausa
 *   automática y el desglose por criterios del prototipo anterior, que salieron
 *   del ERS vigente (RF-006 v2.0 usa el promedio simple de 1 a 5).
 *
 *   El panel del vendedor vigente (`SellerDashboardView`) muestra el promedio
 *   real con `ReputationGauge`, y las sanciones manuales se gestionan en
 *   `AdminSanctionsView` (RF-026). Los criterios ponderados los declaró la
 *   migración de galería y quedan nulos en los datos nuevos.
 */
import { computed } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtChart from '@/components/base/CtChart.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import ReputationBreakdown from '@/components/domain/ReputationBreakdown.vue'
import ReputationGauge from '@/components/domain/ReputationGauge.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import {
  ESTADO_PEDIDO,
  ESTADO_POSTULACION,
  ESTADO_SANCION,
  LABELS,
  REGLAS_HEREDADAS as REGLAS,
} from '@/lib/constants'
import { exportExcel } from '@/lib/csv'
import {
  formatCLP,
  formatDate,
  formatMonthYear,
  formatNumber,
  formatPercent,
  formatScore,
} from '@/lib/format'
import { useAsync } from '@/composables/useAsync'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import { listPedidos } from '@/services/orders'
import {
  getDashboardVendedor,
  getMiPostulacion,
  listMisApelaciones,
  listMisSanciones,
} from '@/services/seller'

const ui = useUiStore()
const geo = useGeographyStore()

const { data, loading, error, run } = useAsync(async () => {
  geo.load()
  const [dashboard, postulacion, pedidosRes] = await Promise.all([
    getDashboardVendedor({ dias: 365 }),
    getMiPostulacion(),
    listPedidos({ rol: 'productor', page: 1, pageSize: 200 }),
  ])

  if (!dashboard)
    return { dashboard: null, postulacion, pedidos: [], sanciones: [], apelaciones: [] }

  const [sancionesRes, apelacionesRes] = await Promise.all([
    listMisSanciones().catch(() => []),
    listMisApelaciones().catch(() => []),
  ])

  return {
    dashboard,
    postulacion,
    pedidos: pedidosRes.items ?? [],
    sanciones: sancionesRes ?? [],
    apelaciones: apelacionesRes ?? [],
  }
})

const dashboard = computed(() => data.value?.dashboard ?? null)
const evaluaciones = computed(() => dashboard.value?.evaluaciones ?? [])
const pedidos = computed(() => data.value?.pedidos ?? [])
const sanciones = computed(() => data.value?.sanciones ?? [])
const apelaciones = computed(() => data.value?.apelaciones ?? [])

const ubicacion = computed(() => ({
  comuna: geo.nombreComuna(dashboard.value?.productor?.comuna_origen_id),
  region: geo.nombreRegion(geo.regionDeComuna(dashboard.value?.productor?.comuna_origen_id)),
}))

/** El sello de identidad se deriva de la postulación aprobada y del productor activo. */
const identidadVerificada = computed(() => {
  const estado = data.value?.postulacion?.estado
  return estado === ESTADO_POSTULACION.APROBADA && Boolean(dashboard.value?.productor?.activo)
})

/* ------------------------------------------------------------------ */
/* Indicadores                                                         */
/* ------------------------------------------------------------------ */

const resumen = computed(() => {
  const evals = evaluaciones.value
  const promediar = (fn) =>
    evals.length ? evals.reduce((acc, e) => acc + fn(e), 0) / evals.length : null

  const aTiempo = evals.filter((e) => e.entrega_a_tiempo === 1).length
  const entregados = pedidos.value.filter((p) => p.envio?.entregado_en).length
  const conEnvio = pedidos.value.filter((p) => p.envio).length

  const reclamos = pedidos.value.filter((p) => p.estado === ESTADO_PEDIDO.RECLAMADO).length

  return {
    tasaEntrega: evals.length ? aTiempo / evals.length : conEnvio ? entregados / conEnvio : null,
    tiempoRespuesta: promediar((e) => Number(e.respuesta_reclamos)),
    calidad: promediar((e) => Number(e.calidad)),
    puntualidad: promediar((e) => (e.entrega_a_tiempo === 1 ? 5 : 1)),
    comunicacion: promediar((e) => Number(e.respuesta_reclamos)),
    disputasResueltas: reclamos,
    disputasTotales: pedidos.value.length,
    conDatos: evals.length > 0,
  }
})

/* ------------------------------------------------------------------ */
/* Historial de reputación                                             */
/* ------------------------------------------------------------------ */

const historial = computed(() => {
  const meses = []
  for (let i = 5; i >= 0; i -= 1) {
    const fecha = new Date()
    fecha.setDate(1)
    fecha.setMonth(fecha.getMonth() - i)
    const clave = `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, '0')}`
    const delMes = evaluaciones.value.filter((e) => {
      const d = new Date(e.creado_en)
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` === clave
    })
    meses.push({
      clave,
      etiqueta: formatMonthYear(fecha.toISOString()),
      puntaje: delMes.length
        ? delMes.reduce((acc, e) => acc + Number(e.puntaje_resultante ?? 0), 0) / delMes.length
        : null,
      cantidad: delMes.length,
    })
  }
  return meses
})

const graficoHistorial = computed(() => ({
  labels: historial.value.map((m) => m.etiqueta),
  datasets: [
    {
      label: 'Puntaje promedio mensual',
      data: historial.value.map((m) =>
        m.puntaje === null ? null : Math.round(m.puntaje * 100) / 100,
      ),
      spanGaps: true,
    },
  ],
}))

/* ------------------------------------------------------------------ */
/* Logros, áreas de mejora y verificación                              */
/* ------------------------------------------------------------------ */

function meta(cumplido, titulo, detalle) {
  return { cumplido, titulo, detalle }
}

const logros = computed(() => {
  const evals = evaluaciones.value
  const datosReputacion = dashboard.value?.reputation
  return [
    meta(
      identidadVerificada.value,
      'Identidad verificada',
      'Postulación aprobada y tienda activa en CuTuCo.',
    ),
    meta(
      datosReputacion && Number(datosReputacion.puntaje) >= REGLAS.REPUTACION.alerta,
      'Reputación saludable',
      `Puntaje sobre ${formatNumber(REGLAS.REPUTACION.alerta, 2)} en el ranking de productores.`,
    ),
    meta(
      pedidos.value.some((p) => p.envio?.entregado_en),
      'Primera entrega completada',
      'Al menos un pedido entregado y confirmado con el código de entrega.',
    ),
    meta(
      !pedidos.value.some((p) => p.estado === ESTADO_PEDIDO.RECLAMADO),
      'Sin reclamos abiertos',
      'Ningún pedido con disputa en curso.',
    ),
    meta(
      evals.length > 0,
      'Clientes que evaluaron',
      `${formatNumber(evals.length)} evaluaciones registradas en tu historial.`,
    ),
  ]
})

const areasMejora = computed(() => {
  const r = resumen.value
  const areas = [
    {
      label: 'Puntualidad en entrega',
      valor: r.puntualidad,
      peso: REGLAS.REPUTACION.pesos.entrega_a_tiempo,
    },
    {
      label: 'Calidad del producto',
      valor: r.calidad,
      peso: REGLAS.REPUTACION.pesos.calidad,
    },
    {
      label: 'Respuesta a reclamos',
      valor: r.comunicacion,
      peso: REGLAS.REPUTACION.pesos.respuesta_reclamos,
    },
  ]
  return areas
    .filter((a) => a.valor !== null)
    .sort((a, b) => a.valor - b.valor)
    .slice(0, 3)
})

const checklist = computed(() => [
  {
    ok: identidadVerificada.value,
    texto: 'Validación de identidad aprobada por un administrador',
  },
  {
    ok: Boolean(dashboard.value?.productor?.activo),
    texto: 'Tienda activa y visible en el catálogo',
  },
  {
    ok: pedidos.value.every((p) => p.envio?.entregado_en || p.estado !== ESTADO_PEDIDO.COMPLETADO),
    texto: 'Envíos entregados con el código de entrega validado',
  },
  {
    ok: !sanciones.value.some((s) => s.estado === ESTADO_SANCION.ACTIVA),
    texto: 'Sin sanciones activas en curso',
  },
  {
    ok: Number(dashboard.value?.reputation?.puntaje ?? 0) >= REGLAS.REPUTACION.alerta,
    texto: `Puntaje por sobre el umbral de alerta (${formatNumber(REGLAS.REPUTACION.alerta, 2)})`,
  },
])

/* ------------------------------------------------------------------ */
/* Sanciones y reporte                                                 */
/* ------------------------------------------------------------------ */

const columnasSanciones = [
  { key: 'inicio_en', label: 'Inicio', format: (v) => formatDate(v) },
  { key: 'tipo', label: 'Tipo', format: (v) => LABELS.tipoSancion[v] ?? v },
  { key: 'motivo', label: 'Motivo' },
  { key: 'accion', label: 'Acción', format: (v) => LABELS.accionSancion[v] ?? v },
  { key: 'estado', label: 'Estado', width: '130px' },
]

async function exportar() {
  const filas = evaluaciones.value.map((e) => ({
    fecha: formatDate(e.creado_en),
    puntaje: formatScore(e.puntaje_resultante),
    entrega_a_tiempo: e.entrega_a_tiempo === 1 ? 'Sí' : 'No',
    calidad: e.calidad,
    respuesta_reclamos: e.respuesta_reclamos,
    comentario: e.comentario ?? '',
  }))
  const ok = await exportExcel(filas, 'reputacion-productor', [
    { key: 'fecha', label: 'Fecha' },
    { key: 'puntaje', label: 'Puntaje' },
    { key: 'entrega_a_tiempo', label: 'Entrega a tiempo' },
    { key: 'calidad', label: 'Calidad' },
    { key: 'respuesta_reclamos', label: 'Respuesta a reclamos' },
    { key: 'comentario', label: 'Comentario' },
  ])
  if (ok) ui.success('Reporte generado', 'Se descargó el Excel con tus evaluaciones.')
  else ui.warning('Sin evaluaciones para exportar', 'Todavía no tienes reseñas registradas.')
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">
          {{ dashboard?.productor?.nombre_comercial ?? 'Reputación del productor' }}
        </h1>
        <p class="page-head__subtitle">
          {{
            dashboard
              ? `${ubicacion.comuna}, ${ubicacion.region} · puntaje, reseñas y sanciones de tu tienda`
              : 'Puntaje, reseñas y sanciones de tu tienda'
          }}
        </p>
      </div>
      <div class="page-head__actions">
        <CtBadge :tone="identidadVerificada ? 'success' : 'warning'" dot>
          {{ identidadVerificada ? 'Identidad Verificada' : 'Identidad en revisión' }}
        </CtBadge>
        <CtButton variant="secondary" :disabled="!evaluaciones.length" @click="exportar">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Descargar Reporte
        </CtButton>
        <CtButton to="/vendedor/tienda">
          <template #icon><CtIcon name="store" :size="16" /></template>
          Mejorar mi Tienda
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="loading" label="Cargando tu reputación" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar la reputación">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
    </CtAlert>

    <CtAlert v-else-if="!dashboard" tone="info" title="Todavía no tienes tienda">
      <p>
        La reputación se calcula una vez que tu cuenta tenga una tienda de productor verificada.
      </p>
      <CtButton size="sm" variant="secondary" to="/vendedor/tienda">Ver mi tienda</CtButton>
    </CtAlert>

    <template v-else>
      <!-- ============ Encabezado con puntaje ============ -->
      <div class="cabecera">
        <div>
          <p class="eyebrow">{{ dashboard.productor.nombre_comercial }}</p>
          <h2 class="cabecera__titulo">
            {{ dashboard.productor.nombre_comercial }} · {{ ubicacion.comuna }},
            {{ ubicacion.region }}
          </h2>
          <div class="cabecera__estrellas">
            <CtRatingStars
              :model-value="Number(dashboard.reputation.puntaje)"
              :size="16"
              show-value
            />
            <span class="text-sm text-muted">
              ({{ formatNumber(dashboard.reputation.cantidad) }} reseñas)
            </span>
          </div>
        </div>
        <CtBadge tone="success" dot>Productor Verificado</CtBadge>
      </div>

      <CtAlert tone="neutral" compact title="Cómo se calcula tu puntaje">
        <p>
          Entregas a tiempo {{ Math.round(REGLAS.REPUTACION.pesos.entrega_a_tiempo * 100) }}% ·
          Calidad {{ Math.round(REGLAS.REPUTACION.pesos.calidad * 100) }}% · Respuesta a reclamos
          {{ Math.round(REGLAS.REPUTACION.pesos.respuesta_reclamos * 100) }}%. Bajo
          {{ formatNumber(REGLAS.REPUTACION.alerta, 2) }} entras en zona de riesgo y bajo
          {{ formatNumber(REGLAS.REPUTACION.pausa, 2) }} tu tienda se pausa automáticamente.
        </p>
      </CtAlert>

      <!-- ============ Indicadores ============ -->
      <div class="grid-kpi">
        <CtStatCard
          label="Tasa de Entrega"
          :value="resumen.tasaEntrega === null ? '—' : formatPercent(resumen.tasaEntrega, 0)"
          tone="success"
          :progress="resumen.tasaEntrega === null ? null : resumen.tasaEntrega * 100"
          hint="Evaluaciones con entrega a tiempo"
        />
        <CtStatCard
          label="Tiempo de Respuesta"
          :value="resumen.tiempoRespuesta === null ? '—' : formatNumber(resumen.tiempoRespuesta, 2)"
          unit="/ 5,0"
          tone="info"
          :progress="resumen.tiempoRespuesta === null ? null : resumen.tiempoRespuesta * 20"
          hint="Índice de respuesta a reclamos"
        />
        <CtStatCard
          label="Calidad de Producto"
          :value="resumen.calidad === null ? '—' : formatNumber(resumen.calidad, 2)"
          unit="/ 5,0"
          tone="primary"
          :progress="resumen.calidad === null ? null : resumen.calidad * 20"
          hint="Puntaje medio declarado por clientes"
        />
        <CtStatCard
          label="Disputas Resueltas"
          :value="formatNumber(resumen.disputasResueltas)"
          tone="danger"
          :hint="`Sobre ${formatNumber(resumen.disputasTotales)} pedidos recibidos`"
        />
      </div>

      <!-- ============ Gráfico + reseñas ============ -->
      <div class="grid">
        <div class="col-7">
          <CtCard
            title="Historial de Reputación"
            subtitle="Puntaje promedio de los últimos 6 meses"
          >
            <CtChart
              v-if="resumen.conDatos"
              type="line"
              :labels="graficoHistorial.labels"
              :datasets="graficoHistorial.datasets"
              :height="260"
              :begin-at-zero="false"
              :show-legend="false"
            />
            <CtEmptyState
              v-else
              compact
              icon="star"
              title="Sin historial todavía"
              message="Cuando tus clientes te evalúen, el puntaje promedio mensual aparecerá aquí."
            />
            <p v-if="resumen.conDatos" class="text-xs text-muted">
              El puntaje histórico de tu tienda es
              <strong>{{ formatNumber(dashboard.reputation.puntaje, 2) }}</strong> sobre 5,0 con
              {{ formatNumber(dashboard.reputation.cantidad) }} evaluaciones.
            </p>
          </CtCard>
        </div>

        <div class="col-5 stack">
          <ReputationGauge
            :puntaje="Number(dashboard.reputation.puntaje)"
            :cantidad="Number(dashboard.reputation.cantidad)"
            :activo="Boolean(dashboard.reputation.activa)"
            size="md"
          />

          <CtCard title="Reseñas Recientes" subtitle="Lo que dicen tus clientes">
            <template #actions>
              <CtButton size="sm" variant="ghost" to="/vendedor/tienda">
                Mejorar mi tienda
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!evaluaciones.length"
              compact
              icon="star"
              title="Sin reseñas todavía"
              message="Las reseñas aparecen cuando el cliente confirma la recepción de un pedido."
            />

            <ul v-else class="resenas">
              <li
                v-for="evaluacion in evaluaciones.slice(0, 4)"
                :key="evaluacion.id"
                class="resena"
              >
                <div class="row row--between">
                  <CtRatingStars :model-value="Number(evaluacion.puntaje_resultante)" :size="13" />
                  <span class="text-xs text-muted">{{ formatDate(evaluacion.creado_en) }}</span>
                </div>
                <p v-if="evaluacion.comentario" class="text-sm text-soft">
                  “{{ evaluacion.comentario }}”
                </p>
                <p class="text-xs text-muted">
                  {{
                    evaluacion.entrega_a_tiempo === 1 ? 'Entrega a tiempo' : 'Entrega con retraso'
                  }}
                  · calidad {{ evaluacion.calidad }}/5 · respuesta
                  {{ evaluacion.respuesta_reclamos }}/5
                </p>
              </li>
            </ul>
          </CtCard>
        </div>
      </div>

      <!-- ============ Logros + mejora + verificación ============ -->
      <div class="grid">
        <div class="col-4">
          <CtCard title="Logros Alcanzados" subtitle="Hitos de tu tienda">
            <ul class="logros">
              <li v-for="item in logros" :key="item.titulo" class="logro">
                <span class="logro__icon" :class="{ 'is-off': !item.cumplido }" aria-hidden="true">
                  <CtIcon name="check" :size="14" />
                </span>
                <div>
                  <p class="logro__titulo">{{ item.titulo }}</p>
                  <p class="text-xs text-muted">{{ item.detalle }}</p>
                </div>
              </li>
            </ul>
          </CtCard>
        </div>

        <div class="col-4">
          <CtCard title="Áreas de Mejora" subtitle="Dimensiones con menor desempeño">
            <CtEmptyState
              v-if="!areasMejora.length"
              compact
              icon="reports"
              title="Sin datos suficientes"
              message="Necesitas al menos una evaluación para identificar áreas de mejora."
            />
            <ul v-else class="mejoras">
              <li v-for="area in areasMejora" :key="area.label">
                <div class="row row--between">
                  <span class="text-sm">{{ area.label }}</span>
                  <span class="text-xs text-muted">
                    {{ formatNumber(area.valor, 2) }} · peso {{ Math.round(area.peso * 100) }}%
                  </span>
                </div>
                <CtProgressBar
                  :value="area.valor"
                  :max="5"
                  size="sm"
                  :tone="area.valor >= 4 ? 'success' : area.valor >= 3 ? 'warning' : 'danger'"
                />
              </li>
            </ul>
            <template #footer>
              <CtButton size="sm" variant="ghost" to="/vendedor/pedidos">
                Revisar pedidos con reclamos
              </CtButton>
            </template>
          </CtCard>

          <CtCard title="Desglose del puntaje">
            <ReputationBreakdown :evaluaciones="evaluaciones" :mostrar-historial="false" />
          </CtCard>
        </div>

        <div class="col-4 stack">
          <CtCard title="Estado de Verificación" subtitle="Requisitos que cumple tu tienda">
            <ul class="checklist">
              <li v-for="item in checklist" :key="item.texto">
                <CtIcon :name="item.ok ? 'check' : 'close'" :size="14" />
                <span>{{ item.texto }}</span>
              </li>
            </ul>
            <template #footer>
              <CtButton size="sm" variant="ghost" to="/vendedor/tienda">
                Ver mi perfil de tienda
              </CtButton>
            </template>
          </CtCard>

          <CtCard title="Sanciones" subtitle="Aplicadas por la plataforma o por un administrador">
            <CtEmptyState
              v-if="!sanciones.length"
              compact
              icon="shield"
              title="Sin sanciones registradas"
              message="Mantén entregas a tiempo y confirma el código de entrega para evitar amonestaciones."
            />

            <CtTable
              v-else
              :columns="columnasSanciones"
              :rows="sanciones"
              dense
              min-width="520px"
              empty-icon=""
              empty-title="Sin sanciones"
            >
              <template #cell-motivo="{ row }">
                <p>{{ row.motivo }}</p>
                <p class="text-xs text-muted">
                  {{
                    row.automatica
                      ? 'Sanción automática'
                      : row.puntaje_disparador
                        ? `Disparador: ${formatScore(row.puntaje_disparador)}`
                        : 'Sin puntaje disparador registrado'
                  }}
                </p>
              </template>
              <template #cell-estado="{ row }">
                <StatusBadge type="sancion" :value="row.estado" size="sm" />
              </template>
            </CtTable>
          </CtCard>

          <CtCard v-if="apelaciones.length" title="Apelaciones" subtitle="Solicitudes en curso">
            <ul class="apelaciones">
              <li v-for="apelacion in apelaciones" :key="apelacion.id">
                <div class="row row--between">
                  <span class="text-sm font-semibold">Apelación</span>
                  <StatusBadge type="apelacion" :value="apelacion.estado" size="sm" />
                </div>
                <p class="text-xs text-muted">
                  Presentada el {{ formatDate(apelacion.creado_en) }}
                </p>
                <p class="text-sm text-soft clamp-2">{{ apelacion.fundamento }}</p>
                <p v-if="apelacion.resolucion" class="text-xs text-success">
                  {{ apelacion.resolucion }}
                </p>
              </li>
            </ul>
          </CtCard>
        </div>
      </div>

      <CtCard title="Resumen económico del período">
        <div class="economico">
          <div>
            <p class="eyebrow">Ventas del período</p>
            <p class="text-2xl font-bold">{{ formatCLP(dashboard.ventasMes) }}</p>
          </div>
          <div>
            <p class="eyebrow">Ingresos netos del productor</p>
            <p class="text-2xl font-bold text-success">
              {{ formatCLP(dashboard.ingresosLiquidos) }}
            </p>
          </div>
          <div>
            <p class="eyebrow">Comisión de plataforma</p>
            <p class="text-2xl font-bold text-accent">
              {{ formatCLP(dashboard.comisionPagada) }}
            </p>
          </div>
        </div>
      </CtCard>
    </template>
  </div>
</template>

<style scoped>
.cabecera {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
  padding: var(--ct-space-5);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface);
}

.cabecera__titulo {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
  margin-block: var(--ct-space-1) var(--ct-space-2);
}

.cabecera__estrellas {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.resenas {
  list-style: none;
  margin: var(--ct-space-4) 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.resena {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.resena:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.logros {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.logro {
  display: flex;
  gap: var(--ct-space-3);
  align-items: flex-start;
}

.logro__icon {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-success-soft);
  color: var(--ct-success);
  flex-shrink: 0;
}

.logro__icon.is-off {
  background: var(--ct-neutral-soft);
  color: var(--ct-text-muted);
}

.logro__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.mejoras {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.checklist {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.checklist li {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.apelaciones {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.economico {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--ct-space-5);
}
</style>
