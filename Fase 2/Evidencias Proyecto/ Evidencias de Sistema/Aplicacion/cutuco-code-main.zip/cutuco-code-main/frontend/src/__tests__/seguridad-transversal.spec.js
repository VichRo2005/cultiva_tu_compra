/**
 * CuTuCo — Seguridad transversal (FL-19).
 *
 * Revalidación ejecutable de CK-0307/0310/0312/0313/0315/0318/0320/0321/0322:
 *   - CK-0312 XSS almacenado: nada de v-html/innerHTML en src y el nombre con
 *     HTML se renderiza como texto inerte;
 *   - CK-0313 inyección en filtros: el término de búsqueda se entrecomilla y se
 *     escapan comillas, barras y comodines LIKE antes de construir el `or` de
 *     PostgREST (el valor viaja como parámetro, nunca concatenado a SQL);
 *   - CK-0321 URLs firmadas KYB con TTL corto (60 s), nunca públicas permanentes;
 *   - CK-0307: el frontend versionado no contiene claves de servicio (JWT service
 *     role ni secretos reales); sólo la anon key pública por diseño.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { mount } from '@vue/test-utils'

const supabaseMock = vi.hoisted(() => ({ supabase: { from: vi.fn() } }))
vi.mock('@/lib/supabase.js', () => supabaseMock)

function archivosFuente(dir = 'src', excluir = new Set(['__tests__', 'dev'])) {
  const out = []
  for (const nombre of readdirSync(dir)) {
    const p = join(dir, nombre)
    if (statSync(p).isDirectory()) {
      if (!excluir.has(nombre)) out.push(...archivosFuente(p, excluir))
    } else if (/\.(vue|js)$/.test(nombre)) {
      out.push(p)
    }
  }
  return out
}

describe('CK-0312 · XSS almacenado', () => {
  it('src no usa v-html, innerHTML, insertAdjacentHTML ni document.write', () => {
    const riesgosos = archivosFuente().filter((p) =>
      /v-html|innerHTML|insertAdjacentHTML|document\.write/.test(readFileSync(p, 'utf8')),
    )
    expect(riesgosos).toEqual([])
  })

  it('un nombre con HTML se muestra como texto y no inyecta nodos', async () => {
    const { default: ProductCard } = await import('@/components/domain/ProductCard.vue')
    const malicioso = '<img src=x onerror=window.__xss=1><script>alert(1)</script>'
    const wrapper = mount(ProductCard, {
      props: {
        producto: {
          id: 'p-xss',
          nombre: malicioso,
          precio: 1000,
          stock: 5,
          unidad_medida: 'unidad',
          imagenPrincipal: null,
          categoria: { nombre: 'Verduras' },
        },
      },
      global: { stubs: { RouterLink: true } },
    })
    expect(wrapper.html()).not.toContain('onerror=')
    expect(wrapper.findAll('script').length).toBe(0)
    expect(wrapper.find('img[src="x"]').exists()).toBe(false)
    expect(globalThis.__xss).toBeUndefined()
    wrapper.unmount()

    // interpolación por defecto de Vue: el HTML del dato queda escapado (&lt;...&gt;)
    const { defineComponent } = await import('vue')
    const Demo = defineComponent({ props: ['texto'], template: '<span>{{ texto }}</span>' })
    const badge = mount(Demo, { props: { texto: malicioso } })
    expect(badge.html()).toContain('&lt;img')
    expect(badge.html()).not.toContain('<img')
    expect(badge.findAll('script').length).toBe(0)
    badge.unmount()
  })
})

describe('CK-0313 · inyección en filtros de búsqueda', () => {
  function queryMock() {
    const q = {}
    for (const m of ['select', 'eq', 'or', 'order']) q[m] = vi.fn(() => q)
    q.range = vi.fn(async () => ({ data: [], error: null, count: 0 }))
    return q
  }

  it('listarUsuarios entrecomilla y escapa el término antes del or de PostgREST', async () => {
    const q = queryMock()
    supabaseMock.supabase.from.mockReturnValue(q)
    const { listarUsuarios } = await import('@/services/adminUsuarios.js')
    await listarUsuarios({ page: 1, pageSize: 10, texto: '"; DROP TABLE perfiles; -- 100% _ *' })
    expect(q.or).toHaveBeenCalledTimes(1)
    const orArg = q.or.mock.calls[0][0]
    // cada campo usa ilike con el valor entre comillas dobles escapadas
    for (const campo of ['nombre', 'apellido', 'telefono']) {
      const re = new RegExp(`${campo}\\.ilike\\."((?:[^"\\\\]|\\\\.)*)"`)
      expect(orArg).toMatch(re)
    }
    // el texto del usuario no puede cerrar la comilla ni alterar la expresión
    const valores = [...orArg.matchAll(/ilike\."((?:[^"\\]|\\.)*)"/g)].map((m) => m[1])
    for (const v of valores) {
      expect(v.includes('DROP TABLE perfiles')).toBe(true) // queda como texto literal
      expect(v).not.toMatch(/[^\\]"/) // sin comillas sin escapar dentro
      expect(v).toContain('\\%') // el % del usuario se escapó como comodín literal
    }
  })
})

describe('CK-0321 · URLs firmadas KYB con TTL', () => {
  it('createSignedUrl siempre usa TTL corto (<= 1 h), nunca URL pública permanente', () => {
    for (const f of ['src/services/registro.js', 'src/services/admin.js']) {
      const src = readFileSync(f, 'utf8')
      const llamadas = src.match(/createSignedUrl\([^)]*\)/g) ?? []
      expect(llamadas.length).toBeGreaterThan(0)
      for (const llamada of llamadas) {
        const ttl = Number(llamada.match(/,\s*(\d+)\s*\)/)?.[1])
        expect(Number.isFinite(ttl)).toBe(true)
        expect(ttl).toBeGreaterThan(0)
        expect(ttl).toBeLessThanOrEqual(3600)
      }
    }
  })
})

describe('CK-0307 · secretos en el frontend versionado', () => {
  it('src no contiene claves de servicio (JWT service_role ni secretos reales)', () => {
    const hallazgos = archivosFuente().filter((p) =>
      /eyJ[A-Za-z0-9_-]{30,}|sb_secret_[A-Za-z0-9_-]{10,}|xkeysib-[A-Za-z0-9-]{20,}/.test(
        readFileSync(p, 'utf8'),
      ),
    )
    expect(hallazgos).toEqual([])
  })
})
