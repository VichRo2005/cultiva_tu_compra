<script setup>
/**
 * CuTuCo — Botón base.
 * Variantes: primary | accent | secondary | outline | ghost | danger | dark
 * Tamaños: sm | md | lg
 */
import { computed } from 'vue'

const props = defineProps({
  variant: { type: String, default: 'primary' },
  size: { type: String, default: 'md' },
  type: { type: String, default: 'button' },
  disabled: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  block: { type: Boolean, default: false },
  pill: { type: Boolean, default: false },
  to: { type: [String, Object], default: null },
  href: { type: String, default: null },
  iconOnly: { type: Boolean, default: false },
  title: { type: String, default: null },
})

const emit = defineEmits(['click'])

const isDisabled = computed(() => props.disabled || props.loading)

/**
 * Atributos del elemento raíz según el tipo de control.
 *
 * No se puede renderizar `:href="undefined"` junto a RouterLink: Vue lo trata
 * como atributo de fallthrough y pisa el `href` calculado por el router
 * (el enlace quedaba sin destino). Se envían sólo los atributos que aplican.
 */
const atributosElemento = computed(() => {
  if (tag.value === 'router-link') return { to: props.to }
  if (tag.value === 'a') return { href: props.href }
  return { type: props.type, disabled: isDisabled.value }
})

const tag = computed(() => {
  if (props.to) return 'router-link'
  if (props.href) return 'a'
  return 'button'
})

const classes = computed(() => [
  'ct-btn',
  `ct-btn--${props.variant}`,
  `ct-btn--${props.size}`,
  {
    'ct-btn--block': props.block,
    'ct-btn--pill': props.pill,
    'ct-btn--icon': props.iconOnly,
    'is-loading': props.loading,
  },
])

function onClick(event) {
  if (isDisabled.value) {
    event.preventDefault()
    return
  }
  emit('click', event)
}
</script>

<template>
  <component
    :is="tag"
    :class="classes"
    v-bind="atributosElemento"
    :aria-busy="loading || undefined"
    :title="title ?? undefined"
    @click="onClick"
  >
    <span v-if="loading" class="ct-btn__spinner" aria-hidden="true" />
    <slot v-else name="icon" />
    <span v-if="$slots.default" class="ct-btn__label"><slot /></span>
    <slot v-if="!loading" name="trailing" />
  </component>
</template>

<style scoped>
.ct-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--ct-space-2);
  border-radius: var(--ct-radius);
  font-weight: var(--ct-fw-semibold);
  line-height: 1.2;
  text-decoration: none;
  white-space: nowrap;
  border: 1px solid transparent;
  transition:
    background-color var(--ct-transition),
    border-color var(--ct-transition),
    color var(--ct-transition),
    box-shadow var(--ct-transition),
    transform var(--ct-transition);
}

.ct-btn:hover {
  text-decoration: none;
}

.ct-btn:active:not(:disabled) {
  transform: translateY(1px);
}

.ct-btn:focus-visible {
  outline: none;
  box-shadow: var(--ct-shadow-focus);
}

.ct-btn:disabled,
.ct-btn.is-loading {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none;
}

/* Tamaños */
.ct-btn--sm {
  font-size: var(--ct-fs-sm);
  padding: 0.375rem 0.75rem;
  min-height: 32px;
}

.ct-btn--md {
  font-size: var(--ct-fs-md);
  padding: 0.5rem 1rem;
  min-height: 40px;
}

.ct-btn--lg {
  font-size: var(--ct-fs-base);
  padding: 0.75rem 1.5rem;
  min-height: 48px;
}

.ct-btn--icon.ct-btn--sm {
  padding: 0.375rem;
  min-width: 32px;
}

.ct-btn--icon.ct-btn--md {
  padding: 0.5rem;
  min-width: 40px;
}

.ct-btn--icon.ct-btn--lg {
  padding: 0.75rem;
  min-width: 48px;
}

.ct-btn--block {
  display: flex;
  width: 100%;
}

.ct-btn--pill {
  border-radius: var(--ct-radius-pill);
}

/* Variantes */
.ct-btn--primary {
  background: var(--ct-primary-fill);
  color: var(--ct-text-invert);
  box-shadow: var(--ct-shadow-xs);
}

.ct-btn--primary:hover:not(:disabled) {
  background: var(--ct-primary-fill-hover);
  box-shadow: var(--ct-shadow-sm);
}

.ct-btn--accent {
  background: var(--ct-accent-strong);
  color: var(--ct-text-invert);
  box-shadow: var(--ct-shadow-xs);
}

.ct-btn--accent:hover:not(:disabled) {
  background: var(--ct-accent-fill-active);
  color: var(--ct-text-invert);
  box-shadow: var(--ct-shadow-sm);
}

.ct-btn--secondary {
  background: var(--ct-surface);
  color: var(--ct-text);
  border-color: var(--ct-border-strong);
}

.ct-btn--secondary:hover:not(:disabled) {
  background: var(--ct-surface-alt);
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.ct-btn--outline {
  background: transparent;
  color: var(--ct-primary-strong);
  border-color: var(--ct-primary);
}

.ct-btn--outline:hover:not(:disabled) {
  background: var(--ct-primary-soft);
}

.ct-btn--ghost {
  background: transparent;
  color: var(--ct-text-soft);
}

.ct-btn--ghost:hover:not(:disabled) {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.ct-btn--danger {
  background: var(--ct-danger);
  color: var(--ct-text-invert);
  box-shadow: var(--ct-shadow-xs);
}

.ct-btn--danger:hover:not(:disabled) {
  background: var(--ct-danger-strong);
  box-shadow: var(--ct-shadow-sm);
}

.ct-btn--dark {
  background: var(--ct-ink);
  color: var(--ct-text-invert);
  /* Sobre el héroe oscuro el relleno se confunde con el fondo: el borde da el
     affordance de botón sin competir con la acción primaria. */
  border-color: var(--ct-on-dark-border);
  box-shadow: var(--ct-shadow-xs);
}

.ct-btn--dark:hover:not(:disabled) {
  background: var(--ct-ink-soft);
  border-color: var(--ct-on-dark-border-strong);
  box-shadow: var(--ct-shadow-sm);
}

.ct-btn__spinner {
  width: 1em;
  height: 1em;
  border-radius: 50%;
  border: 2px solid currentcolor;
  border-top-color: transparent;
  animation: ct-spin 0.7s linear infinite;
  display: inline-block;
}

@keyframes ct-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
