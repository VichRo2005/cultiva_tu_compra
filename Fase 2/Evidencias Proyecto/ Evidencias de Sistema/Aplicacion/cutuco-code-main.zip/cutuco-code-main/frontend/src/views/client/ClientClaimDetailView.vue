<script setup>
/**
 * CuTuCo — Detalle de mi reclamo (RF-025 y RF-026).
 *
 * El cliente ve el motivo, la descripción, el estado, la respuesta del vendedor
 * y el cierre del administrador. Todos los datos salen de `public.reclamos` con
 * RLS de participante, del `pedido` asociado (RLS de participantes del pedido)
 * y del perfil que resolvió.
 *
 * El esquema NO tiene columna `reclamos.resolucion`: el cierre se compone de
 * `estado`, la respuesta del vendedor y `resuelto_en`/`resuelto_por`.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { LABELS } from '@/lib/constants'
import { formatCLP, formatDateTime } from '@/lib/format'
import { getReclamoDetalle } from '@/services/reclamos'

const route = useRoute()

const reclamo = ref(null)
const cargando = ref(true)
const error = ref(null)

const reclamoId = computed(() => route.params.id)

const lineaTiempo = computed(() => {
  if (!reclamo.value) return []
  return [
    {
      key: 'abierto',
      titulo: 'Reclamo abierto',
      detalle: reclamo.value.motivo,
      momento: reclamo.value.creado_en,
    },
    {
      key: 'respuesta',
      titulo: 'Respuesta del vendedor',
      detalle: reclamo.value.respuesta_productor || 'El vendedor aún no responde.',
      momento: reclamo.value.respuesta_productor ? reclamo.value.actualizado_en : null,
    },
    {
      key: 'resuelto',
      titulo: 'Resolución de CuTuCo',
      detalle: reclamo.value.vigente
        ? 'En revisión por el equipo de CuTuCo.'
        : `Estado final: ${LABELS.reclamo[reclamo.value.estado] ?? reclamo.value.estado}.`,
      momento: reclamo.value.resuelto_en,
    },
  ].map((hito, indice, lista) => {
    const ultimoHecho = lista.reduce((ultimo, item, i) => (item.momento ? i : ultimo), -1)
    return {
      ...hito,
      estado: !hito.momento ? 'pendiente' : indice === ultimoHecho ? 'actual' : 'hecho',
    }
  })
})

const nombreRevisor = computed(() => {
  const revisor = reclamo.value?.revisor
  if (!revisor) return null
  return [revisor.nombre, revisor.apellido].filter(Boolean).join(' ')
})

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const resultado = await getReclamoDetalle(reclamoId.value)
    if (!resultado) {
      error.value = 'No encontramos el reclamo solicitado'
      return
    }
    reclamo.value = resultado
  } catch (e) {
    error.value = e?.message ?? 'No se pudo cargar el reclamo'
  } finally {
    cargando.value = false
  }
}

onMounted(cargar)
watch(reclamoId, cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <CtButton to="/cliente/reclamos" variant="ghost" size="sm" class="volver">
          <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
          Volver a Mis Reclamos
        </CtButton>
        <h1 class="page-head__title">Reclamo del pedido {{ reclamo?.pedido?.codigo_pedido ?? '—' }}</h1>
        <p class="page-head__subtitle">
          Registrado el {{ formatDateTime(reclamo?.creado_en) }} · Constancia CuTuCo
        </p>
      </div>
      <div class="page-head__actions">
        <StatusBadge v-if="reclamo" type="reclamo" :value="reclamo.estado" />
        <CtButton
          v-if="reclamo?.pedido"
          variant="secondary"
          :to="`/cliente/pedidos/${reclamo.pedido.id}`"
        >
          <template #icon><CtIcon name="orders" :size="16" /></template>
          Ver el pedido
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="cargando" label="Cargando el reclamo" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo mostrar el reclamo">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" to="/cliente/reclamos">Ver mis reclamos</CtButton>
    </CtAlert>

    <template v-else-if="reclamo">
      <CtAlert v-if="reclamo.vigente" tone="warning" title="Constancia vigente">
        <p class="linea">
          <CtIcon name="lock" :size="16" />
          <span>
            Tu constancia está
            {{ (LABELS.reclamo[reclamo.estado] ?? reclamo.estado).toLowerCase() }}. Coordina la
            solución directamente con el productor fuera de CuTuCo; esta plataforma sólo conserva
            el registro y no modifica el pago.
          </span>
        </p>
      </CtAlert>

      <div class="detalle">
        <div class="detalle__principal stack">
          <CtCard title="Tu reclamo" :subtitle="reclamo.motivo">
            <dl class="datos">
              <div class="dato">
                <dt class="dato__label">Motivo</dt>
                <dd class="dato__valor">{{ reclamo.motivo }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Descripción</dt>
                <dd class="dato__valor">{{ reclamo.descripcion }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Estado</dt>
                <dd class="dato__valor">
                  <StatusBadge type="reclamo" :value="reclamo.estado" size="sm" />
                </dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Registrado</dt>
                <dd class="dato__valor">{{ formatDateTime(reclamo.creado_en) }}</dd>
              </div>
              <div v-if="reclamo.resuelto_en" class="dato">
                <dt class="dato__label">Cerrado</dt>
                <dd class="dato__valor">{{ formatDateTime(reclamo.resuelto_en) }}</dd>
              </div>
              <div v-if="nombreRevisor" class="dato">
                <dt class="dato__label">Resuelto por</dt>
                <dd class="dato__valor">{{ nombreRevisor }}</dd>
              </div>
            </dl>
          </CtCard>

          <CtCard title="Seguimiento de la constancia">
            <ol class="linea-tiempo">
              <li
                v-for="hito in lineaTiempo"
                :key="hito.key"
                class="hito"
                :class="`is-${hito.estado}`"
              >
                <span class="hito__marca" aria-hidden="true">
                  <CtIcon v-if="hito.momento" name="check" :size="13" />
                  <span v-else class="hito__punto" />
                </span>
                <div class="hito__cuerpo">
                  <p class="hito__titulo">{{ hito.titulo }}</p>
                  <p class="hito__detalle">{{ hito.detalle }}</p>
                  <p v-if="hito.momento" class="hito__fecha">{{ formatDateTime(hito.momento) }}</p>
                  <p v-else class="hito__fecha is-pendiente">Pendiente</p>
                </div>
              </li>
            </ol>
          </CtCard>
        </div>

        <aside class="detalle__aside stack">
          <CtCard title="Pedido reclamado" padding="md">
            <dl class="datos" v-if="reclamo.pedido">
              <div class="dato">
                <dt class="dato__label">Código</dt>
                <dd class="dato__valor mono">{{ reclamo.pedido.codigo_pedido }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Estado del pedido</dt>
                <dd class="dato__valor">
                  <StatusBadge type="pedido" :value="reclamo.pedido.estado" size="sm" />
                </dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Total</dt>
                <dd class="dato__valor">{{ formatCLP(reclamo.pedido.total) }}</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Pago</dt>
                <dd class="dato__valor">Autorizado (Webpay Mall)</dd>
              </div>
              <div class="dato">
                <dt class="dato__label">Vendedor</dt>
                <dd class="dato__valor">{{ reclamo.productor?.nombre_comercial ?? '—' }}</dd>
              </div>
            </dl>
            <CtBadge v-if="reclamo.pedido?.estado === 'reclamado'" tone="danger" size="sm">
              Pedido marcado como reclamado
            </CtBadge>
          </CtCard>

          <CtCard title="Respuesta del vendedor" padding="md">
            <p v-if="reclamo.respuesta_productor" class="text-sm text-soft">
              {{ reclamo.respuesta_productor }}
            </p>
            <p v-else class="text-sm text-muted">
              El vendedor todavía no ha respondido a este reclamo.
            </p>
          </CtCard>

          <CtAlert tone="info" compact title="Alcance de CuTuCo">
            <p class="linea">
              <CtIcon name="info" :size="15" />
              <span>
                CuTuCo no media ni decide el resultado del problema. El estado sólo deja una
                constancia del registro y la fecha de cierre; cliente y productor acuerdan la
                solución directamente entre ellos.
              </span>
            </p>
          </CtAlert>
        </aside>
      </div>
    </template>
  </div>
</template>

<style scoped>
.volver {
  margin-bottom: var(--ct-space-2);
  margin-inline-start: calc(-1 * var(--ct-space-3));
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.detalle {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: var(--ct-space-8);
  align-items: start;
}

@media (max-width: 1100px) {
  .detalle {
    grid-template-columns: minmax(0, 1fr);
  }
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.linea-tiempo {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
}

.hito {
  position: relative;
  display: flex;
  gap: var(--ct-space-4);
  padding-bottom: var(--ct-space-5);
}

.hito:last-child {
  padding-bottom: 0;
}

.hito:not(:last-child)::before {
  content: '';
  position: absolute;
  top: 26px;
  left: 12px;
  width: 2px;
  height: calc(100% - 8px);
  background: var(--ct-border);
}

.hito.is-hecho:not(:last-child)::before {
  background: var(--ct-primary);
}

.hito__marca {
  position: relative;
  z-index: 1;
  width: 26px;
  height: 26px;
  flex-shrink: 0;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-surface);
  border: 2px solid var(--ct-border-strong);
  color: var(--ct-text-muted);
}

.hito.is-hecho .hito__marca {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.hito.is-actual .hito__marca {
  box-shadow: 0 0 0 4px var(--ct-primary-soft);
}

.hito__punto {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: currentcolor;
}

.hito__cuerpo {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.hito__titulo {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

.hito:not(.is-hecho):not(.is-actual) .hito__titulo {
  color: var(--ct-text-soft);
}

.hito__detalle {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  overflow-wrap: anywhere;
  word-break: break-word;
}

.detalle__principal,
.detalle__aside {
  min-width: 0;
}

.hito__fecha {
  font-size: var(--ct-fs-xs);
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-medium);
}

.hito__fecha.is-pendiente {
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-regular);
}

/* HAL-VEN-027: respuesta y descripciones largas se ajustan dentro del panel. */
.text-sm,
.hito__detalle {
  overflow-wrap: anywhere;
  word-break: break-word;
}
</style>
