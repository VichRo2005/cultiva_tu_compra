<script setup>
/** CuTuCo — Iconografía en línea. Sin dependencias externas ni emojis. */
import { computed } from 'vue'
import { ICON_PATHS, resolveIconName } from '@/lib/icons'

const props = defineProps({
  name: { type: String, required: true },
  size: { type: [Number, String], default: 18 },
  strokeWidth: { type: [Number, String], default: 1.7 },
})

const path = computed(() => ICON_PATHS[resolveIconName(props.name) ?? 'info'])
</script>

<template>
  <svg
    class="ct-icon"
    :width="props.size"
    :height="props.size"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    :stroke-width="props.strokeWidth"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
    focusable="false"
  >
    <path :d="path" />
  </svg>
</template>

<style scoped>
.ct-icon {
  flex-shrink: 0;
  display: block;
}
</style>
