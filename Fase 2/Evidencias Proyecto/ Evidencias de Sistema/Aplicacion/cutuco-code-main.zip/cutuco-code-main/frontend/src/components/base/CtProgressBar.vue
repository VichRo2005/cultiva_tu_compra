<script setup>
/** CuTuCo — Barra de progreso. */
defineProps({
  value: { type: Number, required: true },
  max: { type: Number, default: 100 },
  tone: { type: String, default: 'primary' },
  size: { type: String, default: 'md' }, // sm | md
  showLabel: { type: Boolean, default: false },
  label: { type: String, default: null },
  markers: { type: Array, default: () => [] }, // [{ at, label }]
})
</script>

<template>
  <div class="ct-progress" :class="[`ct-progress--${tone}`, `ct-progress--${size}`]">
    <div v-if="showLabel && label" class="ct-progress__label">{{ label }}</div>
    <div
      class="ct-progress__track"
      role="progressbar"
      :aria-valuenow="value"
      :aria-valuemin="0"
      :aria-valuemax="max"
    >
      <span
        class="ct-progress__bar"
        :style="{ width: `${Math.min(100, Math.max(0, (value / max) * 100))}%` }"
      />
      <span
        v-for="marker in markers"
        :key="marker.at"
        class="ct-progress__marker"
        :style="{ left: `${Math.min(100, (marker.at / max) * 100)}%` }"
        :title="marker.label"
      />
    </div>
    <span v-if="showLabel" class="ct-progress__value">
      {{ Math.round((value / max) * 100) }}%
    </span>
  </div>
</template>

<style scoped>
.ct-progress {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  width: 100%;
}

.ct-progress__label {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  white-space: nowrap;
}

.ct-progress__track {
  position: relative;
  flex: 1;
  height: 8px;
  background: var(--ct-border);
  border-radius: var(--ct-radius-pill);
  overflow: hidden;
}

.ct-progress--sm .ct-progress__track {
  height: 5px;
}

.ct-progress__bar {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ct-primary);
  transition: width var(--ct-transition-slow);
}

.ct-progress--success .ct-progress__bar {
  background: var(--ct-success);
}
.ct-progress--warning .ct-progress__bar {
  background: var(--ct-warning-strong);
}
.ct-progress--danger .ct-progress__bar {
  background: var(--ct-danger);
}
.ct-progress--info .ct-progress__bar {
  background: var(--ct-info);
}
.ct-progress--accent .ct-progress__bar {
  background: var(--ct-accent);
}

.ct-progress__marker {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 2px;
  background: var(--ct-progress-marker);
}

.ct-progress__value {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-soft);
  min-width: 38px;
  text-align: right;
}
</style>
