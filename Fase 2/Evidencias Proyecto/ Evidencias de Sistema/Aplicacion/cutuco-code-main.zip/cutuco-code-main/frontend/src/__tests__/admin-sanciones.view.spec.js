import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import { createPinia } from 'pinia'
import AdminSanctionsView from '@/views/admin/AdminSanctionsView.vue'
import { crearSancion } from '@/services/adminSanciones'
vi.mock('vue-router', () => ({ useRoute: () => ({ query: {} }) }))
vi.mock('@/services/catalog', () => ({
  listProductores: async () => [{ id: 'p', nombre_comercial: 'Huerta' }],
}))
vi.mock('@/services/adminSanciones', async (importOriginal) => {
  const real = await importOriginal()
  return {
    ...real,
    listSanciones: async () => [
      {
        id: 'ban',
        productor_id: 'p',
        tipo: 'suspension',
        accion: 'ban_permanente',
        estado: 'activa',
        motivo: 'Motivo completo '.repeat(30),
        productor: { nombre_comercial: 'Huerta' },
      },
    ],
    reactivarCuentaPermanente: vi.fn(),
    crearSancion: vi.fn(),
  }
})
vi.mock('@/services/adminApelaciones', async (importOriginal) => ({
  ...(await importOriginal()),
  listApelaciones: async () => [],
}))
vi.mock('@/services/adminModeracion', async (importOriginal) => ({
  ...(await importOriginal()),
  listCoincidenciasModeradas: async () => ({
    palabras: [{ id: 'w', palabra: 'Ejemplo', activo: false }],
    coincidencias: [],
  }),
}))
let wrapper
beforeEach(async () => {
  vi.clearAllMocks()
  wrapper = mount(AdminSanctionsView, {
    global: { plugins: [createPinia()], stubs: { teleport: true, 'router-link': true } },
  })
  await flushPromises()
})
afterEach(() => wrapper.unmount())

describe('Panel de sanciones', () => {
  it('CK-0214: dos clics inmediatos crean una sola amonestación', async () => {
    let completar
    crearSancion.mockReturnValueOnce(new Promise((resolve) => { completar = resolve }))
    await wrapper.findAll('button').find((b) => b.text() === 'Generar sanción').trigger('click')
    const seller = wrapper.findAll('select').find((s) => s.findAll('option').some((o) => o.text() === 'Huerta'))
    await seller.setValue('p')
    await wrapper.find('.admin-sanciones__formulario textarea').setValue('Antecedentes de prueba para la amonestación')
    const registrar = wrapper.findAll('button').find((b) => b.text() === 'Registrar sanción')
    registrar.element.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    registrar.element.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    await flushPromises()
    expect(crearSancion).toHaveBeenCalledTimes(1)
    expect(crearSancion.mock.calls[0][0].tipo).toBe('amonestacion')
    completar({ id: 'nueva' })
    await flushPromises()
  })
  it('un ban activo ofrece reactivar y ver detalles, sin cancelar ni resolver', () => {
    const row = wrapper.find('tbody tr')
    expect(row.text()).toContain('Reactivar cuenta')
    expect(row.text()).toContain('Ver detalles')
    expect(row.text()).not.toContain('Cancelar')
    expect(row.text()).not.toContain('Resolver')
  })
  it('conserva el motivo completo en el modal', async () => {
    await wrapper
      .findAll('button')
      .find((b) => b.text() === 'Ver detalles')
      .trigger('click')
    expect(wrapper.text()).toContain('Detalle de sanción')
    expect(wrapper.find('.admin-sanciones__detalle').text()).toContain(
      'Motivo completo '.repeat(30).trim(),
    )
  })
  it('deshabilita ban permanente para un productor ya baneado', async () => {
    await wrapper
      .findAll('button')
      .find((b) => b.text() === 'Generar sanción')
      .trigger('click')
    const selects = wrapper.findAll('select')
    const seller = selects.find((s) => s.findAll('option').some((o) => o.text() === 'Huerta'))
    await seller.setValue('p')
    const tipo = selects.find((s) =>
      s.element.closest('label')?.textContent.includes('Tipo de sanción'),
    )
    await tipo.setValue('suspension')
    const accion = selects.find((s) =>
      s.element.closest('label')?.textContent.includes('Acción sobre la cuenta'),
    )
    expect(accion.find('option[value="ban_permanente"]').element.disabled).toBe(true)
  })
})
