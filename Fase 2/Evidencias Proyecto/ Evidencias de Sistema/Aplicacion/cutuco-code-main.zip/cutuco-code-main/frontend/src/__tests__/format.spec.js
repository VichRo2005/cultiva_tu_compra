import { describe, it, expect } from 'vitest'

import {
  formatCLP,
  formatNumber,
  formatPercent,
  pluralize,
  maskEmail,
  initials,
  formatDelta,
  formatRut,
  formatBytes,
} from '@/lib/format'

describe('format · precios en pesos chilenos', () => {
  it('formatea montos sin decimales por defecto', () => {
    expect(formatCLP(2810)).toBe('$2.810')
    expect(formatCLP(1234567)).toBe('$1.234.567')
  })

  it('permite quitar el símbolo y agregar decimales', () => {
    expect(formatCLP(2810, { symbol: false })).toBe('2.810')
    expect(formatCLP(2810.456, { decimals: 2 })).toBe('$2.810,46')
  })

  it('devuelve $0 ante valores inválidos', () => {
    expect(formatCLP(null)).toBe('$0')
    expect(formatCLP('abc')).toBe('$0')
  })
})

describe('format · números', () => {
  it('formatea cantidades', () => {
    expect(formatNumber(1250)).toBe('1.250')
    expect(formatNumber(3.14159, 2)).toBe('3,14')
  })

  it('formatea porcentajes a partir de una fracción', () => {
    expect(formatPercent(0.1234)).toBe('12,3%')
  })

  it('calcula la variación entre dos períodos', () => {
    expect(formatDelta(120, 100)).toEqual({ diff: 20, pct: 0.2, positive: true, negative: false })
    expect(formatDelta(80, 100)).toEqual({ diff: -20, pct: -0.2, positive: false, negative: true })
  })

  it('formatea tamaños de archivo', () => {
    expect(formatBytes(0)).toBe('0 B')
    expect(formatBytes(2048)).toContain('KB')
  })
})

describe('format · textos', () => {
  it('pluraliza según el conteo', () => {
    expect(pluralize(1, 'producto', 'productos')).toBe('producto')
    expect(pluralize(3, 'producto', 'productos')).toBe('productos')
  })

  it('enmascara correos', () => {
    const masked = maskEmail('santiago.cliente@ejemplo.cl')
    expect(masked).toContain('@ejemplo.cl')
    expect(masked).not.toContain('santiago.cliente')
  })

  it('obtiene iniciales', () => {
    expect(initials('María Fernanda Soto')).toBe('MF')
    expect(initials('María')).toBe('M')
    expect(initials('')).toBe('??')
  })

  it('formatea RUT', () => {
    expect(formatRut('123456789')).toBe('12.34.5678-9')
  })
})