<script setup>
/** CuTuCo — Diálogo de confirmación reutilizable. */
import CtModal from './CtModal.vue'
import CtButton from './CtButton.vue'

defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, default: '¿Confirmas la acción?' },
  message: { type: String, default: '' },
  confirmLabel: { type: String, default: 'Confirmar' },
  cancelLabel: { type: String, default: 'Cancelar' },
  tone: { type: String, default: 'primary' }, // primary | danger
  loading: { type: Boolean, default: false },
  icon: { type: String, default: null },
})

const emit = defineEmits(['update:modelValue', 'confirm', 'cancel'])

function close() {
  emit('update:modelValue', false)
  emit('cancel')
}
</script>

<template>
  <CtModal
    :model-value="modelValue"
    :title="title"
    size="sm"
    :subtitle="null"
    @update:model-value="emit('update:modelValue', $event)"
  >
    <div class="ct-confirm">
      <div v-if="icon || $slots.icon" class="ct-confirm__icon">
        <slot name="icon">{{ icon }}</slot>
      </div>
      <p class="ct-confirm__message">
        <slot>{{ message }}</slot>
      </p>
      <slot name="details" />
    </div>
    <template #footer>
      <CtButton variant="secondary" @click="close">{{ cancelLabel }}</CtButton>
      <CtButton :variant="tone" :loading="loading" @click="emit('confirm')">
        {{ confirmLabel }}
      </CtButton>
    </template>
  </CtModal>
</template>

<style scoped>
.ct-confirm {
  display: flex;
  gap: var(--ct-space-4);
  align-items: flex-start;
}

.ct-confirm__icon {
  width: 40px;
  height: 40px;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-surface-alt);
  font-size: 1.25rem;
  flex-shrink: 0;
}

.ct-confirm__message {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-md);
}
</style>
