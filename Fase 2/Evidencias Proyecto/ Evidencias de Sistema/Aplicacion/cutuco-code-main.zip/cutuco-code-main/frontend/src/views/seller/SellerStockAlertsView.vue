<script setup>
/**
 * CuTuCo — Alertas de stock (prototipo anterior).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no está en el menú del producto):
 *   Ventana conservada para la GALERÍA DE DESARROLLO (`VITE_DEV_GALLERY=true`).
 *   RF-010 (umbral automático y avisos de stock bajo) salió del alcance: el
 *   vendedor revisa y ajusta su stock a mano en `SellerProductsView`.
 *
 *   Opera sobre la tabla `alertas_stock` y la columna `productos.umbral_bajo`,
 *   declaradas como HERRAMIENTA DE DESARROLLO en la migración de galería.
 */import { computed, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtProgressBar from '@/components/base/CtProgressBar.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import { LABELS } from '@/lib/constants'
import { formatDateTime, formatNumber, formatRelative } from '@/lib/format'
import { useAsync } from '@/composables/useAsync'
import { useUiStore } from '@/stores/ui'
import { atenderAlerta, listStockAlertas } from '@/services/seller'

const ui = useUiStore()

const filtro = ref('pendientes')
const page = ref(1)
const pageSize = ref(6)
const atendiendo = ref(null)

const { data: alertas, loading, error, run } = useAsync(() =>
  listStockAlertas({ soloPendientes: filtro.value === 'pendientes' }),
)

const tabItems = [
  { value: 'pendientes', label: 'Pendientes' },
  { value: 'todas', label: 'Todas' },
]

function cambiarFiltro(valor) {
  filtro.value = valor
  page.value = 1
  run()
}

/** Agrupa por producto para no repetir el mismo producto en la lista. */
const grupos = computed(() => {
  const mapa = new Map()
  for (const alerta of alertas.value ?? []) {
    if (!mapa.has(alerta.producto_id)) {
      mapa.set(alerta.producto_id, { producto: alerta.producto, alertas: [] })
    }
    mapa.get(alerta.producto_id).alertas.push(alerta)
  }
  return [...mapa.values()].sort(
    (a, b) => Number(a.producto?.stock ?? 0) - Number(b.producto?.stock ?? 0),
  )
})

const pendientes = computed(() => grupos.value.filter((g) => g.alertas.some((a) => !a.atendida_en)))

const indicadores = computed(() => {
  const items = grupos.value
  const pendientesItems = pendientes.value
  const unidadesEnRiesgo = pendientesItems.reduce(
    (acc, g) => acc + Number(g.producto?.stock ?? 0),
    0,
  )
  const ultima = (alertas.value ?? []).reduce(
    (max, a) => (new Date(a.generada_en) > new Date(max) ? a.generada_en : max),
    0,
  )
  return {
    total: items.length,
    pendientes: pendientesItems.length,
    riesgo: unidadesEnRiesgo,
    ultima: ultima || null,
  }
})

const visibles = computed(() =>
  grupos.value.slice((page.value - 1) * pageSize.value, page.value * pageSize.value),
)

function unidades(producto) {
  return LABELS.unidad[producto?.unidad_medida] ?? producto?.unidad_medida ?? ''
}

function pendienteDe(grupo) {
  return grupo.alertas.find((a) => !a.atendida_en) ?? null
}

function severidad(grupo) {
  const pendiente = pendienteDe(grupo)
  if (!pendiente) return { tone: 'success', label: 'Atendida' }
  if (Number(grupo.producto?.stock ?? 0) <= 0) return { tone: 'danger', label: 'Sin stock' }
  return { tone: 'warning', label: 'Reponer stock' }
}

async function atender(grupo) {
  const pendiente = pendienteDe(grupo)
  if (!pendiente) return
  atendiendo.value = pendiente.id
  try {
    await atenderAlerta(pendiente.id)
    ui.success(
      'Alerta atendida',
      `${grupo.producto?.nombre ?? 'Producto'} · repón el stock antes de la próxima venta`,
    )
    await run()
  } catch (e) {
    ui.error('No se pudo actualizar la alerta', e.message)
  } finally {
    atendiendo.value = null
  }
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Alertas de Inventario</h1>
        <p class="page-head__subtitle">
          Productos cuyo stock llegó al umbral configurado y necesitan reposición.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" to="/vendedor/productos">
          <template #icon><CtIcon name="inventory" :size="16" /></template>
          Gestionar Inventario
        </CtButton>
        <CtButton to="/vendedor/productos/nuevo">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Nuevo Producto
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar las alertas">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
    </CtAlert>

    <div class="grid-kpi">
      <CtStatCard
        label="Alertas de stock"
        :value="formatNumber(indicadores.pendientes)"
        tone="danger"
        hint="Productos pendientes de reposición"
      />
      <CtStatCard
        label="Productos vigilados"
        :value="formatNumber(indicadores.total)"
        tone="primary"
        hint="Con al menos una alerta registrada"
      />
      <CtStatCard
        label="Unidades en riesgo"
        :value="formatNumber(indicadores.riesgo)"
        tone="warning"
        :hint="`Última alerta: ${
          indicadores.ultima ? formatRelative(indicadores.ultima) : 'sin registros'
        }`"
      />
    </div>

    <CtCard padding="sm">
      <CtTabs
        :model-value="filtro"
        :tabs="tabItems"
        variant="pills"
        @update:model-value="cambiarFiltro"
      />
    </CtCard>

    <CtSpinner v-if="loading && !alertas" label="Cargando alertas de stock" />

    <template v-else>
      <CtCard v-if="!grupos.length">
        <CtEmptyState
          icon=""
          title="No hay alertas de stock"
          message="Todos tus productos activos están por sobre su umbral configurado. CuTuCo genera una alerta automática cuando el stock llega al umbral."
        >
          <CtButton variant="secondary" to="/vendedor/productos">Revisar mi catálogo</CtButton>
        </CtEmptyState>
      </CtCard>

      <div v-else class="grid-cards grid-cards--lg">
        <CtCard
          v-for="grupo in visibles"
          :key="grupo.producto_id"
          :title="grupo.producto?.nombre ?? 'Producto eliminado'"
          :subtitle="`Umbral configurado: ${formatNumber(
            grupo.producto?.umbral_bajo ?? 0,
          )} ${unidades(grupo.producto)}`"
        >
          <template #actions>
            <CtBadge :tone="severidad(grupo).tone" size="sm" dot>
              {{ severidad(grupo).label }}
            </CtBadge>
          </template>

          <div class="stack stack--sm">
            <div class="medidor">
              <p class="text-3xl font-bold" :class="Number(grupo.producto?.stock) > 0 ? 'text-warning' : 'text-danger'">
                {{ formatNumber(grupo.producto?.stock ?? 0) }}
              </p>
              <p class="text-xs text-muted">{{ unidades(grupo.producto) }} disponibles</p>
            </div>

            <CtProgressBar
              :value="Number(grupo.producto?.stock ?? 0)"
              :max="Number(grupo.producto?.umbral_bajo ?? 0) * 2 || 1"
              size="sm"
              :tone="Number(grupo.producto?.stock) <= 0 ? 'danger' : 'warning'"
              show-label
              label="Stock / umbral"
            />

            <ul class="historial">
              <li v-for="alerta in grupo.alertas" :key="alerta.id" class="historial__item">
                <span class="text-xs text-muted">
                  Generada el {{ formatDateTime(alerta.generada_en) }} · stock
                  {{ formatNumber(alerta.stock_actual) }}
                </span>
                <CtBadge :tone="alerta.atendida_en ? 'neutral' : 'warning'" size="sm">
                  {{ alerta.atendida_en ? 'Atendida' : 'Sin atender' }}
                </CtBadge>
              </li>
            </ul>

            <div class="row row--wrap">
              <CtButton
                size="sm"
                :disabled="!pendienteDe(grupo)"
                :loading="atendiendo === pendienteDe(grupo)?.id"
                @click="atender(grupo)"
              >
                Marcar atendida
              </CtButton>
              <CtButton
                size="sm"
                variant="secondary"
                :to="`/vendedor/productos/${grupo.producto_id}/editar`"
              >
                Reponer stock
              </CtButton>
            </div>
          </div>
        </CtCard>
      </div>

      <CtPagination
        v-model:page="page"
        v-model:page-size="pageSize"
        :total="grupos.length"
        label="productos"
      />
    </template>
  </div>
</template>

<style scoped>
.medidor {
  display: flex;
  align-items: baseline;
  gap: var(--ct-space-2);
}

.historial {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.historial__item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}
</style>

