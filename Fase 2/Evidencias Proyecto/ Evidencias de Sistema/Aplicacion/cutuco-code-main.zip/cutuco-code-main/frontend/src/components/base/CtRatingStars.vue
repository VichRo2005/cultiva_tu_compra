<script setup>
/** CuTuCo — Estrellas de calificación (lectura o selección). */
import { computed } from 'vue'

const props = defineProps({
  modelValue: { type: Number, default: 0 },
  max: { type: Number, default: 5 },
  interactive: { type: Boolean, default: false },
  size: { type: Number, default: 16 },
  showValue: { type: Boolean, default: false },
  decimals: { type: Number, default: 2 },
})

const emit = defineEmits(['update:modelValue'])

const stars = computed(() =>
  Array.from({ length: props.max }, (_, i) => {
    const position = i + 1
    if (props.modelValue >= position) return 'full'
    if (props.modelValue >= position - 0.5) return 'half'
    return 'empty'
  }),
)
</script>

<template>
  <span class="ct-stars" :class="{ 'is-interactive': interactive }">
    <component
      :is="interactive ? 'button' : 'span'"
      v-for="(state, index) in stars"
      :key="index"
      class="ct-stars__star"
      :type="interactive ? 'button' : null"
      :aria-label="interactive ? `${index + 1} de ${max} estrellas` : null"
      :aria-hidden="interactive ? null : 'true'"
      @click="interactive && emit('update:modelValue', index + 1)"
    >
      <span :class="`is-${state}`" :style="{ fontSize: `${size}px` }">★</span>
    </component>
    <span v-if="showValue" class="ct-stars__value">{{ Number(modelValue).toFixed(decimals) }}</span>
    <span v-if="!interactive" class="ct-sr-only">{{ Number(modelValue).toFixed(decimals) }} de {{ max }}</span>
  </span>
</template>

<style scoped>
.ct-stars {
  display: inline-flex;
  align-items: center;
  gap: 1px;
}

.ct-stars__star {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  min-height: 18px;
  line-height: 1;
  color: var(--ct-star-full);
  padding: 0 1px;
  border-radius: var(--ct-radius-sm);
}

.is-interactive .ct-stars__star {
  min-width: 28px;
  min-height: 28px;
  cursor: pointer;
  transition: transform var(--ct-transition), background var(--ct-transition);
}

.is-interactive .ct-stars__star:hover {
  transform: scale(1.15);
  background: var(--ct-accent-soft);
}

.is-interactive .ct-stars__star:active {
  transform: scale(1.05);
}

.is-empty {
  color: var(--ct-star-empty);
}

.is-half {
  background: linear-gradient(90deg, var(--ct-star-full) 50%, var(--ct-star-empty) 50%);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  color: var(--ct-star-full);
}

.is-full {
  color: var(--ct-star-full);
}

.ct-stars__value {
  margin-left: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-soft);
}
</style>
