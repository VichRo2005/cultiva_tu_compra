<template>
  <div class="container page">
    <!-- ============ Cabecera ============ -->
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Mi Perfil</h1>
        <p class="page-head__subtitle">
          Información y configuración de tu tienda como vendedor en CuTuCo.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" size="md" @click="irATienda">
          <template #icon><CtIcon name="store" :size="16" /></template>
          Ir a Mi Tienda
        </CtButton>
        <CtButton variant="secondary" size="md" @click="irAProductos">
          <template #icon><CtIcon name="package" :size="16" /></template>
          Gestionar Productos
        </CtButton>
        <CtButton variant="secondary" size="md" @click="irAPedidos">
          <template #icon><CtIcon name="shopping-bag" :size="16" /></template>
          Ver Pedidos
        </CtButton>
      </div>
    </header>

    <!-- ============ Loading / Error / Sin tienda ============ -->
    <CtSpinner v-if="cargando" label="Cargando tu perfil" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar el perfil">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtCard v-else-if="!productor" title="Tu tienda aún no está activa">
      <CtEmptyState
        icon="store"
        title="Sin tienda de productor"
        message="Para vender tu cosecha debes postular como vendedor. Un administrador revisa tu solicitud y, cuando la aprueba, tu tienda queda disponible en el catálogo."
      >
        <CtButton to="/vendedor/tienda">Ir a mi perfil de tienda</CtButton>
      </CtEmptyState>
    </CtCard>

    <!-- ============ Contenido principal ============ -->
    <template v-else>
      <!-- ============ Estado de la postulación ============ -->
      <CtAlert
        v-if="postulacion && postulacion.estado !== 'aprobada'"
        :tone="postulacion.estado === 'rechazada' ? 'danger' : 'warning'"
        :title="`Postulación: ${postulacion.estado}`"
      >
        <p v-if="postulacion.estado === 'pendiente'">
          Tu tienda estará disponible una vez el administrador apruebe tu solicitud.
        </p>
        <p v-else-if="postulacion.estado === 'rechazada'" class="text-sm">
          Observaciones del administrador:
          {{ postulacion.observaciones_admin ?? 'Sin observaciones' }}
        </p>
        <div class="row row--wrap">
          <CtButton size="sm" variant="secondary" to="/vendedor/tienda">
            Ver estado de mi solicitud
          </CtButton>
          <CtButton size="sm" variant="ghost" @click="cargar">Actualizar estado</CtButton>
        </div>
      </CtAlert>

      <!-- ============ Badges de estado ============ -->
      <div class="row row--wrap">
        <CtBadge :tone="productor?.activo ? 'success' : 'warning'" dot>
          {{ productor?.activo ? 'Tienda activa' : 'Tienda inactiva' }}
        </CtBadge>
        <CtBadge v-if="productor?.nombre_comercial" tone="neutral">
          {{ productor.nombre_comercial }}
        </CtBadge>
        <CtBadge v-if="productor?.region_nombre" tone="neutral">
          {{ productor.region_nombre
          }}{{ productor.comuna_nombre ? `, ${productor.comuna_nombre}` : '' }}
        </CtBadge>
        <CtBadge :tone="correoVerificado ? 'success' : 'warning'" dot>
          {{ correoVerificado ? 'Cuenta verificada' : 'Cuenta sin verificar' }}
        </CtBadge>
      </div>

      <!-- ============ Indicadores (KPIs) ============ -->
      <div class="grid-kpi">
        <CtStatCard
          label="Productos publicados"
          :value="formatNumber(totalProductos)"
          tone="primary"
          :hint="`${totalProductos} publicados en el catálogo`"
          :to="puedeOperar ? '/vendedor/productos' : null"
        />
        <CtStatCard
          label="Pedidos recibidos"
          :value="formatNumber(totalPedidos)"
          tone="info"
          :hint="'Historial completo de pedidos'"
        />
        <CtStatCard
          label="Calificación promedio"
          :value="reputacionTexto"
          tone="warning"
          :hint="'Promedio de 1 a 5 estrellas'"
        />
      </div>

      <!-- ============ Foto de perfil ============ -->
      <CtCard title="Foto de perfil" subtitle="Sube o actualiza la foto que verán tus clientes">
        <div class="perfil-foto">
          <div class="perfil-foto__preview-wrap">
            <img
              :key="`perfil-foto-${fotoVersion}`"
              class="perfil-foto__preview"
              :src="fotoPerfil"
              alt="Vista previa de la foto de perfil"
              @error="onErrorFotoPerfil"
            />
          </div>
          <div class="perfil-foto__acciones">
            <CtFileUpload
              :model-value="[]"
              accept="image/jpeg,image/png,image/webp"
              :multiple="false"
              :max="1"
              :disabled="subiendoFoto"
              :loading="subiendoFoto"
              label="Cambiar foto de perfil"
              hint="JPG, PNG o WebP · máximo 5 MB"
              @update:model-value="onElegirFotoPerfil"
              @error="onErrorCargaFoto"
            />
            <CtButton
              v-if="productor?.foto_perfil_storage_path"
              variant="ghost"
              size="sm"
              :disabled="subiendoFoto"
              @click="onQuitarFotoPerfil"
            >
              <template #icon><CtIcon name="trash" :size="14" /></template>
              Quitar y usar imagen por defecto
            </CtButton>
          </div>
        </div>
      </CtCard>

      <!-- ============ Estado de la Postulación (detalle) ============ -->
      <CtCard
        title="Estado de la Postulación"
        subtitle="Situación actual de tu solicitud como vendedor"
      >
        <div v-if="!postulacion" class="text-center py-4">
          <CtEmptyState
            icon="file-text"
            title="Sin información de postulación"
            message="No se encontró información de tu solicitud de vendedor."
          />
        </div>
        <div v-else>
          <dl class="dinero">
            <div>
              <dt>Estado</dt>
              <dd>
                <CtBadge
                  :tone="
                    postulacion.estado === 'aprobada'
                      ? 'success'
                      : postulacion.estado === 'rechazada'
                        ? 'danger'
                        : 'warning'
                  "
                  dot
                >
                  {{ postulacion.estado }}
                </CtBadge>
              </dd>
            </div>
            <div v-if="postulacion.fecha_creacion">
              <dt>Fecha de solicitud</dt>
              <dd>{{ formatDate(postulacion.fecha_creacion) }}</dd>
            </div>
            <div v-if="postulacion.fecha_resolucion">
              <dt>Fecha de resolución</dt>
              <dd>{{ formatDate(postulacion.fecha_resolucion) }}</dd>
            </div>
            <div v-if="postulacion.estado !== 'aprobada'">
              <dt>Próximos pasos</dt>
              <dd class="text-sm text-soft">
                Tu tienda estará disponible una vez el administrador apruebe tu solicitud.
              </dd>
            </div>
            <div v-if="postulacion.observaciones_admin" class="text-sm text-muted">
              <strong>Observaciones del administrador:</strong>
              {{ postulacion.observaciones_admin }}
            </div>
          </dl>
        </div>
      </CtCard>

      <!-- ============ Cuenta de acceso ============ -->
      <CtCard
        title="Cuenta de acceso"
        subtitle="Consulta y actualiza el correo de acceso a tu cuenta"
      >
        <div class="cuenta-acceso">
          <dl class="datos cuenta-acceso__datos">
            <div>
              <dt>Correo electrónico</dt>
              <dd class="cuenta-acceso__correo">
                <span>{{ correo }}</span>
                <CtBadge :tone="correoVerificado ? 'success' : 'warning'" size="sm" dot>
                  {{ correoVerificado ? 'Cuenta verificada' : 'Cuenta sin verificar' }}
                </CtBadge>
              </dd>
            </div>
          </dl>

          <div class="cuenta-acceso__accion">
            <p class="text-sm text-soft">
              Para cambiar el correo, confirma el enlace que enviaremos a la dirección nueva y a la
              actual.
            </p>
            <CtButton variant="secondary" size="md" @click="abrirCambioCorreo">
              <template #icon><CtIcon name="mail" :size="16" /></template>
              Cambiar correo electrónico
            </CtButton>
          </div>
        </div>

        <CtAlert v-if="correoPendiente" tone="info" compact class="cuenta-acceso__pendiente">
          Cambio pendiente de confirmación en <strong>{{ correoPendiente }}</strong>.
        </CtAlert>
      </CtCard>

      <NotificationPreferences :rol="auth.rol" @saved="sincronizarNotificaciones" />
    </template>

    <!-- ============ Modal: Cambio de correo (RF-031 / HAL-VEN-001) ============ -->
    <CtModal v-model="modalCorreo" title="Cambiar correo electrónico" size="sm">
      <div class="stack">
        <CtAlert v-if="errorCorreo" tone="danger">{{ errorCorreo }}</CtAlert>
        <CtAlert
          v-if="correoPendiente"
          tone="info"
          compact
          title="Cambio pendiente de confirmación"
        >
          Pediste cambiar tu correo a <strong>{{ correoPendiente }}</strong>. Revisa esa bandeja y
          la de <strong>{{ correo }}</strong>: el cambio se aplica cuando confirmes en ambas
          direcciones.
        </CtAlert>
        <CtInput
          v-model="nuevoCorreo"
          label="Correo nuevo"
          type="email"
          placeholder="tucorreo@ejemplo.cl"
          autocomplete="email"
          :maxlength="LIMITES.email"
          hint="Te enviaremos un enlace de confirmación a esta dirección y a la actual."
          required
        />
        <CtInput
          v-model="claveCorreo"
          label="Contraseña actual"
          type="password"
          prevent-autofill
          hint="La exigimos para reautenticar el cambio de correo."
          :error="errorClaveCorreo"
          required
        />
        <CtAlert tone="info" compact>
          El cambio de correo no altera tus pedidos, productos ni tu historial. Debes confirmarlo en
          la dirección nueva y en la actual antes de que se aplique.
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="guardandoCorreo" @click="cerrarCambioCorreo">
          Cancelar
        </CtButton>
        <CtButton :loading="guardandoCorreo" :disabled="guardandoCorreo" @click="cambiarCorreo">
          Enviar confirmación
        </CtButton>
      </template>
    </CtModal>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtFileUpload from '@/components/base/CtFileUpload.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import NotificationPreferences from '@/components/domain/NotificationPreferences.vue'
import { formatNumber, formatDate } from '@/lib/format'
import { avatarImage } from '@/lib/images'
import { storageUrl } from '@/lib/supabase'
import { STORAGE_BUCKETS } from '@/lib/constants'
import { emailPolicyMessage, isEmail, LIMITES } from '@/lib/validation'
import { subirFotoPerfil, quitarFotoPerfil } from '@/services/seller'
import { getReputacionProductor, listPedidos } from '@/services/orders'
import { getMiPostulacion, getMiProductor } from '@/services/seller'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'

const router = useRouter()
const auth = useAuthStore()
const ui = useUiStore()

// ---- Estado reactivo ----
const productor = ref(null)
const postulacion = ref(null)
const pedidos = ref([])
const reputacion = ref(null)
const cargando = ref(true)
const error = ref(null)

const modalCorreo = ref(false)
const nuevoCorreo = ref('')
const claveCorreo = ref('')
const errorCorreo = ref(null)
const errorClaveCorreo = ref(null)
const guardandoCorreo = ref(false)
const correoPendiente = ref(null)

const subiendoFoto = ref(false)
const fotoVersion = ref(Date.now())
const fotoTemporal = ref(null)
const fotoConError = ref(false)

const puedeOperar = computed(
  () =>
    Boolean(auth.puedeOperarTienda) &&
    Boolean(productor.value?.activo) &&
    postulacion.value?.estado === 'aprobada',
)

const correo = computed(() => auth.user?.email ?? '—')
const correoVerificado = computed(() => Boolean(auth.user?.email_confirmed_at))

/* ---------- Foto de perfil ---------- */
const fotoPerfil = computed(() => {
  if (fotoTemporal.value) return fotoTemporal.value
  if (fotoConError.value) {
    return avatarImage(productor.value?.nombre_comercial ?? auth.nombreCompleto ?? 'Productor')
  }
  const ruta = productor.value?.foto_perfil_storage_path
  if (ruta) {
    const base = storageUrl(ruta, { bucket: STORAGE_BUCKETS.avataresVendedor })
    if (base) return `${base}${base.includes('?') ? '&' : '?'}v=${fotoVersion.value}`
  }
  return avatarImage(productor.value?.nombre_comercial ?? auth.nombreCompleto ?? 'Productor')
})

/* ---------- Reputación ---------- */
const reputacionTexto = computed(() => {
  const r = reputacion.value
  if (!r) return 'Sin datos'
  const cantidad = Number(r.cantidad ?? 0)
  if (!cantidad || r.puntaje == null) return 'Sin calificaciones'
  return `${formatNumber(Number(r.puntaje), 2)} / 5 · ${cantidad} ${cantidad === 1 ? 'evaluación' : 'evaluaciones'}`
})

const totalProductos = computed(() => productor.value?.total_productos ?? 0)
const totalPedidos = computed(() => pedidos.value.length)
/* ---------- Carga de datos ---------- */
async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const [p, post, pedidosRes] = await Promise.all([
      getMiProductor(),
      getMiPostulacion(),
      listPedidos({ rol: 'productor', all: true }),
    ])
    productor.value = p ?? auth.productor ?? null
    if (p) auth.productor = p
    postulacion.value = post
    pedidos.value = pedidosRes.items ?? []
    reputacion.value = p?.id
      ? await getReputacionProductor(p.id).catch(() => ({
          puntaje: null,
          cantidad: 0,
          evaluaciones: [],
        }))
      : { puntaje: null, cantidad: 0, evaluaciones: [] }
  } catch (e) {
    error.value = e.message
    ui.error('No se pudo cargar el perfil', e.message)
  } finally {
    cargando.value = false
  }
}

/* ---------- Foto de perfil ---------- */
async function onElegirFotoPerfil(filesRecibidos) {
  const filesArray = Array.isArray(filesRecibidos) ? filesRecibidos : [filesRecibidos]
  const fileObj = filesArray?.[0]
  const file = fileObj?.file ?? fileObj

  if (!file) return

  const productorId = productor.value?.id
  if (!productorId) return

  subiendoFoto.value = true
  fotoConError.value = false
  fotoTemporal.value = fileObj?.preview ?? URL.createObjectURL(file)
  try {
    await subirFotoPerfil({
      productorId,
      file,
      rutaActual: productor.value?.foto_perfil_storage_path,
    })
    fotoTemporal.value = null
    fotoConError.value = false
    ui.success('Foto de perfil actualizada', 'Tu foto de perfil ya está publicada')
    await cargar()
    fotoVersion.value = Date.now()
  } catch (e) {
    fotoTemporal.value = null
    fotoConError.value = false
    ui.error('No se pudo subir la foto', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoFoto.value = false
  }
}

async function onQuitarFotoPerfil() {
  const productorId = productor.value?.id
  if (!productorId) return
  subiendoFoto.value = true
  try {
    await quitarFotoPerfil({ productorId, rutaActual: productor.value?.foto_perfil_storage_path })
    fotoTemporal.value = null
    ui.info('Foto eliminada', 'Se muestra la imagen por defecto')
    await cargar()
    fotoVersion.value = Date.now()
  } catch (e) {
    ui.error('No se pudo quitar la foto', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoFoto.value = false
  }
}

function onErrorCargaFoto(message) {
  ui.error('No se pudo seleccionar la foto', message)
}

function onErrorFotoPerfil() {
  fotoTemporal.value = null
  fotoConError.value = true
  ui.error(
    'No se pudo mostrar la foto',
    'Usaremos la imagen por defecto mientras revisas el archivo.',
  )
}

/* ---------- Cambio de correo (RF-031 / HAL-VEN-001) ---------- */
async function cambiarCorreo() {
  if (guardandoCorreo.value) return
  errorCorreo.value = null
  errorClaveCorreo.value = null

  const destino = String(nuevoCorreo.value ?? '')
  const mensajeCorreo = emailPolicyMessage(destino)
  if (mensajeCorreo) {
    errorCorreo.value = mensajeCorreo
    return
  }
  if (!isEmail(destino)) {
    errorCorreo.value = 'Ingresa un correo válido'
    return
  }
  if (!claveCorreo.value) {
    errorClaveCorreo.value = 'Ingresa tu contraseña actual para confirmar el cambio'
    return
  }

  guardandoCorreo.value = true
  try {
    const solicitado = await auth.updateEmail(destino, claveCorreo.value)
    correoPendiente.value = solicitado
    modalCorreo.value = false
    nuevoCorreo.value = ''
    claveCorreo.value = ''
    ui.success(
      'Confirmación enviada',
      `Revisa ${solicitado} y tu correo actual: el cambio se aplica cuando confirmes en ambos.`,
    )
  } catch (e) {
    errorCorreo.value = e?.message ?? 'No se pudo solicitar el cambio de correo'
  } finally {
    guardandoCorreo.value = false
  }
}

watch(modalCorreo, (abierto) => {
  if (!abierto) {
    claveCorreo.value = ''
    errorClaveCorreo.value = null
    errorCorreo.value = null
  }
})

function abrirCambioCorreo() {
  errorCorreo.value = null
  errorClaveCorreo.value = null
  nuevoCorreo.value = ''
  claveCorreo.value = ''
  modalCorreo.value = true
}

function cerrarCambioCorreo() {
  if (!guardandoCorreo.value) modalCorreo.value = false
}

/* ---------- Navegación ---------- */
function irATienda() {
  router.push({ name: 'vendedor-tienda' })
}
function irAProductos() {
  router.push({ name: 'vendedor-productos' })
}
function irAPedidos() {
  router.push({ name: 'vendedor-pedidos' })
}

async function sincronizarNotificaciones() {
  try {
    await ui.syncNotifications({ rol: auth.rol })
  } catch (e) {
    ui.error('No se pudieron actualizar tus notificaciones', e?.message)
  }
}

/* ---------- Inicialización ---------- */
onMounted(() => cargar())
</script>

<style scoped>
/* Estilos mínimos — la estructura usa utilidades globales */
.perfil-foto {
  display: grid;
  grid-template-columns: minmax(132px, 180px) minmax(0, 1fr);
  align-items: center;
  gap: var(--ct-space-6);
}

.perfil-foto__preview-wrap {
  display: grid;
  place-items: center;
  padding: var(--ct-space-3);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface-alt);
}

.perfil-foto__preview {
  width: clamp(120px, 16vw, 160px);
  aspect-ratio: 1;
  height: auto;
  border-radius: 50%;
  border: 1px solid var(--ct-border);
  object-fit: cover;
  background: var(--ct-surface);
}

.perfil-foto__acciones {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  width: 100%;
}

.perfil-foto__acciones > * {
  width: 100%;
}

@media (max-width: 560px) {
  .perfil-foto {
    grid-template-columns: 1fr;
    gap: var(--ct-space-4);
  }

  .perfil-foto__preview-wrap {
    justify-self: stretch;
  }
}

.cuenta-acceso {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(240px, auto);
  align-items: center;
  gap: var(--ct-space-6);
}

.cuenta-acceso__datos {
  margin: 0;
}

.cuenta-acceso__correo {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-1);
  overflow-wrap: anywhere;
}

.cuenta-acceso__accion {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--ct-space-3);
}

.cuenta-acceso__accion p {
  max-width: 38rem;
  margin: 0;
}

.cuenta-acceso__pendiente {
  margin-top: var(--ct-space-5);
}

/* Dinero y datos — usan clases globales pero aseguramos espaciado */
.dinero dt {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}
.dinero dd {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
}

@media (max-width: 680px) {
  .cuenta-acceso {
    grid-template-columns: 1fr;
    gap: var(--ct-space-4);
  }

  .cuenta-acceso__accion,
  .cuenta-acceso__accion .ct-button {
    width: 100%;
  }
}
</style>
