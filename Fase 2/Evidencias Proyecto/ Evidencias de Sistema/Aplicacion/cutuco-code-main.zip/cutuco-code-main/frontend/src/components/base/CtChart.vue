<script setup>
/**
 * CuTuCo — Gráfico reutilizable sobre Chart.js.
 * Envuelve Line, Bar, Doughnut y Radar con el tema CuTuCo aplicado.
 */
import { computed } from 'vue'
import { Bar, Doughnut, Line, Radar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Filler,
  Legend,
  Tooltip,
  Title,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Filler,
  Legend,
  Tooltip,
  Title,
)

const props = defineProps({
  type: { type: String, default: 'line' }, // line | bar | doughnut | radar
  labels: { type: Array, default: () => [] },
  datasets: { type: Array, default: () => [] },
  currency: { type: Boolean, default: false },
  stacked: { type: Boolean, default: false },
  showLegend: { type: Boolean, default: true },
  legendPosition: { type: String, default: 'bottom' },
  fill: { type: Boolean, default: true },
  tension: { type: Number, default: 0.35 },
  height: { type: Number, default: 280 },
  beginAtZero: { type: Boolean, default: true },
  yTitle: { type: String, default: null },
  tooltipCallback: { type: Function, default: null },
})

// Sin violeta (#8E24AA): regla anti-slop de las referencias de diseño; marrón on-brand y ≥3:1 sobre blanco.
const PALETTE = ['#2E7D32', '#FF9800', '#1E88E5', '#795548', '#E53935', '#00897B', '#F9A825']

const chartType = computed(() => {
  if (props.type === 'bar') return Bar
  if (props.type === 'doughnut') return Doughnut
  if (props.type === 'radar') return Radar
  return Line
})

const chartData = computed(() => ({
  labels: props.labels,
  datasets: props.datasets.map((ds, i) => {
    const color = ds.color ?? PALETTE[i % PALETTE.length]
    const base = {
      label: ds.label ?? '',
      data: ds.data ?? [],
      borderColor: color,
      backgroundColor: ds.backgroundColor ?? color,
      borderWidth: ds.borderWidth ?? (props.type === 'line' ? 2.5 : 0),
      pointRadius: ds.pointRadius ?? (props.type === 'line' ? 3 : undefined),
      pointHoverRadius: ds.pointHoverRadius ?? 5,
      tension: ds.tension ?? (props.type === 'line' ? props.tension : 0),
      borderRadius: props.type === 'bar' ? 6 : undefined,
      maxBarThickness: 42,
    }
    if (props.type === 'line' && props.fill && ds.fill !== false) {
      base.fill = true
      base.backgroundColor = ds.backgroundColor ?? hexToRgba(color, 0.12)
    }
    if (props.type === 'doughnut') {
      base.borderWidth = 2
      base.borderColor = '#ffffff'
    }
    return base
  }),
}))

const options = computed(() => {
  const isCircular = props.type === 'doughnut' || props.type === 'radar'
  return {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: {
        display: props.showLegend,
        position: props.legendPosition,
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          boxWidth: 8,
          padding: 16,
          font: { family: 'Inter, sans-serif', size: 12 },
          color: '#5f6b5f',
        },
      },
      tooltip: {
        backgroundColor: '#212121',
        padding: 10,
        cornerRadius: 8,
        titleFont: { family: 'Inter, sans-serif', size: 12 },
        bodyFont: { family: 'Inter, sans-serif', size: 12 },
        callbacks: props.tooltipCallback
          ? { label: props.tooltipCallback }
          : props.currency
            ? {
                label: (ctx) => `${ctx.dataset.label ?? ''}: ${formatCLP(ctx.parsed.y ?? ctx.parsed)}`,
              }
            : undefined,
      },
    },
    scales: isCircular
      ? undefined
      : {
          x: {
            stacked: props.stacked,
            grid: { display: false },
            ticks: { font: { family: 'Inter, sans-serif', size: 11 }, color: '#8a958a' },
          },
          y: {
            stacked: props.stacked,
            beginAtZero: props.beginAtZero,
            title: props.yTitle ? { display: true, text: props.yTitle } : undefined,
            grid: { color: '#eef1ee' },
            ticks: {
              font: { family: 'Inter, sans-serif', size: 11 },
              color: '#8a958a',
              callback: (value) => (props.currency ? `$${value}` : value),
            },
          },
        },
  }
})

function formatCLP(value) {
  return new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 }).format(Number(value))
}

function hexToRgba(hex, alpha) {
  const clean = hex.replace('#', '')
  const r = parseInt(clean.slice(0, 2), 16)
  const g = parseInt(clean.slice(2, 4), 16)
  const b = parseInt(clean.slice(4, 6), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}
</script>

<template>
  <div class="ct-chart" :style="{ height: `${height}px` }">
    <component :is="chartType" :data="chartData" :options="options" />
  </div>
</template>

<style scoped>
.ct-chart {
  position: relative;
  width: 100%;
}
</style>
