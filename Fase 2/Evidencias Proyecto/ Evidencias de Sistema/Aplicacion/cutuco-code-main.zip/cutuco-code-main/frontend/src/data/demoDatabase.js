/**
 * CuTuCo — Base de datos de demostración (modo offline).
 *
 * Dataset en memoria con la MISMA forma que el esquema vigente
 * (`supabase/migrations/20261004021917_nuevo_alcance.sql` + la migración de
 * galería). Lo usa `lib/offlineClient.js`, que reemplaza a Supabase sólo cuando
 * la base de datos no responde, para que las cuentas demo y todas las ventanas
 * sigan funcionando sin Docker.
 *
 * Se persiste en `localStorage` para que las acciones del modo demo (agregar un
 * producto, cambiar un estado de envío, registrar una calificación) sobrevivan a
 * la recarga de la página.
 *
 * IMPORTANTE: cambiar `VERSION` invalida la copia guardada y vuelve a sembrar.
 */

export const DEMO_PASSWORD = 'CutucoDev2026!'

const VERSION = 'cutuco-demo-v1'
const CLAVE = `cutuco:demo:${VERSION}`

/* ==================================================================
 * Utilidades
 * ================================================================== */

const ahora = () => new Date().toISOString()
const dias = (n) => new Date(Date.now() + n * 86400000).toISOString()

let contador = 0
const id = (prefijo) => {
  contador += 1
  const base = Date.now().toString(36)
  return `${prefijo}-${base}-${contador}`.replace(/[^a-z0-9-]/gi, '')
}


/* ==================================================================
 * Semilla
 * ================================================================== */

const REGIONES = [
  { id: 'r-rm', codigo: 'RM13', nombre: 'Región Metropolitana de Santiago' },
  { id: 'r-v', codigo: 'V05', nombre: 'Región de Valparaíso' },
  { id: 'r-ap', codigo: 'XV15', nombre: 'Región de Arica y Parinacota' },
  { id: 'r-ta', codigo: 'I01', nombre: 'Región de Tarapacá' },
  { id: 'r-an', codigo: 'II02', nombre: 'Región de Antofagasta' },
  { id: 'r-at', codigo: 'III03', nombre: 'Región de Atacama' },
  { id: 'r-co', codigo: 'IV04', nombre: 'Región de Coquimbo' },
  { id: 'r-oh', codigo: 'VI06', nombre: 'Región de O’Higgins' },
  { id: 'r-ml', codigo: 'VII07', nombre: 'Región del Maule' },
  { id: 'r-nb', codigo: 'XVI16', nombre: 'Región de Ñuble' },
  { id: 'r-bi', codigo: 'VIII08', nombre: 'Región del Biobío' },
  { id: 'r-ar', codigo: 'IX09', nombre: 'Región de La Araucanía' },
  { id: 'r-lr', codigo: 'XIV14', nombre: 'Región de Los Ríos' },
  { id: 'r-ll', codigo: 'X10', nombre: 'Región de Los Lagos' },
  { id: 'r-ai', codigo: 'XI11', nombre: 'Región de Aysén' },
  { id: 'r-ma', codigo: 'XII12', nombre: 'Región de Magallanes y de la Antártica Chilena' },
]

const COMUNAS = [
  { id: 'c-paine', region_id: 'r-rm', codigo: 'RMPAI', nombre: 'Paine' },
  { id: 'c-buin', region_id: 'r-rm', codigo: 'RMBUI', nombre: 'Buin' },
  { id: 'c-santiago', region_id: 'r-rm', codigo: 'RMSAN', nombre: 'Santiago' },
  { id: 'c-nunoa', region_id: 'r-rm', codigo: 'RMPRO', nombre: 'Providencia' },
  { id: 'c-quillota', region_id: 'r-v', codigo: 'V05QUI', nombre: 'Quillota' },
  { id: 'c-valparaiso', region_id: 'r-v', codigo: 'V05VAL', nombre: 'Valparaíso' },
  { id: 'c-arica', region_id: 'r-ap', codigo: 'XVARI', nombre: 'Arica' },
  { id: 'c-putre', region_id: 'r-ap', codigo: 'XVPUT', nombre: 'Putre' },
  { id: 'c-iquique', region_id: 'r-ta', codigo: 'I01IQU', nombre: 'Iquique' },
  { id: 'c-alto-hospicio', region_id: 'r-ta', codigo: 'I01ALT', nombre: 'Alto Hospicio' },
  { id: 'c-antofagasta', region_id: 'r-an', codigo: 'II02ANT', nombre: 'Antofagasta' },
  { id: 'c-calama', region_id: 'r-an', codigo: 'II02CAL', nombre: 'Calama' },
  { id: 'c-copiapo', region_id: 'r-at', codigo: 'III03COP', nombre: 'Copiapó' },
  { id: 'c-vallenar', region_id: 'r-at', codigo: 'III03VAL', nombre: 'Vallenar' },
  { id: 'c-la-serena', region_id: 'r-co', codigo: 'IV04SER', nombre: 'La Serena' },
  { id: 'c-coquimbo', region_id: 'r-co', codigo: 'IV04COQ', nombre: 'Coquimbo' },
  { id: 'c-rancagua', region_id: 'r-oh', codigo: 'V06RAP', nombre: 'Rancagua' },
  { id: 'c-san-fernando', region_id: 'r-oh', codigo: 'V06SFE', nombre: 'San Fernando' },
  { id: 'c-talca', region_id: 'r-ml', codigo: 'V07TAL', nombre: 'Talca' },
  { id: 'c-curico', region_id: 'r-ml', codigo: 'V07CUR2', nombre: 'Curicó' },
  { id: 'c-chillan', region_id: 'r-nb', codigo: 'XVI16CHI', nombre: 'Chillán' },
  { id: 'c-san-carlos', region_id: 'r-nb', codigo: 'XVI16SCA', nombre: 'San Carlos' },
  { id: 'c-concepcion', region_id: 'r-bi', codigo: 'VIII08CON', nombre: 'Concepción' },
  { id: 'c-los-angeles', region_id: 'r-bi', codigo: 'VIII08LAN', nombre: 'Los Ángeles' },
  { id: 'c-temuco', region_id: 'r-ar', codigo: 'IX09TEM', nombre: 'Temuco' },
  { id: 'c-villarrica', region_id: 'r-ar', codigo: 'IX09VIL', nombre: 'Villarrica' },
  { id: 'c-valdivia', region_id: 'r-lr', codigo: 'XIV14VAL', nombre: 'Valdivia' },
  { id: 'c-la-union', region_id: 'r-lr', codigo: 'XIV14LUN', nombre: 'La Unión' },
  { id: 'c-puerto-montt', region_id: 'r-ll', codigo: 'X10PMO', nombre: 'Puerto Montt' },
  { id: 'c-osorno', region_id: 'r-ll', codigo: 'X10OSO', nombre: 'Osorno' },
  { id: 'c-coyhaique', region_id: 'r-ai', codigo: 'XI11COY', nombre: 'Coyhaique' },
  { id: 'c-puerto-aysen', region_id: 'r-ai', codigo: 'XI11PAY', nombre: 'Puerto Aysén' },
  { id: 'c-punta-arenas', region_id: 'r-ma', codigo: 'XII12PNA', nombre: 'Punta Arenas' },
  { id: 'c-puerto-natales', region_id: 'r-ma', codigo: 'XII12NAT', nombre: 'Puerto Natales' },
]

const CATEGORIAS = [
  { id: 'cat-hortalizas', nombre: 'Hortalizas', slug: 'hortalizas', es_sistema: true, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-frutas', nombre: 'Frutas', slug: 'frutas', es_sistema: true, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-tuberculos', nombre: 'Tubérculos', slug: 'tuberculos', es_sistema: true, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-hierbas', nombre: 'Hierbas aromáticas', slug: 'hierbas-aromaticas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-conservas', nombre: 'Conservas', slug: 'conservas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-lacteos', nombre: 'Lácteos y huevos', slug: 'lacteos-huevos', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-carnes', nombre: 'Carnes y embutidos', slug: 'carnes-embutidos', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-miel', nombre: 'Miel y dulces', slug: 'miel-dulces', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-granos', nombre: 'Granos y semillas', slug: 'granos-semillas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-frutos-secos', nombre: 'Frutos secos', slug: 'frutos-secos', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-aceites', nombre: 'Aceites y condimentos', slug: 'aceites-condimentos', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-bebidas', nombre: 'Bebidas', slug: 'bebidas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-flores', nombre: 'Flores y plantas', slug: 'flores-plantas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-artesanias', nombre: 'Artesanías', slug: 'artesanias', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-mascotas', nombre: 'Alimentos para mascotas', slug: 'alimentos-mascotas', es_sistema: false, categoria_padre_id: null, eliminado_en: null },
  { id: 'cat-hortalizas-hoja', nombre: 'Hojas verdes', slug: 'hortalizas-hojas-verdes', es_sistema: false, categoria_padre_id: 'cat-hortalizas', eliminado_en: null },
  { id: 'cat-hortalizas-fruto', nombre: 'Frutos de huerto', slug: 'hortalizas-frutos-huerto', es_sistema: false, categoria_padre_id: 'cat-hortalizas', eliminado_en: null },
  { id: 'cat-frutas-citricos', nombre: 'Cítricos', slug: 'frutas-citricos', es_sistema: false, categoria_padre_id: 'cat-frutas', eliminado_en: null },
  { id: 'cat-frutas-uvas', nombre: 'Uvas y berries', slug: 'frutas-uvas-berries', es_sistema: false, categoria_padre_id: 'cat-frutas', eliminado_en: null },
  { id: 'cat-tuberculos-papa', nombre: 'Papas', slug: 'tuberculos-papas', es_sistema: false, categoria_padre_id: 'cat-tuberculos', eliminado_en: null },
  { id: 'cat-hortalizas-raiz', nombre: 'Raíces y bulbos', slug: 'hortalizas-raices-bulbos', es_sistema: false, categoria_padre_id: 'cat-hortalizas', eliminado_en: null },
  { id: 'cat-frutas-carozo', nombre: 'Carozos', slug: 'frutas-carozos', es_sistema: false, categoria_padre_id: 'cat-frutas', eliminado_en: null },
  { id: 'cat-frutas-pomacea', nombre: 'Pomáceas', slug: 'frutas-pomaceas', es_sistema: false, categoria_padre_id: 'cat-frutas', eliminado_en: null },
  { id: 'cat-frutas-tropical', nombre: 'Tropicales', slug: 'frutas-tropicales', es_sistema: false, categoria_padre_id: 'cat-frutas', eliminado_en: null },
  { id: 'cat-tuberculos-otros', nombre: 'Camotes y otros', slug: 'tuberculos-camotes', es_sistema: false, categoria_padre_id: 'cat-tuberculos', eliminado_en: null },
  { id: 'cat-hierbas-frescas', nombre: 'Aromáticas frescas', slug: 'hierbas-aromaticas-frescas', es_sistema: false, categoria_padre_id: 'cat-hierbas', eliminado_en: null },
  { id: 'cat-hierbas-medicinales', nombre: 'Medicinales', slug: 'hierbas-medicinales', es_sistema: false, categoria_padre_id: 'cat-hierbas', eliminado_en: null },
  { id: 'cat-conservas-mermelada', nombre: 'Mermeladas y dulces', slug: 'conservas-mermeladas', es_sistema: false, categoria_padre_id: 'cat-conservas', eliminado_en: null },
  { id: 'cat-conservas-encurtido', nombre: 'Encurtidos y fermentos', slug: 'conservas-encurtidos', es_sistema: false, categoria_padre_id: 'cat-conservas', eliminado_en: null },
  { id: 'cat-conservas-salsa', nombre: 'Salsas y aderezos', slug: 'conservas-salsas', es_sistema: false, categoria_padre_id: 'cat-conservas', eliminado_en: null },
  { id: 'cat-lacteos-queso', nombre: 'Quesos', slug: 'lacteos-quesos', es_sistema: false, categoria_padre_id: 'cat-lacteos', eliminado_en: null },
  { id: 'cat-lacteos-leche', nombre: 'Leche y yogur', slug: 'lacteos-leche-yogur', es_sistema: false, categoria_padre_id: 'cat-lacteos', eliminado_en: null },
  { id: 'cat-lacteos-huevo', nombre: 'Huevos', slug: 'lacteos-huevos-frescos', es_sistema: false, categoria_padre_id: 'cat-lacteos', eliminado_en: null },
  { id: 'cat-carnes-pollo', nombre: 'Pollo y aves', slug: 'carnes-pollo-aves', es_sistema: false, categoria_padre_id: 'cat-carnes', eliminado_en: null },
  { id: 'cat-carnes-cerdo', nombre: 'Cerdo', slug: 'carnes-cerdo', es_sistema: false, categoria_padre_id: 'cat-carnes', eliminado_en: null },
  { id: 'cat-carnes-vacuno', nombre: 'Vacuno', slug: 'carnes-vacuno', es_sistema: false, categoria_padre_id: 'cat-carnes', eliminado_en: null },
  { id: 'cat-carnes-embutido', nombre: 'Embutidos', slug: 'carnes-embutidos-artesanales', es_sistema: false, categoria_padre_id: 'cat-carnes', eliminado_en: null },
  { id: 'cat-miel-miel', nombre: 'Miel', slug: 'miel', es_sistema: false, categoria_padre_id: 'cat-miel', eliminado_en: null },
  { id: 'cat-miel-postre', nombre: 'Dulces y postres', slug: 'miel-dulces-postres', es_sistema: false, categoria_padre_id: 'cat-miel', eliminado_en: null },
  { id: 'cat-granos-legumbre', nombre: 'Legumbres', slug: 'granos-legumbres', es_sistema: false, categoria_padre_id: 'cat-granos', eliminado_en: null },
  { id: 'cat-granos-cereal', nombre: 'Cereales', slug: 'granos-cereales', es_sistema: false, categoria_padre_id: 'cat-granos', eliminado_en: null },
  { id: 'cat-granos-semilla', nombre: 'Semillas', slug: 'granos-semillas-varias', es_sistema: false, categoria_padre_id: 'cat-granos', eliminado_en: null },
  { id: 'cat-secos-nuez', nombre: 'Nueces y frutos secos', slug: 'frutos-secos-nueces', es_sistema: false, categoria_padre_id: 'cat-frutos-secos', eliminado_en: null },
  { id: 'cat-secos-fruta', nombre: 'Frutas deshidratadas', slug: 'frutos-secos-deshidratadas', es_sistema: false, categoria_padre_id: 'cat-frutos-secos', eliminado_en: null },
  { id: 'cat-aceites-oliva', nombre: 'Aceite de oliva', slug: 'aceites-oliva', es_sistema: false, categoria_padre_id: 'cat-aceites', eliminado_en: null },
  { id: 'cat-aceites-vinagre', nombre: 'Vinagres', slug: 'aceites-vinagres', es_sistema: false, categoria_padre_id: 'cat-aceites', eliminado_en: null },
  { id: 'cat-aceites-especia', nombre: 'Condimentos y especias', slug: 'aceites-condimentos-especias', es_sistema: false, categoria_padre_id: 'cat-aceites', eliminado_en: null },
  { id: 'cat-bebidas-jugo', nombre: 'Jugos y aguas', slug: 'bebidas-jugos-aguas', es_sistema: false, categoria_padre_id: 'cat-bebidas', eliminado_en: null },
  { id: 'cat-bebidas-vino', nombre: 'Vinos y licores', slug: 'bebidas-vinos-licores', es_sistema: false, categoria_padre_id: 'cat-bebidas', eliminado_en: null },
  { id: 'cat-bebidas-infusion', nombre: 'Infusiones', slug: 'bebidas-infusiones', es_sistema: false, categoria_padre_id: 'cat-bebidas', eliminado_en: null },
  { id: 'cat-flores-corte', nombre: 'Flores de corte', slug: 'flores-corte', es_sistema: false, categoria_padre_id: 'cat-flores', eliminado_en: null },
  { id: 'cat-flores-vivero', nombre: 'Plantas y vivero', slug: 'plantas-vivero', es_sistema: false, categoria_padre_id: 'cat-flores', eliminado_en: null },
  { id: 'cat-artesanias-textil', nombre: 'Textiles', slug: 'artesanias-textiles', es_sistema: false, categoria_padre_id: 'cat-artesanias', eliminado_en: null },
  { id: 'cat-artesanias-madera', nombre: 'Madera y cerámica', slug: 'artesanias-madera-ceramica', es_sistema: false, categoria_padre_id: 'cat-artesanias', eliminado_en: null },
  { id: 'cat-artesanias-cosmetica', nombre: 'Cosmética natural', slug: 'artesanias-cosmetica-natural', es_sistema: false, categoria_padre_id: 'cat-artesanias', eliminado_en: null },
  { id: 'cat-mascotas-alimento', nombre: 'Alimentos para mascotas', slug: 'mascotas-alimentos', es_sistema: false, categoria_padre_id: 'cat-mascotas', eliminado_en: null },
  { id: 'cat-mascotas-snack', nombre: 'Snacks y premios', slug: 'mascotas-snacks', es_sistema: false, categoria_padre_id: 'cat-mascotas', eliminado_en: null },
]

const CUENTAS = [
  {
    id: 'u-admin',
    email: 'admin@cutuco.dev',
    nombre: 'Administrador',
    apellido: 'CuTuCo',
    telefono: '+56900000001',
    rol: 'admin',
  },
  {
    id: 'u-vendedor',
    email: 'vendedor@cutuco.dev',
    nombre: 'Verónica',
    apellido: 'Del Campo',
    telefono: '+56900000002',
    rol: 'vendedor',
  },
  {
    id: 'u-cliente',
    email: 'cliente@cutuco.dev',
    nombre: 'Camila',
    apellido: 'Rojas',
    telefono: '+56900000003',
    rol: 'cliente',
  },
  {
    id: 'u-pendiente',
    email: 'pendiente@cutuco.dev',
    nombre: 'Pedro',
    apellido: 'En Revisión',
    telefono: '+56900000004',
    rol: 'cliente',
  },
]

const PRODUCTORES = [
  {
    id: 'p-huerta',
    perfil_id: 'u-vendedor',
    nombre_comercial: 'Huerta del Desarrollador',
    slug: 'huerta-del-desarrollador',
    descripcion: 'Hortalizas y frutas de temporada cultivadas en Paine.',
    activo: true,
    aprobado_en: dias(-60),
    puntaje_reputacion: 4.6,
    cantidad_evaluaciones: 2,
    region_id: 'r-rm',
  },
  {
    id: 'p-valle',
    perfil_id: 'u-productor-2',
    nombre_comercial: 'Valle de Quillota',
    slug: 'valle-de-quillota',
    descripcion: 'Paltas y cítricos del valle de Quillota.',
    activo: true,
    aprobado_en: dias(-45),
    puntaje_reputacion: 4.2,
    cantidad_evaluaciones: 1,
    region_id: 'r-v',
  },
]

const PRODUCTOS = [
  ['pr-tomate', 'p-huerta', 'cat-hortalizas', 'Tomates Roma', 'Tomates de cultivo, cosechados a mano.', 2800, 48, 'kg', dias(-1)],
  ['pr-lechuga', 'p-huerta', 'cat-hortalizas', 'Lechugas hidropónicas', 'Lechuga fresca de sistema NFT.', 1200, 26, 'unidad', dias(-1)],
  ['pr-papa', 'p-huerta', 'cat-tuberculos', 'Papas nuevas', 'Papas lavadas y clasificadas.', 1600, 60, 'kg', dias(-3)],
  ['pr-miel', 'p-huerta', 'cat-miel', 'Miel multifloral 500 g', 'Miel artesanal sin refinamiento.', 8500, 18, 'unidad', null],
  ['pr-naranja', 'p-huerta', 'cat-frutas', 'Naranjas de mesa', 'Naranjas dulces de la zona central.', 1900, 40, 'kg', dias(-2)],
  ['pr-palta', 'p-valle', 'cat-frutas', 'Paltas Hass', 'Paltas de Quillota, calibre medio.', 4200, 30, 'kg', dias(-4)],
  ['pr-limon', 'p-valle', 'cat-frutas', 'Limones de Pica', 'Limones jugosos y aromáticos.', 2200, 24, 'kg', dias(-5)],
  ['pr-zapallo', 'p-valle', 'cat-hortalizas', 'Zapallo italiano', 'Zapallo tierno de huerto.', 1450, 22, 'unidad', dias(-2)],
]

const IMAGENES = [
  ['pr-tomate', 'tomates.webp'],
  ['pr-lechuga', 'lechugas.webp'],
  ['pr-papa', 'papas.webp'],
  ['pr-miel', 'miel.webp'],
  ['pr-palta', 'paltas.webp'],
]

function construir() {
  const regiones = REGIONES.map((r) => ({ ...r, creado_en: dias(-90) }))
  const comunas = COMUNAS.map((c) => ({ ...c, creado_en: dias(-90) }))

  const perfiles = CUENTAS.map((cuenta) => ({
    id: cuenta.id,
    nombre: cuenta.nombre,
    apellido: cuenta.apellido,
    telefono: cuenta.telefono,
    rol: cuenta.rol,
    activo: true,
    intentos_login_fallidos: 0,
    bloqueado_hasta: null,
    ultimo_acceso_en: dias(-1),
    es_super_admin: false,
    es_protegido: false,
    creado_en: dias(-90),
    email: cuenta.email,
    password: DEMO_PASSWORD,
  }))

  // Un vendedor adicional para el catálogo de otra región (RF-009).
  perfiles.push({
    id: 'u-productor-2',
    nombre: 'Valentina',
    apellido: 'Quillota',
    telefono: '+56900000005',
    rol: 'vendedor',
    activo: true,
    intentos_login_fallidos: 0,
    bloqueado_hasta: null,
    ultimo_acceso_en: dias(-3),
    es_super_admin: false,
    es_protegido: false,
    creado_en: dias(-80),
    email: 'quillota@cutuco.dev',
    password: DEMO_PASSWORD,
  })

  const productores = PRODUCTORES.map((p) => ({
    ...p,
    creado_en: dias(-80),
    actualizado_en: dias(-2),
  }))

  const productos = PRODUCTOS.map(([pid, productor, categoria, nombre, descripcion, precio, stock, unidad, cosecha]) => {
    const umbral = stock <= 26 ? 30 : 10
    return {
      id: pid,
      productor_id: productor,
      categoria_id: categoria,
      nombre,
      slug: nombre.toLowerCase().replaceAll(/[^a-z0-9]+/g, '-'),
      descripcion,
      precio,
      stock,
      unidad_medida: unidad,
      fecha_cosecha: cosecha,
      umbral_bajo: umbral,
      es_cosecha_mismo_dia: false,
      activo: true,
      eliminado_en: null,
      creado_en: dias(-40),
      actualizado_en: dias(-1),
    }
  })

  const imagenes = IMAGENES.map(([producto, archivo], i) => ({
    id: `img-${i + 1}`,
    producto_id: producto,
    ruta_storage: `product-images/${producto}/${archivo}`,
    nombre_archivo: archivo,
    mime_type: 'image/webp',
    tamano_bytes: 102400,
    texto_alternativo: productos.find((p) => p.id === producto)?.nombre ?? '',
    posicion: 1,
    es_principal: true,
    metadatos: {},
    creado_en: dias(-40),
    actualizado_en: dias(-40),
  }))

  const direcciones = [
    {
      id: 'd-vendedor',
      perfil_id: 'u-vendedor',
      etiqueta: 'Predio',
      comuna_id: 'c-paine',
      calle: 'Camino a Paine',
      numero: 'km 4',
      depto_oficina: null,
      referencia: 'Portón verde',
      es_principal: true,
      activo: true,
      creado_en: dias(-89),
    },
    {
      id: 'd-cliente',
      perfil_id: 'u-cliente',
      etiqueta: 'Casa',
      comuna_id: 'c-santiago',
      calle: 'Calle Compañía',
      numero: '1200',
      depto_oficina: 'Depto 402',
      referencia: 'Timbre 3',
      es_principal: true,
      activo: true,
      creado_en: dias(-88),
    },
    {
      id: 'd-cliente-2',
      perfil_id: 'u-cliente',
      etiqueta: 'Oficina',
      comuna_id: 'c-nunoa',
      calle: 'Av. Irarrázaval',
      numero: '3400',
      depto_oficina: null,
      referencia: null,
      es_principal: false,
      activo: true,
      creado_en: dias(-30),
    },
    {
      id: 'd-valle',
      perfil_id: 'u-productor-2',
      etiqueta: 'Predio',
      comuna_id: 'c-quillota',
      calle: 'Camino a San Isidro',
      numero: 'S/N',
      depto_oficina: null,
      referencia: null,
      es_principal: true,
      activo: true,
      creado_en: dias(-80),
    },
  ]

  const postulaciones = [
    {
      id: 'post-1',
      perfil_id: 'u-pendiente',
      nombre_comercial_solicitado: 'Vega del Maipo',
      descripcion: 'Venta de hortalizas y huevos de campo.',
      estado: 'en_revision',
      observaciones_admin: null,
      revisado_por: null,
      revisado_en: null,
      comuna_origen_id: 'c-buin',
      creado_en: dias(-4),
      actualizado_en: dias(-4),
    },
    {
      id: 'post-2',
      perfil_id: 'u-vendedor',
      nombre_comercial_solicitado: 'Huerta del Desarrollador',
      descripcion: 'Postulación aprobada del productor demo.',
      estado: 'aprobada',
      observaciones_admin: null,
      revisado_por: 'u-admin',
      revisado_en: dias(-60),
      comuna_origen_id: 'c-paine',
      creado_en: dias(-62),
      actualizado_en: dias(-60),
    },
    {
      id: 'post-3',
      perfil_id: 'u-productor-2',
      nombre_comercial_solicitado: 'Valle de Quillota',
      descripcion: 'Postulación aprobada del productor de Valparaíso.',
      estado: 'aprobada',
      observaciones_admin: null,
      revisado_por: 'u-admin',
      revisado_en: dias(-45),
      comuna_origen_id: 'c-quillota',
      creado_en: dias(-47),
      actualizado_en: dias(-45),
    },
  ]

  const coberturas = [
    { id: 'cob-1', productor_id: 'p-huerta', tipo_cobertura: 'region', region_id: 'r-rm', comuna_id: null, activo: true, creado_en: dias(-60) },
    { id: 'cob-2', productor_id: 'p-huerta', tipo_cobertura: 'comuna', region_id: null, comuna_id: 'c-paine', activo: true, creado_en: dias(-60) },
    { id: 'cob-3', productor_id: 'p-valle', tipo_cobertura: 'region', region_id: 'r-v', comuna_id: null, activo: true, creado_en: dias(-45) },
  ]

  const datosBancarios = [
    {
      id: 'db-1',
      perfil_id: 'u-vendedor',
      banco: 'Banco Estado',
      tipo_cuenta: 'CuentaRUT',
      numero_cuenta_cifrado: null,
      titular_cuenta: 'Verónica Del Campo',
      rut_titular: '12.345.678-9',
      activo: true,
      creado_en: dias(-60),
    },
  ]

  const pedidos = [
    {
      id: 'o-1',
      codigo_pedido: 'CUTU-2026-0001',
      cliente_id: 'u-cliente',
      productor_id: 'p-huerta',
      region_entrega_id: 'r-rm',
      comuna_entrega_id: 'c-santiago',
      direccion_entrega: 'Calle Compañía 1200, Depto 402',
      referencia_entrega: 'Timbre 3',
      nombre_destinatario: 'Camila Rojas',
      telefono_destinatario: '+56900000003',
      estado: 'en_preparacion',
      subtotal_productos: 5600,
      tarifa_delivery: 3500,
      porcentaje_fee_plataforma: 0.05,
      monto_fee_plataforma: 280,
      total: 9100,
      monto_retenido: 9100,
      monto_liquidar_productor: 8820,
      confirmado_cliente_en: null,
      liberable_desde_en: null,
      payout_ejecutado_en: null,
      inventario_repuesto_en: null,
      cancelado_en: null,
      creado_en: dias(-2),
      actualizado_en: dias(-2),
    },
    {
      id: 'o-2',
      codigo_pedido: 'CUTU-2026-0002',
      cliente_id: 'u-cliente',
      productor_id: 'p-huerta',
      region_entrega_id: 'r-rm',
      comuna_entrega_id: 'c-santiago',
      direccion_entrega: 'Calle Compañía 1200, Depto 402',
      referencia_entrega: null,
      nombre_destinatario: 'Camila Rojas',
      telefono_destinatario: '+56900000003',
      estado: 'completado',
      subtotal_productos: 8500,
      tarifa_delivery: 3500,
      porcentaje_fee_plataforma: 0.05,
      monto_fee_plataforma: 425,
      total: 12000,
      monto_retenido: 12000,
      monto_liquidar_productor: 11575,
      confirmado_cliente_en: dias(-1),
      liberable_desde_en: dias(-1),
      payout_ejecutado_en: null,
      inventario_repuesto_en: null,
      cancelado_en: null,
      creado_en: dias(-6),
      actualizado_en: dias(-1),
    },
    {
      id: 'o-3',
      codigo_pedido: 'CUTU-2026-0003',
      cliente_id: 'u-cliente',
      productor_id: 'p-valle',
      region_entrega_id: 'r-rm',
      comuna_entrega_id: 'c-nunoa',
      direccion_entrega: 'Av. Irarrázaval 3400',
      referencia_entrega: null,
      nombre_destinatario: 'Camila Rojas',
      telefono_destinatario: '+56900000003',
      estado: 'creado',
      subtotal_productos: 4200,
      tarifa_delivery: 3500,
      porcentaje_fee_plataforma: 0.05,
      monto_fee_plataforma: 210,
      total: 7700,
      monto_retenido: 0,
      monto_liquidar_productor: 7490,
      confirmado_cliente_en: null,
      liberable_desde_en: null,
      payout_ejecutado_en: null,
      inventario_repuesto_en: null,
      cancelado_en: null,
      creado_en: dias(-1),
      actualizado_en: dias(-1),
    },
  ]

  const detalles = [
    { id: 'od-1', pedido_id: 'o-1', producto_id: 'pr-tomate', producto_nombre: 'Tomates Roma', precio_unitario: 2800, cantidad: 2, subtotal: 5600, creado_en: dias(-2) },
    { id: 'od-2', pedido_id: 'o-2', producto_id: 'pr-miel', producto_nombre: 'Miel multifloral 500 g', precio_unitario: 8500, cantidad: 1, subtotal: 8500, creado_en: dias(-6) },
    { id: 'od-3', pedido_id: 'o-3', producto_id: 'pr-palta', producto_nombre: 'Paltas Hass', precio_unitario: 4200, cantidad: 1, subtotal: 4200, creado_en: dias(-1) },
  ]

  const pagos = [
    {
      id: 'pay-1',
      pedido_id: 'o-1',
      buy_order: 'CUTUCO-DEMO-0001',
      token_ws: 'demo-token-0001',
      estado: 'retenido',
      monto: 9100,
      codigo_autorizacion: 'AUTH-DEMO-1',
      codigo_respuesta: '0',
      respuesta_webpay: {},
      autorizado_en: dias(-2),
      retenido_en: dias(-2),
      liberado_en: null,
      reembolsado_en: null,
      creado_en: dias(-2),
    },
    {
      id: 'pay-2',
      pedido_id: 'o-2',
      buy_order: 'CUTUCO-DEMO-0002',
      token_ws: 'demo-token-0002',
      estado: 'retenido',
      monto: 12000,
      codigo_autorizacion: 'AUTH-DEMO-2',
      codigo_respuesta: '0',
      respuesta_webpay: {},
      autorizado_en: dias(-6),
      retenido_en: dias(-6),
      liberado_en: null,
      reembolsado_en: null,
      creado_en: dias(-6),
    },
  ]

  const envios = [
    {
      id: 'e-1',
      pedido_id: 'o-1',
      repartidor_id: 'u-vendedor',
      estado: 'preparacion',
      tarifa_fija: 3500,
      codigo_verificacion: null,
      codigo_verificado_en: null,
      despachado_en: null,
      entregado_en: null,
      fallido_en: null,
      motivo_fallo: null,
      creado_en: dias(-2),
      actualizado_en: dias(-2),
    },
    {
      id: 'e-2',
      pedido_id: 'o-2',
      repartidor_id: 'u-vendedor',
      estado: 'entregado',
      tarifa_fija: 3500,
      codigo_verificacion: 'A1B2C3D4E5F6',
      codigo_verificado_en: dias(-1),
      despachado_en: dias(-2),
      entregado_en: dias(-1),
      fallido_en: null,
      motivo_fallo: null,
      creado_en: dias(-6),
      actualizado_en: dias(-1),
    },
  ]

  const payouts = [
    {
      id: 'po-1',
      beneficiario_id: 'u-vendedor',
      pedido_id: 'o-2',
      tipo: 'pago_productor',
      monto: 11575,
      estado: 'pendiente',
      referencia_externa: null,
      comprobante_ruta: null,
      notas: null,
      ejecutado_por: null,
      ejecutado_en: null,
      creado_en: dias(-1),
    },
  ]

  const evaluaciones = [
    {
      id: 'ev-1',
      pedido_id: 'o-2',
      productor_id: 'p-huerta',
      cliente_id: 'u-cliente',
      puntaje: 5,
      comentario: 'Todo llegó fresco y muy bien embalado.',
      entrega_a_tiempo: 1,
      calidad: 5,
      respuesta_reclamos: 4,
      creado_en: dias(-1),
    },
  ]

  const sanciones = [
    {
      id: 'san-1',
      productor_id: 'p-valle',
      tipo: 'amonestacion',
      accion: 'ninguna',
      estado: 'activa',
      numero_amonestacion: 1,
      motivo: 'Retraso reiterado en dos entregas.',
      duracion_dias: null,
      inicio_en: dias(-10),
      fin_en: null,
      resuelta_en: null,
      impuesta_por: 'u-admin',
      automatica: false,
      puntaje_disparador: null,
      creado_en: dias(-10),
    },
  ]

  const alertas = productos
    .filter((p) => p.stock <= p.umbral_bajo)
    .map((p, i) => ({
      id: `al-${i + 1}`,
      producto_id: p.id,
      umbral_configurado: p.umbral_bajo,
      stock_al_generar: p.stock,
      atendida_en: null,
      notificada: true,
      creado_en: dias(-1),
    }))

  const palabrasProhibidas = [
    { id: 'pp-1', palabra: 'falsificado', activo: true, creado_en: dias(-40) },
    { id: 'pp-2', palabra: 'milagroso', activo: true, creado_en: dias(-40) },
    { id: 'pp-3', palabra: 'basura', activo: true, creado_en: dias(-40) },
  ]

  const configuracion = [{ id: 1, tarifa_delivery_defecto: 3500, creado_en: dias(-90) }]
  const cuentaTransferenciaServicio = [
    {
      id: 1,
      banco: 'BancoEstado',
      tipo_cuenta: 'Cuenta corriente',
      numero_cuenta: '12345678',
      titular: 'CuTuCo SpA',
      rut: '76.543.210-8',
      creado_en: dias(-90),
      actualizado_en: dias(-2),
    },
  ]

  const reclamos = [
    {
      id: 'rec-1',
      pedido_id: 'o-1',
      cliente_id: 'u-cliente',
      motivo: 'Faltó una unidad en la entrega.',
      detalle: 'Pedí dos kilos y llegó uno y medio.',
      estado: 'abierto',
      respuesta_productor: null,
      resuelto_por: null,
      resuelto_en: null,
      creado_en: dias(-1),
    },
  ]

  return {
    regiones,
    comunas,
    categorias: CATEGORIAS.map((c) => ({
      ...c,
      categoria_padre_id: c.categoria_padre_id ?? null,
      creado_en: dias(-90),
    })),
    perfiles,
    direcciones,
    postulaciones_vendedores: postulaciones,
    productores,
    datos_bancarios: datosBancarios,
    productos,
    imagenes_productos: imagenes,
    coberturas_productor: coberturas,
    pedidos,
    detalles_pedido: detalles,
    pagos,
    payouts,
    envios,
    evaluaciones_reputacion: evaluaciones,
    sanciones,
    apelaciones: [],
    alertas_stock: alertas,
    historial_precios: [],
    documentos_identidad: [
      {
        id: 'doc-1',
        postulacion_id: 'post-1',
        perfil_id: 'u-pendiente',
        tipo: 'frente',
        ruta_storage: 'identidad-vendedores/frente.svg',
        nombre_archivo: 'frente.svg',
        mime_type: 'image/svg+xml',
        tamano_bytes: 12000,
        metadatos: {},
        subido_en: dias(-4),
        expira_en: dias(7),
        eliminado_en: null,
        creado_en: dias(-4),
      },
    ],
    evidencias_envio: [],
    palabras_prohibidas: palabrasProhibidas,
    configuracion_logistica: configuracion,
    cuenta_transferencia_servicio: cuentaTransferenciaServicio,
    reclamos,
  }
}

/* ==================================================================
 * API de la base de datos demo
 * ================================================================== */

export function createDemoDatabase() {
  let datos = null

  try {
    const guardado = localStorage.getItem(CLAVE)
    if (guardado) datos = JSON.parse(guardado)
  } catch {
    datos = null
  }

  if (!datos) datos = construir()

  // Las copias de modo demostración sobreviven a la recarga. Agregar la tabla
  // singleton aquí evita que una copia creada antes de esta funcionalidad deje
  // al administrador sin una fila que actualizar.
  if (!Array.isArray(datos.cuenta_transferencia_servicio)) {
    datos.cuenta_transferencia_servicio = [
      {
        id: 1,
        banco: 'BancoEstado',
        tipo_cuenta: 'Cuenta corriente',
        numero_cuenta: '12345678',
        titular: 'CuTuCo SpA',
        rut: '76.543.210-8',
        creado_en: ahora(),
        actualizado_en: ahora(),
      },
    ]
    try {
      localStorage.setItem(CLAVE, JSON.stringify(datos))
    } catch {
      /* almacenamiento lleno o no disponible */
    }
  }

  const archivos = {}
  let demo

  function persistir() {
    try {
      localStorage.setItem(CLAVE, JSON.stringify(datos))
    } catch {
      /* almacenamiento lleno o no disponible */
    }
  }

  function tabla(nombre) {
    if (!datos[nombre]) datos[nombre] = []
    return datos[nombre]
  }

  function insertar(nombre, entrada) {
    const filas = tabla(nombre)
    const fila = {
      id: entrada.id ?? id(nombre.slice(0, 3)),
      creado_en: entrada.creado_en ?? ahora(),
      ...entrada,
    }
    filas.push(fila)
    persistir()
    return fila
  }

  function actualizar(nombre, fila, patch) {
    Object.assign(fila, patch, { actualizado_en: ahora() })
    persistir()
    return fila
  }

  function eliminar(nombre, fila) {
    datos[nombre] = tabla(nombre).filter((f) => f !== fila)
    persistir()
    return true
  }

  const buscarPorId = (nombre, valor) => tabla(nombre).find((f) => f.id === valor) ?? null
  const buscarPorEmail = (email) =>
    tabla('perfiles').find((p) => String(p.email).toLowerCase() === String(email).toLowerCase()) ?? null

  function crearPerfil({ email, password, nombre, apellido, telefono }) {
    return insertar('perfiles', {
      email: String(email).toLowerCase(),
      password,
      nombre: nombre ?? 'Usuario',
      apellido: apellido ?? null,
      telefono: telefono ?? null,
      rol: 'cliente',
      activo: true,
      intentos_login_fallidos: 0,
      bloqueado_hasta: null,
      es_super_admin: false,
      es_protegido: false,
    })
  }

  /**
   * RPC de negocio del esquema, implementadas sobre el dataset demo para poder
   * recorrer los flujos completos sin base de datos.
   */
  const rpc = {
    /* HAL-VEN-018: en la base real el cliente obtiene el código por RPC y la
     * columna está revocada; el demo replica el mismo contrato. */
    obtener_codigo_entrega: ({ p_envio_id }) => {
      const envio = buscarPorId('envios', p_envio_id)
      if (!envio) throw new Error('Envío inexistente')
      return envio.codigo_verificacion ?? null
    },
    verificar_codigo_entrega: ({ p_envio_id, p_codigo }) => {
      const envio = buscarPorId('envios', p_envio_id)
      if (!envio) throw new Error('Envío inexistente')
      if (envio.estado !== 'en_transito') {
        throw new Error('El código solo puede verificarse durante el estado en_transito')
      }
      if (String(envio.codigo_verificacion) !== String(p_codigo).trim().toUpperCase()) {
        throw new Error('Código de entrega inválido')
      }
      envio.codigo_verificado_en = ahora()
      persistir()
      return true
    },
    verificar_codigo_entrega_vendedor: ({ p_envio_id, p_codigo }) =>
      rpc.verificar_codigo_entrega({ p_envio_id, p_codigo }),
    marcar_pedido_en_preparacion: ({ p_pedido_id }) => {
      const pedido = buscarPorId('pedidos', p_pedido_id)
      if (!pedido) throw new Error('Pedido inexistente')
      if (!['pagado', 'en_preparacion'].includes(pedido.estado)) {
        throw new Error('Solo se puede marcar en preparación un pedido pagado')
      }
      pedido.estado = 'en_preparacion'
      const envio = tabla('envios').find((e) => e.pedido_id === p_pedido_id)
      if (envio) envio.preparado_en = envio.preparado_en ?? ahora()
      persistir()
      return { ok: true, pedido_id: p_pedido_id, estado: 'en_preparacion' }
    },
    cancelar_pedido_vendedor: ({ p_pedido_id, p_motivo }) => {
      const pedido = buscarPorId('pedidos', p_pedido_id)
      if (!pedido) throw new Error('Pedido inexistente')
      const motivo = String(p_motivo ?? '').trim()
      if (!motivo || motivo.length > 1000) {
        throw new Error('La justificación de cancelación debe tener entre 1 y 1000 caracteres')
      }
      if (pedido.estado === 'cancelado') {
        return { ok: true, pedido_id: p_pedido_id, estado: 'cancelado', ya_cancelado: true }
      }
      pedido.estado = 'cancelado'
      pedido.motivo_cancelacion = motivo
      pedido.cancelado_en = ahora()
      const envio = tabla('envios').find((e) => e.pedido_id === p_pedido_id)
      if (envio && ['preparacion', 'en_transito'].includes(envio.estado)) {
        envio.estado = 'cancelado'
        envio.motivo_cancelacion = motivo
        envio.cancelado_en = ahora()
      }
      persistir()
      return { ok: true, pedido_id: p_pedido_id, estado: 'cancelado', motivo_cancelacion: motivo }
    },
    confirmar_recepcion_pedido: ({ p_pedido_id }) => {
      const pedido = buscarPorId('pedidos', p_pedido_id)
      if (!pedido) throw new Error('Pedido inexistente')
      if (pedido.estado !== 'completado') throw new Error('Solo se puede confirmar un pedido completado')
      pedido.confirmado_cliente_en = pedido.confirmado_cliente_en ?? ahora()
      pedido.liberable_desde_en = pedido.liberable_desde_en ?? ahora()
      persistir()
      return true
    },
    contiene_palabra_prohibida: ({ p_texto }) => {
      const texto = String(p_texto ?? '').toLowerCase()
      return tabla('palabras_prohibidas').some((p) => p.activo && texto.includes(p.palabra.toLowerCase()))
    },
    guardar_datos_bancarios: ({ p_perfil_id, p_banco, p_tipo_cuenta, p_titular, p_rut_titular }) => {
      const existente = tabla('datos_bancarios').find((d) => d.perfil_id === p_perfil_id && d.activo)
      if (existente) {
        Object.assign(existente, {
          banco: p_banco,
          tipo_cuenta: p_tipo_cuenta,
          titular_cuenta: p_titular,
          rut_titular: p_rut_titular,
        })
        persistir()
        return existente.id
      }
      return insertar('datos_bancarios', {
        perfil_id: p_perfil_id,
        banco: p_banco,
        tipo_cuenta: p_tipo_cuenta,
        numero_cuenta_cifrado: null,
        titular_cuenta: p_titular,
        rut_titular: p_rut_titular,
        activo: true,
      }).id
    },
  }

  demo = { datos, archivos, tabla, insertar, actualizar, eliminar, buscarPorId, buscarPorEmail, crearPerfil, persistir, rpc }

  /** Restablece la semilla demo (lo usa la galería si algo queda inconsistente). */
  demo.reiniciar = () => {
    datos = construir()
    persistir()
    return datos
  }

  return demo
}



