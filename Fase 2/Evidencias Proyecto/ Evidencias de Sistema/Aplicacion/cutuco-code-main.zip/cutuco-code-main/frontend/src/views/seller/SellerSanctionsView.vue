<script setup>
/**
 * CuTuCo — Mis sanciones y apelaciones (RF-026).
 *
 * Ventana del vendedor para los cinco requerimientos del mapeo:
 *   r54 listar mis sanciones (con aviso de las vigentes)
 *   r55 ver el detalle de mi sanción
 *   r56 crear una apelación con fundamento (máx. 3000 caracteres)
 *   r57 listar mis apelaciones
 *   r58 ver el detalle de mi apelación (estado y resolución del administrador)
 *
 * Reglas del esquema:
 *   * `sanciones_select_productor_admin` limita la lectura al productor
 *     propietario (`private.es_productor_propietario`) y al administrador.
 *   * `apelaciones_insert_vendedor` exige `solicitante_id = auth.uid()` y que el
 *     productor sea del solicitante; `validar_apelacion` exige que la apelación
 *     nazca `pendiente`.
 *   * `uq_apelacion_pendiente_sancion`: una sola apelación pendiente por sanción.
 *   * `sincronizar_apelacion_sancion_al_crear` deja la sanción en `apelada` si
 *     estaba `activa`; al resolverla (`aprobada`/`rechazada`) el trigger la pasa a
 *     `cancelada` o la devuelve a `activa`.
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ACCION_SANCION, ESTADO_APELACION, ESTADO_SANCION, LABELS } from '@/lib/constants'
import { formatDate, formatDateTime } from '@/lib/format'
import { crearApelacion, getMiProductor, listMisApelaciones, listMisSanciones } from '@/services/seller'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const productor = ref(null)
const sanciones = ref([])
const apelaciones = ref([])
const cargando = ref(true)
const error = ref(null)

const detalle = ref(null)
const modalDetalle = ref(false)

const modalApelacion = ref(false)
const sancionAApelar = ref(null)
const fundamento = ref('')
const errorApelacion = ref(null)
const enviando = ref(false)

/** Estados que mantienen la sanción vigente (RF-026). */
const VIGENTES = [ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA]

const columnsSanciones = [
  { key: 'inicio_en', label: 'Inicio', width: '120px' },
  { key: 'tipo', label: 'Tipo', width: '140px' },
  { key: 'accion', label: 'Acción', width: '190px' },
  { key: 'motivo', label: 'Motivo' },
  { key: 'duracion_dias', label: 'Duración', width: '110px' },
  { key: 'fin_en', label: 'Termina', width: '130px' },
  { key: 'estado', label: 'Estado', width: '140px' },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '150px' },
]

const columnsApelaciones = [
  { key: 'creado_en', label: 'Presentada', width: '130px' },
  { key: 'sancion', label: 'Sanción', width: '200px' },
  { key: 'fundamento', label: 'Fundamento' },
  { key: 'estado', label: 'Estado', width: '140px' },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '120px' },
]

const vigentes = computed(() => sanciones.value.filter((s) => VIGENTES.includes(s.estado)))
const sancionMap = computed(() => new Map(sanciones.value.map((s) => [s.id, s])))

/** Sanciones que admiten una apelación nueva (sin una pendiente). */
const pendientesPorSancion = computed(() => {
  const set = new Set(
    apelaciones.value
      .filter((a) => a.estado === ESTADO_APELACION.PENDIENTE)
      .map((a) => a.sancion_id),
  )
  return set
})

function puedeApelar(sancion) {
  if (!VIGENTES.includes(sancion.estado)) return false
  // El ban permanente se revisa con administración (reactivación), no por el
  // flujo de apelaciones: el administrador no puede resolver esas apelaciones.
  if (sancion.accion === ACCION_SANCION.BAN_PERMANENTE) return false
  return !pendientesPorSancion.value.has(sancion.id)
}

function filasApelaciones() {
  return apelaciones.value.map((a) => ({
    ...a,
    sancion: sancionMap.value.get(a.sancion_id) ?? null,
  }))
}

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    productor.value = await getMiProductor()
    if (!productor.value) {
      sanciones.value = []
      apelaciones.value = []
      return
    }
    const [misSanciones, misApelaciones] = await Promise.all([
      listMisSanciones(),
      listMisApelaciones(),
    ])
    sanciones.value = misSanciones
    apelaciones.value = misApelaciones
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron cargar tus sanciones'
  } finally {
    cargando.value = false
  }
}

function verDetalle(sancion) {
  detalle.value = sancion
  modalDetalle.value = true
}

function verDetalleApelacion(apelacion) {
  detalle.value = { ...apelacion, esApelacion: true, sancion: sancionMap.value.get(apelacion.sancion_id) }
  modalDetalle.value = true
}

function abrirApelacion(sancion) {
  sancionAApelar.value = sancion
  fundamento.value = ''
  errorApelacion.value = null
  modalApelacion.value = true
}

async function enviarApelacion() {
  errorApelacion.value = null
  if (!fundamento.value.trim()) {
    errorApelacion.value = 'Escribe el fundamento de tu apelación'
    return
  }
  enviando.value = true
  try {
    await crearApelacion({
      sancionId: sancionAApelar.value.id,
      productorId: productor.value.id,
      fundamento: fundamento.value,
    })
    modalApelacion.value = false
    ui.success('Apelación enviada', 'El administrador revisará tu caso')
    await cargar()
  } catch (e) {
    errorApelacion.value = e?.message ?? 'No se pudo enviar la apelación'
  } finally {
    enviando.value = false
  }
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Sanciones y Apelaciones</h1>
        <p class="page-head__subtitle">
          {{ sanciones.length }} {{ sanciones.length === 1 ? 'sanción' : 'sanciones' }} ·
          {{ vigentes.length }} {{ vigentes.length === 1 ? 'vigente' : 'vigentes' }} ·
          {{ apelaciones.length }} {{ apelaciones.length === 1 ? 'apelación' : 'apelaciones' }}.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="cargando" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar tus sanciones">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtAlert v-if="vigentes.length" tone="warning" title="Tienes sanciones vigentes">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>
          Mientras una sanción esté {{ LABELS.sancion.activa.toLowerCase() }} o
          {{ LABELS.sancion.apelada.toLowerCase() }}, tu tienda puede quedar fuera del catálogo. Puedes
          apelar cada sanción una vez.
        </span>
      </p>
    </CtAlert>

    <CtSpinner v-if="cargando" label="Cargando tus sanciones" />

    <template v-else>
      <CtCard title="Mis sanciones" subtitle="Aplicadas por el administrador de la plataforma">
        <CtEmptyState
          v-if="!sanciones.length"
          compact
          icon="shieldCheck"
          title="Sin sanciones registradas"
          message="Tu cuenta no tiene sanciones. Cuando el administrador aplique una, aparecerá aquí y te avisaremos al iniciar sesión."
        />

        <CtTable
          v-else
          :columns="columnsSanciones"
          :rows="sanciones"
          min-width="1000px"
          row-key="id"
        >
          <template #cell-inicio_en="{ row }">{{ formatDate(row.inicio_en) }}</template>
          <template #cell-tipo="{ row }">
            {{ LABELS.tipoSancion[row.tipo] ?? row.tipo }}
          </template>
          <template #cell-accion="{ row }">
            {{ LABELS.accionSancion[row.accion] ?? row.accion }}
          </template>
          <template #cell-motivo="{ row }">
            <span class="text-sm clamp-2">{{ row.motivo }}</span>
          </template>
          <template #cell-duracion_dias="{ row }">
            {{ row.duracion_dias ? `${row.duracion_dias} días` : '—' }}
          </template>
          <template #cell-fin_en="{ row }">
            {{ row.fin_en ? formatDate(row.fin_en) : 'Sin término' }}
          </template>
          <template #cell-estado="{ row }">
            <StatusBadge type="sancion" :value="row.estado" size="sm" />
          </template>
          <template #cell-acciones="{ row }">
            <div class="acciones">
              <CtButton size="sm" variant="ghost" @click="verDetalle(row)">Detalle</CtButton>
              <CtButton
                v-if="puedeApelar(row)"
                size="sm"
                variant="outline"
                @click="abrirApelacion(row)"
              >
                Apelar
              </CtButton>
            </div>
          </template>
        </CtTable>
      </CtCard>

      <CtCard title="Mis apelaciones" subtitle="Seguimiento de las apelaciones presentadas">
        <CtEmptyState
          v-if="!apelaciones.length"
          compact
          icon="doc"
          title="Sin apelaciones"
          message="Puedes apelar una sanción vigente desde la tabla de arriba."
        />

        <CtTable
          v-else
          :columns="columnsApelaciones"
          :rows="filasApelaciones()"
          min-width="920px"
          row-key="id"
        >
          <template #cell-creado_en="{ row }">{{ formatDate(row.creado_en) }}</template>
          <template #cell-sancion="{ row }">
            <span v-if="row.sancion" class="text-sm">
              {{ LABELS.tipoSancion[row.sancion.tipo] ?? row.sancion.tipo }} ·
              {{ formatDate(row.sancion.inicio_en) }}
            </span>
            <span v-else class="text-sm text-muted">—</span>
          </template>
          <template #cell-fundamento="{ row }">
            <span class="text-sm clamp-2">{{ row.fundamento }}</span>
          </template>
          <template #cell-estado="{ row }">
            <StatusBadge type="apelacion" :value="row.estado" size="sm" />
          </template>
          <template #cell-acciones="{ row }">
            <CtButton size="sm" variant="ghost" @click="verDetalleApelacion(row)">Detalle</CtButton>
          </template>
        </CtTable>
      </CtCard>
    </template>

    <!-- ============ Detalle (sanción o apelación) ============ -->
    <CtModal
      v-model="modalDetalle"
      :title="detalle?.esApelacion ? 'Detalle de mi apelación' : 'Detalle de mi sanción'"
      size="md"
    >
      <div v-if="detalle" class="stack">
        <template v-if="!detalle.esApelacion">
          <dl class="datos">
            <div class="dato">
              <dt class="dato__label">Tipo</dt>
              <dd class="dato__valor">{{ LABELS.tipoSancion[detalle.tipo] ?? detalle.tipo }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Acción</dt>
              <dd class="dato__valor">{{ LABELS.accionSancion[detalle.accion] ?? detalle.accion }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Estado</dt>
              <dd class="dato__valor"><StatusBadge type="sancion" :value="detalle.estado" size="sm" /></dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Motivo</dt>
              <dd class="dato__valor">{{ detalle.motivo }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Inicio</dt>
              <dd class="dato__valor">{{ formatDateTime(detalle.inicio_en) }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Duración</dt>
              <dd class="dato__valor">
                {{ detalle.duracion_dias ? `${detalle.duracion_dias} días` : 'Sin plazo definido' }}
              </dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Término</dt>
              <dd class="dato__valor">
                {{ detalle.fin_en ? formatDateTime(detalle.fin_en) : 'Sin término' }}
              </dd>
            </div>
            <div v-if="detalle.numero_amonestacion" class="dato">
              <dt class="dato__label">N.º de amonestación</dt>
              <dd class="dato__valor">{{ detalle.numero_amonestacion }}</dd>
            </div>
          </dl>
        </template>

        <template v-else>
          <dl class="datos">
            <div class="dato">
              <dt class="dato__label">Estado</dt>
              <dd class="dato__valor">
                <StatusBadge type="apelacion" :value="detalle.estado" size="sm" />
              </dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Presentada</dt>
              <dd class="dato__valor">{{ formatDateTime(detalle.creado_en) }}</dd>
            </div>
            <div v-if="detalle.sancion" class="dato">
              <dt class="dato__label">Sanción apelada</dt>
              <dd class="dato__valor">
                {{ LABELS.tipoSancion[detalle.sancion.tipo] ?? detalle.sancion.tipo }} ·
                {{ formatDate(detalle.sancion.inicio_en) }}
              </dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Fundamento</dt>
              <dd class="dato__valor">{{ detalle.fundamento }}</dd>
            </div>
            <div v-if="detalle.resolucion" class="dato">
              <dt class="dato__label">Resolución del administrador</dt>
              <dd class="dato__valor">{{ detalle.resolucion }}</dd>
            </div>
            <div v-if="detalle.resuelto_en" class="dato">
              <dt class="dato__label">Resuelta</dt>
              <dd class="dato__valor">{{ formatDateTime(detalle.resuelto_en) }}</dd>
            </div>
          </dl>
          <CtBadge v-if="detalle.estado === ESTADO_APELACION.PENDIENTE" tone="warning" size="sm">
            Pendiente de revisión
          </CtBadge>
        </template>
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="modalDetalle = false">Cerrar</CtButton>
        <CtButton
          v-if="detalle && !detalle.esApelacion && puedeApelar(detalle)"
          @click="modalDetalle = false; abrirApelacion(detalle)"
        >
          Apelar esta sanción
        </CtButton>
      </template>
    </CtModal>

    <!-- ============ Crear apelación (r56) ============ -->
    <CtModal
      v-model="modalApelacion"
      title="Apelar la sanción"
      subtitle="Explica por qué consideras que la sanción no corresponde"
      size="md"
    >
      <div class="stack">
        <CtAlert v-if="errorApelacion" tone="danger">{{ errorApelacion }}</CtAlert>

        <dl v-if="sancionAApelar" class="datos">
          <div class="dato">
            <dt class="dato__label">Sanción</dt>
            <dd class="dato__valor">
              {{ LABELS.tipoSancion[sancionAApelar.tipo] ?? sancionAApelar.tipo }} ·
              {{ formatDate(sancionAApelar.inicio_en) }}
            </dd>
          </div>
          <div class="dato">
            <dt class="dato__label">Motivo</dt>
            <dd class="dato__valor">{{ sancionAApelar.motivo }}</dd>
          </div>
        </dl>

        <CtTextarea
          v-model="fundamento"
          label="Fundamento de la apelación"
          placeholder="Explica con detalle por qué la sanción no corresponde o qué antecedentes tienes"
          :rows="6"
          :maxlength="3000"
          show-count
          required
        />

        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              Sólo puedes tener una apelación pendiente por sanción. Mientras se resuelve, la sanción
              queda en estado «{{ LABELS.sancion.apelada }}» y el administrador decide si la cancela o la
              mantiene.
            </span>
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="enviando" @click="modalApelacion = false">
          Cancelar
        </CtButton>
        <CtButton :loading="enviando" @click="enviarApelacion">Enviar apelación</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  justify-content: flex-end;
}

.clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}
</style>
