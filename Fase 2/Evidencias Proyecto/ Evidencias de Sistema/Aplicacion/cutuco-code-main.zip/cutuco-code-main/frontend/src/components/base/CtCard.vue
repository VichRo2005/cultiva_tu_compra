<script setup>
/** CuTuCo — Tarjeta base con encabezado, contenido y acciones opcionales. */
defineProps({
  title: { type: String, default: null },
  subtitle: { type: String, default: null },
  padding: { type: String, default: 'md' }, // none | sm | md | lg
  hover: { type: Boolean, default: false },
  as: { type: String, default: 'section' },
  flat: { type: Boolean, default: false },
  accent: { type: String, default: null },
})
</script>

<template>
  <component :is="as" class="ct-card" :class="[`ct-card--pad-${padding}`, { 'ct-card--hover': hover, 'ct-card--flat': flat }]">
    <span v-if="accent" class="ct-card__accent" :style="{ background: accent }" aria-hidden="true" />
    <header v-if="title || $slots.header || $slots.actions" class="ct-card__header">
      <div class="ct-card__heading">
        <slot name="header">
          <h3 v-if="title" class="ct-card__title">{{ title }}</h3>
          <p v-if="subtitle" class="ct-card__subtitle">{{ subtitle }}</p>
        </slot>
      </div>
      <div v-if="$slots.actions" class="ct-card__actions">
        <slot name="actions" />
      </div>
    </header>
    <div class="ct-card__body">
      <slot />
    </div>
    <footer v-if="$slots.footer" class="ct-card__footer">
      <slot name="footer" />
    </footer>
  </component>
</template>

<style scoped>
.ct-card {
  position: relative;
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-xs);
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.ct-card--flat {
  box-shadow: none;
  background: var(--ct-surface-alt);
}

.ct-card--hover {
  transition:
    box-shadow var(--ct-transition),
    transform var(--ct-transition),
    border-color var(--ct-transition);
}

.ct-card--hover:hover {
  box-shadow: var(--ct-shadow-md);
  transform: translateY(-2px);
  border-color: var(--ct-border-strong);
}

.ct-card__accent {
  position: absolute;
  inset: 0 auto 0 0;
  width: 4px;
  border-radius: var(--ct-radius-lg) 0 0 var(--ct-radius-lg);
}

.ct-card--pad-none .ct-card__body {
  padding: 0;
}

.ct-card--pad-sm .ct-card__body {
  padding: var(--ct-space-4);
}

.ct-card--pad-md .ct-card__body {
  padding: var(--ct-space-6);
}

.ct-card--pad-lg .ct-card__body {
  padding: var(--ct-space-8);
}

.ct-card__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
  padding: var(--ct-space-5) var(--ct-space-6) 0;
}

.ct-card--pad-none .ct-card__header {
  padding: var(--ct-space-5) var(--ct-space-5) 0;
}

.ct-card__title {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.ct-card__subtitle {
  margin-top: var(--ct-space-1);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.ct-card__actions {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-shrink: 0;
}

.ct-card__footer {
  padding: var(--ct-space-4) var(--ct-space-6);
  border-top: 1px solid var(--ct-border);
  background: var(--ct-surface-alt);
  border-radius: 0 0 var(--ct-radius-lg) var(--ct-radius-lg);
}

.ct-card--pad-none .ct-card__footer {
  padding: var(--ct-space-4);
}
</style>
