import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtPagination from '@/components/base/CtPagination.vue'

const servicios = vi.hoisted(() => ({
  listarUsuarios: vi.fn(),
  obtenerDetalle: vi.fn(),
  toggleActivo: vi.fn(),
  eliminar: vi.fn(),
}))
vi.mock('@/services/adminUsuarios.js', () => servicios)
vi.mock('@/stores/auth.js', () => ({ useAuthStore: () => ({ user: { id: 'admin-actual' } }) }))
vi.mock('@/stores/ui.js', () => ({ useUiStore: () => ({ success: vi.fn(), error: vi.fn() }) }))
import AdminUsersView from '@/views/admin/AdminUsersView.vue'

const usuario = {
  id: 'cliente',
  nombre: 'Ana',
  apellido: 'Pérez',
  nombreCompleto: 'Ana Pérez',
  rol: 'cliente',
  activo: true,
  protegido: false,
  eliminado: false,
  telefono: '+56911112222',
}
let wrapper
function montar() {
  wrapper = mount(AdminUsersView, {
    global: { stubs: { 'router-link': { template: '<a><slot /></a>' } } },
  })
  return wrapper
}
async function detalle() {
  montar()
  await flushPromises()
  await wrapper.find('[aria-label="Ver detalle de Ana Pérez"]').trigger('click')
  await flushPromises()
}
beforeEach(() => {
  vi.resetAllMocks()
  servicios.listarUsuarios.mockResolvedValue({ items: [usuario], total: 25, page: 1, pageSize: 12 })
  servicios.obtenerDetalle.mockResolvedValue({ ...usuario, productor: null })
})
afterEach(() => {
  wrapper?.unmount()
  document.body.innerHTML = ''
  vi.useRealTimers()
})

describe('admin-usuarios · vista', () => {
  it('envía paginación y filtros al service', async () => {
    montar()
    await flushPromises()
    wrapper.findComponent(CtPagination).vm.$emit('update:page', 2)
    await flushPromises()
    expect(servicios.listarUsuarios).toHaveBeenLastCalledWith(expect.objectContaining({ page: 2 }))
    wrapper.findAllComponents(CtSelect)[0].vm.$emit('update:modelValue', 'admin')
    await flushPromises()
    expect(servicios.listarUsuarios).toHaveBeenLastCalledWith(
      expect.objectContaining({ rol: 'admin', page: 1 }),
    )
    wrapper.findAllComponents(CtSelect)[1].vm.$emit('update:modelValue', 'false')
    await flushPromises()
    expect(servicios.listarUsuarios).toHaveBeenLastCalledWith(
      expect.objectContaining({ activo: false }),
    )
  })

  it('absorbe cambios de filtros durante una carga y descarta la respuesta vieja', async () => {
    let resolver
    servicios.listarUsuarios.mockReturnValueOnce(
      new Promise((resolve) => {
        resolver = resolve
      }),
    )
    servicios.listarUsuarios.mockResolvedValueOnce({
      items: [{ ...usuario, nombreCompleto: 'Resultado nuevo', rol: 'admin' }],
      total: 1,
    })
    montar()
    await wrapper.findAllComponents(CtSelect)[0].vm.$emit('update:modelValue', 'admin')
    resolver({ items: [usuario], total: 25 })
    await flushPromises()
    expect(wrapper.text()).toContain('Resultado nuevo')
    expect(wrapper.text()).not.toContain('Ana Pérez')
    expect(servicios.listarUsuarios).toHaveBeenCalledTimes(2)
  })

  it('aplica debounce a la búsqueda', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] })
    montar()
    await flushPromises()
    await wrapper.find('input').setValue('Ana')
    await vi.advanceTimersByTimeAsync(349)
    expect(servicios.listarUsuarios).toHaveBeenCalledTimes(1)
    await vi.advanceTimersByTimeAsync(1)
    await flushPromises()
    expect(servicios.listarUsuarios).toHaveBeenLastCalledWith(
      expect.objectContaining({ texto: 'Ana', page: 1 }),
    )
  })

  it('no cambia estado sin confirmar y conserva el error del service en el diálogo', async () => {
    servicios.toggleActivo.mockRejectedValue(new Error('No tienes permisos'))
    montar()
    await flushPromises()
    await wrapper.find('[aria-label="Desactivar a Ana Pérez"]').trigger('click')
    expect(servicios.toggleActivo).not.toHaveBeenCalled()
    wrapper.findComponent(CtConfirmDialog).vm.$emit('confirm')
    await flushPromises()
    expect(servicios.toggleActivo).toHaveBeenCalledExactlyOnceWith(usuario.id, true)
    expect(wrapper.findComponent(CtConfirmDialog).props('modelValue')).toBe(true)
    expect(document.body.textContent).toContain('No tienes permisos')
  })

  it('deshabilita mutaciones de protegidos y de la propia cuenta en la tabla', async () => {
    servicios.listarUsuarios.mockResolvedValue({
      items: [
        { ...usuario, id: 'protegido', protegido: true },
        { ...usuario, id: 'admin-actual', nombreCompleto: 'Administrador actual' },
      ],
      total: 2,
    })
    montar()
    await flushPromises()
    expect(
      wrapper.find('[aria-label="Desactivar a Ana Pérez"]').attributes('disabled'),
    ).toBeDefined()
    expect(
      wrapper.find('[aria-label="Desactivar a Administrador actual"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('retira el cambio de rol del detalle y solicita confirmación para eliminar', async () => {
    await detalle()
    expect(document.body.textContent).not.toContain('Cambiar rol')
    expect(wrapper.findAllComponents(CtSelect)).toHaveLength(2)
    const boton = [...document.body.querySelectorAll('button')].find((b) =>
      b.textContent.includes('Eliminar permanentemente'),
    )
    expect(boton.disabled).toBe(false)
    boton.click()
    await flushPromises()
    expect(servicios.eliminar).not.toHaveBeenCalled()
    expect(wrapper.findComponent(CtConfirmDialog).props('message')).toContain(
      'no se puede revertir',
    )
  })

  it('confirma la baja permanente y deshabilita reactivación y nuevas bajas', async () => {
    const eliminado = {
      ...usuario,
      activo: false,
      eliminado: true,
      eliminado_en: '2026-10-09T15:00:00Z',
    }
    servicios.eliminar.mockResolvedValue(eliminado)
    servicios.listarUsuarios
      .mockResolvedValueOnce({ items: [usuario], total: 1 })
      .mockResolvedValue({ items: [eliminado], total: 1 })
    await detalle()
    const boton = [...document.body.querySelectorAll('button')].find(
      (b) => b.textContent.trim() === 'Eliminar permanentemente',
    )
    boton.click()
    await flushPromises()
    wrapper.findComponent(CtConfirmDialog).vm.$emit('confirm')
    await flushPromises()
    expect(servicios.eliminar).toHaveBeenCalledExactlyOnceWith(usuario.id)
    expect(wrapper.findComponent(CtConfirmDialog).props('modelValue')).toBe(false)
    expect(document.body.textContent).toContain('Cuenta eliminada permanentemente')
    expect(boton.disabled).toBe(true)
    expect(
      wrapper.find('[aria-label="Cuenta eliminada de Ana Pérez"]').attributes('disabled'),
    ).toBeDefined()
  })

  it('la eliminación fallida conserva el detalle y muestra el error sin marcar la cuenta', async () => {
    servicios.eliminar.mockRejectedValue(new Error('La cuenta cambió'))
    await detalle()
    const boton = [...document.body.querySelectorAll('button')].find(
      (b) => b.textContent.trim() === 'Eliminar permanentemente',
    )
    boton.click()
    await flushPromises()
    wrapper.findComponent(CtConfirmDialog).vm.$emit('confirm')
    await flushPromises()
    expect(wrapper.findComponent(CtConfirmDialog).props('modelValue')).toBe(true)
    expect(document.body.textContent).toContain('La cuenta cambió')
    expect(document.body.textContent).not.toContain('Cuenta eliminada permanentemente')
  })

  it.each([
    ['vendedor', true],
    ['vendedor', false],
    ['admin', true],
    ['admin', false],
    ['cliente', true],
    ['cliente', false],
  ])('limita acciones en tabla y detalle de %s (activo: %s)', async (rol, activo) => {
    const perfil = {
      ...usuario,
      rol,
      activo,
      productor: rol === 'vendedor' ? { activo: true, nombre_comercial: 'Huerta' } : null,
    }
    servicios.listarUsuarios.mockResolvedValue({ items: [perfil], total: 1 })
    servicios.obtenerDetalle.mockResolvedValue(perfil)
    await detalle()
    const permitido = rol === 'cliente'
    const accion = activo ? 'Desactivar' : 'Reactivar'
    expect(wrapper.find(`[aria-label="${accion} a Ana Pérez"]`).element.disabled).toBe(!permitido)
    const botones = [...document.body.querySelectorAll('button')]
    const estado = botones.find((b) => b.textContent.trim() === `${accion} cuenta`)
    const eliminar = botones.find((b) => b.textContent.trim() === 'Eliminar permanentemente')
    expect(estado.disabled).toBe(!permitido)
    expect(eliminar.disabled).toBe(!permitido)
  })

  it.each(['vendedor', 'admin'])('no abre confirmaciones ni muta cuentas de %s', async (rol) => {
    servicios.obtenerDetalle.mockResolvedValue({ ...usuario, rol, productor: null })
    await detalle()
    const botones = [...document.body.querySelectorAll('button')]
    botones.find((b) => b.textContent.trim() === 'Desactivar cuenta').click()
    botones.find((b) => b.textContent.trim() === 'Eliminar permanentemente').click()
    await flushPromises()
    expect(wrapper.findComponent(CtConfirmDialog).props('modelValue')).toBe(false)
    expect(servicios.toggleActivo).not.toHaveBeenCalled()
    expect(servicios.eliminar).not.toHaveBeenCalled()
    expect(document.body.textContent).toContain('solo para clientes')
  })

  it('ofrece el acceso al módulo de Sanciones para vendedores', async () => {
    servicios.obtenerDetalle.mockResolvedValue({
      ...usuario,
      rol: 'vendedor',
      productor: { activo: true, nombre_comercial: 'Huerta' },
    })
    await detalle()
    const enlace = wrapper
      .findAllComponents({ name: 'CtButton' })
      .find((boton) => boton.props('href') === '/admin/sanciones')
    expect(enlace).toBeDefined()
    expect(enlace.text()).toBe('Ir a Sanciones')
    expect(enlace.element.tagName).toBe('A')
    expect(enlace.attributes('href')).toBe('/admin/sanciones')
    expect(document.body.textContent).toContain('Huerta')
    expect(document.body.textContent).toContain('Tienda activa')
  })
})
