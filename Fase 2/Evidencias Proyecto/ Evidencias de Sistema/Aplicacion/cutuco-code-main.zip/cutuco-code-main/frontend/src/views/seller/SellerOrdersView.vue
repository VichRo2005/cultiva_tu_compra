<script setup>
/**
 * CuTuCo — Pedidos recibidos por el productor (página 14 del diseño).
 *
 *   RF-003  el vendedor revisa los pedidos recibidos por su tienda
 *   RF-025  filtros por estado actual del pedido y del envío, acceso al detalle
 *
 * Sólo se muestran pedidos del productor autenticado: `listPedidos({ rol:
 * 'productor' })` filtra por `productor_id` del perfil en sesión y la RLS del
 * esquema lo refuerza.
 *
 * HAL-VEN-020: el estado se deriva una sola vez con `estadoActualPedido()`.
 * No se muestran dos badges (pedido + envío) que puedan contradecirse.
 * HAL-VEN-021: el filtro incluye «En tránsito» y «Entrega fallida», y se combina
 * con la búsqueda y las pestañas.
 *
 * NOTA DE MIGRACIÓN: las evidencias fotográficas salieron del alcance
 * (HAL-CLI-022). La entrega se respalda sólo con el código que el cliente
 * recibe y entrega al vendedor.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtDateRange from '@/components/base/CtDateRange.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_ENVIO, ESTADO_PEDIDO } from '@/lib/constants'
import { exportExcel } from '@/lib/csv'
import { formatCLP, formatDate, formatDateTime, formatNumber, pluralize } from '@/lib/format'
import {
  ESTADOS_TERMINALES,
  OPCIONES_ESTADO_ACTUAL,
  esEstadoTerminal,
  estadoActualPedido,
  etiquetaEstadoActual,
  motivoCancelacion,
  netoProductor,
  pedidoCoincideBusqueda,
  pedidoCoincideEstado,
} from '@/lib/orders'
import { useAsync, useDebounceFn } from '@/composables/useAsync'
import { useAuthStore } from '@/stores/auth'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import { listPedidos } from '@/services/orders'

const router = useRouter()
const ui = useUiStore()
const geo = useGeographyStore()
const auth = useAuthStore()

const PENDIENTES = 'pendientes'
const COMPLETADOS = 'completados'

/** Opciones del filtro por estado (HAL-VEN-021: incluye En tránsito). */
const FILTROS_ESTADO = [
  { value: '', label: 'Todos los estados' },
  ...OPCIONES_ESTADO_ACTUAL.map((opcion) => ({ ...opcion })),
]

const pestana = ref(PENDIENTES)
const texto = ref('')
const busqueda = ref('')
const estado = ref('')
const fechaDesde = ref('')
const fechaHasta = ref('')
const page = ref(1)
const pageSize = ref(6)

watch(pestana, () => {
  page.value = 1
})

const {
  data: respuesta,
  loading,
  error,
  run,
} = useAsync(() => listPedidos({ rol: 'productor', all: true }))

const buscar = useDebounceFn((valor) => {
  busqueda.value = valor
  page.value = 1
}, 350)

/** El filtro es local: así «En tránsito» combina con la búsqueda y la pestaña. */
function filtrarPorEstado() {
  page.value = 1
  if (estado.value) {
    pestana.value = ESTADOS_TERMINALES.includes(estado.value) ? COMPLETADOS : PENDIENTES
  }
}

function filtrarPorFecha() {
  page.value = 1
}

function quitarFiltroFecha() {
  fechaDesde.value = ''
  fechaHasta.value = ''
  filtrarPorFecha()
}

function limpiarFiltros() {
  texto.value = ''
  busqueda.value = ''
  estado.value = ''
  fechaDesde.value = ''
  fechaHasta.value = ''
  page.value = 1
}

onMounted(() => {
  geo.load()
})

const pedidos = computed(() => respuesta.value?.items ?? [])
const total = computed(() => respuesta.value?.total ?? 0)

const hoy = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(new Date())
const formatoFechaPedido = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' })

function fechaPedido(pedido) {
  const fecha = new Date(pedido.creado_en)
  return Number.isNaN(fecha.getTime()) ? '' : formatoFechaPedido.format(fecha)
}

function pedidoCoincideFecha(pedido) {
  const fecha = fechaPedido(pedido)
  return (
    Boolean(fecha) &&
    (!fechaDesde.value || fecha >= fechaDesde.value) &&
    (!fechaHasta.value || fecha <= fechaHasta.value)
  )
}

const esDeHoy = (pedido) =>
  new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(
    new Date(pedido.creado_en),
  ) === hoy

const indicadores = computed(() => {
  const items = pedidos.value
  const inicioMes = new Date()
  inicioMes.setDate(1)

  return {
    hoy: items.filter(esDeHoy),
    // «Pendientes» es todo lo que aún no termina: pagado, preparación, tránsito
    // o entrega fallida. Un pedido en tránsito no puede desaparecer de la tabla.
    pendientes: items.filter((p) => !esEstadoTerminal(p)),
    enRuta: items.filter(
      (p) => p.envio?.estado === ESTADO_ENVIO.EN_TRANSITO && p.estado !== ESTADO_PEDIDO.CANCELADO,
    ),
    ingresosMes: items
      .filter(
        (p) =>
          new Date(p.creado_en) >= inicioMes && estadoActualPedido(p) !== ESTADO_PEDIDO.CANCELADO,
      )
      .reduce((acc, p) => acc + netoProductor(p), 0),
  }
})

const tabItems = computed(() => [
  {
    value: PENDIENTES,
    label: 'Pendientes',
    count: indicadores.value.pendientes.length,
    tone: 'warning',
  },
  {
    value: COMPLETADOS,
    label: 'Completados',
    count: pedidos.value.filter(esEstadoTerminal).length,
    tone: 'success',
  },
])

const base = computed(() =>
  pestana.value === PENDIENTES
    ? indicadores.value.pendientes
    : pedidos.value.filter(esEstadoTerminal),
)

const filtrados = computed(() =>
  base.value.filter(
    (pedido) =>
      pedidoCoincideEstado(pedido, estado.value) &&
      pedidoCoincideFecha(pedido) &&
      pedidoCoincideBusqueda(pedido, busqueda.value, {
        comuna: geo.nombreComuna(pedido.comuna_entrega_id),
      }),
  ),
)

const hayFiltros = computed(() =>
  Boolean(estado.value || busqueda.value.trim() || fechaDesde.value || fechaHasta.value),
)

const visibles = computed(() =>
  filtrados.value.slice((page.value - 1) * pageSize.value, page.value * pageSize.value),
)

const columnas = [
  { key: 'codigo', label: 'ID Pedido', width: '160px' },
  { key: 'cliente', label: 'Cliente' },
  { key: 'estado', label: 'Estado', width: '170px' },
  { key: 'productos', label: 'Productos' },
  { key: 'entrega', label: 'Entrega', width: '200px' },
  { key: 'total', label: 'Total', align: 'right', width: '160px' },
]

function resumenProductos(pedido) {
  const detalles = pedido.detalles ?? []
  const unidades = detalles.reduce((acc, d) => acc + Number(d.cantidad ?? 0), 0)
  return `${detalles.length} ${pluralize(detalles.length, 'producto')} · ${formatNumber(unidades)} unidades`
}

function etiquetaEntrega(pedido) {
  const comuna = geo.nombreComuna(pedido.comuna_entrega_id)
  if (estadoActualPedido(pedido) === ESTADO_PEDIDO.CANCELADO) {
    const motivo = motivoCancelacion(pedido)
    return motivo ? `Cancelado: ${motivo}` : 'Cancelado antes del despacho'
  }
  if (pedido.envio?.estado === ESTADO_ENVIO.EN_TRANSITO) return `En ruta hacia ${comuna}`
  if (pedido.envio?.estado === ESTADO_ENVIO.ENTREGADO) return `Entregado en ${comuna}`
  if (pedido.envio?.estado === ESTADO_ENVIO.FALLIDO) return `Entrega fallida en ${comuna}`
  return `Preparar envío a ${comuna}`
}

function abrirPedido(pedido) {
  router.push(`/vendedor/pedidos/${pedido.id}`)
}

/* ------------------------------------------------------------------ */
/* Exportación                                                         */
/* ------------------------------------------------------------------ */

const columnasExport = [
  { key: 'codigo_pedido', label: 'Pedido' },
  { key: 'nombre_destinatario', label: 'Cliente' },
  {
    key: 'comuna_entrega_id',
    label: 'Comuna',
    get: (row) => geo.nombreComuna(row.comuna_entrega_id),
  },
  { key: 'creado_en', label: 'Fecha', get: (row) => formatDateTime(row.creado_en) },
  { key: 'total', label: 'Total', get: (row) => formatCLP(row.total) },
  {
    key: 'neto_productor',
    label: 'Neto estimado',
    get: (row) => formatCLP(netoProductor(row)),
  },
  {
    key: 'estado_actual',
    label: 'Estado',
    get: (row) => etiquetaEstadoActual(estadoActualPedido(row)),
  },
  {
    key: 'motivo_cancelacion',
    label: 'Motivo de cancelación',
    get: (row) => motivoCancelacion(row) ?? '',
  },
]

async function exportar() {
  const ok = await exportExcel(filtrados.value, 'pedidos-recibidos', columnasExport)
  if (ok) ui.success('Pedidos exportados', 'Se descargó el Excel de los pedidos de esta vista.')
  else ui.warning('Sin datos para exportar', 'No hay pedidos en la pestaña seleccionada.')
}

/* ------------------------------------------------------------------ */
/* Tarjetas de consejo (sin evidencia fotográfica: RF-007 vigente)     */
/* ------------------------------------------------------------------ */

const consejos = computed(() => {
  const cards = []

  const masAntiguo = [...indicadores.value.pendientes].sort(
    (a, b) => new Date(a.creado_en) - new Date(b.creado_en),
  )[0]

  cards.push({
    icon: 'dashboard',
    titulo: 'Consejo de eficiencia',
    texto: masAntiguo
      ? `El pedido más antiguo en espera es ${masAntiguo.codigo_pedido}, creado el ${formatDate(
          masAntiguo.creado_en,
        )}. Confirma la preparación, marca En Tránsito cuando salgas a entregar y pídele el código de verificación al cliente al llegar.`
      : 'No tienes pedidos pendientes de despacho. Revisa tu stock a mano para no perder ventas.',
    enlace: '/vendedor/productos',
    accion: 'Gestionar inventario',
  })

  const enRuta = indicadores.value.enRuta
  cards.push({
    icon: 'truck',
    titulo: 'Entregas en tránsito',
    texto: enRuta.length
      ? `${pluralize(enRuta.length, 'pedido')} en camino. Al llegar, el cliente te entrega el código de verificación: ingrésalo en el detalle del pedido para cerrar la entrega.`
      : 'No hay entregas en tránsito. Cuando marques un envío En Tránsito, el cliente recibirá el código de verificación en su seguimiento.',
    enlace: enRuta.length ? `/vendedor/pedidos/${enRuta[0].id}` : '/vendedor/pedidos',
    accion: enRuta.length ? 'Cerrar entrega' : 'Ver pedidos',
  })

  return cards
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Pedidos Recibidos</h1>
        <p class="page-head__subtitle">
          Gestiona el armado, el despacho y la entrega con código de verificación de cada pedido que
          te compran.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="!filtrados.length" @click="exportar">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar
        </CtButton>
        <CtButton variant="secondary" to="/vendedor/productos">
          <template #icon><CtIcon name="inventory" :size="16" /></template>
          Ver mi inventario
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar los pedidos">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
    </CtAlert>

    <CtAlert
      v-else-if="!loading && pedidos.length && !filtrados.length && hayFiltros"
      tone="info"
      title="Sin resultados con los filtros"
      compact
    >
      <p>No hay pedidos que coincidan con los filtros. Prueba con otros criterios.</p>
      <CtButton size="sm" variant="secondary" @click="limpiarFiltros">Limpiar filtros</CtButton>
    </CtAlert>

    <CtAlert v-else-if="!loading && !pedidos.length && auth.bloqueoVendedor" tone="warning" compact>
      <p>{{ auth.bloqueoVendedor }}</p>
    </CtAlert>

    <!-- ============ Indicadores ============ -->
    <div class="grid-kpi">
      <CtStatCard
        label="Total Hoy"
        :value="formatNumber(indicadores.hoy.length)"
        tone="primary"
        :hint="`${formatCLP(
          indicadores.hoy.reduce((acc, p) => acc + Number(p.total ?? 0), 0),
        )} en ventas de hoy`"
        calculation="La cifra principal cuenta los pedidos creados hoy. El monto indicado debajo suma el total de esos pedidos, incluidos IVA y despacho cuando corresponden."
      />
      <CtStatCard
        label="Pendientes"
        :value="formatNumber(indicadores.pendientes.length)"
        tone="warning"
        hint="Pedidos activos: pago, preparación, tránsito o entrega fallida"
      />
      <CtStatCard
        label="En Ruta"
        :value="formatNumber(indicadores.enRuta.length)"
        tone="info"
        hint="Despachados y pendientes de entrega"
      />
      <CtStatCard
        label="Ventas del Mes"
        :value="formatCLP(indicadores.ingresosMes)"
        tone="success"
        hint="Neto estimado de pedidos no cancelados"
        calculation="Suma el total de los pedidos no cancelados creados durante el mes y descuenta la comisión de plataforma. Es una estimación operativa, no un saldo disponible."
      />
    </div>

    <CtAlert tone="neutral" compact title="Pedidos manuales">
      <p>
        En CuTuCo los pedidos los crea el cliente desde el catálogo. El productor confirma la
        preparación, despacha y cierra la entrega, pero no registra ventas manuales: por eso no hay
        un botón de "pedido manual" en esta pantalla.
      </p>
    </CtAlert>

    <!-- ============ Filtros y tabla ============ -->
    <CtCard padding="sm">
      <div class="filtros">
        <CtTabs v-model="pestana" :tabs="tabItems" variant="pills" stretch />
        <div class="filtros__campos">
          <CtSearchInput
            v-model="texto"
            class="filtros__busqueda"
            placeholder="Buscar por código, cliente o comuna"
            @update:model-value="buscar"
            @search="buscar"
          />
          <CtSelect
            v-model="estado"
            :options="FILTROS_ESTADO"
            label="Filtrar por estado"
            @update:model-value="filtrarPorEstado"
          />
          <details class="filtros__fecha" :class="{ 'is-active': fechaDesde || fechaHasta }">
            <summary>
              <CtIcon name="calendar" :size="15" aria-hidden="true" />
              <span>Fecha del pedido</span>
              <span v-if="fechaDesde || fechaHasta" class="filtros__fecha-estado">Aplicado</span>
            </summary>
            <div class="filtros__fecha-contenido">
              <CtDateRange
                v-model:desde="fechaDesde"
                v-model:hasta="fechaHasta"
                label="Accesos rápidos"
                @change="filtrarPorFecha"
              />
              <CtButton
                v-if="fechaDesde || fechaHasta"
                size="sm"
                variant="ghost"
                @click="quitarFiltroFecha"
              >
                Quitar fecha
              </CtButton>
            </div>
          </details>
        </div>
      </div>
      <div v-if="hayFiltros" class="filtros__activos">
        <span class="text-xs text-muted">Filtros activos</span>
        <CtButton size="sm" variant="ghost" @click="limpiarFiltros">Limpiar filtros</CtButton>
      </div>
    </CtCard>

    <CtCard padding="none">
      <CtSpinner v-if="loading && !respuesta" label="Cargando pedidos" />

      <CtTable
        v-else
        :columns="columnas"
        :rows="visibles"
        row-key="id"
        clickable
        min-width="1020px"
        empty-icon="orders"
        :empty-title="
          hayFiltros
            ? 'Sin pedidos con estos filtros'
            : pestana === PENDIENTES
              ? 'Sin pedidos pendientes'
              : 'Sin pedidos completados'
        "
        empty-message="Cuando un cliente compre tus productos, el pedido aparecerá aquí."
        @row-click="abrirPedido"
      >
        <template #empty-action>
          <CtButton variant="secondary" to="/vendedor/productos">Revisar mi catálogo</CtButton>
        </template>

        <template #cell-codigo="{ row }">
          <router-link :to="`/vendedor/pedidos/${row.id}`" class="enlace">
            {{ row.codigo_pedido }}
          </router-link>
          <p class="text-xs text-muted">{{ formatDateTime(row.creado_en) }}</p>
        </template>

        <template #cell-cliente="{ row }">
          <div class="cliente">
            <span class="cliente__avatar" aria-hidden="true">
              {{ (row.nombre_destinatario ?? '?').charAt(0) }}
            </span>
            <div class="cliente__datos">
              <p class="font-semibold texto-largo">
                {{ row.nombre_destinatario ?? 'Cliente sin nombre' }}
              </p>
              <p class="text-xs text-muted texto-largo">
                {{ geo.nombreComuna(row.comuna_entrega_id) }},
                {{ geo.nombreRegion(row.region_entrega_id) }}
              </p>
            </div>
          </div>
        </template>

        <template #cell-estado="{ row }">
          <StatusBadge type="actual" :value="estadoActualPedido(row)" size="sm" />
        </template>

        <template #cell-productos="{ row }">
          <span class="text-sm">{{ resumenProductos(row) }}</span>
        </template>

        <template #cell-entrega="{ row }">
          <span class="text-sm text-soft texto-largo clamp-2" :title="etiquetaEntrega(row)">
            {{ etiquetaEntrega(row) }}
          </span>
        </template>

        <template #cell-total="{ row }">
          <span class="font-semibold">{{ formatCLP(row.total) }}</span>
          <p class="text-xs text-muted">Te corresponde {{ formatCLP(netoProductor(row)) }}</p>
        </template>
      </CtTable>

      <template #footer>
        <CtPagination
          v-model:page="page"
          v-model:page-size="pageSize"
          :total="filtrados.length"
          label="pedidos"
        />
      </template>
    </CtCard>

    <p class="text-xs text-muted">
      Mostrando {{ filtrados.length }} de {{ total }}
      {{ pluralize(total, 'pedido recibido', 'pedidos recibidos') }} en total.
    </p>

    <!-- ============ Consejos ============ -->
    <div class="grid">
      <div v-for="consejo in consejos" :key="consejo.titulo" class="col-6">
        <CtCard>
          <div class="consejo">
            <span class="consejo__icon" aria-hidden="true">
              <CtIcon :name="consejo.icon" :size="20" />
            </span>
            <div>
              <h3 class="consejo__titulo">{{ consejo.titulo }}</h3>
              <p class="text-sm text-soft">{{ consejo.texto }}</p>
            </div>
          </div>
          <template #footer>
            <CtButton size="sm" variant="secondary" :to="consejo.enlace">
              {{ consejo.accion }}
            </CtButton>
          </template>
        </CtCard>
      </div>
    </div>
  </div>
</template>

<style scoped>
.filtros {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.filtros__campos {
  display: grid;
  grid-template-columns: minmax(240px, 1fr) minmax(200px, 240px) auto;
  gap: var(--ct-space-3);
  align-items: end;
}

.filtros__busqueda {
  min-width: 0;
}

.filtros__fecha {
  min-width: 0;
}

.filtros__fecha summary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 38px;
  gap: var(--ct-space-2);
  padding: 0.45rem var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius);
  background: var(--ct-surface);
  color: var(--ct-text-soft);
  cursor: pointer;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  list-style: none;
  white-space: nowrap;
}

.filtros__fecha summary::-webkit-details-marker {
  display: none;
}

.filtros__fecha summary:hover {
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.filtros__fecha summary:focus-visible {
  outline: 2px solid var(--ct-primary);
  outline-offset: 2px;
}

.filtros__fecha.is-active summary {
  border-color: var(--ct-primary);
  color: var(--ct-primary-strong);
}

.filtros__fecha-estado {
  border-radius: var(--ct-radius-pill);
  background: var(--ct-primary-soft);
  padding: 1px var(--ct-space-2);
  color: var(--ct-primary-strong);
  font-size: var(--ct-fs-2xs);
}

.filtros__fecha[open] {
  grid-column: 1 / -1;
}

.filtros__fecha-contenido {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-3);
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
}

.filtros__activos {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-2);
}

@media (max-width: 900px) {
  .filtros__campos {
    grid-template-columns: minmax(0, 1fr);
  }

  .filtros__fecha,
  .filtros__fecha[open] {
    grid-column: auto;
  }

  .filtros__fecha summary {
    width: 100%;
  }

  .filtros__fecha-contenido {
    align-items: stretch;
    flex-direction: column;
  }

  .filtros__activos {
    justify-content: flex-start;
  }
}

.texto-largo {
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.enlace {
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-primary-strong);
}

.cliente {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  min-width: 0;
}

.cliente__datos {
  min-width: 0;
}

.cliente__avatar {
  width: 36px;
  height: 36px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  display: grid;
  place-items: center;
  font-weight: var(--ct-fw-semibold);
  flex-shrink: 0;
}

.consejo {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  gap: var(--ct-space-4);
  align-items: start;
}

.consejo__icon {
  width: 44px;
  height: 44px;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.consejo__titulo {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  margin-bottom: var(--ct-space-2);
}
</style>
