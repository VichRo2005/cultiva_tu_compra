<script setup>
/**
 * CuTuCo — Contenedor temporal de la galería de vistas (TEMPORAL).
 *
 * ⚠️ Se elimina junto con la carpeta `src/dev/` antes del release.
 *
 * Punto de montaje único: `layouts/AppShell.vue` y `layouts/AuthLayout.vue`
 * incluyen `<DevOverlay />` sobre el contenido. Ese es todo el cableado.
 */
import { ref } from 'vue'
import DevBanner from '@/dev/DevBanner.vue'
import DevGalleryNav from '@/dev/DevGalleryNav.vue'
import { DEV_GALLERY_ENABLED } from '@/dev/devGallery'

const abierto = ref(false)
</script>

<template>
  <template v-if="DEV_GALLERY_ENABLED">
    <DevBanner @open-gallery="abierto = true" />
    <DevGalleryNav v-model="abierto" />
  </template>
</template>