import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

const configuracionCobro = vi.hoisted(() => ({
  actualizarIvaHabilitado: vi.fn(),
  obtenerConfiguracionCobro: vi.fn(),
}))

const pagos = vi.hoisted(() => ({
  listPagos: vi.fn(),
}))

vi.mock('@/services/configuracionCobro', async (importOriginal) => ({
  ...(await importOriginal()),
  ...configuracionCobro,
}))

vi.mock('@/services/payments', async (importOriginal) => ({
  ...(await importOriginal()),
  ...pagos,
}))

import AdminPaymentsView from '@/views/admin/AdminPaymentsView.vue'

let wrapper

beforeEach(() => {
  setActivePinia(createPinia())
  pagos.listPagos.mockResolvedValue([])
  configuracionCobro.obtenerConfiguracionCobro.mockResolvedValue({
    ivaHabilitado: true,
    tasaIva: 0.19,
  })
})

afterEach(() => {
  wrapper?.unmount()
  vi.resetAllMocks()
})

describe('AdminPaymentsView · configuración de IVA', () => {
  it('mantiene el ajuste plegado y permite retirar el IVA de los nuevos pagos tras confirmarlo', async () => {
    wrapper = mount(AdminPaymentsView, {
      global: {
        plugins: [createPinia()],
        stubs: {
          CtConfirmDialog: {
            props: ['modelValue'],
            emits: ['confirm', 'update:modelValue'],
            template: `
              <div v-if="modelValue">
                <button type="button" class="cancelar-cambio-iva" @click="$emit('update:modelValue', false)">Cancelar</button>
                <button type="button" class="confirmar-cambio-iva" @click="$emit('confirm')">Confirmar</button>
              </div>
            `,
          },
          CtDateRange: true,
          CtPagination: true,
          CtStatCard: true,
          CtTable: true,
        },
      },
    })
    await flushPromises()

    expect(wrapper.text()).toContain('Aplicado · 19 %')
    expect(wrapper.findAll('.pagos__ajuste-iva input')).toHaveLength(0)

    const editar = wrapper.findAll('button').find((boton) => boton.text() === 'Configurar IVA')
    expect(editar.attributes('aria-expanded')).toBe('false')
    await editar.trigger('click')
    await flushPromises()

    const interruptor = wrapper.find('.pagos__ajuste-iva input[type="checkbox"]')
    expect(interruptor.element.checked).toBe(true)

    configuracionCobro.actualizarIvaHabilitado.mockResolvedValue({
      ivaHabilitado: false,
      tasaIva: 0.19,
    })
    await interruptor.setValue(false)
    await flushPromises()
    expect(wrapper.find('.pagos__ajuste-iva input[type="checkbox"]').element.checked).toBe(true)
    await wrapper.find('.cancelar-cambio-iva').trigger('click')
    await flushPromises()
    expect(configuracionCobro.actualizarIvaHabilitado).not.toHaveBeenCalled()
    expect(wrapper.find('.pagos__ajuste-iva input[type="checkbox"]').element.checked).toBe(true)

    await wrapper.find('.pagos__ajuste-iva input[type="checkbox"]').setValue(false)
    await flushPromises()
    await wrapper.find('.confirmar-cambio-iva').trigger('click')
    await flushPromises()

    expect(configuracionCobro.actualizarIvaHabilitado).toHaveBeenCalledWith(false)
    expect(wrapper.text()).toContain('Sin IVA')
  })

  it('permite volver a aplicar el IVA cuando está desactivado', async () => {
    configuracionCobro.obtenerConfiguracionCobro.mockResolvedValue({
      ivaHabilitado: false,
      tasaIva: 0.19,
    })
    wrapper = mount(AdminPaymentsView, {
      global: {
        plugins: [createPinia()],
        stubs: {
          CtConfirmDialog: {
            props: ['modelValue'],
            emits: ['confirm', 'update:modelValue'],
            template: `
              <div v-if="modelValue">
                <button type="button" class="cancelar-cambio-iva" @click="$emit('update:modelValue', false)">Cancelar</button>
                <button type="button" class="confirmar-cambio-iva" @click="$emit('confirm')">Confirmar</button>
              </div>
            `,
          },
          CtDateRange: true,
          CtPagination: true,
          CtStatCard: true,
          CtTable: true,
        },
      },
    })
    await flushPromises()

    expect(wrapper.text()).toContain('Sin IVA')
    await wrapper.findAll('button').find((boton) => boton.text() === 'Configurar IVA').trigger('click')
    await flushPromises()

    configuracionCobro.actualizarIvaHabilitado.mockResolvedValue({
      ivaHabilitado: true,
      tasaIva: 0.19,
    })
    await wrapper.find('.pagos__ajuste-iva input[type="checkbox"]').setValue(true)
    await flushPromises()
    await wrapper.find('.confirmar-cambio-iva').trigger('click')
    await flushPromises()

    expect(configuracionCobro.actualizarIvaHabilitado).toHaveBeenCalledWith(true)
    expect(wrapper.text()).toContain('Aplicado · 19 %')
  })
})
