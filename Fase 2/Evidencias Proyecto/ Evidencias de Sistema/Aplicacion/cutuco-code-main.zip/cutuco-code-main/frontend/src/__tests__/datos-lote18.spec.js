/**
 * CuTuCo — Lote 18 (Datos y privacidad), lado frontend.
 *
 * CK-0294: combobox con catálogo vacío muestra placeholder deshabilitado y no
 *         emite ningún valor (no se inventa FK).
 * CK-0296: los errores de BD se explican sin filtrar SQL, constraints, SQLSTATE
 *          ni secretos (mensajeSeguro + servicios que lo usan).
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'
import { mensajeSeguro } from '@/services/errores'

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0294 · lookup vacío', () => {
  it('CtSelect sin opciones sólo muestra el placeholder deshabilitado con valor null', () => {
    const c = src('components/base/CtSelect.vue')
    expect(c).toContain("<option :value=\"null\" disabled>{{ placeholder }}</option>")
    expect(c).toContain("options: { type: Array, default: () => [] }")
    // los formularios exigen selección antes de enviar (sin FK inventada)
    const form = src('views/seller/SellerProductFormView.vue')
    expect(form).toMatch(/categoria/i)
    expect(form).toMatch(/requerid|obligatorio|Selecciona/i)
  })
})

describe('CtSelect · opción seleccionada', () => {
  it('mantiene un hover y foco visibles en amarillo semitransparente', () => {
    const select = src('components/base/CtSelect.vue')
    const tokens = src('styles/tokens.css')
    expect(tokens).toContain('--ct-accent-tint-50: rgb(255 212 71 / 50%)')
    expect(select).toContain('.ct-select__option.is-selected:hover:not(:disabled)')
    expect(select).toContain('.ct-select__option.is-selected:focus-visible')
    expect(select).toContain('background: var(--ct-accent-tint-50)')
    expect(select).toContain('color: var(--ct-accent-ink)')
  })
})

describe('Mensajes y estados con contraste', () => {
  it('no deja texto blanco sobre los fondos verdes claros de compra', () => {
    const carrito = src('views/client/CartView.vue')
    const checkout = src('views/client/CheckoutView.vue')

    expect(carrito).toContain('.cobertura__mensaje')
    expect(carrito).toContain('background: var(--ct-success)')
    expect(carrito).toContain('background: var(--ct-primary-fill)')
    expect(carrito).toContain('color: var(--ct-text-invert)')
    expect(checkout).toContain('.resumen__nota')
    expect(checkout).toContain('background: var(--ct-primary-fill)')
    expect(checkout).toContain('color: var(--ct-text-invert)')
  })

  it('mantiene los controles activos legibles y amarillos al pasar el cursor', () => {
    for (const archivo of ['views/public/CatalogView.vue', 'views/admin/AdminGeographyView.vue']) {
      const vista = src(archivo)
      expect(vista).toContain('color: var(--ct-primary-strong)')
      expect(vista).toContain('background: var(--ct-accent-tint-50)')
      expect(vista).toContain('color: var(--ct-accent-ink)')
    }
  })
})

describe('CK-0296 · errores de BD sin filtrar SQL ni secretos', () => {
  it('mensajeSeguro traduce violaciones conocidas a mensajes legibles', () => {
    expect(mensajeSeguro({ message: 'duplicate key value violates unique constraint "uq_perfil_email"' }))
      .toBe('Ya existe un registro con esos datos.')
    expect(mensajeSeguro({ message: 'insert or update on table "productos" violates foreign key constraint "productos_categoria_id_fkey"' }))
      .toBe('La referencia indicada no existe.')
    expect(mensajeSeguro({ message: 'new row for relation "productos" violates check constraint "ck_producto_precio_no_negativo"' }))
      .toBe('Los datos no cumplen las reglas de validación.')
    expect(mensajeSeguro({ message: 'new row violates row-level security policy for table "datos_bancarios"', code: '42501' }))
      .toBe('No tienes permisos para realizar esta operación.')
    expect(mensajeSeguro({ message: 'invalid input value for enum unidad_medida_producto: "tonelada"' }))
      .toBe('Algún campo tiene un valor no permitido.')
    expect(mensajeSeguro({ message: "Cannot read properties of null (reading 'id')" }))
      .toBe('Tuvimos un problema al procesar tu solicitud. Inténtalo nuevamente.')
  })

  it('mensajeSeguro corta DETAIL/CONTEXT/SQLSTATE y nunca filtra nombres internos', () => {
    const feo = 'ERROR: update on table "datos_bancarios" violates policy\nDETAIL: secret-token=abc123\nSQLSTATE: 42501'
    const m = mensajeSeguro({ message: feo, code: '42501' })
    expect(m).not.toMatch(/DETAIL|SQLSTATE|secret|datos_bancarios|constraint|relation/i)
    const m2 = mensajeSeguro({ message: 'algo muy técnico e inexplicable ' + 'x'.repeat(300) })
    expect(m2).toMatch(/No se pudo completar la operación/)
  })

  it('los servicios ya no propagan error.message crudo', () => {
    for (const s of ['services/admin.js', 'services/payments.js', 'services/catalog.js', 'services/session.js',
                     'services/registro.js', 'services/reclamos.js', 'services/orders.js', 'services/seller.js',
                     'services/geography.js', 'services/adminCatalog.js', 'stores/auth.js']) {
      const t = src(s)
      const crudos = t.split('\n').filter((l) => {
        const activa = l.trim()
        if (activa.startsWith('//')) return false
        return /throw new Error\(\w*[Ee]rror\.message/.test(activa) || activa.includes('${e.message}')
      })
      expect(crudos, `${s} tiene throws crudos: ${crudos.join(' | ')}`).toHaveLength(0)
      expect(t).toContain('mensajeSeguro')
    }
  })
})
