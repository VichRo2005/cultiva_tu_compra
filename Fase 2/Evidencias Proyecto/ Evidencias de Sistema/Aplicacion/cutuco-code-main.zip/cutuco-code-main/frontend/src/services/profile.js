/** Operaciones de foto para el perfil personal del cliente. */
import { STORAGE_BUCKETS } from '@/lib/constants'
import { getClient } from '@/lib/supabase'
import { mensajeSeguro } from '@/services/errores'
import { unwrap } from '@/services/session'

const EXTENSIONES_IMAGEN = Object.freeze({
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
})
const TAMANO_MAXIMO_IMAGEN = 5 * 1024 * 1024

function validarFoto(file) {
  if (!file) throw new Error('No se recibió ningún archivo')
  const extension = EXTENSIONES_IMAGEN[file.type]
  if (!extension) throw new Error('Selecciona una imagen JPG, PNG o WebP válida')
  if (file.size > TAMANO_MAXIMO_IMAGEN) throw new Error('La imagen no debe superar 5 MB')
  return extension
}

/**
 * Sube una foto nueva a la carpeta del usuario y después actualiza su perfil.
 * Usar una ruta por versión evita que el navegador mantenga una imagen anterior
 * en caché mientras se publica el reemplazo.
 */
export async function subirFotoPerfilCliente({ perfilId, file, rutaActual = null }) {
  if (!perfilId) throw new Error('No se encontró el perfil de la cuenta')
  const extension = validarFoto(file)
  const client = getClient()
  const version =
    globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`
  const ruta = `${perfilId}/avatar-${version}.${extension}`
  const { error: upError } = await client.storage
    .from(STORAGE_BUCKETS.avataresCliente)
    .upload(ruta, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type,
    })
  if (upError) throw new Error(mensajeSeguro(upError))

  let perfil
  try {
    perfil = unwrap(
      await client
        .from('perfiles')
        .update({ foto_perfil_storage_path: ruta })
        .eq('id', perfilId)
        .select()
        .single(),
      'No se pudo guardar la foto de perfil',
    )
  } catch (error) {
    // Si el perfil no se actualiza, no dejamos un archivo huérfano en Storage.
    await client.storage.from(STORAGE_BUCKETS.avataresCliente).remove([ruta])
    throw error
  }

  // La foto nueva ya está publicada: fallar al limpiar la anterior no la revierte.
  if (rutaActual && rutaActual !== ruta) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.avataresCliente)
      .remove([rutaActual])
    if (removeError) {
      console.warn('[subirFotoPerfilCliente] No se pudo limpiar la foto anterior', removeError)
    }
  }
  return perfil
}

/** Limpia la referencia del perfil antes de borrar el objeto de Storage. */
export async function quitarFotoPerfilCliente({ perfilId, rutaActual }) {
  if (!perfilId) throw new Error('No se encontró el perfil de la cuenta')
  const client = getClient()
  const perfil = unwrap(
    await client
      .from('perfiles')
      .update({ foto_perfil_storage_path: null })
      .eq('id', perfilId)
      .select()
      .single(),
    'No se pudo quitar la foto de perfil',
  )
  if (rutaActual) {
    const { error: removeError } = await client.storage
      .from(STORAGE_BUCKETS.avataresCliente)
      .remove([rutaActual])
    if (removeError) {
      console.warn('[quitarFotoPerfilCliente] No se pudo borrar la foto anterior', removeError)
    }
  }
  return perfil
}
