<script setup>
/** CuTuCo — Interruptor (switch). */
defineProps({
  modelValue: { type: Boolean, default: false },
  label: { type: String, default: null },
  description: { type: String, default: null },
  disabled: { type: Boolean, default: false },
  size: { type: String, default: 'md' },
})

const emit = defineEmits(['update:modelValue'])
</script>

<template>
  <label class="ct-toggle" :class="[`ct-toggle--${size}`, { 'is-disabled': disabled }]">
    <input
      type="checkbox"
      class="ct-toggle__input"
      :checked="modelValue"
      :disabled="disabled"
      @change="emit('update:modelValue', !modelValue)"
    />
    <span class="ct-toggle__track" aria-hidden="true">
      <span class="ct-toggle__thumb" />
    </span>
    <span v-if="label || description || $slots.default" class="ct-toggle__text">
      <span class="ct-toggle__label"><slot>{{ label }}</slot></span>
      <span v-if="description" class="ct-toggle__description">{{ description }}</span>
    </span>
  </label>
</template>

<style scoped>
.ct-toggle {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-3);
  cursor: pointer;
}

.ct-toggle.is-disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.ct-toggle__input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.ct-toggle__track {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 22px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-border-strong);
  transition: background-color var(--ct-transition);
  flex-shrink: 0;
}

.ct-toggle--sm .ct-toggle__track {
  width: 34px;
  height: 19px;
}

.ct-toggle__thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--ct-text-invert);
  box-shadow: var(--ct-shadow-sm);
  transition: transform var(--ct-transition);
}

.ct-toggle--sm .ct-toggle__thumb {
  width: 15px;
  height: 15px;
}

.ct-toggle__input:checked + .ct-toggle__track {
  background: var(--ct-primary);
}

.ct-toggle__input:checked + .ct-toggle__track .ct-toggle__thumb {
  transform: translateX(18px);
}

.ct-toggle--sm .ct-toggle__input:checked + .ct-toggle__track .ct-toggle__thumb {
  transform: translateX(15px);
}

.ct-toggle__input:focus-visible + .ct-toggle__track {
  box-shadow: var(--ct-shadow-focus);
}

.ct-toggle__text {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ct-toggle__label {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.ct-toggle__description {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}
</style>
