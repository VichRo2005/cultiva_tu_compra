import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'

const service = vi.hoisted(() => ({
  cargarCatalogoAdmin: vi.fn(),
  cambiarEstadoProductoAdmin: vi.fn(),
}))
vi.mock('@/services/adminCatalog', async (importOriginal) => ({
  ...(await importOriginal()),
  ...service,
}))
vi.mock('@/stores/ui', () => ({
  useUiStore: () => ({ success: vi.fn(), error: vi.fn(), warning: vi.fn() }),
}))
vi.mock('@/views/public/ProductDetailView.vue', () => ({
  default: {
    props: ['adminProduct', 'adminMode'],
    template: '<div data-test="detalle">{{ adminProduct.nombre }}</div>',
  },
}))
import AdminCatalogView from '@/views/admin/AdminCatalogView.vue'

const productos = [
  {
    id: '1',
    nombre: 'Tomate',
    productor_id: 'p1',
    categoria_id: 'c1',
    activo: true,
    stock: 5,
    productor: { id: 'p1', nombre_comercial: 'Huerta', activo: true },
    categoria: { id: 'c1', nombre: 'Verduras' },
  },
  {
    id: '2',
    nombre: 'Queso',
    productor_id: 'p2',
    categoria_id: 'c2',
    activo: false,
    stock: 40,
    productor: { id: 'p2', nombre_comercial: 'Campo', activo: false },
    categoria: { id: 'c2', nombre: 'Lácteos' },
  },
]
let wrapper
async function montar() {
  wrapper = mount(AdminCatalogView, { attachTo: document.body })
  await flushPromises()
  return wrapper
}
beforeEach(() => {
  vi.resetAllMocks()
  service.cargarCatalogoAdmin.mockResolvedValue({
    productos: productos.map((p) => ({ ...p })),
    productores: productos.map((p) => p.productor),
    categorias: productos.map((p) => p.categoria),
  })
  service.cambiarEstadoProductoAdmin.mockResolvedValue({ activo: false, motivo_pausa: 'Control' })
})
afterEach(() => {
  wrapper?.unmount()
  document.body.innerHTML = ''
})

describe('administración de productos · integración de vista', () => {
  it('filtra por categoría y abre detalle sin navegar ni mostrar carrito', async () => {
    await montar()
    expect(wrapper.text()).toContain('Tomate')
    expect(wrapper.text()).toContain('Queso')
    wrapper.findAllComponents(CtSelect)[0].vm.$emit('update:modelValue', 'c1')
    await flushPromises()
    expect(wrapper.text()).toContain('Tomate')
    expect(wrapper.text()).not.toContain('Queso')
    await wrapper.find('.admin-catalogo__nombre').trigger('click')
    await flushPromises()
    expect(document.body.querySelector('[data-test="detalle"]')?.textContent).toBe('Tomate')
    expect(wrapper.findAllComponents(CtModal)[0].props('modelValue')).toBe(true)
  })

  it('deshabilita acciones del productor pausado y exige motivo al pausar', async () => {
    await montar()
    const filas = wrapper.findAll('tbody tr')
    expect(
      filas[1]
        .findAll('.admin-catalogo__acciones button')
        .every((b) => b.attributes('disabled') !== undefined),
    ).toBe(true)
    await filas[0]
      .findAll('button')
      .find((b) => b.text() === 'Pausar')
      .trigger('click')
    await flushPromises()
    expect(service.cambiarEstadoProductoAdmin).not.toHaveBeenCalled()
    const motivo = document.body.querySelector('textarea')
    motivo.value = 'Corto'
    motivo.dispatchEvent(new Event('input', { bubbles: true }))
    await flushPromises()
    expect(
      [...document.body.querySelectorAll('button')].find((b) => b.textContent === 'Confirmar')
        .disabled,
    ).toBe(true)
    motivo.value = 'Control de calidad'
    motivo.dispatchEvent(new Event('input', { bubbles: true }))
    await flushPromises()
    const confirmar = [...document.body.querySelectorAll('button')].find(
      (b) => b.textContent === 'Confirmar',
    )
    confirmar.click()
    await flushPromises()
    expect(service.cambiarEstadoProductoAdmin).toHaveBeenCalledWith(
      expect.objectContaining({ id: '1' }),
      'pausar',
      'Control de calidad',
    )
  })

  it('actualiza las tarjetas al filtrar por productor', async () => {
    await montar()
    const tarjetas = wrapper.findAllComponents(CtStatCard)
    expect(tarjetas.map((t) => t.props('value'))).toEqual(['1', '5'])
    wrapper.findAllComponents(CtSelect)[1].vm.$emit('update:modelValue', 'p2')
    await flushPromises()
    expect(tarjetas.map((t) => t.props('value'))).toEqual(['0', '0'])
  })

  it('exige justificación válida antes de eliminar', async () => {
    await montar()
    await wrapper
      .findAll('tbody tr')[0]
      .findAll('.admin-catalogo__acciones button')[1]
      .trigger('click')
    await flushPromises()
    const motivo = document.body.querySelector('textarea')
    expect(motivo.getAttribute('maxlength')).toBe('1000')
    const eliminar = [...document.body.querySelectorAll('button')].find(
      (b) => b.textContent === 'Eliminar' && b.closest('[role="dialog"]'),
    )
    expect(eliminar.disabled).toBe(true)
    motivo.value = 'Motivo de eliminación válido'
    motivo.dispatchEvent(new Event('input', { bubbles: true }))
    await flushPromises()
    expect(eliminar.disabled).toBe(false)
    eliminar.click()
    await flushPromises()
    expect(service.cambiarEstadoProductoAdmin).toHaveBeenCalledWith(
      expect.objectContaining({ id: '1' }),
      'eliminar',
      'Motivo de eliminación válido',
    )
  })
})
