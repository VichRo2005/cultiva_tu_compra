/**
 * CuTuCo — Lote 17 (Servicio mensual), lado frontend.
 *
 * CK-0241: la vista muestra período, monto, emisión, vencimiento, gracia y estado.
 * CK-0245: con suspensión por deuda se puede consultar la cuota e iniciar el pago.
 * CK-0404: el monto de la cuota es fijo (2990 CLP); no hay campo editable de monto
 *          y la pasarela cobra/concilia el monto exacto (backend).
 * CK-0491 (HAL-VEN-003): datos bancarios de destino CuTuCo visibles con copiar,
 *          administrados desde el panel y con placeholder si no están configurados.
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'
import { REGLAS_SERVICIO, ESTADO_SERVICIO, ESTADO_TIENDA_SERVICIO } from '@/lib/constants'
import { diasHastaSuspension, fechasCuotaServicio } from '@/services/servicio'

const src = (p) => readFileSync(`src/${p}`, 'utf8')
const vista = () => src('views/seller/SellerServiceView.vue')

describe('CK-0241 · consulta de Servicio y pagos', () => {
  it('muestra período, monto, emisión, vencimiento, gracia y estado', () => {
    const v = vista()
    for (const etiqueta of ['Cuota mensual', 'Período facturado', 'Emitida', 'Vencimiento', 'Gracia hasta', 'Suspensión desde', 'Estado actual']) {
      expect(v).toContain(etiqueta)
    }
    expect(v).toContain('getMiServicio()')
    expect(v).toContain('listPagosServicio()')
  })

  it('deriva emisión/vencimiento/gracia desde vence_en con 10+5 días', () => {
    const plazos = fechasCuotaServicio({ vence_en: '2026-11-20', periodo: '2026-11-01' })
    expect(plazos.vence).toBe('2026-11-20')
    expect(plazos.emision).toBe('2026-11-10')
    expect(plazos.graciaHasta).toBe('2026-11-25')
    expect(plazos.suspensionDesde).toBe('2026-11-26') // día 16 desde la emisión
    expect(REGLAS_SERVICIO.diasVencimiento).toBe(10)
    expect(REGLAS_SERVICIO.diasGracia).toBe(5)
  })
})

describe('CK-0245 · pagar estando suspendido', () => {
  it('puedePagar depende de la cuota (pendiente/rechazado), no del estado de suspensión', () => {
    const v = vista()
    expect(v).toMatch(/puedePagar[\s\S]{0,220}ESTADO_SERVICIO\.PENDIENTE, ESTADO_SERVICIO\.RECHAZADO/)
    expect(v).toContain('Pagar con Webpay')
    expect(v).toContain('Registrar transferencia')
    // aviso de suspensión separado del pago
    expect(v).toContain('Servicio vencido: tu tienda está suspendida')
  })
})

describe('CK-0404 · monto de cuota fijo y exacto', () => {
  it('el monto mostrado es 2990 CLP y no hay input editable de monto en el formulario', () => {
    expect(REGLAS_SERVICIO.montoMensual).toBe(2990)
    const v = vista()
    expect(v).toContain("formatCLP(cuota?.monto ?? REGLAS_SERVICIO.montoMensual)")
    // el modal de transferencia sólo pide referencia y observaciones
    const modal = v.slice(v.indexOf('Registrar transferencia'))
    expect(modal).toContain('N° de operación')
    expect(modal).not.toMatch(/v-model="transferencia\.monto"/)
    // el monto viaja en el texto para copiar, no como campo editable
    expect(v).toContain('Cuota mensual CuTuCo:')
  })
})

describe('CK-0491 · HAL-VEN-003 datos bancarios de destino CuTuCo', () => {
  it('consulta la configuración administrada y ofrece copiar cada dato y todos', () => {
    const v = vista()
    expect(v).toContain('obtenerDatosTransferenciaCutuco()')
    expect(v).toContain('DATOS_TRANSFERENCIA_CUTUCO_VACIOS')
    expect(v).not.toContain('VITE_CUTUCO_BANCO')
    expect(v).toContain('Copiar todos los datos')
    expect(v).toContain('aria-label')
    // sin configuración: placeholder explícito y copia deshabilitada (nunca cuenta inventada)
    expect(v).toContain("'No configurado'")
    expect(v).toContain(':disabled="!fila.valor"')
    expect(v).toContain('Datos bancarios de CuTuCo no configurados')
    expect(v).toMatch(/No deposites en una cuenta\s+distinta/)
  })
})
