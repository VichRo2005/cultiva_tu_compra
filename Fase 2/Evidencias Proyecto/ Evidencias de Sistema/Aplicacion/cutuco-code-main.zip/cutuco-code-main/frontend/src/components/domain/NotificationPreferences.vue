<script setup>
/** Canales de notificación que CuTuCo puede entregar realmente. */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import {
  PREFERENCIAS_NOTIFICACION_PREDETERMINADAS,
  guardarPreferenciasNotificacion,
  obtenerPreferenciasNotificacion,
} from '@/services/notificationPreferences'
import { useUiStore } from '@/stores/ui'

const props = defineProps({
  rol: { type: String, required: true },
})

const emit = defineEmits(['saved'])
const ui = useUiStore()

const preferencias = ref({ ...PREFERENCIAS_NOTIFICACION_PREDETERMINADAS })
const cargando = ref(true)
const guardando = ref(false)
const error = ref(null)

const descripcionCorreo = computed(() =>
  props.rol === 'vendedor'
    ? 'Nuevos pedidos y la resolución de tu postulación llegarán a tu correo.'
    : 'Las confirmaciones y actualizaciones de tus pedidos llegarán a tu correo.',
)

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    preferencias.value = await obtenerPreferenciasNotificacion()
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron cargar tus preferencias de notificación.'
  } finally {
    cargando.value = false
  }
}

async function guardar() {
  if (guardando.value) return
  guardando.value = true
  error.value = null
  try {
    preferencias.value = await guardarPreferenciasNotificacion(preferencias.value)
    emit('saved', preferencias.value)
    ui.success(
      'Preferencias guardadas',
      'Las actualizaciones futuras se enviarán sólo por los canales que mantuviste activos.',
    )
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron guardar tus preferencias de notificación.'
  } finally {
    guardando.value = false
  }
}

onMounted(cargar)
</script>

<template>
  <section class="bloque">
    <div class="bloque__cabecera">
      <h2 class="bloque__titulo">Preferencias de notificación</h2>
    </div>
    <p class="bloque__texto">
      Elige por qué canales quieres recibir avisos de tu cuenta. Los cambios se aplican al guardar.
    </p>

    <CtAlert v-if="error" tone="danger" compact class="preferencias__error">
      {{ error }}
    </CtAlert>

    <div v-if="cargando" class="text-sm text-soft">Cargando tus preferencias…</div>
    <ul v-else class="preferencias">
      <li>
        <CtCheckbox
          v-model="preferencias.email"
          label="Correo electrónico"
          :description="descripcionCorreo"
        />
      </li>
      <li>
        <CtCheckbox
          v-model="preferencias.inApp"
          label="Avisos dentro de CuTuCo"
          description="Alertas en la campana y en el centro de notificaciones mientras uses la plataforma."
        />
      </li>
    </ul>

    <CtAlert tone="neutral" compact class="preferencias__aviso">
      Los mensajes necesarios para proteger tu acceso, como la recuperación de contraseña, siempre
      se enviarán al correo de tu cuenta.
    </CtAlert>

    <div class="acciones">
      <CtButton :loading="guardando" :disabled="cargando || guardando" @click="guardar">
        Guardar preferencias
      </CtButton>
    </div>
  </section>
</template>

<style scoped>
.bloque {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.bloque__cabecera {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}

.bloque__titulo {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-2xs);
  font-weight: var(--ct-fw-semibold);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
}

.bloque__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-normal);
}

.preferencias {
  list-style: none;
  margin: var(--ct-space-3) 0 var(--ct-space-5);
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.preferencias__error,
.preferencias__aviso {
  margin: var(--ct-space-3) 0;
}

.acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
}
</style>
