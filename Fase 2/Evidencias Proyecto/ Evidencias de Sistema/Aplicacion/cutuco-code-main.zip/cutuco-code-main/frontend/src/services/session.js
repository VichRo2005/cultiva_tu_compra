/**
 * CuTuCo — Contexto de sesión y permisos compartidos por los servicios.
 *
 * El rol vive en `public.perfiles` (RF-001). El vendedor sólo puede operar su
 * tienda cuando el administrador aprobó su postulación y su cuenta está activa
 * (RF-021).
 *
 * Las sanciones se evalúan por su estado EFECTIVO usando la hora del cliente:
 * una suspensión con `fin_en` cumplido ya no bloquea el acceso (LOG-NEG-006),
 * aunque el productor siga con `activo=false` hasta que se reconcilie en la
 * base. El ban permanente nunca expira.
 */

import { mensajeSeguro } from '@/services/errores'
import { tryGetClient } from '@/lib/supabase'
import { ACCION_SANCION, ESTADO_POSTULACION, ESTADO_SANCION, ROL_USUARIO } from '@/lib/constants'

/** Estados de sanción que mantienen vigente la restricción sobre el vendedor. */
const SANCION_VIGENTE = [ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA]

/** Devuelve { user, perfil, productor, postulacion } del usuario autenticado. */
export async function currentAuth() {
  const client = tryGetClient()
  if (!client) return { user: null, perfil: null, productor: null, postulacion: null }

  const { data, error: userError } = await client.auth.getUser()
  if (userError) {
    // Sin sesión, el SDK devuelve AuthSessionMissingError: no es un fallo del
    // servicio ni debe mostrar un error al visitante. Sólo los errores reales
    // de red/servidor se propagan (LOG-NEG-007).
    const textoError = `${userError.name ?? ''} ${userError.message ?? ''}`
    if (!/authsessionmissing|session missing|no session/i.test(textoError)) {
      throw new Error('No se pudo verificar tu sesión. Vuelve a iniciar sesión.')
    }
  }
  const user = data?.user ?? null
  if (!user) return { user: null, perfil: null, productor: null, postulacion: null }

  const { data: perfil, error: perfilError } = await client
    .from('perfiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()
  // LOG-NEG-007: un fallo al consultar rol/estado no puede conceder acceso
  // parcial. El store cierra la sesión y muestra un error recuperable.
  if (perfilError) {
    throw new Error(
      'No pudimos verificar el estado de tu cuenta. Revisa tu conexión e inténtalo de nuevo.',
    )
  }

  let productor = null
  let postulacion = null
  if (perfil) {
    const { data: prod, error: productorError } = await client
      .from('productores')
      .select('*')
      .eq('perfil_id', user.id)
      .maybeSingle()
    if (productorError) {
      throw new Error(
        'No pudimos verificar el estado de tu tienda. Revisa tu conexión e inténtalo de nuevo.',
      )
    }
    productor = prod ?? null
    const { data: post, error: postulacionError } = await client
      .from('postulaciones_vendedores')
      .select('*')
      .eq('perfil_id', user.id)
      .order('creado_en', { ascending: false })
      .limit(1)
      .maybeSingle()
    if (postulacionError && postulacionError.code !== 'PGRST116') {
      throw new Error(
        'No pudimos verificar el estado de tu postulación. Revisa tu conexión e inténtalo de nuevo.',
      )
    }
    postulacion = post ?? null
  }

  return { user, perfil: perfil ?? null, productor, postulacion }
}

export async function currentUserId() {
  const client = tryGetClient()
  if (!client) return null
  const { data } = await client.auth.getUser()
  return data?.user?.id ?? null
}

/** Lanza el error de Supabase si existe, o devuelve los datos. */
export function unwrap({ data, error }, fallback = 'Ocurrió un error inesperado') {
  if (error) throw new Error(mensajeSeguro(error, fallback))
  return data
}

/** true cuando el vendedor ya fue aprobado y puede publicar productos (RF-021). */
export function vendedorAprobado({ productor, postulacion } = {}) {
  if (productor?.activo && productor?.aprobado_en) return true
  return postulacion?.estado === ESTADO_POSTULACION.APROBADA
}

/**
 * ¿La sanción sigue vigente y además restringe la operación? (RF-026)
 *
 * Una amonestación deja constancia en el historial, pero NO suspende la tienda:
 * el trigger de la base sólo desactiva al productor cuando la acción es
 * `suspender` o `ban_permanente`. Vigente = estado `activa`/`apelada` + acción
 * que bloquea + plazo no cumplido (el ban permanente no expira).
 */
export function sancionVigente(sancion, ahora = Date.now()) {
  if (!sancion || !SANCION_VIGENTE.includes(sancion.estado)) return false
  const accion = sancion.accion
  if (accion === ACCION_SANCION.BAN_PERMANENTE) return true
  if (accion !== ACCION_SANCION.SUSPENDER) return false
  return sancion.fin_en ? new Date(sancion.fin_en).getTime() > ahora : true
}

/** true cuando la cuenta del vendedor está suspendida o con ban permanente (RF-026). */
export function vendedorSancionado(sanciones = [], ahora = Date.now()) {
  return sanciones.some((s) => sancionVigente(s, ahora))
}

/** Ban permanente efectivo (activo o en apelación): cierra el acceso. */
export function banPermanenteVigente(sanciones = [], ahora = Date.now()) {
  return sanciones.some(
    (s) =>
      s?.accion === ACCION_SANCION.BAN_PERMANENTE && sancionVigente(s, ahora),
  )
}

/** Suspensión temporal efectiva (no vencida): acceso sólo a amonestaciones. */
export function suspensionVigente(sanciones = [], ahora = Date.now()) {
  return sanciones.some(
    (s) => s?.accion === ACCION_SANCION.SUSPENDER && sancionVigente(s, ahora),
  )
}

/**
 * Estado efectivo de la cuenta para decidir el acceso y la ruta inicial.
 * Valores: sin_perfil | eliminado | desactivado | baneado | suspendido |
 * postulacion | pendiente | activo.
 *
 * No consulta la red: recibe lo cargado en `auth.refresh()`. La fecha de la
 * suspensión se compara con la hora local, que es la referencia disponible en
 * el cliente; el backend revalida al operar.
 */
export function estadoEfectivoCuenta({ perfil, productor, postulacion, sanciones = [] } = {}) {
  if (!perfil) return 'sin_perfil'
  if (perfil.eliminado_en) return 'eliminado'
  if (perfil.activo === false) {
    if (banPermanenteVigente(sanciones)) return 'baneado'
    return 'desactivado'
  }
  if (banPermanenteVigente(sanciones)) return 'baneado'
  if (suspensionVigente(sanciones)) return 'suspendido'
  if (postulacion?.estado === ESTADO_POSTULACION.RECHAZADA) return 'postulacion_rechazada'
  if (
    postulacion &&
    [ESTADO_POSTULACION.BORRADOR, ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(
      postulacion.estado,
    )
  ) {
    return 'postulacion'
  }
  if (perfil.rol === ROL_USUARIO.VENDEDOR && !vendedorAprobado({ productor, postulacion })) {
    return 'pendiente'
  }
  return 'activo'
}

/** Mensaje único para explicar por qué un vendedor no puede operar. */
export function motivoBloqueoVendedor({ perfil, productor, postulacion, sanciones = [] } = {}) {
  const estado = estadoEfectivoCuenta({ perfil, productor, postulacion, sanciones })
  switch (estado) {
    case 'eliminado':
      return 'Tu cuenta fue eliminada y no se puede reactivar.'
    case 'desactivado':
      return 'Tu cuenta está desactivada. Contacta al administrador.'
    case 'baneado':
      return 'Tu cuenta tiene un ban permanente. Contacta al administrador si necesitas apelar.'
    case 'suspendido':
      return 'Tu cuenta está suspendida. Puedes revisar y apelar la sanción en este apartado.'
    case 'postulacion':
      return 'Tu solicitud de vendedor está pendiente: completa los datos requeridos en Mi Postulación.'
    case 'postulacion_rechazada':
      return postulacion?.observaciones_admin
        ? `Tu solicitud fue rechazada: ${postulacion.observaciones_admin}`
        : 'Tu solicitud de vendedor fue rechazada. Puedes revisarla y volver a postular.'
    case 'pendiente':
      return 'Tu solicitud de vendedor está pendiente de aprobación del administrador.'
    default:
      return null
  }
}

/** Permisos por rol usados por el router y la navegación. */
export const PERMISOS = Object.freeze({
  [ROL_USUARIO.CLIENTE]: ['catalogo', 'carrito', 'checkout', 'pedidos', 'perfil', 'calificar'],
  [ROL_USUARIO.VENDEDOR]: ['tienda', 'productos', 'ventas', 'pedidos', 'reclamos', 'servicio'],
  [ROL_USUARIO.ADMIN]: [
    'panel',
    'usuarios',
    'productos',
    'moderacion',
    'sanciones',
    'pagos',
    'servicios',
    'reclamos',
  ],
})

export function tienePermiso(rol, permiso) {
  return (PERMISOS[rol] ?? []).includes(permiso)
}
