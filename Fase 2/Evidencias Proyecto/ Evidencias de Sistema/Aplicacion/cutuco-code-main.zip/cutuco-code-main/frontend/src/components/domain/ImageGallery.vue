<script setup>
/** CuTuCo — Galería de imágenes con visor ampliado. */
import { computed, ref } from 'vue'
import CtModal from '@/components/base/CtModal.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import { placeholderImage } from '@/lib/images'

const props = defineProps({
  images: { type: Array, default: () => [] }, // [{ url, texto_alternativo, ... }]
  alt: { type: String, default: 'Imagen del producto' },
  /** Imagen a mostrar cuando el producto no tiene fotografías cargadas. */
  respaldo: { type: String, default: null },
})

const indice = ref(0)
const visorAbierto = ref(false)

function imagenFallida(event) {
  const respaldo = props.respaldo || placeholderImage(props.alt, props.alt)
  if (event.target.src !== respaldo) event.target.src = respaldo
}

/** Nunca queda un contenedor vacío: si no hay galería, se usa el respaldo. */
const imagenActual = computed(() => {
  const elegida = props.images[indice.value] ?? props.images[0] ?? null
  if (elegida?.url) return elegida
  if (props.respaldo) return { url: props.respaldo, texto_alternativo: props.alt }
  return null
})

function abrir(index) {
  indice.value = index
  visorAbierto.value = true
}

function anterior() {
  indice.value = (indice.value - 1 + props.images.length) % props.images.length
}

function siguiente() {
  indice.value = (indice.value + 1) % props.images.length
}
</script>

<template>
  <div class="ct-gallery">
    <div class="ct-gallery__main">
      <img v-if="imagenActual" :src="imagenActual.url" :alt="imagenActual.texto_alternativo || alt" @error="imagenFallida" />
      <div v-else class="ct-gallery__placeholder" aria-hidden="true"><CtIcon name="image" :size="34" /></div>

      <button
        v-if="images.length > 1"
        type="button"
        class="ct-gallery__nav is-prev"
        aria-label="Imagen anterior"
        @click="anterior"
      >
        ‹
      </button>
      <button
        v-if="images.length > 1"
        type="button"
        class="ct-gallery__nav is-next"
        aria-label="Imagen siguiente"
        @click="siguiente"
      >
        ›
      </button>
      <button
        v-if="imagenActual"
        type="button"
        class="ct-gallery__zoom"
        aria-label="Ampliar imagen"
        @click="abrir(indice)"
      >
        <CtIcon name="search" :size="16" />
      </button>
    </div>

    <ul v-if="images.length > 1" class="ct-gallery__thumbs">
      <li v-for="(img, index) in images" :key="img.url ?? index">
        <button
          type="button"
          class="ct-gallery__thumb"
          :class="{ 'is-active': index === indice }"
          @click="indice = index"
        >
          <img :src="img.url" :alt="img.texto_alternativo || `Vista ${index + 1}`" @error="imagenFallida" />
        </button>
      </li>
    </ul>

    <CtModal v-model="visorAbierto" size="lg" :title="imagenActual?.texto_alternativo || alt">
      <img
        v-if="imagenActual"
        :src="imagenActual.url"
        :alt="imagenActual.texto_alternativo || alt"
        class="ct-gallery__full"
        @error="imagenFallida"
      />
    </CtModal>
  </div>
</template>

<style scoped>
.ct-gallery {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.ct-gallery__main {
  position: relative;
  aspect-ratio: 4 / 3;
  border-radius: var(--ct-radius-lg);
  overflow: hidden;
  background: var(--ct-surface-alt);
  border: 1px solid var(--ct-border);
}

.ct-gallery__main img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform var(--ct-transition);
}

/* Zoom suave de la imagen principal al hover (dentro del marco). */
.ct-gallery__main:hover img {
  transform: scale(1.02);
}

.ct-gallery__placeholder {
  width: 100%;
  height: 100%;
  display: grid;
  place-items: center;
  font-size: 4rem;
}

.ct-gallery__nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: var(--ct-surface-translucent);
  color: var(--ct-text);
  font-size: 1.4rem;
  line-height: 1;
  display: grid;
  place-items: center;
  box-shadow: var(--ct-shadow-sm);
  transition:
    background var(--ct-transition),
    color var(--ct-transition),
    box-shadow var(--ct-transition),
    transform var(--ct-transition);
}

.ct-gallery__nav.is-prev {
  left: var(--ct-space-3);
}
.ct-gallery__nav.is-next {
  right: var(--ct-space-3);
}

.ct-gallery__nav:hover {
  background: var(--ct-surface);
  color: var(--ct-primary-strong);
  box-shadow: var(--ct-shadow-md);
  transform: translateY(-50%) scale(1.06);
}

.ct-gallery__nav:active {
  transform: translateY(-50%) scale(0.96);
}

.ct-gallery__zoom {
  transition:
    background var(--ct-transition),
    color var(--ct-transition);
}

.ct-gallery__zoom:hover {
  background: var(--ct-surface);
  color: var(--ct-primary-strong);
}

.ct-gallery__zoom {
  position: absolute;
  right: var(--ct-space-3);
  bottom: var(--ct-space-3);
  width: 34px;
  height: 34px;
  border-radius: var(--ct-radius-sm);
  background: var(--ct-surface-translucent);
  display: grid;
  place-items: center;
}

.ct-gallery__thumbs {
  display: flex;
  gap: var(--ct-space-2);
  list-style: none;
  padding: 0;
  margin: 0;
  flex-wrap: wrap;
}

.ct-gallery__thumb {
  width: 68px;
  height: 68px;
  border-radius: var(--ct-radius-md);
  overflow: hidden;
  border: 2px solid transparent;
  padding: 0;
}

.ct-gallery__thumb {
  transition:
    border-color var(--ct-transition),
    transform var(--ct-transition),
    box-shadow var(--ct-transition);
}

.ct-gallery__thumb:hover {
  border-color: var(--ct-border-strong);
  transform: translateY(-2px);
  box-shadow: var(--ct-shadow-sm);
}

.ct-gallery__thumb.is-active {
  border-color: var(--ct-primary);
}

.ct-gallery__thumb.is-active:hover {
  border-color: var(--ct-primary-strong);
}

.ct-gallery__thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.ct-gallery__full {
  width: 100%;
  border-radius: var(--ct-radius-md);
}
</style>
