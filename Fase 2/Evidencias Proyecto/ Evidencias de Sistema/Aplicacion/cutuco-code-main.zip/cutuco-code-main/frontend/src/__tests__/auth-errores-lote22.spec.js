/**
 * CuTuCo — Lote 22 (CK-0036): enlace de recuperación/OTP vencido se rechaza
 * con mensaje claro (normalizarErrorAuth mapea 'expired'/'otp expired').
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

const contexto = vi.hoisted(() => ({
  currentAuth: vi.fn(),
  motivoBloqueoVendedor: vi.fn(),
  sancionVigente: vi.fn(() => false),
  estadoEfectivoCuenta: vi.fn(({ perfil } = {}) => (perfil ? 'activo' : 'sin_perfil')),
}))
const cliente = vi.hoisted(() => ({
  from: vi.fn(),
  auth: {
    getSession: vi.fn(),
    getUser: vi.fn(),
    signInWithPassword: vi.fn(),
    signOut: vi.fn(),
    updateUser: vi.fn(),
    resetPasswordForEmail: vi.fn(),
    resend: vi.fn(),
    onAuthStateChange: vi.fn(),
  },
}))
vi.mock('@/services/session', () => contexto)
vi.mock('@/lib/supabase', () => ({
  getClient: () => cliente,
  tryGetClient: () => cliente,
  MISSING_ENV: false,
  MODO_DEMO: { value: false },
}))
import { useAuthStore } from '@/stores/auth.js'

beforeEach(() => {
  vi.resetAllMocks()
  setActivePinia(createPinia())
  cliente.auth.getSession.mockResolvedValue({ data: { session: null }, error: null })
  cliente.auth.onAuthStateChange.mockReturnValue({
    data: { subscription: { unsubscribe: vi.fn() } },
  })
  cliente.auth.signOut.mockResolvedValue({ error: null })
})

describe('CK-0036 · enlace vencido', () => {
  it.each([
    'otp expired',
    'recovery token expired',
    'email link expired',
  ])('el error "%s" se traduce a enlace vencido y no concede acceso', async (mensaje) => {
    cliente.auth.signInWithPassword.mockResolvedValueOnce({ error: { status: 400, message: mensaje } })
    const auth = useAuthStore()
    const error = await auth.signIn({ email: 'qa@example.test', password: 'Clave123!' }).catch((e) => e)
    expect(String(error?.message)).toMatch(/enlace de recuperación venció|ya fue utilizado/i)
    expect(String(error?.message)).not.toMatch(/otp|token expired/i)
    expect(auth.perfil).toBeNull()
  })
})
