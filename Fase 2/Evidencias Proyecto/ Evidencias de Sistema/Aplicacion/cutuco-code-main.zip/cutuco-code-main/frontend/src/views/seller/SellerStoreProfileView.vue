<script setup>
/**
 * CuTuCo — Perfil de tienda del productor (página 16 del diseño).
 *
 *   RF-021  estado de la solicitud de vendedor (pendiente/aprobada/rechazada con
 *           observaciones) y datos bancarios de respaldo de la tienda
 *   RF-024  cambio de contraseña con `auth.updatePassword(actual, nueva)`
 *   RF-026  sanciones vigentes de la cuenta
 *   RF-009  región y comuna se leen de la dirección activa; se editan con
 *           `updateDireccion` (el vendedor sólo despacha en su región)
 *   RF-018  regiones y comunas se eligen con `CtSelect`
 *   RF-019  validaciones con `@/lib/validation` y error en cada campo
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   Esta vista usaba `actualizarTienda(productorId, {comuna_origen_id})`,
 *   `getMiCobertura`, `getDocumentosPostulacion`/`subirDocumentoIdentidad`
 *   (carnet, RF-015 fuera de alcance), `getDashboardVendedor` (score 40/40/20) y
 *   `ReputationGauge` con la pausa automática por puntaje. Nada de eso existe en
 *   el ERS vigente: la región vive en la dirección activa (RF-009), el score es
 *   un promedio simple de 1 a 5 y las sanciones las aplica el administrador a
 *   mano (RF-026). Ahora se usan `updateTienda`, `getTiendaConUbicacion`,
 *   `getDatosBancarios`, `guardarDatosBancarios`, `listSancionesDeProductor` y
 *   `updateDireccion`.
 */
import { computed, onMounted, ref, watch } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtFileUpload from '@/components/base/CtFileUpload.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import {
  BANCOS_DISPONIBLES,
  ESTADO_POSTULACION,
  ESTADO_SANCION,
  etiquetaTipoCuenta,
  LABELS,
  REGLAS,
  TIPOS_CUENTA_BANCARIA,
} from '@/lib/constants'
import { formatDate, formatDateTime, formatNumber, formatRut } from '@/lib/format'
import portadaFondoUrl from '@/assets/fondo-agro.jpg'
import { NAV_SECUNDARIO } from '@/lib/navigation'
import {
  isDeptoOficina,
  isNumeroCuentaBancaria,
  isNumeroDireccion,
  isPhone,
  isReferenciaDireccion,
  isTitularCuenta,
  LIMITES,
  passwordPolicyMessage,
  validate,
} from '@/lib/validation'
import { useAsync } from '@/composables/useAsync'
import { readFileAsDataURL, storageUrl } from '@/lib/supabase'
import { STORAGE_BUCKETS } from '@/lib/constants'
import { useAuthStore } from '@/stores/auth'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import { getReputacionProductor } from '@/services/orders'
import { updateDireccion } from '@/services/geography'
import {
  getDatosBancarios,
  getMiPostulacion,
  getMiProductor,
  getTiendaConUbicacion,
  guardarDatosBancarios,
  listSancionesDeProductor,
  quitarPortadaTienda,
  subirPortadaTienda,
  updateTienda,
} from '@/services/seller'

const auth = useAuthStore()
const geo = useGeographyStore()
const ui = useUiStore()

/**
 * Bancos y tipos de cuenta aceptados por FastAPI (`schemas/datos_bancarios.py`).
 * Son la única vía de escritura: `public.datos_bancarios` no es alcanzable por
 * PostgREST. Si la etiqueta no coincide con el contrato, el endpoint responde 422.
 */
const BANCOS = BANCOS_DISPONIBLES
const TIPOS_CUENTA = TIPOS_CUENTA_BANCARIA

/** Sanciones que restringen la operación (RF-026). */
const SANCIONES_VIGENTES = Object.freeze([ESTADO_SANCION.ACTIVA, ESTADO_SANCION.APELADA])

const tab = ref('informacion')
const tabItems = [
  { value: 'informacion', label: 'Información de Tienda' },
  { value: 'operativa', label: 'Datos bancarios y ubicación' },
  { value: 'seguridad', label: 'Contraseña y solicitud' },
]

const guardando = ref(false)
const guardandoBanco = ref(false)
const cambiandoPassword = ref(false)
const guardandoDireccion = ref(false)

const { data, loading, error, run } = useAsync(async () => {
  void geo.load()
  const [productor, postulacion] = await Promise.all([getMiProductor(), getMiPostulacion()])

  if (!productor?.id) {
    return {
      productor: null,
      postulacion,
      tienda: null,
      datosBancarios: null,
      sanciones: [],
      reputacion: { puntaje: null, cantidad: 0 },
    }
  }

  const [tienda, datosBancarios, sanciones, reputacion] = await Promise.all([
    getTiendaConUbicacion(productor.id),
    productor.perfil_id ? getDatosBancarios().catch(() => null) : null,
    listSancionesDeProductor(productor.id).catch(() => []),
    getReputacionProductor(productor.id),
  ])

  return { productor, postulacion, tienda, datosBancarios, sanciones, reputacion }
})

const productor = computed(() => data.value?.productor ?? auth.productor ?? null)
const postulacion = computed(() => data.value?.postulacion ?? auth.postulacion ?? null)
const tienda = computed(() => data.value?.tienda ?? null)
const direccion = computed(() => tienda.value?.direccion ?? null)
const sanciones = computed(() => data.value?.sanciones ?? auth.sanciones ?? [])
const reputacion = computed(() => data.value?.reputacion ?? { puntaje: null, cantidad: 0 })

/**
 * Única fuente de ubicación (HAL-VEN-009): la dirección activa devuelta por
 * `getTiendaConUbicacion`, con la comuna y región ya resueltas por el servicio.
 * Se acepta también la forma anidada de versiones anteriores para no romper
 * montajes existentes.
 */
const comunaActual = computed(() => tienda.value?.comuna ?? direccion.value?.comuna ?? null)
const regionActual = computed(() => tienda.value?.region ?? direccion.value?.region ?? null)
const regionIdDireccion = computed(
  () =>
    regionActual.value?.id ??
    comunaActual.value?.region_id ??
    geo.regionDeComuna(direccion.value?.comuna_id) ??
    '',
)

const sancionesVigentes = computed(() =>
  sanciones.value.filter((s) => SANCIONES_VIGENTES.includes(s.estado)),
)

/** Tras la aprobación de la postulación los datos bancarios quedan bloqueados (HAL-VEN-008). */
const bancoBloqueado = computed(() => postulacion.value?.estado === ESTADO_POSTULACION.APROBADA)

onMounted(() => run())

/* ------------------------------------------------------------------ */
/* Formulario de tienda (RF-021)                                       */
/* ------------------------------------------------------------------ */

const form = ref({ nombre_comercial: '', descripcion: '' })
const errores = ref({})

/**
 * HAL-VEN-005: el slug de la tienda se deriva del nombre comercial. Un nombre
 * sólo con símbolos produce un slug vacío y la BD lo rechaza con un error de
 * CHECK. Se valida aquí para mostrar un mensaje funcional y no llegar a guardar.
 */
const NOMBRE_COMERCIAL_UTIL = /[\p{L}\p{N}]/u

function mensajeNombreComercial(valor) {
  const texto = String(valor ?? '').trim()
  if (!texto) return 'El nombre comercial es obligatorio'
  if (!NOMBRE_COMERCIAL_UTIL.test(texto)) {
    return 'El nombre comercial debe incluir al menos una letra o número para generar la dirección de tu tienda'
  }
  return null
}

/** Nombre completo del titular (HAL-REG-008), nunca iniciales ni alias. */
const titularSugerido = computed(() => {
  if (auth.nombreCompleto) return auth.nombreCompleto
  return [auth.perfil?.nombre, auth.perfil?.apellido].filter(Boolean).join(' ')
})

const ESQUEMA_TIENDA = {
  nombre_comercial: {
    required: true,
    minLength: 3,
    maxLength: LIMITES.nombreComercial,
    custom: (valor) => mensajeNombreComercial(valor),
  },
  descripcion: { maxLength: LIMITES.descripcion },
}

function hidratar() {
  if (!productor.value) return
  form.value = {
    nombre_comercial: productor.value.nombre_comercial ?? '',
    descripcion: productor.value.descripcion ?? '',
  }
  banco.value = {
    banco: datosBancarios.value?.banco ?? '',
    tipoCuenta: datosBancarios.value?.tipo_cuenta ?? '',
    numeroCuenta: '',
    titular: datosBancarios.value?.titular_cuenta || titularSugerido.value,
    rutTitular: datosBancarios.value?.rut_titular ?? '',
  }
  direccionForm.value = {
    regionId: regionIdDireccion.value,
    comunaId: comunaActual.value?.id ?? direccion.value?.comuna_id ?? '',
    calle: direccion.value?.calle ?? '',
    numero: direccion.value?.numero ?? '',
    deptoOficina: direccion.value?.depto_oficina ?? '',
    referencia: direccion.value?.referencia ?? '',
  }
  telefono.value = auth.perfil?.telefono ?? ''
}

async function guardarTienda() {
  errores.value = {}
  if (!productor.value) return

  const { valid, errors } = validate(form.value, ESQUEMA_TIENDA)
  errores.value = errors
  if (!valid) {
    ui.warning('Revisa el formulario', 'Hay campos obligatorios por completar')
    return
  }

  guardando.value = true
  try {
    await updateTienda({
      productorId: productor.value.id,
      nombreComercial: form.value.nombre_comercial.trim(),
      descripcion: form.value.descripcion.trim(),
    })
    await run()
    await auth.refresh()
    ui.success('Tienda actualizada', 'El nombre comercial y la descripción ya están publicados.')
  } catch (e) {
    const mensaje = e?.message ?? 'No se pudo actualizar la tienda'
    if (/nombre comercial|slug|direcci[oó]n de tu tienda/i.test(mensaje)) {
      errores.value = { ...errores.value, nombre_comercial: mensaje }
    }
    ui.error('No se pudo guardar la tienda', mensaje)
  } finally {
    guardando.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Ubicación: región y comuna de la dirección activa (RF-009)          */
/* ------------------------------------------------------------------ */

const direccionForm = ref({
  regionId: '',
  comunaId: '',
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
})
const erroresDireccion = ref({})
const telefono = ref('')

const ESQUEMA_DIRECCION = {
  regionId: { required: true },
  comunaId: { required: true },
  calle: { required: true, minLength: 3, maxLength: LIMITES.calle },
  numero: {
    custom: (valor) =>
      isNumeroDireccion(valor) ? null : 'Número inválido: usa hasta 20 caracteres alfanuméricos',
  },
  deptoOficina: {
    custom: (valor) =>
      isDeptoOficina(valor) ? null : 'Departamento u oficina inválido: máximo 50 caracteres',
  },
  referencia: {
    custom: (valor) =>
      isReferenciaDireccion(valor)
        ? null
        : 'Referencia inválida: máximo 500 caracteres con letras o números',
  },
}

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)
const opcionesComuna = computed(() =>
  geo.comunasDeRegion(direccionForm.value.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

/** La comuna debe pertenecer a la región elegida (RF-009). */
function alCambiarRegion() {
  direccionForm.value.comunaId = ''
  erroresDireccion.value = {
    ...erroresDireccion.value,
    regionId: undefined,
    comunaId: undefined,
  }
}

function alCambiarComuna() {
  erroresDireccion.value = { ...erroresDireccion.value, comunaId: undefined }
}

async function guardarDireccion() {
  if (guardandoDireccion.value) return
  erroresDireccion.value = {}
  if (!direccion.value?.id) {
    ui.warning('Sin dirección registrada', 'No hay una dirección activa que puedas editar.')
    return
  }

  const { valid, errors } = validate(direccionForm.value, ESQUEMA_DIRECCION)
  erroresDireccion.value = errors
  if (!valid) {
    ui.warning('Revisa la dirección', 'Región, comuna y calle son obligatorias.')
    return
  }

  guardandoDireccion.value = true
  try {
    await updateDireccion(direccion.value.id, {
      comuna_id: direccionForm.value.comunaId,
      calle: direccionForm.value.calle.trim(),
      numero: direccionForm.value.numero?.trim() || null,
      depto_oficina: direccionForm.value.deptoOficina?.trim() || null,
      referencia: direccionForm.value.referencia?.trim() || null,
    })
    await run()
    ui.success(
      'Dirección actualizada',
      'La región de tu tienda se define con la comuna de tu dirección activa. El cambio se ve en el catálogo, el despacho y esta pantalla.',
    )
  } catch (e) {
    ui.error('No se pudo actualizar la dirección', e.message)
  } finally {
    guardandoDireccion.value = false
  }
}

/** El teléfono de contacto vive en el perfil del usuario (RF-001). */
async function guardarTelefono() {
  if (telefono.value && !isPhone(telefono.value)) {
    erroresDireccion.value = {
      ...erroresDireccion.value,
      telefono: 'Teléfono inválido (ej. +56 9 1234 5678)',
    }
    return
  }
  erroresDireccion.value = { ...erroresDireccion.value, telefono: null }
  try {
    await auth.updatePerfil({ telefono: telefono.value.trim() || null })
    ui.success('Teléfono actualizado', 'El teléfono de contacto quedó guardado en tu perfil.')
  } catch (e) {
    ui.error('No se pudo guardar el teléfono', e.message)
  }
}

/* ------------------------------------------------------------------ */
/* Datos bancarios de respaldo de la tienda (RF-021)                   */
/* ------------------------------------------------------------------ */

const banco = ref({ banco: '', tipoCuenta: '', numeroCuenta: '', titular: '', rutTitular: '' })
const erroresBanco = ref({})

const opcionesBanco = BANCOS.map((b) => ({ value: b, label: b }))

const datosBancarios = computed(() => data.value?.datosBancarios ?? null)

/*
 * Hidratación inicial de los formularios.
 *
 * OJO: este `watch` debe declararse DESPUÉS de `banco`, `direccionForm`,
 * `telefono` y `datosBancarios`. Con `immediate: true` ejecuta `hidratar()` en el
 * acto, durante el `setup`; si se declara antes, esas refs todavía están en la
 * zona muerta temporal y la vista falla con
 * «Cannot access 'banco' before initialization», dejando la página en blanco.
 */
watch([productor, tienda], hidratar, { immediate: true })

const ESQUEMA_BANCO = {
  banco: { required: true },
  tipoCuenta: { required: true, oneOf: TIPOS_CUENTA.map((t) => t.value) },
  numeroCuenta: {
    required: true,
    custom: (valor, values) =>
      isNumeroCuentaBancaria(valor, values.tipoCuenta)
        ? null
        : 'El número no es válido para el tipo de cuenta elegido (sólo dígitos)',
  },
  titular: {
    required: true,
    custom: (valor) =>
      isTitularCuenta(valor) ? null : 'Ingresa el nombre o razón social del titular',
  },
  rutTitular: { required: true, rut: true },
}

// Al cambiar de banco se limpian tipo y número: evita combinaciones inválidas
// entre una cuenta y un banco que no le corresponden.
watch(
  () => banco.value.banco,
  (nuevo, anterior) => {
    if (!anterior || nuevo === anterior) return
    banco.value.tipoCuenta = ''
    banco.value.numeroCuenta = ''
    erroresBanco.value = { ...erroresBanco.value, tipoCuenta: undefined, numeroCuenta: undefined }
  },
)

async function guardarBanco() {
  erroresBanco.value = {}
  const perfilId = productor.value?.perfil_id ?? auth.perfil?.id ?? null
  if (!perfilId) {
    ui.error(
      'Sin perfil de usuario',
      'No se pudo identificar tu perfil para guardar los datos bancarios.',
    )
    return
  }

  const { valid, errors } = validate(banco.value, ESQUEMA_BANCO)
  erroresBanco.value = errors
  if (!valid) {
    ui.warning(
      'Revisa los datos bancarios',
      'Completa banco, tipo y número de cuenta, titular y RUT.',
    )
    return
  }

  guardandoBanco.value = true
  try {
    await guardarDatosBancarios({
      banco: banco.value.banco,
      tipoCuenta: banco.value.tipoCuenta,
      numeroCuenta: banco.value.numeroCuenta.trim(),
      titular: banco.value.titular.trim(),
      rutTitular: banco.value.rutTitular.trim(),
    })
    banco.value = { ...banco.value, numeroCuenta: '' }
    await run()
    ui.success(
      'Datos bancarios guardados',
      'El número de cuenta queda cifrado y sólo se muestra enmascarado. Lo usa el administrador para verificar la titularidad y gestionar ajustes o devoluciones.',
    )
  } catch (e) {
    ui.error('No se pudieron guardar los datos bancarios', e.message)
  } finally {
    guardandoBanco.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Cambio de contraseña (RF-024)                                       */
/* ------------------------------------------------------------------ */

const password = ref({ actual: '', nueva: '', confirmar: '' })
const erroresPassword = ref({})

const ESQUEMA_PASSWORD = {
  actual: { required: true },
  nueva: {
    required: true,
    custom: (valor) => passwordPolicyMessage(valor),
  },
  confirmar: { required: true, match: 'nueva' },
}

async function cambiarPassword() {
  erroresPassword.value = {}
  const { valid, errors } = validate(password.value, ESQUEMA_PASSWORD)
  erroresPassword.value = errors
  if (!valid) {
    ui.warning('Revisa las contraseñas', 'Debes cumplir la política mínima de seguridad.')
    return
  }

  cambiandoPassword.value = true
  try {
    await auth.updatePassword(password.value.actual, password.value.nueva)
    password.value = { actual: '', nueva: '', confirmar: '' }
    ui.success('Contraseña actualizada', 'Usa la nueva contraseña en tu próximo inicio de sesión.')
  } catch (e) {
    erroresPassword.value = { actual: e.message }
    ui.error('No se pudo cambiar la contraseña', e.message)
  } finally {
    cambiandoPassword.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Presentación                                                        */
/* ------------------------------------------------------------------ */

/* Portada: si el vendedor subió una imagen propia se usa esa; si no, la foto
 * agrícola por defecto. */
const subiendoPortada = ref(false)
const portadaVersion = ref(Date.now())
const portadaTemporal = ref(null)
const portadaConError = ref(false)

const portadaFondo = computed(() => {
  if (portadaTemporal.value) return portadaTemporal.value
  if (portadaConError.value) return portadaFondoUrl
  const ruta = productor.value?.portada_storage_path
  if (ruta) {
    const base = storageUrl(ruta, { bucket: STORAGE_BUCKETS.portadasTienda })
    if (base) return `${base}${base.includes('?') ? '&' : '?'}v=${portadaVersion.value}`
  }
  return portadaFondoUrl
})

async function onElegirPortada(filesRecibidos) {
  const filesArray = Array.isArray(filesRecibidos) ? filesRecibidos : [filesRecibidos]
  const fileObj = filesArray?.[0]
  const file = fileObj?.file ?? fileObj
  if (!file) return

  const productorId = productor.value?.id
  if (!productorId) return

  subiendoPortada.value = true
  try {
    portadaConError.value = false
    portadaTemporal.value = fileObj?.preview ?? (await readFileAsDataURL(file))
    await subirPortadaTienda({
      productorId,
      file,
      rutaActual: productor.value?.portada_storage_path,
    })
    portadaTemporal.value = null
    portadaConError.value = false
    ui.success('Portada actualizada', 'La imagen de fondo de tu tienda ya está publicada')
    await run()
    portadaVersion.value = Date.now()
  } catch (e) {
    portadaTemporal.value = null
    portadaConError.value = false
    ui.error('No se pudo subir la portada', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoPortada.value = false
  }
}

async function onQuitarPortada() {
  const productorId = productor.value?.id
  if (!productorId) return
  subiendoPortada.value = true
  try {
    await quitarPortadaTienda({ productorId, rutaActual: productor.value?.portada_storage_path })
    portadaTemporal.value = null
    portadaConError.value = false
    ui.info('Portada eliminada', 'Se muestra la imagen por defecto de CuTuCo')
    await run()
    portadaVersion.value = Date.now()
  } catch (e) {
    ui.error('No se pudo quitar la portada', e?.message ?? 'Inténtalo de nuevo')
  } finally {
    subiendoPortada.value = false
  }
}

function onErrorCargaPortada(message) {
  ui.error('No se pudo seleccionar la portada', message)
}

function onErrorPortada() {
  if (portadaConError.value) return
  portadaTemporal.value = null
  portadaConError.value = true
  ui.error(
    'No se pudo mostrar la portada',
    'Usaremos la imagen por defecto mientras revisas el archivo.',
  )
}

const estadoPostulacion = computed(() => {
  const estado = postulacion.value?.estado
  if ([ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(estado)) {
    return {
      tone: 'warning',
      titulo: 'Solicitud pendiente de aprobación',
      detalle:
        'Un administrador revisa tus antecedentes antes de habilitar la publicación de productos. Mientras tanto no puedes crear ni editar productos.',
    }
  }
  if (estado === ESTADO_POSTULACION.RECHAZADA) {
    return {
      tone: 'danger',
      titulo: 'Solicitud rechazada',
      detalle: postulacion.value?.observaciones_admin
        ? `Motivo informado por el administrador: ${postulacion.value.observaciones_admin}`
        : 'El administrador rechazó tu solicitud de vendedor.',
    }
  }
  if (estado === ESTADO_POSTULACION.APROBADA) {
    return {
      tone: 'success',
      titulo: 'Solicitud aprobada',
      detalle: 'Tu cuenta está habilitada para publicar productos y gestionar pedidos.',
    }
  }
  return {
    tone: 'neutral',
    titulo: 'Sin solicitud registrada',
    detalle: 'No encontramos una postulación de vendedor asociada a tu cuenta.',
  }
})

const eslogan = computed(() => {
  const descripcion = productor.value?.descripcion ?? ''
  const primera = descripcion.split(/[.·\n]/)[0]?.trim()
  return primera && primera.length > 8 ? primera : 'Cosecha chilena directo del productor'
})

/** Módulos secundarios del panel del productor, tal como los define la navegación. */
const modulos = computed(() =>
  NAV_SECUNDARIO.vendedor.filter((item) => item.to !== '/vendedor/tienda'),
)

const nombreRegionDireccion = computed(() => {
  if (regionActual.value?.nombre) return regionActual.value.nombre
  if (regionIdDireccion.value) {
    const nombre = geo.nombreRegion(regionIdDireccion.value)
    if (nombre && nombre !== '—') return nombre
  }
  return 'Sin región registrada'
})

const nombreComunaDireccion = computed(() => {
  if (comunaActual.value?.nombre) return comunaActual.value.nombre
  const comunaId = direccion.value?.comuna_id
  if (comunaId) {
    const nombre = geo.nombreComuna(comunaId)
    if (nombre && nombre !== '—') return nombre
  }
  return 'Sin comuna registrada'
})

/** Dirección completa visible, con los cuatro campos que conserva la BD. */
const direccionCompleta = computed(() => {
  const d = direccion.value
  if (!d) return ''
  return [d.calle, d.numero, d.depto_oficina, d.referencia].filter(Boolean).join(' · ')
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Perfil de Tienda</h1>
        <p class="page-head__subtitle">
          Datos públicos de tu tienda, ubicación de despacho, datos bancarios y estado de tu
          solicitud.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" to="/vendedor/productos">
          <template #icon><CtIcon name="inventory" :size="16" /></template>
          Ver mi catálogo
        </CtButton>
        <CtButton :loading="guardando" :disabled="!productor" @click="guardarTienda">
          <template #icon><CtIcon name="check" :size="16" /></template>
          Guardar Cambios
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar tu tienda">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-else-if="loading" label="Cargando tu perfil de tienda" />

    <CtAlert v-else-if="!productor" tone="info" title="Todavía no tienes tienda">
      <p>Tu tienda se crea cuando un administrador aprueba tu postulación de productor.</p>
      <CtButton size="sm" variant="secondary" to="/vendedor">Volver al panel</CtButton>
    </CtAlert>

    <template v-else>
      <!-- ============ Portada ============ -->
      <section class="portada">
        <img
          :key="`portada-fondo-${portadaVersion}`"
          class="portada__fondo"
          :src="portadaFondo"
          alt=""
          aria-hidden="true"
          @error="onErrorPortada"
        />
        <div class="portada__texto">
          <p class="eyebrow">Tienda en CuTuCo</p>
          <h2 class="portada__titulo">{{ productor.nombre_comercial }}</h2>
          <p class="portada__eslogan">{{ eslogan }}</p>
          <p class="portada__lugar">
            <CtIcon name="pin" :size="14" />
            {{ nombreComunaDireccion }}, {{ nombreRegionDireccion }}
          </p>
          <div class="portada__chips">
            <CtBadge :tone="productor.activo ? 'success' : 'warning'" variant="solid" dot>
              {{ productor.activo ? 'Tienda activa' : 'Tienda desactivada' }}
            </CtBadge>
            <CtBadge tone="neutral">
              {{
                reputacion.puntaje === null
                  ? 'Sin calificaciones'
                  : `${formatNumber(reputacion.puntaje, 2)} · Reputación`
              }}
            </CtBadge>
            <CtBadge tone="neutral">{{ formatNumber(reputacion.cantidad) }} evaluación(es)</CtBadge>
          </div>
        </div>
        <div class="portada__gauge">
          <p class="eyebrow">Reputación promedio</p>
          <p class="portada__score">
            {{ reputacion.puntaje === null ? '—' : formatNumber(reputacion.puntaje, 2) }}
            <span>/ 5,0</span>
          </p>
          <p class="text-xs">
            {{ formatNumber(reputacion.cantidad) }} calificación(es) de clientes
          </p>
        </div>
      </section>

      <!-- ============ Imagen de portada de la tienda ============ -->
      <CtCard
        title="Imagen de portada"
        subtitle="Foto de fondo que se ve arriba en tu perfil de tienda"
      >
        <div class="portada-editor">
          <figure class="portada-editor__media">
            <img
              :key="`portada-preview-${portadaVersion}`"
              class="portada-editor__preview"
              :src="portadaFondo"
              alt="Vista previa de la portada"
              @error="onErrorPortada"
            />
            <figcaption>Se recorta automáticamente para la cabecera de tu tienda.</figcaption>
          </figure>
          <div class="portada-editor__acciones">
            <CtFileUpload
              :model-value="[]"
              accept="image/jpeg,image/png,image/webp"
              :multiple="false"
              :max="1"
              :disabled="subiendoPortada"
              :loading="subiendoPortada"
              label="Cambiar portada"
              hint="JPG, PNG o WebP · máximo 5 MB"
              @update:model-value="onElegirPortada"
              @error="onErrorCargaPortada"
            />
            <CtButton
              v-if="productor?.portada_storage_path"
              variant="ghost"
              size="sm"
              :disabled="subiendoPortada"
              @click="onQuitarPortada"
            >
              Quitar y usar la imagen por defecto
            </CtButton>
          </div>
        </div>
      </CtCard>

      <div class="grid">
        <div class="col-8 stack stack--lg">
          <CtTabs v-model="tab" :tabs="tabItems" variant="underline" stretch />

          <!-- ============ Información de tienda ============ -->
          <template v-if="tab === 'informacion'">
            <CtCard title="Datos Generales" subtitle="Cómo te ven los compradores en el catálogo">
              <div class="stack">
                <CtInput
                  v-model="form.nombre_comercial"
                  label="Nombre Comercial"
                  required
                  :error="errores.nombre_comercial"
                  hint="Es el nombre que aparece en los pedidos y en tu ficha de tienda. Debe incluir al menos una letra o número."
                />
                <CtTextarea
                  v-model="form.descripcion"
                  label="Descripción de la Tienda"
                  :rows="5"
                  :maxlength="2000"
                  show-count
                  :error="errores.descripcion"
                  hint="Cuenta qué produces, desde cuándo y qué distingue tu producción."
                />
              </div>

              <template #footer>
                <CtButton :loading="guardando" @click="guardarTienda">
                  <template #icon><CtIcon name="check" :size="16" /></template>
                  Guardar nombre y descripción
                </CtButton>
              </template>
            </CtCard>

            <CtCard title="Estado de la tienda" subtitle="Visibilidad y reputación">
              <dl class="datos">
                <div>
                  <dt>Estado de la cuenta</dt>
                  <dd>
                    <CtBadge :tone="productor.activo ? 'success' : 'warning'" size="sm" dot>
                      {{ productor.activo ? 'Activa en el catálogo' : 'Desactivada' }}
                    </CtBadge>
                  </dd>
                </div>
                <div>
                  <dt>Aprobada el</dt>
                  <dd>
                    {{
                      productor.aprobado_en
                        ? formatDate(productor.aprobado_en)
                        : 'Sin fecha de aprobación'
                    }}
                  </dd>
                </div>
                <div>
                  <dt>Reputación promedio</dt>
                  <dd>
                    {{
                      reputacion.puntaje === null
                        ? 'Sin calificaciones'
                        : `${formatNumber(reputacion.puntaje, 2)} / 5,0`
                    }}
                  </dd>
                </div>
                <div>
                  <dt>Evaluaciones recibidas</dt>
                  <dd>{{ formatNumber(reputacion.cantidad) }}</dd>
                </div>
                <div>
                  <dt>Región de despacho</dt>
                  <dd>{{ nombreRegionDireccion }}</dd>
                </div>
              </dl>
              <CtAlert tone="neutral" compact>
                <p>
                  La reputación es el promedio simple de las calificaciones de 1 a 5. No existen
                  pausas automáticas ni sanciones por puntaje: cualquier suspensión la aplica el
                  administrador.
                </p>
              </CtAlert>
            </CtCard>
          </template>

          <!-- ============ Ubicación y datos bancarios ============ -->
          <template v-else-if="tab === 'operativa'">
            <CtCard title="Ubicación de despacho" subtitle="Región y comuna de tu dirección activa">
              <div v-if="direccion" class="ubicacion">
                <div class="ubicacion__resumen">
                  <span class="ubicacion__icono" aria-hidden="true">
                    <CtIcon name="pin" :size="20" />
                  </span>
                  <div class="ubicacion__resumen-texto">
                    <p class="ubicacion__eyebrow">Dirección activa</p>
                    <p class="ubicacion__direccion">
                      {{ direccionCompleta || 'Sin calle registrada' }}
                    </p>
                    <p class="ubicacion__meta">
                      {{ nombreComunaDireccion }}, {{ nombreRegionDireccion }}
                      <span aria-hidden="true">·</span>
                      {{ direccion.es_principal ? 'Dirección principal' : 'Dirección de despacho' }}
                    </p>
                  </div>
                </div>

                <CtAlert tone="info" compact>
                  Sólo puedes vender a clientes de la región de tu dirección activa. Al guardar, el
                  cambio se refleja en el catálogo y el despacho.
                </CtAlert>

                <fieldset class="ubicacion__formulario">
                  <legend>Actualizar dirección de despacho</legend>
                  <div class="form-grid form-grid--ubicacion">
                    <CtSelect
                      v-model="direccionForm.regionId"
                      label="Región"
                      required
                      clearable
                      :options="opcionesRegion"
                      :error="erroresDireccion.regionId"
                      placeholder="Selecciona la región"
                      @update:model-value="alCambiarRegion"
                    />
                    <CtSelect
                      v-model="direccionForm.comunaId"
                      label="Comuna"
                      required
                      :options="opcionesComuna"
                      :error="erroresDireccion.comunaId"
                      :disabled="!direccionForm.regionId"
                      placeholder="Selecciona la comuna"
                      @update:model-value="alCambiarComuna"
                    />
                  </div>

                  <div class="form-grid form-grid--direccion">
                    <CtInput
                      v-model="direccionForm.calle"
                      label="Calle o camino"
                      required
                      :error="erroresDireccion.calle"
                      placeholder="Ruta o camino de acceso al fundo"
                    />
                    <CtInput
                      v-model="direccionForm.numero"
                      label="Número (opcional)"
                      :error="erroresDireccion.numero"
                      placeholder="Kilómetro o número"
                      hint="Puede incluir letras: 12B, km 4, casa 3"
                    />
                  </div>

                  <div class="form-grid form-grid--direccion">
                    <CtInput
                      v-model="direccionForm.deptoOficina"
                      label="Departamento u oficina (opcional)"
                      :error="erroresDireccion.deptoOficina"
                      placeholder="Depto 402, oficina 3, parcela 7"
                      hint="Máximo 50 caracteres"
                    />
                    <CtInput
                      v-model="direccionForm.referencia"
                      label="Referencia de acceso (opcional)"
                      :error="erroresDireccion.referencia"
                      placeholder="Portón verde, frente a la escuela"
                      hint="Máximo 500 caracteres"
                    />
                  </div>
                </fieldset>

                <div class="ubicacion__acciones">
                  <CtButton
                    :loading="guardandoDireccion"
                    :disabled="guardandoDireccion"
                    @click="guardarDireccion"
                  >
                    Guardar dirección
                  </CtButton>
                  <CtButton variant="ghost" :disabled="guardandoDireccion" @click="hidratar">
                    Descartar cambios
                  </CtButton>
                </div>
              </div>

              <CtEmptyState
                v-else
                compact
                icon="pin"
                title="Sin dirección activa"
                message="No encontramos una dirección activa en tu perfil. Mientras no exista, no podrás publicar productos ni recibir pedidos."
              />
            </CtCard>

            <CtCard title="Datos de contacto" subtitle="Teléfono visible para la entrega">
              <div class="form-grid">
                <CtInput
                  v-model="telefono"
                  label="Teléfono"
                  type="tel"
                  placeholder="+56 9 1234 5678"
                  :error="erroresDireccion.telefono"
                  hint="Se guarda en tu perfil de usuario"
                />
                <CtInput
                  :model-value="auth.user?.email ?? ''"
                  label="Correo Electrónico"
                  disabled
                  hint="El correo de la cuenta con la que te registraste no se edita aquí."
                />
              </div>
              <template #footer>
                <CtButton variant="secondary" @click="guardarTelefono">Guardar teléfono</CtButton>
              </template>
            </CtCard>

            <CtCard title="Datos bancarios" subtitle="Respaldo para la verificación de tu tienda">
              <CtAlert tone="info" compact>
                <p>
                  El número de cuenta se guarda cifrado y sólo se muestra enmascarado. El
                  administrador lo usa para verificar la titularidad y gestionar ajustes o
                  devoluciones. Por seguridad no se vuelve a mostrar completo en esta pantalla.
                </p>
              </CtAlert>

              <div class="stack">
                <div class="form-grid">
                  <CtSelect
                    v-model="banco.banco"
                    label="Banco"
                    required
                    :options="opcionesBanco"
                    :error="erroresBanco.banco"
                    placeholder="Selecciona el banco"
                    :disabled="bancoBloqueado"
                  />
                  <CtSelect
                    v-model="banco.tipoCuenta"
                    label="Tipo de cuenta"
                    required
                    :options="TIPOS_CUENTA"
                    :error="erroresBanco.tipoCuenta"
                    placeholder="Selecciona el tipo de cuenta"
                    :disabled="bancoBloqueado"
                  />
                </div>
                <div class="form-grid">
                  <CtInput
                    v-model="banco.numeroCuenta"
                    label="Número de cuenta"
                    required
                    :error="erroresBanco.numeroCuenta"
                    placeholder="000123456789"
                    hint="Se guarda cifrado: escríbelo cada vez que actualices tus datos"
                    :disabled="bancoBloqueado"
                  />
                  <CtInput
                    v-model="banco.rutTitular"
                    label="RUT del titular"
                    required
                    :error="erroresBanco.rutTitular"
                    placeholder="12.345.678-9"
                    :disabled="bancoBloqueado"
                  />
                </div>
                <CtInput
                  v-model="banco.titular"
                  label="Nombre del titular"
                  required
                  :error="erroresBanco.titular"
                  placeholder="Nombre completo del titular de la cuenta"
                  :disabled="bancoBloqueado"
                />

                <CtAlert v-if="bancoBloqueado" tone="warning" compact>
                  <p>
                    Los datos bancarios están bloqueados porque tu postulación ya fue aprobada. Para
                    modificarlos contacta al administrador.
                  </p>
                </CtAlert>

                <CtAlert v-if="datosBancarios" tone="neutral" compact>
                  <p>
                    Datos registrados: <strong>{{ datosBancarios.banco }}</strong> ·
                    {{ etiquetaTipoCuenta(datosBancarios.tipo_cuenta) }} · cuenta
                    {{ datosBancarios.numero_cuenta_enmascarado ?? '—' }} · titular
                    {{ datosBancarios.titular_cuenta }}
                    <template v-if="datosBancarios.rut_titular">
                      ({{ formatRut(datosBancarios.rut_titular) }}) </template
                    >.
                  </p>
                </CtAlert>
                <CtAlert v-else tone="warning" compact>
                  <p>
                    No tienes datos bancarios registrados. Sin ellos no se puede completar la
                    verificación de tu cuenta.
                  </p>
                </CtAlert>

                <div class="row">
                  <CtButton
                    :loading="guardandoBanco"
                    :disabled="bancoBloqueado"
                    @click="guardarBanco"
                  >
                    Guardar datos bancarios
                  </CtButton>
                  <CtButton variant="ghost" :disabled="guardandoBanco" @click="hidratar">
                    Descartar cambios
                  </CtButton>
                </div>
              </div>
            </CtCard>
          </template>

          <!-- ============ Contraseña, solicitud y sanciones ============ -->
          <template v-else>
            <CtCard title="Cambio de contraseña" subtitle="Actualiza tu clave de acceso">
              <div class="stack">
                <CtAlert tone="neutral" compact>
                  <p>
                    La contraseña debe tener al menos
                    {{ REGLAS.SEGURIDAD.passwordMinLength }} caracteres, con letras y números.
                  </p>
                </CtAlert>
                <CtInput
                  v-model="password.actual"
                  type="password"
                  label="Contraseña actual"
                  required
                  :error="erroresPassword.actual"
                  prevent-autofill
                />
                <div class="form-grid">
                  <CtInput
                    v-model="password.nueva"
                    type="password"
                    label="Nueva contraseña"
                    required
                    :error="erroresPassword.nueva"
                    hint="Mínimo 8 caracteres, con letras y números"
                    prevent-autofill
                  />
                  <CtInput
                    v-model="password.confirmar"
                    type="password"
                    label="Confirmar nueva contraseña"
                    required
                    :error="erroresPassword.confirmar"
                    prevent-autofill
                  />
                </div>
                <div class="row">
                  <CtButton :loading="cambiandoPassword" @click="cambiarPassword">
                    Cambiar contraseña
                  </CtButton>
                </div>
              </div>
            </CtCard>

            <CtCard title="Solicitud de vendedor" subtitle="Estado de tu verificación en CuTuCo">
              <div class="stack">
                <CtAlert :tone="estadoPostulacion.tone" :title="estadoPostulacion.titulo">
                  <p>{{ estadoPostulacion.detalle }}</p>
                </CtAlert>

                <dl class="datos">
                  <div>
                    <dt>Estado</dt>
                    <dd>
                      <StatusBadge
                        v-if="postulacion"
                        type="postulacion"
                        :value="postulacion.estado"
                        size="sm"
                      />
                      <CtBadge v-else tone="neutral" size="sm">Sin postulación</CtBadge>
                    </dd>
                  </div>
                  <div>
                    <dt>Nombre comercial solicitado</dt>
                    <dd>{{ postulacion?.nombre_comercial_solicitado ?? '—' }}</dd>
                  </div>
                  <div>
                    <dt>Solicitada el</dt>
                    <dd>
                      {{ postulacion?.creado_en ? formatDateTime(postulacion.creado_en) : '—' }}
                    </dd>
                  </div>
                  <div>
                    <dt>Revisada el</dt>
                    <dd>
                      {{
                        postulacion?.revisado_en
                          ? formatDateTime(postulacion.revisado_en)
                          : 'Pendiente de revisión'
                      }}
                    </dd>
                  </div>
                </dl>

                <CtAlert
                  v-if="postulacion?.observaciones_admin"
                  tone="warning"
                  compact
                  title="Observaciones del administrador"
                >
                  <p>{{ postulacion.observaciones_admin }}</p>
                </CtAlert>
              </div>
            </CtCard>

            <CtCard title="Sanciones vigentes" subtitle="Amonestaciones, suspensiones y bans">
              <CtEmptyState
                v-if="!sancionesVigentes.length"
                compact
                icon="shieldCheck"
                title="Sin sanciones vigentes"
                message="Tu cuenta no tiene amonestaciones, suspensiones ni bans activos."
              />

              <ul v-else class="sanciones">
                <li v-for="sancion in sancionesVigentes" :key="sancion.id" class="sancion">
                  <div>
                    <p class="text-sm font-semibold">
                      {{ LABELS.accionSancion[sancion.accion] ?? sancion.accion }} ·
                      {{ LABELS.tipoSancion[sancion.tipo] ?? sancion.tipo }}
                    </p>
                    <p class="text-xs text-muted">
                      Desde {{ formatDate(sancion.inicio_en) }}
                      <template v-if="sancion.fin_en">
                        · hasta {{ formatDate(sancion.fin_en) }}</template
                      >
                      <template v-else> · sin fecha de término</template>
                    </p>
                    <p v-if="sancion.motivo" class="text-xs text-muted">
                      Motivo: {{ sancion.motivo }}
                    </p>
                  </div>
                  <StatusBadge type="sancion" :value="sancion.estado" size="sm" />
                </li>
              </ul>

              <CtAlert v-if="sancionesVigentes.length" tone="danger" compact>
                <p>
                  Mientras tengas una sanción vigente no puedes publicar ni vender productos. La
                  revisión de tu caso la decide el administrador de forma manual.
                </p>
              </CtAlert>

              <template #footer>
                <CtButton size="sm" variant="ghost" to="/vendedor/productos">
                  Revisar mis productos
                </CtButton>
              </template>
            </CtCard>
          </template>
        </div>

        <!-- ============ Columna derecha ============ -->
        <div class="col-4 stack">
          <CtCard title="Estado del vendedor" subtitle="Resumen de tu cuenta">
            <ul class="estado">
              <li>
                <div class="row row--between">
                  <span class="text-sm">Solicitud de vendedor</span>
                  <StatusBadge
                    v-if="postulacion"
                    type="postulacion"
                    :value="postulacion.estado"
                    size="sm"
                  />
                  <CtBadge v-else tone="neutral" size="sm">Sin registrar</CtBadge>
                </div>
              </li>
              <li>
                <div class="row row--between">
                  <span class="text-sm">Tienda</span>
                  <CtBadge :tone="productor.activo ? 'success' : 'warning'" size="sm">
                    {{ productor.activo ? 'Activa' : 'Desactivada' }}
                  </CtBadge>
                </div>
              </li>
              <li>
                <div class="row row--between">
                  <span class="text-sm">Datos bancarios</span>
                  <CtBadge :tone="datosBancarios ? 'success' : 'warning'" size="sm">
                    {{ datosBancarios ? 'Registrados' : 'Pendientes' }}
                  </CtBadge>
                </div>
              </li>
              <li>
                <div class="row row--between">
                  <span class="text-sm">Sanciones vigentes</span>
                  <CtBadge :tone="sancionesVigentes.length ? 'danger' : 'success'" size="sm">
                    {{ formatNumber(sancionesVigentes.length) }}
                  </CtBadge>
                </div>
              </li>
              <li>
                <div class="row row--between">
                  <span class="text-sm">Región de despacho</span>
                  <span class="text-xs text-muted">{{ nombreRegionDireccion }}</span>
                </div>
              </li>
            </ul>
          </CtCard>

          <CtCard title="Soporte CuTuCo" subtitle="Antes de escalar, revisa estos puntos">
            <ul class="soporte">
              <li>
                <CtIcon name="truck" :size="15" />
                <span>Entregas y código de verificación</span>
              </li>
              <li>
                <CtIcon name="wallet" :size="15" />
                <span>Datos bancarios y verificación</span>
              </li>
              <li>
                <CtIcon name="shield" :size="15" />
                <span>Aprobación de la cuenta y sanciones</span>
              </li>
            </ul>
            <div class="row row--wrap">
              <CtButton
                v-for="modulo in modulos"
                :key="modulo.to"
                size="sm"
                variant="ghost"
                :to="modulo.to"
              >
                <template #icon><CtIcon :name="modulo.icon" :size="15" /></template>
                {{ modulo.label }}
              </CtButton>
            </div>
          </CtCard>
        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.portada {
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-6);
  flex-wrap: wrap;
  padding: var(--ct-space-8);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-ink);
  color: var(--ct-text-invert);
}

.portada__fondo {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.45;
  pointer-events: none;
}

.portada__texto,
.portada__gauge {
  position: relative;
}

.portada__texto {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.portada__titulo {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

.portada__eslogan {
  font-size: var(--ct-fs-lg);
  color: var(--ct-primary-soft);
}

.portada__lugar {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-md);
  color: var(--ct-primary-soft);
}

.portada__chips {
  display: flex;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  margin-top: var(--ct-space-2);
}

.portada__gauge {
  min-width: 220px;
}

/* El eyebrow dentro de la portada (fondo oscuro con foto) va en blanco. */
.portada .eyebrow {
  color: var(--ct-text-invert);
}

/* Editor de portada de la tienda */
.portada-editor {
  display: grid;
  grid-template-columns: minmax(240px, 380px) minmax(0, 1fr);
  align-items: start;
  gap: var(--ct-space-6);
}

.portada-editor__media {
  margin: 0;
}

.portada-editor__preview {
  display: block;
  width: 100%;
  aspect-ratio: 16 / 7;
  height: auto;
  object-fit: cover;
  border-radius: var(--ct-radius-lg);
  border: 1px solid var(--ct-border);
  background: var(--ct-ink);
}

.portada-editor__media figcaption {
  margin-top: var(--ct-space-2);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.portada-editor__acciones {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  min-width: 0;
}

.portada-editor__acciones > * {
  width: 100%;
}

@media (max-width: 700px) {
  .portada-editor {
    grid-template-columns: 1fr;
    gap: var(--ct-space-4);
  }
}

.portada__score {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

.portada__score span {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-primary-soft);
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--ct-space-4);
}

.ubicacion {
  display: grid;
  gap: var(--ct-space-5);
}

.ubicacion__resumen {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface-alt);
}

.ubicacion__icono {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  flex: 0 0 auto;
  border-radius: 50%;
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.ubicacion__resumen-texto {
  min-width: 0;
}

.ubicacion__eyebrow,
.ubicacion__direccion,
.ubicacion__meta {
  margin: 0;
}

.ubicacion__eyebrow {
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--ct-text-soft);
}

.ubicacion__direccion {
  margin-top: var(--ct-space-1);
  font-weight: var(--ct-fw-semibold);
  overflow-wrap: anywhere;
}

.ubicacion__meta {
  margin-top: var(--ct-space-1);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.ubicacion__formulario {
  display: grid;
  gap: var(--ct-space-4);
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}

.ubicacion__formulario legend {
  padding: 0;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-semibold);
}

.form-grid--direccion {
  grid-template-columns: minmax(0, 2fr) minmax(220px, 1fr);
}

.ubicacion__acciones {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
}

@media (max-width: 700px) {
  .form-grid--direccion {
    grid-template-columns: 1fr;
  }

  .ubicacion__acciones,
  .ubicacion__acciones .ct-button {
    width: 100%;
  }
}

.estado,
.sanciones,
.soporte {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.sancion {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.sancion:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.datos div {
  display: flex;
  justify-content: space-between;
  gap: var(--ct-space-4);
}

.datos dt {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.datos dd {
  margin: 0;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  text-align: right;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.soporte li {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}
</style>
