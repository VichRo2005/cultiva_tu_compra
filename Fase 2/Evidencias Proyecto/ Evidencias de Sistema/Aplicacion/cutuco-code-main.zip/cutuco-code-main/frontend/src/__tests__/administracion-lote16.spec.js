/**
 * CuTuCo — Lote 16 (Administración y cobros), lado frontend.
 *
 * CK-0268: dashboard operativo con pendientes (KYB/sanciones/servicio) y
 * enlaces a cada módulo. CK-0269: bandeja vacía explícita ("Sin pendientes").
 * CK-0275: ubicaciones fijas — la vista geográfica es de sólo lectura, sin CRUD.
 * CK-0402: rechazar pago exige observación no vacía en la interfaz.
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0268 · dashboard operativo con pendientes y acceso a módulos', () => {
  it('muestra pendientes de postulaciones, sanciones y servicio con enlaces', () => {
    const v = src('views/admin/AdminDashboardView.vue')
    expect(v).toContain('getPendientesAdmin')
    expect(v).toContain('listServiciosAdmin')
    for (const ruta of ['/admin/moderacion', '/admin/sanciones', '/admin/servicios', '/admin/pagos']) {
      expect(v).toContain(ruta)
    }
    expect(v).not.toContain('Accesos del panel')
    expect(v).toContain('Revisar') // botón que lleva al módulo que ejecuta la acción
  })
})

describe('CK-0269 · bandeja vacía explícita', () => {
  it('hay estado vacío con texto claro cuando no hay pendientes', () => {
    const v = src('views/admin/AdminDashboardView.vue')
    expect(v).toContain('Sin pendientes')
    expect(v).toMatch(/No hay postulaciones ni sanciones esperando tu revisión/)
    expect(v).toContain('Sin sanciones activas')
    // y los errores de consulta no se muestran como cero (servicio lanza)
    const admin = src('services/admin.js')
    expect(admin).toContain('No se pudieron cargar los pendientes administrativos')
  })
})

describe('CK-0275 · ubicaciones fijas sin CRUD geográfico administrativo', () => {
  it('la vista geográfica no inserta ni modifica regiones/comunas', () => {
    const v = src('views/admin/AdminGeographyView.vue')
    expect(v).toMatch(/regiones|comunas/i)
    for (const prohibido of ['.insert(', '.update(', '.upsert(', '.delete(']) {
      expect(v).not.toContain(prohibido)
    }
    // ningún servicio admin escribe sobre catálogos geográficos
    for (const servicio of ['services/admin.js', 'services/adminCatalog.js', 'services/adminGeography.js']) {
      try {
        const s = src(servicio)
        expect(s).not.toMatch(/from\('(regiones|comunas)'\)\s*\.\s*(insert|update|upsert|delete)/)
      } catch {
        /* servicio no existe: no hay CRUD */
      }
    }
  })
})

describe('CK-0402 · observación obligatoria al rechazar pago (interfaz)', () => {
  it('el botón de rechazo se deshabilita sin observación y el servidor también la exige', () => {
    const v = src('views/admin/AdminServicesView.vue')
    expect(v).toContain('Obligatorio al rechazar')
    expect(v).toMatch(/:disabled="!observaciones\.trim\(\)"/)
    expect(v).toContain("resolver('rechazado')")
    const servicio = src('services/servicio.js')
    expect(servicio).toContain('resolverPagoServicio')
    expect(servicio).toContain("rpc('resolver_pago_servicio'")
  })
})

describe('Configuración de cuenta para transferencias del servicio', () => {
  it('permite a administración completar y publicar los cinco datos bancarios', () => {
    const v = src('views/admin/AdminServicesView.vue')
    for (const etiqueta of ['Banco', 'Tipo de cuenta', 'Número de cuenta', 'Titular', 'RUT']) {
      expect(v).toContain(`label="${etiqueta}"`)
    }
    expect(v).toContain('obtenerDatosTransferenciaCutuco')
    expect(v).toContain('actualizarDatosTransferenciaCutuco')
    expect(v).toContain('Guardar y publicar datos')
  })
})
