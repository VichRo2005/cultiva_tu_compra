<script setup>
/**
 * CuTuCo — Portada pública (página 1 del diseño).
 * Secciones a sangre con `.container` interno, sin repetir el cromo del shell.
 */
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import ProductGrid from '@/components/domain/ProductGrid.vue'
import {
  filtrarCategoriasVisibles,
  filtrarProductosVisibles,
  getArbolCategorias,
  listProductos,
} from '@/services/catalog'
import { useCartStore } from '@/stores/cart'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import heroFondoUrl from '@/assets/fondo-agro.jpg'

const router = useRouter()
const geo = useGeographyStore()
const cart = useCartStore()
const ui = useUiStore()

const heroFondo = heroFondoUrl

const cargando = ref(true)
const error = ref(null)
const recomendados = ref([])
const categorias = ref([])

const CONFIANZA = [
  { icon: 'shieldCheck', title: 'Productores Verificados', text: 'La cuenta se activa después de la revisión de antecedentes.' },
  { icon: 'truck', title: 'Entrega Verificada', text: 'La entrega se cierra con el código de verificación que recibe el cliente.' },
  { icon: 'store', title: 'Directo del Productor', text: 'Cada pedido sale de la tienda del productor y llega sin intermediarios.' },
]

const POR_QUE = [
  {
    icon: 'scale',
    title: 'Transparencia en cada precio',
    text: 'El precio que publica el productor es el que pagas, con la tarifa de despacho informada antes de confirmar.',
  },
  {
    icon: 'lock',
    title: 'Pago seguro con Webpay',
    text: 'Pagas de forma segura con Webpay. El productor recibe el pago de su venta y CuTuCo descuenta su comisión.',
  },
  {
    icon: 'check',
    title: 'Código de verificación',
    text: 'El cliente recibe un código único para el pedido: sin ese código la entrega no se marca como entregada.',
  },
  {
    icon: 'reports',
    title: 'Eficiencia en la cadena',
    text: 'Del productor al comprador sin intermediarios que inflen el costo.',
  },
]

async function cargar() {
  // El catálogo es independiente de los selectores geográficos: cargarlo de
  // inmediato evita que la portada quede en placeholders por esa consulta.
  void geo.load()

  cargando.value = true
  error.value = null
  try {
    // RF-022: portada pública sin sesión. Se muestran sólo productos con stock
    // y las últimas publicaciones creadas en CuTuCo.
    // NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): la sección "Cosecha
    // del día" usaba `listProductos({ soloCosechaDia: true })`; ese filtro no
    // existe en el servicio ni en el esquema vigente (salió del alcance).
    const [recs, cats] = await Promise.all([
      listProductos({ orden: 'relevancia', soloStock: true, pageSize: 12 }),
      getArbolCategorias(),
    ])
    recomendados.value = filtrarProductosVisibles(recs.items)
      .filter((p) => Number(p.stock) > 0)
      .slice(0, 8)
    // HAL-CLI-021: "Alimentos para mascotas" y sus subcategorías no se ofrecen.
    categorias.value = filtrarCategoriasVisibles(cats).slice(0, 8)
  } catch (e) {
    error.value = e.message
  } finally {
    cargando.value = false
  }
}

onMounted(cargar)

function agregar(producto) {
  try {
    cart.agregar(producto)
    ui.success('Producto agregado', `${producto.nombre} está en tu carrito`)
  } catch (e) {
    ui.error('No se pudo agregar', e.message)
  }
}

function abrirCategoria(categoriaId) {
  router.push({ path: '/catalogo', query: { categoria: categoriaId } })
}

function reintentar() {
  cargar()
}
</script>

<template>
  <div class="home">
    <!-- ===================== HERO ===================== -->
    <section class="hero hero-dark">
      <img class="hero__fondo" :src="heroFondo" alt="" aria-hidden="true" />
      <div class="hero__layout">
        <div class="hero__inner">
          <p class="eyebrow hero__eyebrow">Marketplace agrícola · Productores AFC de Chile</p>
          <h1 class="hero__title">El Campo Chileno en tu Pantalla</h1>
          <p class="hero__lead">Conecta con lo mejor del campo chileno, directo del productor.</p>
          <p class="hero__slogan">Transparencia y Eficiencia en cada Cosecha.</p>
          <p class="hero__text">
            Conectamos a productores locales directamente con mayoristas y minoristas. Una cadena de
            suministro tecnificada para el agro chileno moderno.
          </p>
          <div class="hero__acciones">
            <CtButton size="lg" to="/catalogo">Explorar Catálogo</CtButton>
            <CtButton
              size="lg"
              variant="dark"
              :to="{ name: 'home', hash: '#quiero-vender-en-cutuco' }"
            >
              Soy Productor
            </CtButton>
          </div>
        </div>
        <div class="hero__side">
          <article v-for="item in CONFIANZA" :key="item.title" class="hero__mini">
            <span class="hero__mini-icon" aria-hidden="true">
              <CtIcon :name="item.icon" :size="20" />
            </span>
            <div>
              <h2 class="hero__mini-title">{{ item.title }}</h2>
              <p class="hero__mini-text">{{ item.text }}</p>
            </div>
          </article>
        </div>
      </div>
    </section>

    <div class="container page">
      <CtAlert v-if="error" tone="danger" title="No pudimos cargar la portada">
        {{ error }}
        <CtButton variant="secondary" size="sm" type="button" @click="reintentar">
          Reintentar
        </CtButton>
      </CtAlert>

      <CtSpinner v-if="cargando" label="Cargando el catálogo público" />

      <template v-else>
        <!--
          NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
          aquí iba la sección destacada "Cosecha del día" (`cosechaDelDia`). El
          sello de cosecha del mismo día y su filtro salieron del ERS, así que
          la portada muestra un único bloque de catálogo con stock disponible.
        -->

        <!-- ===================== CATEGORÍAS ===================== -->
        <section v-if="categorias.length" class="bloque">
          <header class="bloque__head">
            <div class="bloque__text">
              <h2 class="bloque__titulo">Explora por categoría</h2>
              <p class="bloque__subtitulo">Directas del campo a tu mesa</p>
            </div>
          </header>
          <div class="categorias">
            <button
              v-for="categoria in categorias"
              :key="categoria.id"
              type="button"
              class="categoria"
              @click="abrirCategoria(categoria.id)"
            >
              <span class="categoria__nombre">{{ categoria.nombre }}</span>
              <span class="categoria__conteo">
                {{ categoria.hijos?.length ? `${categoria.hijos.length} subcategorías` : 'Ver productos' }}
              </span>
            </button>
          </div>
        </section>

        <!-- ===================== RECOMENDADOS ===================== -->
        <section class="bloque">
          <header class="bloque__head">
            <div class="bloque__text">
              <h2 class="bloque__titulo">Productos disponibles</h2>
              <p class="bloque__subtitulo">Lo último que llegó al catálogo de CuTuCo</p>
            </div>
            <CtButton variant="secondary" to="/catalogo">Ver Todo el Catálogo</CtButton>
          </header>

          <ProductGrid
            v-if="recomendados.length"
            :productos="recomendados"
            show-rating
            show-category
            @add="agregar"
          />
          <CtEmptyState
            v-else
            title="Todavía no hay productos publicados"
            message="Estamos validando nuevos productores. Vuelve pronto para ver sus cosechas."
          >
            <CtButton variant="secondary" to="/catalogo">Explorar el catálogo</CtButton>
          </CtEmptyState>
        </section>

        <!-- ===================== POR QUÉ ELEGIR CUTUCO ===================== -->
        <section class="bloque">
          <header class="bloque__head">
            <div class="bloque__text">
              <h2 class="bloque__titulo">Por qué elegir CuTuCo</h2>
              <p class="bloque__subtitulo">Una cadena de suministro pensada para el agro chileno</p>
            </div>
          </header>
          <div class="porque">
            <article v-for="item in POR_QUE" :key="item.title" class="porque__card">
              <span class="porque__icon" aria-hidden="true">
                <CtIcon :name="item.icon" :size="20" />
              </span>
              <h3 class="porque__titulo">{{ item.title }}</h3>
              <p class="porque__texto">{{ item.text }}</p>
            </article>
          </div>
        </section>

      </template>

      <!-- Se conserva fuera de la carga del catálogo: así los enlaces con hash
           pueden desplazar hasta este CTA desde cualquier ruta. -->
      <section
        id="quiero-vender-en-cutuco"
        class="institucional hero-dark"
        tabindex="-1"
        aria-labelledby="quiero-vender-en-cutuco-titulo"
      >
        <div class="institucional__inner">
          <div>
            <h2 id="quiero-vender-en-cutuco-titulo" class="institucional__titulo">
              ¿Cultivas y quieres vender en CuTuCo?
            </h2>
            <p class="institucional__texto">
              Publica tu cosecha, define la zona donde entregas y recibe directamente de tus
              clientes, con el pago protegido por la plataforma. Tu cuenta queda pendiente de
              aprobación hasta que revisemos tus antecedentes.
            </p>
          </div>
          <CtButton size="lg" to="/registro-vendedor">Crear cuenta de productor</CtButton>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
/* ===================== HERO ===================== */

.home {
  margin-top: calc(-1 * var(--ct-space-8));
}

.page {
  background: #f7f7f8;
  border-radius: var(--ct-radius-lg);
  padding: var(--ct-space-6);
}

.hero {
  position: relative;
  overflow: hidden;
  padding-block: var(--ct-space-20) var(--ct-space-16);
  background: transparent;
}

.hero__fondo {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 1;
  pointer-events: none;
}

.hero__layout {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: var(--ct-space-8);
  width: 100%;
  max-width: var(--ct-container);
  margin-inline: auto;
  padding-inline: var(--ct-gutter);
}

.hero__inner {
  position: relative;
  z-index: 1;
  flex-shrink: 0;
  width: 560px;
  max-width: 560px;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  background: rgba(23, 59, 87, 0.85);
  padding: var(--ct-space-6);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-md);
}

.hero__side {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.hero__mini {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  background: rgba(255, 255, 255, 0.88);
  padding: var(--ct-space-4);
  border-radius: var(--ct-radius-md);
  box-shadow: var(--ct-shadow-sm);
  color: var(--ct-text);
}

.hero__mini-icon {
  width: 38px;
  height: 38px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-primary);
  color: var(--ct-text-invert);
}

.hero__mini-title {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.hero__mini-text {
  margin-top: 2px;
  font-size: var(--ct-fs-sm);
  line-height: var(--ct-lh-normal);
  color: var(--ct-text-soft);
}

@media (max-width: 980px) {
  .hero__layout {
    flex-direction: column;
    align-items: stretch;
  }

  .hero__inner {
    width: 100%;
    max-width: 100%;
  }
}

.hero__eyebrow {
  color: var(--ct-accent);
}

.hero__title {
  margin-top: var(--ct-space-2);
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  line-height: 1.1;
  letter-spacing: -0.03em;
  text-wrap: balance;
  color: var(--ct-text-invert);
}

.hero__lead {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-invert);
  opacity: 1;
}

.hero__slogan {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-accent);
}

.hero__text {
  font-size: var(--ct-fs-sm);
  line-height: var(--ct-lh-relaxed);
  color: var(--ct-text-on-dark-soft);
  max-width: 48ch;
}

.hero__acciones {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-4);
}

/* ===================== CONFIANZA ===================== */

.confianza {
  background: var(--ct-surface);
  padding-block: var(--ct-space-10);
}

.confianza__grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--ct-space-6);
}

.confianza__card {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.confianza__icon {
  width: 46px;
  height: 46px;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-primary);
  color: var(--ct-text-invert);
}

.confianza__title {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.confianza__text {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
}

/* ===================== BLOQUES ===================== */

.bloque {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.bloque__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--ct-space-4);
}

.bloque__titulo {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
}

.bloque__subtitulo {
  margin-top: var(--ct-space-1);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-md);
}

/* ===================== CATEGORÍAS ===================== */

.categorias {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: var(--ct-space-3);
}

.categoria {
  display: flex;
  flex-direction: column;
  gap: 2px;
  text-align: left;
  padding: var(--ct-space-4);
  border-radius: var(--ct-radius-md);
  border: 1px solid var(--ct-border);
  background: var(--ct-surface);
  transition:
    border-color var(--ct-transition),
    background-color var(--ct-transition);
}

.categoria:hover {
  border-color: var(--ct-primary);
  background: var(--ct-primary-softer);
}

.categoria__nombre {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text);
}

.categoria__conteo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

/* ===================== PRODUCTORES ===================== */

/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 * la tarjeta de productores de la portada leía `comuna_origen_id`, columna que
 * no existe en `productores` (la ubicación vive en `direcciones`/`comunas`), y
 * anunciaba "cobertura definida" y geolocalización, ambas fuera del ERS. El
 * perfil público del vendedor se consulta ahora en `/vendedores/:id`. Estas
 * reglas se conservan tal cual para no alterar el diseño existente.
 */
.productores {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: var(--ct-space-5);
}

.productor {
  gap: var(--ct-space-3);
}

.productor__head {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
}

.productor__icon {
  width: 42px;
  height: 42px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-accent-soft);
  color: var(--ct-accent-strong);
}

.productor__identidad {
  flex: 1;
  min-width: 0;
}

.productor__nombre {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
}

.productor__lugar {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.productor__descripcion {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.productor__meta {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
  padding-top: var(--ct-space-3);
  border-top: 1px solid var(--ct-border);
}

/* ===================== POR QUÉ ===================== */

.porque {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--ct-space-5);
}

.porque__card {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-6);
  background: var(--ct-surface);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  box-shadow: var(--ct-shadow-xs);
}

.porque__icon {
  width: 42px;
  height: 42px;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-primary);
  color: var(--ct-text-invert);
}

.porque__titulo {
  font-size: var(--ct-fs-base);
  font-weight: var(--ct-fw-semibold);
}

.porque__texto {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
}

/* ===================== INSTITUCIONAL ===================== */

.institucional {
  scroll-margin-top: var(--ct-space-6);
  border-radius: var(--ct-radius-xl);
  padding: var(--ct-space-10);
}

.institucional__inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-8);
  flex-wrap: wrap;
}

.institucional__titulo {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
  color: var(--ct-text-invert);
}

.institucional__texto {
  margin-top: var(--ct-space-2);
  color: var(--ct-text-invert);
  max-width: 62ch;
  line-height: var(--ct-lh-relaxed);
}

@media (max-width: 980px) {
  .confianza__grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
