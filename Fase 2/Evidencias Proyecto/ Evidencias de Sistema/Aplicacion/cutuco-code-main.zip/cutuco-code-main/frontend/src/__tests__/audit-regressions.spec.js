import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import { nextTick } from 'vue'
import { readFileSync } from 'node:fs'

import CtAlert from '@/components/base/CtAlert.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import { visibleSections } from '@/lib/navigation'
import { netoProductor } from '@/lib/orders'
import { OfflineSupabaseClient } from '@/lib/offlineClient'
import { ACCION_SANCION, ESTADO_SANCION, POSTULACIONES_PENDIENTES } from '@/lib/constants'
import { sancionVigente } from '@/services/session'

describe('regresiones de la auditoría', () => {
  it('una amonestación no bloquea la tienda; una suspensión o un ban sí', () => {
    const base = { estado: ESTADO_SANCION.ACTIVA, fin_en: null }
    expect(sancionVigente({ ...base, accion: ACCION_SANCION.NINGUNA })).toBe(false)
    expect(sancionVigente({ ...base, accion: ACCION_SANCION.SUSPENDER, fin_en: '2999-01-01' })).toBe(
      true,
    )
    expect(
      sancionVigente({ ...base, accion: ACCION_SANCION.SUSPENDER, fin_en: '2000-01-01' }),
    ).toBe(false)
    expect(sancionVigente({ ...base, accion: ACCION_SANCION.BAN_PERMANENTE })).toBe(true)
  })

  it('el neto del productor se deriva del total y la comisión (columna eliminada)', () => {
    expect(netoProductor({ total: 10000, monto_fee_plataforma: 500 })).toBe(9500)
    expect(netoProductor({ total: 3500, monto_fee_plataforma: 0 })).toBe(3500)
    expect(netoProductor({ total: 100, monto_fee_plataforma: 500 })).toBe(0)
  })

  it('la navegación no muestra secciones de otro rol', () => {
    const admin = visibleSections('admin', { isAuthenticated: true })
    // El administrador sólo ve su panel: no hereda Inicio ni Catálogo.
    expect(admin.map((s) => s.key)).toEqual(['administracion'])
    const adminItems = admin.flatMap((s) => s.items.map((i) => i.to))
    expect(adminItems).not.toContain('/')
    expect(adminItems).not.toContain('/catalogo')
    const vendedor = visibleSections('vendedor', { isAuthenticated: true })
    // HAL-VEN-002: el vendedor sólo ve funciones de su operación; no hereda
    // Inicio, Catálogo, Mis Direcciones, carrito ni buscador de comprador.
    expect(vendedor.map((s) => s.key)).toEqual(['vendedor'])
    expect(vendedor[0].items.map((i) => i.to)).not.toContain('/direcciones')
    expect(vendedor[0].items.map((i) => i.to)).not.toContain('/carrito')
    const cliente = visibleSections('cliente', { isAuthenticated: true })
    expect(cliente.map((s) => s.key)).toEqual(['general'])
    const invitado = visibleSections(null, { isAuthenticated: false })
    expect(invitado[0].items.map((i) => i.to)).toEqual(['/', '/catalogo'])
  })

  it('CtInput aplica tamaño/error y enlaza el mensaje con aria-describedby', () => {
    const wrapper = mount(CtInput, {
      props: { label: 'Correo', size: 'sm', error: 'Correo inválido' },
      attachTo: document.body,
    })
    expect(wrapper.classes()).toContain('ct-field--sm')
    expect(wrapper.classes()).toContain('ct-field--error')
    const input = wrapper.find('input')
    const error = wrapper.find('.ct-field__error')
    expect(wrapper.find('label').attributes('for')).toBe(input.attributes('id'))
    expect(error.attributes('role')).toBe('alert')
    expect(input.attributes('aria-describedby')).toBe(error.attributes('id'))
    wrapper.unmount()
  })

  it('CtModal tiene nombre accesible y lleva el foco al panel', async () => {
    const wrapper = mount(CtModal, {
      props: { modelValue: false, title: 'Confirmar pedido' },
      attachTo: document.body,
    })
    await wrapper.setProps({ modelValue: true })
    await nextTick()
    await nextTick()
    const dialog = document.querySelector('[role="dialog"]')
    expect(dialog).toBeTruthy()
    expect(dialog.getAttribute('aria-labelledby')).toBeTruthy()
    expect(dialog.getAttribute('aria-modal')).toBe('true')
    expect(document.activeElement?.classList.contains('ct-modal__panel')).toBe(true)
    await wrapper.setProps({ modelValue: false })
    wrapper.unmount()
  })

  it('CtAlert anuncia los errores como alert y el resto como status', () => {
    const error = mount(CtAlert, { props: { tone: 'danger', title: 'Error' } })
    expect(error.attributes('role')).toBe('alert')
    const info = mount(CtAlert, { props: { tone: 'info', title: 'Info' } })
    expect(info.attributes('role')).toBe('status')
    error.unmount()
    info.unmount()
  })

  it('la consulta de postulaciones pendientes usa sólo el enum vigente', () => {
    // Un `.in()` con `pendiente_aprobacion` (renombrado a en_revision) hace que
    // PostgREST responda 400 y la bandeja del admin quede vacía.
    expect(POSTULACIONES_PENDIENTES).toEqual(['en_revision'])
  })

  it('el servicio del vendedor no vuelve a consultar la columna eliminada', () => {
    // Vitest se ejecuta desde frontend/: la ruta relativa es estable.
    const fuente = readFileSync('src/services/seller.js', 'utf8')
    // `monto_liquidar_productor` fue eliminada por la migración Webpay Mall;
    // un select a esa columna tumba el panel completo con 42703.
    expect(fuente).not.toContain('monto_liquidar_productor')
  })

  it('las fotos del seed demo se sirven como ilustración, no como offline:// roto', () => {
    const client = new OfflineSupabaseClient()
    const { data } = client.storage
      .from('product-images')
      .getPublicUrl('product-images/pr-lechuga/lechugas.webp')
    expect(data.publicUrl.startsWith('data:image/svg+xml')).toBe(true)
    expect(data.publicUrl.startsWith('offline://')).toBe(false)
  })
})
