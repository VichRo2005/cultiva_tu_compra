<script setup>
/**
 * CuTuCo — Regiones, comunas y cobertura (prototipo anterior).
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no está en el menú del producto):
 *   Ventana conservada para la GALERÍA DE DESARROLLO (`VITE_DEV_GALLERY=true`).
 *   La cobertura por comuna (RF-009 v1) salió del alcance: el ERS vigente
 *   compara sólo regiones mediante `productores.region_id` (RF-009 v2), y las
 *   categorías, regiones y comunas se consultan para los combobox (RF-018), sin
 *   administrarse desde el panel (RF-004).
 *
 *   Opera sobre la tabla `coberturas_productor`, declarada como HERRAMIENTA DE
 *   DESARROLLO en la migración `20261006100000_add_gallery_legacy_tables.sql`.
 */import { computed, onMounted, ref, watch } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import { LABELS, TIPO_COBERTURA } from '@/lib/constants'
import { formatDate, formatNumber } from '@/lib/format'
import { listProductores } from '@/services/catalog'
import { listCoberturas, removeCobertura, setCobertura } from '@/services/geography'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const geo = useGeographyStore()

const regionSeleccionadaId = ref(null)
const texto = ref('')
const productores = ref([])
const productorId = ref(null)
const coberturas = ref([])
const loading = ref(true)
const loadingCoberturas = ref(false)
const error = ref(null)
const guardando = ref(false)

const nuevaCobertura = ref({ tipo: TIPO_COBERTURA.REGION, regionId: null, comunaId: null })
const eliminacion = ref({ abierto: false, cobertura: null })

const columnasComunas = [
  { key: 'codigo', label: 'Código' },
  { key: 'nombre', label: 'Comuna', width: '45%' },
  { key: 'productores', label: 'Productores en la comuna' },
]

const columnasCoberturas = [
  { key: 'tipo', label: 'Tipo' },
  { key: 'destino', label: 'Destino' },
  { key: 'estado', label: 'Estado' },
  { key: 'creado', label: 'Registrada' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const regionSeleccionada = computed(
  () => geo.regiones.find((r) => r.id === regionSeleccionadaId.value) ?? null,
)

const opcionesProductor = computed(() =>
  productores.value.map((p) => ({ value: p.id, label: p.nombre_comercial })),
)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)

const opcionesComuna = computed(() => {
  const lista = regionSeleccionadaId.value
    ? geo.comunasDeRegion(regionSeleccionadaId.value)
    : [...geo.comunas].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))
  return lista.map((c) => ({ value: c.id, label: c.nombre, group: geo.nombreRegion(c.region_id) }))
})

const productorSeleccionado = computed(
  () => productores.value.find((p) => p.id === productorId.value) ?? null,
)

const comunasVisibles = computed(() => {
  const busqueda = texto.value.trim().toLowerCase()
  const lista = regionSeleccionadaId.value ? geo.comunasDeRegion(regionSeleccionadaId.value) : geo.comunas
  const ordenadas = [...lista].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))
  if (!busqueda) return ordenadas
  return ordenadas.filter(
    (c) => c.nombre.toLowerCase().includes(busqueda) || c.codigo.toLowerCase().includes(busqueda),
  )
})

/** Comunas con al menos un productor que las cubre, a partir de las coberturas cargadas. */
const coberturaPorComuna = computed(() => {
  const conteo = {}
  for (const c of coberturas.value) {
    if (!c.activo) continue
    if (c.tipo_cobertura === TIPO_COBERTURA.COMUNA && c.comuna_id) {
      conteo[c.comuna_id] = (conteo[c.comuna_id] ?? 0) + 1
    } else if (c.tipo_cobertura === TIPO_COBERTURA.REGION && c.region_id) {
      const enRegion = geo.comunasDeRegion(c.region_id)
      for (const comuna of enRegion) conteo[comuna.id] = (conteo[comuna.id] ?? 0) + 1
    }
  }
  return conteo
})

async function cargarCoberturas() {
  if (!productorId.value) {
    coberturas.value = []
    return
  }
  loadingCoberturas.value = true
  try {
    coberturas.value = await listCoberturas(productorId.value)
  } catch (e) {
    ui.error('No se pudo cargar la cobertura', e.message)
    coberturas.value = []
  } finally {
    loadingCoberturas.value = false
  }
}

async function agregarCobertura() {
  const { tipo, regionId, comunaId } = nuevaCobertura.value
  if (tipo === TIPO_COBERTURA.REGION && !regionId) {
    ui.warning('Selecciona una región', 'La cobertura regional necesita una región.')
    return
  }
  if (tipo === TIPO_COBERTURA.COMUNA && !comunaId) {
    ui.warning('Selecciona una comuna', 'La cobertura comunal necesita una comuna.')
    return
  }
  guardando.value = true
  try {
    await setCobertura({
      productorId: productorId.value,
      tipo,
      regionId: tipo === TIPO_COBERTURA.REGION ? regionId : null,
      comunaId: tipo === TIPO_COBERTURA.COMUNA ? comunaId : null,
      activo: true,
    })
    ui.success('Cobertura guardada', 'El productor ya puede recibir pedidos en esa zona.')
    nuevaCobertura.value = { tipo: TIPO_COBERTURA.REGION, regionId: null, comunaId: null }
    await cargarCoberturas()
  } catch (e) {
    ui.error('No se pudo guardar la cobertura', e.message)
  } finally {
    guardando.value = false
  }
}

async function alternarCobertura(cobertura) {
  guardando.value = true
  try {
    await setCobertura({
      productorId: cobertura.productor_id,
      tipo: cobertura.tipo_cobertura,
      regionId: cobertura.region_id,
      comunaId: cobertura.comuna_id,
      activo: !cobertura.activo,
    })
    cobertura.activo = !cobertura.activo
    ui.success(
      cobertura.activo ? 'Cobertura activada' : 'Cobertura desactivada',
      `${cobertura.region?.nombre ?? cobertura.comuna?.nombre ?? 'La zona'} ${
        cobertura.activo ? 'vuelve a estar disponible' : 'dejó de estar disponible'
      }.`,
    )
  } catch (e) {
    ui.error('No se pudo actualizar la cobertura', e.message)
  } finally {
    guardando.value = false
  }
}

function pedirEliminacion(cobertura) {
  eliminacion.value = { abierto: true, cobertura }
}

async function confirmarEliminacion() {
  const cobertura = eliminacion.value.cobertura
  guardando.value = true
  try {
    await removeCobertura(cobertura.id)
    coberturas.value = coberturas.value.filter((c) => c.id !== cobertura.id)
    ui.info('Cobertura eliminada', 'La zona dejó de estar en la lista del productor.')
    eliminacion.value = { abierto: false, cobertura: null }
  } catch (e) {
    ui.error('No se pudo eliminar la cobertura', e.message)
  } finally {
    guardando.value = false
  }
}

function destino(cobertura) {
  if (cobertura.tipo_cobertura === TIPO_COBERTURA.REGION) {
    return `${cobertura.region?.nombre ?? '—'} (región completa)`
  }
  return `${cobertura.comuna?.nombre ?? '—'}, ${geo.nombreRegion(cobertura.comuna?.region_id)}`
}

async function cargar() {
  loading.value = true
  error.value = null
  try {
    void geo.load()
    if (geo.error) throw new Error(geo.error)
    productores.value = await listProductores()
    if (geo.regiones.length && !regionSeleccionadaId.value) {
      regionSeleccionadaId.value = geo.regiones[0].id
    }
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

watch(productorId, cargarCoberturas)

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Regiones y comunas</h1>
        <p class="page-head__subtitle">
          Maestro territorial de Chile y cobertura logística de cada productor.
        </p>
      </div>
      <div class="page-head__actions">
        <CtBadge tone="info" size="sm">{{ formatNumber(geo.regiones.length) }} regiones</CtBadge>
        <CtBadge tone="neutral" size="sm">{{ formatNumber(geo.comunas.length) }} comunas</CtBadge>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el maestro geográfico">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtAlert tone="neutral" compact title="Maestro de sólo lectura">
      <p>
        El servicio <code class="mono">geography.js</code> expone lectura de regiones y comunas, pero
        no permite crearlas ni editarlas: el maestro se mantiene en el esquema. Lo que sí se
        administra desde aquí es la cobertura de cada productor.
      </p>
    </CtAlert>

    <CtSpinner v-if="loading" label="Cargando maestro geográfico…" />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Regiones"
          :value="formatNumber(geo.regiones.length)"
          icon="pin"
          tone="primary"
          hint="Divisiones territoriales del maestro"
        />
        <CtStatCard
          label="Comunas"
          :value="formatNumber(geo.comunas.length)"
          icon="map"
          tone="info"
          :hint="regionSeleccionada ? `En ${regionSeleccionada.nombre}` : 'En todo el país'"
        />
        <CtStatCard
          label="Productores"
          :value="formatNumber(productores.length)"
          icon="leaf"
          tone="success"
          :hint="`${formatNumber(productores.filter((p) => p.activo).length)} con tienda activa`"
        />
        <CtStatCard
          label="Coberturas del productor"
          :value="formatNumber(coberturas.length)"
          icon="truck"
          tone="warning"
          :hint="
            productorSeleccionado
              ? `${formatNumber(coberturas.filter((c) => c.activo).length)} activas para ${productorSeleccionado.nombre_comercial}`
              : 'Selecciona un productor para ver su cobertura'
          "
        />
      </div>

      <div class="geografia">
        <!-- ==================== Maestro ==================== -->
        <CtCard padding="md" title="Maestro territorial" subtitle="Regiones y comunas del esquema">
          <nav class="regiones" aria-label="Regiones de Chile">
            <button
              v-for="region in geo.regionesOrdenadas"
              :key="region.id"
              type="button"
              class="regiones__item"
              :class="{ 'is-active': regionSeleccionadaId === region.id }"
              @click="regionSeleccionadaId = region.id"
            >
              <span class="regiones__codigo mono">{{ region.codigo }}</span>
              <span class="regiones__nombre">{{ region.nombre }}</span>
              <span class="regiones__conteo">{{ formatNumber(geo.comunasDeRegion(region.id).length) }}</span>
            </button>
          </nav>

          <div class="comunas">
            <div class="comunas__barra">
              <CtSearchInput
                v-model="texto"
                class="barra__buscador"
                :placeholder="`Buscar comuna${regionSeleccionada ? ` en ${regionSeleccionada.nombre}` : ''}…`"
                aria-label="Buscar comuna"
              />
              <CtButton
                v-if="regionSeleccionadaId"
                size="sm"
                variant="ghost"
                @click="regionSeleccionadaId = null"
              >
                Ver todo el país
              </CtButton>
            </div>

            <CtTable
              :columns="columnasComunas"
              :rows="comunasVisibles"
              dense
              min-width="520px"
              empty-icon="map"
              empty-title="Sin comunas"
              empty-message="No hay comunas que coincidan con la búsqueda o la región elegida."
            >
              <template #cell-codigo="{ row }">
                <span class="mono text-xs">{{ row.codigo }}</span>
              </template>
              <template #cell-nombre="{ row }">
                <div class="comuna">
                  <p class="comuna__nombre">{{ row.nombre }}</p>
                  <p v-if="!regionSeleccionadaId" class="comuna__region">
                    {{ geo.nombreRegion(row.region_id) }}
                  </p>
                </div>
              </template>
              <template #cell-productores="{ row }">
                <CtBadge :tone="coberturaPorComuna[row.id] ? 'success' : 'neutral'" size="sm">
                  {{ coberturaPorComuna[row.id] ?? 0 }} con cobertura
                </CtBadge>
              </template>
            </CtTable>
          </div>
        </CtCard>

        <!-- ==================== Cobertura del productor ==================== -->
        <div class="cobertura">
          <CtCard padding="md" title="Cobertura del productor" subtitle="Zonas donde puede recibir pedidos">
            <CtSelect
              v-model="productorId"
              label="Productor"
              :options="opcionesProductor"
              placeholder="Seleccionar productor…"
            />

            <CtEmptyState
              v-if="!productorId"
              compact
              icon="truck"
              title="Selecciona un productor"
              message="La cobertura se define por productor y habilita las ventas en su comuna o región."
            />

            <template v-else>
              <form class="form" @submit.prevent="agregarCobertura">
                <CtSelect
                  v-model="nuevaCobertura.tipo"
                  label="Tipo de cobertura"
                  :options="[
                    { value: TIPO_COBERTURA.REGION, label: LABELS.cobertura.region },
                    { value: TIPO_COBERTURA.COMUNA, label: LABELS.cobertura.comuna },
                  ]"
                />
                <CtSelect
                  v-if="nuevaCobertura.tipo === TIPO_COBERTURA.REGION"
                  v-model="nuevaCobertura.regionId"
                  label="Región"
                  :options="opcionesRegion"
                  placeholder="Seleccionar región…"
                />
                <CtSelect
                  v-else
                  v-model="nuevaCobertura.comunaId"
                  label="Comuna"
                  :options="opcionesComuna"
                  placeholder="Seleccionar comuna…"
                />
                <CtButton type="submit" block :loading="guardando">
                  <template #icon><CtIcon name="plus" :size="16" /></template>
                  Agregar cobertura
                </CtButton>
              </form>

              <CtTable
                :columns="columnasCoberturas"
                :rows="coberturas"
                :loading="loadingCoberturas"
                dense
                min-width="520px"
                empty-icon="pin"
                empty-title="Sin cobertura"
                empty-message="Este productor todavía no puede recibir pedidos en ninguna zona."
              >
                <template #cell-tipo="{ row }">
                  <span class="text-sm">{{ LABELS.cobertura[row.tipo_cobertura] }}</span>
                </template>
                <template #cell-destino="{ row }">
                  <span class="text-sm">{{ destino(row) }}</span>
                </template>
                <template #cell-estado="{ row }">
                  <CtBadge :tone="row.activo ? 'success' : 'neutral'" dot>
                    {{ row.activo ? 'Activa' : 'Inactiva' }}
                  </CtBadge>
                </template>
                <template #cell-creado="{ row }">
                  <span class="text-sm text-muted">{{ formatDate(row.creado_en) }}</span>
                </template>
                <template #cell-acciones="{ row }">
                  <div class="acciones">
                    <CtButton size="sm" variant="ghost" @click="alternarCobertura(row)">
                      {{ row.activo ? 'Desactivar' : 'Activar' }}
                    </CtButton>
                    <CtButton size="sm" variant="ghost" @click="pedirEliminacion(row)">
                      <template #icon><CtIcon name="trash" :size="14" /></template>
                    </CtButton>
                  </div>
                </template>
              </CtTable>
            </template>
          </CtCard>

          <CtCard padding="md" title="Origen de los productores" subtitle="Comuna declarada en la postulación">
            <CtTable
              :columns="[
                { key: 'nombre', label: 'Productor' },
                { key: 'comuna', label: 'Comuna de origen' },
                { key: 'estado', label: 'Tienda' },
              ]"
              :rows="productores.slice(0, 8)"
              dense
              min-width="460px"
              empty-icon="leaf"
              empty-title="Sin productores"
              empty-message="Todavía no hay productores registrados."
            >
              <template #cell-nombre="{ row }">
                <p class="font-semibold">{{ row.nombre_comercial }}</p>
              </template>
              <template #cell-comuna="{ row }">
                <span class="text-sm">{{ geo.nombreComuna(row.comuna_origen_id) }}</span>
              </template>
              <template #cell-estado="{ row }">
                <CtBadge :tone="row.activo ? 'success' : 'danger'" size="sm">
                  {{ row.activo ? 'Activa' : 'Pausada' }}
                </CtBadge>
              </template>
            </CtTable>
          </CtCard>
        </div>
      </div>
    </template>

    <CtConfirmDialog
      v-model="eliminacion.abierto"
      title="Eliminar cobertura"
      tone="danger"
      confirm-label="Eliminar"
      :loading="guardando"
      :message="`${destino(eliminacion.cobertura ?? {})} dejará de estar disponible para este productor.`"
      @confirm="confirmarEliminacion"
    />
  </div>
</template>

<style scoped>
.geografia {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 460px;
  gap: var(--ct-space-6);
  align-items: start;
}

.regiones {
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 420px;
  overflow-y: auto;
  padding-right: var(--ct-space-2);
  margin-bottom: var(--ct-space-5);
}

.regiones__item {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
  padding: var(--ct-space-2) var(--ct-space-3);
  border-radius: var(--ct-radius-sm);
  text-align: left;
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  transition: background-color var(--ct-transition), color var(--ct-transition);
}

.regiones__item:hover {
  background: var(--ct-surface-alt);
  color: var(--ct-text);
}

.regiones__item.is-active {
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}

.regiones__item.is-active:hover {
  background: var(--ct-accent-tint-50);
  color: var(--ct-accent-ink);
}

.regiones__codigo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  min-width: 22px;
}

.regiones__nombre {
  flex: 1;
}

.regiones__conteo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  background: var(--ct-surface-alt);
  border-radius: var(--ct-radius-pill);
  padding: 1px 8px;
}

.regiones__item.is-active .regiones__conteo {
  background: var(--ct-primary-softer);
}

.comunas__barra {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: var(--ct-space-3);
  margin-bottom: var(--ct-space-4);
}

.barra__buscador {
  max-width: 340px;
}

.comuna__nombre {
  font-weight: var(--ct-fw-medium);
}

.comuna__region {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.cobertura {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-6);
}

.form {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
  margin: var(--ct-space-5) 0;
}

.acciones {
  display: flex;
  justify-content: flex-end;
  gap: var(--ct-space-1);
}

@media (max-width: 1280px) {
  .geografia {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>

