import { describe, it, expect } from 'vitest'
import { mount } from '@vue/test-utils'
import { createMemoryHistory, createRouter } from 'vue-router'

import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtQuantityStepper from '@/components/base/CtQuantityStepper.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'

describe('CtBadge', () => {
  it('muestra el contenido y el tono', () => {
    const wrapper = mount(CtBadge, { props: { tone: 'success' }, slots: { default: 'Orgánico' } })
    expect(wrapper.text()).toBe('Orgánico')
    expect(wrapper.classes().join(' ')).toContain('success')
  })
})

describe('CtButton', () => {
  it('emite click y respeta el estado deshabilitado', async () => {
    const wrapper = mount(CtButton, { props: { disabled: true }, slots: { default: 'Pagar' } })
    await wrapper.trigger('click')
    expect(wrapper.emitted('click')).toBeUndefined()
    expect(wrapper.attributes('disabled')).toBeDefined()
  })

  it('renderiza href cuando recibe una ruta (RouterLink)', async () => {
    const router = createRouter({
      history: createMemoryHistory(),
      routes: [
        { path: '/', component: { template: '<div />' } },
        { path: '/login', component: { template: '<div />' } },
      ],
    })
    await router.push('/')
    const wrapper = mount(CtButton, {
      props: { to: '/login' },
      slots: { default: 'Volver' },
      global: { plugins: [router] },
    })
    const enlace = wrapper.find('a')
    expect(enlace.attributes('href')).toBe('/login')
    expect(enlace.attributes('href')).not.toBeUndefined()
    expect(wrapper.find('button').exists()).toBe(false)
  })

  it('renderiza un ancla externa cuando recibe href', () => {
    const wrapper = mount(CtButton, { props: { href: 'https://example.test/ayuda' } })
    expect(wrapper.find('a').attributes('href')).toBe('https://example.test/ayuda')
  })
})

describe('CtEmptyState', () => {
  it('muestra título y mensaje', () => {
    const wrapper = mount(CtEmptyState, {
      props: { title: 'Carrito vacío', message: 'Agrega productos para continuar' },
    })
    expect(wrapper.text()).toContain('Carrito vacío')
    expect(wrapper.text()).toContain('Agrega productos')
  })
})

describe('CtMoneyInfo', () => {
  it('mantiene la explicación cerrada hasta que la persona la solicite', () => {
    const wrapper = mount(CtMoneyInfo, {
      slots: { default: '<p>Suma de comprobantes autorizados.</p>' },
    })

    expect(wrapper.find('details').attributes('open')).toBeUndefined()
    expect(wrapper.find('summary').text()).toContain('Cómo se calcula este monto')
    expect(wrapper.text()).toContain('Suma de comprobantes autorizados.')
  })

  it('muestra el desglose dentro del KPI sin usar details ni cambiar su flujo', async () => {
    const wrapper = mount(CtStatCard, {
      props: {
        label: 'Ventas autorizadas',
        value: '$10.000',
        calculation: 'Suma los pedidos pagados y no cancelados.',
      },
    })

    const abrir = wrapper.find('[aria-label="Ver cómo se calcula Ventas autorizadas"]')
    expect(abrir.text()).toContain('Cómo se calcula')
    expect(wrapper.find('details').exists()).toBe(false)
    expect(wrapper.find('.kpi__detail').exists()).toBe(false)

    await abrir.trigger('click')
    expect(wrapper.find('.kpi__detail').text()).toContain('Suma los pedidos pagados')
    expect(wrapper.find('.kpi--mostrando-detalle').exists()).toBe(true)
    expect(wrapper.find('a button').exists()).toBe(false)

    await wrapper.find('[aria-label="Volver al indicador"]').trigger('click')
    expect(wrapper.find('.kpi__detail').exists()).toBe(false)
    expect(wrapper.find('[aria-label="Ver cómo se calcula Ventas autorizadas"]').exists()).toBe(true)
  })
})

describe('CtQuantityStepper', () => {
  it('emite el nuevo valor al aumentar', async () => {
    const wrapper = mount(CtQuantityStepper, { props: { modelValue: 1, max: 5 } })
    await wrapper.find('[aria-label="Sumar 1"]').trigger('click')
    expect(wrapper.emitted('update:modelValue')?.at(-1)).toEqual([2])
  })

  it('no supera el máximo', () => {
    const wrapper = mount(CtQuantityStepper, { props: { modelValue: 5, max: 5 } })
    expect(wrapper.find('[aria-label="Sumar 1"]').attributes('disabled')).toBeDefined()
  })

  it('no baja del mínimo', () => {
    const wrapper = mount(CtQuantityStepper, { props: { modelValue: 1, min: 1 } })
    expect(wrapper.find('[aria-label="Restar 1"]').attributes('disabled')).toBeDefined()
  })
})

describe('StatusBadge', () => {
  it('traduce el estado de un pedido', () => {
    const wrapper = mount(StatusBadge, { props: { type: 'pedido', value: 'pagado' } })
    expect(wrapper.text().length).toBeGreaterThan(0)
    expect(wrapper.text().toLowerCase()).toContain('pagado')
  })

  it('traduce el estado de pago en custodia', () => {
    const wrapper = mount(StatusBadge, { props: { type: 'pago', value: 'en_custodia' } })
    expect(wrapper.text().length).toBeGreaterThan(0)
  })
})
