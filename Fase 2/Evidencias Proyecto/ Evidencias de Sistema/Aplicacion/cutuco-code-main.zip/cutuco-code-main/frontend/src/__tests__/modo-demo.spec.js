/**
 * CuTuCo — Modo demostración offline.
 *
 * Verifica que las cuentas demo y las consultas funcionen sin Supabase (Docker
 * apagado), que es lo que permite revisar todas las ventanas desde la vista de
 * desarrollador en cualquier equipo.
 */
import { beforeEach, describe, expect, it } from 'vitest'

import { OfflineSupabaseClient, DEMO_PASSWORD } from '@/lib/offlineClient'
import { createDemoDatabase } from '@/data/demoDatabase'

const CLAVES_DEMO = ['admin@cutuco.dev', 'vendedor@cutuco.dev', 'cliente@cutuco.dev', 'pendiente@cutuco.dev']

describe('modo demo · cuentas', () => {
  let client

  beforeEach(() => {
    localStorage.clear()
    client = new OfflineSupabaseClient({ db: createDemoDatabase() })
  })

  it('permite entrar con las cuatro cuentas demo de la galería', async () => {
    for (const email of CLAVES_DEMO) {
      const { data, error } = await client.auth.signInWithPassword({ email, password: DEMO_PASSWORD })
      expect(error, `falló ${email}`).toBeNull()
      expect(data.user.email).toBe(email)

      const { data: perfil } = await client.from('perfiles').select('*').eq('id', data.user.id).maybeSingle()
      expect(perfil.email).toBe(email)
      await client.auth.signOut()
    }
  })

  it('rechaza una contraseña incorrecta con un mensaje claro', async () => {
    const { error } = await client.auth.signInWithPassword({
      email: 'admin@cutuco.dev',
      password: 'otra-clave',
    })
    expect(error.message).toMatch(/correo o la contraseña/i)
  })

  it('asigna los roles esperados a cada cuenta', async () => {
    const esperado = {
      'admin@cutuco.dev': 'admin',
      'vendedor@cutuco.dev': 'vendedor',
      'cliente@cutuco.dev': 'cliente',
      'pendiente@cutuco.dev': 'cliente',
    }
    for (const [email, rol] of Object.entries(esperado)) {
      const { data } = await client.auth.signInWithPassword({ email, password: DEMO_PASSWORD })
      const { data: perfil } = await client.from('perfiles').select('rol').eq('id', data.user.id).maybeSingle()
      expect(`${email}: ${perfil.rol}`).toBe(`${email}: ${rol}`)
      await client.auth.signOut()
    }
  })

  it('el vendedor demo tiene productor, dirección y catálogo', async () => {
    const { data } = await client.auth.signInWithPassword({
      email: 'vendedor@cutuco.dev',
      password: DEMO_PASSWORD,
    })
    const { data: productor } = await client
      .from('productores')
      .select('*')
      .eq('perfil_id', data.user.id)
      .maybeSingle()
    expect(productor?.nombre_comercial).toBeTruthy()
    expect(productor?.region_id).toBeTruthy()

    const { data: productos } = await client.from('productos').select('*').eq('productor_id', productor.id)
    expect(productos.length).toBeGreaterThan(0)

    const { data: direcciones } = await client.from('direcciones').select('*').eq('perfil_id', data.user.id)
    expect(direcciones.length).toBe(1)
    await client.auth.signOut()
  })

  it('el usuario pendiente tiene una postulación en revisión (RF-021)', async () => {
    const { data } = await client.auth.signInWithPassword({
      email: 'pendiente@cutuco.dev',
      password: DEMO_PASSWORD,
    })
    const { data: postulacion } = await client
      .from('postulaciones_vendedores')
      .select('*')
      .eq('perfil_id', data.user.id)
      .maybeSingle()
    expect(postulacion.estado).toBe('en_revision')
    await client.auth.signOut()
  })
})

describe('modo demo · consultas', () => {
  let client

  beforeEach(() => {
    localStorage.clear()
    client = new OfflineSupabaseClient({ db: createDemoDatabase() })
  })

  it('lista productos con los filtros que usan los servicios', async () => {
    const { data, error, count } = await client
      .from('productos')
      .select('*', { count: 'exact' })
      .eq('activo', true)
      .is('eliminado_en', null)
      .order('nombre', { ascending: true })
    expect(error).toBeNull()
    expect(data.length).toBeGreaterThan(0)
    expect(count).toBe(data.length)
    expect(data[0].nombre.localeCompare(data[1].nombre, 'es')).toBeLessThan(0)
  })

  it('soporta ilike, in, gt y or como PostgREST', async () => {
    const { data: tomates } = await client.from('productos').select('*').ilike('nombre', '%tomate%')
    expect(tomates.length).toBeGreaterThan(0)

    const ids = tomates.map((p) => p.id)
    const { data: porIds } = await client.from('productos').select('*').in('id', ids)
    expect(porIds.length).toBe(ids.length)

    const { data: conStock } = await client.from('productos').select('*').gt('stock', 30)
    expect(conStock.every((p) => p.stock > 30)).toBe(true)

    const { data: buscados } = await client
      .from('productos')
      .select('*')
      .or('nombre.ilike.%miel%,nombre.ilike.%palta%')
    expect(buscados.length).toBeGreaterThan(0)
  })

  it('inserta, actualiza y elimina registros', async () => {
    const { data: creado } = await client
      .from('productos')
      .insert({ productor_id: 'p-huerta', nombre: 'Producto demo', precio: 1000, stock: 5 })
      .select()
      .single()
    expect(creado.id).toBeTruthy()

    const { data: actualizado } = await client
      .from('productos')
      .update({ stock: 12 })
      .eq('id', creado.id)
      .select()
      .single()
    expect(actualizado.stock).toBe(12)

    await client.from('productos').delete().eq('id', creado.id)
    const { data: eliminado } = await client.from('productos').select('*').eq('id', creado.id).maybeSingle()
    expect(eliminado).toBeNull()
  })

  it('resuelve los pedidos y envíos del cliente demo', async () => {
    const { data: pedidos } = await client
      .from('pedidos')
      .select('*')
      .eq('cliente_id', 'u-cliente')
      .order('creado_en', { ascending: false })
    expect(pedidos.length).toBeGreaterThan(0)

    const { data: envios } = await client.from('envios').select('*').eq('pedido_id', pedidos[0].id)
    expect(Array.isArray(envios)).toBe(true)
  })

  it('implementa las RPC del flujo de entrega (RF-007 y RF-025)', async () => {
    const db = createDemoDatabase()
    const demo = new OfflineSupabaseClient({ db })

    // En preparación: hay que pasar a en tránsito para tener código.
    const { data: envio } = await demo.from('envios').select('*').eq('estado', 'preparacion').single()
    await demo
      .from('envios')
      .update({ estado: 'en_transito', codigo_verificacion: 'CODIGO1' })
      .eq('id', envio.id)
    const { data: enTransito } = await demo.from('envios').select('*').eq('id', envio.id).single()

    const malo = await demo.rpc('verificar_codigo_entrega', {
      p_envio_id: enTransito.id,
      p_codigo: 'INCORRECTO',
    })
    expect(malo.error).toBeTruthy()

    const bueno = await demo.rpc('verificar_codigo_entrega', {
      p_envio_id: enTransito.id,
      p_codigo: 'CODIGO1',
    })
    expect(bueno.error).toBeNull()

    const { data: pedidoCompletado } = await demo
      .from('pedidos')
      .select('*')
      .eq('estado', 'completado')
      .single()
    const recepcion = await demo.rpc('confirmar_recepcion_pedido', { p_pedido_id: pedidoCompletado.id })
    expect(recepcion.error).toBeNull()
  })

  it('ya no existe la RPC de payouts (Webpay Mall): el pago queda como comprobante autorizado', async () => {
    const demo = new OfflineSupabaseClient({ db: createDemoDatabase() })
    // La RPC `registrar_payout_pagado` se retiró con la migración Webpay Mall:
    // el cliente en memoria debe rechazarla como función desconocida.
    const { error } = await demo.rpc('registrar_payout_pagado', { p_payout_id: 'inexistente' })
    expect(error).toBeTruthy()

    // El modelo vigente: `pagos` guarda el comprobante autorizado del pedido.
    const { data: pagos } = await demo.from('pagos').select('*')
    expect((pagos ?? []).length).toBeGreaterThan(0)
    for (const p of pagos ?? []) expect(Number(p.monto)).toBeGreaterThan(0)
  })

  it('persiste los cambios en el almacenamiento local', async () => {
    const db = createDemoDatabase()
    db.insertar('productos', { productor_id: 'p-huerta', nombre: 'Persistente', precio: 999, stock: 1 })

    const otra = createDemoDatabase()
    const encontrado = otra.tabla('productos').find((p) => p.nombre === 'Persistente')
    expect(encontrado).toBeTruthy()
  })
})
