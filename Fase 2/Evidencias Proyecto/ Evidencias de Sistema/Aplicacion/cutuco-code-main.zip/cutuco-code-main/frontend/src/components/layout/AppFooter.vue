<script setup>
/**
 * CuTuCo — Pie de página institucional.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *  - El enlace "Trazabilidad de precios" (/precios) apuntaba a PriceHistoryView
 *    (RF-008, fuera del ERS vigente): era un enlace muerto y se retiró.
 *  - El aviso de "datos de demostración" dependía de `DEMO_MODE`, la bandera del
 *    cliente simulado que ya no existe (`lib/mockSupabase.js`). Todo dato sale de
 *    Supabase (PostgREST + RLS) o de FastAPI.
 *  - Tampoco hay referencias a alertas de stock (RF-010), evidencias por pedido
 *    ni reclamos: esas funciones salieron del alcance.
 */
import CtIcon from '@/components/base/CtIcon.vue'

const anio = new Date().getFullYear()
</script>

<template>
  <footer class="ct-foot">
    <div class="container ct-foot__inner">
      <nav class="ct-foot__links" aria-label="Enlaces legales">
        <router-link to="/terminos">Términos y Condiciones</router-link>
        <router-link to="/privacidad">Políticas de Privacidad</router-link>
        <!--
          NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
          <router-link to="/precios">Trazabilidad de precios</router-link>
        -->
        <a href="mailto:cutucosoporte@gmail.com">Contacto</a>
      </nav>

      <div class="ct-foot__meta">
        <p class="ct-foot__brand">
          <img
            class="ct-foot__brand-img"
            src="@/assets/logos/Isotipo.jpg"
            alt="CuTuCo"
          />
          <span>CuTuCo SpA · Mercado Agrícola Digital</span>
        </p>
        <p class="ct-foot__copy">
          {{ anio }} CuTuCo SpA. Todos los derechos reservados. Hecho para el campo chileno.
        </p>
        <!--
          NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el aviso de prototipo
          con datos de demostración (DEMO_MODE + src/data/demoDataset.js) ya no
          corresponde: la aplicación sólo opera con datos reales.
          <p v-if="DEMO_MODE" class="ct-foot__demo">...</p>
        -->
      </div>
    </div>
  </footer>
</template>

<style scoped>
.ct-foot {
  margin-top: auto;
  background: var(--ct-gradient-sidebar);
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding-block: var(--ct-space-10) var(--ct-space-6);
  color: var(--ct-text-invert);
}

.ct-foot__inner {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-6);
}

.ct-foot__links {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-6);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.ct-foot__links a {
  position: relative;
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  color: var(--ct-text-invert);
  transition: color var(--ct-transition);
}

.ct-foot__links a::after {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  bottom: 2px;
  height: 2px;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-accent);
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform var(--ct-transition);
}

.ct-foot__links a:hover {
  color: var(--ct-accent);
  text-decoration: none;
}

.ct-foot__links a:hover::after {
  transform: scaleX(1);
}

.ct-foot__meta {
  text-align: right;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
}

.ct-foot__brand {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-text-invert);
}

.ct-foot__brand-img {
  width: 24px;
  height: 24px;
  border-radius: var(--ct-radius-md);
  object-fit: contain;
  background: var(--ct-white);
  padding: 3px;
  flex-shrink: 0;
}

.ct-foot__copy,
.ct-foot__demo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-on-dark-soft);
}

.ct-foot__demo {
  color: var(--ct-info);
}

@media (max-width: 720px) {
  .ct-foot__meta {
    text-align: left;
  }
}
</style>
