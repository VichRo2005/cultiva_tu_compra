import { beforeEach, expect, it, vi } from 'vitest'
import { consulta, admin } from './admin-test-utils'
const sdk = vi.hoisted(() => ({ from: vi.fn(), auth: { getSession: vi.fn(), getUser: vi.fn() } }))
vi.mock('@/lib/supabase', () => ({
  getClient: () => sdk,
  tryGetClient: () => sdk,
  storageUrl: vi.fn(),
}))
import { resolverReclamo } from '@/services/adminReclamos'
beforeEach(() => vi.resetAllMocks())
it('cierra reclamos abiertos con responsable obtenido de GoTrue', async () => {
  admin(sdk)
  const query = consulta(sdk, { data: { id: 'r', estado: 'resuelto' } })
  await resolverReclamo('r', 'resuelto')
  expect(query.update).toHaveBeenCalledWith(
    expect.objectContaining({ estado: 'resuelto', resuelto_por: 'admin' }),
  )
  expect(query.in).toHaveBeenCalledWith('estado', ['abierto', 'en_revision'])
})
it('rechaza estados ajenos al cierre administrativo', async () => {
  admin(sdk)
  await expect(resolverReclamo('r', 'desconocido')).rejects.toThrow('resolución válida')
})
