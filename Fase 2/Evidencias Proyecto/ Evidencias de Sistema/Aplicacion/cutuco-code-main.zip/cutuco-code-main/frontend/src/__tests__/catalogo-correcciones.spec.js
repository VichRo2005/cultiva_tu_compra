/**
 * CuTuCo — Correcciones del catálogo y del producto (HAL-CLI-005/006/008/009/
 * 014/020/021 y HAL-VEN-006/007, más los casos CLI-CAT/CLI-PRO aplicables).
 *
 * Las pruebas se concentran en las funciones puras que sostienen las vistas:
 * búsqueda normalizada, filtros de URL (incluido el regional), categoría de
 * mascotas oculta, unidad/cantidad comercial y estado de calificación.
 */
import { describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createMemoryHistory, createRouter } from 'vue-router'

import {
  TEXTO_BUSQUEDA_MAX,
  calcularTotalProducto,
  coincideBusqueda,
  configuracionCantidadProducto,
  construirQueryCatalogo,
  esCantidadValida,
  esCategoriaFueraDeAlcance,
  esProductoDeCategoriaOculta,
  estadoCalificacion,
  filtrarCategoriasVisibles,
  filtrarProductosPorRegion,
  filtrarProductosVisibles,
  formatearCantidad,
  getArbolCategorias,
  leerFiltrosCatalogo,
  limpiarTextoBusqueda,
  listProductos,
  listProductoresPorRegion,
  normalizarNombreCategoria,
  normalizarBusqueda,
} from '@/services/catalog'
import CatalogView from '@/views/public/CatalogView.vue'

const geoMock = vi.hoisted(() => ({
  regiones: [
    { id: 'region-metropolitana', nombre: 'Metropolitana' },
    { id: 'region-araucania', nombre: 'La Araucanía' },
  ],
  regionesOrdenadas: [
    { id: 'region-araucania', nombre: 'La Araucanía' },
    { id: 'region-metropolitana', nombre: 'Metropolitana' },
  ],
  regionSeleccionadaId: null,
  load: vi.fn(async () => {}),
  setRegionSeleccionada: vi.fn(),
}))

vi.mock('@/services/catalog', async (importOriginal) => {
  const actual = await importOriginal()
  return {
    ...actual,
    getArbolCategorias: vi.fn(async () => [
      { id: 'verduras', nombre: 'Verduras', hijos: [{ id: 'tomates', nombre: 'Tomates', hijos: [] }] },
      {
        id: 'mascotas',
        nombre: 'Alimentos para mascotas',
        hijos: [{ id: 'snacks', nombre: 'Snacks y premios', hijos: [] }],
      },
    ]),
    listProductos: vi.fn(async () => ({ items: [], total: 0 })),
    listProductoresPorRegion: vi.fn(async () => []),
  }
})

vi.mock('@/services/geography', async (importOriginal) => ({
  ...(await importOriginal()),
  getRegionCliente: vi.fn(async () => null),
}))

vi.mock('@/stores/auth', () => ({
  useAuthStore: () => ({ isAuthenticated: false, perfil: null }),
}))

vi.mock('@/stores/cart', () => ({
  useCartStore: () => ({ agregar: vi.fn() }),
}))

vi.mock('@/stores/geography', () => ({
  useGeographyStore: () => geoMock,
}))

vi.mock('@/stores/ui', () => ({
  useUiStore: () => ({ success: vi.fn(), error: vi.fn(), warning: vi.fn() }),
}))

describe('búsqueda del catálogo (CLI-CAT-012 a CLI-CAT-020)', () => {
  it('encuentra por nombre completo, parcial y sin distinguir mayúsculas', () => {
    const palta = { nombre: 'Palta Hass de Paine' }
    expect(coincideBusqueda(palta, 'Palta Hass de Paine')).toBe(true)
    expect(coincideBusqueda(palta, 'PALTA')).toBe(true)
    expect(coincideBusqueda(palta, 'lta h')).toBe(true)
    expect(coincideBusqueda(palta, 'tomate')).toBe(false)
  })

  it('ignora tildes y la ñ al comparar, y recorta espacios externos', () => {
    const producto = { nombre: 'Pequeña Agricultura Campesina' }
    expect(coincideBusqueda(producto, 'pequena')).toBe(true)
    expect(coincideBusqueda(producto, 'PEQUEÑA')).toBe(true)
    expect(coincideBusqueda(producto, '  agricultura  ')).toBe(true)
    expect(normalizarBusqueda('  Pequeña   AGRICULTURA  ')).toBe('pequena agricultura')
  })

  it('trata la búsqueda vacía como “sin filtro” y el HTML como texto literal', () => {
    const normal = { nombre: 'Tomate Roma' }
    const html = { nombre: '<script>alert(1)</script>' }
    expect(coincideBusqueda(normal, '')).toBe(true)
    expect(coincideBusqueda(normal, '   ')).toBe(true)
    expect(coincideBusqueda(normal, '<script>alert(1)</script>')).toBe(false)
    expect(coincideBusqueda(html, '<script>alert(1)</script>')).toBe(true)
    expect(coincideBusqueda(html, '<SCRIPT>ALERT(1)</SCRIPT>')).toBe(true)
  })

  it('trata sintaxis de inyección como texto y no amplía resultados', () => {
    const intento = "tomate') OR 1=1 --"
    expect(coincideBusqueda({ nombre: 'Tomates de Paine' }, intento)).toBe(false)
    expect(coincideBusqueda({ nombre: intento }, intento)).toBe(true)
    expect(construirQueryCatalogo({ texto: intento })).toEqual({ q: intento })
  })

  it('limita el término de búsqueda sin romper el texto', () => {
    expect(limpiarTextoBusqueda(`  ${'x'.repeat(200)}  `)).toHaveLength(TEXTO_BUSQUEDA_MAX)
    expect(normalizarBusqueda('')).toBe('')
  })
})

describe('filtro regional inmediato (CLI-CAT-024, HAL-CLI-014 y HAL-VEN-007)', () => {
  it('lee la región desde la URL en el mismo paso que el resto de los filtros', () => {
    const filtros = leerFiltrosCatalogo({
      q: '  tomate  ',
      region: 'region-araucania',
      categoria: 'cat-verduras',
      subcategoria: 'cat-tomates',
      page: '3',
    })

    expect(filtros).toMatchObject({
      texto: 'tomate',
      regionId: 'region-araucania',
      categoriaId: 'cat-verduras',
      subcategoriaId: 'cat-tomates',
      page: 3,
    })
  })

  it('vuelve a escribir la región en la URL y la retira al limpiar', () => {
    const activos = leerFiltrosCatalogo({ region: 'region-araucania', q: 'tomate' })
    expect(construirQueryCatalogo(activos, 1)).toEqual({
      q: 'tomate',
      region: 'region-araucania',
    })

    const limpios = leerFiltrosCatalogo({})
    expect(construirQueryCatalogo(limpios, 1)).toEqual({})
  })

  it('deja sólo los productos cuyo vendedor pertenece a la región elegida', () => {
    const productos = [
      { id: 'tomate', productor_id: 'p1' },
      { id: 'queso', productor_id: 'p2' },
      { id: 'miel', productor_id: 'p3' },
    ]
    const regiones = new Map([
      ['p1', { id: 'region-metropolitana', nombre: 'Metropolitana' }],
      ['p2', { id: 'region-araucania', nombre: 'La Araucanía' }],
    ])

    expect(filtrarProductosPorRegion(productos, regiones, 'region-araucania').map((p) => p.id)).toEqual([
      'queso',
    ])
    expect(filtrarProductosPorRegion(productos, regiones, '')).toHaveLength(3)
  })
})

describe('categorías fuera de alcance y normalización (HAL-CLI-021 y HAL-VEN-006)', () => {
  const arbol = [
    {
      id: 'verduras',
      nombre: 'Verduras',
      hijos: [{ id: 'tomates', nombre: 'Tomates', hijos: [] }],
    },
    {
      id: 'mascotas',
      nombre: 'Alimentos para mascotas',
      hijos: [
        { id: 'mascotas-alimento', nombre: 'Alimentos para mascotas', hijos: [] },
        { id: 'snacks', nombre: 'Snacks y premios', hijos: [] },
      ],
    },
    { id: 'sin-mayuscula', nombre: 'Sin Categoría', hijos: [] },
    { id: 'sin-minuscula', nombre: 'Sin categoría', hijos: [] },
  ]

  it('oculta la categoría de mascotas, sus subcategorías y sus productos', () => {
    const visibles = filtrarCategoriasVisibles(arbol)
    expect(visibles.map((categoria) => categoria.id)).toEqual(['verduras', 'sin-mayuscula'])
    expect(esCategoriaFueraDeAlcance({ nombre: '  ALIMENTOS PARA MASCOTAS ' })).toBe(true)
    expect(esCategoriaFueraDeAlcance('verduras')).toBe(false)

    expect(
      esProductoDeCategoriaOculta({
        categoria: { nombre: 'Snacks y premios' },
        categoriaPadre: { nombre: 'Alimentos para mascotas' },
      }),
    ).toBe(true)
    expect(
      filtrarProductosVisibles([
        { id: '1', categoria: { nombre: 'Verduras' }, categoriaPadre: null },
        { id: '2', categoria: { nombre: 'Snacks y premios' }, categoriaPadre: { nombre: 'Alimentos para mascotas' } },
      ]).map((producto) => producto.id),
    ).toEqual(['1'])
  })

  it('normaliza “Sin categoría” y evita duplicados entre hermanos', () => {
    expect(normalizarNombreCategoria('Sin Categoría')).toBe('Sin categoría')
    expect(normalizarNombreCategoria('  sin categoría ')).toBe('Sin categoría')
    expect(normalizarNombreCategoria('')).toBe('Sin categoría')

    const visibles = filtrarCategoriasVisibles(arbol)
    const sinCategoria = visibles.filter((categoria) => categoria.nombre === 'Sin categoría')
    expect(sinCategoria).toHaveLength(1)
  })
})

describe('unidad comercial y cantidad (HAL-CLI-008 y HAL-CLI-009, CLI-PRO-010 a 024)', () => {
  it('conserva kg como unidad y parte en la compra mínima, no en 10', () => {
    const config = configuracionCantidadProducto({ unidad_medida: 'kg', stock: 10 })
    expect(config).toMatchObject({
      unidad: 'kg',
      fraccionable: true,
      paso: 0.1,
      min: 0.1,
      max: 10,
      inicial: 0.1,
      agotado: false,
    })
    expect(config.inicial).not.toBe(10)
    expect(esCantidadValida(0.1, config)).toBe(true)
    expect(esCantidadValida(0.15, config)).toBe(false)
    expect(esCantidadValida(10, config)).toBe(true)
    expect(esCantidadValida(10.1, config)).toBe(false)
    expect(calcularTotalProducto(2800, 0.5)).toBe(1400)
  })

  it('usa 1 como mínimo para unidades discretas y rechaza decimales', () => {
    const config = configuracionCantidadProducto({ unidad_medida: 'unidad', stock: 10 })
    expect(config).toMatchObject({ unidad: 'unidad', min: 1, inicial: 1, paso: 1, decimales: 0 })
    expect(esCantidadValida(1, config)).toBe(true)
    expect(esCantidadValida(1.5, config)).toBe(false)
    expect(esCantidadValida(0, config)).toBe(false)
    expect(esCantidadValida(-2, config)).toBe(false)
    expect(esCantidadValida(1e3, config)).toBe(false)
  })

  it('no supera el stock y respeta el stock fraccionario restante (HAL-CLI-008: 1 decimal)', () => {
    const config = configuracionCantidadProducto({ unidad_medida: 'kg', stock: 2.35 })
    // la cantidad fraccionable se delimita a un decimal: el tope baja a 2,3
    expect(config.decimales).toBe(1)
    expect(config.max).toBe(2.3)
    expect(esCantidadValida(2.3, config)).toBe(true)
    expect(esCantidadValida(2.35, config)).toBe(false)
    expect(esCantidadValida(2.4, config)).toBe(false)

    const agotado = configuracionCantidadProducto({ unidad_medida: 'kg', stock: 0 })
    expect(agotado.agotado).toBe(true)
    expect(agotado.max).toBe(0)
    expect(esCantidadValida(0.1, agotado)).toBe(false)
  })

  it('respeta el incremento y el mínimo configurados por el vendedor', () => {
    const config = configuracionCantidadProducto({
      unidad_medida: 'kg',
      stock: 10,
      incremento_venta: 0.2,
      cantidad_minima_compra: 2,
    })
    expect(config).toMatchObject({ paso: 0.2, min: 2, max: 10, inicial: 2, decimales: 1 })
    expect(esCantidadValida(2, config)).toBe(true)
    expect(esCantidadValida(2.2, config)).toBe(true)
    expect(esCantidadValida(1.8, config)).toBe(false)
    expect(esCantidadValida(2.25, config)).toBe(false)
  })

  it('formatea la cantidad con la unidad real del producto', () => {
    expect(formatearCantidad(10, 'kg')).toBe('10')
    expect(formatearCantidad(0.5, 'kg')).toMatch(/0[.,]5/)
    expect(formatearCantidad(0.1, 'kg')).toMatch(/0[.,]1/)
    expect(formatearCantidad(3, 'unidad')).toBe('3')
  })
})

describe('estado de calificación del perfil (HAL-CLI-005)', () => {
  it('muestra el resumen cuando hay promedio o evaluaciones, aunque no haya comentarios', () => {
    expect(
      estadoCalificacion({ puntaje: 5, cantidadEvaluaciones: 1, evaluaciones: [] }),
    ).toBe('resumen')
    expect(
      estadoCalificacion({ puntaje: 5, cantidadEvaluaciones: 1, evaluaciones: [{ id: 1 }] }),
    ).toBe('resumen')
    expect(estadoCalificacion({ puntaje: null, cantidadEvaluaciones: 0, evaluaciones: [{ id: 1 }] })).toBe(
      'resumen',
    )
  })

  it('muestra el estado vacío sólo cuando no hay ningún dato de reputación', () => {
    expect(
      estadoCalificacion({ puntaje: null, cantidadEvaluaciones: 0, evaluaciones: [] }),
    ).toBe('vacio')
    expect(estadoCalificacion({ puntaje: 0, cantidadEvaluaciones: 0, evaluaciones: [] })).toBe(
      'vacio',
    )
    // El esquema arranca con 5.00 por defecto: sin evaluaciones no hay resumen.
    expect(estadoCalificacion({ puntaje: 5, cantidadEvaluaciones: 0, evaluaciones: [] })).toBe(
      'vacio',
    )
  })
})

describe('CatalogView · filtro regional en el mismo evento (HAL-CLI-014)', () => {
  it('reacciona a la región de la URL, recarga resultados y sincroniza el chip superior', async () => {
    const router = createRouter({
      history: createMemoryHistory(),
      routes: [{ path: '/catalogo', component: { template: '<div />' } }],
    })
    await router.push('/catalogo')
    await router.isReady()

    const wrapper = mount(CatalogView, { global: { plugins: [router] } })
    await flushPromises()

    expect(getArbolCategorias).toHaveBeenCalled()
    // La categoría de mascotas llega en el árbol, pero la vista la oculta.
    expect(wrapper.text()).not.toContain('Alimentos para mascotas')

    await router.push('/catalogo?region=region-araucania')
    await flushPromises()

    const llamadas = listProductos.mock.calls.map(([args]) => args)
    expect(llamadas.some((args) => args.regionId === 'region-araucania')).toBe(true)
    expect(llamadas.at(-1)?.regionId).toBe('region-araucania')
    expect(listProductoresPorRegion).toHaveBeenCalledWith('region-araucania')
    expect(geoMock.setRegionSeleccionada).toHaveBeenCalledWith('region-araucania')
    expect(wrapper.text()).toContain('La Araucanía')

    wrapper.unmount()
  })
})
