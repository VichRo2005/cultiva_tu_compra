/**
 * CuTuCo — Lote 8 (Entrega y seguimiento), lado frontend.
 *
 * CK-0392: código de entrega numérico de seis dígitos validado en interfaz antes de llamar a la RPC.
 * CK-0394: motivo de entrega fallida obligatorio y con tope 1000 en interfaz.
 * CK-0481 (HAL-CLI-022): sin textos de evidencias fotográficas en las vistas de entrega.
 * CK-0508 (HAL-VEN-020): un único estado actual por pedido en el listado del vendedor.
 * CK-0509 (HAL-VEN-021): el filtro de pedidos incluye «En tránsito».
 * CK-0518 (HAL-VEN-030): cliente y vendedor comparten los mismos hitos base.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)
const sessionMock = vi.hoisted(() => ({
  currentUserId: vi.fn(async () => 'u-1'),
  unwrap: (r, msg) => { if (r?.error) throw new Error(msg); return r?.data },
}))
vi.mock('@/services/session.js', () => sessionMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0392 · código de entrega validado en interfaz', () => {
  it('esCodigoEntregaValido exige seis dígitos', async () => {
    const { esCodigoEntregaValido, normalizarCodigoEntrega, LONGITUD_CODIGO_ENTREGA } = await import('@/lib/orders.js')
    expect(LONGITUD_CODIGO_ENTREGA).toBe(6)
    expect(esCodigoEntregaValido('482731')).toBe(true)
    expect(esCodigoEntregaValido(normalizarCodigoEntrega(' 482731 '))).toBe(true)
    for (const malo of ['', 'NO-ES-CODIGO', '48273', '4827314', '48A731']) {
      expect(esCodigoEntregaValido(malo)).toBe(false)
    }
  })

  it('verificarCodigoEntregaVendedor rechaza antes de llamar a la RPC', async () => {
    const rpc = vi.fn()
    supabaseMock.getClient.mockReturnValue({ rpc })
    const { verificarCodigoEntregaVendedor } = await import('@/services/orders.js')
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'e-1', codigo: 'corto' })
    ).rejects.toThrow(/6 dígitos/)
    expect(rpc).not.toHaveBeenCalled()
  })

  it('SellerOrderDetailView limpia el campo y cierra automáticamente al sexto dígito', () => {
    const vista = src('views/seller/SellerOrderDetailView.vue')
    expect(vista).toContain('esCodigoEntregaValido')
    expect(vista).toContain('watch(codigoIngresado, async')
    expect(vista).toContain("replace(/\\D/g, '')")
    expect(vista).toContain('await confirmarCodigo()')
    expect(vista).toContain('await marcarEnvioEntregado(envio.value.id)')
    expect(vista).toContain(':maxlength="LONGITUD_CODIGO_ENTREGA"')
    expect(vista).not.toContain('Validar código')
  })
})

describe('CK-0394 · motivo de entrega fallida obligatorio en interfaz', () => {
  it('validarJustificacion rechaza vacío, sólo espacios y más de 1000', async () => {
    const { validarJustificacion } = await import('@/lib/orders.js')
    expect(validarJustificacion('', { campo: 'La justificación de la entrega fallida' }).valida).toBe(false)
    expect(validarJustificacion('   ', { campo: 'x' }).valida).toBe(false)
    expect(validarJustificacion('x'.repeat(1001), { campo: 'x' }).valida).toBe(false)
    expect(validarJustificacion('x'.repeat(1000), { campo: 'x' }).valida).toBe(true)
  })

  it('marcarEnvioFallido no envía motivo vacío y traduce el error 1000', async () => {
    const update = vi.fn()
    const q = { update, eq: vi.fn(() => q), select: vi.fn(() => q), single: vi.fn(async () => ({ data: {}, error: null })) }
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => q) })
    const { marcarEnvioFallido } = await import('@/services/orders.js')
    const { traducirErrorJustificacion } = await import('@/lib/orders.js')
    await expect(marcarEnvioFallido('e-1', '   ')).rejects.toThrow(/justificación/i)
    expect(update).not.toHaveBeenCalled()
    expect(traducirErrorJustificacion('value too long for type character varying(1000)'))
      .toMatch(/1\.?000|1000/)
  })

  it('el formulario del vendedor exige motivo antes de registrar el fallo', () => {
    const vista = src('views/seller/SellerOrderDetailView.vue')
    expect(vista).toContain("Selecciona el motivo de la entrega fallida")
    expect(vista).toContain('Máximo 1.000 caracteres')
  })
})

describe('CK-0481 (HAL-CLI-022) · sin evidencias fotográficas en las vistas de entrega', () => {
  it('ninguna vista de entrega menciona comprobante visual o carga de fotos', () => {
    for (const vista of [
      'views/seller/SellerOrdersView.vue',
      'views/seller/SellerOrderDetailView.vue',
      'views/client/ClientOrderDetailView.vue',
      'components/domain/DeliveryStepper.vue',
    ]) {
      const contenido = src(vista)
      expect(contenido.toLowerCase()).not.toContain('comprobante visual')
      expect(contenido.toLowerCase()).not.toContain('0 evidencias')
      expect(contenido.toLowerCase()).not.toContain('subir foto')
      expect(contenido.toLowerCase()).not.toContain('carga de fotos')
    }
    // la única mención es la ventana retirada que explica que ya no se usan
    const retirada = src('views/seller/SellerEvidenceView.vue')
    expect(retirada).toContain('ya no se utilizan')
  })
})

describe('CK-0508 (HAL-VEN-020) · un único estado actual por pedido', () => {
  it('el listado del vendedor deriva un único estado del envío por pedido', () => {
    const vista = src('views/seller/SellerOrdersView.vue')
    // cadena única de mapeo estado_envio -> texto (sin estados duplicados)
    const coincidencias = vista.match(/envio\?\.estado === ESTADO_ENVIO\./g) || []
    expect(coincidencias.length).toBeGreaterThanOrEqual(3) // preparacion/en_transito/entregado/fallido en un solo switch
    expect(vista).not.toMatch(/estado.*y.*estado/i)
  })
})

describe('CK-0509 (HAL-VEN-021) · el filtro incluye En tránsito', () => {
  it('OPCIONES_ESTADO_ACTUAL incluye en_transito y el listado lo usa', async () => {
    const { OPCIONES_ESTADO_ACTUAL } = await import('@/lib/orders.js')
    expect(OPCIONES_ESTADO_ACTUAL.some((o) => o.value === 'en_transito')).toBe(true)
    expect(OPCIONES_ESTADO_ACTUAL.find((o) => o.value === 'en_transito').label).toBe('En tránsito')
    const vista = src('views/seller/SellerOrdersView.vue')
    expect(vista).toContain('OPCIONES_ESTADO_ACTUAL')
    expect(vista).toContain('HAL-VEN-021')
  })
})

describe('CK-0518 (HAL-VEN-030) · mismos hitos para cliente y vendedor', () => {
  it('cliente y vendedor comparten hitosPedido (4 hitos base)', async () => {
    const { hitosPedido } = await import('@/lib/orders.js')
    const pedido = {
      estado: 'completado',
      envio: { estado: 'entregado', creado_en: '2026-11-05T10:00:00Z', despachado_en: '2026-11-05T11:00:00Z', entregado_en: '2026-11-05T12:00:00Z' },
      pago: { autorizado_en: '2026-11-05T09:00:00Z' },
    }
    const hitos = hitosPedido(pedido)
    expect(hitos.length).toBe(4)
    const cliente = src('views/client/ClientOrderDetailView.vue')
    const vendedor = src('views/seller/SellerOrderDetailView.vue')
    const stepper = src('components/domain/DeliveryStepper.vue')
    expect(cliente).toContain('hitosPedido')
    expect(stepper).toContain('hitosPedido')
    expect(vendedor).toContain('DeliveryStepper')
  })
})
