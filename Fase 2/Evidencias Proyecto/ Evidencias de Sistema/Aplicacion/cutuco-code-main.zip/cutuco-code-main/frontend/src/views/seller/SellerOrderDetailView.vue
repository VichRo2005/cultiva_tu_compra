<script setup>
/**
 * CuTuCo — Detalle y gestión de entrega de un pedido recibido.
 *
 *   RF-003  el vendedor gestiona los pedidos de su tienda
 *   RF-007  el CLIENTE recibe el código de entrega y se lo entrega al vendedor.
 *           El vendedor lo ingresa aquí para validarlo; el código NO se muestra
 *           en su panel (HAL-VEN-018).
 *   RF-014  desglose del dinero: subtotal + delivery $3.500 − fee 5%
 *   RF-025  Preparación → En Tránsito → Entregado, y entrega fallida con motivo
 *
 * HAL-VEN-020: un único estado actual derivado (`estadoActualPedido`).
 * HAL-VEN-022: «Webpay» (método) y «Autorizado» (estado) van separados.
 * HAL-VEN-028: la justificación de entrega fallida se limita a 1.000 caracteres.
 * HAL-VEN-029: la cancelación guarda motivo y no se confunde con entrega fallida.
 *
 * NOTA DE MIGRACIÓN: las evidencias fotográficas salieron del alcance
 * (HAL-CLI-022). La entrega se respalda sólo con el código de verificación y la
 * entrega fallida se registra con `marcarEnvioFallido` usando
 * MOTIVOS_FALLO_ENTREGA.
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import DeliveryStepper from '@/components/domain/DeliveryStepper.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { ESTADO_ENVIO, ESTADO_PEDIDO, LABELS, MOTIVOS_FALLO_ENTREGA, REGLAS } from '@/lib/constants'
import { formatCLP, formatDateTime, formatNumber, formatPhone } from '@/lib/format'
import { formatearCantidad } from '@/services/catalog'
import {
  ESTADO_ENVIO_CANCELADO,
  LIMITE_JUSTIFICACION,
  LONGITUD_CODIGO_ENTREGA,
  construirJustificacion,
  esCodigoEntregaValido,
  estadoActualPedido,
  motivoCancelacion,
  netoProductor,
  normalizarCodigoEntrega,
  validarJustificacion,
} from '@/lib/orders'
import { required } from '@/lib/validation'
import { useAsync } from '@/composables/useAsync'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'
import {
  cancelarPedido,
  getPedidoDetalle,
  marcarEnTransito,
  marcarEnvioEntregado,
  marcarEnvioFallido,
  marcarPedidoEnPreparacion,
  verificarCodigoEntregaVendedor,
} from '@/services/orders'

const route = useRoute()
const ui = useUiStore()
const geo = useGeographyStore()

const pedidoId = computed(() => route.params.id)
/**
 * `incluirCodigo:false`: el vendedor no recibe `codigo_verificacion` ni siquiera
 * en la respuesta del servicio. El código lo tiene el cliente (HAL-VEN-018).
 */
const {
  data: pedido,
  loading,
  error,
  run,
} = useAsync(() => getPedidoDetalle(pedidoId.value, { incluirCodigo: false }))

const motivoCancelacionReciente = ref('')

watch(pedidoId, () => {
  motivoCancelacionReciente.value = ''
  run()
})

onMounted(() => {
  geo.load()
})

const accionEnCurso = ref(false)

const envio = computed(() => pedido.value?.envio ?? null)
const estadoActual = computed(() => estadoActualPedido(pedido.value))
const cancelado = computed(() => estadoActual.value === ESTADO_PEDIDO.CANCELADO)
const reclamado = computed(() => estadoActual.value === ESTADO_PEDIDO.RECLAMADO)
const entregaCerrada = computed(
  () =>
    !envio.value ||
    [ESTADO_ENVIO.ENTREGADO, ESTADO_ENVIO.FALLIDO, ESTADO_ENVIO_CANCELADO].includes(
      envio.value.estado,
    ),
)

/** Con Webpay Mall la fila de `pagos` existe sólo cuando el pago quedó autorizado. */
const pagoAutorizado = computed(() => Boolean(pedido.value?.pago))
const metodoPago = computed(() => (pedido.value?.pago ? 'Webpay' : 'Sin pago registrado'))

/** El vendedor ya validó el código que le entregó el cliente. */
const codigoVerificado = computed(() => Boolean(envio.value?.codigo_verificado_en))

/* ------------------------------------------------------------------ */
/* Acciones de delivery (RF-025 y RF-007)                              */
/* ------------------------------------------------------------------ */

/** HAL-CLI-010: preparación confirmada por el vendedor, no por el pago. */
const puedeMarcarPreparacion = computed(
  () =>
    Boolean(envio.value) &&
    envio.value.estado === ESTADO_ENVIO.PREPARACION &&
    !envio.value.preparado_en &&
    !cancelado.value &&
    !reclamado.value &&
    [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(pedido.value?.estado),
)

const puedeMarcarTransito = computed(
  () =>
    Boolean(envio.value) &&
    envio.value.estado === ESTADO_ENVIO.PREPARACION &&
    Boolean(envio.value.preparado_en) &&
    !cancelado.value &&
    !reclamado.value &&
    [ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(pedido.value?.estado),
)

/**
 * Cerrar la entrega exige el código ya validado: el trigger
 * `validar_transicion_envio` rechaza el cambio en caso contrario.
 */
const puedeCerrarEntrega = computed(
  () =>
    envio.value?.estado === ESTADO_ENVIO.EN_TRANSITO &&
    codigoVerificado.value &&
    !cancelado.value &&
    !reclamado.value,
)

/**
 * HAL-VEN-027: «Marcar fallida» sólo tiene sentido cuando el pedido ya salió a
 * despacho (`en_transito`). En preparación todavía no hay nada que reintentar.
 */
const puedeMarcarFallido = computed(
  () =>
    Boolean(envio.value) &&
    envio.value.estado === ESTADO_ENVIO.EN_TRANSITO &&
    !cancelado.value &&
    !reclamado.value,
)

/** HAL-VEN-029: el vendedor puede cancelar antes de que la entrega se cierre. */
const puedeCancelar = computed(
  () =>
    Boolean(pedido.value) &&
    [ESTADO_PEDIDO.CREADO, ESTADO_PEDIDO.PAGADO, ESTADO_PEDIDO.EN_PREPARACION].includes(
      pedido.value.estado,
    ) &&
    pedido.value.estado !== ESTADO_PEDIDO.CANCELADO &&
    envio.value?.estado !== ESTADO_ENVIO.ENTREGADO &&
    envio.value?.estado !== ESTADO_ENVIO.FALLIDO &&
    envio.value?.estado !== ESTADO_ENVIO_CANCELADO,
)

async function marcarPreparacion() {
  if (!pedido.value) return
  accionEnCurso.value = true
  try {
    await marcarPedidoEnPreparacion(pedido.value.id)
    ui.success(
      'Preparación confirmada',
      'El hito de preparación quedó cerrado. Ahora puedes marcar el pedido En Tránsito cuando salga a despacho.',
    )
    await run()
  } catch (e) {
    ui.error('No se pudo confirmar la preparación', e.message)
  } finally {
    accionEnCurso.value = false
  }
}

async function marcarTransito() {
  if (!envio.value) return
  accionEnCurso.value = true
  try {
    await marcarEnTransito(envio.value.id)
    ui.success(
      'Pedido en tránsito',
      'El código de verificación se generó y se muestra en el seguimiento del cliente. Pídeselo al entregar.',
    )
    await run()
  } catch (e) {
    ui.error('No se pudo marcar en tránsito', e.message)
  } finally {
    accionEnCurso.value = false
  }
}

/**
 * RF-007: cierra la entrega. El código ya lo validó el vendedor con lo que le
 * entregó el cliente; aquí sólo se avanza el envío a `entregado` (el trigger
 * valida que esté verificado y sincroniza el pedido).
 */
async function marcarEntregado() {
  if (!envio.value) return
  accionEnCurso.value = true
  try {
    await marcarEnvioEntregado(envio.value.id)
    ui.success(
      'Entrega confirmada',
      'El pedido quedó entregado. El pago de esa venta se envió a tu cuenta registrada.',
    )
    await run()
  } catch (e) {
    ui.error('No se pudo cerrar la entrega', e.message)
  } finally {
    accionEnCurso.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Código de entrega (HAL-VEN-018)                                     */
/* ------------------------------------------------------------------ */

const codigoIngresado = ref('')
const errorCodigo = ref(null)
const verificandoCodigo = ref(false)

const puedeVerificarCodigo = computed(
  () =>
    envio.value?.estado === ESTADO_ENVIO.EN_TRANSITO &&
    !codigoVerificado.value &&
    !cancelado.value &&
    !reclamado.value,
)

watch(codigoIngresado, async (codigo) => {
  // El campo sólo conserva dígitos y permite pegar el código con espacios o guiones.
  // La función de servicio sigue validando el valor completo antes de llamar a la RPC.
  const soloDigitos = String(codigo ?? '')
    .replace(/\D/g, '')
    .slice(0, LONGITUD_CODIGO_ENTREGA)
  if (codigo !== soloDigitos) {
    codigoIngresado.value = soloDigitos
    return
  }
  if (errorCodigo.value) errorCodigo.value = null

  if (
    puedeVerificarCodigo.value &&
    esCodigoEntregaValido(soloDigitos) &&
    !verificandoCodigo.value
  ) {
    await confirmarCodigo()
  }
})

/**
 * HAL-CLI-019: al validar el código de entrega que entrega el cliente, el
 * pedido queda AUTOMÁTICAMENTE «entregado» al completar los seis dígitos (no se
 * marca a mano aparte): la RPC
 * registra `codigo_verificado_en` y enseguida se cierra el envío con
 * `marcarEnvioEntregado`, cuyo trigger sincroniza el pedido a `completado`.
 * Si el cierre automático falla por una incidencia de red o del servidor, el
 * código queda validado y se informa una acción de recuperación explícita.
 */
async function confirmarCodigo() {
  errorCodigo.value = null
  if (!envio.value || verificandoCodigo.value || !puedeVerificarCodigo.value) return
  const limpio = normalizarCodigoEntrega(codigoIngresado.value)
  if (!esCodigoEntregaValido(limpio)) {
    errorCodigo.value = `Escribe los ${LONGITUD_CODIGO_ENTREGA} dígitos que te entregó el cliente`
    return
  }
  verificandoCodigo.value = true
  let codigoValidado = false
  try {
    await verificarCodigoEntregaVendedor({ envioId: envio.value.id, codigo: limpio })
    codigoValidado = true
    codigoIngresado.value = ''
    await marcarEnvioEntregado(envio.value.id)
    ui.success(
      'Entrega confirmada automáticamente',
      'El código coincidió con este pedido y quedó Entregado. El pago ya fue autorizado por Webpay.',
    )
    await run()
  } catch (e) {
    errorCodigo.value = codigoValidado
      ? 'El código fue validado, pero no se pudo cerrar la entrega. Intenta nuevamente desde Gestión de la entrega.'
      : (e?.message ?? 'No se pudo validar el código de entrega')
  } finally {
    verificandoCodigo.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Entrega fallida (RF-025 y HAL-VEN-028)                              */
/* ------------------------------------------------------------------ */

const modalFallo = ref(false)
const motivoFallo = ref('')
const notaFallo = ref('')
const errorFallo = ref(null)

const opcionesMotivoFallo = MOTIVOS_FALLO_ENTREGA.map((m) => ({ value: m, label: m }))

const justificacionFallo = computed(() =>
  construirJustificacion({ motivo: motivoFallo.value, detalle: notaFallo.value }),
)
const validacionFallo = computed(() =>
  validarJustificacion(justificacionFallo.value, {
    campo: 'La justificación de la entrega fallida',
  }),
)
const errorJustificacion = computed(() =>
  validacionFallo.value.longitud > LIMITE_JUSTIFICACION ? validacionFallo.value.error : null,
)

function abrirModalFallo() {
  motivoFallo.value = ''
  notaFallo.value = ''
  errorFallo.value = null
  modalFallo.value = true
}

async function confirmarFallo() {
  errorFallo.value = null
  if (!required(motivoFallo.value)) {
    errorFallo.value = 'Selecciona el motivo de la entrega fallida'
    return
  }
  const validacion = validarJustificacion(justificacionFallo.value, {
    campo: 'La justificación de la entrega fallida',
  })
  if (!validacion.valida) {
    errorFallo.value = validacion.error
    return
  }

  accionEnCurso.value = true
  try {
    await marcarEnvioFallido(envio.value.id, justificacionFallo.value)
    ui.success(
      'Entrega fallida registrada',
      'El pedido queda fuera de la ruta de entrega; el pago ya estaba autorizado y el administrador revisa el caso.',
    )
    modalFallo.value = false
    await run()
  } catch (e) {
    errorFallo.value = e.message
    ui.error('No se pudo registrar la entrega fallida', e.message)
  } finally {
    accionEnCurso.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Cancelación (HAL-VEN-029)                                           */
/* ------------------------------------------------------------------ */

const modalCancelacion = ref(false)
const textoCancelacion = ref('')
const errorCancelacion = ref(null)

const validacionCancelacion = computed(() =>
  validarJustificacion(textoCancelacion.value, {
    campo: 'El motivo de la cancelación',
  }),
)
const motivoCancelacionVisible = computed(
  () => motivoCancelacion(pedido.value) ?? (motivoCancelacionReciente.value || null),
)

function abrirModalCancelacion() {
  textoCancelacion.value = ''
  errorCancelacion.value = null
  modalCancelacion.value = true
}

async function confirmarCancelacion() {
  errorCancelacion.value = null
  const validacion = validarJustificacion(textoCancelacion.value, {
    campo: 'El motivo de la cancelación',
  })
  if (!validacion.valida) {
    errorCancelacion.value = validacion.error
    return
  }

  accionEnCurso.value = true
  try {
    const resultado = await cancelarPedido(pedido.value.id, textoCancelacion.value.trim())
    motivoCancelacionReciente.value = textoCancelacion.value.trim()
    modalCancelacion.value = false
    if (resultado?.motivo_registrado === false) {
      ui.warning(
        'Pedido cancelado',
        'El estado quedó Cancelado y el stock se repuso, pero el motivo no pudo persistirse en el servidor.',
      )
    } else {
      ui.success(
        'Pedido cancelado',
        'El cliente verá el estado Cancelado y el motivo en el seguimiento. El stock se repuso al catálogo.',
      )
    }
    await run()
  } catch (e) {
    errorCancelacion.value = e.message
    ui.error('No se pudo cancelar el pedido', e.message)
  } finally {
    accionEnCurso.value = false
  }
}

/* ------------------------------------------------------------------ */
/* Desglose del dinero (RF-014)                                        */
/* ------------------------------------------------------------------ */

const liquidacion = computed(() => {
  const p = pedido.value
  if (!p) return null
  const subtotal = Number(p.subtotal_productos ?? 0)
  const fee = Number(
    p.monto_fee_plataforma ?? Math.round(subtotal * REGLAS.TARIFAS.feePlataforma * 100) / 100,
  )
  const tarifaDelivery = Number(p.tarifa_delivery ?? REGLAS.TARIFAS.deliveryDefecto)
  const tasaIva = Number(p.tasa_iva ?? 0)
  const iva = Number(p.monto_iva ?? 0)
  const total = Number(p.total ?? subtotal + tarifaDelivery + iva)
  const neto = netoProductor(p)
  return {
    subtotal,
    fee,
    porcentaje: Number(p.porcentaje_fee_plataforma ?? REGLAS.TARIFAS.feePlataforma) * 100,
    tarifaDelivery,
    tasaIva,
    iva,
    total,
    neto,
  }
})

/** HAL-CLI-008: cantidad con la precisión real de la unidad (0,5 kg, no «0»). */
function cantidadDetalle(detalle) {
  return formatearCantidad(detalle.cantidad, detalle.unidad)
}
</script>

<template>
  <div class="container page">
    <CtSpinner v-if="loading" label="Cargando el pedido" />

    <CtAlert v-else-if="error" tone="danger" title="No se pudo cargar el pedido">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="run">Reintentar</CtButton>
    </CtAlert>

    <CtAlert v-else-if="!pedido" tone="warning" title="Pedido no encontrado">
      <p>El pedido que buscas no existe o no pertenece a tu tienda.</p>
      <CtButton size="sm" variant="secondary" to="/vendedor/pedidos">Volver a pedidos</CtButton>
    </CtAlert>

    <template v-else>
      <header class="page-head">
        <div class="page-head__text">
          <router-link to="/vendedor/pedidos" class="volver">
            <CtIcon name="arrowLeft" :size="14" />
            Volver a pedidos recibidos
          </router-link>
          <h1 class="page-head__title">{{ pedido.codigo_pedido }}</h1>
          <p class="page-head__subtitle">
            Realizado el {{ formatDateTime(pedido.creado_en) }} · entrega en
            {{ pedido.comuna?.nombre ?? geo.nombreComuna(pedido.comuna_entrega_id) }}
          </p>
        </div>
        <div class="page-head__actions">
          <StatusBadge type="actual" :value="estadoActual" />
          <CtButton variant="secondary" to="/vendedor/pedidos">
            <template #icon><CtIcon name="orders" :size="16" /></template>
            Pedidos recibidos
          </CtButton>
        </div>
      </header>

      <CtAlert v-if="cancelado" tone="neutral" title="Pedido cancelado" compact class="texto-largo">
        <p class="texto-largo">
          El pedido fue cancelado
          {{ pedido.cancelado_en ? `el ${formatDateTime(pedido.cancelado_en)}` : '' }}.
          <template v-if="motivoCancelacionVisible">
            Motivo registrado: {{ motivoCancelacionVisible }}.
          </template>
          <template v-else> El motivo no está disponible en el registro del pedido. </template>
          El inventario fue repuesto al catálogo y no hay acciones de entrega pendientes.
        </p>
      </CtAlert>

      <CtAlert v-else-if="!envio" tone="info" title="El envío todavía no está creado" compact>
        <p>
          El envío se genera cuando el pago de Webpay queda autorizado. Vuelve a cargar el pedido en
          unos segundos: sin envío no es posible confirmar la preparación, marcar En Tránsito ni
          cerrar la entrega.
        </p>
        <CtButton size="sm" variant="secondary" @click="run">Actualizar pedido</CtButton>
      </CtAlert>

      <CtAlert
        v-else-if="!pagoAutorizado && !entregaCerrada"
        tone="warning"
        compact
        title="Pago no autorizado"
      >
        <p>
          No encontramos el comprobante de pago autorizado de este pedido: Webpay no confirmó el
          cobro. No entregues hasta que el pago esté autorizado; si algo no cuadra, avisa al
          administrador.
        </p>
      </CtAlert>

      <!-- ============ Seguimiento ============ -->
      <CtCard title="Seguimiento de Entrega" subtitle="Estado del envío">
        <DeliveryStepper :pedido="pedido" orientation="vertical" />
      </CtCard>

      <!-- ============ Acciones de entrega ============ -->
      <CtCard
        title="Gestión de la entrega"
        subtitle="Acciones disponibles según el estado del envío"
      >
        <CtEmptyState
          v-if="cancelado"
          compact
          icon="orders"
          title="Pedido cancelado"
          message="No hay acciones de entrega disponibles. El cliente ve el estado Cancelado y el motivo en su seguimiento."
        />

        <CtEmptyState
          v-else-if="entregaCerrada || !envio"
          compact
          icon="truck"
          :title="
            envio?.estado === ESTADO_ENVIO.ENTREGADO
              ? 'Entrega confirmada'
              : envio?.estado === ESTADO_ENVIO.FALLIDO
                ? 'Entrega fallida registrada'
                : 'Sin acciones disponibles'
          "
          :message="
            envio?.estado === ESTADO_ENVIO.ENTREGADO
              ? 'El pedido quedó entregado con el código correcto; el pago de esa venta se envió a tu cuenta registrada.'
              : envio?.estado === ESTADO_ENVIO.FALLIDO
                ? `Motivo registrado: ${envio?.motivo_fallo ?? 'sin detalle'}.`
                : 'Cuando el envío exista podrás confirmar la preparación y avanzar la entrega.'
          "
        />

        <div v-else class="stack">
          <!-- HAL-CLI-010: la preparación la confirma el vendedor -->
          <div v-if="puedeMarcarPreparacion" class="accion">
            <div class="accion__texto">
              <p class="accion__titulo">Confirmar preparación</p>
              <p class="text-xs text-muted texto-largo">
                Marca este hito cuando el pedido esté listo para despacho. Recién entonces podrás
                marcarlo En Tránsito.
              </p>
            </div>
            <CtButton size="sm" :loading="accionEnCurso" @click="marcarPreparacion">
              <template #icon><CtIcon name="inventory" :size="15" /></template>
              Marcar en preparación
            </CtButton>
          </div>

          <div v-if="puedeMarcarTransito" class="accion">
            <div class="accion__texto">
              <p class="accion__titulo">Marcar pedido En Tránsito</p>
              <p class="text-xs text-muted texto-largo">
                Registra la salida hacia la comuna de destino. Al confirmarlo, el sistema genera el
                código de verificación que verá el cliente en su seguimiento.
              </p>
            </div>
            <CtButton size="sm" :loading="accionEnCurso" @click="marcarTransito">
              <template #icon><CtIcon name="truck" :size="15" /></template>
              Marcar En Tránsito
            </CtButton>
          </div>

          <div v-if="puedeCerrarEntrega" class="accion">
            <div class="accion__texto">
              <p class="accion__titulo">Cerrar la entrega</p>
              <p class="text-xs text-muted texto-largo">
                El código de entrega ya fue validado
                {{
                  envio.codigo_verificado_en
                    ? `el ${formatDateTime(envio.codigo_verificado_en)}`
                    : ''
                }}. Al confirmar, el pedido queda Entregado; el pago ya fue autorizado por Webpay.
              </p>
            </div>
            <CtButton size="sm" :loading="accionEnCurso" @click="marcarEntregado">
              <template #icon><CtIcon name="check" :size="15" /></template>
              Marcar Entregado
            </CtButton>
          </div>

          <CtAlert
            v-else-if="envio?.estado === ESTADO_ENVIO.EN_TRANSITO"
            tone="info"
            compact
            title="Falta validar el código"
            class="texto-largo"
          >
            <p class="texto-largo">
              Pídele el código de entrega al cliente e ingrésalo en «Código de entrega». Cuando
              coincida, el pedido queda automáticamente Entregado.
            </p>
          </CtAlert>

          <!-- Paso alternativo: entrega fallida -->
          <div v-if="puedeMarcarFallido" class="accion">
            <div class="accion__texto">
              <p class="accion__titulo">Marcar entrega fallida</p>
              <p class="text-xs text-muted texto-largo">
                Úsalo cuando la entrega no se pudo realizar. El motivo es obligatorio y el
                cliente y productor deben coordinar la solución directamente; el pago ya fue confirmado.
              </p>
            </div>
            <CtButton size="sm" variant="danger" :loading="accionEnCurso" @click="abrirModalFallo">
              <template #icon><CtIcon name="alert" :size="15" /></template>
              Marcar fallida
            </CtButton>
          </div>
        </div>

        <div v-if="puedeCancelar" class="accion accion--peligro">
          <div class="accion__texto">
            <p class="accion__titulo">Cancelar pedido</p>
            <p class="text-xs text-muted texto-largo">
              El pedido quedará Cancelado, se repondrá el stock y el cliente verá el motivo en su
              seguimiento. No uses esta acción para una entrega fallida.
            </p>
          </div>
          <CtButton
            size="sm"
            variant="danger"
            :disabled="accionEnCurso"
            @click="abrirModalCancelacion"
          >
            <template #icon><CtIcon name="close" :size="15" /></template>
            Cancelar pedido
          </CtButton>
        </div>
      </CtCard>

      <div class="detalle">
        <!-- ============ Columna principal ============ -->
        <div class="stack">
          <CtCard
            title="Código de entrega"
            subtitle="Lo recibe el cliente y te lo entrega al recibir el pedido"
          >
            <CtAlert v-if="cancelado" tone="neutral" compact title="Pedido cancelado">
              <p>El pedido fue cancelado y no hay un código de entrega que validar.</p>
            </CtAlert>

            <CtAlert v-else-if="!envio" tone="neutral" compact>
              <p>El pedido aún no tiene envío, por lo que tampoco tiene código de verificación.</p>
            </CtAlert>

            <CtAlert
              v-else-if="envio.estado === ESTADO_ENVIO.PREPARACION"
              tone="info"
              compact
              title="El código se genera al salir a despacho"
            >
              <p>
                El código de verificación se genera automáticamente cuando marcas el pedido En
                Tránsito. Se muestra únicamente en el seguimiento del cliente; no aparece en tu
                panel.
              </p>
            </CtAlert>

            <div v-else-if="envio.estado === ESTADO_ENVIO.EN_TRANSITO" class="stack stack--sm">
              <CtAlert v-if="codigoVerificado" tone="success" compact title="Código validado">
                <p>
                  El cliente te entregó el código correcto
                  {{
                    envio.codigo_verificado_en
                      ? `el ${formatDateTime(envio.codigo_verificado_en)}`
                      : ''
                  }}. Si el cierre automático no se aplicó, usa «Marcar Entregado» en «Gestión de la
                  entrega».
                </p>
              </CtAlert>
              <CtAlert v-else tone="info" compact title="Pídele el código al cliente">
                <p>
                  El código no se muestra en tu panel. Pídelo al cliente al entregar el pedido e
                  ingrésalo aquí para confirmar que corresponde a este envío.
                </p>
              </CtAlert>

              <div v-if="puedeVerificarCodigo" class="codigo-form">
                <CtInput
                  v-model="codigoIngresado"
                  label="Código que te entregó el cliente"
                  placeholder="Ej. 482731"
                  hint="Al completar los 6 dígitos, la entrega se valida y se cierra automáticamente."
                  :maxlength="LONGITUD_CODIGO_ENTREGA"
                  inputmode="numeric"
                  pattern="[0-9]*"
                  autocomplete="one-time-code"
                  autocapitalize="off"
                  :disabled="verificandoCodigo"
                  :error="errorCodigo"
                  @enter="confirmarCodigo"
                />
                <span v-if="verificandoCodigo" class="text-sm text-muted" role="status">
                  Validando y cerrando la entrega…
                </span>
              </div>

              <dl class="datos">
                <div>
                  <dt>Estado del código</dt>
                  <dd>
                    <CtBadge :tone="codigoVerificado ? 'success' : 'warning'" size="sm" dot>
                      {{
                        codigoVerificado ? 'Validado por el vendedor' : 'Pendiente de validación'
                      }}
                    </CtBadge>
                  </dd>
                </div>
                <div>
                  <dt>En tránsito desde</dt>
                  <dd>{{ formatDateTime(envio.despachado_en) }}</dd>
                </div>
                <div v-if="envio.codigo_verificado_en">
                  <dt>Código validado el</dt>
                  <dd>{{ formatDateTime(envio.codigo_verificado_en) }}</dd>
                </div>
                <div v-if="envio.entregado_en">
                  <dt>Entregado el</dt>
                  <dd>{{ formatDateTime(envio.entregado_en) }}</dd>
                </div>
              </dl>
            </div>

            <CtAlert
              v-else-if="envio.estado === ESTADO_ENVIO.FALLIDO"
              tone="danger"
              compact
              title="Entrega fallida"
              class="texto-largo"
            >
              <p class="texto-largo">
                Motivo registrado: {{ envio.motivo_fallo ?? 'sin detalle' }}. El administrador
                revisa el caso y decide la devolución del dinero al cliente.
              </p>
            </CtAlert>

            <CtAlert
              v-else-if="envio.estado === ESTADO_ENVIO_CANCELADO"
              tone="neutral"
              compact
              title="Pedido cancelado"
              class="texto-largo"
            >
              <p class="texto-largo">
                El pedido fue cancelado{{
                  motivoCancelacionVisible ? `: ${motivoCancelacionVisible}` : ''
                }}. No hay un código de entrega que validar.
              </p>
            </CtAlert>

            <CtAlert v-else tone="success" compact title="Entrega confirmada">
              <p>
                El pedido se entregó con el código correcto el
                {{ formatDateTime(envio.entregado_en) }}. El pago de esa venta se envió a tu cuenta
                registrada.
              </p>
            </CtAlert>
          </CtCard>

          <CtCard title="Productos del pedido" subtitle="Detalle enviado al cliente">
            <div class="tabla-wrap">
              <table class="items">
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th class="num">Código</th>
                    <th class="num">Precio Unit.</th>
                    <th class="num">Cantidad</th>
                    <th class="num">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="detalle in pedido.detalles" :key="detalle.id">
                    <td>
                      <router-link
                        v-if="detalle.producto_id"
                        :to="`/producto/${detalle.producto_id}`"
                        class="enlace texto-largo"
                      >
                        {{ detalle.producto_nombre }}
                      </router-link>
                      <span v-else class="texto-largo">{{ detalle.producto_nombre }}</span>
                    </td>
                    <td class="num">{{ detalle.codigo_producto ?? '—' }}</td>
                    <td class="num">{{ formatCLP(detalle.precio_unitario) }}</td>
                    <td class="num">
                      {{ cantidadDetalle(detalle) }}
                      {{ LABELS.unidad[detalle.unidad] ?? detalle.unidad ?? '' }}
                    </td>
                    <td class="num font-semibold">{{ formatCLP(detalle.subtotal) }}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <CtEmptyState
              v-if="!pedido.detalles?.length"
              compact
              icon="inventory"
              title="Sin ítems registrados"
              message="El pedido no tiene líneas de detalle asociadas."
            />
          </CtCard>
        </div>

        <!-- ============ Columna lateral ============ -->
        <aside class="stack">
          <CtCard title="Información de Envío" subtitle="Destinatario y ruta de entrega">
            <dl class="datos">
              <div>
                <dt>Destinatario</dt>
                <dd class="texto-largo">{{ pedido.nombre_destinatario ?? '—' }}</dd>
              </div>
              <div>
                <dt>Teléfono</dt>
                <dd>{{ formatPhone(pedido.telefono_destinatario) }}</dd>
              </div>
              <div>
                <dt>Dirección</dt>
                <dd class="texto-largo">{{ pedido.direccion_entrega ?? '—' }}</dd>
              </div>
              <div>
                <dt>Referencia</dt>
                <dd class="texto-largo">{{ pedido.referencia_entrega ?? 'Sin instrucciones' }}</dd>
              </div>
              <div>
                <dt>Comuna de entrega</dt>
                <dd class="texto-largo">
                  {{ pedido.comuna?.nombre ?? geo.nombreComuna(pedido.comuna_entrega_id) }},
                  {{ geo.nombreRegion(pedido.region_entrega_id) }}
                </dd>
              </div>
              <div>
                <dt>Método de pago</dt>
                <dd>{{ metodoPago }}</dd>
              </div>
              <div>
                <dt>Estado del pago</dt>
                <dd>
                  <StatusBadge
                    v-if="pedido.pago"
                    type="pago"
                    :value="pedido.pago.estado"
                    size="sm"
                    :dot="false"
                  />
                  <span v-else>Sin pago registrado</span>
                </dd>
              </div>
            </dl>

            <CtAlert tone="info" compact title="Boleta o factura por correo">
              <p class="texto-largo">
                El comprobante tributario (boleta o factura) se envía por correo a los datos
                ingresados en el checkout. CuTuCo no emite documentos tributarios.
              </p>
            </CtAlert>
          </CtCard>

          <CtCard
            v-if="liquidacion"
            title="Desglose del dinero"
            subtitle="Modelo de negocio de CuTuCo"
          >
            <dl class="datos">
              <div>
                <dt>Subtotal productos</dt>
                <dd>{{ formatCLP(liquidacion.subtotal) }}</dd>
              </div>
              <div>
                <dt>Delivery (tarifa fija)</dt>
                <dd>{{ formatCLP(liquidacion.tarifaDelivery) }}</dd>
              </div>
              <div v-if="liquidacion.tasaIva || liquidacion.iva">
                <dt>IVA ({{ formatNumber(liquidacion.tasaIva * 100) }}%)</dt>
                <dd>{{ formatCLP(liquidacion.iva) }}</dd>
              </div>
              <div>
                <dt>
                  Comisión de CuTuCo
                  <span class="text-xs text-muted"
                    >({{ formatNumber(liquidacion.porcentaje) }}%)</span
                  >
                </dt>
                <dd>− {{ formatCLP(liquidacion.fee) }}</dd>
              </div>
              <div>
                <dt>Total pagado por el cliente</dt>
                <dd>{{ formatCLP(liquidacion.total) }}</dd>
              </div>
            </dl>

            <div class="neto">
              <span>Recibes</span>
              <strong>{{ formatCLP(liquidacion.neto) }}</strong>
            </div>

            <CtAlert tone="neutral" compact>
              <p class="texto-largo">
                El pago se confirmó con Webpay. Recibes el monto de la venta menos la comisión del
                5% de CuTuCo.
              </p>
            </CtAlert>

            <CtMoneyInfo title="Cómo se calcula este desglose">
              <p>
                El total del cliente se forma con productos, despacho e IVA cuando corresponde. La
                comisión de plataforma se calcula sobre el subtotal de productos y se descuenta en
                Webpay Mall; no vuelve a cobrarse al cliente.
              </p>
            </CtMoneyInfo>
          </CtCard>
        </aside>
      </div>
    </template>

    <!-- ============ Entrega fallida ============ -->
    <CtModal
      v-model="modalFallo"
      title="Marcar entrega fallida"
      subtitle="El motivo es obligatorio y queda registrado en el envío"
    >
      <div class="stack">
        <CtAlert tone="warning" compact>
          <p class="texto-largo">
            Al registrar la entrega fallida el pedido sale de la ruta de entrega. El pago ya fue
            confirmado; coordina directamente con el cliente cómo resolver el problema.
          </p>
        </CtAlert>
        <CtSelect
          v-model="motivoFallo"
          label="Motivo de la entrega fallida"
          required
          :options="opcionesMotivoFallo"
          :error="errorFallo"
          placeholder="Selecciona el motivo"
        />
        <CtTextarea
          v-model="notaFallo"
          label="Detalle adicional (opcional)"
          :rows="3"
          :maxlength="LIMITE_JUSTIFICACION"
          placeholder="Explica brevemente qué ocurrió en el domicilio"
          hint="Se suma al motivo elegido. Máximo 1.000 caracteres en total."
          :error="errorJustificacion"
        />
        <p
          class="contador"
          :class="{ 'is-error': validacionFallo.longitud > LIMITE_JUSTIFICACION }"
          aria-live="polite"
        >
          {{ validacionFallo.longitud }} / 1.000 caracteres
        </p>
      </div>

      <template #footer>
        <CtButton variant="secondary" :disabled="accionEnCurso" @click="modalFallo = false">
          Cancelar
        </CtButton>
        <CtButton variant="danger" :loading="accionEnCurso" @click="confirmarFallo">
          Registrar entrega fallida
        </CtButton>
      </template>
    </CtModal>

    <!-- ============ Cancelación ============ -->
    <CtModal
      v-model="modalCancelacion"
      title="Cancelar el pedido"
      subtitle="El estado Cancelado y el motivo quedan visibles para el cliente"
    >
      <div class="stack">
        <CtAlert tone="danger" compact>
          <p class="texto-largo">
            El pedido quedará Cancelado y el stock se repondrá al catálogo. Usa la entrega fallida
            sólo cuando el pedido ya había salido a despacho y no se pudo entregar.
          </p>
        </CtAlert>
        <CtTextarea
          v-model="textoCancelacion"
          label="Motivo de la cancelación"
          required
          :rows="4"
          :maxlength="LIMITE_JUSTIFICACION"
          placeholder="Explica al cliente por qué se cancela el pedido"
          hint="El cliente verá este motivo en el seguimiento del pedido."
          :error="errorCancelacion"
        />
        <p
          class="contador"
          :class="{ 'is-error': validacionCancelacion.longitud > LIMITE_JUSTIFICACION }"
          aria-live="polite"
        >
          {{ validacionCancelacion.longitud }} / 1.000 caracteres
        </p>
      </div>

      <template #footer>
        <CtButton variant="secondary" :disabled="accionEnCurso" @click="modalCancelacion = false">
          Volver
        </CtButton>
        <CtButton variant="danger" :loading="accionEnCurso" @click="confirmarCancelacion">
          Cancelar pedido
        </CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.detalle {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 340px;
  gap: var(--ct-space-6);
  align-items: start;
}

@media (max-width: 1100px) {
  .detalle {
    grid-template-columns: minmax(0, 1fr);
  }
}

.volver {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  min-height: 24px;
  padding-inline: 2px;
  border-radius: var(--ct-radius-sm);
  color: var(--ct-primary-strong);
  text-decoration: none;
  font-size: var(--ct-fs-sm);
}

.volver:hover {
  text-decoration: none;
}

.accion {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
  padding: var(--ct-space-4);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
  min-width: 0;
}

.accion + .accion {
  margin-top: var(--ct-space-3);
}

.accion--peligro {
  margin-top: var(--ct-space-4);
  border-color: var(--ct-danger);
  background: var(--ct-danger-soft);
}

.accion__texto {
  min-width: 0;
  flex: 1 1 260px;
}

.accion__titulo {
  font-weight: var(--ct-fw-semibold);
  margin-bottom: 2px;
}

.codigo-form {
  display: flex;
  align-items: flex-end;
  gap: var(--ct-space-3);
  flex-wrap: wrap;
  padding: var(--ct-space-4);
  border: 1px dashed var(--ct-border-strong);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
}

.codigo-form > :first-child {
  flex: 1 1 260px;
  min-width: 0;
}

.contador {
  margin: 0;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  text-align: right;
}

.contador.is-error {
  color: var(--ct-danger);
  font-weight: var(--ct-fw-semibold);
}

.texto-largo {
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

/* HAL-VEN-027: el motivo largo de la entrega fallida también envuelve dentro
   del estado vacío y de las alertas. */
:deep(.ct-empty__message) {
  overflow-wrap: anywhere;
  word-break: break-word;
  max-width: 100%;
}

.tabla-wrap {
  overflow-x: auto;
}

.items {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--ct-fs-md);
}

.items th {
  text-align: left;
  font-size: var(--ct-fs-xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-soft);
  padding: var(--ct-space-2) var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.items td {
  padding: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.items tbody tr:last-child td {
  border-bottom: none;
}

.num {
  text-align: right;
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.datos div {
  display: flex;
  justify-content: space-between;
  gap: var(--ct-space-4);
  min-width: 0;
}

.datos dt {
  flex-shrink: 0;
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.datos dd {
  margin: 0;
  min-width: 0;
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
  text-align: right;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.neto {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  margin-top: var(--ct-space-4);
  padding-top: var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
  font-size: var(--ct-fs-lg);
}

.neto strong {
  color: var(--ct-success);
}

.enlace {
  display: inline-block;
  min-height: 24px;
  padding-block: 2px;
  font-weight: var(--ct-fw-semibold);
  color: var(--ct-primary-strong);
}
</style>
