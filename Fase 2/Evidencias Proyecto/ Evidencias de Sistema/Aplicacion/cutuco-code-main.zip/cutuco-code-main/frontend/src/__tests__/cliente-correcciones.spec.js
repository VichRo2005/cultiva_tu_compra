/**
 * CuTuCo — Correcciones del flujo cliente (HAL-CLI-001/003/004/008/010/012/
 * 013/016/019/022/023/024/025/026/027 y HAL-VEN-027).
 *
 * Pruebas locales, sin backend:
 *   - dirección con número opcional/alfanumérico y depto separado;
 *   - etiqueta real del comprobante y ausencia de evidencias/IVA inventado;
 *   - código de entrega como texto y calificación sólo tras la entrega;
 *   - consentimiento expreso de términos en el checkout;
 *   - máximos locales de contraseña (72) y correo (254);
 *   - unidad comercial y cantidades decimales del carrito;
 *   - aislamiento del carrito entre cuentas.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { createMemoryHistory, createRouter } from 'vue-router'
import { nextTick } from 'vue'

const serviciosOrders = vi.hoisted(() => ({
  iniciarPago: vi.fn(),
  getEmpresaTributaria: vi.fn(),
  getPedidoDetalle: vi.fn(),
  confirmarPago: vi.fn(),
  verificarCodigoEntrega: vi.fn(),
  createEvaluacion: vi.fn(),
  confirmarRecepcion: vi.fn(),
}))
const serviciosGeography = vi.hoisted(() => ({
  getJerarquiaGeografica: vi.fn(),
  getComuna: vi.fn(),
  getRegion: vi.fn(),
  getRegionProductor: vi.fn(),
  getRegionDeDireccion: vi.fn(),
  listDirecciones: vi.fn(),
  createDireccion: vi.fn(),
  updateDireccion: vi.fn(),
}))
const serviciosCatalog = vi.hoisted(() => ({
  getProductorDetalle: vi.fn(),
  getProducto: vi.fn(),
}))
const serviciosReclamos = vi.hoisted(() => ({
  getReclamoVigenteDePedido: vi.fn(),
  crearReclamo: vi.fn(),
}))
const toasts = vi.hoisted(() => ({
  success: vi.fn(),
  error: vi.fn(),
  warning: vi.fn(),
  info: vi.fn(),
}))

vi.mock('@/services/orders', () => serviciosOrders)
vi.mock('@/services/geography', async (importOriginal) => ({
  ...(await importOriginal()),
  ...serviciosGeography,
}))
vi.mock('@/services/catalog', async (importOriginal) => ({
  ...(await importOriginal()),
  ...serviciosCatalog,
}))
vi.mock('@/services/reclamos', async (importOriginal) => ({
  ...(await importOriginal()),
  ...serviciosReclamos,
}))
vi.mock('@/stores/ui', () => ({ useUiStore: () => toasts }))

import {
  emailPolicyMessage,
  isDeptoOficina,
  isEmail,
  isNumeroDireccion,
  passwordPolicyMessage,
  LIMITES,
} from '@/lib/validation'
import { useCartStore } from '@/stores/cart'
import { useAuthStore } from '@/stores/auth'
import CheckoutView from '@/views/client/CheckoutView.vue'
import ClientOrderDetailView from '@/views/client/ClientOrderDetailView.vue'
import PaymentResultView from '@/views/client/PaymentResultView.vue'

const REGION = { id: 'r1', nombre: 'Metropolitana' }
const COMUNA = { id: 'c1', nombre: 'Paine', region_id: 'r1' }
const DIRECCION = {
  id: 'dir-1',
  etiqueta: 'Casa',
  calle: 'Calle Compañía',
  numero: '123-B',
  depto_oficina: 'Depto 4',
  referencia: null,
  comuna_id: 'c1',
  es_principal: true,
  activo: true,
}

const PRODUCTO = {
  id: 'p1',
  nombre: 'Tomates',
  precio: 2800,
  stock: 10,
  unidad_medida: 'kg',
  productor_id: 'pr1',
  productor: { nombre_comercial: 'Huerta Sur' },
  imagenPrincipal: null,
}

function crearRouter(path) {
  const router = createRouter({
    history: createMemoryHistory(),
    routes: [
      { path: '/checkout', component: { template: '<div />' } },
      { path: '/pago/retorno', name: 'pago-retorno', component: { template: '<div />' } },
      { path: '/cliente/pedidos', component: { template: '<div />' } },
      { path: '/cliente/pedidos/:id', component: { template: '<div />' } },
      { path: '/cliente/reclamos/:id', component: { template: '<div />' } },
      { path: '/producto/:id', component: { template: '<div />' } },
      { path: '/carrito', component: { template: '<div />' } },
      { path: '/catalogo', component: { template: '<div />' } },
      { path: '/terminos', component: { template: '<div />' } },
    ],
  })
  router.push(path)
  return router
}

function prepararGeografia() {
  serviciosGeography.getJerarquiaGeografica.mockResolvedValue([
    { id: REGION.id, codigo: 'RM', nombre: REGION.nombre, comunas: [COMUNA] },
  ])
  serviciosGeography.getComuna.mockResolvedValue(COMUNA)
  serviciosGeography.getRegion.mockResolvedValue(REGION)
  serviciosGeography.getRegionProductor.mockResolvedValue(REGION)
  serviciosGeography.getRegionDeDireccion.mockResolvedValue({ comuna: COMUNA, region: REGION })
  serviciosGeography.listDirecciones.mockResolvedValue([{ ...DIRECCION }])
  serviciosGeography.createDireccion.mockResolvedValue({ ...DIRECCION, id: 'dir-2' })
  serviciosGeography.updateDireccion.mockResolvedValue({ ...DIRECCION })
}

beforeEach(() => {
  vi.resetAllMocks()
  localStorage.clear()
  setActivePinia(createPinia())
  prepararGeografia()
  serviciosReclamos.getReclamoVigenteDePedido.mockResolvedValue(null)
  serviciosCatalog.getProductorDetalle.mockResolvedValue({
    id: 'pr1',
    nombre_comercial: 'Huerta Sur',
    activo: true,
    puntaje_reputacion: 4.5,
    cantidad_evaluaciones: 2,
    perfil: { telefono: '+56912345678' },
  })
})

afterEach(() => {
  document.body.innerHTML = ''
})

describe('direcciones · número opcional y depto separado', () => {
  it('acepta número vacío y valores alfanuméricos, pero no controles ni exceso', () => {
    expect(isNumeroDireccion('')).toBe(true)
    expect(isNumeroDireccion('123-B')).toBe(true)
    expect(isNumeroDireccion('Casa 3')).toBe(true)
    expect(isNumeroDireccion('Parcela 4')).toBe(true)
    expect(isNumeroDireccion('x'.repeat(LIMITES.numero + 1))).toBe(false)
    expect(isNumeroDireccion('linea\u0000rota')).toBe(false)
  })

  it('acepta depto/oficina vacío y complementos alfanuméricos', () => {
    expect(isDeptoOficina('')).toBe(true)
    expect(isDeptoOficina('Depto 12')).toBe(true)
    expect(isDeptoOficina('Parcela 4')).toBe(true)
    expect(isDeptoOficina('Local B')).toBe(true)
    expect(isDeptoOficina('x'.repeat(LIMITES.deptoOficina + 1))).toBe(false)
  })
})

describe('seguridad · máximos locales en español', () => {
  it('rechaza contraseña de 73 caracteres antes de llamar a Auth', () => {
    const larga = `Aa1!${'x'.repeat(LIMITES.password - 4)}x`
    expect(larga).toHaveLength(LIMITES.password + 1)
    expect(passwordPolicyMessage(larga)).toContain(String(LIMITES.password))
    expect(passwordPolicyMessage('Aa1!' + 'x'.repeat(68))).toBeNull()
  })

  it('rechaza correo sobre 254 caracteres con mensaje local', () => {
    const correo = `${'a'.repeat(246)}@dominio.cl`
    expect(correo.length).toBeGreaterThan(LIMITES.email)
    expect(isEmail(correo)).toBe(false)
    expect(emailPolicyMessage(correo)).toContain(String(LIMITES.email))
  })
})

describe('carrito · unidad y aislamiento por cuenta', () => {
  it('conserva la unidad de venta y admite decimales en kg', () => {
    const cart = useCartStore()
    cart.agregar(PRODUCTO, 1.5)

    expect(cart.items[0].unidad).toBe('kg')
    expect(cart.totalItems).toBe(1.5)
    expect(cart.subtotal).toBe(4200)
    expect(cart.total).toBe(9163)

    // HAL-CLI-008: la cantidad fraccionable admite hasta UN decimal
    cart.setCantidad(PRODUCTO.id, 2.5)
    expect(cart.items[0].cantidad).toBe(2.5)
    expect(cart.subtotal).toBe(7000)
    // dos decimales ya no se aceptan en unidades fraccionables
    cart.setCantidad(PRODUCTO.id, 2.25)
    expect(cart.items[0].cantidad).toBe(2.5)
  })

  it('separa el carrito de dos cuentas en el mismo navegador', async () => {
    const auth = useAuthStore()
    auth.user = { id: 'cuenta-a', email: 'a@cutuco.cl' }
    const cart = useCartStore()
    cart.agregar(PRODUCTO, 1)
    await nextTick()

    expect(cart.vacio).toBe(false)
    expect(localStorage.getItem('cutuco:carrito:cuenta-a')).toContain('p1')

    auth.user = { id: 'cuenta-b', email: 'b@cutuco.cl' }
    await nextTick()
    expect(cart.vacio).toBe(true)
    expect(localStorage.getItem('cutuco:carrito:cuenta-a')).toContain('p1')

    auth.user = { id: 'cuenta-a', email: 'a@cutuco.cl' }
    await nextTick()
    expect(cart.items).toHaveLength(1)
  })
})

describe('checkout · consentimiento expreso y documento del productor', () => {
  let wrapper
  async function montar() {
    const auth = useAuthStore()
    auth.user = { id: 'cliente-1', email: 'cliente@cutuco.cl' }
    auth.perfil = {
      id: 'cliente-1',
      nombre: 'Ana',
      apellido: 'Pérez',
      telefono: '+56912345678',
    }
    const cart = useCartStore()
    cart.agregar(PRODUCTO, 1.5)

    const router = crearRouter('/checkout')
    await router.isReady()
    wrapper = mount(CheckoutView, { global: { plugins: [router] } })
    await flushPromises()
    await flushPromises()
    return wrapper
  }

  it('exige aceptar términos una sola vez y no atribuye la factura a CuTuCo', async () => {
    await montar()
    expect(wrapper.text()).toContain('El documento lo genera el productor')
    expect(wrapper.text()).toContain('CuTuCo no emite ni administra boletas o facturas electrónicas')
    expect(wrapper.text()).toContain('1,5 kg')

    const revisar = wrapper.findAll('button').find((b) => b.text().includes('Revisar el pago'))
    expect(revisar.attributes('disabled')).toBeUndefined()
    await revisar.trigger('click')
    await nextTick()

    const aRevision = wrapper.findAll('button').find((b) => b.text().includes('Ir a la revisión final'))
    await aRevision.trigger('click')
    await nextTick()

    const continuar = wrapper.findAll('button').find((b) => b.text().includes('Continuar al Pago'))
    expect(continuar.attributes('disabled')).toBeDefined()

    const checkbox = wrapper.find('input[type="checkbox"]')
    expect(checkbox.exists()).toBe(true)
    await checkbox.setValue(true)
    await nextTick()

    const continuarHabilitado = wrapper
      .findAll('button')
      .find((b) => b.text().includes('Continuar al Pago'))
    expect(continuarHabilitado.attributes('disabled')).toBeUndefined()
  })
  it('bloquea el pago si una tienda tiene subtotal fraccionario y explica cómo corregirlo', async () => {
    await montar()
    await wrapper.findAll('button').find((b) => b.text().includes('Revisar el pago')).trigger('click')
    await nextTick()
    await wrapper.findAll('button').find((b) => b.text().includes('Ir a la revisión final')).trigger('click')
    await nextTick()
    await wrapper.find('input[type="checkbox"]').setValue(true)
    const cart = useCartStore()
    cart.items[0].precio = 1001
    await nextTick()
    expect(wrapper.text()).toContain('el subtotal de cada tienda debe quedar en pesos enteros')
    expect(wrapper.text()).toContain('$1.501,50')
    const pagar = () => wrapper.findAll('button').find((b) => b.text().includes('Continuar al Pago'))
    expect(pagar().attributes('disabled')).toBeDefined()
    expect(serviciosOrders.iniciarPago).not.toHaveBeenCalled()
    cart.setCantidad(PRODUCTO.id, 2)
    await nextTick()
    expect(pagar().attributes('disabled')).toBeUndefined()
  })
  it('detiene el pago si el stock reduce la cantidad solicitada durante la sincronización', async () => {
    await montar()
    serviciosCatalog.getProducto.mockResolvedValue({ ...PRODUCTO, activo: true, stock: 1 })
    await wrapper.findAll('button').find((b) => b.text().includes('Revisar el pago')).trigger('click')
    await nextTick()
    await wrapper.findAll('button').find((b) => b.text().includes('Ir a la revisión final')).trigger('click')
    await nextTick()
    await wrapper.find('input[type="checkbox"]').setValue(true)
    await wrapper.findAll('button').find((b) => b.text().includes('Continuar al Pago')).trigger('click')
    await flushPromises()
    expect(serviciosOrders.iniciarPago).not.toHaveBeenCalled()
    expect(useCartStore().items[0].cantidad).toBe(1)
    expect(wrapper.text()).toContain('No hay stock suficiente para: Tomates')
  })

  it('detiene la creación del pago cuando el precio cambia y exige aceptación expresa', async () => {
    await montar()
    serviciosCatalog.getProducto.mockResolvedValue({ ...PRODUCTO, activo: true, precio: 3000 })
    await wrapper.findAll('button').find((b) => b.text().includes('Revisar el pago')).trigger('click')
    await nextTick()
    await wrapper.findAll('button').find((b) => b.text().includes('Ir a la revisión final')).trigger('click')
    await nextTick()
    await wrapper.find('input[type="checkbox"]').setValue(true)
    await wrapper.findAll('button').find((b) => b.text().includes('Continuar al Pago')).trigger('click')
    await flushPromises()
    expect(serviciosOrders.iniciarPago).not.toHaveBeenCalled()
    expect(useCartStore().items[0].precio).toBe(3000)
    expect(document.body.textContent).toContain('Los precios cambiaron')
    expect(document.body.textContent).toContain('Aceptar y continuar')
    expect(document.body.textContent).toContain('$9.520')
    serviciosOrders.iniciarPago.mockRejectedValue(new Error('Pasarela simulada no disponible'))
    const aceptar = [...document.body.querySelectorAll('button')]
      .find((button) => button.textContent.includes('Aceptar y continuar'))
    aceptar.click()
    await flushPromises()
    expect(serviciosOrders.iniciarPago).toHaveBeenCalledWith(expect.objectContaining({
      montoEsperado: 9520,
    }))
  })
})

describe('detalle del pedido · comprobante, hitos y código de texto', () => {
  let wrapper

  function pedidoBase(overrides = {}) {
    return {
      id: 'ped-1',
      codigo_pedido: 'CUTU-20261001-ABC123',
      estado: 'en_transito',
      creado_en: '2026-10-01T10:00:00Z',
      subtotal_productos: 10000,
      monto_fee_plataforma: 500,
      total: 13500,
      nombre_destinatario: 'Ana Pérez',
      direccion_entrega: 'Calle Compañía 123-B',
      referencia_entrega: null,
      documento_tributario: { tipo: 'boleta', rut: '66666666-6' },
      confirmado_cliente_en: null,
      detalles: [
        {
          id: 'd1',
          producto_id: 'p1',
          producto_nombre: 'Tomates',
          precio_unitario: 5000,
          cantidad: 2,
          subtotal: 10000,
        },
      ],
      pago: {
        estado: 'autorizado',
        monto: 13000,
        monto_fee_descontado: 500,
        buy_order: 'BO-1',
        codigo_autorizacion: '777',
        creado_en: '2026-10-01T10:01:00Z',
        autorizado_en: '2026-10-01T10:01:00Z',
      },
      envio: {
        id: 'env-1',
        estado: 'en_transito',
        tarifa_fija: 3500,
        creado_en: '2026-10-01T10:02:00Z',
        despachado_en: '2026-10-01T11:00:00Z',
        entregado_en: null,
        codigo_verificacion: '482731',
        codigo_verificado_en: null,
        motivo_fallo: null,
      },
      productor: { nombre_comercial: 'Huerta Sur' },
      comuna: { nombre: 'Paine' },
      evaluacion: null,
      ...overrides,
    }
  }

  async function montar(pedido) {
    serviciosOrders.getPedidoDetalle.mockResolvedValue(pedido)
    const router = crearRouter('/cliente/pedidos/ped-1')
    await router.isReady()
    wrapper = mount(ClientOrderDetailView, { global: { plugins: [router] } })
    await flushPromises()
    await flushPromises()
    return wrapper
  }

  it('usa "Descargar comprobante", elimina evidencias/IVA y no simula la preparación', async () => {
    await montar(pedidoBase())

    expect(wrapper.text()).toContain('Descargar comprobante (PDF)')
    expect(wrapper.text()).not.toContain('Descargar Factura')
    expect(wrapper.text()).not.toContain('Comprobante Visual')
    expect(wrapper.text()).not.toContain('0 evidencias')
    expect(wrapper.text()).not.toContain('IVA (19%) referencial')

    const preparacion = wrapper
      .findAll('.hito')
      .find((hito) => hito.text().includes('Preparación'))
    expect(preparacion).toBeTruthy()
    expect(preparacion.text()).toContain('Fecha no registrada')
    expect(preparacion.text()).not.toContain('10:02')
    expect(wrapper.text()).not.toContain('Califica al vendedor')
  })

  it('muestra el código al cliente para que lo entregue al vendedor, sin verificación propia', async () => {
    await montar(pedidoBase())

    expect(wrapper.text()).toContain('482731')
    expect(wrapper.text()).toContain('Entrega estos 6 dígitos al vendedor')
    expect(wrapper.text()).toContain('El cliente no lo ingresa en la plataforma')
    expect(wrapper.findAll('button').some((b) => b.text().includes('Verificar el código'))).toBe(false)
    expect(document.body.querySelector('.ct-modal')).toBeNull()
  })

  it('habilita la calificación sólo cuando el pedido está completado por el vendedor', async () => {
    await montar(pedidoBase())

    expect(wrapper.text()).not.toContain('Califica al vendedor')

    wrapper.unmount()
    await montar(
      pedidoBase({
        estado: 'completado',
        confirmado_cliente_en: '2026-10-01T11:30:00Z',
        envio: {
          ...pedidoBase().envio,
          estado: 'entregado',
          entregado_en: '2026-10-01T11:30:00Z',
          codigo_verificado_en: '2026-10-01T11:29:00Z',
        },
      }),
    )

    expect(wrapper.text()).toContain('Califica al vendedor')
    expect(wrapper.text()).toContain('Entrega confirmada por el vendedor')
  })

  it('no afirma que el vendedor recibió el aviso hasta que el correo queda confirmado', async () => {
    serviciosOrders.confirmarPago.mockResolvedValue({
      ok: true,
      estado: 'autorizado',
      pedidos: [{ pedido_id: 'ped-1' }],
      ya_confirmado: false,
      requiere_conciliacion: false,
    })
    serviciosOrders.getPedidoDetalle.mockResolvedValue(
      pedidoBase({ correo_productor_enviado_en: null }),
    )
    const router = crearRouter('/pago/retorno?token_ws=tok-1')
    await router.isReady()
    wrapper = mount(PaymentResultView, { global: { plugins: [router] } })
    await flushPromises()
    await flushPromises()

    expect(wrapper.text()).not.toContain('El vendedor ya recibió el aviso')
    expect(wrapper.text()).toContain('Aviso al vendedor: en proceso')

    wrapper.unmount()
    serviciosOrders.getPedidoDetalle.mockResolvedValue(
      pedidoBase({ correo_productor_enviado_en: '2026-10-01T10:03:00Z' }),
    )
    const router2 = crearRouter('/pago/retorno?token_ws=tok-2')
    await router2.isReady()
    wrapper = mount(PaymentResultView, { global: { plugins: [router2] } })
    await flushPromises()
    await flushPromises()

    expect(wrapper.text()).toContain('Aviso al vendedor: confirmado')
  })

  it('no presenta la autorización parcial como rechazo ni invita a repetir el cobro', async () => {
    serviciosOrders.confirmarPago.mockResolvedValue({
      ok: false, estado: 'parcial', pedidos: [], requiere_conciliacion: true,
    })
    const cart = useCartStore()
    cart.agregar(PRODUCTO, 1)
    const router = crearRouter('/pago/retorno?token_ws=token-parcial-qa')
    await router.isReady()
    wrapper = mount(PaymentResultView, { global: { plugins: [router] } })
    await flushPromises()
    expect(wrapper.text()).toContain('Pago autorizado de forma parcial')
    expect(wrapper.text()).toMatch(/no repitas la compra completa/i)
    expect(wrapper.text()).not.toContain('Reintentar la confirmación')
    expect(toasts.error).not.toHaveBeenCalled()
    expect(toasts.warning).toHaveBeenCalledWith('Estamos revisando el pago', expect.any(String))
    expect(cart.items).toHaveLength(1)
  })

  it('muestra el motivo de cancelación y no lo presenta como entrega fallida', async () => {
    await montar(
      pedidoBase({
        estado: 'cancelado',
        motivo_cancelacion: 'El producto se dañó antes del despacho',
        envio: {
          ...pedidoBase().envio,
          estado: 'fallido',
          motivo_fallo: 'Domicilio no encontrado',
        },
      }),
    )

    expect(wrapper.text()).toContain('El producto se dañó antes del despacho')
    expect(wrapper.text()).toContain('cancelación')
    expect(wrapper.text()).not.toContain('La entrega falló')
  })
})
