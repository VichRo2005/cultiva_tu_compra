/**
 * CuTuCo — Carrito de compras (RF-002).
 *
 * Un pedido pertenece a un único vendedor (`pedidos.productor_id`), así que el
 * carrito agrupa por vendedor y Webpay Mall genera un pedido por cada tienda.
 * La cobertura se valida contra la región de cada vendedor (RF-009),
 * nunca por comuna ni con geolocalización.
 */

import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { REGLAS } from '@/lib/constants'
import { subtotalCLP } from '@/lib/pricing'
import { desgloseConIva, TASA_IVA_CHILE } from '@/lib/taxes'
import { obtenerConfiguracionCobro } from '@/services/configuracionCobro'
import {
  configuracionCantidadProducto,
  esCantidadValida,
  formatearCantidad,
  redondearCantidad,
} from '@/services/catalog'
import { getRegionProductor, getRegionDeDireccion } from '@/services/geography'
import { useAuthStore } from '@/stores/auth'

/**
 * El carrito de invitado conserva la clave histórica. Cada cuenta autenticada
 * tiene su propia clave para que dos clientes del mismo navegador no compartan
 * productos ni cantidades (CLI-CAR-007).
 */
const STORAGE_KEY = 'cutuco:carrito'

function clavePara(userId) {
  return userId ? `${STORAGE_KEY}:${userId}` : STORAGE_KEY
}

function load(clave = STORAGE_KEY) {
  try {
    const raw = localStorage.getItem(clave)
    const parsed = raw ? JSON.parse(raw) : []
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function guardar(clave, items) {
  try {
    localStorage.setItem(clave, JSON.stringify(items))
  } catch {
    /* almacenamiento no disponible */
  }
}

const round2 = (n) => Math.round(n * 100) / 100

function reglasCantidad(producto = {}) {
  return configuracionCantidadProducto({
    unidad_medida: producto.unidad_medida ?? producto.unidad,
    stock: producto.stock,
    incremento_venta: producto.incremento_venta ?? producto.incrementoVenta,
    cantidad_minima_compra: producto.cantidad_minima_compra ?? producto.cantidadMinimaCompra,
  })
}

function errorCantidadInvalida(cantidad, config) {
  const valor = Number(cantidad)
  if (!Number.isFinite(valor) || valor <= 0) return 'La cantidad debe ser mayor que cero.'
  if (config.decimales === 0 && !Number.isInteger(valor)) {
    return 'Este producto requiere una cantidad entera.'
  }
  if (Math.abs(redondearCantidad(valor, config.decimales) - valor) > 1e-9) {
    return `La cantidad admite hasta ${config.decimales === 1 ? 'un decimal' : `${config.decimales} decimales`}.`
  }
  if (valor + 1e-9 < config.min) {
    return `La compra mínima es ${formatearCantidad(config.min, config.unidad)} ${config.unidad}.`
  }
  if (valor - 1e-9 > config.max) {
    return `Sólo quedan ${formatearCantidad(config.max, config.unidad)} ${config.unidad} disponibles.`
  }
  return `Este producto se vende en incrementos de ${formatearCantidad(config.paso, config.unidad)} ${config.unidad}.`
}

export const useCartStore = defineStore('cart', () => {
  const auth = useAuthStore()
  const usuarioId = computed(() => auth.user?.id ?? null)

  let storageKey = clavePara(usuarioId.value)
  /** @type {import('vue').Ref<Array>} */
  const items = ref(load(storageKey))
  /** Dirección de entrega elegida en el checkout: { direccionId, comunaId, regionId }. */
  const destino = ref({ direccionId: null, comunaId: null, regionId: null })
  const cargando = ref(false)
  const cobertura = ref(null)
  /** Tasa vigente leída desde la configuración pública; el backend la vuelve a validar. */
  const tasaIva = ref(TASA_IVA_CHILE)

  watch(
    items,
    (value) => guardar(storageKey, value),
    { deep: true },
  )

  /**
   * Aislamiento por cuenta: al iniciar sesión se carga el carrito propio y, si
   * la cuenta aún no tenía uno, se migra el carrito de invitado. Al cerrar
   * sesión el carrito de la cuenta queda guardado en su clave y la sesión de
   * invitado arranca vacía.
   */
  watch(usuarioId, (nuevo, anterior) => {
    if (nuevo === anterior) return
    const claveAnterior = clavePara(anterior)
    guardar(claveAnterior, items.value)

    const propio = load(clavePara(nuevo))
    const migrarInvitado = !anterior && Boolean(nuevo) && !propio.length && items.value.length
    storageKey = clavePara(nuevo)
    if (migrarInvitado) {
      guardar(storageKey, items.value)
      try {
        localStorage.removeItem(clavePara(null))
      } catch {
        /* almacenamiento no disponible */
      }
    } else {
      items.value = propio
    }
    destino.value = { direccionId: null, comunaId: null, regionId: null }
    cobertura.value = null
  })

  const totalItems = computed(() => items.value.reduce((acc, i) => acc + Number(i.cantidad), 0))
  const cantidadProductos = computed(() => items.value.length)
  const subtotalLinea = (item) => subtotalCLP(item.precio, item.cantidad)
  const subtotal = computed(() => round2(items.value.reduce((acc, i) => acc + subtotalLinea(i), 0)))
  const envio = computed(() => REGLAS.TARIFAS.deliveryDefecto * porVendedor.value.length)
  // El backend redondea la comisión a CLP enteros por tienda, no por carrito.
  const comision = computed(() => porVendedor.value.reduce((suma, vendedor) => {
    const base = round2(vendedor.items.reduce((acc, item) => acc + subtotalLinea(item), 0))
    return suma + Math.round(base * REGLAS.TARIFAS.feePlataforma)
  }, 0))
  const desgloseIva = computed(() =>
    desgloseConIva({ subtotalProductos: subtotal.value, despacho: envio.value, tasa: tasaIva.value }),
  )
  const baseImponible = computed(() => desgloseIva.value.baseImponible)
  const iva = computed(() => desgloseIva.value.iva)
  const total = computed(() => desgloseIva.value.total)
  const vacio = computed(() => items.value.length === 0)

  /** Vendedores presentes en el carrito: un despacho y pedido por tienda. */
  const porVendedor = computed(() => {
    const map = new Map()
    for (const item of items.value) {
      if (!map.has(item.productorId)) {
        map.set(item.productorId, {
          productorId: item.productorId,
          productorNombre: item.productorNombre,
          items: [],
        })
      }
      map.get(item.productorId).items.push(item)
    }
    return [...map.values()]
  })

  const errorMontos = computed(() => porVendedor.value.some((grupo) =>
    !Number.isSafeInteger(round2(grupo.items.reduce((acc, item) => acc + subtotalLinea(item), 0))),
  ) ? 'Ajusta las cantidades: el subtotal de cada tienda debe quedar en pesos enteros para pagar.' : null)

  const vendedorPrincipal = computed(() => porVendedor.value[0] ?? null)
  const requiereVariosVendedores = computed(() => porVendedor.value.length > 1)

  /* ------------------------- disponibilidad ------------------------- */

  function cantidadDe(productoId) {
    return items.value.find((i) => i.productoId === productoId)?.cantidad ?? 0
  }

  function agregar(producto, cantidad = null) {
    const config = reglasCantidad(producto)
    if (config.agotado) {
      throw new Error('Este producto no tiene stock suficiente para su compra mínima por ahora.')
    }

    const cantidadNum = Number(cantidad ?? config.inicial)
    if (!esCantidadValida(cantidadNum, config)) throw new Error(errorCantidadInvalida(cantidadNum, config))

    const existente = items.value.find((i) => i.productoId === producto.id)
    if (existente) {
      if (existente.productorId !== producto.productor_id) {
        throw new Error(
          'Cada pedido en CuTuCo corresponde a un solo vendedor. Finaliza o quita los productos de la otra tienda.',
        )
      }
      const nueva = redondearCantidad(Number(existente.cantidad) + cantidadNum, config.decimales)
      if (!esCantidadValida(nueva, config)) throw new Error(errorCantidadInvalida(nueva, config))
      existente.stock = Number(producto.stock)
      existente.incrementoVenta = config.paso
      existente.cantidadMinimaCompra = config.min
      existente.cantidad = nueva
      return existente
    }

    const nuevo = {
      productoId: producto.id,
      nombre: producto.nombre,
      precio: Number(producto.precio),
      unidad: producto.unidad_medida ?? config.unidad,
      imagen: producto.imagenPrincipal?.url ?? null,
      productorId: producto.productor_id,
      productorNombre: producto.productor?.nombre_comercial ?? 'Vendedor',
      productorComuna: producto.comunaProductor?.nombre ?? '',
      categoria: producto.categoria?.nombre ?? null,
      cantidad: cantidadNum,
      stock: Number(producto.stock),
      incrementoVenta: config.paso,
      cantidadMinimaCompra: config.min,
    }
    items.value.push(nuevo)
    return nuevo
  }

  /** Ajusta la cantidad respetando el stock disponible (RF-002). */
  function setCantidad(productoId, cantidad) {
    const item = items.value.find((i) => i.productoId === productoId)
    if (!item) return
    // Un valor indeterminado o negativo no debe alterar la línea.
    if (cantidad === '' || cantidad === null || cantidad === undefined) return
    const n = Number(cantidad)
    if (!Number.isFinite(n) || n < 0) return
    if (n === 0) {
      quitar(productoId)
      return
    }
    const config = reglasCantidad(item)
    const ajustada = n > config.max ? config.max : n
    if (!esCantidadValida(ajustada, config)) return
    item.cantidad = redondearCantidad(ajustada, config.decimales)
  }

  function ajustar(productoId, delta) {
    const item = items.value.find((i) => i.productoId === productoId)
    if (!item) return
    const config = reglasCantidad(item)
    setCantidad(productoId, redondearCantidad(Number(item.cantidad) + delta, config.decimales))
  }

  function quitar(productoId) {
    items.value = items.value.filter((i) => i.productoId !== productoId)
  }

  function limpiar() {
    items.value = []
    destino.value = { direccionId: null, comunaId: null, regionId: null }
    cobertura.value = null
  }

  /** Sincroniza el resumen visible con el interruptor global de IVA. */
  async function cargarConfiguracionIva() {
    try {
      const configuracion = await obtenerConfiguracionCobro()
      tasaIva.value = configuracion.ivaHabilitado ? configuracion.tasaIva : 0
      return configuracion
    } catch {
      // Si la consulta temporalmente falla, se conserva 19%: el backend es la
      // fuente autoritativa y rechazará un total que no coincida antes de cobrar.
      tasaIva.value = TASA_IVA_CHILE
      return { ivaHabilitado: true, tasaIva: TASA_IVA_CHILE }
    }
  }

  /* --------------------------- cobertura --------------------------- */

  const validandoCobertura = ref(false)

  /**
   * RF-009: compara la región del vendedor con la región de la dirección de
   * entrega. Se ejecuta antes de crear el pago.
   */
  async function validarCobertura(direccion) {
    const vendedores = porVendedor.value
    if (!vendedores.length || !direccion?.comuna_id) {
      cobertura.value = null
      return { ok: false, motivo: 'Selecciona una dirección de entrega.' }
    }
    validandoCobertura.value = true
    cobertura.value = null
    try {
      const [regiones, regionCliente] = await Promise.all([
        Promise.all(vendedores.map((v) => getRegionProductor(v.productorId))),
        getRegionDeDireccion(direccion).then((r) => r?.region ?? null),
      ])
      if (regiones.some((r) => !r)) {
        cobertura.value = { ok: false, motivo: 'El vendedor no tiene una región registrada.' }
        return cobertura.value
      }
      if (!regionCliente) {
        cobertura.value = { ok: false, motivo: 'Tu dirección no tiene una región registrada.' }
        return cobertura.value
      }
      const regionVendedor = regiones[0]
      const fuera = vendedores.filter((_, i) => regiones[i].id !== regionCliente.id)
      const ok = fuera.length === 0
      cobertura.value = {
        ok,
        regionVendedor,
        regionCliente,
        productoresFuera: fuera.map((v) => v.productorId),
        motivo: ok
          ? null
          : `${fuera.map((v) => v.productorNombre).join(', ')} no entrega en ${regionCliente.nombre}.`,
      }
      return cobertura.value
    } finally {
      validandoCobertura.value = false
    }
  }

  /** Refresca precios y stock contra el catálogo antes del checkout. */
  async function sincronizar() {
    if (!items.value.length) return
    cargando.value = true
    try {
      const { getProducto } = await import('@/services/catalog')
      const sinStock = []
      for (const item of items.value) {
        const producto = await getProducto(item.productoId)
        if (!producto || !producto.activo) {
          sinStock.push(item.nombre)
          continue
        }
        item.precio = Number(producto.precio)
        item.stock = Number(producto.stock)
        item.nombre = producto.nombre
        // La unidad comercial del producto se mantiene en el carrito y en el
        // pedido (HAL-CLI-008); no se reemplaza por "unidades" genéricas.
        item.unidad = producto.unidad_medida ?? item.unidad
        item.imagen = producto.imagenPrincipal?.url ?? item.imagen
        item.incrementoVenta = producto.incremento_venta ?? item.incrementoVenta
        item.cantidadMinimaCompra = producto.cantidad_minima_compra ?? item.cantidadMinimaCompra
        if (Number(item.stock) <= 0) {
          sinStock.push(item.nombre)
          continue
        }
        const config = reglasCantidad(item)
        if (config.agotado) {
          sinStock.push(item.nombre)
          continue
        }
        if (!esCantidadValida(item.cantidad, config)) {
          // Si el stock bajó, conservar la mayor parte posible de la
          // selección del cliente. Volver al mínimo (p. ej. 0,1 kg) cuando
          // aún hay 1 kg disponible cambia el pedido más de lo necesario.
          // `max` ya respeta el paso comercial y la precisión de la unidad.
          const cantidadAjustada = redondearCantidad(
            Math.min(Number(item.cantidad), config.max),
            config.decimales,
          )
          item.cantidad = esCantidadValida(cantidadAjustada, config)
            ? cantidadAjustada
            : config.inicial
          sinStock.push(item.nombre)
        }
      }
      return sinStock
    } finally {
      cargando.value = false
    }
  }

  /** Ítems en el formato que espera FastAPI (`/api/webpay/iniciar`). */
  function toItems() {
    return items.value.map((i) => ({
      productoId: i.productoId,
      cantidad: Number(i.cantidad),
    }))
  }

  return {
    items,
    destino,
    cargando,
    cobertura,
    validandoCobertura,
    totalItems,
    cantidadProductos,
    subtotal,
    errorMontos,
    envio,
    comision,
    tasaIva,
    baseImponible,
    iva,
    total,
    vacio,
    porVendedor,
    vendedorPrincipal,
    requiereVariosVendedores,
    cantidadDe,
    agregar,
    setCantidad,
    ajustar,
    quitar,
    limpiar,
    cargarConfiguracionIva,
    validarCobertura,
    sincronizar,
    toItems,
  }
})
