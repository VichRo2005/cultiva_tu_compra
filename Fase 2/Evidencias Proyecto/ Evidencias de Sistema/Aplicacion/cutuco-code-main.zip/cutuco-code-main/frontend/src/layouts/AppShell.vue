<script setup>
/**
 * CuTuCo — Shell persistente de la aplicación.
 * Envuelve todas las ventanas de producto (público, cliente, vendedor y admin)
 * con la barra lateral, la barra superior y el pie comunes del diseño.
 *
 * Además muestra el aviso de sanciones vigentes (RF-026 / r54 del mapeo): las
 * sanciones se cargan al iniciar sesión en `stores/auth.js`, así que el banner
 * aparece apenas el vendedor entra, sin tener que abrir su panel.
 */
import { computed } from 'vue'
import AppFooter from '@/components/layout/AppFooter.vue'
import AppSidebar from '@/components/layout/AppSidebar.vue'
import AppTopbar from '@/components/layout/AppTopbar.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import DevOverlay from '@/dev/DevOverlay.vue'
import { LABELS } from '@/lib/constants'
import { formatDate } from '@/lib/format'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const auth = useAuthStore()

const sancion = computed(() => auth.sancionesVigentes[0] ?? null)

const tituloSancion = computed(() => {
  const actual = sancion.value
  if (!actual) return ''
  return actual.estado === 'apelada'
    ? 'Tienes una sanción en revisión'
    : 'Tienes una sanción vigente'
})

const detalleSancion = computed(() => {
  const actual = sancion.value
  if (!actual) return ''
  const partes = [`${LABELS.tipoSancion[actual.tipo] ?? actual.tipo}: ${actual.motivo}`]
  if (actual.accion !== 'ninguna') {
    partes.push(`Acción: ${LABELS.accionSancion[actual.accion] ?? actual.accion}`)
  }
  if (actual.fin_en) partes.push(`Hasta el ${formatDate(actual.fin_en)}`)
  if (auth.sancionesVigentes.length > 1) {
    partes.push(`Y ${auth.sancionesVigentes.length - 1} sanción(es) más`)
  }
  return partes.join(' · ')
})
</script>

<template>
  <div class="ct-shell">
    <AppSidebar :open="ui.sidebarAbierto" @navigate="ui.sidebarAbierto = false" />

    <div class="ct-shell__main">
      <AppTopbar />
      <DevOverlay />
      <main class="ct-shell__content">
        <div v-if="sancion" class="container ct-shell__aviso">
          <CtAlert :title="tituloSancion" tone="warning">
            <p class="ct-shell__aviso-texto">
              <CtIcon name="alert" :size="16" />
              <span>{{ detalleSancion }}</span>
            </p>
            <CtButton size="sm" variant="secondary" to="/vendedor/sanciones">
              Ver mis sanciones y apelar
            </CtButton>
          </CtAlert>
        </div>

        <RouterView v-slot="{ Component }">
          <Transition name="fade" mode="out-in">
            <component :is="Component" />
          </Transition>
        </RouterView>
      </main>
      <AppFooter />
    </div>

    <button
      v-if="ui.sidebarAbierto"
      type="button"
      class="ct-shell__scrim"
      aria-label="Cerrar navegación"
      @click="ui.sidebarAbierto = false"
    />
  </div>
</template>

<style scoped>
.ct-shell {
  display: flex;
  align-items: stretch;
  min-height: 100vh;
  min-height: 100dvh;
  background: var(--ct-gradient-main);
}

.ct-shell__main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.ct-shell__content {
  flex: 1;
  padding-block: var(--ct-space-8);
  background: #f7f7f8;
}

.ct-shell__aviso {
  padding-bottom: var(--ct-space-5);
}

.ct-shell__aviso-texto {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.ct-shell__aviso-texto > span {
  flex: 1;
  min-width: 0;
}

.ct-shell__scrim {
  display: none;
}

@media (max-width: 1024px) {
  .ct-shell__scrim {
    display: block;
    position: fixed;
    inset: 0;
    z-index: calc(var(--ct-z-sidebar) - 1);
    background: var(--ct-overlay);
    border: none;
  }
}
</style>
