<script setup>
/**
 * Servicio mensual de CuTuCo para vendedores.
 *
 * Regla vigente (ver docs/servicio-plataforma.md):
 *   $2.990/mes para nuevas cuotas, vence 10 días después de emitida la cuota, 5 días de gracia.
 *   Toda transferencia queda pendiente de revisión administrativa. Webpay se confirma con Transbank.
 *   Al día 16 sin pago la tienda queda suspendida y se reactiva al pagar.
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import { formatCLP, formatDate, formatDateTime } from '@/lib/format'
import {
  ESTADO_SERVICIO,
  ESTADO_TIENDA_SERVICIO,
  REGLAS_SERVICIO,
} from '@/lib/constants'
import {
  diasHastaSuspension,
  DATOS_TRANSFERENCIA_CUTUCO_VACIOS,
  etiquetaEstadoServicio,
  fechasCuotaServicio,
  getMiServicio,
  iniciarPagoServicioWebpay,
  listPagosServicio,
  obtenerDatosTransferenciaCutuco,
  registrarTransferenciaServicio,
  tonoEstadoServicio,
} from '@/services/servicio'
import { useUiStore } from '@/stores/ui'

const route = useRoute()
const ui = useUiStore()

const cargando = ref(true)
const errorCarga = ref(null)
const servicio = ref(null)
const historial = ref([])
const modalTransferencia = ref(false)
const guardando = ref(false)
const iniciandoWebpay = ref(false)
const transferencia = ref({ referencia: '', observaciones: '' })
const errores = ref({})
const webpay = ref({ url: '', token: '' })
const formWebpay = ref(null)
const datosBancariosCutuco = ref({ ...DATOS_TRANSFERENCIA_CUTUCO_VACIOS })
const errorDatosTransferencia = ref(null)

const cuota = computed(() => servicio.value?.cuota ?? null)
const historialFilas = computed(() => historial.value.map(filaHistorial))
const estado = computed(() => servicio.value?.estado ?? ESTADO_TIENDA_SERVICIO.SIN_PRODUCTOR)
const sinProductor = computed(() => estado.value === ESTADO_TIENDA_SERVICIO.SIN_PRODUCTOR)
const puedePagar = computed(
  () =>
    cuota.value &&
    [ESTADO_SERVICIO.PENDIENTE, ESTADO_SERVICIO.RECHAZADO].includes(cuota.value.estado),
)
const enRevision = computed(
  () =>
    estado.value === ESTADO_TIENDA_SERVICIO.PENDIENTE_REVISION ||
    cuota.value?.estado === ESTADO_SERVICIO.PENDIENTE_REVISION,
)
const diasRestantes = computed(() => {
  if (![ESTADO_SERVICIO.PENDIENTE, ESTADO_SERVICIO.RECHAZADO].includes(cuota.value?.estado)) return null
  return diasHastaSuspension(cuota.value)
})

/** Fechas derivadas de la cuota con la regla 10 días + 5 de gracia (HAL-VEN-019). */
const plazosCuota = computed(() => fechasCuotaServicio(cuota.value))

const textoDiasRestantes = computed(() => {
  if (diasRestantes.value === null) return '—'
  if (diasRestantes.value < 0) return 'Plazo vencido'
  if (diasRestantes.value === 0) return 'Último día de gracia'
  return diasRestantes.value === 1 ? '1 día' : `${diasRestantes.value} días`
})

const transferenciaConfigurada = computed(() =>
  ['banco', 'tipoCuenta', 'numeroCuenta', 'titular', 'rut'].every((campo) =>
    Boolean(datosBancariosCutuco.value[campo]),
  ),
)

/**
 * Filas de la cuenta de CuTuCo. Si falta la configuración se mantiene la fila
 * con el placeholder y el botón Copiar deshabilitado.
 */
const datosTransferencia = computed(() => {
  const campos = [
    { campo: 'banco', etiqueta: 'Banco', valor: datosBancariosCutuco.value.banco },
    { campo: 'tipoCuenta', etiqueta: 'Tipo de cuenta', valor: datosBancariosCutuco.value.tipoCuenta },
    { campo: 'numeroCuenta', etiqueta: 'Número de cuenta', valor: datosBancariosCutuco.value.numeroCuenta },
    { campo: 'titular', etiqueta: 'Titular', valor: datosBancariosCutuco.value.titular },
    { campo: 'rut', etiqueta: 'RUT', valor: datosBancariosCutuco.value.rut },
  ]
  return campos.map((fila) => ({
    ...fila,
    valorVisible: fila.valor || 'No configurado',
  }))
})

const montoTransferencia = computed(() => Number(cuota.value?.monto ?? REGLAS_SERVICIO.montoMensual))

/** Texto conjunto listo para pegar en el comprobante o en un correo. */
const textoTransferencia = computed(() => {
  const lineas = [
    `Cuota mensual CuTuCo: ${formatCLP(montoTransferencia.value)}`,
    `Período: ${cuota.value?.periodo ? formatDate(cuota.value.periodo) : '—'}`,
    ...datosTransferencia.value.map((fila) => `${fila.etiqueta}: ${fila.valor || 'No configurado'}`),
  ]
  return lineas.join('\n')
})

const copiadoCampo = ref(null)
const mensajeCopia = ref('')
let temporizadorCopia = null

async function escribirPortapapeles(texto) {
  if (navigator?.clipboard?.writeText) {
    await navigator.clipboard.writeText(texto)
    return
  }
  // Fallback para navegadores sin Clipboard API.
  const area = document.createElement('textarea')
  area.value = texto
  area.setAttribute('readonly', '')
  area.style.position = 'fixed'
  area.style.opacity = '0'
  document.body.appendChild(area)
  area.select()
  const ok = document.execCommand('copy')
  document.body.removeChild(area)
  if (!ok) throw new Error('copy-failed')
}

async function copiar(campo, texto, etiqueta = '') {
  if (!texto) return
  try {
    await escribirPortapapeles(texto)
    copiadoCampo.value = campo
    mensajeCopia.value = `${etiqueta || 'Dato'} copiado al portapapeles.`
    ui.success('Copiado', mensajeCopia.value)
    if (temporizadorCopia) clearTimeout(temporizadorCopia)
    temporizadorCopia = setTimeout(() => {
      copiadoCampo.value = null
      mensajeCopia.value = ''
    }, 2400)
  } catch {
    mensajeCopia.value = 'No se pudo copiar. Selecciona el texto y cópialo manualmente.'
    ui.error('No se pudo copiar', mensajeCopia.value)
  }
}

function copiarTodos() {
  return copiar('todos', textoTransferencia.value, 'Datos de transferencia')
}

onBeforeUnmount(() => {
  if (temporizadorCopia) clearTimeout(temporizadorCopia)
})

const columnas = [
  { key: 'periodo', label: 'Período' },
  { key: 'monto', label: 'Monto', align: 'right' },
  { key: 'vence_en', label: 'Vencimiento' },
  { key: 'estado', label: 'Estado' },
  { key: 'metodo', label: 'Método' },
  { key: 'pagado_en', label: 'Pagado' },
]

function filaHistorial(pago) {
  return {
    ...pago,
    periodo: formatDate(pago.periodo),
    monto: formatCLP(pago.monto),
    vence_en: formatDate(pago.vence_en),
    pagado_en: pago.pagado_en ? formatDateTime(pago.pagado_en) : '—',
    metodo: pago.metodo === 'webpay' ? 'Webpay' : pago.metodo === 'transferencia' ? 'Transferencia' : '—',
  }
}

async function cargar() {
  cargando.value = true
  errorCarga.value = null
  errorDatosTransferencia.value = null
  try {
    const [estadoServicio, pagos, datosTransferencia] = await Promise.all([
      getMiServicio(),
      listPagosServicio(),
      obtenerDatosTransferenciaCutuco().catch((error) => {
        errorDatosTransferencia.value = error?.message ?? 'No se pudieron verificar los datos bancarios.'
        return { ...DATOS_TRANSFERENCIA_CUTUCO_VACIOS }
      }),
    ])
    servicio.value = estadoServicio
    historial.value = pagos
    datosBancariosCutuco.value = datosTransferencia
  } catch (e) {
    errorCarga.value = e?.message ?? 'No se pudo cargar el estado del servicio'
  } finally {
    cargando.value = false
  }
}

function abrirTransferencia() {
  transferencia.value = { referencia: '', observaciones: '' }
  errores.value = {}
  modalTransferencia.value = true
}

async function guardarTransferencia() {
  errores.value = {}
  const referencia = transferencia.value.referencia.trim()
  if (!referencia) {
    errores.value = { referencia: 'Ingresa el número de operación de la transferencia.' }
    return
  }
  guardando.value = true
  try {
    const result = await registrarTransferenciaServicio({
      referencia,
      observaciones: transferencia.value.observaciones,
    })
    modalTransferencia.value = false
    await cargar()
    if (result?.automatico) {
      ui.success('Pago registrado', 'Tu transferencia quedó validada y el servicio está al día.')
    } else {
      ui.info(
        'Pago enviado a revisión',
        'El administrador revisará la transferencia y actualizará el estado.',
      )
    }
  } catch (e) {
    ui.error('No se pudo registrar la transferencia', e.message)
  } finally {
    guardando.value = false
  }
}

async function pagarConWebpay() {
  iniciandoWebpay.value = true
  try {
    const respuesta = await iniciarPagoServicioWebpay()
    // El backend pudo recuperar un pago anterior autorizado sin commit: no hay
    // que redirigir a Webpay, el servicio ya quedó pagado (o en conciliación).
    if (respuesta.estado === 'pagado' || !respuesta.url) {
      ui.success(
        'Pago confirmado',
        respuesta.estado === 'pagado'
          ? 'Tu pago anterior quedó autorizado y se confirmó; el servicio está al día.'
          : 'Estamos revisando el pago anterior. Revisa su estado o usa transferencia.',
      )
      await cargar()
      return
    }
    webpay.value = { url: respuesta.url, token: respuesta.token_ws }
    await nextTick()
    formWebpay.value?.submit()
  } catch (e) {
    ui.error('No se pudo iniciar Webpay', e?.message ?? 'Intenta nuevamente o usa transferencia')
  } finally {
    iniciandoWebpay.value = false
  }
}

onMounted(async () => {
  await cargar()
  const pago = String(route.query.pago ?? '')
  if (pago === 'pagado') ui.success('Pago confirmado', 'El servicio quedó al día.')
  else if (pago === 'error') ui.error('Pago no confirmado', 'No se registró el pago. Intenta de nuevo.')
  else if (pago === 'cancelado') ui.info('Pago cancelado', 'Puedes pagar con transferencia o Webpay.')
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Servicio y pagos</h1>
        <p class="page-head__subtitle">
          Mantén habilitada tu tienda en CuTuCo. Cuota mensual de
          {{ formatCLP(REGLAS_SERVICIO.montoMensual) }}.
        </p>
      </div>
      <CtButton variant="secondary" :loading="cargando" @click="cargar">Actualizar</CtButton>
    </header>

    <CtAlert v-if="errorCarga" tone="danger" title="No pudimos cargar tu servicio">
      <p>{{ errorCarga }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-else-if="cargando" label="Cargando tu servicio…" />

    <template v-else>
      <CtEmptyState
        v-if="sinProductor"
        icon="store"
        title="Aún no tienes una tienda"
        message="El servicio mensual se activa cuando tu postulación de vendedor es aprobada."
      />

      <template v-else>
        <CtAlert
          v-if="estado === ESTADO_TIENDA_SERVICIO.VENCIDO"
          tone="danger"
          title="Servicio vencido: tu tienda está suspendida"
        >
          <p>
            La cuota venció y no se registró el pago dentro de los
            {{ REGLAS_SERVICIO.diasGracia }} días de gracia. Regulariza el pago para reactivar
            automáticamente la venta; tus productos y pedidos no se eliminan.
          </p>
        </CtAlert>
        <CtAlert
          v-else-if="enRevision"
          tone="info"
          title="Transferencia pendiente de revisión"
        >
          <p>
            El administrador está revisando tu pago. Mientras tanto no se te suspende; si se
            rechaza, deberás pagar nuevamente.
          </p>
        </CtAlert>
        <CtAlert
          v-else-if="estado === ESTADO_TIENDA_SERVICIO.PENDIENTE"
          tone="warning"
          title="Tienes una cuota pendiente"
        >
          <p>
            La cuota vence el {{ plazosCuota?.vence ? formatDate(plazosCuota.vence) : '—' }} y tienes
            {{ REGLAS_SERVICIO.diasGracia }} días de gracia, hasta el
            {{ plazosCuota?.graciaHasta ? formatDate(plazosCuota.graciaHasta) : '—' }}. La venta se
            suspende desde el
            {{ plazosCuota?.suspensionDesde ? formatDate(plazosCuota.suspensionDesde) : '—' }}.
          </p>
        </CtAlert>
        <CtAlert v-else tone="success" title="Servicio al día">
          <p>Tu tienda está habilitada para vender en CuTuCo.</p>
        </CtAlert>

        <div class="servicio__grid">
          <CtCard padding="md">
            <div class="servicio__estado">
              <div>
                <p class="eyebrow">Estado actual</p>
                <h2 class="servicio__titulo">{{ etiquetaEstadoServicio(estado) }}</h2>
              </div>
              <CtBadge :tone="tonoEstadoServicio(estado)" size="md">
                {{ etiquetaEstadoServicio(estado) }}
              </CtBadge>
            </div>
            <dl class="servicio__datos">
              <div>
                <dt>Cuota mensual</dt>
                <dd>{{ formatCLP(cuota?.monto ?? REGLAS_SERVICIO.montoMensual) }}</dd>
              </div>
              <div>
                <dt>Período facturado</dt>
                <dd>{{ cuota?.periodo ? formatDate(cuota.periodo) : '—' }}</dd>
              </div>
              <div>
                <dt>Emitida</dt>
                <dd>{{ plazosCuota?.emision ? formatDate(plazosCuota.emision) : '—' }}</dd>
              </div>
              <div>
                <dt>Vencimiento</dt>
                <dd>{{ plazosCuota?.vence ? formatDate(plazosCuota.vence) : '—' }}</dd>
              </div>
              <div>
                <dt>Gracia hasta</dt>
                <dd>{{ plazosCuota?.graciaHasta ? formatDate(plazosCuota.graciaHasta) : '—' }}</dd>
              </div>
              <div>
                <dt>Suspensión desde</dt>
                <dd>{{ plazosCuota?.suspensionDesde ? formatDate(plazosCuota.suspensionDesde) : '—' }}</dd>
              </div>
              <div>
                <dt>Días hasta la suspensión</dt>
                <dd :class="{ 'text-danger': diasRestantes !== null && diasRestantes < 0 }">
                  {{ textoDiasRestantes }}
                </dd>
              </div>
            </dl>
            <div class="servicio__acciones">
              <CtButton v-if="puedePagar" :loading="iniciandoWebpay" @click="pagarConWebpay">
                Pagar con Webpay
              </CtButton>
              <CtButton
                v-if="puedePagar"
                variant="secondary"
                @click="abrirTransferencia"
              >
                Registrar transferencia
              </CtButton>
              <p v-if="!puedePagar && !enRevision" class="text-sm text-muted">
                No hay una cuota pendiente de pago.
              </p>
            </div>
          </CtCard>

          <CtCard padding="md">
            <h2 class="eyebrow">Cómo funciona</h2>
            <ul class="servicio__reglas">
              <li>
                El período facturado es el mes calendario. La cuota se emite al aprobar tu tienda o al
                abrir este panel por primera vez en el mes.
              </li>
              <li>
                Vence {{ REGLAS_SERVICIO.diasVencimiento }} días después de su emisión (no el día 1 del
                período).
              </li>
              <li>
                Hay {{ REGLAS_SERVICIO.diasGracia }} días de gracia después del vencimiento; la venta se
                suspende al día siguiente del último día de gracia.
              </li>
              <li>
                Toda transferencia requiere revisión administrativa antes de marcar la cuota como pagada.
              </li>
              <li>Cuando se confirme tu pago con Webpay, la tienda se reactivará automáticamente.</li>
              <li>La suspensión no elimina productos, pedidos ni tu cuenta.</li>
            </ul>
          </CtCard>
        </div>

        <CtCard padding="md">
          <h2 class="eyebrow">Historial de pagos</h2>
          <CtTable
            :columns="columnas"
            :rows="historialFilas"
            row-key="id"
            empty-message="Todavía no hay pagos registrados."
          >
            <template #cell-estado="{ row }">
              <CtBadge :tone="tonoEstadoServicio(row.estado)">
                {{ etiquetaEstadoServicio(row.estado) }}
              </CtBadge>
            </template>
          </CtTable>
        </CtCard>
      </template>
    </template>

    <CtModal
      v-model="modalTransferencia"
      title="Registrar transferencia"
      subtitle="Transfiere el monto de la cuota a la cuenta de CuTuCo y registra el número de operación."
      size="md"
    >
      <div class="stack">
        <CtAlert
          v-if="errorDatosTransferencia"
          tone="warning"
          title="No pudimos verificar los datos bancarios de CuTuCo"
        >
          <p>
            {{ errorDatosTransferencia }} No deposites en una cuenta distinta: intenta actualizar o
            paga con Webpay.
          </p>
        </CtAlert>
        <CtAlert
          v-else-if="!transferenciaConfigurada"
          tone="warning"
          title="Datos bancarios de CuTuCo no configurados"
        >
          <p>
            Esta instalación todavía no publica los datos para transferir. No deposites en una cuenta
            distinta: solicita los datos a administración o paga con Webpay. Cuando CuTuCo publique
            sus datos de transferencia, aparecerán aquí para que puedas copiarlos.
          </p>
        </CtAlert>

        <div class="transferencia">
          <div class="row row--between row--wrap">
            <div>
              <p class="eyebrow">Datos para transferir</p>
              <p class="transferencia__monto">
                Monto: <strong>{{ formatCLP(montoTransferencia) }}</strong>
                <span v-if="cuota?.periodo" class="text-muted">
                  · período {{ formatDate(cuota.periodo) }}
                </span>
              </p>
            </div>
            <CtBadge :tone="transferenciaConfigurada ? 'success' : 'warning'" size="sm">
              {{ transferenciaConfigurada ? 'Datos publicados' : 'Sin configurar' }}
            </CtBadge>
          </div>

          <dl class="transferencia__lista">
            <div v-for="fila in datosTransferencia" :key="fila.campo" class="transferencia__fila">
              <dt>{{ fila.etiqueta }}</dt>
              <dd :class="{ 'transferencia__placeholder': !fila.valor }">
                {{ fila.valorVisible }}
              </dd>
              <CtButton
                size="sm"
                variant="ghost"
                :disabled="!fila.valor"
                :aria-label="`Copiar ${fila.etiqueta.toLowerCase()}`"
                @click="copiar(fila.campo, fila.valor, fila.etiqueta)"
              >
                <template #icon><CtIcon name="doc" :size="14" /></template>
                {{ copiadoCampo === fila.campo ? 'Copiado' : 'Copiar' }}
              </CtButton>
            </div>
          </dl>

          <div class="row row--wrap">
            <CtButton
              size="sm"
              variant="secondary"
              :disabled="!transferenciaConfigurada"
              @click="copiarTodos"
            >
              <template #icon><CtIcon name="doc" :size="14" /></template>
              {{ copiadoCampo === 'todos' ? 'Datos copiados' : 'Copiar todos los datos' }}
            </CtButton>
            <span class="text-xs text-muted">
              Incluye monto, período, banco, tipo y número de cuenta, titular y RUT.
            </span>
          </div>
          <p v-if="mensajeCopia" class="transferencia__estado" role="status" aria-live="polite">
            {{ mensajeCopia }}
          </p>
        </div>

        <CtInput
          v-model="transferencia.referencia"
          label="N° de operación"
          placeholder="Ej. 123456789"
          :error="errores.referencia"
          required
          maxlength="80"
        />
        <CtTextarea
          v-model="transferencia.observaciones"
          label="Observaciones (opcional)"
          :rows="3"
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" @click="modalTransferencia = false">Cancelar</CtButton>
        <CtButton :loading="guardando" @click="guardarTransferencia">Registrar pago</CtButton>
      </template>
    </CtModal>

    <form ref="formWebpay" :action="webpay.url" method="post" class="webpay">
      <input type="hidden" name="token_ws" :value="webpay.token" />
    </form>
  </div>
</template>

<style scoped>
.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.transferencia {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface-alt);
  min-width: 0;
}

.transferencia__monto {
  margin: var(--ct-space-1) 0 0;
  font-size: var(--ct-fs-md);
}

.transferencia__lista {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-1);
  margin: 0;
}

.transferencia__fila {
  display: grid;
  grid-template-columns: minmax(110px, 0.8fr) minmax(0, 1.6fr) auto;
  align-items: center;
  gap: var(--ct-space-3);
  padding: var(--ct-space-2) 0;
  border-bottom: 1px solid var(--ct-border);
}

.transferencia__fila:last-child {
  border-bottom: none;
}

.transferencia__fila dt {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
}

.transferencia__fila dd {
  margin: 0;
  min-width: 0;
  font-weight: var(--ct-fw-semibold);
  overflow-wrap: anywhere;
}

.transferencia__placeholder {
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-medium);
  font-style: italic;
}

.transferencia__estado {
  margin: 0;
  color: var(--ct-success);
  font-size: var(--ct-fs-sm);
}

@media (max-width: 640px) {
  .transferencia__fila {
    grid-template-columns: minmax(0, 1fr) auto;
  }

  .transferencia__fila dt {
    grid-column: 1 / -1;
  }
}

.servicio__grid {
  display: grid;
  grid-template-columns: 1.25fr 1fr;
  gap: var(--ct-space-4);
}
.servicio__estado {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--ct-space-4);
}
.servicio__titulo {
  margin: 2px 0 0;
  font-size: var(--ct-fs-xl);
}
.servicio__datos {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
  margin: var(--ct-space-5) 0;
}
.servicio__datos dt {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.servicio__datos dd {
  margin: 2px 0 0;
  font-weight: var(--ct-fw-semibold);
}
.servicio__acciones {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-3);
  align-items: center;
}
.servicio__reglas {
  margin: var(--ct-space-3) 0 0;
  padding-left: 1.1rem;
  display: grid;
  gap: var(--ct-space-2);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-sm);
}
.webpay {
  display: none;
}
@media (max-width: 860px) {
  .servicio__grid {
    grid-template-columns: 1fr;
  }
  .servicio__datos {
    grid-template-columns: 1fr;
  }
}
</style>
