<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import ProductDetailView from '@/views/public/ProductDetailView.vue'
import { exportExcel } from '@/lib/csv'
import { formatCLP, formatDate, formatNumber } from '@/lib/format'
import {
  arbolDesdeListaPlana,
  formatearCantidad,
  normalizarNombreCategoria,
  opcionesCategoriasJerarquicas,
} from '@/services/catalog'
import {
  cargarCatalogoAdmin,
  cambiarEstadoProductoAdmin,
  errorMotivoProducto,
  filtrarProductosAdmin,
  MAX_CARACTERES_MOTIVO,
  resumenProductosAdmin,
} from '@/services/adminCatalog'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()
const productos = ref([])
const productores = ref([])
const categorias = ref([])
const texto = ref('')
const categoriaId = ref('')
const productorId = ref('')
const estado = ref('')
const page = ref(1)
const pageSize = ref(12)
const loading = ref(true)
const guardando = ref(false)
const error = ref(null)
const detalle = ref(null)
const accion = ref({ abierto: false, tipo: '', producto: null, motivo: '' })

const columnasProductos = [
  { key: 'producto', label: 'Producto', width: '24%' },
  { key: 'codigo', label: 'Código', width: '120px' },
  { key: 'categoria', label: 'Categoría' },
  { key: 'productor', label: 'Productor' },
  { key: 'precio', label: 'Precio', align: 'right' },
  { key: 'stock', label: 'Stock', align: 'right' },
  { key: 'cosecha', label: 'Cosecha' },
  { key: 'estado', label: 'Estado' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

/**
 * HAL-VEN-006: filtro jerárquico (optgroup por categoría padre con sus
 * subcategorías), sin lista plana con duplicados ni "Sin categoría"/"Sin
 * Categoría" mezclados.
 */
const opcionesCategoria = computed(() => [
  { value: '', label: 'Todas las categorías' },
  ...opcionesCategoriasJerarquicas(arbolDesdeListaPlana(categorias.value)),
])

/** Nombre visible de la categoría con su jerarquía: «Padre › Subcategoría». */
function categoriaTexto(row) {
  const categoria = row.categoria
  if (!categoria) return 'Sin categoría'
  const nombre = normalizarNombreCategoria(categoria.nombre)
  const padre = categorias.value.find((c) => c.id === categoria.categoria_padre_id)
  return padre ? `${normalizarNombreCategoria(padre.nombre)} › ${nombre}` : nombre
}
const opcionesProductor = computed(() => [
  { value: '', label: 'Todos los productores' },
  ...productores.value.map((p) => ({ value: p.id, label: p.nombre_comercial })),
])
const opcionesEstado = [
  { value: '', label: 'Todos los estados' },
  { value: 'publicado', label: 'Publicado' },
  { value: 'pausado', label: 'Pausado' },
  { value: 'eliminado', label: 'Eliminado' },
]
const filtrados = computed(() =>
  filtrarProductosAdmin(productos.value, {
    texto: texto.value,
    categoriaId: categoriaId.value,
    productorId: productorId.value,
    estado: estado.value,
  }),
)
const resumen = computed(() =>
  resumenProductosAdmin(productos.value, { productorId: productorId.value }),
)
const motivoError = computed(() => errorMotivoProducto(accion.value.tipo, accion.value.motivo))
const paginados = computed(() =>
  filtrados.value.slice((page.value - 1) * pageSize.value, page.value * pageSize.value),
)

watch([texto, categoriaId, productorId, estado, pageSize], () => {
  page.value = 1
})

async function cargar() {
  loading.value = true
  error.value = null
  try {
    const datos = await cargarCatalogoAdmin()
    productos.value = datos.productos
    productores.value = datos.productores
    categorias.value = datos.categorias
    if (page.value > Math.max(1, Math.ceil(filtrados.value.length / pageSize.value))) page.value = 1
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}

function abrirAccion(producto, tipo) {
  if (!producto.productor?.activo || producto.eliminado_en || guardando.value) return
  accion.value = { abierto: true, tipo, producto, motivo: '' }
}

async function confirmarAccion() {
  const { producto, tipo, motivo } = accion.value
  if (motivoError.value) {
    ui.warning('Justificación inválida', motivoError.value)
    return
  }
  guardando.value = true
  try {
    const actualizado = await cambiarEstadoProductoAdmin(producto, tipo, motivo)
    const indice = productos.value.findIndex((p) => p.id === producto.id)
    if (indice >= 0) productos.value[indice] = { ...producto, ...actualizado }
    if (detalle.value?.id === producto.id) detalle.value = { ...detalle.value, ...actualizado }
    accion.value.abierto = false
    ui.success(
      'Producto actualizado',
      `${producto.nombre}: ${tipo === 'eliminar' ? 'eliminado' : tipo === 'pausar' ? 'pausado' : 'publicado'}.`,
    )
  } catch (e) {
    ui.error('No se pudo actualizar el producto', e.message)
  } finally {
    guardando.value = false
  }
}

async function exportarProductos() {
  if (!filtrados.value.length) {
    ui.warning('Sin datos para exportar', 'No hay productos con los filtros actuales.')
    return
  }
  await exportExcel(
    filtrados.value.map((p) => ({
      producto: p.nombre,
      codigo: p.codigo_producto ?? '—',
      categoria: p.categoria ? normalizarNombreCategoria(p.categoria.nombre) : 'Sin categoría',
      productor: p.productor?.nombre_comercial ?? '—',
      precio: p.precio,
      stock: p.stock,
      estado: p.eliminado_en ? 'Eliminado' : p.activo ? 'Publicado' : 'Pausado',
      justificacion: p.eliminado_en ? p.motivo_eliminacion : p.motivo_pausa,
    })),
    'cutuco-catalogo-productos',
    [
      { key: 'producto', label: 'Producto' },
      { key: 'codigo', label: 'Código' },
      { key: 'categoria', label: 'Categoría' },
      { key: 'productor', label: 'Productor' },
      { key: 'precio', label: 'Precio' },
      { key: 'stock', label: 'Stock' },
      { key: 'estado', label: 'Estado' },
      { key: 'justificacion', label: 'Justificación' },
    ],
  )
}

onMounted(cargar)

// Implementación anterior de la vista, conservada como comentario durante la migración a services/adminCatalog.js.
// /**
//  * CuTuCo — Categorías y productos del catálogo (módulo secundario del admin).
//  * Árbol CRUD de categorías y tabla de productos publicados con activación.
//  * El servicio de catálogo sólo expone productos activos, por eso la vista lo
//  * explicita y no promete listar borrados o inactivos.
//  */
// import { computed, onMounted, ref } from 'vue'
// import CtAlert from '@/components/base/CtAlert.vue'
// import CtBadge from '@/components/base/CtBadge.vue'
// import CtButton from '@/components/base/CtButton.vue'
// import CtCard from '@/components/base/CtCard.vue'
// import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
// import CtEmptyState from '@/components/base/CtEmptyState.vue'
// import CtIcon from '@/components/base/CtIcon.vue'
// import CtInput from '@/components/base/CtInput.vue'
// import CtModal from '@/components/base/CtModal.vue'
// import CtPagination from '@/components/base/CtPagination.vue'
// import CtSearchInput from '@/components/base/CtSearchInput.vue'
// import CtSelect from '@/components/base/CtSelect.vue'
// import CtSpinner from '@/components/base/CtSpinner.vue'
// import CtStatCard from '@/components/base/CtStatCard.vue'
// import CtTable from '@/components/base/CtTable.vue'
// import CategoryTree from '@/components/domain/CategoryTree.vue'
// import { exportExcel } from '@/lib/csv'
// import { formatCLP, formatDate, formatNumber } from '@/lib/format'
// import {
//   createCategoria,
//   eliminarCategoria,
//   getArbolCategorias,
//   listCategorias,
//   slugify,
//   updateCategoria,
// } from '@/services/catalog'
// import {
//   desactivarProductoAdmin,
//   listProductosAdmin,
//   reactivarProductoAdmin,
// } from '@/services/admin'
// import { useUiStore } from '@/stores/ui'
//
// const ui = useUiStore()
//
// const categorias = ref([])
// const arbol = ref([])
// const productos = ref([])
// const totalProductos = ref(0)
// const categoriaSeleccionada = ref(null)
// const texto = ref('')
// const page = ref(1)
// const pageSize = ref(12)
// const mostrarEliminadas = ref(false)
// const loading = ref(true)
// const loadingProductos = ref(false)
// const error = ref(null)
// const guardando = ref(false)
//
// const editor = ref({ abierto: false, id: null, nombre: '', slug: '', padreId: null })
// const eliminacion = ref({ abierto: false, categoria: null })
//
// const columnasProductos = [
//   { key: 'producto', label: 'Producto', width: '28%' },
//   { key: 'categoria', label: 'Categoría' },
//   { key: 'productor', label: 'Productor' },
//   { key: 'precio', label: 'Precio', align: 'right' },
//   { key: 'stock', label: 'Stock', align: 'right' },
//   { key: 'cosecha', label: 'Cosecha' },
//   { key: 'estado', label: 'Estado' },
//   { key: 'acciones', label: 'Acciones', align: 'right' },
// ]
//
// const categoriasPlanas = computed(() => {
//   const lista = []
//   const walk = (nodos) => {
//     for (const nodo of nodos) {
//       lista.push({ value: nodo.id, label: nodo.nombre, sistema: nodo.es_sistema })
//       walk(nodo.hijos ?? [])
//     }
//   }
//   walk(arbol.value)
//   return lista
// })
//
// const opcionesCategoria = computed(() => [
//   { value: '', label: 'Todas las categorías' },
//   ...categoriasPlanas.value.map((c) => ({ value: c.value, label: c.label })),
// ])
//
// /** Número de productos publicados por categoría, para el contador del árbol. */
// const conteoPorCategoria = computed(() => {
//   const conteo = {}
//   for (const producto of productos.value) {
//     const id = producto.categoria_id
//     if (!id) continue
//     conteo[id] = (conteo[id] ?? 0) + 1
//   }
//   return conteo
// })
//
// const totalComunas = computed(() => categorias.value.length)
//
// const subcategorias = computed(() => categorias.value.filter((c) => c.categoria_padre_id).length)
//
// const stockTotal = computed(() =>
//   productos.value.reduce((acc, p) => acc + Number(p.stock ?? 0), 0),
// )
//
// const stockBajo = computed(() => productos.value.filter((p) => p.stockBajo).length)
//
// function abrirEditor(categoria = null, padre = null) {
//   if (categoria) {
//     editor.value = {
//       abierto: true,
//       id: categoria.id,
//       nombre: categoria.nombre,
//       slug: categoria.slug,
//       padreId: categoria.categoria_padre_id ?? null,
//     }
//     return
//   }
//   editor.value = {
//     abierto: true,
//     id: null,
//     nombre: '',
//     slug: '',
//     padreId: padre?.id ?? categoriaSeleccionada.value?.id ?? null,
//   }
// }
//
// async function guardarCategoria() {
//   const nombre = editor.value.nombre.trim()
//   if (!nombre) {
//     ui.warning('Nombre requerido', 'La categoría necesita un nombre visible.')
//     return
//   }
//   guardando.value = true
//   try {
//     const slug = editor.value.slug.trim() || slugify(nombre)
//     if (editor.value.id) {
//       await updateCategoria(editor.value.id, {
//         nombre,
//         slug,
//         categoria_padre_id: editor.value.padreId ?? null,
//       })
//       ui.success('Categoría actualizada', nombre)
//     } else {
//       await createCategoria({ nombre, slug, categoria_padre_id: editor.value.padreId ?? null })
//       ui.success('Categoría creada', `${nombre} ya está disponible en el catálogo.`)
//     }
//     editor.value.abierto = false
//     await cargarCategorias()
//     await cargarProductos()
//   } catch (e) {
//     ui.error('No se pudo guardar la categoría', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
// function pedirEliminacion(categoria) {
//   if (categoria.es_sistema) {
//     ui.warning('Categoría de sistema', 'Las categorías marcadas como sistema no se pueden eliminar.')
//     return
//   }
//   eliminacion.value = { abierto: true, categoria }
// }
//
// async function confirmarEliminacion() {
//   const categoria = eliminacion.value.categoria
//   guardando.value = true
//   try {
//     await eliminarCategoria(categoria.id)
//     if (categoriaSeleccionada.value?.id === categoria.id) categoriaSeleccionada.value = null
//     ui.success('Categoría eliminada', `${categoria.nombre} ya no aparece en el catálogo público.`)
//     eliminacion.value = { abierto: false, categoria: null }
//     await cargarCategorias()
//     await cargarProductos()
//   } catch (e) {
//     ui.error('No se pudo eliminar la categoría', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
// /**
//  * Baja lógica y republicación del producto desde el panel (RF-017 y RF-004).
//  * El catálogo público sólo muestra productos activos y no eliminados.
//  */
// async function alternarProducto(producto) {
//   guardando.value = true
//   try {
//     if (producto.activo) await desactivarProductoAdmin(producto.id)
//     else await reactivarProductoAdmin(producto.id)
//     producto.activo = !producto.activo
//     ui.success(
//       producto.activo ? 'Producto publicado' : 'Producto desactivado',
//       `${producto.nombre} ${producto.activo ? 'vuelve a estar visible' : 'dejó de estar visible en el catálogo'}.`,
//     )
//   } catch (e) {
//     ui.error('No se pudo actualizar el producto', e.message)
//   } finally {
//     guardando.value = false
//   }
// }
//
// function exportarProductos() {
//   if (!productos.value.length) {
//     ui.warning('Sin datos para exportar', 'No hay productos visibles con los filtros actuales.')
//     return
//   }
//   const ok = exportExcel(
//     productos.value.map((p) => ({
//       producto: p.nombre,
//       categoria: p.categoria?.nombre ?? 'Sin categoría',
//       productor: p.productor?.nombre_comercial ?? '—',
//       precio: p.precio,
//       stock: p.stock,
//       unidad: p.unidad_medida,
//       fechaCosecha: p.fecha_cosecha,
//       estado: p.activo ? 'Publicado' : 'Pausado',
//     })),
//     'cutuco-catalogo-productos',
//     [
//       { key: 'producto', label: 'Producto' },
//       { key: 'categoria', label: 'Categoría' },
//       { key: 'productor', label: 'Productor' },
//       { key: 'precio', label: 'Precio' },
//       { key: 'stock', label: 'Stock' },
//       { key: 'unidad', label: 'Unidad' },
//       { key: 'fechaCosecha', label: 'Fecha cosecha' },
//       { key: 'estado', label: 'Estado' },
//     ],
//   )
//   if (ok) ui.success('Listado exportado', 'Se descargó el Excel de productos publicados.')
//   else ui.error('No se pudo exportar', 'No hay filas para exportar.')
// }
//
// async function cargarCategorias() {
//   categorias.value = await listCategorias({ includeDeleted: mostrarEliminadas.value })
//   arbol.value = await getArbolCategorias({ includeDeleted: mostrarEliminadas.value })
// }
//
// async function cargarProductos() {
//   loadingProductos.value = true
//   try {
//     // El administrador ve también los productos desactivados (baja lógica).
//     const lista = await listProductosAdmin({
//       texto: texto.value,
//       activo: null,
//     })
//     const filtrados = categoriaSeleccionada.value
//       ? lista.filter((p) => p.categoria_id === categoriaSeleccionada.value.id)
//       : lista
//     totalProductos.value = filtrados.length
//     const inicio = (page.value - 1) * pageSize.value
//     productos.value = filtrados.slice(inicio, inicio + pageSize.value)
//   } catch (e) {
//     ui.error('No se pudieron cargar los productos', e.message)
//     productos.value = []
//     totalProductos.value = 0
//   } finally {
//     loadingProductos.value = false
//   }
// }
//
// async function cargar() {
//   loading.value = true
//   error.value = null
//   try {
//     await cargarCategorias()
//     await cargarProductos()
//   } catch (e) {
//     error.value = e.message
//   } finally {
//     loading.value = false
//   }
// }
//
// onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Administración de productos</h1>
        <p class="page-head__subtitle">Estado de publicación e inventario del catálogo.</p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="loading" @click="exportarProductos">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton :loading="loading" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el catálogo">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>
    <CtSpinner v-if="loading" label="Cargando productos…" />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Productos publicados"
          :value="formatNumber(resumen.publicados)"
          icon="inventory"
          tone="success"
          hint="Productos activos"
        />
        <CtStatCard
          label="Stock total"
          :value="formatNumber(resumen.stockTotal, 0)"
          icon="box"
          tone="info"
          hint="Solo productos activos"
        />
      </div>

      <!-- Árbol de categorías y su mantenedor anterior quedan deshabilitados:
           <CategoryTree :nodes="arbol" @edit="abrirEditor($event)" @delete="pedirEliminacion($event)" />
           <CtModal v-model="editor.abierto">Editor de categoría</CtModal>
           <CtConfirmDialog v-model="eliminacion.abierto" title="Eliminar categoría" /> -->
      <CtCard padding="md" title="Productos" subtitle="Gestiona la publicación de cada producto">
        <div class="admin-catalogo__barra">
          <CtSearchInput
            v-model="texto"
            class="admin-catalogo__buscador"
            placeholder="Buscar producto, productor o categoría…"
            aria-label="Buscar productos"
          />
          <CtSelect
            v-model="categoriaId"
            class="admin-catalogo__filtro"
            label="Categoría"
            :options="opcionesCategoria"
          />
          <CtSelect
            v-model="productorId"
            class="admin-catalogo__filtro"
            label="Productor"
            :options="opcionesProductor"
          />
          <CtSelect
            v-model="estado"
            class="admin-catalogo__filtro"
            label="Estado"
            :options="opcionesEstado"
          />
        </div>

        <CtTable
          :columns="columnasProductos"
          :rows="paginados"
          dense
          min-width="940px"
          empty-icon="inventory"
          empty-title="Sin productos"
          empty-message="No hay productos con los filtros seleccionados."
        >
          <template #cell-producto="{ row }">
            <div class="admin-catalogo__producto">
              <img
                v-if="row.imagenPrincipal"
                class="admin-catalogo__imagen"
                :src="row.imagenPrincipal.url"
                :alt="row.nombre"
                loading="lazy"
              />
              <span v-else class="admin-catalogo__placeholder" aria-hidden="true"
                ><CtIcon name="leaf" :size="18"
              /></span>
              <button type="button" class="admin-catalogo__nombre" @click="detalle = row">
                {{ row.nombre }}
              </button>
            </div>
          </template>

          <template #cell-codigo="{ row }">
            <span class="mono text-sm">{{ row.codigo_producto ?? '—' }}</span>
          </template>
          <template #cell-categoria="{ row }">{{ categoriaTexto(row) }}</template>
          <template #cell-productor="{ row }">{{
            row.productor?.nombre_comercial ?? '—'
          }}</template>
          <template #cell-precio="{ row }"
            >{{ formatCLP(row.precio) }} / {{ row.unidad_medida }}</template
          >
          <template #cell-stock="{ row }"
            >{{ formatearCantidad(row.stock, row.unidad_medida) }} {{ row.unidad_medida }}</template
          >
          <template #cell-cosecha="{ row }">{{ formatDate(row.fecha_cosecha) }}</template>
          <template #cell-estado="{ row }">
            <CtBadge :tone="row.eliminado_en ? 'danger' : row.activo ? 'success' : 'neutral'" dot>
              {{ row.eliminado_en ? 'Eliminado' : row.activo ? 'Publicado' : 'Pausado' }}
            </CtBadge>
            <p
              v-if="row.eliminado_en ? row.motivo_eliminacion : row.motivo_pausa"
              class="admin-catalogo__motivo"
            >
              {{ row.eliminado_en ? row.motivo_eliminacion : row.motivo_pausa }}
            </p>
          </template>
          <template #cell-acciones="{ row }">
            <div class="admin-catalogo__acciones">
              <CtButton
                size="sm"
                variant="ghost"
                :disabled="guardando || Boolean(row.eliminado_en) || !row.productor?.activo"
                @click="abrirAccion(row, row.activo ? 'pausar' : 'publicar')"
              >
                {{ row.activo ? 'Pausar' : 'Publicar' }}
              </CtButton>
              <CtButton
                size="sm"
                variant="danger"
                :disabled="guardando || Boolean(row.eliminado_en) || !row.productor?.activo"
                @click="abrirAccion(row, 'eliminar')"
                >Eliminar</CtButton
              >
            </div>
          </template>
        </CtTable>
        <CtPagination
          :page="page"
          :total="filtrados.length"
          :page-size="pageSize"
          label="productos"
          @update:page="page = $event"
          @update:page-size="pageSize = $event"
        />
      </CtCard>
    </template>

    <CtModal
      :model-value="Boolean(detalle)"
      :title="detalle?.nombre ?? 'Producto'"
      size="xl"
      hide-footer
      @update:model-value="!$event && (detalle = null)"
    >
      <ProductDetailView v-if="detalle" :admin-product="detalle" admin-mode />
    </CtModal>

    <CtModal
      :model-value="accion.abierto"
      :title="
        accion.tipo === 'pausar'
          ? 'Pausar producto'
          : accion.tipo === 'eliminar'
            ? 'Eliminar producto'
            : 'Publicar producto'
      "
      size="sm"
      @update:model-value="!$event && (accion.abierto = false)"
    >
      <p v-if="accion.tipo === 'publicar'">¿Publicar “{{ accion.producto?.nombre }}” nuevamente?</p>
      <p v-else-if="accion.tipo === 'eliminar'">
        “{{ accion.producto?.nombre }}” quedará eliminado y no podrá volver a publicarse.
      </p>
      <CtTextarea
        v-if="accion.tipo === 'pausar' || accion.tipo === 'eliminar'"
        v-model="accion.motivo"
        :label="
          accion.tipo === 'pausar' ? 'Justificación de la pausa' : 'Justificación de la eliminación'
        "
        hint="Entre 10 y 1000 caracteres."
        :error="accion.motivo ? motivoError : null"
        required
        :rows="3"
        :maxlength="MAX_CARACTERES_MOTIVO"
        show-count
        :placeholder="
          accion.tipo === 'pausar'
            ? 'Explica por qué se pausa este producto'
            : 'Explica por qué se elimina este producto'
        "
      />
      <template #footer>
        <CtButton variant="secondary" @click="accion.abierto = false">Cancelar</CtButton>
        <CtButton
          :loading="guardando"
          :variant="accion.tipo === 'eliminar' ? 'danger' : 'primary'"
          :disabled="Boolean(motivoError)"
          @click="confirmarAccion"
          >{{ accion.tipo === 'eliminar' ? 'Eliminar' : 'Confirmar' }}</CtButton
        >
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.admin-catalogo__barra {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: var(--ct-space-3);
  margin-bottom: var(--ct-space-4);
}
.admin-catalogo__buscador {
  flex: 1 1 240px;
}
.admin-catalogo__filtro {
  min-width: 190px;
}
.admin-catalogo__producto {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}
.admin-catalogo__imagen,
.admin-catalogo__placeholder {
  width: 40px;
  height: 40px;
  border-radius: var(--ct-radius-sm);
  object-fit: cover;
  background: var(--ct-surface-alt);
  flex-shrink: 0;
}
.admin-catalogo__placeholder {
  display: grid;
  place-items: center;
  color: var(--ct-primary);
}
.admin-catalogo__nombre {
  color: var(--ct-text);
  font-weight: var(--ct-fw-semibold);
  text-align: left;
}
.admin-catalogo__nombre:hover {
  color: var(--ct-primary-strong);
}
.admin-catalogo__nombre:focus-visible {
  box-shadow: var(--ct-shadow-focus);
}
.admin-catalogo__motivo {
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-xs);
  /* HAL-VEN-027: la justificación larga no desborda la celda. */
  overflow-wrap: anywhere;
  word-break: break-word;
  min-width: 0;
}
.admin-catalogo__acciones {
  display: flex;
  justify-content: flex-end;
  gap: var(--ct-space-2);
}
@media (max-width: 720px) {
  .admin-catalogo__filtro {
    min-width: 100%;
  }
}
</style>
