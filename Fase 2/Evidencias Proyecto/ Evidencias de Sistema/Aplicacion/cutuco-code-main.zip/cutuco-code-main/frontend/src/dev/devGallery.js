import { useAuthStore } from '@/stores/auth'
import { MODO_DEMO, tryGetClient } from '@/lib/supabase'

/**
 * CuTuCo — GALERÍA DE VISTAS (herramienta de desarrollo).
 *
 * Permite recorrer y gestionar todas las ventanas sin depender del flujo
 * completo (catálogo → carrito → pago → entrega). Se activa de forma explícita
 * con `VITE_DEV_GALLERY=true`; por defecto está apagada, de modo que la
 * aplicación respeta los guards de rol.
 *
 * Las cuentas demo existen en dos lugares:
 *   * `supabase/seeds/gallery_dev.sql` cuando la base está levantada.
 *   * `src/data/demoDatabase.js` cuando la aplicación corre en modo demostración
 *     offline (Docker apagado), con las mismas credenciales.
 */

/**
 * Interruptor maestro. Sólo el valor exacto `true` habilita la galería.
 */
export const DEV_GALLERY_ENABLED = import.meta.env.VITE_DEV_GALLERY === 'true'

/** Contraseña compartida por las cuentas de prueba del seed. */
export const DEV_PASSWORD = import.meta.env.VITE_DEV_PASSWORD ?? 'CutucoDev2026!'

/** Contraseña del seed base, usada como respaldo si la base no tiene las cuentas de la galería. */
export const DEV_PASSWORD_RESPALDO = 'CutucoTest!2026'

/**
 * Cuentas del seed para saltar de rol sin pasar por el formulario de login.
 * `home` es la ventana de inicio de cada rol: al cambiar de sesión la galería
 * navega ahí para que los paneles muestren datos reales de esa cuenta.
 */
export const DEV_SESSIONS = Object.freeze([
  {
    key: 'admin',
    label: 'Administración',
    email: 'admin@cutuco.dev',
    icon: 'shield',
    home: '/admin',
    nota: 'Permisos completos: usuarios, productos, aprobaciones, sanciones y pagos',
    alternativas: [{ email: 'cutuco.admin.base@example.test', password: 'CutucoTest!2026' }],
  },
  {
    key: 'vendedor',
    label: 'Vendedor',
    email: 'vendedor@cutuco.dev',
    icon: 'store',
    home: '/vendedor',
    nota: 'Productor aprobado: inventario, pedidos, entrega con código y pago por Webpay Mall',
    alternativas: [{ email: 'cutuco.productor.paine@example.test', password: 'CutucoTest!2026' }],
  },
  {
    key: 'cliente',
    label: 'Cliente',
    email: 'cliente@cutuco.dev',
    icon: 'user',
    home: '/cliente/pedidos',
    nota: 'Compra, direcciones, seguimiento del pedido y calificación',
    alternativas: [{ email: 'cutuco.cliente.santiago@example.test', password: 'CutucoTest!2026' }],
  },
  {
    key: 'pendiente',
    label: 'Vendedor pendiente',
    email: 'pendiente@cutuco.dev',
    icon: 'clock',
    home: '/vendedor',
    nota: 'Solicitud en revisión: muestra los bloqueos de RF-021',
    alternativas: [{ email: 'cutuco.productor.pausado@example.test', password: 'CutucoTest!2026' }],
  },
])

/** Sesión con la que se entra automáticamente al abrir la aplicación. */
export const DEV_DEFAULT_SESSION = 'admin'

/**
 * Inicia sesión con una cuenta de la galería y devuelve el perfil resultante.
 *
 * Primero intenta la cuenta propia de `supabase/seeds/gallery_dev.sql`
 * (`nombre@cutuco.dev` con `DEV_PASSWORD`) y, si esa base todavía no tiene la
 * semilla de la galería, cae a la cuenta equivalente de `supabase/seed.sql` con
 * `DEV_PASSWORD_RESPALDO`. Así el selector de roles funciona en cualquier
 * entorno local sin reescribir credenciales a mano.
 */
let _ultimaSesion = null

export async function autenticarComo(sesion) {
  const objetivo = normalizarSesion(sesion)
  if (!objetivo) {
    throw new Error(
      'No se recibió una cuenta de revisión válida. Recarga la página para reiniciar la galería de desarrollo.',
    )
  }

  const auth = useAuthStore()
  if (auth.email === objetivo.email) {
    _ultimaSesion = objetivo.email
    return auth.perfil
  }
  // Evita reautenticar dos veces por el mismo destino mientras el guard se
  // reevalúa (cambio de rol + navegación).
  if (_ultimaSesion === objetivo.email && !auth.isAuthenticated) return null

  const intentos = [
    { email: objetivo.email, password: DEV_PASSWORD },
    ...(objetivo.alternativas ?? []).map((alt) => ({
      email: alt.email,
      password: alt.password ?? DEV_PASSWORD_RESPALDO,
    })),
  ]

  let ultimoError = null
  await auth.signOut({ automatico: true })
  for (const intento of intentos) {
    try {
      await auth.signIn(intento)
      _ultimaSesion = objetivo.email
      return auth.perfil
    } catch (e) {
      ultimoError = e
      await auth.signOut({ automatico: true })
    }
  }

  const pista = MODO_DEMO.value
    ? 'Estás en modo demostración: limpia `cutuco:demo:*` en el almacenamiento del navegador o recarga la página.'
    : 'Revisa que el Supabase local tenga las semillas cargadas: supabase db reset.'
  throw new Error(
    `No se pudo entrar con la cuenta "${objetivo.label ?? objetivo.email}". ${pista} (${ultimoError?.message ?? 'sin detalle'})`,
  )
}

/**
 * Normaliza la cuenta recibida: acepta la clave de rol (`'admin'`), el correo o
 * el objeto de sesión. Evita el error «cuenta undefined» cuando llega un valor
 * que no corresponde a ninguna cuenta conocida.
 */
export function normalizarSesion(valor) {
  if (!valor) return null
  if (typeof valor === 'string') {
    return (
      DEV_SESSIONS.find((s) => s.key === valor) ??
      DEV_SESSIONS.find((s) => s.email === valor) ??
      null
    )
  }
  const sesion = DEV_SESSIONS.find((s) => s && (s.key === valor.key || s.email === valor.email))
  if (sesion) return sesion
  // Objeto con correo pero sin coincidencia exacta: se usa tal cual si tiene email.
  return valor.email ? valor : null
}
/* ==================================================================
 * Sesión de revisión: acceso total a todas las ventanas
 * ==================================================================
 * Con la galería activa la aplicación entra con el Administrador Base (el rol
 * con permisos completos en RLS) y, si una ventana exige otro rol, cambia de
 * sesión automáticamente para que nada quede bloqueado. Si el revisor cierra
 * sesión a mano, no se vuelve a entrar solo: así se puede ver la aplicación tal
 * como la ve un visitante.
 * ================================================================ */

const CLAVE_CIERRE_MANUAL = 'cutuco:dev:sesion-cerrada'

/** ¿Se permite el acceso automático con una cuenta del seed? */
export function permiteSesionAutomatica() {
  try {
    return sessionStorage.getItem(CLAVE_CIERRE_MANUAL) !== '1'
  } catch {
    return true
  }
}

/** Marca que el revisor cerró sesión a propósito (hasta recargar la página). */
export function bloquearSesionAutomatica() {
  try {
    sessionStorage.setItem(CLAVE_CIERRE_MANUAL, '1')
  } catch {
    /* almacenamiento no disponible */
  }
}

/** Vuelve a habilitar el acceso automático (por ejemplo al usar la galería). */
export function habilitarSesionAutomatica() {
  try {
    sessionStorage.removeItem(CLAVE_CIERRE_MANUAL)
  } catch {
    /* almacenamiento no disponible */
  }
}

/** Sesión de la galería por clave de rol; `null` si la clave no existe. */
export function sesionDeGaleria(key = DEV_DEFAULT_SESSION) {
  return DEV_SESSIONS.find((s) => s.key === key) ?? null
}

/**
 * ¿El rol actual puede abrir esta ruta? Se evalúa igual que el guard del router:
 * las ventanas públicas siempre; las que declaran `roles`, sólo si coinciden.
 */
export function rolPuedeAbrir(rol, meta = {}) {
  if (meta.gallery) return true
  const roles = meta.roles
  if (!roles) return true
  return Boolean(rol) && roles.includes(rol)
}

/**
 * Sesión necesaria para una ruta; `null` cuando el rol actual sirve.
 * Las ventanas públicas nunca fuerzan un cambio de rol: primero se elige la
 * cuenta del área de la ventana (vendedor o administración) y, en los flujos de
 * compra, la cuenta de cliente.
 */
export function sesionParaRuta(rol, meta = {}, path = '') {
  if (rolPuedeAbrir(rol, meta)) return null
  const roles = meta.roles ?? []
  if (path.startsWith('/vendedor') && roles.includes('vendedor')) return sesionDeGaleria('vendedor')
  if (path.startsWith('/admin') && roles.includes('admin')) return sesionDeGaleria('admin')
  if (roles.includes('admin')) return sesionDeGaleria('admin')
  if (roles.includes('vendedor')) return sesionDeGaleria('vendedor')
  return sesionDeGaleria('cliente')
}

/**
 * Registros del seed para las rutas con parámetro.
 *
 * Los UUID corresponden a `supabase/seed.sql` (base real). Cuando la aplicación
 * corre en modo demostración offline, los identificadores son los del dataset en
 * memoria, así que se resuelven al cargar el módulo para que la galería abra
 * ventanas con datos en ambos casos.
 */
export const DEV_IDS = {
  producto: '30000000-0000-0000-0000-000000000101',
  productoAjeno: '30000000-0000-0000-0000-000000000201',
  pedidoCreado: '40000000-0000-0000-0000-000000000001',
  pedidoPagado: '40000000-0000-0000-0000-000000000002',
  pedidoEnTransito: '40000000-0000-0000-0000-000000000003',
  reclamo: 'b0000000-0000-0000-0000-000000000005',
  vendedor: '20000000-0000-0000-0000-000000000001',
}

/** Ajusta los identificadores de ejemplo a la fuente de datos activa. */
export function ajustarIdsDeGaleria() {
  try {
    const client = tryGetClient()
    if (!MODO_DEMO.value || !client?.db) return DEV_IDS
    const productos = client.db.tabla('productos')
    const pedidos = client.db.tabla('pedidos')
    const productores = client.db.tabla('productores')
    const reclamos = client.db.tabla('reclamos')
    DEV_IDS.producto = productos[0]?.id ?? DEV_IDS.producto
    DEV_IDS.productoAjeno = productos.find((p) => p.productor_id !== productos[0]?.productor_id)?.id ?? DEV_IDS.productoAjeno
    DEV_IDS.pedidoCreado = pedidos.find((p) => p.estado === 'creado')?.id ?? DEV_IDS.pedidoCreado
    DEV_IDS.pedidoPagado = pedidos.find((p) => p.estado === 'en_preparacion')?.id ?? DEV_IDS.pedidoPagado
    DEV_IDS.pedidoEnTransito = pedidos.find((p) => p.estado === 'completado')?.id ?? DEV_IDS.pedidoEnTransito
    DEV_IDS.reclamo = reclamos[0]?.id ?? DEV_IDS.reclamo
    DEV_IDS.vendedor = productores[0]?.id ?? DEV_IDS.vendedor
  } catch {
    /* sin cliente de datos: se usan los identificadores del seed */
  }
  return DEV_IDS
}

/** Todas las ventanas del producto, agrupadas como los bloques del diseño. */
export const DEV_GROUPS = Object.freeze([
  {
    key: 'publico',
    label: 'Público (RF-022)',
    icon: 'home',
    views: [
      { path: '/', label: 'Inicio', desc: 'Portada con hero, categorías y vendedores' },
      { path: '/catalogo', label: 'Catálogo', desc: 'Buscador, filtros y grilla de productos' },
      { path: `/producto/${DEV_IDS.producto}`, label: 'Detalle de producto', desc: 'Galería, precio y vendedor' },
      { path: `/vendedores/${DEV_IDS.vendedor}`, label: 'Perfil del vendedor', desc: 'Reputación y catálogo' },
      { path: '/terminos', label: 'Términos y condiciones' },
      { path: '/privacidad', label: 'Política de privacidad' },
      { path: '/ruta-inexistente', label: 'Página no encontrada (404)' },
    ],
  },
  {
    key: 'auth',
    label: 'Autenticación (RF-001, RF-020, RF-021, RF-023)',
    icon: 'lock',
    views: [
      { path: '/cuentas-demo', label: 'Cuentas de prueba', desc: 'Entrar con cada rol del seed en un clic' },
      { path: '/login', label: 'Iniciar sesión' },
      { path: '/registro', label: 'Crear cuenta de cliente' },
      { path: '/registro-vendedor', label: 'Registro de vendedor', desc: 'Queda pendiente de aprobación' },
      { path: '/recuperar-clave', label: 'Recuperar contraseña' },
    ],
  },
  {
    key: 'cliente',
    label: 'Cliente (RF-002, RF-005, RF-006, RF-009)',
    icon: 'cart',
    views: [
      { path: '/carrito', label: 'Tu carrito', desc: 'Cantidades, stock y cobertura regional' },
      { path: '/checkout', label: 'Finalizar pedido', desc: 'Dirección, totales y Webpay Plus' },
      { path: '/pago/retorno?token_ws=demo', label: 'Retorno de Webpay', desc: 'Commit y pago autorizado' },      { path: '/cliente/pedidos', label: 'Mis pedidos' },
      { path: `/cliente/pedidos/${DEV_IDS.pedidoEnTransito}`, label: 'Seguimiento del pedido', desc: 'Código, entrega y calificación' },
      { path: '/cliente/reclamos', label: 'Mis reclamos', desc: 'Abrir y seguir reclamos de pedidos' },
      { path: `/cliente/reclamos/${DEV_IDS.reclamo}`, label: 'Detalle del reclamo', desc: 'Motivo, estado y respuesta del vendedor' },
      { path: '/cliente/perfil', label: 'Mi perfil', desc: 'Datos, dirección y contraseña' },
      { path: '/direcciones', label: 'Mis direcciones', desc: 'Listar, crear, editar, eliminar y marcar principal' },
      { path: '/mi-postulacion', label: 'Mi postulación', desc: 'Completar, corregir y reenviar la solicitud de vendedor' },
    ],
  },
  {
    key: 'vendedor',
    label: 'Vendedor (RF-003, RF-021, RF-025)',
    icon: 'store',
    views: [
      { path: '/vendedor', label: 'Dashboard del vendedor' },
      { path: '/vendedor/perfil', label: 'Perfil del vendedor' },
      { path: '/vendedor/productos', label: 'Gestión de inventario' },
      { path: '/vendedor/productos/nuevo', label: 'Agregar producto', desc: 'Foto tomada con la cámara' },
      { path: `/vendedor/productos/${DEV_IDS.producto}/editar`, label: 'Editar producto' },
      { path: '/vendedor/pedidos', label: 'Pedidos recibidos' },
      { path: '/vendedor/servicio', label: 'Servicio y pagos', desc: 'Cuota mensual, transferencia y Webpay' },
      { path: `/vendedor/pedidos/${DEV_IDS.pedidoEnTransito}`, label: 'Detalle y despacho', desc: 'Código de verificación (RF-007)' },
      { path: '/vendedor/reclamos', label: 'Reclamos recibidos', desc: 'Listar y responder reclamos de mis pedidos' },
      { path: '/vendedor/sanciones', label: 'Sanciones y apelaciones', desc: 'Detalle de sanciones y creación de apelaciones (RF-026)' },
      { path: '/vendedor/tienda', label: 'Perfil de tienda', desc: 'Datos bancarios del comercio' },
    ],
  },
  {
    key: 'admin',
    label: 'Administración (RF-004, RF-011, RF-014, RF-026)',
    icon: 'shield',
    views: [
      { path: '/admin', label: 'Panel de administración', desc: 'Pendientes: aprobaciones y sanciones' },
      { path: '/admin/moderacion', label: 'Aprobación de vendedores' },
      { path: '/admin/usuarios', label: 'Usuarios', desc: 'Roles, activación y baja lógica' },
      { path: '/admin/productos', label: 'Productos y categorías' },
      { path: '/admin/pagos', label: 'Pagos', desc: 'Comprobantes autorizados; la dispersión la hace Transbank' },
      { path: '/admin/servicios', label: 'Servicio de vendedores', desc: 'Cuotas, revisión de transferencias y morosidad' },
      { path: '/admin/sanciones', label: 'Sanciones y moderación' },
    ],
  },
  {
    key: 'galeria',
    label: 'Ventanas del prototipo anterior',
    icon: 'doc',
    views: [
      { path: '/vendedor/reputacion', label: 'Reputación y sanciones', desc: 'RF-006 v1: score 40/40/20 y pausa automática' },
      { path: '/vendedor/alertas-stock', label: 'Alertas de stock', desc: 'RF-010: umbral automático (fuera de alcance)' },
      { path: '/admin/reportes', label: 'Centro de reportes', desc: 'RF-011 v1: KPIs, ventas por región y ticket promedio' },
      { path: '/admin/reclamos', label: 'Reclamos abiertos', desc: 'Reclamos del prototipo anterior' },
      { path: '/admin/geografia', label: 'Regiones, comunas y cobertura', desc: 'RF-009 v1: cobertura por comuna' },
    ],
  },
])

/** Total de ventanas listadas (lo muestra la barra de la galería). */
export const DEV_VIEW_COUNT = DEV_GROUPS.reduce((acc, g) => acc + g.views.length, 0)






