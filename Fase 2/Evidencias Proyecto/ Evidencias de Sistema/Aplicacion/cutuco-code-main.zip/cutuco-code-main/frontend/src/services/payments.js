/**
 * CuTuCo — Servicio de lectura de pagos (Webpay Mall Plus).
 *
 * El dinero lo dispersa Transbank por Mall: con el commit autorizado el pedido
 * queda `pagado` y `pagos` guarda ÚNICAMENTE el comprobante exitoso (inmutable,
 * escrito por FastAPI con service_role). Ya no existe escrow ni la tabla
 * `payouts`: la comisión del 5% la registra CuTuCo como cargo del Mall y el resto
 * va directo al comercio del productor.
 *
 * La creación y la confirmación del pago viven en `services/orders.js`
 * (`/api/webpay/iniciar` y `/api/webpay/confirmar`). Aquí queda sólo la
 * lectura vía PostgREST/RLS: los participantes del pedido lo leen por
 * `pagos_select_participantes` y el administrador por `pagos_select_admin`.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, eliminado): la custodia/escrow, los
 * payouts y los reembolsos manuales (`listPayouts`, `registrarPayoutPagado`,
 * `registrarReembolsoCliente`, `getResumenCustodia`) se retiraron con la
 * migración `20261010010000_webpay_mall_postulaciones.sql`.
 */

import { mensajeSeguro } from '@/services/errores'
import { getClient } from '@/lib/supabase'

/* ---------------------------------------------------------------- */
/* Lectura                                                             */
/* ---------------------------------------------------------------- */

/**
 * Comprobante de pago de un pedido (o `null` si aún no se autoriza).
 * La fil existe sólo cuando el pago quedó autorizado por Webpay Mall.
 */
export async function getPagoDePedido(pedidoId) {
  const client = getClient()
  const { data } = await client.from('pagos').select('*').eq('pedido_id', pedidoId).maybeSingle()
  return data ?? null
}

/**
 * Comprobantes visibles para el usuario de la sesión (RLS):
 * el cliente/el productor ven los de sus pedidos; el administrador, todos.
 * @param {{desde?: string|null}} opciones
 */
export async function listPagos({ desde = null } = {}) {
  const client = getClient()
  let query = client.from('pagos').select('*')
  if (desde) query = query.gte('creado_en', desde)
  const { data, error } = await query.order('creado_en', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}
