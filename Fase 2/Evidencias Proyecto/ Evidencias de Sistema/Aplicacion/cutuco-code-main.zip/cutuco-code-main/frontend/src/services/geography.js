/**
 * CuTuCo — Servicio de geografía y direcciones.
 *
 * RF-009: la cobertura se valida comparando la región del cliente con la
 * región del vendedor. Las regiones y comunas se consultan directo a
 * PostgREST para los combobox (RF-018). No existe cobertura por comuna ni
 * geolocalización.
 */

import { mensajeSeguro } from '@/services/errores'
import { getClient } from '@/lib/supabase'
import { unwrap } from '@/services/session'

/* ------------------------------ regiones ------------------------------ */

export async function listRegiones() {
  const client = getClient()
  const { data, error } = await client
    .from('regiones')
    .select('*')
    .order('nombre', { ascending: true })
  return unwrap({ data, error }, 'No se pudieron cargar las regiones')
}

export async function getRegion(regionId) {
  if (!regionId) return null
  const client = getClient()
  const { data, error } = await client.from('regiones').select('*').eq('id', regionId).maybeSingle()
  if (error) return null
  return data
}

/* ------------------------------ comunas ------------------------------- */

export async function listComunas({ regionId = null } = {}) {
  const client = getClient()
  let query = client.from('comunas').select('*')
  if (regionId) query = query.eq('region_id', regionId)
  const { data, error } = await query.order('nombre', { ascending: true })
  return unwrap({ data, error }, 'No se pudieron cargar las comunas')
}

export async function getComuna(comunaId) {
  if (!comunaId) return null
  const client = getClient()
  const { data, error } = await client.from('comunas').select('*').eq('id', comunaId).maybeSingle()
  if (error) return null
  return data
}

/** Estructura región -> comunas para los combobox encadenados (RF-018). */
export async function getJerarquiaGeografica() {
  const [regiones, comunas] = await Promise.all([listRegiones(), listComunas()])
  return regiones.map((region) => ({
    ...region,
    comunas: comunas.filter((c) => c.region_id === region.id),
  }))
}

/** Opciones listas para <CtSelect> con agrupación por región. */
export async function getOpcionesComunas({ regionId = null } = {}) {
  const [regiones, comunas] = await Promise.all([listRegiones(), listComunas({ regionId })])
  const regionMap = new Map(regiones.map((r) => [r.id, r]))
  return comunas.map((c) => ({
    value: c.id,
    label: c.nombre,
    group: regionMap.get(c.region_id)?.nombre ?? 'Sin región',
    regionId: c.region_id,
  }))
}

/* ----------------------------- direcciones ---------------------------- */

/** Direcciones del usuario autenticado (RLS: propias o administrador). */
export async function listDirecciones({ perfilId = null } = {}) {
  const client = getClient()
  let query = client.from('direcciones').select('*').eq('activo', true)
  if (perfilId) query = query.eq('perfil_id', perfilId)
  const { data, error } = await query.order('es_principal', { ascending: false })
  if (error) throw new Error(mensajeSeguro(error))
  return data ?? []
}

/**
 * Región de cobertura del vendedor (RF-009).
 * Lee la columna derivada `productores.region_id` (la mantiene un trigger del
 * esquema) y, si aún no está poblada, cae a la dirección activa.
 */
export async function getRegionProductor(productorId) {
  if (!productorId) return null
  const client = getClient()
  const { data: productor } = await client
    .from('productores')
    .select('id, perfil_id, region_id')
    .eq('id', productorId)
    .maybeSingle()
  if (!productor) return null
  if (productor.region_id) return getRegion(productor.region_id)
  return (await getDireccionProductor(productorId))?.region ?? null
}

/** Dirección activa del vendedor: define su región de cobertura (RF-009). */
export async function getDireccionProductor(productorId) {
  const client = getClient()
  const { data: productor } = await client
    .from('productores')
    .select('id, perfil_id')
    .eq('id', productorId)
    .maybeSingle()
  if (!productor) return null
  const { data } = await client
    .from('direcciones')
    .select('*')
    .eq('perfil_id', productor.perfil_id)
    .eq('activo', true)
    .order('es_principal', { ascending: false })
    .limit(1)
    .maybeSingle()
  if (!data) return null
  const comuna = await getComuna(data.comuna_id)
  const region = comuna ? await getRegion(comuna.region_id) : null
  return { ...data, comuna, region }
}

/**
 * Región de entrega del cliente autenticado (RF-009).
 *
 * `perfiles` no guarda la región: se deriva de su dirección activa principal
 * (`direcciones` -> `comunas` -> `regiones`). La RLS `direcciones_select_propias_admin`
 * permite al cliente leer sus propias direcciones.
 * @returns {Promise<{region: object, comuna: object, direccion: object}|null>}
 */
export async function getRegionCliente(perfilId) {
  if (!perfilId) return null
  const direcciones = await listDirecciones({ perfilId })
  if (!direcciones.length) return null
  const principal = direcciones.find((d) => d.es_principal) ?? direcciones[0]
  const comuna = await getComuna(principal.comuna_id)
  if (!comuna) return null
  const region = await getRegion(comuna.region_id)
  if (!region) return null
  return { region, comuna, direccion: principal }
}

/**
 * Región de entrega de una dirección (para RF-009 en el cliente).
 * @returns {Promise<{comuna: object, region: object}|null>}
 */
export async function getRegionDeDireccion(direccion) {
  if (!direccion?.comuna_id) return null
  const comuna = await getComuna(direccion.comuna_id)
  if (!comuna) return null
  const region = await getRegion(comuna.region_id)
  return region ? { comuna, region } : null
}

export async function createDireccion({
  perfilId,
  etiqueta = 'Casa',
  comunaId,
  calle,
  numero = null,
  deptoOficina = null,
  referencia = null,
  esPrincipal = false,
}) {
  const client = getClient()
  // HAL-CLI-001: número y complemento son opcionales; se persisten como NULL
  // (no como cadena vacía) y la calle se guarda sin espacios externos.
  const opcional = (valor) => {
    const texto = String(valor ?? '').trim()
    return texto || null
  }
  return unwrap(
    await client
      .from('direcciones')
      .insert({
        perfil_id: perfilId,
        etiqueta: String(etiqueta ?? '').trim() || 'Casa',
        comuna_id: comunaId,
        calle: String(calle ?? '').trim(),
        numero: opcional(numero),
        depto_oficina: opcional(deptoOficina),
        referencia: opcional(referencia),
        es_principal: esPrincipal,
        activo: true,
      })
      .select()
      .single(),
    'No se pudo guardar la dirección',
  )
}

export async function updateDireccion(id, patch) {
  const client = getClient()
  return unwrap(
    await client.from('direcciones').update(patch).eq('id', id).select().single(),
    'No se pudo actualizar la dirección',
  )
}

/** Desactivación lógica de una dirección (RF-017). */
export async function desactivarDireccion(id) {
  const client = getClient()
  return unwrap(
    await client.from('direcciones').update({ activo: false, es_principal: false }).eq('id', id),
    'No se pudo desactivar la dirección',
  )
}

/**
 * Marca una dirección como principal.
 *
 * `uq_direccion_principal_activa` es un índice UNIQUE parcial
 * (`(perfil_id) WHERE es_principal AND activo`), así que una sola sentencia que
 * marque la nueva sin liberar la anterior falla con 23505. Se hace en dos pasos
 * —liberar la principal actual y luego marcar la elegida— porque PostgREST no
 * ofrece transacciones multi-sentencia. Si el segundo paso fallara, el perfil
 * queda sin principal y `getRegionCliente` cae a la primera dirección activa.
 *
 * El trigger `trg_sincronizar_region_productor` recalcula
 * `productores.region_id` con la dirección activa principal; para un productor el
 * cambio es inocuo porque sólo puede tener una activa (lo garantiza
 * `trg_validar_direccion`).
 */
export async function marcarDireccionPrincipal({ direccionId, perfilId }) {
  const client = getClient()
  if (!perfilId) throw new Error('Falta el perfil para marcar la dirección principal')

  const { error: liberarError } = await client
    .from('direcciones')
    .update({ es_principal: false })
    .eq('perfil_id', perfilId)
    .eq('es_principal', true)
    .eq('activo', true)
  if (liberarError) throw new Error(mensajeSeguro(liberarError))

  return unwrap(
    await client
      .from('direcciones')
      .update({ es_principal: true })
      .eq('id', direccionId)
      .select()
      .single(),
    'No se pudo marcar la dirección como principal',
  )
}

/**
 * Elimina una dirección del perfil autenticado.
 *
 * Es un DELETE real: la tabla no tiene columna `eliminado_en`, `authenticated`
 * tiene el privilegio DELETE y la policy `direcciones_delete_propias` lo limita a
 * las direcciones propias. El trigger `validar_direccion` impide que un productor
 * se quede sin su única dirección activa («Un productor debe conservar
 * exactamente una direccion activa»).
 */
export async function eliminarDireccion(direccionId) {
  const client = getClient()
  return unwrap(
    await client.from('direcciones').delete().eq('id', direccionId),
    'No se pudo eliminar la dirección',
  )
}

/** Verifica que el vendedor tenga exactamente una dirección activa (RF-021). */
export async function direccionActivaUnica(perfilId) {
  const direcciones = await listDirecciones({ perfilId })
  return {
    total: direcciones.length,
    direccion: direcciones[0] ?? null,
    ok: direcciones.length === 1,
  }
}

/* ==================================================================
 * SERVICIOS HEREDADOS — SÓLO GALERÍA DE DESARROLLO
 * ==================================================================
 * NOTA DE MIGRACIÓN (alcance anterior, ya se usa sólo en la ventana
 * "Regiones y comunas" que la galería sigue mostrando):
 *   La cobertura por comuna (RF-009 v1) salió del alcance: el ERS vigente
 *   compara únicamente la región del vendedor (`productores.region_id`, que
 *   mantiene un trigger) con la región de la dirección de entrega.
 *
 *   Estas funciones operan sobre la tabla `coberturas_productor`, declarada
 *   como HERRAMIENTA DE DESARROLLO en la migración
 *   `20261006100000_add_gallery_legacy_tables.sql`. Ninguna vista vigente las
 *   importa.
 * ================================================================ */

/** Coberturas de un vendedor (heredado). */
export async function listCoberturas(productorId) {
  const client = getClient()
  const { data, error } = await client
    .from('coberturas_productor')
    .select('*')
    .eq('productor_id', productorId)
  if (error) return []
  return Promise.all(
    data.map(async (c) => ({
      ...c,
      region: c.region_id ? await getRegion(c.region_id) : null,
      comuna: c.comuna_id ? await getComuna(c.comuna_id) : null,
    })),
  )
}

/** Alta o actualización de una cobertura (heredado). */
export async function setCobertura({ productorId, tipo, regionId, comunaId, activo = true }) {
  const client = getClient()
  const payload =
    tipo === 'region'
      ? { productor_id: productorId, tipo_cobertura: tipo, region_id: regionId, comuna_id: null }
      : { productor_id: productorId, tipo_cobertura: tipo, region_id: null, comuna_id: comunaId }

  const { data: existentes, error: findError } = await client
    .from('coberturas_productor')
    .select('*')
    .eq('productor_id', productorId)
    .eq('tipo_cobertura', tipo)
  if (findError) throw new Error(mensajeSeguro(findError))

  const match = (existentes ?? []).find((c) =>
    tipo === 'region' ? c.region_id === regionId : c.comuna_id === comunaId,
  )

  if (match) {
    return unwrap(
      await client.from('coberturas_productor').update({ activo }).eq('id', match.id).select().single(),
      'No se pudo actualizar la cobertura',
    )
  }
  return unwrap(
    await client.from('coberturas_productor').insert({ ...payload, activo }).select().single(),
    'No se pudo guardar la cobertura',
  )
}

/** Eliminación física de una cobertura (heredado; tabla de desarrollo). */
export async function removeCobertura(coberturaId) {
  const client = getClient()
  return unwrap(
    await client.from('coberturas_productor').delete().eq('id', coberturaId),
    'No se pudo eliminar la cobertura',
  )
}

/** Comunas donde el vendedor podía entregar (heredado). */
export async function getComunasCobertas(productorId) {
  const coberturas = await listCoberturas(productorId)
  const client = getClient()
  const { data } = await client.from('comunas').select('*')
  const regiones = await listRegiones()
  const regionMap = new Map(regiones.map((r) => [r.id, r]))

  return coberturas
    .filter((c) => c.activo)
    .flatMap((c) => {
      if (c.tipo_cobertura === 'region') {
        return (data ?? []).filter((com) => com.region_id === c.region_id)
      }
      return (data ?? []).filter((com) => com.id === c.comuna_id)
    })
    .map((comuna) => ({
      ...comuna,
      regionNombre: regionMap.get(comuna.region_id)?.nombre ?? '',
      alcance: coberturas.find(
        (c) =>
          (c.tipo_cobertura === 'region' && c.region_id === comuna.region_id) ||
          (c.tipo_cobertura === 'comuna' && c.comuna_id === comuna.id),
      )?.tipo_cobertura,
    }))
}
