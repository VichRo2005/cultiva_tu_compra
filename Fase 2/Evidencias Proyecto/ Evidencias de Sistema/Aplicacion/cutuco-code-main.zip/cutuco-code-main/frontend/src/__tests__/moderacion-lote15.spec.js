/**
 * CuTuCo — Lote 15 (Moderación y sanciones), lado frontend.
 *
 * CK-0400: el motivo de la sanción se valida en la interfaz (vacío / solo
 * espacios rechazados antes de enviar; el dato anterior se conserva).
 * Refuerza CK-0401 (servidor/BD, test PG16 test_moderacion_lote15.py).
 * Además: adminErrores traduce el rechazo de moderación sin filtrar nombres
 * de tabla internos, y adminModeracion administra la lista de palabras.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

import { beforeEach } from 'vitest'
import { consulta, admin } from './admin-test-utils'
const sdk = vi.hoisted(() => ({
  from: vi.fn(),
  rpc: vi.fn(),
  auth: { getSession: vi.fn(), getUser: vi.fn() },
}))
vi.mock('@/lib/supabase', () => ({
  getClient: () => sdk,
  tryGetClient: () => sdk,
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
}))
beforeEach(() => vi.resetAllMocks())

const src = (p) => readFileSync(`src/${p}`, 'utf8')

import { validarSancion, crearSancion } from '@/services/adminSanciones'
import { adminResult } from '@/services/adminErrores'

describe('CK-0400 · motivo de sanción validado en interfaz', () => {
  it('rechaza motivo vacío o solo espacios sin llamar a la API', () => {
    for (const motivo of ['', '   ', '\t\n ']) {
      expect(() =>
        validarSancion({ productorId: 'p1', tipo: 'suspension', accion: 'suspender', motivo, duracionDias: 7 })
      ).toThrow('motivo')
    }
  })

  it('crearSancion exige motivo no vacío y envía el motivo recortado', async () => {
    admin(sdk)
    await expect(
      crearSancion({ productorId: 'p', tipo: 'suspension', accion: 'suspender', motivo: '   ', duracionDias: 7 })
    ).rejects.toThrow('motivo')
    const insert = consulta(sdk, { data: { id: 's1' } })
    const r = await crearSancion({
      productorId: 'p', tipo: 'suspension', accion: 'suspender',
      motivo: '  Motivo valido de prueba lote 15  ', duracionDias: 7,
    })
    expect(r.id).toBe('s1')
    expect(insert.insert).toHaveBeenCalledWith(
      expect.objectContaining({ motivo: 'Motivo valido de prueba lote 15' })
    )
  })

  it('el formulario de sanciones conserva el motivo previo ante error', () => {
    const spec = src('__tests__/admin-sanciones.view.spec.js')
    expect(spec).toBeTruthy()
    const view = src('views/admin/AdminSanctionsView.vue')
    expect(view).toMatch(/motivo/)
  })
})

describe('Moderación · mensajes y lista administrable', () => {
  it('adminErrores traduce el rechazo de moderación a mensaje legible (sin nombre de tabla)', () => {
    expect(() =>
      adminResult({ data: null, error: { message: 'El texto contiene una palabra prohibida por la moderacion' } })
    ).toThrow(/palabras no permitidas/i)
    expect(() =>
      adminResult({ data: null, error: { message: 'new row for relation "palabras_prohibidas" violates ck_palabra_sin_wildcards' } })
    ).toThrow(/comodines/i)
  })

  it('adminModeracion lista y administra palabras prohibidas (solo admin por RLS)', () => {
    const s = src('services/adminModeracion.js')
    expect(s).toContain('palabras_prohibidas')
    expect(s).toMatch(/export (async )?function/)
  })
})
