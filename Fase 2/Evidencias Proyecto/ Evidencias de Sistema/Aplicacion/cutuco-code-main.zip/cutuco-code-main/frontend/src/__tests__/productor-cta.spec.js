/** Flujo de captación de productores desde Inicio y Mi Postulación. */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'

const src = (path) => readFileSync(`src/${path}`, 'utf8')
const ANCLA_PRODUCTORES = '#quiero-vender-en-cutuco'

describe('CTA de productor', () => {
  it('Inicio lleva “Soy Productor” al bloque institucional y conserva el acceso al registro', () => {
    const home = src('views/public/HomeView.vue')

    expect(home).toContain(`hash: '${ANCLA_PRODUCTORES}'`)
    expect(home).toContain('id="quiero-vender-en-cutuco"')
    expect(home).toContain('¿Cultivas y quieres vender en CuTuCo?')
    expect(home).toContain('to="/registro-vendedor">Crear cuenta de productor</CtButton>')
  })

  it('Mi Postulación abre Inicio en el mismo bloque para continuar el flujo', () => {
    const postulacion = src('views/auth/MiPostulacionView.vue')

    expect(postulacion).toContain("router.push({ name: 'home', hash: '#quiero-vender-en-cutuco' })")
    expect(postulacion).toContain('@click="irABloqueProductores"')
  })

  it('el router realiza el desplazamiento suave para los enlaces con hash', () => {
    const router = src('router/index.js')

    expect(router).toContain("if (to.hash) return { el: to.hash, behavior: 'smooth' }")
  })

  it('un cliente autenticado puede abrir el registro de vendedor desde el CTA', () => {
    const router = src('router/index.js')

    expect(router).toContain("['login', 'registro', 'recuperar-clave'].includes(to.name)")
    expect(router).not.toContain("['login', 'registro', 'registro-vendedor', 'recuperar-clave'].includes(to.name)")
  })
})
