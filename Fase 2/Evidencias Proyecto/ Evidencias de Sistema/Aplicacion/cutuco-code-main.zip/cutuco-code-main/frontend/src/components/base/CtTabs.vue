<script setup>
/** CuTuCo — Pestañas. */
import CtBadge from './CtBadge.vue'

defineProps({
  modelValue: { type: [String, Number], required: true },
  tabs: { type: Array, default: () => [] }, // [{ value, label, count, icon, tone }]
  variant: { type: String, default: 'underline' }, // underline | pills
  stretch: { type: Boolean, default: false },
})

const emit = defineEmits(['update:modelValue', 'change'])
</script>

<template>
  <div class="ct-tabs" :class="[`ct-tabs--${variant}`, { 'is-stretch': stretch }]" role="tablist">
    <button
      v-for="tab in tabs"
      :key="tab.value"
      type="button"
      role="tab"
      class="ct-tabs__tab"
      :class="{ 'is-active': tab.value === modelValue }"
      :aria-selected="tab.value === modelValue"
      @click="emit('update:modelValue', tab.value); emit('change', tab.value)"
    >
      <span v-if="tab.icon" aria-hidden="true">{{ tab.icon }}</span>
      <span>{{ tab.label }}</span>
      <CtBadge v-if="tab.count !== undefined" :tone="tab.tone || 'neutral'" size="sm">
        {{ tab.count }}
      </CtBadge>
    </button>
  </div>
</template>

<style scoped>
.ct-tabs {
  display: flex;
  gap: var(--ct-space-2);
  border-bottom: 1px solid var(--ct-border);
  overflow-x: auto;
  /* HAL-VEN-012: la barra nativa sólo aparece cuando hace falta desplazar;
     se oculta visualmente sin quitar el desplazamiento accesible. */
  scrollbar-width: none;
}

.ct-tabs::-webkit-scrollbar {
  display: none;
}

.ct-tabs.is-stretch .ct-tabs__tab {
  flex: 1;
  justify-content: center;
}

.ct-tabs--pills {
  border-bottom: none;
  flex-wrap: wrap;
}

.ct-tabs__tab {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  padding: var(--ct-space-3) var(--ct-space-4);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-soft);
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  white-space: nowrap;
  transition:
    color var(--ct-transition),
    border-color var(--ct-transition);
}

.ct-tabs__tab:hover {
  color: var(--ct-text);
}

/* En la variante underline el subrayado se dibuja al hover y se consolida al activar. */
.ct-tabs--underline .ct-tabs__tab:hover {
  border-bottom-color: var(--ct-border-strong);
}

.ct-tabs__tab.is-active {
  color: var(--ct-primary-strong);
  border-bottom-color: var(--ct-primary);
  font-weight: var(--ct-fw-semibold);
}

.ct-tabs__tab.is-active:hover {
  color: var(--ct-primary-ink);
  border-bottom-color: var(--ct-primary-strong);
}

.ct-tabs--pills .ct-tabs__tab {
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-pill);
  margin-bottom: 0;
  background: var(--ct-surface);
}

.ct-tabs--pills .ct-tabs__tab.is-active {
  background: var(--ct-primary-strong);
  border-color: var(--ct-primary-strong);
  color: var(--ct-text-invert);
}

.ct-tabs--pills .ct-tabs__tab:hover {
  border-color: var(--ct-primary);
  color: var(--ct-primary-ink);
}

.ct-tabs--pills .ct-tabs__tab.is-active:hover {
  background: var(--ct-primary-ink);
  border-color: var(--ct-primary-ink);
  color: var(--ct-text-invert);
}
</style>
