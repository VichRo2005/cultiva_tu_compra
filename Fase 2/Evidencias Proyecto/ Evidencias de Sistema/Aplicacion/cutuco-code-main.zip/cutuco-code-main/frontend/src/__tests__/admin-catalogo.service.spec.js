import { beforeEach, describe, expect, it, vi } from 'vitest'

const sdk = vi.hoisted(() => ({ from: vi.fn() }))
vi.mock('@/lib/supabase', () => ({
  supabase: sdk,
  // El servicio usa getClient(): ambos caminos comparten el mismo mock.
  getClient: () => sdk,
  storageUrl: (path) => `/storage/${path}`,
}))
import {
  cargarCatalogoAdmin,
  cambiarEstadoProductoAdmin,
  errorMotivoProducto,
  filtrarProductosAdmin,
  resumenProductosAdmin,
} from '@/services/adminCatalog'

function consulta(data, error = null) {
  const q = {
    select: vi.fn(() => q),
    order: vi.fn(() => q),
    in: vi.fn(() => q),
    eq: vi.fn(() => q),
    is: vi.fn(() => q),
    update: vi.fn(() => q),
    single: vi.fn(() => Promise.resolve({ data, error })),
    // La consulta del SDK es thenable; el doble de prueba reproduce ese contrato.
    // oxlint-disable-next-line unicorn/no-thenable
    then: (resolve) => Promise.resolve({ data, error }).then(resolve),
  }
  return q
}

beforeEach(() => vi.resetAllMocks())

describe('administración de catálogo', () => {
  const base = [
    {
      id: '1',
      nombre: 'Tomate',
      productor_id: 'p1',
      categoria_id: 'c1',
      activo: true,
      stock: 4,
      productor: { nombre_comercial: 'Huerta Norte' },
      categoria: { nombre: 'Verduras' },
    },
    {
      id: '2',
      nombre: 'Queso',
      productor_id: 'p2',
      categoria_id: 'c2',
      activo: false,
      stock: 99,
      productor: { nombre_comercial: 'Campo Sur' },
      categoria: { nombre: 'Lácteos' },
    },
    {
      id: '3',
      nombre: 'Antiguo',
      productor_id: 'p1',
      categoria_id: 'c1',
      activo: false,
      eliminado_en: '2026-10-20',
      stock: 30,
      productor: { nombre_comercial: 'Huerta Norte' },
      categoria: { nombre: 'Verduras' },
    },
  ]

  it('busca producto, productor y categoría; combina los filtros', () => {
    expect(filtrarProductosAdmin(base, { texto: 'huerta' }).map((p) => p.id)).toEqual(['1', '3'])
    expect(
      filtrarProductosAdmin(base, {
        texto: 'verduras',
        estado: 'publicado',
        categoriaId: 'c1',
      }).map((p) => p.id),
    ).toEqual(['1'])
    expect(
      filtrarProductosAdmin(base, { productorId: 'p2', estado: 'pausado' }).map((p) => p.id),
    ).toEqual(['2'])
    expect(filtrarProductosAdmin(base, { estado: 'eliminado' }).map((p) => p.id)).toEqual(['3'])
    expect(resumenProductosAdmin(base)).toEqual({ publicados: 1, stockTotal: 4 })
    expect(resumenProductosAdmin(base, { productorId: 'p1' })).toEqual({
      publicados: 1,
      stockTotal: 4,
    })
    expect(resumenProductosAdmin(base, { productorId: 'p2' })).toEqual({
      publicados: 0,
      stockTotal: 0,
    })
  })

  it('hidrata todos los productos para los filtros y el detalle', async () => {
    const queries = {
      productos: consulta(base.map(({ productor: _productor, categoria: _categoria, ...p }) => p)),
      productores: consulta([{ id: 'p1', nombre_comercial: 'Huerta Norte', activo: true }]),
      categorias: consulta([{ id: 'c1', nombre: 'Verduras' }]),
      imagenes_productos: consulta([
        { producto_id: '1', ruta_storage: 'tomate.jpg', es_principal: true },
      ]),
    }
    sdk.from.mockImplementation((tabla) => queries[tabla])
    const datos = await cargarCatalogoAdmin()
    expect(datos.productos).toHaveLength(3)
    expect(datos.productos[0].productor.nombre_comercial).toBe('Huerta Norte')
    expect(datos.productos[0].imagenPrincipal.url).toBe('/storage/tomate.jpg')
  })

  it('valida longitud de ambas justificaciones y bloquea productos eliminados', async () => {
    for (const accion of ['pausar', 'eliminar']) {
      expect(errorMotivoProducto(accion, '123456789')).toContain('10 y 1000')
      expect(errorMotivoProducto(accion, 'x'.repeat(1001))).toContain('10 y 1000')
      expect(errorMotivoProducto(accion, '  1234567890  ')).toBeNull()
      await expect(cambiarEstadoProductoAdmin(base[0], accion, '123456789')).rejects.toThrow(
        '10 y 1000',
      )
      await expect(cambiarEstadoProductoAdmin(base[0], accion, 'x'.repeat(1001))).rejects.toThrow(
        '10 y 1000',
      )
    }
    await expect(cambiarEstadoProductoAdmin(base[2], 'publicar')).rejects.toThrow('eliminado')
    const productor = consulta({ activo: false })
    sdk.from.mockReturnValue(productor)
    await expect(cambiarEstadoProductoAdmin(base[0], 'eliminar', 'Razón válida')).rejects.toThrow(
      'desactivado',
    )
    expect(productor.update).not.toHaveBeenCalled()
  })

  it('limpia motivo al publicar y marca eliminado al eliminar', async () => {
    const productor = consulta({ activo: true })
    const producto = consulta({ ...base[0], activo: true, motivo_pausa: null })
    sdk.from.mockImplementation((tabla) => (tabla === 'productores' ? productor : producto))
    await cambiarEstadoProductoAdmin(base[1], 'publicar')
    expect(producto.update).toHaveBeenCalledWith({ activo: true, motivo_pausa: null })
    await cambiarEstadoProductoAdmin(base[0], 'eliminar', 'Control de calidad')
    expect(producto.update).toHaveBeenLastCalledWith(
      expect.objectContaining({
        activo: false,
        motivo_pausa: null,
        eliminado_en: expect.any(String),
        motivo_eliminacion: 'Control de calidad',
      }),
    )
  })
})
