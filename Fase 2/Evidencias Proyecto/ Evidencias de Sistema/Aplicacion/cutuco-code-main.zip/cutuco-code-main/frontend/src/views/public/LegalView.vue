<script setup>
/**
 * CuTuCo — Documentos legales (términos y privacidad).
 * Una sola vista para ambas rutas, con el lenguaje visual del pie institucional.
 */
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'

const route = useRoute()

const DOCUMENTOS = {
  terminos: {
    icon: 'doc',
    eyebrow: 'Legal · Términos y condiciones',
    title: 'Términos y Condiciones',
    intro:
      'Estos términos rigen el uso de CuTuCo (Cultiva Tu Compra), la plataforma que conecta clientes con agricultores familiares y campesinos verificados de Chile.',
    actualizado: 'Septiembre de 2026',
    secciones: [
      {
        titulo: 'Objeto de la plataforma',
        cuerpo:
          'CuTuCo es un intermediario digital que facilita la concertación entre clientes y productores. La plataforma no vende productos por cuenta propia: cada operación se celebra entre el cliente y el productor, con CuTuCo como canal de pago, registro y soporte.',
      },
      {
        titulo: 'Cuenta y verificación',
        cuerpo:
          'Para comprar basta con una cuenta de cliente. Para publicar productos, el productor completa su postulación con sus datos personales, de tienda y bancarios; el equipo de CuTuCo revisa los antecedentes y activa la cuenta de forma manual. El uso de la plataforma implica aceptar estos términos y la política de privacidad.',
      },
      {
        titulo: 'Cobertura y entrega',
        cuerpo:
          'La cobertura se define por región: el productor sólo vende a clientes cuya dirección de entrega esté en su misma región, y la validación ocurre antes de crear el pago. La entrega avanza por los estados Preparación, En Tránsito y Entregado. El cliente consulta su código de entrega y lo comunica al vendedor al recibir el pedido; el vendedor debe validarlo para registrar la entrega. El despacho se cobra por vendedor y su total se informa antes de confirmar.',
      },
      {
        titulo: 'Pago con Webpay Mall',
        cuerpo:
          'Los pagos se procesan con Webpay Mall. El productor recibe el pago de su venta y CuTuCo descuenta una comisión del 5%. CuTuCo no guarda ni libera manualmente el dinero de las ventas.',
      },
      {
        titulo: 'Reclamos y compensaciones',
        cuerpo:
          'CuTuCo permite registrar un reclamo como constancia dentro de la plataforma. El cliente y el productor deben conversar y resolver el problema directamente entre ellos, fuera de CuTuCo. Este registro no genera cancelaciones, reembolsos ni compensaciones automáticas.',
      },
      {
        titulo: 'Calidad y trazabilidad',
        cuerpo:
          'Cada producto publicado incluye su descripción, categoría, unidad de venta, precio y la fecha de cosecha declarada por el productor. La entrega queda respaldada por el código de verificación del pedido.',
      },
      {
        titulo: 'Reputación y sanciones',
        cuerpo:
          'La reputación de un productor es el promedio simple de las calificaciones de 1 a 5 que dejan los clientes al recibir su pedido. No existen reglas automáticas: cualquier amonestación, suspensión o ban permanente lo decide el administrador de forma manual y queda registrada con su motivo y duración.',
      },
      {
        titulo: 'Responsabilidad',
        cuerpo:
          'CuTuCo responde por el funcionamiento de la plataforma. El pago de cada venta llega al productor mediante Webpay Mall y CuTuCo no guarda esos fondos. La calidad de los productos corresponde al productor, quien debe informar si son orgánicos o convencionales.',
      },
    ],
  },
  privacidad: {
    icon: 'lock',
    eyebrow: 'Legal · Política de privacidad',
    title: 'Política de Privacidad',
    intro:
      'Tratamos los datos personales de clientes y productores con la finalidad de operar la plataforma, verificar identidades, procesar pagos y prevenir fraudes.',
    actualizado: 'Septiembre de 2026',
    secciones: [
      {
        titulo: 'Datos que recopilamos',
        cuerpo:
          'Recopilamos datos de cuenta (nombre, apellido, correo y teléfono), datos de entrega (dirección y comuna), datos de la tienda, datos bancarios del productor e imágenes de los productos. Los documentos de la postulación de vendedores se guardan de forma segura y sólo los revisa el equipo de CuTuCo al aprobar la cuenta.',
      },
      {
        titulo: 'Finalidad del tratamiento',
        cuerpo:
          'Usamos los datos para gestionar pedidos y entregas, validar la cobertura regional del productor, procesar el pago con Webpay Mall y mantener la reputación de los productores.',
      },
      {
        titulo: 'Base legal',
        cuerpo:
          'El tratamiento se realiza con el consentimiento del titular y para la ejecución de la relación contractual con CuTuCo, conforme a la Ley 19.628 sobre Protección de la Vida Privada.',
      },
      {
        titulo: 'Compartir con terceros',
        cuerpo:
          'Solo compartimos datos con los productores respecto de los pedidos que el cliente realiza, con pasarelas de pago para procesar transacciones y con proveedores de infraestructura bajo acuerdos de confidencialidad.',
      },
      {
        titulo: 'Retención',
        cuerpo:
          'Los datos de pedidos y pagos se conservan por los plazos legales aplicables. Las imágenes de los productos se mantienen mientras la publicación esté activa.',
      },
      {
        titulo: 'Derechos del titular',
        cuerpo:
          'El titular puede solicitar acceso, rectificación, supresión u oposición escribiendo a cutucosoporte@gmail.com. También puede revocar su consentimiento en cualquier momento, sin efecto retroactivo sobre los tratamientos ya realizados.',
      },
    ],
  },
}

const documento = computed(() => DOCUMENTOS[route.meta.doc] ?? DOCUMENTOS.terminos)
</script>

<template>
  <div class="container page legal">
    <header class="legal__cabecera">
      <p class="eyebrow legal__eyebrow">
        <CtIcon :name="documento.icon" :size="13" class="legal__eyebrow-icon" />
        {{ documento.eyebrow }}
      </p>
      <h1 class="legal__titulo">{{ documento.title }}</h1>
      <p class="legal__intro">{{ documento.intro }}</p>
      <CtBadge tone="muted" size="sm">Última actualización: {{ documento.actualizado }}</CtBadge>
    </header>

    <CtCard padding="none" class="legal__doc">
      <ol class="legal__lista">
        <li v-for="(seccion, index) in documento.secciones" :key="seccion.titulo" class="legal__seccion">
          <span class="legal__numero" aria-hidden="true">{{ index + 1 }}</span>
          <div class="legal__contenido">
            <h2 class="legal__seccion-titulo">{{ seccion.titulo }}</h2>
            <p class="legal__texto">{{ seccion.cuerpo }}</p>
          </div>
        </li>
      </ol>
    </CtCard>

    <CtAlert tone="info" compact>
      <CtIcon name="info" :size="16" class="legal__info-icon" />
      ¿Tienes dudas sobre este documento? Escríbenos a cutucosoporte@gmail.com o revisa el
      <router-link to="/catalogo">catálogo público</router-link> de CuTuCo.
    </CtAlert>

    <section class="legal__institucional hero-dark">
      <div class="legal__institucional-inner">
        <div>
          <p class="eyebrow legal__eyebrow">CuTuCo SpA · Mercado Agrícola Digital</p>
          <p class="legal__institucional-texto">
            {{ documento.title }} · Versión vigente en la plataforma y en cada pedido emitido.
          </p>
        </div>
        <nav class="legal__enlaces" aria-label="Documentos legales">
          <router-link to="/terminos">
            <CtIcon name="doc" :size="15" />
            Términos y Condiciones
          </router-link>
          <router-link to="/privacidad">
            <CtIcon name="lock" :size="15" />
            Políticas de Privacidad
          </router-link>
          <a href="mailto:cutucosoporte@gmail.com">
            <CtIcon name="phone" :size="15" />
            Contacto
          </a>
        </nav>
      </div>
    </section>
  </div>
</template>

<style scoped>
.legal {
  max-width: var(--ct-container-narrow);
}

.legal__eyebrow {
  color: var(--ct-text-muted);
}

.legal__institucional .legal__eyebrow {
  color: var(--ct-text-invert);
}

.legal__cabecera {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-6);
  border-bottom: 1px solid var(--ct-border);
}

.legal__cabecera .legal__eyebrow {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
}

.legal__titulo {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: var(--ct-lh-tight);
}

.legal__intro {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-base);
  line-height: var(--ct-lh-relaxed);
  max-width: 68ch;
}

.legal__doc {
  overflow: hidden;
}

.legal__lista {
  list-style: none;
  margin: 0;
  padding: 0;
}

.legal__seccion {
  display: flex;
  gap: var(--ct-space-4);
  padding: var(--ct-space-6);
  border-bottom: 1px solid var(--ct-border);
}

.legal__seccion:last-child {
  border-bottom: none;
}

.legal__numero {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--ct-surface-alt);
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-xs);
  font-weight: var(--ct-fw-bold);
}

.legal__contenido {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  min-width: 0;
}

.legal__seccion-titulo {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
  letter-spacing: -0.01em;
}

.legal__texto {
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
}

.legal__info-icon {
  display: inline-block;
  vertical-align: -3px;
  margin-right: var(--ct-space-1);
}

.legal__institucional {
  border-radius: var(--ct-radius-lg);
  padding: var(--ct-space-8);
}

.legal__institucional-inner {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-6);
}

.legal__institucional-texto {
  margin-top: var(--ct-space-2);
  font-size: var(--ct-fs-md);
  color: var(--ct-text-invert);
}

.legal__enlaces {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-5);
}

.legal__enlaces a {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-2);
  min-height: 24px;
  padding-inline: 2px;
  border-radius: var(--ct-radius-sm);
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  color: var(--ct-text-invert);
  opacity: 1;
}

.legal__enlaces a:hover {
  color: var(--ct-accent);
  opacity: 1;
  text-decoration: none;
  background: var(--ct-on-dark-soft);
}
</style>
