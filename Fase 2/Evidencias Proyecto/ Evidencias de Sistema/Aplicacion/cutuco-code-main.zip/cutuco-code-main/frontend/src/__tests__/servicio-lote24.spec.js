/**
 * CuTuCo — Lote 24 (CK-0258, lado UI): la resolución administrativa de un pago
 * de servicio exige observaciones (monto y beneficiario verificados) antes de
 * habilitar el botón de aprobar/rechazar.
 */
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const vista = readFileSync('src/views/admin/AdminServicesView.vue', 'utf8')
const servicio = readFileSync('src/services/servicio.js', 'utf8')

describe('CK-0258 · resolución registrada en UI', () => {
  it('el botón de resolver queda deshabilitado sin observaciones', () => {
    expect(vista).toMatch(/:disabled="!observaciones\.trim\(\)"/)
  })

  it('resolverPagoServicio invoca la RPC con observaciones', () => {
    expect(servicio).toMatch(/rpc\('resolver_pago_servicio'/)
    expect(servicio).toMatch(/p_observaciones/)
  })
})
