/**
 * CuTuCo — Lote 7 (Correos transaccionales), lado frontend.
 *
 * CK-0476 (HAL-CLI-016): el mensaje de éxito distingue "pedido registrado"
 * de "aviso al vendedor confirmado" usando los flags correo_*_enviado_en.
 * CK-0287: el resultado KYB vive en el panel y el backend notifica la decisión
 *   por Brevo, una vez por cada intento de postulación.
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'

const src = (p) => readFileSync(`src/${p}`, 'utf8')
const backend = (p) => readFileSync(`../backend/${p}`, 'utf8')

describe('CK-0476 · mensaje de éxito honesto sobre el aviso al vendedor', () => {
  it('PaymentResultView distingue enviado confirmado de aún procesando', () => {
    const vista = src('views/client/PaymentResultView.vue')
    expect(vista).toContain('correo_productor_enviado_en')
    expect(vista).toContain('correo_comprador_enviado_en')
    expect(vista).toContain("correoProductorEnviado ? 'confirmado' : 'en proceso'")
    expect(vista).toContain("correoCompradorEnviado ? 'confirmado' : 'en proceso'")
  })

  it('los flags se escriben sólo con confirmación del proveedor (pedidos_repo)', () => {
    const repo = backend('app/repositories/pedidos_repo.py')
    expect(repo).toContain('"comprador": "correo_comprador_enviado_en"')
    expect(repo).toContain('"productor": "correo_productor_enviado_en"')
  })
})

describe('CK-0287 · resultado KYB en panel y por correo', () => {
  it('MiPostulacionView muestra la decisión en pantalla', () => {
    const vista = src('views/auth/MiPostulacionView.vue')
    expect(vista).toContain('Tu solicitud fue rechazada')
    expect(vista).toContain('¡Tu postulación fue aprobada!')
    expect(vista).toContain('postulaciones_revisiones')
  })

  it('el backend programa una notificación Brevo idempotente al resolver', () => {
    const email = backend('app/services/email_service.py')
    expect(email).toContain('enviar_notificacion_resolucion_postulacion')
    expect(email).toContain('postulacion_resuelta.html')
    expect(email).toContain('correo_resolucion_enviado_en')
    const router = backend('app/routers/postulaciones.py')
    expect(router).toContain('background_tasks.add_task')
    // y el servicio webpay sólo agenda correos de pedido ya confirmado
    const webpay = backend('app/services/webpay_service.py')
    expect(webpay).toContain('enviar_pendiente')
  })
})
