<script setup>
/**
 * CuTuCo — Mis direcciones (RF-009 y RF-017).
 *
 * Ventana compartida por **cliente y vendedor**: la tabla `direcciones` es la
 * misma y las reglas de la base de datos cambian según quién sea el dueño.
 *
 *   * `direcciones_select_propias_admin` / `_insert_propias` / `_update_propias` /
 *     `_delete_propias`: cada perfil gestiona sólo sus direcciones
 *     (`perfil_id = auth.uid()`).
 *   * `trg_validar_direccion` impone que un **productor** (perfil con fila en
 *     `productores`) tenga exactamente una dirección activa: no puede crear una
 *     segunda activa, ni desactivar la suya, ni borrarla.
 *   * `uq_direccion_principal_activa` es UNIQUE parcial `(perfil_id) WHERE
 *     es_principal AND activo`, así que marcar una principal exige liberar antes
 *     la anterior (lo resuelve `marcarDireccionPrincipal`).
 *   * `ck_direccion_principal_activa` impide que una dirección inactiva sea
 *     principal.
 *
 * El esquema no guarda la región en `direcciones`: se deriva de la comuna. Al
 * cambiar la comuna de la dirección activa de un productor, el trigger
 * `trg_sincronizar_region_productor` actualiza `productores.region_id`, es decir,
 * su región de cobertura en el catálogo (RF-009).
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import {
  isDeptoOficina,
  isNumeroDireccion,
  isReferenciaDireccion,
  LIMITES,
  maxLength,
  required,
} from '@/lib/validation'
import {
  createDireccion,
  eliminarDireccion,
  listDirecciones,
  marcarDireccionPrincipal,
  updateDireccion,
} from '@/services/geography'
import { useAuthStore } from '@/stores/auth'
import { useGeographyStore } from '@/stores/geography'
import { useUiStore } from '@/stores/ui'

const auth = useAuthStore()
const geo = useGeographyStore()
const ui = useUiStore()

const direcciones = ref([])
const cargando = ref(true)
const error = ref(null)
const guardando = ref(false)
const errorFormulario = ref(null)
const procesandoId = ref(null)

const modalAbierto = ref(false)
const editandoId = ref(null)
const eraPrincipal = ref(false)
const eliminarAbierto = ref(false)
const porEliminar = ref(null)

const formulario = ref({
  etiqueta: 'Casa',
  regionId: null,
  comunaId: null,
  calle: '',
  numero: '',
  deptoOficina: '',
  referencia: '',
  esPrincipal: false,
})

/**
 * El trigger del esquema considera «productor» a cualquier perfil con fila en
 * `productores`, que es exactamente lo que expone `auth.tieneTienda`.
 */
const esProductor = computed(() => auth.tieneTienda)

const opcionesRegion = computed(() =>
  geo.regionesOrdenadas.map((r) => ({ value: r.id, label: r.nombre })),
)
const opcionesComuna = computed(() =>
  geo.comunasDeRegion(formulario.value.regionId).map((c) => ({ value: c.id, label: c.nombre })),
)

/** Un productor sólo admite una dirección activa (`trg_validar_direccion`). */
const puedeAgregar = computed(() => !esProductor.value || direcciones.value.length === 0)

/** Un productor no puede quedarse sin su dirección activa. */
function puedeEliminar(direccion) {
  return !(esProductor.value && direcciones.value.length === 1 && direccion.activo)
}

function nombreComuna(comunaId) {
  return geo.nombreComuna(comunaId)
}
function nombreRegion(comunaId) {
  const regionId = geo.regionDeComuna(comunaId)
  return regionId ? geo.nombreRegion(regionId) : '—'
}
function textoDireccion(d) {
  return [d.calle, d.numero, d.depto_oficina].filter(Boolean).join(' ')
}

/** Traduce los errores de los triggers del esquema a mensajes accionables. */
function mensajeError(e) {
  const texto = String(e?.message ?? '')
  if (/uq_direccion_principal_activa|duplicate key/i.test(texto)) {
    return 'Ya tenías otra dirección marcada como principal. Vuelve a intentarlo.'
  }
  if (/solo puede tener una direccion activa/i.test(texto)) {
    return 'Como productor sólo puedes tener una dirección activa: edita la que ya tienes.'
  }
  if (/debe conservar exactamente una direccion activa/i.test(texto)) {
    return 'Como productor debes conservar tu dirección activa: no puedes eliminarla.'
  }
  if (/Solo el propietario/i.test(texto)) {
    return 'Sólo el dueño de la dirección puede gestionarla.'
  }
  return texto || 'No se pudo completar la operación'
}

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    direcciones.value = await listDirecciones({ perfilId: auth.perfil?.id })
  } catch (e) {
    error.value = mensajeError(e)
  } finally {
    cargando.value = false
  }
}

function abrirNueva() {
  errorFormulario.value = null
  editandoId.value = null
  eraPrincipal.value = false
  formulario.value = {
    etiqueta: direcciones.value.length ? 'Entrega' : 'Casa',
    regionId: null,
    comunaId: null,
    calle: '',
    numero: '',
    deptoOficina: '',
    referencia: '',
    // La primera dirección siempre nace como principal (si no, el perfil
    // quedaría sin ninguna).
    esPrincipal: direcciones.value.length === 0,
  }
  modalAbierto.value = true
}

function abrirEdicion(direccion) {
  errorFormulario.value = null
  editandoId.value = direccion.id
  eraPrincipal.value = Boolean(direccion.es_principal)
  formulario.value = {
    etiqueta: direccion.etiqueta ?? 'Casa',
    regionId: geo.regionDeComuna(direccion.comuna_id),
    comunaId: direccion.comuna_id,
    calle: direccion.calle ?? '',
    numero: direccion.numero ?? '',
    deptoOficina: direccion.depto_oficina ?? '',
    referencia: direccion.referencia ?? '',
    esPrincipal: Boolean(direccion.es_principal),
  }
  modalAbierto.value = true
}

async function guardar() {
  if (guardando.value) return
  errorFormulario.value = null
  if (!formulario.value.comunaId) {
    errorFormulario.value = 'Selecciona la comuna'
    return
  }
  if (!required(formulario.value.calle)) {
    errorFormulario.value = 'Escribe la calle de tu dirección'
    return
  }
  // A3: límites del esquema validados antes de guardar (varchar en la BD).
  if (!maxLength(formulario.value.calle, LIMITES.calle)) {
    errorFormulario.value = `La calle no puede superar ${LIMITES.calle} caracteres`
    return
  }
  // HAL-CLI-001: número opcional y alfanumérico; nunca se exige dígito.
  if (!isNumeroDireccion(formulario.value.numero)) {
    errorFormulario.value = `El número es opcional; si lo ingresas, usa hasta ${LIMITES.numero} caracteres alfanuméricos`
    return
  }
  if (formulario.value.etiqueta && !maxLength(formulario.value.etiqueta, 50)) {
    errorFormulario.value = 'La etiqueta no puede superar 50 caracteres'
    return
  }
  if (!isDeptoOficina(formulario.value.deptoOficina)) {
    errorFormulario.value = `El depto u oficina es opcional; si lo ingresas, usa hasta ${LIMITES.deptoOficina} caracteres`
    return
  }
  if (!isReferenciaDireccion(formulario.value.referencia)) {
    errorFormulario.value = `La referencia es opcional; si la ingresas, usa hasta ${LIMITES.referencia} caracteres`
    return
  }

  guardando.value = true
  try {
    const base = {
      etiqueta: formulario.value.etiqueta?.trim() || 'Casa',
      comunaId: formulario.value.comunaId,
      calle: formulario.value.calle.trim(),
      numero: formulario.value.numero?.trim() || null,
      deptoOficina: formulario.value.deptoOficina?.trim() || null,
      referencia: formulario.value.referencia?.trim() || null,
    }

    if (editandoId.value) {
      const patch = {
        etiqueta: base.etiqueta,
        comuna_id: base.comunaId,
        calle: base.calle,
        numero: base.numero,
        depto_oficina: base.deptoOficina,
        referencia: base.referencia,
        // Desmarcar «principal» sí debe persistirse; antes el control no hacía
        // nada y la dirección seguía siendo la predeterminada.
        ...(eraPrincipal.value && !formulario.value.esPrincipal ? { es_principal: false } : {}),
      }
      await updateDireccion(editandoId.value, patch)
      // Marcar como principal se hace después y en dos pasos: primero se libera
      // la principal anterior (índice UNIQUE parcial).
      if (formulario.value.esPrincipal && !eraPrincipal.value) {
        await marcarDireccionPrincipal({
          direccionId: editandoId.value,
          perfilId: auth.perfil.id,
        })
      }
      ui.success('Dirección actualizada', 'Los cambios quedaron guardados')
    } else {
      // Se crea SIEMPRE sin principal: el índice UNIQUE parcial rechazaría el
      // INSERT si ya existe otra principal. Luego se hace el cambio en dos pasos.
      const creada = await createDireccion({
        perfilId: auth.perfil.id,
        ...base,
        esPrincipal: false,
      })
      if (formulario.value.esPrincipal && creada?.id) {
        await marcarDireccionPrincipal({ direccionId: creada.id, perfilId: auth.perfil.id })
      }
      ui.success('Dirección agregada', 'Ya puedes usarla en tus pedidos')
    }

    modalAbierto.value = false
    await cargar()
  } catch (e) {
    errorFormulario.value = mensajeError(e)
  } finally {
    guardando.value = false
  }
}

async function marcarPrincipal(direccion) {
  procesandoId.value = direccion.id
  try {
    await marcarDireccionPrincipal({ direccionId: direccion.id, perfilId: auth.perfil.id })
    ui.success('Dirección principal actualizada', `${direccion.etiqueta} será la predeterminada`)
    await cargar()
  } catch (e) {
    ui.error('No se pudo marcar como principal', mensajeError(e))
  } finally {
    procesandoId.value = null
  }
}

function pedirEliminar(direccion) {
  porEliminar.value = direccion
  eliminarAbierto.value = true
}

async function confirmarEliminar() {
  if (!porEliminar.value) return
  const objetivo = porEliminar.value
  procesandoId.value = objetivo.id
  try {
    await eliminarDireccion(objetivo.id)
    eliminarAbierto.value = false
    porEliminar.value = null
    ui.success('Dirección eliminada', `${objetivo.etiqueta} ya no está disponible`)
    await cargar()
  } catch (e) {
    ui.error('No se pudo eliminar la dirección', mensajeError(e))
  } finally {
    procesandoId.value = null
  }
}

onMounted(async () => {
  void geo.load()
  await cargar()
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Mis Direcciones</h1>
        <p class="page-head__subtitle">
          {{ direcciones.length }}
          {{ direcciones.length === 1 ? 'dirección activa' : 'direcciones activas' }} ·
          la principal se usa por defecto en tus pedidos.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton :disabled="!puedeAgregar" @click="abrirNueva">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Agregar dirección
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar tus direcciones">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtAlert v-if="esProductor" tone="info" compact title="Dirección del productor">
      <p class="linea">
        <CtIcon name="info" :size="15" />
        <span>
          Como productor CuTuCo admite <strong>una sola dirección activa</strong>: es tu región de
          cobertura. Si cambias la comuna, cambiarás también la región en la que apareces para las
          compras.
        </span>
      </p>
    </CtAlert>

    <CtAlert v-if="!puedeAgregar" tone="warning" compact title="Ya tienes tu dirección activa">
      <p class="linea">
        <CtIcon name="alert" :size="15" />
        <span>
          Los productores no pueden registrar una segunda dirección activa. Edita la existente si
          necesitas cambiar de ubicación.
        </span>
      </p>
    </CtAlert>

    <CtSpinner v-if="cargando" label="Cargando tus direcciones" />

    <template v-else>
      <CtEmptyState
        v-if="!direcciones.length"
        icon="pin"
        title="Todavía no tienes direcciones"
        message="Registra tu dirección de entrega para poder validar la cobertura del vendedor y pagar tus pedidos."
      >
        <CtButton @click="abrirNueva">
          <template #icon><CtIcon name="plus" :size="16" /></template>
          Agregar mi primera dirección
        </CtButton>
      </CtEmptyState>

      <div v-else class="grilla">
        <CtCard v-for="direccion in direcciones" :key="direccion.id" padding="md">
          <template #header>
            <div class="row row--between">
              <strong class="text-md">{{ direccion.etiqueta }}</strong>
              <CtBadge :tone="direccion.es_principal ? 'success' : 'neutral'" size="sm" dot>
                {{ direccion.es_principal ? 'Principal' : 'Secundaria' }}
              </CtBadge>
            </div>
          </template>

          <dl class="datos">
            <div class="dato">
              <dt class="dato__label">Dirección</dt>
              <dd class="dato__valor">{{ textoDireccion(direccion) }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Comuna</dt>
              <dd class="dato__valor">{{ nombreComuna(direccion.comuna_id) }}</dd>
            </div>
            <div class="dato">
              <dt class="dato__label">Región</dt>
              <dd class="dato__valor">{{ nombreRegion(direccion.comuna_id) }}</dd>
            </div>
            <div v-if="direccion.referencia" class="dato">
              <dt class="dato__label">Referencia</dt>
              <dd class="dato__valor">{{ direccion.referencia }}</dd>
            </div>
          </dl>

          <template #footer>
            <div class="acciones">
              <CtButton
                v-if="!direccion.es_principal"
                size="sm"
                variant="secondary"
                :loading="procesandoId === direccion.id"
                @click="marcarPrincipal(direccion)"
              >
                <template #icon><CtIcon name="check" :size="15" /></template>
                Marcar como principal
              </CtButton>
              <CtButton size="sm" variant="outline" @click="abrirEdicion(direccion)">
                <template #icon><CtIcon name="edit" :size="15" /></template>
                Editar
              </CtButton>
              <CtButton
                size="sm"
                variant="ghost"
                :disabled="!puedeEliminar(direccion)"
                :title="
                  puedeEliminar(direccion)
                    ? 'Eliminar dirección'
                    : 'Un productor debe conservar su dirección activa'
                "
                @click="pedirEliminar(direccion)"
              >
                <template #icon><CtIcon name="trash" :size="15" /></template>
                Eliminar
              </CtButton>
            </div>
          </template>
        </CtCard>
      </div>
    </template>

    <!-- ============ Alta / edición ============ -->
    <CtModal
      v-model="modalAbierto"
      :title="editandoId ? 'Editar dirección' : 'Agregar dirección'"
      subtitle="Elige la región y la comuna de tu dirección de entrega."
      size="md"
    >
      <div class="stack">
        <CtAlert v-if="errorFormulario" tone="danger">{{ errorFormulario }}</CtAlert>

        <CtAlert v-if="geo.error" tone="danger" title="No pudimos cargar regiones y comunas">
          <p>{{ geo.error }}</p>
          <CtButton size="sm" variant="secondary" :loading="geo.cargando" @click="geo.load({ force: true })">
            Reintentar
          </CtButton>
        </CtAlert>

        <div class="formulario__fila">
          <CtSelect
            v-model="formulario.regionId"
            label="Región"
            :options="opcionesRegion"
            :disabled="geo.cargando || !geo.cargado"
            placeholder="Selecciona la región"
            @change="formulario.comunaId = null"
          />
          <CtSelect
            v-model="formulario.comunaId"
            label="Comuna"
            :options="opcionesComuna"
            :disabled="!formulario.regionId"
            placeholder="Selecciona la comuna"
            required
          />
        </div>

        <div class="formulario__fila">
          <CtInput v-model="formulario.calle" label="Calle" placeholder="Calle Compañía" required />
          <CtInput
            v-model="formulario.numero"
            label="Nro./Altura de calle (opcional)"
            placeholder="123-B, Casa 3"
            :hint="`Opcional y alfanumérico (máx. ${LIMITES.numero} caracteres)`"
          />
        </div>

        <div class="formulario__fila">
          <CtInput v-model="formulario.etiqueta" label="Etiqueta" placeholder="Casa" />
          <CtInput
            v-model="formulario.deptoOficina"
            label="Depto u oficina (opcional)"
            placeholder="Depto 402, Parcela 4, Local B"
            :hint="`Complemento separado de la calle (máx. ${LIMITES.deptoOficina} caracteres)`"
          />
        </div>

        <CtInput
          v-model="formulario.referencia"
          label="Referencia"
          placeholder="Portón verde, timbre 3"
          hint="Opcional: ayuda al repartidor a ubicar el domicilio"
        />

        <CtCheckbox
          v-model="formulario.esPrincipal"
          label="Usar como dirección principal"
          description="La principal se preselecciona en el carrito y en el checkout."
        />
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="guardando" @click="modalAbierto = false">
          Cancelar
        </CtButton>
        <CtButton :loading="guardando" @click="guardar">
          {{ editandoId ? 'Guardar cambios' : 'Agregar dirección' }}
        </CtButton>
      </template>
    </CtModal>

    <CtConfirmDialog
      v-model="eliminarAbierto"
      title="¿Eliminar esta dirección?"
      :message="
        porEliminar?.es_principal && direcciones.length > 1
          ? 'Es tu dirección principal: después de eliminarla tendrás que elegir otra como principal.'
          : 'La dirección dejará de estar disponible para tus pedidos. Esta acción no se puede deshacer.'
      "
      confirm-label="Eliminar dirección"
      tone="danger"
      :loading="Boolean(procesandoId)"
      @confirm="confirmarEliminar"
    >
      <template #icon><CtIcon name="trash" :size="20" /></template>
    </CtConfirmDialog>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.grilla {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: var(--ct-space-5);
  align-items: start;
}

.formulario__fila {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--ct-space-4);
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
}

.acciones {
  display: flex;
  align-items: center;
  gap: var(--ct-space-2);
  flex-wrap: wrap;
  justify-content: flex-end;
}
</style>
