<script setup>
/** CuTuCo — Grilla de productos con estados de carga y vacío. */
import ProductCard from './ProductCard.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtPagination from '@/components/base/CtPagination.vue'

defineProps({
  productos: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  skeletonCount: { type: Number, default: 8 },
  showRating: { type: Boolean, default: false },
  showCategory: { type: Boolean, default: false },
  emptyTitle: { type: String, default: 'No encontramos productos' },
  emptyMessage: { type: String, default: 'Prueba ajustando los filtros de categoría, región o búsqueda.' },
  page: { type: Number, default: 1 },
  total: { type: Number, default: 0 },
  pageSize: { type: Number, default: 12 },
})

const emit = defineEmits(['add', 'update:page', 'update:pageSize'])
</script>

<template>
  <div class="pgrid">
    <template v-if="loading">
      <div v-for="i in skeletonCount" :key="i" class="pgrid__skeleton">
        <div class="skeleton pgrid__skeleton-media" />
        <div class="pgrid__skeleton-lines">
          <div class="skeleton" style="height: 14px; width: 70%" />
          <div class="skeleton" style="height: 12px; width: 45%" />
          <div class="skeleton" style="height: 20px; width: 35%" />
        </div>
      </div>
    </template>

    <template v-else-if="productos.length">
      <ProductCard
        v-for="producto in productos"
        :key="producto.id"
        :producto="producto"
        :show-rating="showRating"
        :show-category="showCategory"
        @add="emit('add', $event)"
      />
    </template>

    <CtEmptyState v-else icon="catalog" :title="emptyTitle" :message="emptyMessage">
      <slot name="empty-action" />
    </CtEmptyState>

    <div v-if="!loading && productos.length" class="pgrid__pagination">
      <CtPagination
        :page="page"
        :total="total"
        :page-size="pageSize"
        label="productos"
        @update:page="emit('update:page', $event)"
        @update:page-size="emit('update:pageSize', $event)"
      />
    </div>
  </div>
</template>

<style scoped>
.pgrid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: var(--ct-space-5);
}

.pgrid__skeleton {
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  overflow: hidden;
  background: var(--ct-surface);
}

.pgrid__skeleton-media {
  aspect-ratio: 4 / 3;
  border-radius: 0;
}

.pgrid__skeleton-lines {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
  padding: var(--ct-space-4);
}

.pgrid__pagination {
  grid-column: 1 / -1;
}
</style>
