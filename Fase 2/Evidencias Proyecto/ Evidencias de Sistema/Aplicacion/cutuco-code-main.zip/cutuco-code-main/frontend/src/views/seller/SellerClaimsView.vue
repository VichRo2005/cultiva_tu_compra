<script setup>
/**
 * CuTuCo — Reclamos recibidos (RF-027 y RF-026).
 *
 * Bandeja del vendedor con los reclamos abiertos sobre SUS pedidos. La RLS
 * `reclamos_select_participantes` deja ver al productor propietario los reclamos
 * de sus pedidos, y `reclamos_update_productor_admin` le permite responderlos.
 *
 * El trigger `proteger_campos_reclamo` limita al vendedor a escribir
 * `respuesta_productor`: el estado y la resolución del caso son del
 * administrador. Con Webpay Mall el reclamo NO bloquea dinero: el cobro ya fue
 * dispersado por Transbank; la resolución la decide el administrador.
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { formatCLP, formatDate, formatDateTime, pluralize } from '@/lib/format'
import { identificadorClienteReclamo, nombreClienteReclamo } from '@/lib/orders'
import { listReclamosProductor, responderReclamo } from '@/services/reclamos'
import { getMiProductor } from '@/services/seller'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const reclamos = ref([])
const cargando = ref(true)
const error = ref(null)

const modalAbierto = ref(false)
const reclamoActual = ref(null)
const respuesta = ref('')
const errorRespuesta = ref(null)
const enviando = ref(false)

const columns = [
  { key: 'pedido', label: 'Pedido', width: '180px' },
  { key: 'creado_en', label: 'Recibido', width: '130px' },
  { key: 'motivo', label: 'Motivo' },
  { key: 'cliente', label: 'Cliente', width: '190px' },
  { key: 'estado', label: 'Estado', width: '150px' },
  { key: 'acciones', label: 'Acciones', align: 'right', width: '200px' },
]

const vigentes = computed(() => reclamos.value.filter((r) => r.vigente))
const sinResponder = computed(() =>
  reclamos.value.filter((r) => r.vigente && !r.respuesta_productor),
)

/** Enlace al pedido: es el canal de contacto permitido desde la bandeja. */
function enlacePedido(reclamo) {
  return `/vendedor/pedidos/${reclamo.pedido_id}`
}

async function cargar() {
  cargando.value = true
  error.value = null
  try {
    const productor = await getMiProductor()
    reclamos.value = productor ? await listReclamosProductor(productor.id) : []
  } catch (e) {
    error.value = e?.message ?? 'No se pudieron cargar los reclamos'
  } finally {
    cargando.value = false
  }
}

function abrirRespuesta(reclamo) {
  reclamoActual.value = reclamo
  respuesta.value = reclamo.respuesta_productor ?? ''
  errorRespuesta.value = null
  modalAbierto.value = true
}

async function enviarRespuesta() {
  errorRespuesta.value = null
  if (!respuesta.value.trim()) {
    errorRespuesta.value = 'Escribe una respuesta para el cliente'
    return
  }
  enviando.value = true
  try {
    await responderReclamo({ reclamoId: reclamoActual.value.id, respuesta: respuesta.value })
    modalAbierto.value = false
    ui.success('Respuesta enviada', 'El cliente verá tu respuesta en el detalle del reclamo')
    await cargar()
  } catch (e) {
    errorRespuesta.value = e?.message ?? 'No se pudo enviar la respuesta'
  } finally {
    enviando.value = false
  }
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Reclamos Recibidos</h1>
        <p class="page-head__subtitle">
          {{ reclamos.length }} {{ pluralize(reclamos.length, 'reclamo', 'reclamos') }} ·
          {{ sinResponder.length }} sin respuesta.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="cargando" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar los reclamos">
      <p class="linea">
        <CtIcon name="alert" :size="16" />
        <span>{{ error }}</span>
      </p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtAlert tone="info" compact title="Efecto de un reclamo abierto">
      <p class="linea">
        <CtIcon name="info" :size="15" />
        <span>
          Esta sección conserva una constancia para ambas partes. Responde al cliente y coordina la
          solución directamente con él fuera de CuTuCo. El registro no bloquea ni modifica tu pago.
        </span>
      </p>
    </CtAlert>

    <CtSpinner v-if="cargando" label="Cargando los reclamos de tus pedidos" />

    <template v-else>
      <CtCard padding="md">
        <div class="grid-kpi">
          <div class="kpi">
            <span class="eyebrow">Total</span>
            <span class="kpi__valor">{{ reclamos.length }}</span>
          </div>
          <div class="kpi">
            <span class="eyebrow">Vigentes</span>
            <span class="kpi__valor">{{ vigentes.length }}</span>
          </div>
          <div class="kpi">
            <span class="eyebrow">Sin responder</span>
            <span class="kpi__valor">{{ sinResponder.length }}</span>
          </div>
        </div>
      </CtCard>

      <CtTable
        :columns="columns"
        :rows="reclamos"
        empty-icon=""
        empty-title="Sin reclamos"
        empty-message="Ningún cliente ha reclamado sobre tus pedidos."
        min-width="900px"
      >
        <template #cell-pedido="{ row }">
          <div class="stack stack--xs">
            <router-link :to="`/vendedor/pedidos/${row.pedido_id}`" class="mono font-semibold">
              {{ row.pedido?.codigo_pedido ?? '—' }}
            </router-link>
            <span class="text-xs text-muted">
              {{ formatCLP(row.pedido?.total ?? 0) }} · pago autorizado
            </span>
          </div>
        </template>

        <template #cell-creado_en="{ row }">
          {{ formatDate(row.creado_en) }}
        </template>

        <template #cell-motivo="{ row }">
          <div class="stack stack--xs">
            <span class="text-sm font-semibold texto-largo">{{ row.motivo }}</span>
            <span class="text-xs text-muted texto-largo clamp-2">{{ row.descripcion }}</span>
          </div>
        </template>

        <template #cell-cliente="{ row }">
          <router-link :to="enlacePedido(row)" class="cliente-enlace">
            <span class="font-semibold texto-largo">{{ nombreClienteReclamo(row) }}</span>
            <span class="text-xs text-muted">
              Cliente {{ identificadorClienteReclamo(row) }} · ver pedido
            </span>
          </router-link>
        </template>

        <template #cell-estado="{ row }">
          <div class="row row--wrap">
            <StatusBadge type="reclamo" :value="row.estado" size="sm" />
            <CtBadge v-if="row.respuesta_productor" tone="success" size="sm">Respondido</CtBadge>
          </div>
        </template>

        <template #cell-acciones="{ row }">
          <div class="acciones">
            <CtButton v-if="row.vigente" size="sm" variant="outline" @click="abrirRespuesta(row)">
              {{ row.respuesta_productor ? 'Editar respuesta' : 'Responder' }}
            </CtButton>
            <span v-else class="text-xs text-muted">Reclamo cerrado</span>
            <CtButton size="sm" variant="ghost" :to="enlacePedido(row)">Ver pedido</CtButton>
          </div>
        </template>
      </CtTable>
    </template>

    <CtModal
      v-model="modalAbierto"
      title="Responder el reclamo"
      :subtitle="reclamoActual?.motivo"
      size="md"
    >
      <div class="stack">
        <CtAlert v-if="errorRespuesta" tone="danger">{{ errorRespuesta }}</CtAlert>

        <dl class="datos">
          <div class="dato">
            <dt class="dato__label">Pedido</dt>
            <dd class="dato__valor mono">
              <router-link
                v-if="reclamoActual"
                :to="enlacePedido(reclamoActual)"
                class="cliente-enlace"
              >
                {{ reclamoActual?.pedido?.codigo_pedido ?? '—' }}
              </router-link>
              <template v-else>—</template>
            </dd>
          </div>
          <div class="dato">
            <dt class="dato__label">Cliente</dt>
            <dd class="dato__valor texto-largo">
              {{ reclamoActual ? nombreClienteReclamo(reclamoActual) : '—' }}
              <span class="text-xs text-muted">
                · Cliente {{ reclamoActual ? identificadorClienteReclamo(reclamoActual) : '—' }}
              </span>
            </dd>
          </div>
          <div class="dato">
            <dt class="dato__label">Recibido</dt>
            <dd class="dato__valor">{{ formatDateTime(reclamoActual?.creado_en) }}</dd>
          </div>
          <div class="dato">
            <dt class="dato__label">Descripción del cliente</dt>
            <dd class="dato__valor texto-largo">{{ reclamoActual?.descripcion }}</dd>
          </div>
        </dl>

        <CtAlert tone="neutral" compact title="Cómo resolver el caso">
          <p class="texto-largo">
            CuTuCo sólo registra la constancia. Coordina la solución directamente con el cliente
            usando los datos de entrega del pedido asociado; el resultado no se decide dentro de
            esta plataforma.
          </p>
          <CtButton
            v-if="reclamoActual"
            size="sm"
            variant="secondary"
            :to="enlacePedido(reclamoActual)"
          >
            Abrir el pedido
          </CtButton>
        </CtAlert>

        <CtTextarea
          v-model="respuesta"
          label="Tu respuesta"
          placeholder="Explica qué ocurrió y cómo lo resolviste"
          :rows="5"
          :maxlength="2500"
          show-count
          required
        />

        <CtAlert tone="info" compact>
          <p class="linea">
            <CtIcon name="info" :size="15" />
            <span>
              Tu respuesta queda visible para el cliente como parte de la constancia. La solución
              se acuerda directamente entre ambas partes fuera de CuTuCo.
            </span>
          </p>
        </CtAlert>
      </div>
      <template #footer>
        <CtButton variant="secondary" :disabled="enviando" @click="modalAbierto = false">
          Cancelar
        </CtButton>
        <CtButton :loading="enviando" @click="enviarRespuesta">Enviar respuesta</CtButton>
      </template>
    </CtModal>
  </div>
</template>

<style scoped>
.linea {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-2);
}

.linea > span {
  flex: 1;
  min-width: 0;
}

.grid-kpi {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: var(--ct-space-4);
}

.kpi {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.kpi__valor {
  font-size: var(--ct-fs-2xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: var(--ct-tracking-tight);
}

.clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.texto-largo {
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.cliente-enlace {
  display: inline-flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
  color: inherit;
  text-decoration: none;
}

.cliente-enlace:hover .font-semibold {
  color: var(--ct-primary-strong);
  text-decoration: underline;
}

.acciones {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: var(--ct-space-1);
}

.datos {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  margin: 0;
}

.dato {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.dato__label {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.dato__valor {
  margin: 0;
  min-width: 0;
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-medium);
  overflow-wrap: anywhere;
  word-break: break-word;
}
</style>
