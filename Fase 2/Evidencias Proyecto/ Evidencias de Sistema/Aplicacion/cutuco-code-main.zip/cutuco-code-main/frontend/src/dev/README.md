# CuTuCo — Galería temporal de vistas (TEMPORAL)

> ⚠️ **Todo lo que hay en esta carpeta es temporal y se elimina antes del release de producción.**
> No forma parte del diseño de `CuTuCo Vistas.pdf`: es una herramienta de revisión interna.

## Qué hace

- Muestra el aviso **“Vistas en Desarrollo”** en todas las ventanas.
- Agrega un botón flotante “Vistas” que abre una barra lateral con **todas** las ventanas
  del producto (público, autenticación, cliente, productor y administración).
- Permite abrir cualquiera de ellas **sin autenticarse**: el guard de rutas queda
  desactivado y se entra automáticamente con la cuenta demo de administración.
- Permite cambiar de rol (Administración / Productor / Cliente) desde la misma barra,
  sin pasar por el formulario de login.

Los datos siguen viniendo del modo demo de Supabase (`src/lib/mockSupabase.js` +
`src/data/demoDataset.js`), que respeta el esquema de
`supabase/migrations/20260924114306_remote_schema.sql`.

## Archivos

| Archivo | Rol |
| --- | --- |
| `devGallery.js` | Interruptor, cuentas demo, IDs de ejemplo y registro de ventanas |
| `DevOverlay.vue` | Contenedor: aviso + botón flotante |
| `DevBanner.vue` | Aviso “Vistas en Desarrollo” |
| `DevGalleryNav.vue` | Barra lateral con todas las ventanas |

## Nota sobre los datos

El modo demo de Supabase (`src/lib/mockSupabase.js`) guarda el dataset **en memoria**: las
escrituras (crear un producto, aprobar una postulación, liberar un pago) se ven al instante en la
sesión abierta, pero se reinician al recargar la página. Para probar un flujo completo conviene
recorrerlo sin recargar.

## Cómo desactivarla sin borrar nada

Definir la variable de entorno y reiniciar Vite:

```
VITE_DEV_GALLERY=false
```

## Cómo eliminarla por completo (5 pasos)

1. Borrar la carpeta `src/dev/`.
2. `src/layouts/AppShell.vue`: quitar el import de `DevOverlay` y el `<DevOverlay />`.
3. `src/layouts/AuthLayout.vue`: quitar el import de `DevOverlay` y el `<DevOverlay />`.
4. `src/router/index.js`: quitar el import de `DEV_GALLERY_ENABLED` y el bloque
   `if (DEV_GALLERY_ENABLED) return true`.
5. `src/App.vue`: quitar el import de `@/dev/devGallery` y la función `sesionDeGaleria()`
   junto con su llamada en `onMounted`.

Ningún otro archivo del producto depende de esta carpeta.