<script setup>
/**
 * CuTuCo — Alta y edición de un producto (página 13 del diseño).
 *
 *   RF-003  nombre, descripción, precio, stock, unidad de medida, categoría y
 *           fotografía del producto tomada con la cámara (`capture="environment"`)
 *   RF-018  categoría elegida con `CtSelect` jerárquico desde
 *           `getArbolCategorias()` (HAL-VEN-006)
 *   RF-019  validaciones con `@/lib/validation` y error mostrado en cada campo
 *   RF-021  sólo el vendedor aprobado y activo puede publicar
 *
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa):
 *   El formulario incluía variedad y calibre anexados a la descripción, umbral
 *   de stock bajo y "Cosecha del día" (RF-010 y sello fuera de alcance),
 *   sugerencia de precios con historial de mercado (RF-008), documentos de
 *   identidad de la postulación (RF-015, carnet fuera de alcance), cobertura por
 *   comuna (RF-009 versión antigua) y el guardado con `saveProducto`. Todo eso
 *   salió del ERS: ahora se usan `createProducto`, `updateProducto`,
 *   `getProductoVendedor`, `subirImagenProducto` y `eliminarImagenProducto` de
 *   `@/services/seller`, con la cámara como fuente de la fotografía.
 */
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtCheckbox from '@/components/base/CtCheckbox.vue'
import CtFileUpload from '@/components/base/CtFileUpload.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtInput from '@/components/base/CtInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTextarea from '@/components/base/CtTextarea.vue'
import { ESTADO_POSTULACION, LABELS, UNIDAD_MEDIDA } from '@/lib/constants'
import { formatCLP, formatDate, formatNumber, formatRelative, todayISO } from '@/lib/format'
import { validate } from '@/lib/validation'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import {
  esMultiploDeIncremento,
  esUnidadFraccionable,
  formatearCantidad,
  getArbolCategorias,
} from '@/services/catalog'
import {
  createProducto,
  eliminarImagenProducto,
  getMiPostulacion,
  getMiProductor,
  getProductoVendedor,
  LIMITES_PRODUCTO,
  MOTIVO_PAUSA_POR_DEFECTO,
  MOTIVO_PRODUCTO_MAX,
  subirImagenProducto,
  updateProducto,
  validarMotivoProducto,
} from '@/services/seller'

const route = useRoute()
const router = useRouter()
const ui = useUiStore()
const auth = useAuthStore()

const productoId = computed(() => route.params.id ?? null)
const esEdicion = computed(() => Boolean(productoId.value))

const cargando = ref(true)
const guardando = ref(false)
const errorForm = ref(null)
const errorImagen = ref(null)

const productor = ref(null)
const postulacion = ref(null)
/** Árbol padre → hijos ya filtrado (HAL-VEN-006/021): sin duplicados ni fuera de alcance. */
const arbolCategorias = ref([])
const productoOriginal = ref(null)

const form = ref({
  nombre: '',
  categoria_id: null,
  categoria_principal_id: null,
  subcategoria_id: null,
  descripcion: '',
  precio: '',
  stock: '',
  unidad_medida: 'kg',
  incremento_venta: 1,
  cantidad_minima_compra: 1,
  fecha_cosecha: '',
  activo: true,
})

const errores = ref({})
const nuevasImagenes = ref([])
/** Justificación que exige el trigger cuando el producto pasa a inactivo. */
const motivoPausa = ref(MOTIVO_PAUSA_POR_DEFECTO)

/** Categorías raíz: se elige primero la categoría principal. */
const opcionesCategoriaPrincipal = computed(() =>
  arbolCategorias.value.map((categoria) => ({
    value: categoria.id,
    label: categoria.nombre,
  })),
)

/** Subcategorías de la categoría principal seleccionada; no son obligatorias. */
const opcionesSubcategoria = computed(() => {
  const principal = arbolCategorias.value.find(
    (categoria) => String(categoria.id) === String(form.value.categoria_principal_id ?? ''),
  )
  return (principal?.hijos ?? []).map((categoria) => ({ value: categoria.id, label: categoria.nombre }))
})
const opcionesUnidad = computed(() =>
  UNIDAD_MEDIDA.map((u) => ({ value: u, label: LABELS.unidad[u] ?? u })),
)

const unidades = computed(() => LABELS.unidad[form.value.unidad_medida] ?? form.value.unidad_medida)
const unidadFraccionable = computed(() => esUnidadFraccionable(form.value.unidad_medida))
const pasoCampoCantidad = computed(() => (unidadFraccionable.value ? 0.1 : 1))

function cantidadConPrecisionValida(valor) {
  const cantidad = Number(valor)
  const escalada = Math.round(cantidad * 10)
  return (
    Number.isFinite(cantidad) &&
    cantidad > 0 &&
    cantidad <= LIMITES_PRODUCTO.stockMax &&
    Math.abs(cantidad - escalada / 10) <= 1e-9
  )
}

function errorCantidadComercial(valor, etiqueta, valores) {
  const cantidad = Number(valor)
  if (!cantidadConPrecisionValida(cantidad)) {
    return `${etiqueta} debe ser mayor que cero y tener como máximo un decimal.`
  }
  if (!esUnidadFraccionable(valores.unidad_medida) && !Number.isInteger(cantidad)) {
    return `${etiqueta} debe ser una cantidad entera para ${LABELS.unidad[valores.unidad_medida] ?? 'esta unidad'}.`
  }
  return null
}

function asignarCategoriaDesdeProducto(categoriaId) {
  const principal = arbolCategorias.value.find(
    (categoria) =>
      String(categoria.id) === String(categoriaId ?? '') ||
      (categoria.hijos ?? []).some((hijo) => String(hijo.id) === String(categoriaId ?? '')),
  )
  form.value.categoria_principal_id = principal?.id ?? null
  form.value.subcategoria_id =
    principal?.hijos?.some((hijo) => String(hijo.id) === String(categoriaId ?? '')) ? categoriaId : null
  form.value.categoria_id = categoriaId ?? null
}

function cambiarCategoriaPrincipal(categoriaId) {
  form.value.categoria_principal_id = categoriaId || null
  form.value.subcategoria_id = null
  form.value.categoria_id = categoriaId || null
}

function cambiarSubcategoria(subcategoriaId) {
  form.value.subcategoria_id = subcategoriaId || null
  form.value.categoria_id = subcategoriaId || form.value.categoria_principal_id || null
}

const resumenReglasVenta = computed(() => {
  const paso = Number(form.value.incremento_venta)
  const minimo = Number(form.value.cantidad_minima_compra)
  if (!cantidadConPrecisionValida(paso) || !cantidadConPrecisionValida(minimo)) return null
  return `El cliente comprará desde ${formatearCantidad(minimo, form.value.unidad_medida)} ${unidades.value}, en incrementos de ${formatearCantidad(paso, form.value.unidad_medida)} ${unidades.value}.`
})

/** RF-019: reglas del formulario de producto (se muestran en el campo). */
const ESQUEMA = {
  nombre: { required: true, minLength: 3, maxLength: 180 },
  categoria_id: { required: true },
  descripcion: { required: true, minLength: 10, maxLength: 1800 },
  unidad_medida: { required: true, oneOf: UNIDAD_MEDIDA },
  precio: {
    required: true,
    positive: true,
    integer: true,
    custom: (valor) =>
      Number(valor) > LIMITES_PRODUCTO.precioMax
        ? `El precio no puede superar ${formatNumber(LIMITES_PRODUCTO.precioMax)} CLP`
        : null,
  },
  stock: {
    required: true,
    nonNegative: true,
    custom: (valor) => {
      const stock = Number(valor)
      if (!Number.isFinite(stock) || Math.abs(stock - Math.round(stock * 10) / 10) > 1e-9) {
        return 'El stock puede tener como máximo un decimal.'
      }
      return stock > LIMITES_PRODUCTO.stockMax
        ? `El stock no puede superar ${formatNumber(LIMITES_PRODUCTO.stockMax)} unidades`
        : null
    },
  },
  incremento_venta: {
    required: true,
    positive: true,
    custom: (valor, valores) => errorCantidadComercial(valor, 'El incremento de venta', valores),
  },
  cantidad_minima_compra: {
    required: true,
    positive: true,
    custom: (valor, valores) => {
      const errorBase = errorCantidadComercial(valor, 'La compra mínima', valores)
      if (errorBase) return errorBase
      const minimo = Number(valor)
      const incremento = Number(valores.incremento_venta)
      if (!cantidadConPrecisionValida(incremento)) {
        return 'Define primero un incremento de venta válido.'
      }
      if (!esMultiploDeIncremento(minimo, incremento)) {
        return 'La compra mínima debe ser múltiplo del incremento de venta.'
      }
      const stock = Number(valores.stock)
      if (Number.isFinite(stock) && stock > 0 && minimo > stock) {
        return 'La compra mínima no puede superar el stock publicado.'
      }
      return null
    },
  },
  fecha_cosecha: {
    custom: (valor) => (valor && String(valor) > todayISO() ? 'La fecha de cosecha no puede ser futura' : null),
  },
}

onMounted(async () => {
  try {
    const [miProductor, miPostulacion, arbol] = await Promise.all([
      getMiProductor(),
      getMiPostulacion(),
      getArbolCategorias().catch(() => []),
    ])
    productor.value = miProductor ?? auth.productor ?? null
    postulacion.value = miPostulacion ?? auth.postulacion ?? null
    arbolCategorias.value = arbol ?? []
  } catch (e) {
    errorForm.value = e.message
  }

  if (esEdicion.value) {
    try {
      const producto = await getProductoVendedor(productoId.value)
      if (!producto) {
        errorForm.value = 'El producto no existe, fue eliminado o no pertenece a tu tienda.'
      } else {
        productoOriginal.value = producto
        form.value = {
          nombre: producto.nombre ?? '',
          categoria_id: producto.categoria_id ?? null,
          categoria_principal_id: null,
          subcategoria_id: null,
          descripcion: producto.descripcion ?? '',
          precio: producto.precio ?? '',
          stock: producto.stock ?? '',
          unidad_medida: producto.unidad_medida ?? 'kg',
          incremento_venta: producto.incremento_venta ?? 1,
          cantidad_minima_compra: producto.cantidad_minima_compra ?? 1,
          fecha_cosecha: producto.fecha_cosecha ?? '',
          activo: producto.activo ?? true,
        }
        asignarCategoriaDesdeProducto(producto.categoria_id)
        motivoPausa.value = producto.motivo_pausa || MOTIVO_PAUSA_POR_DEFECTO
      }
    } catch (e) {
      errorForm.value = e.message
    }
  }

  cargando.value = false
})

/* ------------------------------------------------------------------ */
/* Permisos de la cuenta (RF-021 y RF-026)                             */
/* ------------------------------------------------------------------ */

const aprobado = computed(
  () => postulacion.value?.estado === ESTADO_POSTULACION.APROBADA && Boolean(productor.value?.aprobado_en),
)

const motivoBloqueo = computed(() => {
  if (auth.bloqueoVendedor) return auth.bloqueoVendedor
  if (!productor.value) {
    return 'Todavía no tienes una tienda de productor. La tienda se crea cuando el administrador aprueba tu postulación.'
  }
  if (productor.value.activo === false) return 'Tu tienda está desactivada: no puedes publicar productos.'
  if (productor.value.servicio_suspendido) {
    return 'Tu tienda está suspendida por el servicio mensual impago. Paga en Servicio y pagos para reactivarla.'
  }
  if (postulacion.value?.estado === ESTADO_POSTULACION.RECHAZADA) {
    return 'Tu solicitud de vendedor fue rechazada.'
  }
  if (
    [ESTADO_POSTULACION.EN_REVISION, ESTADO_POSTULACION.PENDIENTE_APROBACION].includes(
      postulacion.value?.estado,
    )
  ) {
    return 'Tu solicitud de vendedor está pendiente de aprobación: aún no puedes publicar productos.'
  }
  return null
})

const puedeOperar = computed(() => !motivoBloqueo.value && aprobado.value)

const imagenes = computed(() => productoOriginal.value?.imagenes ?? [])

/** RF-003: en el alta la fotografía del producto es obligatoria. */
const exigeFoto = computed(() => nuevasImagenes.value.length + imagenes.value.length === 0)

const diasEnCatalogo = computed(() => {
  const creado = productoOriginal.value?.creado_en
  if (!creado) return null
  return Math.max(0, Math.round((Date.now() - new Date(creado).getTime()) / 86400000))
})

const eliminado = computed(() => Boolean(productoOriginal.value?.eliminado_en))
const pausando = computed(
  () => Boolean(productoOriginal.value?.activo) && !form.value.activo && !eliminado.value,
)
const reactivando = computed(
  () => productoOriginal.value && !productoOriginal.value.activo && Boolean(form.value.activo),
)
const motivoPausaError = computed(() =>
  pausando.value ? validarMotivoProducto(motivoPausa.value, { max: MOTIVO_PRODUCTO_MAX }) : null,
)
const justificacionVigente = computed(
  () => productoOriginal.value?.motivo_eliminacion || productoOriginal.value?.motivo_pausa || null,
)
const puedeGuardar = computed(() => puedeOperar.value && !eliminado.value)

/* ------------------------------------------------------------------ */
/* Imágenes                                                            */
/* ------------------------------------------------------------------ */

async function quitarImagen(imagen) {
  const producto = productoOriginal.value
  // RF-003: un producto publicado debe conservar al menos una fotografía.
  if (producto?.activo && !producto?.eliminado_en && imagenes.value.length <= 1) {
    ui.warning(
      'No puedes quitar la última foto',
      'Un producto publicado debe conservar al menos una fotografía. Pausa el producto o sube otra foto primero.',
    )
    return
  }
  try {
    await eliminarImagenProducto(imagen)
    productoOriginal.value = {
      ...productoOriginal.value,
      imagenes: imagenes.value.filter((i) => i.id !== imagen.id),
    }
    ui.success('Imagen eliminada', 'La fotografía se quitó del producto.')
  } catch (e) {
    ui.error('No se pudo eliminar la imagen', e.message)
  }
}

/* ------------------------------------------------------------------ */
/* Guardado                                                            */
/* ------------------------------------------------------------------ */

async function guardar() {
  errorForm.value = null
  const { valid, errors } = validate(form.value, ESQUEMA)
  errores.value = { ...errors }

  // HAL-VEN-014: si se desmarca "Publicación activa", el trigger exige una
  // justificación de 10 a 1000 caracteres en el mismo UPDATE.
  if (pausando.value) {
    const errorPausa = validarMotivoProducto(motivoPausa.value, { max: MOTIVO_PRODUCTO_MAX })
    if (errorPausa) errores.value = { ...errores.value, motivo_pausa: errorPausa }
  }

  errorImagen.value = exigeFoto.value ? 'Adjunta una fotografía del producto tomada con la cámara' : null

  if (!valid || errorImagen.value || errores.value.motivo_pausa) {
    ui.warning('Revisa el formulario', 'Hay campos obligatorios por completar o corregir')
    return
  }
  if (eliminado.value) {
    errorForm.value = 'Este producto fue eliminado por el administrador: ya no se puede editar ni reactivar.'
    ui.error('Producto eliminado', errorForm.value)
    return
  }
  if (!puedeOperar.value) {
    ui.error('No puedes publicar productos', motivoBloqueo.value ?? 'Tu cuenta no está habilitada.')
    return
  }

  guardando.value = true
  try {
    const payload = {
      nombre: form.value.nombre.trim(),
      descripcion: form.value.descripcion.trim(),
      precio: Number(form.value.precio),
      stock: Number(form.value.stock),
      unidadMedida: form.value.unidad_medida,
      incrementoVenta: Number(form.value.incremento_venta),
      cantidadMinimaCompra: Number(form.value.cantidad_minima_compra),
      categoriaId: form.value.categoria_id,
      fechaCosecha: form.value.fecha_cosecha || null,
    }

    let guardado
    if (esEdicion.value) {
      const cambios = {
        nombre: payload.nombre,
        descripcion: payload.descripcion,
        precio: payload.precio,
        stock: payload.stock,
        unidad_medida: payload.unidadMedida,
        incremento_venta: payload.incrementoVenta,
        cantidad_minima_compra: payload.cantidadMinimaCompra,
        categoria_id: payload.categoriaId,
        fecha_cosecha: payload.fechaCosecha,
      }
      // Sólo se envía `activo` cuando cambia: si el producto ya estaba pausado
      // y sigue pausado, el trigger no debe volver a exigir justificación.
      if (pausando.value) {
        cambios.activo = false
        cambios.motivo_pausa = motivoPausa.value.trim()
      } else if (reactivando.value) {
        cambios.activo = true
      }
      guardado = await updateProducto(productoId.value, cambios)
    } else {
      guardado = await createProducto({ productorId: productor.value.id, ...payload })
    }

    // La fotografía se carga una vez que existe la publicación (RF-003).
    const yaTienePrincipal = imagenes.value.some((i) => i.es_principal)
    try {
      for (const [index, item] of nuevasImagenes.value.entries()) {
        await subirImagenProducto({
          productoId: guardado.id,
          file: item.file,
          textoAlternativo: payload.nombre,
          esPrincipal: !yaTienePrincipal && index === 0,
        })
      }
    } catch (e) {
      if (!esEdicion.value && guardado?.id) {
        // El producto ya existe: no se debe reintentar el alta (duplicaría la
        // publicación). Se continúa en edición para completar las fotos.
        ui.warning(
          'Producto creado sin todas las fotos',
          'Guardamos el producto, pero una foto no se pudo subir. Completa las fotografías en la edición.',
        )
        router.replace(`/vendedor/productos/${guardado.id}/editar`)
        return
      }
      throw e
    }

    ui.success(
      esEdicion.value ? 'Producto actualizado' : 'Producto creado',
      `${payload.nombre} quedó en el catálogo con sus fotografías.`,
    )
    router.push('/vendedor/productos')
  } catch (e) {
    errorForm.value = e.message
    ui.error('No se pudo guardar el producto', e.message)
  } finally {
    guardando.value = false
  }
}

function limpiarErrorPausa() {
  if (errores.value.motivo_pausa) {
    errores.value = { ...errores.value, motivo_pausa: undefined }
  }
}

function cancelar() {
  router.push('/vendedor/productos')
}
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <p class="text-sm">
          <CtButton variant="ghost" size="sm" @click="cancelar">
            <template #icon><CtIcon name="arrowLeft" :size="15" /></template>
            Volver al Inventario
          </CtButton>
        </p>
        <h1 class="page-head__title">{{ esEdicion ? 'Editar Producto' : 'Agregar Producto' }}</h1>
        <p class="page-head__subtitle">
          {{
            esEdicion
              ? 'Actualiza los datos de tu publicación, su precio, su stock y sus fotografías.'
              : 'Publica un producto de tu cosecha en el catálogo de CuTuCo.'
          }}
        </p>
      </div>
      <div class="page-head__actions">
        <CtBadge :tone="puedeOperar ? 'success' : 'warning'" dot>
          {{ puedeOperar ? 'Cuenta habilitada para vender' : 'Cuenta sin habilitación' }}
        </CtBadge>
        <CtButton variant="secondary" :disabled="guardando" @click="cancelar">Cancelar</CtButton>
        <CtButton :loading="guardando" :disabled="!puedeGuardar" @click="guardar">
          {{ esEdicion ? 'Guardar Cambios' : 'Crear Producto' }}
        </CtButton>
      </div>
    </header>

    <CtSpinner v-if="cargando" label="Cargando formulario" />

    <template v-else>
      <CtAlert v-if="motivoBloqueo" tone="warning" title="No puedes publicar productos">
        <p>{{ motivoBloqueo }}</p>
        <CtButton size="sm" variant="secondary" to="/vendedor/tienda">Ver mi perfil de tienda</CtButton>
      </CtAlert>

      <CtAlert v-if="eliminado" tone="danger" title="Producto eliminado">
        <p>
          Este producto fue eliminado por el administrador y ya no se puede editar ni reactivar.
          Consulta el motivo en el detalle del inventario.
        </p>
        <CtButton size="sm" variant="secondary" to="/vendedor/productos">Volver al inventario</CtButton>
      </CtAlert>

      <CtAlert
        v-if="justificacionVigente && !eliminado"
        tone="warning"
        compact
        :title="productoOriginal?.activo ? 'Justificación registrada' : 'Producto pausado'"
      >
        <p>{{ justificacionVigente }}</p>
      </CtAlert>

      <CtAlert v-if="errorForm" tone="danger" title="No se pudo guardar">
        <p>{{ errorForm }}</p>
      </CtAlert>

      <div class="form-grid">
        <!-- ============ Columna principal ============ -->
        <div class="stack">
          <CtCard title="Información General" subtitle="Cómo se verá el producto en el catálogo">
            <div class="stack">
              <CtInput
                v-model="form.nombre"
                label="Nombre del Producto"
                required
                :error="errores.nombre"
                placeholder="Tomate italiano de temporada"
                hint="Entre 3 y 180 caracteres"
              />

              <CtSelect
                v-model="form.categoria_principal_id"
                label="Categoría principal"
                required
                :error="errores.categoria_id"
                :options="opcionesCategoriaPrincipal"
                :disabled="!opcionesCategoriaPrincipal.length"
                placeholder="Selecciona una categoría"
                @change="cambiarCategoriaPrincipal"
              />

              <CtSelect
                v-model="form.subcategoria_id"
                label="Subcategoría (opcional)"
                :options="opcionesSubcategoria"
                :disabled="!form.categoria_principal_id || !opcionesSubcategoria.length"
                :clearable="Boolean(form.subcategoria_id)"
                :hint="
                  !form.categoria_principal_id
                    ? 'Selecciona primero una categoría principal.'
                    : opcionesSubcategoria.length
                      ? 'Puedes dejarla sin seleccionar.'
                      : 'Esta categoría no tiene subcategorías disponibles.'
                "
                placeholder="Sin subcategoría"
                @change="cambiarSubcategoria"
              />

              <CtAlert v-if="!opcionesCategoriaPrincipal.length" tone="warning" compact>
                <p>
                  No hay categorías disponibles para seleccionar. Sin categoría no es posible guardar el
                  producto.
                </p>
              </CtAlert>

              <CtTextarea
                v-model="form.descripcion"
                label="Descripción Detallada"
                required
                :error="errores.descripcion"
                :maxlength="1800"
                :rows="5"
                show-count
                placeholder="Origen, forma de cultivo, calibre y formato de la entrega"
              />
            </div>
          </CtCard>

          <CtCard title="Precio, Stock y Cosecha" subtitle="Datos comerciales de la publicación">
            <div class="stack">
              <div class="par">
                <CtInput
                  v-model="form.precio"
                  type="number"
                  label="Precio por Unidad (CLP)"
                  required
                  prefix="$"
                  :min="LIMITES_PRODUCTO.precioMin"
                  :max="LIMITES_PRODUCTO.precioMax"
                  step="1"
                  :error="errores.precio"
                  :hint="
                    form.precio
                      ? `${formatCLP(form.precio)} · máximo ${formatCLP(LIMITES_PRODUCTO.precioMax)}`
                      : `Monto entero entre ${formatCLP(LIMITES_PRODUCTO.precioMin)} y ${formatCLP(LIMITES_PRODUCTO.precioMax)}: Webpay cobra en CLP sin centavos`
                  "
                />
                <CtSelect
                  v-model="form.unidad_medida"
                  label="Unidad de Medida"
                  required
                  :error="errores.unidad_medida"
                  :options="opcionesUnidad"
                />
              </div>

              <div class="par">
                <CtInput
                  v-model="form.stock"
                  type="number"
                  label="Stock Disponible"
                  required
                  :min="LIMITES_PRODUCTO.stockMin"
                  :max="LIMITES_PRODUCTO.stockMax"
                  step="0.1"
                  :error="errores.stock"
                  :hint="`Se publica como ${form.stock === '' ? 0 : formatearCantidad(form.stock, form.unidad_medida)} ${unidades}. Máximo ${formatNumber(LIMITES_PRODUCTO.stockMax)} unidades; se permite hasta un decimal`"
                />
                <CtInput
                  v-model="form.fecha_cosecha"
                  type="date"
                  label="Fecha de Cosecha (opcional)"
                  :error="errores.fecha_cosecha"
                  :max="todayISO()"
                  hint="Ayuda al cliente a elegir lo más fresco"
                />
              </div>

              <div class="par">
                <CtInput
                  v-model="form.incremento_venta"
                  type="number"
                  label="Incremento de venta"
                  required
                  :min="pasoCampoCantidad"
                  :max="LIMITES_PRODUCTO.stockMax"
                  :step="pasoCampoCantidad"
                  :error="errores.incremento_venta"
                  :suffix="unidades"
                  :hint="`El cliente podrá aumentar su compra de ${formatearCantidad(form.incremento_venta || 0, form.unidad_medida)} en ${formatearCantidad(form.incremento_venta || 0, form.unidad_medida)} ${unidades}.`"
                />
                <CtInput
                  v-model="form.cantidad_minima_compra"
                  type="number"
                  label="Compra mínima"
                  required
                  :min="pasoCampoCantidad"
                  :max="LIMITES_PRODUCTO.stockMax"
                  :step="pasoCampoCantidad"
                  :error="errores.cantidad_minima_compra"
                  :suffix="unidades"
                  hint="Debe ser múltiplo del incremento y no superar el stock publicado."
                />
              </div>

              <CtAlert v-if="resumenReglasVenta" tone="info" compact>
                <p>{{ resumenReglasVenta }}</p>
              </CtAlert>

              <CtCheckbox
                v-if="esEdicion"
                v-model="form.activo"
                label="Publicación activa"
                description="Si la desmarcas, el producto queda pausado (baja lógica) y sale del catálogo."
              />

              <CtTextarea
                v-if="pausando"
                v-model="motivoPausa"
                label="Justificación de la pausa"
                hint="Obligatoria: entre 10 y 1000 caracteres. Queda registrada en el producto."
                :error="errores.motivo_pausa ?? motivoPausaError"
                :rows="3"
                :maxlength="MOTIVO_PRODUCTO_MAX"
                show-count
                required
                placeholder="Explica por qué pausas este producto"
                @update:model-value="limpiarErrorPausa"
              />

              <CtAlert v-if="reactivando" tone="info" compact>
                <p>
                  Al volver a publicar, el producto se reactiva y se limpia la justificación de la pausa
                  anterior.
                </p>
              </CtAlert>
            </div>
          </CtCard>

          <CtCard title="Fotografía del Producto" subtitle="Toma la foto con la cámara del dispositivo">
            <div class="stack">
              <ul v-if="imagenes.length" class="galeria">
                <li v-for="imagen in imagenes" :key="imagen.id" class="galeria__item">
                  <img :src="imagen.url" :alt="imagen.texto_alternativo || imagen.nombre_archivo" />
                  <CtBadge v-if="imagen.es_principal" tone="primary" size="sm">Portada</CtBadge>
                  <button
                    type="button"
                    class="galeria__remove"
                    aria-label="Quitar imagen"
                    @click="quitarImagen(imagen)"
                  >
                    ×
                  </button>
                </li>
              </ul>

              <CtFileUpload
                v-model="nuevasImagenes"
                capture="environment"
                :multiple="true"
                :max="3"
                required
                :error="errorImagen"
                label="Fotografía del producto"
                hint="Toma la foto con la cámara; JPG, PNG o WEBP de hasta 5 MB"
                empty-icon="camera"
                @error="(mensaje) => (errorImagen = mensaje)"
              />
              <p class="text-xs text-muted">
                Guarda el producto para cargar las fotografías y ver cómo se muestran en tu publicación.
              </p>
            </div>
          </CtCard>
        </div>

        <!-- ============ Columna lateral ============ -->
        <aside class="stack">
          <CtCard title="Tips para la foto" subtitle="Buenas prácticas del catálogo">
            <ul class="tips">
              <li>
                <strong>Luz natural, sin sombras duras</strong>
                <span>Toma la foto de día y con el producto limpio.</span>
              </li>
              <li>
                <strong>Encuadre cercano</strong>
                <span>El producto debe ocupar la mayor parte de la imagen.</span>
              </li>
              <li>
                <strong>Formato de venta</strong>
                <span>Fotografía la bandeja, caja o malla tal como la entregas.</span>
              </li>
              <li>
                <strong>Stock real</strong>
                <span>El cliente sólo puede comprar las unidades que publiques.</span>
              </li>
            </ul>
          </CtCard>

          <CtCard title="Métricas del producto" subtitle="Datos disponibles en CuTuCo">
            <dl class="metricas">
              <div>
                <dt>Días en catálogo</dt>
                <dd>{{ diasEnCatalogo === null ? '—' : formatNumber(diasEnCatalogo) }}</dd>
              </div>
              <div>
                <dt>Fotografías</dt>
                <dd>{{ imagenes.length + nuevasImagenes.length }}</dd>
              </div>
              <div>
                <dt>Stock a publicar</dt>
                <dd>{{ formatearCantidad(form.stock || 0, form.unidad_medida) }} {{ unidades }}</dd>
              </div>
              <div>
                <dt>Precio por unidad</dt>
                <dd>{{ formatCLP(form.precio || 0) }}</dd>
              </div>
              <div>
                <dt>Fecha de cosecha</dt>
                <dd>{{ form.fecha_cosecha ? formatDate(form.fecha_cosecha) : 'No informada' }}</dd>
              </div>
              <div>
                <dt>Última actualización</dt>
                <dd>
                  {{
                    productoOriginal?.actualizado_en
                      ? formatRelative(productoOriginal.actualizado_en)
                      : 'Sin publicar'
                  }}
                </dd>
              </div>
            </dl>

            <CtAlert tone="neutral" compact>
              <p>
                CuTuCo no registra historial de precios ni alertas de stock bajo: el
                precio y el stock los mantienes tú desde este formulario.
              </p>
            </CtAlert>
          </CtCard>
        </aside>
      </div>

      <!-- ============ Pie ============ -->
      <CtCard padding="sm">
        <div class="pie">
          <p class="text-sm text-muted">
            El guardado deja el producto en el catálogo con el estado que definiste. Las validaciones de
            este formulario respetan los límites del catálogo y la justificación exigida al pausar.
          </p>
          <div class="row">
            <CtButton variant="secondary" :disabled="guardando" @click="cancelar">Cancelar</CtButton>
            <CtButton :loading="guardando" :disabled="!puedeGuardar" @click="guardar">
              {{ esEdicion ? 'Actualizar Producto' : 'Crear Producto' }}
            </CtButton>
          </div>
        </div>
      </CtCard>
    </template>
  </div>
</template>

<style scoped>
.page-head__text,
.page-head__actions {
  min-width: 0;
}

.page-head__title,
.page-head__subtitle {
  overflow-wrap: anywhere;
}

.form-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 340px;
  gap: var(--ct-space-6);
  align-items: start;
}

@media (max-width: 1100px) {
  .form-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}

.par {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: var(--ct-space-4);
}

.galeria {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(96px, 1fr));
  gap: var(--ct-space-2);
  list-style: none;
  padding: 0;
  margin: 0;
}

.galeria__item {
  position: relative;
  aspect-ratio: 1;
  border-radius: var(--ct-radius-md);
  overflow: hidden;
  border: 1px solid var(--ct-border);
}

.galeria__item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.galeria__item :deep(.ct-badge) {
  position: absolute;
  left: 4px;
  bottom: 4px;
}

.galeria__remove {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  border: none;
  background: var(--ct-text);
  color: var(--ct-text-invert);
  font-size: 1rem;
  line-height: 1;
  display: grid;
  place-items: center;
}

.tips {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
}

.tips li {
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: var(--ct-fs-md);
}

.tips span {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.metricas {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: var(--ct-space-4);
  margin: 0 0 var(--ct-space-4);
}

.metricas dt {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.metricas dd {
  margin: 2px 0 0;
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-semibold);
}

.pie {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
  flex-wrap: wrap;
}
</style>

