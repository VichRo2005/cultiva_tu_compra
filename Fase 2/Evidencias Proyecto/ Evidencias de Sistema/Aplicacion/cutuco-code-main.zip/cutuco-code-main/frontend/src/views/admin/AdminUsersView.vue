<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { listarUsuarios, obtenerDetalle, toggleActivo, eliminar } from '@/services/adminUsuarios.js'
import { useAsync } from '@/composables/useAsync.js'
import { useAuthStore } from '@/stores/auth.js'
import { useUiStore } from '@/stores/ui.js'
import { formatDate, formatDateTime, formatPhone, formatScore } from '@/lib/format.js'
import { LABELS, STORAGE_BUCKETS } from '@/lib/constants.js'
import { storageUrl } from '@/lib/supabase.js'
import CtAlert from '@/components/base/CtAlert.vue'
import CtAvatar from '@/components/base/CtAvatar.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtPagination from '@/components/base/CtPagination.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtRatingStars from '@/components/base/CtRatingStars.vue'

const auth = useAuthStore()
const ui = useUiStore()
const texto = ref('')
const textoAplicado = ref('')
const rol = ref('')
const activo = ref('')
const page = ref(1)
const pageSize = ref(12)
const detalleAbierto = ref(false)
const confirmacion = ref({ abierto: false, accion: '', usuario: null })
const filtrosRol = [
  { value: '', label: 'Todos los roles' },
  { value: 'cliente', label: 'Cliente' },
  { value: 'postulante', label: 'Postulante a productor' },
  { value: 'vendedor', label: 'Vendedor' },
  { value: 'admin', label: 'Administrador' },
]
const filtrosActivo = [
  { value: '', label: 'Todos los estados' },
  { value: 'true', label: 'Activos' },
  { value: 'false', label: 'Desactivados' },
]
const columnas = [
  { key: 'usuario', label: 'Usuario' },
  { key: 'rol', label: 'Rol' },
  { key: 'estado', label: 'Estado' },
  { key: 'creado_en', label: 'Registro', format: formatDate },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

let revision = 0
let solicitud = null
let timer = null
let desmontado = false
// useAsync controla carga/error. Un único loader absorbe cambios de filtros
// mientras hay una consulta en vuelo, evitando que respuestas viejas ganen.
const {
  data: listado,
  loading,
  error,
  run,
} = useAsync(
  async () => {
    while (!desmontado) {
      const actual = revision
      let resultado
      try {
        resultado = await listarUsuarios({
          texto: textoAplicado.value,
          rol: rol.value,
          activo: activo.value === '' ? null : activo.value === 'true',
          page: page.value,
          pageSize: pageSize.value,
        })
      } catch (e) {
        if (actual !== revision) continue
        throw e
      }
      if (actual !== revision) continue
      const ultima = Math.max(1, Math.ceil(resultado.total / pageSize.value))
      if (page.value > ultima) {
        page.value = ultima
        continue
      }
      return resultado
    }
    return null
  },
  { immediate: false },
)

function cargar() {
  revision += 1
  if (!solicitud)
    solicitud = run().finally(() => {
      solicitud = null
    })
  return solicitud
}
const usuarios = computed(() => (error.value ? [] : (listado.value?.items ?? [])))
const total = computed(() => (error.value ? 0 : (listado.value?.total ?? 0)))
const hayFiltros = computed(() => Boolean(texto.value || rol.value || activo.value))
watch(texto, () => {
  clearTimeout(timer)
  timer = setTimeout(() => {
    textoAplicado.value = texto.value.trim()
    page.value = 1
    cargar()
  }, 350)
})
watch([rol, activo, pageSize], () => {
  page.value = 1
  cargar()
})
watch(page, cargar)

function limpiarFiltros() {
  clearTimeout(timer)
  texto.value = ''
  textoAplicado.value = ''
  rol.value = ''
  activo.value = ''
  page.value = 1
  cargar()
}

const detalleCarga = useAsync(
  async (id) => {
    const usuario = await obtenerDetalle(id)
    if (!usuario) throw new Error('El perfil no existe o no tienes permisos para verlo.')
    return usuario
  },
  { immediate: false },
)
const { data: detalle, loading: cargandoDetalle, error: errorDetalle } = detalleCarga
const detalleId = ref(null)
async function verDetalle(usuario) {
  detalleId.value = usuario.id
  detalle.value = null
  detalleAbierto.value = true
  await detalleCarga.run(usuario.id)
}
function editable(usuario) {
  return (
    usuario &&
    usuario.rol === 'cliente' &&
    !usuario.protegido &&
    !usuario.eliminado &&
    usuario.id !== auth.user?.id
  )
}

function etiquetaRol(usuario) {
  return LABELS.rol[usuario?.rolMostrado ?? usuario?.rol] ?? usuario?.rol
}

function urlImagen(ruta, bucket, actualizadoEn = '') {
  const base = ruta ? storageUrl(ruta, { bucket }) : null
  if (!base || base.startsWith('data:') || base.startsWith('offline:')) return base
  return `${base}${base.includes('?') ? '&' : '?'}v=${encodeURIComponent(actualizadoEn || ruta)}`
}

function fotoPerfil(usuario) {
  const productor = usuario?.productor
  if (productor?.foto_perfil_storage_path) {
    return urlImagen(
      productor.foto_perfil_storage_path,
      STORAGE_BUCKETS.avataresVendedor,
      productor.actualizado_en,
    )
  }
  return urlImagen(
    usuario?.foto_perfil_storage_path,
    STORAGE_BUCKETS.avataresCliente,
    usuario?.actualizado_en,
  )
}

function portadaProductor(usuario) {
  const productor = usuario?.productor
  return urlImagen(
    productor?.portada_storage_path,
    STORAGE_BUCKETS.portadasTienda,
    productor?.actualizado_en,
  )
}

function tieneValoraciones(productor) {
  return Number(productor?.cantidad_evaluaciones ?? 0) > 0
}

const mutacion = useAsync(
  async (accion) => {
    const { usuario } = accion
    const resultado =
      accion.accion === 'eliminar'
        ? await eliminar(usuario.id)
        : await toggleActivo(usuario.id, usuario.activo)
    if (detalle.value?.id === usuario.id) {
      detalle.value = { ...detalle.value, ...resultado }
    }
    ui.success('Usuario actualizado', 'La operación se completó correctamente.')
    await cargar()
    return true
  },
  { immediate: false },
)
const { loading: guardando, error: errorMutacion } = mutacion

function pedirAccion(usuario, accion) {
  if (!editable(usuario) || guardando.value) return
  errorMutacion.value = null
  confirmacion.value = { abierto: true, usuario, accion }
}
async function confirmar() {
  if (guardando.value) return
  const accion = { ...confirmacion.value }
  const ok = await mutacion.run(accion)
  if (ok) confirmacion.value.abierto = false
}
const tituloConfirmacion = computed(() => {
  if (confirmacion.value.accion === 'eliminar') return 'Eliminar permanentemente'
  return confirmacion.value.usuario?.activo ? 'Desactivar cuenta' : 'Reactivar cuenta'
})
const mensajeConfirmacion = computed(() => {
  const { usuario, accion } = confirmacion.value
  const nombre = usuario?.nombreCompleto ?? ''
  if (accion === 'eliminar')
    return `La cuenta de ${nombre} quedará eliminada permanentemente. Esta acción no se puede revertir ni permite reactivar la cuenta. Su historial se conservará.`
  return usuario?.activo
    ? `${nombre} quedará desactivado. Su historial se conservará.`
    : `${nombre} volverá a tener una cuenta activa.`
})

onMounted(cargar)
onBeforeUnmount(() => {
  desmontado = true
  clearTimeout(timer)
})
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div>
        <h1 class="page-head__title">Gestión de usuarios</h1>
        <p class="page-head__subtitle">
          Consulta perfiles y administra el estado de las cuentas de clientes.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="loading || guardando" @click="cargar"
          >Actualizar</CtButton
        >
        <CtButton to="/admin/moderacion">Aprobación de vendedores</CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar los usuarios" role="alert">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" :disabled="loading" @click="cargar"
        >Reintentar</CtButton
      >
    </CtAlert>

    <CtCard padding="md">
      <div class="grid grid--tight">
        <div class="col-6">
          <CtSearchInput
            v-model="texto"
            label="Buscar usuarios"
            placeholder="Buscar por nombre, apellido o teléfono…"
            aria-label="Buscar usuarios"
          />
        </div>
        <CtSelect v-model="rol" class="col-3" label="Rol" :options="filtrosRol" />
        <CtSelect
          v-model="activo"
          class="col-3"
          label="Estado de cuenta"
          :options="filtrosActivo"
        />
      </div>
      <div class="row row--between row--wrap admin-usuarios__resumen">
        <p class="text-sm text-soft" role="status" aria-live="polite">
          {{ total }} {{ total === 1 ? 'resultado' : 'resultados' }} · {{ usuarios.length }} en esta
          página
        </p>
        <CtButton variant="ghost" :disabled="!hayFiltros" @click="limpiarFiltros"
          >Limpiar filtros</CtButton
        >
      </div>
      <CtTable
        :columns="columnas"
        :rows="usuarios"
        :loading="loading"
        dense
        empty-icon="users"
        empty-title="Sin usuarios"
        empty-message="No hay perfiles que coincidan con los filtros."
      >
        <template #empty-action>
          <CtButton v-if="hayFiltros" size="sm" variant="secondary" @click="limpiarFiltros"
            >Limpiar filtros</CtButton
          >
        </template>
        <template #cell-usuario="{ row }">
          <div class="row">
            <CtAvatar :name="row.nombreCompleto" :src="fotoPerfil(row)" :size="36" />
            <div>
              <p class="font-semibold">{{ row.nombreCompleto }}</p>
              <p class="text-xs text-muted">{{ formatPhone(row.telefono) }}</p>
            </div>
          </div>
        </template>
        <template #cell-rol="{ row }">
          <CtBadge :tone="row.esPostulante ? 'warning' : 'info'">{{ etiquetaRol(row) }}</CtBadge>
          <p v-if="row.esPostulante" class="text-xs text-muted">
            {{ LABELS.postulacion[row.postulacion?.estado] ?? 'En proceso' }}
          </p>
          <p v-if="row.protegido" class="text-xs text-muted">Cuenta protegida</p>
        </template>
        <template #cell-estado="{ row }">
          <CtBadge :tone="row.eliminado ? 'danger' : row.activo ? 'success' : 'neutral'" dot>{{
            row.eliminado ? 'Eliminado permanentemente' : row.activo ? 'Activo' : 'Desactivado'
          }}</CtBadge>
          <p v-if="row.bloqueado" class="text-xs text-muted">
            Bloqueo de acceso hasta {{ formatDateTime(row.bloqueado_hasta) }}
          </p>
        </template>
        <template #cell-acciones="{ row }">
          <div class="row row--end row--wrap">
            <CtButton
              size="sm"
              variant="secondary"
              :disabled="guardando || cargandoDetalle"
              :aria-label="`Ver detalle de ${row.nombreCompleto}`"
              @click="verDetalle(row)"
              >Ver detalle</CtButton
            >
            <CtButton
              size="sm"
              variant="ghost"
              :disabled="!editable(row) || guardando"
              :aria-label="`${row.eliminado ? 'Cuenta eliminada de' : row.activo ? 'Desactivar a' : 'Reactivar a'} ${row.nombreCompleto}`"
              @click="pedirAccion(row, 'activo')"
              >{{
                row.eliminado ? 'Cuenta eliminada' : row.activo ? 'Desactivar' : 'Reactivar'
              }}</CtButton
            >
          </div>
        </template>
      </CtTable>
      <CtPagination
        :page="page"
        :total="total"
        :page-size="pageSize"
        label="usuarios"
        @update:page="page = $event"
        @update:page-size="pageSize = $event"
      />
    </CtCard>

    <CtModal
      v-model="detalleAbierto"
      title="Detalle de usuario"
      size="lg"
      :close-on-backdrop="!guardando"
    >
      <CtSpinner v-if="cargandoDetalle" label="Cargando detalle…" />
      <CtAlert
        v-else-if="errorDetalle"
        tone="danger"
        title="No se pudo cargar el detalle"
        role="alert"
      >
        <p>{{ errorDetalle }}</p>
        <CtButton size="sm" variant="secondary" @click="verDetalle({ id: detalleId })"
          >Reintentar</CtButton
        >
      </CtAlert>
      <div v-else-if="detalle" class="stack stack--lg">
        <section class="admin-usuarios__imagenes" aria-label="Imágenes para moderación">
          <figure class="admin-usuarios__imagen">
            <img
              v-if="fotoPerfil(detalle)"
              :src="fotoPerfil(detalle)"
              :alt="`Foto de perfil de ${detalle.nombreCompleto}`"
            />
            <CtAvatar v-else :name="detalle.nombreCompleto" :size="144" />
            <figcaption>Foto de perfil</figcaption>
          </figure>
          <figure v-if="portadaProductor(detalle)" class="admin-usuarios__imagen admin-usuarios__imagen--portada">
            <img
              :src="portadaProductor(detalle)"
              :alt="`Imagen de portada de ${detalle.productor?.nombre_comercial ?? detalle.nombreCompleto}`"
            />
            <figcaption>Portada de la tienda</figcaption>
          </figure>
        </section>
        <section class="stack stack--sm" aria-label="Datos del perfil">
          <h2 class="section-title">{{ detalle.nombreCompleto }}</h2>
          <dl class="grid grid--tight">
            <div class="col-6">
              <dt class="text-sm text-muted">Teléfono</dt>
              <dd>{{ formatPhone(detalle.telefono) }}</dd>
            </div>
            <div class="col-6">
              <dt class="text-sm text-muted">Rol actual</dt>
              <dd>{{ etiquetaRol(detalle) }}</dd>
            </div>
            <div class="col-6">
              <dt class="text-sm text-muted">Estado</dt>
              <dd>
                {{
                  detalle.eliminado
                    ? 'Eliminado permanentemente'
                    : detalle.activo
                      ? 'Activo'
                      : 'Desactivado'
                }}
              </dd>
            </div>
            <div class="col-6">
              <dt class="text-sm text-muted">Fecha de registro</dt>
              <dd>{{ formatDateTime(detalle.creado_en) }}</dd>
            </div>
            <div class="col-12">
              <dt class="text-sm text-muted">Identificador</dt>
              <dd class="mono admin-usuarios__id">{{ detalle.id }}</dd>
            </div>
          </dl>
          <CtAlert v-if="detalle.protegido" tone="info" title="Cuenta protegida"
            >Esta cuenta no admite cambios de estado ni eliminación desde este panel.</CtAlert
          >
          <CtAlert v-if="detalle.esPostulante" tone="warning" title="Postulante a productor">
            Estado de postulación:
            {{ LABELS.postulacion[detalle.postulacion?.estado] ?? 'En proceso' }}.
            <template v-if="detalle.postulacion?.intento">
              Intento {{ detalle.postulacion.intento }} de
              {{ 3 + Number(detalle.postulacion.intentos_extra ?? 0) }}.
            </template>
          </CtAlert>
          <CtAlert v-else-if="detalle.id === auth.user?.id" tone="info"
            >Tu propia cuenta no se puede desactivar ni eliminar desde este panel.</CtAlert
          >
          <CtAlert v-if="detalle.eliminado" tone="danger" title="Cuenta eliminada permanentemente">
            Eliminada el {{ formatDateTime(detalle.eliminado_en) }}. No se puede reactivar.
          </CtAlert>
        </section>
        <section
          v-if="detalle.rol === 'vendedor'"
          class="stack stack--sm"
          aria-label="Datos del productor"
        >
          <h2 class="section-title">Productor</h2>
          <template v-if="detalle.productor">
            <p class="font-semibold">{{ detalle.productor.nombre_comercial }}</p>
            <p v-if="detalle.productor.descripcion" class="text-soft">
              {{ detalle.productor.descripcion }}
            </p>
            <p class="text-sm">
              {{ detalle.productor.activo ? 'Tienda activa' : 'Tienda inactiva' }} · Aprobado el
              {{ formatDate(detalle.productor.aprobado_en) }}
            </p>
            <div v-if="tieneValoraciones(detalle.productor)" class="row text-sm text-soft">
              <CtRatingStars
                :model-value="Number(detalle.productor.puntaje_reputacion)"
                :size="18"
                show-value
              />
              <span>
                {{ formatScore(detalle.productor.puntaje_reputacion) }} ·
                {{ detalle.productor.cantidad_evaluaciones }} evaluaciones
              </span>
            </div>
            <p v-else class="text-sm text-soft">Sin valoraciones</p>
          </template>
          <CtEmptyState
            v-else
            icon="leaf"
            title="Sin productor asociado"
            message="Este perfil no tiene un productor disponible para consultar."
          />
        </section>
        <section class="stack stack--sm" aria-label="Administración del usuario">
          <h2 class="section-title">Administrar cuenta</h2>
          <CtAlert v-if="detalle.rol !== 'cliente'" tone="info">
            <p>
              Activar, desactivar y eliminar desde este panel está disponible solo para clientes.
            </p>
            <template v-if="detalle.rol === 'vendedor'">
              <p>Las suspensiones y los baneos de vendedores se gestionan desde Sanciones.</p>
              <CtButton href="/admin/sanciones" variant="secondary" size="sm"
                >Ir a Sanciones</CtButton
              >
            </template>
          </CtAlert>
          <div class="row row--wrap">
            <CtButton
              variant="secondary"
              :disabled="!editable(detalle) || guardando"
              @click="pedirAccion(detalle, 'activo')"
              >{{
                detalle.eliminado
                  ? 'Cuenta eliminada'
                  : detalle.activo
                    ? 'Desactivar cuenta'
                    : 'Reactivar cuenta'
              }}</CtButton
            >
            <CtButton
              variant="danger"
              :disabled="!editable(detalle) || guardando"
              @click="pedirAccion(detalle, 'eliminar')"
              >Eliminar permanentemente</CtButton
            >
          </div>
          <p v-if="detalle.rol === 'cliente'" class="text-sm text-muted">
            Desactivar permite reactivar la cuenta. Eliminar es permanente y conserva el historial.
          </p>
        </section>
      </div>
      <template #footer
        ><CtButton variant="secondary" :disabled="guardando" @click="detalleAbierto = false"
          >Cerrar</CtButton
        ></template
      >
    </CtModal>

    <CtConfirmDialog
      v-model="confirmacion.abierto"
      :title="tituloConfirmacion"
      :message="mensajeConfirmacion"
      :confirm-label="tituloConfirmacion"
      :tone="
        confirmacion.accion === 'eliminar' ||
        (confirmacion.accion === 'activo' && confirmacion.usuario?.activo)
          ? 'danger'
          : 'primary'
      "
      :loading="guardando"
      @confirm="confirmar"
    >
      <template #details>
        <CtAlert
          v-if="errorMutacion"
          tone="danger"
          title="No se pudo actualizar el usuario"
          role="alert"
          >{{ errorMutacion }}</CtAlert
        >
      </template>
    </CtConfirmDialog>
  </div>
</template>

<style scoped>
.admin-usuarios__resumen {
  margin-block: var(--ct-space-4);
}
.admin-usuarios__id {
  overflow-wrap: anywhere;
}
.admin-usuarios__imagenes {
  display: grid;
  grid-template-columns: minmax(144px, 220px) minmax(0, 1fr);
  gap: var(--ct-space-5);
  align-items: start;
}
.admin-usuarios__imagen {
  display: grid;
  gap: var(--ct-space-2);
  margin: 0;
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-sm);
}
.admin-usuarios__imagen img {
  width: 100%;
  min-height: 144px;
  max-height: 280px;
  object-fit: cover;
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
}
.admin-usuarios__imagen--portada img {
  min-height: 180px;
}
@media (max-width: 640px) {
  .admin-usuarios__imagenes {
    grid-template-columns: 1fr;
  }
}
</style>
