<script setup>
/** CuTuCo — Mapa de ubicación aproximada (SVG, sin dependencia externa). */
import { computed } from 'vue'

const props = defineProps({
  comuna: { type: String, default: null },
  region: { type: String, default: null },
  productor: { type: String, default: null },
  zoom: { type: Number, default: 1 },
  size: { type: String, default: 'md' }, // sm | md | lg
  radiusKm: { type: Number, default: 8 },
})

const label = computed(() => {
  if (props.comuna && props.region) return `${props.productor ? `${props.productor} · ` : ''}${props.comuna}, ${props.region}`
  return props.comuna || props.region || 'Ubicación aproximada'
})

/** Radio del halo del marcador en función del zoom. */
const halo = computed(() => 34 + props.zoom * 12)
</script>

<template>
  <figure class="ct-map" :class="`ct-map--${size}`">
    <svg viewBox="0 0 400 260" role="img" :aria-label="`Ubicación aproximada: ${label}`">
      <defs>
        <linearGradient id="ctMapBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#eef4ec" />
          <stop offset="100%" stop-color="#ffffff" />
        </linearGradient>
        <pattern id="ctMapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M40 0H0v40" fill="none" stroke="#dfe7dd" stroke-width="1" />
        </pattern>
      </defs>

      <rect width="400" height="260" fill="url(#ctMapBg)" />
      <rect width="400" height="260" fill="url(#ctMapGrid)" />

      <!-- Red de caminos -->
      <path d="M0 150 L400 110" stroke="#d8e2d6" stroke-width="7" fill="none" />
      <path d="M90 0 L140 260" stroke="#d8e2d6" stroke-width="5" fill="none" />
      <path d="M300 0 L250 260" stroke="#d8e2d6" stroke-width="6" fill="none" />
      <path d="M0 210 L400 190" stroke="#e6ece4" stroke-width="4" fill="none" />

      <!-- Parcelas agrícolas -->
      <g opacity="0.65">
        <rect x="28" y="34" width="54" height="34" rx="6" fill="#c8e6c9" />
        <rect x="322" y="30" width="52" height="30" rx="6" fill="#c8e6c9" />
        <rect x="30" y="228" width="48" height="24" rx="6" fill="#c8e6c9" />
        <rect x="330" y="222" width="46" height="28" rx="6" fill="#c8e6c9" />
      </g>

      <!-- Radio de cobertura -->
      <circle :cx="200" :cy="130" :r="halo" fill="#4CAF50" opacity="0.12" />
      <circle :cx="200" :cy="130" :r="halo" fill="none" stroke="#4CAF50" stroke-width="1.5" stroke-dasharray="6 5" opacity="0.5" />

      <!-- Marcador -->
      <g transform="translate(200,130)">
        <circle r="18" fill="#2E7D32" opacity="0.18" />
        <path
          d="M0-26c-8.5 0-15 6.6-15 14.8C-15-1.6 0 14 0 14s15-15.6 15-25.2C15-19.4 8.5-26 0-26z"
          fill="#2E7D32"
        />
        <circle cy="-11" r="5.4" fill="#ffffff" />
      </g>
    </svg>

    <figcaption class="ct-map__caption">
      <strong>{{ comuna || region || 'Zona de entrega' }}</strong>
      <span class="text-muted">
        Ubicación aproximada por privacidad · radio de entrega ≈ {{ radiusKm }} km
      </span>
    </figcaption>
  </figure>
</template>

<style scoped>
.ct-map {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-lg);
  overflow: hidden;
  background: var(--ct-surface);
}

.ct-map svg {
  width: 100%;
  height: auto;
  display: block;
}

.ct-map--sm svg {
  max-height: 140px;
}

.ct-map--lg svg {
  max-height: 320px;
}

.ct-map__caption {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--ct-space-3) var(--ct-space-4);
  border-top: 1px solid var(--ct-border);
  font-size: var(--ct-fs-sm);
}
</style>
