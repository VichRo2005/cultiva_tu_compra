import { mensajeSeguro } from '@/services/errores'
import { getClient } from '@/lib/supabase'
import { adminResult as unwrap } from '@/services/adminErrores'
export async function listPalabrasProhibidas({ soloActivas = false } = {}) {
  const client = getClient()
  let query = client.from('palabras_prohibidas').select('*')
  if (soloActivas) query = query.eq('activo', true)
  const { data, error } = await query.order('palabra', { ascending: true })
  if (error) unwrap({ error })
  return data ?? []
}

/** Límites del esquema: varchar(120), sin comodines y única en minúsculas. */
export const MAX_CARACTERES_PALABRA = 120

/**
 * Normaliza y valida la palabra antes de tocar la BD: recorta espacios,
 * unifica en minúsculas (la comparación y el UNIQUE de la BD son
 * case-insensitive) y rechaza comodines, longitudes y duplicados con un
 * mensaje accionable en vez del error crudo de PostgreSQL.
 */
export function normalizarPalabra(palabra) {
  const texto = String(palabra ?? '').trim().toLocaleLowerCase('es')
  if (texto.length < 2) throw new Error('Ingresa al menos 2 caracteres.')
  if (texto.length > MAX_CARACTERES_PALABRA)
    throw new Error(`La palabra no puede exceder ${MAX_CARACTERES_PALABRA} caracteres.`)
  if (texto.includes('%') || texto.includes('_'))
    throw new Error('La palabra no puede contener los comodines % ni _.')
  return mensajeSeguro(texto)
}

export async function crearPalabraProhibida(palabra) {
  const texto = normalizarPalabra(palabra)
  const client = getClient()
  return unwrap(
    await client
      .from('palabras_prohibidas')
      .insert({ palabra: texto, activo: true })
      .select()
      .single(),
    'No se pudo agregar la palabra',
  )
}

export async function actualizarPalabraProhibida(id, patch) {
  const actual = unwrap(
    await getClient().from('palabras_prohibidas').select('*').eq('id', id).single(),
  )
  if (!actual.activo && !(patch.activo === true && Object.keys(patch).length === 1)) {
    throw new Error('Una palabra desactivada solo se puede reactivar.')
  }
  if (Object.keys(patch).some((key) => !['palabra', 'activo'].includes(key)))
    throw new Error('Cambio no permitido.')
  if ('palabra' in patch) {
    patch = { ...patch, palabra: normalizarPalabra(patch.palabra) }
  }
  const client = getClient()
  return unwrap(
    await client.from('palabras_prohibidas').update(patch).eq('id', id).select().single(),
    'No se pudo actualizar la palabra',
  )
}

/**
 * Revisa un texto contra la blacklist usando la función del esquema, que aplica
 * el operador LIKE case-insensitive (RF-004).
 */
export async function revisarTexto(texto) {
  const client = getClient()
  const { data, error } = await client.rpc('contiene_palabra_prohibida', { p_texto: texto })
  if (error) unwrap({ error })
  return Boolean(data)
}

/**
 * Productos cuyo nombre o descripción contiene una palabra prohibida.
 * La comparación se hace en el cliente con la lista activa porque PostgREST no
 * expone el operador LIKE sobre un array de términos.
 */
export async function listCoincidenciasModeradas() {
  const client = getClient()
  const [palabras, productosRes] = await Promise.all([
    listPalabrasProhibidas(),
    client.from('productos').select('id, nombre, descripcion, activo, productor_id'),
  ])
  const productos = unwrap(productosRes)
  const productores = unwrap(await client.from('productores').select('id, nombre_comercial'))
  const productorMap = new Map((productores ?? []).map((p) => [p.id, p]))
  const terminos = (palabras ?? []).filter((p) => p.activo).map((p) => p.palabra.toLowerCase())

  const coincidencias = []
  for (const producto of productos ?? []) {
    const texto = `${producto.nombre ?? ''} ${producto.descripcion ?? ''}`.toLowerCase()
    const encontradas = terminos.filter((t) => texto.includes(t))
    if (encontradas.length) {
      coincidencias.push({
        ...producto,
        productor: productorMap.get(producto.productor_id) ?? null,
        palabras: encontradas,
      })
    }
  }
  return { palabras: palabras ?? [], coincidencias }
}

/* ---------------------------------------------------------------- */
/* Sanciones (RF-026)                                                  */
/* ---------------------------------------------------------------- */

export function filtrarPalabras(rows, { texto = '', activo = '' } = {}) {
  return rows.filter(
    (p) =>
      (activo === '' || p.activo === (activo === 'true')) &&
      p.palabra.toLocaleLowerCase('es').includes(texto.trim().toLocaleLowerCase('es')),
  )
}