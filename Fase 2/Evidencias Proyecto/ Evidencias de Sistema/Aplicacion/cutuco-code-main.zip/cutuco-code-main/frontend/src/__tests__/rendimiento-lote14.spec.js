/**
 * CuTuCo — Lote 14 (Rendimiento y experiencia), verificación de accesibilidad/UX.
 *
 * CK-0326/0328/0332: matriz de navegadores según DC-09 (Chromium/Chrome/Edge;
 * E2E ejecutado en Edge 5/5; Firefox fuera del MVP). CK-0333: foco visible con
 * teclado (focus-visible + trampa de foco en CtModal). CK-0334: errores por campo
 * con aria-invalid/aria-describedby. CK-0335: zoom 200% (unidades relativas).
 * CK-0336: doble envío visible (loading/aria-busy) + idempotencia en BD.
 * CK-0337: conexión lenta (timeout + modo demo/offline). CK-0338: recarga SPA con
 * hosting sirviendo la ruta (vercel.json) y guard de autorización.
 */
import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'

const src = (p) => readFileSync(`src/${p}`, 'utf8')
const root = (p) => readFileSync(p, 'utf8')
const doc = (p) => readFileSync(`../docs/${p}`, 'utf8')
const mig = (p) => readFileSync(`../supabase/migrations/${p}`, 'utf8')

describe('CK-0326 / CK-0328 / CK-0332 · matriz de navegadores (DC-09)', () => {
  it('DC-09 define Chromium/Chrome/Edge con E2E ejecutado y Firefox fuera del MVP', () => {
    const dc = doc('decisiones-resueltas.md')
    expect(dc).toMatch(/DC-09 \| Matriz de aceptación: Chromium\/Chrome\/Edge/)
    expect(dc).toMatch(/Firefox queda fuera del MVP de pruebas/)
    expect(dc).toContain('work/e2e-run.log')
  })

  it('el E2E ejecutado dejó reportes JSON trazables', () => {
    const reporte = readFileSync('../docs/audits/evidence/real-ui-report.json', 'utf8')
    expect(reporte).toContain('CUTUCO-E2E-')
  })
})

describe('CK-0333 · navegación con teclado', () => {
  it('foco visible global y en componentes interactivos', () => {
    expect(src('styles/base.css')).toMatch(/:focus-visible/)
    expect(src('components/base/CtButton.vue')).toMatch(/\.ct-btn:focus-visible/)
    expect(src('components/base/CtInput.vue')).toBeTruthy()
    expect(src('components/base/CtCheckbox.vue')).toMatch(/focus-visible/)
    expect(src('components/base/CtToggle.vue')).toMatch(/focus-visible/)
  })

  it('el modal atrapa el foco y bloquea el fondo (teclado alcanzable)', () => {
    const modal = src('components/base/CtModal.vue')
    expect(modal).toContain('[tabindex]:not([tabindex="-1"])') // trampa de foco
    expect(modal).toContain('tabindex="-1"')
  })
})

describe('CK-0334 · errores identificados por campo', () => {
  it('CtInput y CtSelect enlazan el error con aria-invalid y aria-describedby (no solo color)', () => {
    for (const comp of ['components/base/CtInput.vue', 'components/base/CtSelect.vue']) {
      const c = src(comp)
      expect(c).toContain(':aria-invalid="Boolean(error) || undefined"')
      expect(c).toContain(':aria-describedby="descritoPor"')
    }
    const audio = src('__tests__/audit-regressions.spec.js')
    expect(audio).toContain('aria-describedby')
  })

  it('el registro muestra el error junto al campo y conserva la entrada válida', () => {
    const v = src('views/auth/RegisterView.vue')
    expect(v).toMatch(/@blur="validarCampo/)
    expect(v).toContain(':error="errores.')
  })
})

describe('CK-0335 · zoom 200% y contraste', () => {
  it('viewport configurado y estilos en unidades relativas', () => {
    expect(root('index.html')).toContain('width=device-width, initial-scale=1.0')
    const base = src('styles/base.css')
    expect(base).toMatch(/rem/)
    expect(base).not.toMatch(/user-scalable=no/)
  })
})

describe('CK-0336 · doble envío visible e idempotente', () => {
  it('CtButton muestra progreso y bloquea el botón durante la petición', () => {
    const b = src('components/base/CtButton.vue')
    expect(b).toContain(':aria-busy="loading || undefined"')
    expect(b).toContain('ct-btn__spinner')
    expect(b).toContain('props.disabled || props.loading') // isDisabled bloquea el clic
    expect(b).toContain('disabled: isDisabled.value')
    expect(b).toMatch(/if \(isDisabled\.value\) \{\s*event\.preventDefault\(\)/)
  })

  it('el servidor conserva idempotencia: unique (token_ws, codigo_comercio, buy_order) en pagos', () => {
    const m = mig('20261010010000_webpay_mall_postulaciones.sql')
    expect(m).toContain('unique (token_ws, codigo_comercio, buy_order)')
    const conc = readFileSync('../backend/tests/integration/test_webpay_concurrency.py', 'utf8')
    expect(conc).toBeTruthy()
  })
})

describe('CK-0337 · conexión lenta o caída', () => {
  it('una caída no suplanta la sesión ni activa modo demo automático', () => {
    const s = src('lib/supabase.js')
    expect(s).not.toContain('supabaseResponde')
    expect(s).toContain('forzarDemo')
    const off = src('__tests__/modo-offline.spec.js')
    expect(off).toContain('activa el modo demo sólo cuando se solicita para pruebas')
  })
})

describe('CK-0338 · enlaces directos y recarga de la SPA', () => {
  it('el hosting sirve index.html en cualquier ruta (SPA fallback)', () => {
    const v = JSON.parse(root('vercel.json'))
    expect(v.rewrites).toEqual([{ source: '/(.*)', destination: '/index.html' }])
  })

  it('el router exige sesión en rutas protegidas tras la recarga', () => {
    const r = src('router/index.js')
    expect(r).toContain('router.beforeEach')
    expect(r).toMatch(/to\.meta\.requiresAuth && !auth\.isAuthenticated/)
    expect(r).toContain("name: 'login'")
  })
})
