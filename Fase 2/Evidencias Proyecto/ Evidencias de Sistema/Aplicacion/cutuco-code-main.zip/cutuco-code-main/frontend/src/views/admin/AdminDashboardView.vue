<script setup>
/**
 * CuTuCo — Dashboard administrativo (RF-011).
 *
 * El ERS redujo este panel a los pendientes que el administrador debe resolver:
 * aprobación de postulaciones de vendedores y sanciones vigentes, más los datos
 * de operación que los acompañan. Con Webpay Mall ya no hay payouts ni custodia:
 * Transbank dispersa el pago al comercio del productor y el panel muestra los
 * cobros autorizados (suma de `listPagos`) como referencia informativa.
 *
 * NOTA DE MIGRACIÓN (alcance anterior, eliminado): las tarjetas de custodia y
 * "pagos por aprobar" salieron con la migración Webpay Mall; se conservan los
 * bloques visuales reutilizables con los datos de `getPendientesAdmin()`.
 */
import { computed, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtChart from '@/components/base/CtChart.vue'
import CtEmptyState from '@/components/base/CtEmptyState.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtMoneyInfo from '@/components/base/CtMoneyInfo.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTabs from '@/components/base/CtTabs.vue'
import { formatCLP, formatDateTime, formatNumber } from '@/lib/format'
import { TIPO_SANCION } from '@/lib/constants'
import { getPendientesAdmin } from '@/services/admin'
import { listPagos } from '@/services/payments'
import { listServiciosAdmin } from '@/services/servicio'

const loading = ref(true)
const error = ref(null)
const datos = ref(null)
/** Comprobantes autorizados leídos de `pagos` (tolerante: si falla, se ocultan los KPI). */
const pagos = ref(null)
const servicios = ref([])
const diasGrafico = ref(7)
const opcionesGrafico = [
  { value: 7, label: '7 días' },
  { value: 30, label: '30 días' },
]

const serviciosPendientes = computed(
  () =>
    servicios.value.filter((s) => ['pendiente', 'pendiente_revision', 'vencido'].includes(s.estado))
      .length,
)
const serviciosVencidos = computed(
  () => servicios.value.filter((s) => s.estado === 'vencido').length,
)

const pendientes = computed(() => datos.value?.pendientes ?? { productores: 0, sanciones: 0 })
const operacion = computed(
  () =>
    datos.value?.operacion ?? {
      pedidos: 0,
      entregados: 0,
      enCurso: 0,
      comisiones: 0,
      liquidable: 0,
      ventas: 0,
    },
)

const totalPendientes = computed(() => pendientes.value.productores + pendientes.value.sanciones)

const totalCobrado = computed(() => {
  if (!Array.isArray(pagos.value)) return null
  return (
    Math.round(
      pagos.value.reduce(
        (acc, p) => acc + Number(p.monto ?? 0) + Number(p.monto_fee_descontado ?? 0),
        0,
      ) * 100,
    ) / 100
  )
})

const comisionCobrada = computed(() => {
  if (!Array.isArray(pagos.value)) return null
  return (
    Math.round(pagos.value.reduce((acc, p) => acc + Number(p.monto_fee_descontado ?? 0), 0) * 100) /
    100
  )
})

/** Neto de comprobantes Mall: la misma fuente de los dos KPI financieros. */
const netoDispersado = computed(() => {
  if (!Array.isArray(pagos.value)) return null
  return Math.round(pagos.value.reduce((acc, p) => acc + Number(p.monto ?? 0), 0) * 100) / 100
})

const formatoDiaChile = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' })
const etiquetaDiaChile = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: 'short',
  timeZone: 'America/Santiago',
})

/**
 * Serie diaria de los comprobantes Webpay Mall. El apilado siempre cumple
 * cobrado = neto a comercios + comisión CuTuCo, igual que los KPI superiores.
 */
const serieCobros = computed(() => {
  const indice = new Map()
  const serie = []

  for (let i = diasGrafico.value - 1; i >= 0; i -= 1) {
    const fecha = new Date()
    fecha.setHours(0, 0, 0, 0)
    fecha.setDate(fecha.getDate() - i)
    const clave = formatoDiaChile.format(fecha)
    const fila = { clave, etiqueta: etiquetaDiaChile.format(fecha), neto: 0, comision: 0 }
    indice.set(clave, fila)
    serie.push(fila)
  }

  for (const pago of pagos.value ?? []) {
    const fecha = new Date(pago.creado_en)
    if (Number.isNaN(fecha.getTime())) continue
    const fila = indice.get(formatoDiaChile.format(fecha))
    if (!fila) continue
    fila.neto += Number(pago.monto ?? 0)
    fila.comision += Number(pago.monto_fee_descontado ?? 0)
  }

  return serie
})

const graficoCobros = computed(() => ({
  labels: serieCobros.value.map((fila) => fila.etiqueta),
  datasets: [
    { label: 'Neto a comercios', data: serieCobros.value.map((fila) => Math.round(fila.neto)) },
    { label: 'Comisión CuTuCo', data: serieCobros.value.map((fila) => Math.round(fila.comision)) },
  ],
}))

/** Aprobaciones de vendedor por resolver (RF-004 y RF-021). */
const postulaciones = computed(() => datos.value?.postulaciones ?? [])
/** Sanciones vigentes (RF-026). */
const sanciones = computed(() => datos.value?.sanciones ?? [])

/** Línea de tiempo con los pendientes reales, con lo más reciente primero. */
const actividad = computed(() => {
  const eventos = []

  for (const p of postulaciones.value) {
    eventos.push({
      id: `postulacion-${p.id}`,
      fecha: p.creado_en,
      titulo: `Vendedor por aprobar: ${p.nombre_comercial_solicitado}`,
      detalle: p.region ? `Región ${p.region.nombre}` : 'Sin región registrada',
      icono: 'shieldCheck',
      to: '/admin/moderacion',
    })
  }

  for (const s of sanciones.value) {
    eventos.push({
      id: `sancion-${s.id}`,
      fecha: s.inicio_en,
      titulo: `Sanción ${s.tipo === TIPO_SANCION.SUSPENSION ? 'suspensión' : 'amonestación'} a ${s.productor?.nombre_comercial ?? 'vendedor'}`,
      detalle: s.fin_en ? `Vigente hasta ${formatDateTime(s.fin_en)}` : 'Sin fecha de término',
      icono: 'alert',
      to: '/admin/sanciones',
    })
  }

  return eventos.sort((a, b) => new Date(b.fecha ?? 0) - new Date(a.fecha ?? 0)).slice(0, 8)
})

async function cargar() {
  loading.value = true
  error.value = null
  try {
    datos.value = await getPendientesAdmin()
    try {
      pagos.value = await listPagos()
    } catch {
      pagos.value = null
    }
    servicios.value = await listServiciosAdmin()
  } catch (e) {
    error.value = e.message
    datos.value = null
  } finally {
    loading.value = false
  }
}

cargar()
</script>

<template>
  <div class="container page panel-page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Panel de Administración</h1>
        <p class="page-head__subtitle">
          Postulaciones de vendedores y sanciones vigentes: los pendientes de CuTuCo en un solo
          lugar. Los pagos los dispersa Transbank vía Webpay Mall.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :loading="loading" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudo cargar el panel">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-if="loading && !datos" label="Cargando pendientes…" />

    <template v-if="datos">
      <div class="grid-kpi panel-kpi">
        <CtStatCard
          label="Postulaciones pendientes"
          :value="formatNumber(pendientes.productores)"
          icon="shieldCheck"
          tone="warning"
          hint="Revisa los antecedentes antes de activar la cuenta"
          to="/admin/moderacion"
        />
        <CtStatCard
          label="Sanciones"
          :value="formatNumber(pendientes.sanciones)"
          icon="alert"
          tone="danger"
          hint="Amonestaciones, suspensiones, bans y apelaciones vigentes"
          to="/admin/sanciones"
        />
        <CtStatCard
          v-if="totalCobrado !== null"
          label="Total cobrado (Webpay Mall)"
          :value="formatCLP(totalCobrado)"
          icon="scale"
          tone="accent"
          hint="Cobros autorizados por Transbank; la autorización no confirma el abono bancario"
          calculation="Suma el neto entregado a cada vendedor y el cargo de CuTuCo de todos los comprobantes autorizados por Webpay Mall. En las compras nuevas equivale a productos y despacho netos más IVA de 19%; los pedidos anteriores mantienen el total registrado al pagarse."
          to="/admin/pagos"
        />
        <CtStatCard
          v-if="comisionCobrada !== null"
          label="Comisión CuTuCo (5 %)"
          :value="formatCLP(comisionCobrada)"
          icon="wallet"
          tone="info"
          hint="Comisión de CuTuCo incluida en cada transacción del Mall"
          calculation="Suma los cargos registrados por Webpay Mall para CuTuCo. La comisión corresponde al 5% del subtotal de productos: no se calcula sobre el IVA ni el despacho y no se agrega un cobro extra al cliente."
        />
        <CtStatCard
          label="Servicio de vendedores"
          :value="formatNumber(serviciosPendientes)"
          icon="store"
          :tone="serviciosVencidos ? 'danger' : 'success'"
          :hint="
            serviciosVencidos
              ? `${serviciosVencidos} vencido(s) / suspendido(s)`
              : 'Cuotas pendientes o en revisión'
          "
          to="/admin/servicios"
        />
      </div>

      <CtAlert v-if="!totalPendientes" tone="success" compact title="Sin pendientes">
        <p>No hay postulaciones ni sanciones esperando tu revisión.</p>
      </CtAlert>

      <div class="grid grid--tight panel-grid">
        <div class="col-7">
          <CtCard
            title="Pendientes por resolver"
            subtitle="Ordenados del más reciente al más antiguo"
          >
            <CtEmptyState
              v-if="!actividad.length"
              compact
              icon="check"
              title="Todo al día"
              message="No hay postulaciones ni sanciones pendientes de revisión."
            />
            <ol v-else class="linea">
              <li v-for="evento in actividad" :key="evento.id" class="linea__item">
                <span class="linea__icono" aria-hidden="true">
                  <CtIcon :name="evento.icono" :size="15" />
                </span>
                <div class="linea__texto">
                  <p class="linea__titulo">{{ evento.titulo }}</p>
                  <p class="linea__detalle">{{ evento.detalle }}</p>
                  <p class="linea__fecha">{{ formatDateTime(evento.fecha) }}</p>
                </div>
                <CtButton size="sm" variant="ghost" :to="evento.to">Revisar</CtButton>
              </li>
            </ol>
          </CtCard>
        </div>

        <div class="col-5">
          <CtCard
            title="Operación"
            subtitle="Cobros autorizados y estado actual del marketplace"
          >
            <template #actions>
              <CtTabs v-model="diasGrafico" :tabs="opcionesGrafico" variant="pills" />
            </template>

            <template v-if="pagos !== null">
              <CtChart
                type="bar"
                :labels="graficoCobros.labels"
                :datasets="graficoCobros.datasets"
                :height="250"
                currency
                stacked
                y-title="CLP"
              />

              <div class="operacion__montos">
                <article class="operacion__monto">
                  <span>Total cobrado (Webpay Mall)</span>
                  <strong>{{ formatCLP(totalCobrado) }}</strong>
                  <CtMoneyInfo title="Origen de este total">
                    <p>
                      Suma cada comprobante autorizado: el neto que recibe el comercio más el cargo
                      de CuTuCo. Es exactamente el mismo total del indicador superior.
                    </p>
                  </CtMoneyInfo>
                </article>
                <article class="operacion__monto">
                  <span>Neto a comercios</span>
                  <strong>{{ formatCLP(netoDispersado) }}</strong>
                  <CtMoneyInfo title="Origen de este neto">
                    <p>
                      Suma el campo neto de cada comprobante Webpay Mall. Transbank lo dispersa al
                      comercio de cada vendedor; el valor debe conciliarse con los abonos bancarios.
                    </p>
                  </CtMoneyInfo>
                </article>
                <article class="operacion__monto">
                  <span>Comisión CuTuCo (5 %)</span>
                  <strong>{{ formatCLP(comisionCobrada) }}</strong>
                  <CtMoneyInfo title="Origen de esta comisión">
                    <p>
                      Suma los cargos de CuTuCo en Webpay Mall. Cada uno se calcula al 5% sobre los
                      productos, sin IVA ni despacho; junto al neto forma el total cobrado.
                    </p>
                  </CtMoneyInfo>
                </article>
              </div>
            </template>

            <CtAlert v-else tone="warning" compact title="Sin datos de Webpay Mall">
              <p>
                No se pudieron leer los comprobantes autorizados. Los contadores operativos siguen
                disponibles, pero el desglose monetario se oculta para no mostrar cifras incongruentes.
              </p>
            </CtAlert>

            <dl class="salud operacion__estado">
              <div class="salud__fila">
                <dt>Pedidos registrados</dt>
                <dd>{{ formatNumber(operacion.pedidos) }}</dd>
              </div>
              <div class="salud__fila">
                <dt>Pedidos en curso</dt>
                <dd>{{ formatNumber(operacion.enCurso) }}</dd>
              </div>
              <div class="salud__fila">
                <dt>Pedidos entregados</dt>
                <dd>{{ formatNumber(operacion.entregados) }}</dd>
              </div>
            </dl>
          </CtCard>
        </div>
      </div>

      <div class="grid grid--tight panel-grid">
        <div class="col-7">
          <CtCard title="Postulaciones pendientes" subtitle="Solicitudes en revisión">
            <template #actions>
              <CtButton size="sm" variant="ghost" to="/admin/moderacion">
                <template #icon><CtIcon name="arrowRight" :size="14" /></template>
                Ver todo
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!postulaciones.length"
              compact
              icon="shieldCheck"
              title="Nada por revisar"
              message="No hay solicitudes de vendedor pendientes de aprobación."
            />

            <ul v-else class="lista">
              <li v-for="p in postulaciones.slice(0, 5)" :key="p.id" class="item">
                <div class="item__texto">
                  <p class="item__titulo">{{ p.nombre_comercial_solicitado }}</p>
                  <p class="item__detalle">
                    {{
                      [p.perfil?.nombre, p.perfil?.apellido].filter(Boolean).join(' ') ||
                      'Sin perfil asociado'
                    }}
                    · {{ p.region?.nombre ?? 'Sin región' }} · {{ formatDateTime(p.creado_en) }}
                  </p>
                </div>
                <CtButton size="sm" to="/admin/moderacion">Revisar</CtButton>
              </li>
            </ul>
          </CtCard>
        </div>

        <div class="col-5">
          <CtCard title="Sanciones vigentes" subtitle="">
            <template #actions>
              <CtButton size="sm" variant="ghost" to="/admin/sanciones">
                <template #icon><CtIcon name="arrowRight" :size="14" /></template>
                Ver todo
              </CtButton>
            </template>

            <CtEmptyState
              v-if="!sanciones.length"
              compact
              icon="shield"
              title="Sin sanciones activas"
              message="No hay vendedores con sanción vigente."
            />

            <ul v-else class="lista">
              <li v-for="s in sanciones.slice(0, 5)" :key="s.id" class="item">
                <div class="item__texto">
                  <p class="item__titulo">{{ s.productor?.nombre_comercial ?? 'Vendedor' }}</p>
                  <p class="item__detalle">
                    {{ s.tipo === TIPO_SANCION.SUSPENSION ? 'Suspensión' : 'Amonestación' }}
                    · {{ formatDateTime(s.inicio_en) }}
                  </p>
                </div>
                <CtButton size="sm" to="/admin/sanciones">Revisar</CtButton>
              </li>
            </ul>
          </CtCard>

        </div>
      </div>
    </template>
  </div>
</template>

<style scoped>
.panel-page {
  gap: var(--ct-space-6);
}

.panel-kpi,
.panel-grid {
  gap: var(--ct-space-4);
}

.panel-grid {
  align-items: start;
}

.panel-grid > [class*='col-'] {
  min-width: 0;
}

.lista {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface);
}

.item__texto {
  min-width: 0;
}

.item__titulo {
  font-weight: var(--ct-fw-semibold);
}

.item__detalle {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.salud {
  display: flex;
  flex-direction: column;
}

.salud__fila {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-3);
  padding: var(--ct-space-2) 0;
  border-bottom: 1px solid var(--ct-border);
}

.salud__fila:last-child {
  border-bottom: none;
}

.salud__fila dt {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.salud__fila dd {
  font-size: var(--ct-fs-md);
  font-weight: var(--ct-fw-semibold);
  text-align: right;
}

.linea {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.linea__item {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
  padding-bottom: var(--ct-space-3);
  border-bottom: 1px solid var(--ct-border);
}

.linea__item:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.linea__icono {
  width: 30px;
  height: 30px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border-radius: var(--ct-radius-pill);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.linea__texto {
  flex: 1;
  min-width: 0;
}

.linea__titulo {
  font-weight: var(--ct-fw-semibold);
  font-size: var(--ct-fs-md);
}

.linea__detalle,
.linea__fecha {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.operacion__montos {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-3);
  margin-top: var(--ct-space-4);
}

.operacion__monto:first-child {
  grid-column: 1 / -1;
}

.operacion__monto {
  min-width: 0;
  padding: var(--ct-space-3);
  border: 1px solid var(--ct-border);
  border-radius: var(--ct-radius-md);
  background: var(--ct-surface-alt);
}

.operacion__monto > span {
  display: block;
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-soft);
}

.operacion__monto > strong {
  display: block;
  margin-top: var(--ct-space-1);
  font-variant-numeric: tabular-nums;
  font-size: var(--ct-fs-lg);
}

.operacion__monto :deep(.money-info) {
  border-top: 1px solid var(--ct-border);
  padding-top: var(--ct-space-2);
}

.operacion__estado {
  margin-top: var(--ct-space-4);
}

@media (max-width: 720px) {
  .operacion__montos {
    grid-template-columns: 1fr;
  }
}
</style>
