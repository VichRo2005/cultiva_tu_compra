/**
 * CuTuCo — Pedidos del vendedor.
 *
 * Cubre las reglas puras y los servicios modificados para HAL-VEN-018/020/021/
 * 028/029/030/032:
 *   - estado actual único y filtros combinados;
 *   - hitos compartidos y preparación confirmada por el vendedor;
 *   - límite de 1.000 caracteres de la justificación;
 *   - cancelación con motivo y traducción de errores de BD;
 *   - código de entrega no expuesto al vendedor y validación por RPC.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'

const sdk = vi.hoisted(() => ({
  client: null,
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn(),
  tryGetClient: vi.fn(),
}))

vi.mock('@/lib/supabase', () => ({
  getClient: () => sdk.client,
  tryGetClient: () => sdk.client,
  apiFetch: sdk.apiFetch,
  storageUrl: sdk.storageUrl,
}))

vi.mock('@/services/session', () => ({
  currentUserId: vi.fn(async () => 'perfil-1'),
  unwrap: ({ data, error }, fallback) => {
    if (error) throw new Error(error.message || fallback)
    return data
  },
}))

import { ESTADO_ENVIO, ESTADO_PEDIDO } from '@/lib/constants'
import {
  LIMITE_JUSTIFICACION,
  OPCIONES_ESTADO_ACTUAL,
  construirJustificacion,
  esCodigoEntregaValido,
  esEstadoTerminal,
  estadoActualPedido,
  hitosPedido,
  identificadorClienteReclamo,
  motivoCancelacion,
  nombreClienteReclamo,
  normalizarCodigoEntrega,
  pasoActualPedido,
  pedidoCoincideBusqueda,
  pedidoCoincideEstado,
  traducirErrorCancelacion,
  traducirErrorCodigoEntrega,
  traducirErrorJustificacion,
  validarJustificacion,
} from '@/lib/orders'
import {
  cancelarPedido,
  columnasEnvio,
  getPedidoDetalle,
  iniciarPago,
  marcarEnvioFallido,
  obtenerCodigoEntregaCliente,
  verificarCodigoEntrega,
  verificarCodigoEntregaVendedor,
} from '@/services/orders'

beforeEach(() => {
  sdk.client = null
  sdk.getClient.mockReset()
  sdk.apiFetch.mockReset()
})

describe('inicio de pago · consentimiento de monto', () => {
  it('envía el monto aceptado separado de las cantidades y sin precios manipulables', async () => {
    await iniciarPago({
      direccionId: 'direccion-1', montoEsperado: 8000,
      items: [{ productoId: 'producto-1', cantidad: 1.5, precio: 1 }],
    })
    expect(sdk.apiFetch).toHaveBeenCalledWith('/api/webpay/iniciar', {
      method: 'POST',
      body: {
        direccion_id: 'direccion-1', monto_esperado: 8000,
        items: [{ producto_id: 'producto-1', cantidad: 1.5 }],
      },
    })
  })
})

/** Cliente Supabase mínimo para leer el detalle de un pedido. */
function clienteDetalle({ envio, rpc = vi.fn(), errorTabla = null }) {
  const selects = []
  const pedido = {
    id: 'pedido-1',
    cliente_id: 'cliente-1',
    productor_id: 'productor-1',
    comuna_entrega_id: 'comuna-1',
    estado: ESTADO_PEDIDO.EN_PREPARACION,
    creado_en: '2026-10-20T09:00:00Z',
  }
  const filas = {
    pedidos: pedido,
    pagos: null,
    envios: envio,
    productores: null,
    comunas: null,
    evaluaciones_reputacion: null,
    perfiles: null,
  }
  const listas = { detalles_pedido: [] }

  function query(table) {
    const q = {
      select: vi.fn((columnas) => {
        selects.push({ table, columnas })
        return q
      }),
      eq: vi.fn(() => q),
      in: vi.fn(() => q),
      order: vi.fn(() => q),
      maybeSingle: vi.fn(async () => ({ data: filas[table] ?? null, error: table === errorTabla ? { message: 'fallo de red' } : null })),
      single: vi.fn(async () => ({ data: filas[table] ?? null, error: table === errorTabla ? { message: 'fallo de red' } : null })),
      then: (resolve, reject) =>
        Promise.resolve({ data: listas[table] ?? [], error: table === errorTabla ? { message: 'fallo de red' } : null }).then(resolve, reject),
    }
    return q
  }

  const client = {
    from: vi.fn((table) => query(table)),
    rpc,
    auth: { getUser: vi.fn(async () => ({ data: { user: { id: 'cliente-1' } } })) },
  }
  return { client, selects, rpc }
}

/* ------------------------------------------------------------------ */
/* Estado actual único y filtros (HAL-VEN-020 y HAL-VEN-021)           */
/* ------------------------------------------------------------------ */

describe('estado actual único', () => {
  it('el envío en tránsito manda sobre el pedido en preparación', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.EN_TRANSITO },
      pago: { estado: 'autorizado' },
    }
    expect(estadoActualPedido(pedido)).toBe(ESTADO_ENVIO.EN_TRANSITO)
  })

  it('un pedido entregado no se duplica como en preparación', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.COMPLETADO,
      envio: { estado: ESTADO_ENVIO.ENTREGADO, entregado_en: '2026-10-20T12:00:00Z' },
    }
    expect(estadoActualPedido(pedido)).toBe(ESTADO_PEDIDO.COMPLETADO)
    expect(estadoActualPedido({ estado: 'en_preparacion', envio: null })).toBe(
      ESTADO_PEDIDO.EN_PREPARACION,
    )
  })

  it('no muestra «En preparación» hasta que el vendedor confirma preparado_en', () => {
    const sinPreparar = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.PREPARACION, preparado_en: null },
      pago: { estado: 'autorizado' },
    }
    const preparado = {
      ...sinPreparar,
      envio: { ...sinPreparar.envio, preparado_en: '2026-10-20T10:00:00Z' },
    }
    expect(estadoActualPedido(sinPreparar)).toBe(ESTADO_PEDIDO.PAGADO)
    expect(estadoActualPedido(preparado)).toBe(ESTADO_PEDIDO.EN_PREPARACION)
  })

  it('cancelado gana sobre entrega fallida y conserva su propio significado', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.CANCELADO,
      envio: { estado: ESTADO_ENVIO.FALLIDO, motivo_fallo: 'No estaba en el domicilio' },
    }
    expect(estadoActualPedido(pedido)).toBe(ESTADO_PEDIDO.CANCELADO)
    expect(estadoActualPedido({ estado: ESTADO_PEDIDO.RECLAMADO, envio: { estado: 'entregado' } })).toBe(
      ESTADO_PEDIDO.RECLAMADO,
    )
    expect(
      estadoActualPedido({ estado: ESTADO_PEDIDO.EN_PREPARACION, envio: { estado: 'cancelado' } }),
    ).toBe(ESTADO_PEDIDO.CANCELADO)
  })

  it('el filtro incluye En tránsito y Entrega fallida', () => {
    const valores = OPCIONES_ESTADO_ACTUAL.map((o) => o.value)
    expect(valores).toContain(ESTADO_ENVIO.EN_TRANSITO)
    expect(valores).toContain(ESTADO_ENVIO.FALLIDO)

    const enTransito = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.EN_TRANSITO },
    }
    expect(pedidoCoincideEstado(enTransito, ESTADO_ENVIO.EN_TRANSITO)).toBe(true)
    expect(pedidoCoincideEstado(enTransito, ESTADO_PEDIDO.CANCELADO)).toBe(false)
    expect(pedidoCoincideEstado(enTransito, '')).toBe(true)
  })

  it('un pedido en tránsito o con entrega fallida sigue en la pestaña Pendientes', () => {
    const enTransito = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.EN_TRANSITO },
    }
    const fallido = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.FALLIDO, preparado_en: '2026-10-20T10:00:00Z' },
    }
    const cancelado = { estado: ESTADO_PEDIDO.CANCELADO, envio: null }
    expect(esEstadoTerminal(enTransito)).toBe(false)
    expect(esEstadoTerminal(fallido)).toBe(false)
    expect(esEstadoTerminal(cancelado)).toBe(true)
    expect(esEstadoTerminal({ estado: ESTADO_PEDIDO.COMPLETADO })).toBe(true)
  })

  it('combina búsqueda y filtro sin mezclar resultados', () => {
    const pedido = {
      codigo_pedido: 'CUTU-20261020-AB12CD',
      nombre_destinatario: 'Ana Pérez',
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      envio: { estado: ESTADO_ENVIO.EN_TRANSITO },
      comuna_entrega_id: 'comuna-1',
    }
    expect(pedidoCoincideBusqueda(pedido, 'ana')).toBe(true)
    expect(pedidoCoincideBusqueda(pedido, 'ab12')).toBe(true)
    expect(pedidoCoincideBusqueda(pedido, 'temuco', { comuna: 'Temuco' })).toBe(true)
    expect(pedidoCoincideBusqueda(pedido, 'otra cosa')).toBe(false)
    expect(
      pedidoCoincideEstado(pedido, ESTADO_ENVIO.EN_TRANSITO) &&
        pedidoCoincideBusqueda(pedido, 'ana'),
    ).toBe(true)
  })
})

/* ------------------------------------------------------------------ */
/* Hitos compartidos y preparación (HAL-VEN-030 y HAL-CLI-010)         */
/* ------------------------------------------------------------------ */

describe('hitos compartidos', () => {
  it('usa cuatro hitos base, en orden y sin repetir el estado actual', () => {
    const hitos = hitosPedido({
      estado: ESTADO_PEDIDO.PAGADO,
      pago: { creado_en: '2026-10-20T09:00:00Z' },
      envio: { estado: ESTADO_ENVIO.PREPARACION, preparado_en: null },
    })
    expect(hitos.map((h) => h.key)).toEqual([
      ESTADO_PEDIDO.PAGADO,
      ESTADO_ENVIO.PREPARACION,
      ESTADO_ENVIO.EN_TRANSITO,
      ESTADO_ENVIO.ENTREGADO,
    ])
    expect(hitos[0].estado).toBe('actual')
    expect(hitos[1].estado).toBe('pendiente')
    expect(hitos[1].meta).toBeNull()
    expect(pasoActualPedido({ estado: 'pagado', envio: { estado: 'preparacion' } })).toBe(0)
  })

  it('la preparación sólo se cierra con preparado_en y muestra su fecha', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      pago: { creado_en: '2026-10-20T09:00:00Z' },
      envio: { estado: ESTADO_ENVIO.PREPARACION, preparado_en: '2026-10-20T10:30:00Z' },
    }
    const hitos = hitosPedido(pedido)
    expect(pasoActualPedido(pedido)).toBe(1)
    expect(hitos[1].estado).toBe('actual')
    expect(hitos[1].meta).toBe('2026-10-20T10:30:00Z')
  })

  it('un hito pendiente no aparece como realizado y la entrega falla en tránsito', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.EN_PREPARACION,
      pago: { creado_en: '2026-10-20T09:00:00Z' },
      envio: {
        estado: ESTADO_ENVIO.FALLIDO,
        preparado_en: '2026-10-20T10:30:00Z',
        despachado_en: '2026-10-20T11:00:00Z',
        motivo_fallo: 'Dirección no encontrada',
      },
    }
    const hitos = hitosPedido(pedido)
    expect(estadoActualPedido(pedido)).toBe(ESTADO_ENVIO.FALLIDO)
    expect(hitos[2].failed).toBe(true)
    expect(hitos[2].estado).toBe('fallido')
    expect(hitos[3].estado).toBe('pendiente')
    expect(hitos[3].meta).toBeNull()
  })

  it('un pedido cancelado no se muestra como entrega fallida', () => {
    const pedido = {
      estado: ESTADO_PEDIDO.CANCELADO,
      envio: { estado: ESTADO_ENVIO.FALLIDO, despachado_en: '2026-10-20T11:00:00Z' },
    }
    const hitos = hitosPedido(pedido)
    expect(hitos.some((h) => h.failed)).toBe(false)
    expect(pasoActualPedido(pedido)).toBe(2)
  })

  it('un pedido cancelado antes de pagar no muestra el pago como realizado', () => {
    const hitos = hitosPedido({ estado: ESTADO_PEDIDO.CANCELADO, pago: null, envio: null })
    expect(hitos[0].meta).toBeNull()
    expect(hitos[0].estado).toBe('actual')
    expect(hitos[1].estado).toBe('pendiente')
  })
})

/* ------------------------------------------------------------------ */
/* Justificación de entrega fallida (HAL-VEN-028)                      */
/* ------------------------------------------------------------------ */

describe('justificación de entrega fallida', () => {
  it('construye el texto sin separadores vacíos', () => {
    expect(construirJustificacion({ motivo: 'Otro motivo', detalle: '' })).toBe('Otro motivo')
    expect(construirJustificacion({ motivo: 'Otro motivo', detalle: '  ' })).toBe('Otro motivo')
    expect(construirJustificacion({ motivo: 'Dañado', detalle: 'Caja rota' })).toBe(
      'Dañado: Caja rota',
    )
  })

  it('acepta 999 y 1.000 caracteres y rechaza 1.001', () => {
    expect(LIMITE_JUSTIFICACION).toBe(1000)
    const de999 = 'a'.repeat(999)
    const de1000 = 'a'.repeat(1000)
    const de1001 = 'a'.repeat(1001)
    expect(validarJustificacion(de999)).toEqual({ valida: true, longitud: 999, error: null })
    expect(validarJustificacion(de1000)).toEqual({ valida: true, longitud: 1000, error: null })
    const rechazo = validarJustificacion(de1001)
    expect(rechazo.valida).toBe(false)
    expect(rechazo.longitud).toBe(1001)
    expect(rechazo.error).toMatch(/1\.000/)
  })

  it('traduce el error varchar(1000) de PostgreSQL', () => {
    expect(
      traducirErrorJustificacion('value too long for type character varying(1000)'),
    ).toMatch(/1\.000 caracteres/)
    expect(traducirErrorJustificacion('Un envio fallido requiere motivo_fallo')).toMatch(
      /Debes indicar el motivo/,
    )
  })

  it('marcarEnvioFallido no llama a la BD con 1.001 caracteres', async () => {
    const update = vi.fn()
    sdk.client = {
      from: vi.fn(() => ({ update })),
    }
    await expect(marcarEnvioFallido('envio-1', 'x'.repeat(1001))).rejects.toThrow(/1\.000/)
    expect(sdk.client.from).not.toHaveBeenCalled()
  })

  it('marcarEnvioFallido envía 1.000 caracteres y traduce el error de la BD', async () => {
    const query = {
      update: vi.fn(() => query),
      eq: vi.fn(() => query),
      select: vi.fn(() => query),
      single: vi.fn(async () => ({
        data: { id: 'envio-1', estado: ESTADO_ENVIO.FALLIDO },
        error: null,
      })),
    }
    sdk.client = { from: vi.fn(() => query) }
    const texto = 'x'.repeat(1000)
    await marcarEnvioFallido('envio-1', texto)
    expect(query.update).toHaveBeenCalledWith({
      estado: ESTADO_ENVIO.FALLIDO,
      motivo_fallo: texto,
    })

    query.single.mockResolvedValueOnce({
      data: null,
      error: { message: 'value too long for type character varying(1000)' },
    })
    await expect(marcarEnvioFallido('envio-2', 'y'.repeat(1000))).rejects.toThrow(
      /1\.000 caracteres/,
    )
  })
})

/* ------------------------------------------------------------------ */
/* Cancelación con motivo (HAL-VEN-029)                                */
/* ------------------------------------------------------------------ */

describe('cancelación del pedido', () => {
  it('llama a la RPC del vendedor con pedido y motivo', async () => {
    const rpc = vi.fn(async () => ({
      data: { id: 'pedido-1', estado: ESTADO_PEDIDO.CANCELADO, motivo_cancelacion: 'Sin stock' },
      error: null,
    }))
    sdk.client = { rpc, from: vi.fn() }
    const resultado = await cancelarPedido('pedido-1', '  Sin stock  ')
    expect(rpc).toHaveBeenCalledWith('cancelar_pedido_vendedor', {
      p_pedido_id: 'pedido-1',
      p_motivo: 'Sin stock',
    })
    expect(resultado.estado).toBe(ESTADO_PEDIDO.CANCELADO)
    expect(resultado.motivo_cancelacion).toBe('Sin stock')
    expect(resultado.motivo_registrado).toBe(true)
  })

  it('si la RPC no existe, cae al update directo guardando el motivo', async () => {
    const query = {
      update: vi.fn(() => query),
      eq: vi.fn(() => query),
      select: vi.fn(() => query),
      single: vi.fn(async () => ({
        data: {
          id: 'pedido-1',
          estado: ESTADO_PEDIDO.CANCELADO,
          motivo_cancelacion: 'Dirección errada',
        },
        error: null,
      })),
    }
    sdk.client = {
      rpc: vi.fn(async () => ({
        data: null,
        error: { message: 'Could not find the function public.cancelar_pedido_vendedor' },
      })),
      from: vi.fn(() => query),
    }
    const resultado = await cancelarPedido('pedido-1', 'Dirección errada')
    expect(query.update).toHaveBeenCalledWith(
      expect.objectContaining({
        estado: ESTADO_PEDIDO.CANCELADO,
        motivo_cancelacion: 'Dirección errada',
      }),
    )
    expect(resultado.motivo_registrado).toBe(true)
  })

  it('si falta la columna motivo_cancelacion, cancela igual y lo informa', async () => {
    let intento = 0
    const query = {
      update: vi.fn(() => query),
      eq: vi.fn(() => query),
      select: vi.fn(() => query),
      single: vi.fn(async () => {
        intento += 1
        if (intento === 1) {
          return {
            data: null,
            error: {
              code: 'PGRST204',
              message: "Could not find the 'motivo_cancelacion' column of 'pedidos'",
            },
          }
        }
        return { data: { id: 'pedido-1' }, error: null }
      }),
    }
    sdk.client = {
      rpc: vi.fn(async () => ({ data: null, error: { message: 'function does not exist' } })),
      from: vi.fn(() => query),
    }
    const resultado = await cancelarPedido('pedido-1', 'Motivo')
    expect(query.update).toHaveBeenCalledTimes(2)
    expect(resultado.motivo_registrado).toBe(false)
    expect(resultado.motivo_cancelacion).toBe('Motivo')
  })

  it('traduce RLS y transiciones inválidas', () => {
    expect(traducirErrorCancelacion('permission denied for table pedidos')).toMatch(
      /no está habilitada en el servidor/,
    )
    expect(traducirErrorCancelacion('Transicion de pedido no permitida: completado -> cancelado')).toMatch(
      /ya no se puede cancelar/,
    )
  })

  it('motivoCancelacion nunca usa motivo_fallo y respeta el motivo del envío', () => {
    expect(motivoCancelacion({ envio: { motivo_fallo: 'Entrega fallida' } })).toBeNull()
    expect(motivoCancelacion({ motivo_cancelacion: '  Sin stock  ' })).toBe('Sin stock')
    expect(motivoCancelacion({ envio: { motivo_cancelacion: 'Sin stock' } })).toBe('Sin stock')
  })
})

/* ------------------------------------------------------------------ */
/* Código de entrega (HAL-VEN-018)                                     */
/* ------------------------------------------------------------------ */

describe('código de entrega', () => {
  it('normaliza y valida el formato de seis dígitos', () => {
    expect(normalizarCodigoEntrega(' 482731 ')).toBe('482731')
    expect(esCodigoEntregaValido('482731')).toBe(true)
    expect(esCodigoEntregaValido('48273')).toBe(false)
    expect(esCodigoEntregaValido('NO-ES-CODIGO')).toBe(false)
  })

  it('la proyección de envíos nunca pide codigo_verificacion', () => {
    const columnas = columnasEnvio()
    expect(columnas).not.toContain('codigo_verificacion')
    expect(columnas).toContain('preparado_en')
    expect(columnas).toContain('codigo_verificado_en')
  })

  it('el vendedor recibe el detalle sin código y sin llamar a la RPC', async () => {
    const rpc = vi.fn()
    const { client, selects } = clienteDetalle({
      envio: {
        id: 'envio-1',
        pedido_id: 'pedido-1',
        repartidor_id: 'repartidor-1',
        estado: ESTADO_ENVIO.PREPARACION,
        preparado_en: null,
        codigo_verificado_en: null,
      },
      rpc,
    })
    sdk.client = client

    const detalle = await getPedidoDetalle('pedido-1', { incluirCodigo: false })
    const selectEnvio = selects.find((s) => s.table === 'envios')
    expect(selectEnvio.columnas).not.toContain('codigo_verificacion')
    expect(rpc).not.toHaveBeenCalled()
    expect(detalle.envio.codigo_verificacion).toBeUndefined()
  })

  it('el cliente recibe el código sólo por la RPC obtener_codigo_entrega', async () => {
    const rpc = vi.fn(async (name) =>
      name === 'obtener_codigo_entrega'
        ? { data: '482731', error: null }
        : { data: null, error: { message: 'RPC inesperada' } },
    )
    const { client, selects } = clienteDetalle({
      envio: {
        id: 'envio-1',
        pedido_id: 'pedido-1',
        repartidor_id: 'repartidor-1',
        estado: ESTADO_ENVIO.EN_TRANSITO,
        preparado_en: '2026-10-20T10:00:00Z',
        despachado_en: '2026-10-20T11:00:00Z',
        codigo_verificado_en: null,
      },
      rpc,
    })
    sdk.client = client

    const detalle = await getPedidoDetalle('pedido-1')
    const selectEnvio = selects.find((s) => s.table === 'envios')
    expect(selectEnvio.columnas).not.toContain('codigo_verificacion')
    expect(rpc).toHaveBeenCalledWith('obtener_codigo_entrega', { p_envio_id: 'envio-1' })
    expect(detalle.envio.codigo_verificacion).toBe('482731')
  })

  it('el cliente ya no valida el código: la compatibilidad falla con mensaje claro', async () => {
    const rpc = vi.fn()
    sdk.client = { rpc }
    await expect(
      verificarCodigoEntrega({ envioId: 'envio-1', codigo: '482731' }),
    ).rejects.toThrow(/lo valida el vendedor/)
    expect(rpc).not.toHaveBeenCalled()
  })

  it('obtenerCodigoEntregaCliente usa la RPC del cliente', async () => {
    const rpc = vi.fn(async () => ({ data: '482731', error: null }))
    sdk.client = { rpc }
    await expect(obtenerCodigoEntregaCliente('envio-1')).resolves.toBe('482731')
    expect(rpc).toHaveBeenCalledWith('obtener_codigo_entrega', { p_envio_id: 'envio-1' })
  })

  it('el vendedor valida el código con la RPC autorizada', async () => {
    const rpc = vi.fn(async () => ({ data: true, error: null }))
    sdk.client = { rpc }
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'envio-1', codigo: ' 482731 ' }),
    ).resolves.toBe(true)
    expect(rpc).toHaveBeenCalledWith('verificar_codigo_entrega_vendedor', {
      p_envio_id: 'envio-1',
      p_codigo: '482731',
    })
  })

  it('si la RPC nueva no existe, usa el alias verificar_codigo_entrega del vendedor', async () => {
    const rpc = vi
      .fn()
      .mockResolvedValueOnce({
        data: null,
        error: {
          message: 'Could not find the function public.verificar_codigo_entrega_vendedor',
        },
      })
      .mockResolvedValueOnce({ data: true, error: null })
    sdk.client = { rpc }
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'envio-1', codigo: '482731' }),
    ).resolves.toBe(true)
    expect(rpc).toHaveBeenNthCalledWith(2, 'verificar_codigo_entrega', {
      p_envio_id: 'envio-1',
      p_codigo: '482731',
    })
  })

  it('rechaza códigos inválidos antes de llamar al servidor', async () => {
    const rpc = vi.fn()
    sdk.client = { rpc }
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'envio-1', codigo: '123' }),
    ).rejects.toThrow(/6 dígitos/)
    expect(rpc).not.toHaveBeenCalled()
  })

  it('si las dos RPC no existen, informa la dependencia en español', async () => {
    sdk.client = {
      rpc: vi.fn(async () => ({
        data: null,
        error: { message: 'function public.verificar_codigo_entrega_vendedor does not exist' },
      })),
    }
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'envio-1', codigo: '482731' }),
    ).rejects.toThrow(/no está habilitada en el servidor/)
  })

  it('traduce código inválido y estado incorrecto', () => {
    expect(traducirErrorCodigoEntrega('Codigo de entrega invalido')).toMatch(/no coincide/)
    expect(traducirErrorCodigoEntrega('El codigo solo puede verificarse durante el estado en_transito')).toMatch(
      /En tránsito/,
    )
  })

  it('CK-0478 / HAL-CLI-019: el campo acepta seis dígitos y se validan en el servidor', async () => {
    const { mount } = await import('@vue/test-utils')
    const { default: CtInput } = await import('@/components/base/CtInput.vue')
    const wrapper = mount(CtInput, {
      props: { modelValue: '', label: 'Código que te entregó el cliente' },
      attrs: { maxlength: '6', inputmode: 'numeric', pattern: '[0-9]*', autocomplete: 'one-time-code' },
    })
    const input = wrapper.find('input')
    expect(input.attributes('type')).toBe('text')

    // escribir dígito a dígito o pegar los seis dígitos.
    await input.setValue('482')
    await input.setValue('482731')

    const emisiones = wrapper.emitted('update:modelValue')
    expect(emisiones.at(-1)[0]).toBe('482731')
    // lo que llega al servidor son exactamente seis dígitos.
    const pegado = emisiones.at(-1)[0]
    expect(esCodigoEntregaValido(normalizarCodigoEntrega(pegado))).toBe(true)

    const rpc = vi.fn(async () => ({ data: true, error: null }))
    sdk.client = { rpc }
    await expect(
      verificarCodigoEntregaVendedor({ envioId: 'envio-1', codigo: pegado }),
    ).resolves.toBe(true)
    expect(rpc).toHaveBeenCalledWith('verificar_codigo_entrega_vendedor', {
      p_envio_id: 'envio-1',
      p_codigo: '482731',
    })
    wrapper.unmount()
  })
})

/* ------------------------------------------------------------------ */
/* Reclamos: cliente visible (HAL-VEN-032)                             */
/* ------------------------------------------------------------------ */

describe('cliente en reclamos del vendedor', () => {
  it('cae al nombre del destinatario cuando la RLS no expone el perfil', () => {
    expect(
      nombreClienteReclamo({
        cliente: null,
        pedido: { nombre_destinatario: 'Ana Pérez' },
      }),
    ).toBe('Ana Pérez')
    expect(nombreClienteReclamo({ cliente: null, pedido: null })).toBe('Cliente sin nombre')
  })

  it('muestra un identificador corto y consistente con el pedido', () => {
    expect(identificadorClienteReclamo({ cliente_id: '12345678-90ab-cdef' })).toBe('#12345678')
    expect(identificadorClienteReclamo({ pedido: { cliente_id: 'abcdef12-3456' } })).toBe(
      '#abcdef12',
    )
    expect(identificadorClienteReclamo({})).toBe('—')
  })
})


describe('CK-0149: no inventar seguimiento ante consultas fallidas', () => {
  it.each(['pedidos', 'detalles_pedido', 'pagos', 'envios', 'productores', 'comunas', 'evaluaciones_reputacion'])(
    'no muestra un detalle parcial cuando falla %s', async (errorTabla) => {
      sdk.client = clienteDetalle({ envio: null, errorTabla }).client
      await expect(getPedidoDetalle('pedido-1')).rejects.toThrow('estado completo del pedido')
    },
  )

  it('distingue código no disponible de fallo de consulta', async () => {
    sdk.client = clienteDetalle({ envio: { id: 'envio-1' }, rpc: vi.fn(async () => ({
      data: null, error: { message: 'fallo de red' },
    })) }).client
    await expect(getPedidoDetalle('pedido-1')).rejects.toThrow('consultar el código')
  })
})
