/**
 * CuTuCo — Lote 9 (Reclamos), lado frontend.
 *
 * CK-0396: motivo y descripción obligatorios en interfaz antes de enviar.
 * CK-0398: respuesta del vendedor obligatoria y sólo mientras el reclamo siga vigente.
 * CK-0515 (HAL-VEN-027): descripciones largas ajustan líneas (clamp + wrap).
 * CK-0519 (HAL-VEN-031): sin correo/teléfono del cliente; el canal es el pedido.
 * CK-0520 (HAL-VEN-032): la columna Cliente muestra nombre/identificador real.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)
const sessionMock = vi.hoisted(() => ({
  currentUserId: vi.fn(async () => 'u-cliente'),
  unwrap: (r, msg) => { if (r?.error) throw new Error(msg); return r?.data },
}))
vi.mock('@/services/session.js', () => sessionMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0396 · reclamo con antecedentes obligatorios en interfaz', () => {
  it('crearReclamo rechaza motivo o descripción vacíos antes de llamar a la BD', async () => {
    const insert = vi.fn()
    const q = { insert, select: vi.fn(() => q), single: vi.fn(async () => ({ data: {}, error: null })) }
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => q) })
    const { crearReclamo } = await import('@/services/reclamos.js')
    await expect(crearReclamo({ pedidoId: 'p1', motivo: '  ', descripcion: 'x' })).rejects.toThrow(/motivo/i)
    await expect(crearReclamo({ pedidoId: 'p1', motivo: 'Daño', descripcion: '   ' })).rejects.toThrow(/Describe/i)
    expect(insert).not.toHaveBeenCalled()
  })
})

describe('CK-0398 · respuesta del vendedor obligatoria y sólo si el reclamo está vigente', () => {
  it('responderReclamo rechaza texto vacío y limita a estados abiertos', async () => {
    const update = vi.fn(() => q)
    const q = { update, eq: vi.fn(() => q), in: vi.fn(() => q), select: vi.fn(() => q), single: vi.fn(async () => ({ data: {}, error: null })) }
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => q) })
    const { responderReclamo } = await import('@/services/reclamos.js')
    await expect(responderReclamo({ reclamoId: 'r1', respuesta: '   ' })).rejects.toThrow(/respuesta/i)
    expect(update).not.toHaveBeenCalled()
    await responderReclamo({ reclamoId: 'r1', respuesta: 'Se repone el producto' })
    expect(q.in).toHaveBeenCalledWith('estado', ['abierto', 'en_revision'])
  })

  it('la bandeja bloquea la edición cuando el reclamo está cerrado', () => {
    const vista = src('views/seller/SellerClaimsView.vue')
    expect(vista).toContain('v-if="row.vigente"')
    expect(vista).toContain('Reclamo cerrado')
  })
})

describe('CK-0515 (HAL-VEN-027) · descripciones largas ajustan líneas', () => {
  it('las celdas de motivo/descripción usan clamp y wrap', () => {
    const vista = src('views/seller/SellerClaimsView.vue')
    expect(vista).toContain('texto-largo clamp-2')
    const estilos = vista.slice(vista.indexOf('<style'))
    expect(estilos).toContain('line-clamp')
    expect(estilos).toContain('overflow-wrap: anywhere')
    expect(estilos).toContain('word-break: break-word')
    // el detalle del admin también ajusta bloques largos (HAL-VEN-027)
    const admin = src('views/admin/AdminClaimsView.vue')
    const bloque = admin.slice(admin.indexOf('.bloque__texto'))
    expect(bloque).toContain('overflow-wrap: anywhere')
    expect(bloque).toContain('word-break: break-word')
  })
})

describe('CK-0519 (HAL-VEN-031) · contacto indirecto vía pedido, sin datos directos', () => {
  it('la bandeja no muestra correo ni teléfono del cliente', () => {
    const vista = src('views/seller/SellerClaimsView.vue')
    expect(vista).not.toMatch(/correo.*cliente|teléfono.*cliente/i)
    expect(vista).toContain('usando los datos de entrega del pedido asociado')
    // el enlace permitido es el pedido asociado
    expect(vista).toContain('enlacePedido(row)')
  })
})

describe('CK-0520 (HAL-VEN-032) · columna Cliente con nombre real, nunca guion por fallo', () => {
  it('nombreClienteReclamo usa nombre o destinatario, sin devolver guion', async () => {
    const { nombreClienteReclamo, identificadorClienteReclamo } = await import('@/lib/orders.js')
    expect(nombreClienteReclamo({ cliente: { nombre: 'Ana', apellido: 'Paz' } })).toBe('Ana Paz')
    expect(nombreClienteReclamo({ pedido: { nombre_destinatario: 'Juan Pérez' } })).toBe('Juan Pérez')
    expect(nombreClienteReclamo({})).toBe('Cliente sin nombre')
    expect(identificadorClienteReclamo({ cliente_id: 'abc12345-xyz' })).toBe('#abc12345')
    const vista = src('views/seller/SellerClaimsView.vue')
    expect(vista).toContain('nombreClienteReclamo(row)')
    expect(vista).toContain('identificadorClienteReclamo(row)')
  })
})
