<script setup>
/**
 * CuTuCo — Carga de imágenes con captura por cámara.
 * Emite `update:modelValue` con un array de archivos (File + preview).
 */
import { ref } from 'vue'
import CtButton from './CtButton.vue'
import CtIcon from './CtIcon.vue'
import { readFileAsDataURL } from '@/lib/supabase'
import { isAllowedImage } from '@/lib/validation'

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  label: { type: String, default: 'Fotografías' },
  hint: { type: String, default: 'JPG, PNG o WEBP · máximo 5 MB por imagen' },
  accept: { type: String, default: 'image/*' },
  multiple: { type: Boolean, default: true },
  max: { type: Number, default: 5 },
  capture: { type: String, default: 'environment' },
  required: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  error: { type: String, default: null },
  emptyIcon: { type: String, default: 'camera' },
})

const emit = defineEmits(['update:modelValue', 'error'])

const cameraInput = ref(null)
const galleryInput = ref(null)
const isDragging = ref(false)

async function onSelect(event) {
  if (props.disabled || props.loading) return
  const files = [...event.target.files]
  event.target.value = ''
  await addFiles(files)
}

async function addFiles(files) {
  if (props.disabled || props.loading) return
  const next = [...props.modelValue]
  for (const file of files) {
    const message = isAllowedImage(file)
    if (message) {
      emit('error', message)
      continue
    }
    if (next.length >= props.max) {
      emit('error', `Puedes cargar hasta ${props.max} imágenes`)
      break
    }
    next.push({ file, preview: await readFileAsDataURL(file), name: file.name, size: file.size })
  }
  emit('update:modelValue', next)
}

function remove(index) {
  if (props.disabled || props.loading) return
  const next = [...props.modelValue]
  next.splice(index, 1)
  emit('update:modelValue', next)
}

function onDrop(event) {
  if (props.disabled || props.loading) return
  isDragging.value = false
  addFiles([...event.dataTransfer.files])
}
</script>

<template>
  <div class="ct-upload">
    <div class="ct-upload__head">
      <span class="ct-upload__label">
        {{ label }}
        <span v-if="required" class="ct-upload__required">*</span>
      </span>
      <span class="ct-upload__count">{{ modelValue.length }}/{{ max }}</span>
    </div>

    <div
      class="ct-upload__dropzone"
      :class="{ 'is-dragging': isDragging, 'is-disabled': disabled || loading }"
      @dragover.prevent="!disabled && !loading && (isDragging = true)"
      @dragleave.prevent="isDragging = false"
      @drop.prevent="onDrop"
    >
      <span class="ct-upload__icon" aria-hidden="true"
        ><CtIcon :name="emptyIcon" :size="30"
      /></span>
      <p class="ct-upload__text">
        Arrastra imágenes aquí o usa la cámara del dispositivo para documentar el pedido.
      </p>
      <div class="ct-upload__actions">
        <CtButton
          size="sm"
          variant="secondary"
          type="button"
          :disabled="disabled || loading"
          @click="cameraInput?.click()"
        >
          <template #icon><CtIcon name="camera" :size="15" /></template>
          Tomar foto
        </CtButton>
        <CtButton
          size="sm"
          variant="ghost"
          type="button"
          :disabled="disabled || loading"
          @click="galleryInput?.click()"
        >
          <template #icon><CtIcon name="image" :size="15" /></template>
          Subir archivo
        </CtButton>
      </div>
    </div>

    <input
      ref="cameraInput"
      type="file"
      :accept="accept"
      :capture="capture"
      :disabled="disabled || loading"
      class="ct-upload__input"
      @change="onSelect"
    />
    <input
      ref="galleryInput"
      type="file"
      :accept="accept"
      :multiple="multiple"
      :disabled="disabled || loading"
      class="ct-upload__input"
      @change="onSelect"
    />

    <ul v-if="modelValue.length" class="ct-upload__list">
      <li v-for="(item, index) in modelValue" :key="item.preview" class="ct-upload__item">
        <img :src="item.preview" :alt="item.name" />
        <button
          type="button"
          class="ct-upload__remove"
          aria-label="Quitar imagen"
          :disabled="disabled || loading"
          @click="remove(index)"
        >
          <CtIcon name="close" :size="14" />
        </button>
      </li>
    </ul>

    <p v-if="error" class="ct-upload__error">{{ error }}</p>
    <p v-else-if="hint" class="ct-upload__hint">{{ hint }}</p>
  </div>
</template>

<style scoped>
.ct-upload {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
}

.ct-upload__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.ct-upload__label {
  font-size: var(--ct-fs-sm);
  font-weight: var(--ct-fw-medium);
}

.ct-upload__required {
  color: var(--ct-danger);
}

.ct-upload__count {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ct-upload__dropzone {
  border: 1.5px dashed var(--ct-border-strong);
  border-radius: var(--ct-radius-lg);
  background: var(--ct-surface-alt);
  padding: var(--ct-space-6);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--ct-space-2);
  text-align: center;
  transition:
    border-color var(--ct-transition),
    background-color var(--ct-transition);
}

.ct-upload__dropzone.is-dragging {
  border-color: var(--ct-primary);
  background: var(--ct-primary-softer);
}

.ct-upload__dropzone.is-disabled {
  cursor: not-allowed;
  opacity: 0.65;
}

.ct-upload__icon {
  color: var(--ct-text-muted);
}

.ct-upload__text {
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
  max-width: 44ch;
}

.ct-upload__actions {
  display: flex;
  gap: var(--ct-space-2);
  margin-top: var(--ct-space-1);
}

.ct-upload__input {
  display: none;
}

.ct-upload__list {
  display: flex;
  gap: var(--ct-space-3);
  list-style: none;
  padding: 0;
  margin: 0;
  flex-wrap: wrap;
}

.ct-upload__item {
  position: relative;
  width: 88px;
  height: 88px;
  border-radius: var(--ct-radius-md);
  overflow: hidden;
  border: 1px solid var(--ct-border);
}

.ct-upload__item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.ct-upload__remove {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ct-overlay-strong);
  color: var(--ct-text-invert);
  font-size: 1rem;
  line-height: 1;
  display: grid;
  place-items: center;
  transition:
    background-color var(--ct-transition),
    transform var(--ct-transition);
}

.ct-upload__remove:hover {
  background: var(--ct-danger);
  transform: scale(1.06);
}

.ct-upload__hint {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.ct-upload__error {
  font-size: var(--ct-fs-xs);
  color: var(--ct-danger);
  font-weight: var(--ct-fw-medium);
}
</style>
