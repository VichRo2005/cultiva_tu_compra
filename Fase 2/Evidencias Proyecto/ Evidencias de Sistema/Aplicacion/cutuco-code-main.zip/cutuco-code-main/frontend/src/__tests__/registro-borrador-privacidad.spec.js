import { beforeEach, describe, expect, it } from 'vitest'
import { guardarBorradorClienteLocal, leerBorradorClienteLocal } from '@/services/registro'

const clave = 'cutuco:registro-cliente-pendiente'
beforeEach(() => localStorage.clear())

describe('Privacidad del borrador de registro', () => {
  it('conserva los datos del formulario sin persistir contraseña ni confirmación', () => {
    guardarBorradorClienteLocal({ nombre: 'Ana', calle: 'Camino QA', paso: 3,
      password: 'SecretoSoloDePrueba1!', confirmacion: 'SecretoSoloDePrueba1!' })
    expect(JSON.parse(localStorage.getItem(clave))).toEqual({ nombre: 'Ana', calle: 'Camino QA', paso: 3 })
  })
  it('retira la contraseña de un borrador antiguo conservando los otros datos', () => {
    localStorage.setItem(clave, JSON.stringify({ nombre: 'Ana', numero: '12 B',
      password: 'SecretoSoloDePrueba1!', confirmacion: 'SecretoSoloDePrueba1!' }))
    expect(leerBorradorClienteLocal()).toEqual({ nombre: 'Ana', numero: '12 B' })
    expect(JSON.parse(localStorage.getItem(clave))).toEqual({ nombre: 'Ana', numero: '12 B' })
  })
})
