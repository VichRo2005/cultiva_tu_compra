/**
 * CuTuCo — Galería de desarrollo de vistas.
 *
 * La galería dejó de estar activa por defecto: sólo se habilita con
 * `VITE_DEV_GALLERY=true`, para que la aplicación respete los guards de rol y
 * trabaje siempre con datos reales de Supabase. Estas pruebas verifican el
 * contrato de la herramienta y que su listado cubra las ventanas del alcance
 * vigente.
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { beforeEach, describe, expect, it } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'

import router from '@/router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import AppShell from '@/layouts/AppShell.vue'
import DevBanner from '@/dev/DevBanner.vue'
import DevGalleryNav from '@/dev/DevGalleryNav.vue'
import {
  DEV_GALLERY_ENABLED,
  DEV_GROUPS,
  DEV_IDS,
  DEV_PASSWORD,
  DEV_SESSIONS,
  DEV_VIEW_COUNT,
  rolPuedeAbrir,
  sesionParaRuta,
} from '@/dev/devGallery'

function fuenteDe(component) {
  const ruta = component.__file ?? ''
  return readFileSync(ruta.startsWith('file:') ? fileURLToPath(ruta) : ruta, 'utf8')
}

describe('galería de desarrollo de vistas', () => {
  beforeEach(async () => {
    localStorage.clear()
    setActivePinia(createPinia())
    await router.replace('/')
    await router.isReady()
  })

  it('está apagada salvo que se active con VITE_DEV_GALLERY=true', () => {
    expect(typeof DEV_GALLERY_ENABLED).toBe('boolean')
    expect(DEV_SESSIONS.map((s) => s.key)).toEqual(['admin', 'vendedor', 'cliente', 'pendiente'])
    // La primera cuenta es la de administración: permisos completos.
    expect(DEV_SESSIONS[0].email).toBe('admin@cutuco.dev')
    expect(DEV_PASSWORD.length).toBeGreaterThanOrEqual(8)
    expect(DEV_IDS.producto).toMatch(/^[0-9a-f-]{36}$/)
  })

  it('las cuentas de la galería tienen correo, contraseña y ventana de inicio', () => {
    for (const sesion of DEV_SESSIONS) {
      expect(sesion.email, `correo de ${sesion.key}`).toMatch(/^[^@\s]+@cutuco\.dev$/)
      expect(sesion.home, `inicio de ${sesion.key}`).toMatch(/^\//)
      expect(sesion.label).toBeTruthy()
      // Cada cuenta trae un respaldo del seed base por si la semilla de la
      // galería no está cargada en la base.
      expect(Array.isArray(sesion.alternativas)).toBe(true)
      expect(sesion.alternativas.length).toBeGreaterThan(0)
    }
    // El correo obsoleto del prototipo ya no se ofrece como cuenta principal.
    expect(DEV_SESSIONS.map((s) => s.email)).not.toContain('productor.paine@example.test')
  })

  it('resuelve el rol necesario para cada ventana (acceso total)', () => {
    // Ventanas públicas: nunca fuerzan cambio de rol.
    expect(sesionParaRuta('cliente', {}, '/catalogo')).toBeNull()
    // Ventanas de un rol: se cambia a la cuenta del área correspondiente.
    expect(sesionParaRuta('vendedor', { roles: ['admin'] }, '/admin/usuarios')?.key).toBe('admin')
    expect(sesionParaRuta('admin', { roles: ['vendedor', 'admin'] }, '/vendedor')).toBeNull()
    expect(sesionParaRuta('cliente', { roles: ['vendedor', 'admin'] }, '/vendedor/pedidos')?.key).toBe(
      'vendedor',
    )
    expect(sesionParaRuta('vendedor', { roles: ['vendedor', 'admin'] }, '/vendedor/productos')).toBeNull()
    // Ventanas heredadas de la galería: siempre accesibles sin cambiar de cuenta.
    expect(rolPuedeAbrir('cliente', { gallery: true, roles: ['admin'] })).toBe(true)
    expect(sesionParaRuta('cliente', { gallery: true, roles: ['admin'] }, '/admin/reportes')).toBeNull()
  })

  it('lista todas las ventanas del alcance vigente sin repetir rutas', () => {
    const listadas = DEV_GROUPS.flatMap((g) => g.views.map((v) => v.path))
    expect(DEV_VIEW_COUNT).toBe(listadas.length)
    expect(new Set(listadas).size).toBe(listadas.length)
  })

  it('cubre las ventanas registradas en el router', () => {
    const listadas = DEV_GROUPS.flatMap((g) => g.views.map((v) => v.path.split('?')[0]))
    const hojas = router
      .getRoutes()
      .filter((r) => r.name && r.name !== 'not-found' && !r.path.includes('pathMatch'))

    for (const ruta of hojas) {
      const base = ruta.path.includes('/:') ? `${ruta.path.split('/:')[0]}/` : ruta.path
      const cubierta = listadas.some((p) => p === ruta.path || (base !== ruta.path && p.startsWith(base)))
      expect(cubierta, `falta ${ruta.path} en la galería`).toBe(true)
    }
  })

  it('incluye las ventanas del prototipo anterior para poder revisarlas', () => {
    const grupo = DEV_GROUPS.find((g) => g.key === 'galeria')
    expect(grupo, 'falta el grupo de ventanas del prototipo anterior').toBeTruthy()
    const rutas = grupo.views.map((v) => v.path)
    for (const esperada of [
      '/vendedor/reputacion',
      '/vendedor/alertas-stock',
      '/admin/reportes',
      '/admin/reclamos',
      '/admin/geografia',
    ]) {
      expect(rutas).toContain(esperada)
    }
  })

  it('el historial de precios (RF-008) sí se retiró por completo', () => {
    const listadas = DEV_GROUPS.flatMap((g) => g.views.map((v) => v.path)).join(' ')
    expect(listadas).not.toContain('/precios')
    expect(router.resolve('/precios').name).toBe('not-found')
  })

  it('muestra el aviso de vistas en desarrollo', () => {
    const aviso = mount(DevBanner)
    expect(aviso.text()).toContain('Vistas en Desarrollo')
    expect(aviso.text()).toContain('Ver todas las ventanas')
    aviso.unmount()
  })

  it('el aviso se monta en los dos layouts que cubren todas las ventanas', () => {
    for (const layout of [AppShell, AuthLayout]) {
      expect(fuenteDe(layout)).toContain('DevOverlay')
    }
  })

  it('la barra lateral lista las ventanas agrupadas por módulo', async () => {
    const nav = mount(DevGalleryNav, { props: { modelValue: true }, global: { plugins: [router] } })
    await flushPromises()

    const grupos = nav.findAll('.dev-gallery__group')
    expect(grupos).toHaveLength(DEV_GROUPS.length)

    await grupos[0].find('.dev-gallery__group-head').trigger('click')
    expect(nav.findAll('.dev-gallery__link')).toHaveLength(DEV_GROUPS[0].views.length)

    expect(nav.text()).toContain('Ver como')
    expect(nav.findAll('.dev-gallery__role')).toHaveLength(DEV_SESSIONS.length)
    nav.unmount()
  })
})
