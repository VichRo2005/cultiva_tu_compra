<script setup>
/**
 * CuTuCo — Componente raíz: arranque de sesión (RF-001), geografía, toasts
 * globales y la galería de desarrollo opcional (`VITE_DEV_GALLERY`).
 *
 * Fuente de datos: Supabase real. El modo demostración, cuando se habilita de
 * forma explícita para pruebas, no suplanta la identidad de quien visita el sitio.
 */
import { onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import CtToastHost from '@/components/base/CtToastHost.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import { useGeographyStore } from '@/stores/geography'
/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): `useCartStore` se usaba en
 * este componente para validar la cobertura por comuna del perfil. La cobertura
 * vigente es regional y la valida el checkout con la dirección elegida (RF-009).
 * import { useCartStore } from '@/stores/cart'
 */
import {
  ajustarIdsDeGaleria,
  autenticarComo,
  DEV_GALLERY_ENABLED,
  permiteSesionAutomatica,
  sesionDeGaleria as sesionGaleria,
} from '@/dev/devGallery'

const auth = useAuthStore()
const ui = useUiStore()
const geo = useGeographyStore()
const route = useRoute()
const router = useRouter()

onMounted(async () => {
  if (auth.initializing) await auth.init()
  ajustarIdsDeGaleria()
  await iniciarSesionAutomatica()
  // La geografía sólo alimenta etiquetas y selectores. No puede retrasar el
  // arranque de la sesión ni la primera carga del catálogo si PostgREST está
  // lento o momentáneamente no disponible.
  void geo.load()
  await sync()
})

/**
 * Sesión inicial.
 *
 * Sólo la galería de desarrollo (`VITE_DEV_GALLERY=true`) inicia una sesión de
 * ejemplo. Una visita normal siempre comienza como visitante hasta autenticarse.
 */
async function iniciarSesionAutomatica() {
  if (auth.isAuthenticated || !permiteSesionAutomatica()) return

  if (!DEV_GALLERY_ENABLED) return
  try {
    await autenticarComo(sesionGaleria())
  } catch {
    // Sin sesión disponible: la aplicación sigue funcionando en modo público.
  }
}

/** Avisos del rol activo (RF-011 y RF-021) sobre los datos del dominio. */
async function sync() {
  if (!auth.isAuthenticated) {
    ui.limpiarNotificaciones()
    ui.panelAbierto = false
    if (route.meta.requiresAuth) {
      await router.replace({ name: 'login', query: { redirect: route.fullPath } })
    }
    return
  }
  await ui.syncNotifications({ rol: auth.rol })
  /*
   * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): aquí se llamaba a
   * `cart.validarCobertura({ comunaId: auth.perfil.comuna_principal_id })`
   * (RF-009 versión antigua, cobertura por comuna). `perfiles` no guarda una
   * comuna y la cobertura vigente es regional: se valida en `CartView` y
   * `CheckoutView` con `cart.validarCobertura(direccion)` sobre la dirección
   * de entrega elegida, antes de crear el pago.
   */
}

watch(() => [auth.user?.id, auth.rol], () => {
  ui.limpiarNotificaciones()
  void sync()
})
</script>

<template>
  <div v-if="auth.initializing" class="ct-boot">
    <CtSpinner :size="42" label="Cargando CuTuCo…" />
  </div>
  <RouterView v-else />
  <CtToastHost />
</template>

<style scoped>
.ct-boot {
  min-height: 100vh;
  min-height: 100dvh;
  display: grid;
  place-items: center;
  background: var(--ct-bg);
}
</style>
