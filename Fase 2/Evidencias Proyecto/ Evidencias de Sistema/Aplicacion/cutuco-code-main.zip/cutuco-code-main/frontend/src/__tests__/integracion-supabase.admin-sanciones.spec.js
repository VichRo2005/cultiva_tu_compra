// Integración SDK → GoTrue/PostgREST → triggers/RLS. Solo Supabase local.
import { createClient } from '@supabase/supabase-js'
import { beforeAll, afterAll, describe, expect, it, vi } from 'vitest'
const state = vi.hoisted(() => ({ client: null }))
vi.mock('@/lib/supabase', () => ({
  getClient: () => state.client,
  tryGetClient: () => state.client,
}))
import { crearSancion, resolverSancion, reactivarCuentaPermanente } from '@/services/adminSanciones'
import { resolverApelacion, listApelaciones } from '@/services/adminApelaciones'
const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY
const local = url && ['127.0.0.1', 'localhost'].includes(new URL(url).hostname)
const productorId = '20000000-0000-0000-0000-000000000003'
const perfilId = 'a0000000-0000-0000-0000-000000000103'
let adminClient,
  sellerClient,
  original,
  originalPerfil,
  ready = false
const ids = []
const appealIds = []
const unwrap = (r) => {
  if (r.error) throw r.error
  return r.data
}
const row = (table, id) => adminClient.from(table).select('*').eq('id', id).single().then(unwrap)
beforeAll(async () => {
  if (!local || !key) return
  adminClient = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false, storageKey: 'admin-sanctions-test' },
  })
  sellerClient = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  try {
    await fetch(url + '/auth/v1/health', {
      headers: { apikey: key },
      signal: AbortSignal.timeout(2500),
    })
  } catch {
    return
  }
  unwrap(
    await adminClient.auth.signInWithPassword({
      email: 'cutuco.admin.base@example.test',
      password: 'CutucoTest!2026',
    }),
  )
  unwrap(
    await sellerClient.auth.signInWithPassword({
      email: 'cutuco.productor.quillota@example.test',
      password: 'CutucoTest!2026',
    }),
  )
  state.client = adminClient
  original = await row('productores', productorId)
  originalPerfil = await row('perfiles', perfilId)
  const vigentes = unwrap(
    await adminClient
      .from('sanciones')
      .select('id')
      .eq('productor_id', productorId)
      .in('estado', ['activa', 'apelada']),
  )
  if (vigentes.length)
    throw new Error(
      'La cuenta de pruebas tiene sanciones vigentes: no se modifican datos ajenos al test.',
    )
  ready = true
}, 15000)
afterAll(async () => {
  if (ready && ids.length) {
    if (appealIds.length) unwrap(await adminClient.from('apelaciones').delete().in('id', appealIds))
    if (ids.length) unwrap(await adminClient.from('sanciones').delete().in('id', ids))
    unwrap(
      await adminClient
        .from('perfiles')
        .update({ activo: originalPerfil.activo })
        .eq('id', perfilId),
    )
    unwrap(
      await adminClient
        .from('productores')
        .update({ activo: original.activo })
        .eq('id', productorId),
    )
  }
  await adminClient?.auth.signOut({ scope: 'local' })
  await sellerClient?.auth.signOut({ scope: 'local' })
})
async function nueva(accion = 'suspender') {
  const s = await crearSancion({
    productorId,
    tipo: 'suspension',
    accion,
    motivo: 'Verificacion administrativa de integracion',
    duracionDias: '2',
  })
  ids.push(s.id)
  return s
}
async function apelar(sancion) {
  const a = unwrap(
    await sellerClient
      .from('apelaciones')
      .insert({
        sancion_id: sancion.id,
        productor_id: productorId,
        solicitante_id: perfilId,
        fundamento: 'Solicito revisar los antecedentes del caso',
      })
      .select()
      .single(),
  )
  appealIds.push(a.id)
  return a
}
describe('Supabase local · sanciones', () => {
  it('respeta suspensión, reapelación, múltiples sanciones, ban duplicado y reactivación atómica', async (ctx) => {
    if (!ready) return ctx.skip(true, 'Requiere Supabase local y credenciales de seed')
    const first = await nueva()
    const second = await nueva()
    expect((await row('perfiles', perfilId)).activo).toBe(true)
    expect((await row('productores', productorId)).activo).toBe(false)
    const appeal = await apelar(first)
    expect((await row('sanciones', first.id)).estado).toBe('apelada')
    await resolverApelacion(appeal.id, 'rechazada', 'Se mantienen los antecedentes')
    expect((await row('sanciones', first.id)).estado).toBe('activa')
    const retry = await apelar(first)
    const detail = (await listApelaciones()).find((a) => a.id === retry.id)
    expect(detail.sancion.motivo).toBe(first.motivo)
    await resolverApelacion(retry.id, 'aprobada', 'Antecedentes revisados')
    expect((await row('sanciones', first.id)).estado).toBe('resuelta')
    expect((await row('productores', productorId)).activo).toBe(false)
    const secondAppeal = await apelar(second)
    const ban = await nueva('ban_permanente')
    expect((await row('perfiles', perfilId)).activo).toBe(false)
    await expect(nueva('ban_permanente')).rejects.toThrow('ya tiene un ban')
    const duplicate = await adminClient
      .from('sanciones')
      .insert({
        productor_id: productorId,
        tipo: 'suspension',
        accion: 'ban_permanente',
        motivo: 'Prueba de duplicado',
      })
    expect(duplicate.error?.message).toContain('ban permanente activo')
    await expect(reactivarCuentaPermanente(ban.id)).rejects.toThrow('otras sanciones')
    expect((await row('perfiles', perfilId)).activo).toBe(false)
    await resolverApelacion(secondAppeal.id, 'aprobada', 'Revisión completada')
    expect((await row('productores', productorId)).activo).toBe(false)
    await reactivarCuentaPermanente(ban.id)
    expect((await row('perfiles', perfilId)).activo).toBe(true)
    expect((await row('productores', productorId)).activo).toBe(true)
    expect((await row('sanciones', ban.id)).estado).toBe('resuelta')
    const cancel = await nueva()
    await resolverSancion(cancel.id, 'cancelada')
    expect((await row('sanciones', cancel.id)).estado).toBe('cancelada')
    expect((await row('productores', productorId)).activo).toBe(true)
  }, 30000)
})
