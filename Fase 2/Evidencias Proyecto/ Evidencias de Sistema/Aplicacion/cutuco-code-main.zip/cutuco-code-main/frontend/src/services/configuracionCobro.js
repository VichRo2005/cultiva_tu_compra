/**
 * Configuración comercial pública de CuTuCo.
 *
 * Sólo expone el estado y la tasa del IVA, información necesaria para que el
 * carrito muestre el mismo cálculo que el backend. La escritura conserva la
 * política RLS de `configuracion_logistica`: únicamente administración.
 */
import { getClient } from '@/lib/supabase'
import { mensajeSeguro } from '@/services/errores'

export const CONFIGURACION_IVA_POR_DEFECTO = Object.freeze({
  ivaHabilitado: true,
  tasaIva: 0.19,
})

function normalizar(fila) {
  return {
    ivaHabilitado: fila?.iva_habilitado !== false,
    tasaIva: Number(fila?.tasa_iva ?? CONFIGURACION_IVA_POR_DEFECTO.tasaIva),
  }
}

/** Lee la misma configuración singleton que usará el checkout en el servidor. */
export async function obtenerConfiguracionCobro() {
  const client = getClient()
  const { data, error } = await client
    .from('configuracion_logistica')
    .select('iva_habilitado, tasa_iva')
    .eq('id', 1)
    .maybeSingle()
  if (error) throw new Error(mensajeSeguro(error.message, 'No se pudo cargar la configuración de IVA.'))
  return normalizar(data)
}

/** Actualización administrativa del interruptor global de IVA. */
export async function actualizarIvaHabilitado(ivaHabilitado) {
  const client = getClient()
  const { data, error } = await client
    .from('configuracion_logistica')
    .update({ iva_habilitado: Boolean(ivaHabilitado) })
    .eq('id', 1)
    .select('iva_habilitado, tasa_iva')
    .single()
  if (error) throw new Error(mensajeSeguro(error.message, 'No se pudo actualizar el IVA.'))
  return normalizar(data)
}
