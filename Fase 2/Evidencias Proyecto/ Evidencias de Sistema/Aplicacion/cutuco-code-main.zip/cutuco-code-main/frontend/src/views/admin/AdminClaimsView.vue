<script setup>
/**
 * CuTuCo — Reclamos de clientes (RF-027).
 *
 * El cliente presenta un reclamo sobre su pedido; el vendedor puede responder
 * y sólo el administrador puede resolverlo o rechazarlo. Esta bandeja es la
 * entrada operativa del administrador al flujo de reclamos.
 */
import { computed, onMounted, ref } from 'vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtConfirmDialog from '@/components/base/CtConfirmDialog.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import CtModal from '@/components/base/CtModal.vue'
import CtSearchInput from '@/components/base/CtSearchInput.vue'
import CtSpinner from '@/components/base/CtSpinner.vue'
import CtStatCard from '@/components/base/CtStatCard.vue'
import CtTable from '@/components/base/CtTable.vue'
import CtSelect from '@/components/base/CtSelect.vue'
import StatusBadge from '@/components/domain/StatusBadge.vue'
import { exportExcel } from '@/lib/csv'
import { ESTADO_RECLAMO, LABELS } from '@/lib/constants'
import { formatCLP, formatDate, formatDateTime, formatNumber, truncate } from '@/lib/format'
import { listReclamos, resolverReclamo } from '@/services/adminReclamos'
import { getPedidoDetalle } from '@/services/orders'
import { useUiStore } from '@/stores/ui'

const ui = useUiStore()

const TABS = [
  { value: 'todos', label: 'Todos' },
  { value: ESTADO_RECLAMO.ABIERTO, label: LABELS.reclamo.abierto },
  { value: ESTADO_RECLAMO.EN_REVISION, label: LABELS.reclamo.en_revision },
  { value: ESTADO_RECLAMO.RESUELTO, label: LABELS.reclamo.resuelto },
  { value: ESTADO_RECLAMO.RECHAZADO, label: LABELS.reclamo.rechazado },
]

const estado = ref('todos')
const texto = ref('')
const reclamos = ref([])
const loading = ref(true)
const error = ref(null)
const guardando = ref(false)

const detalle = ref({ abierto: false, reclamo: null, pedido: null, cargando: false })
const confirmacion = ref({ abierto: false, reclamo: null, nuevoEstado: null })

const columnas = [
  { key: 'motivo', label: 'Motivo', width: '30%' },
  { key: 'pedido', label: 'Pedido' },
  { key: 'descripcion', label: 'Descripción' },
  { key: 'creado', label: 'Recibido' },
  { key: 'estado', label: 'Estado' },
  { key: 'acciones', label: 'Acciones', align: 'right' },
]

const tabs = computed(() =>
  TABS.map((t) => ({
    ...t,
    count:
      t.value === 'todos'
        ? reclamos.value.length
        : reclamos.value.filter((r) => r.estado === t.value).length,
  })),
)

const filtrados = computed(() => {
  const busqueda = texto.value.trim().toLowerCase()
  return reclamos.value.filter((r) => {
    if (estado.value !== 'todos' && r.estado !== estado.value) return false
    if (!busqueda) return true
    return (
      String(r.id).toLowerCase().includes(busqueda) ||
      (r.motivo ?? '').toLowerCase().includes(busqueda) ||
      (r.descripcion ?? '').toLowerCase().includes(busqueda) ||
      (r.pedido?.codigo_pedido ?? '').toLowerCase().includes(busqueda)
    )
  })
})

const esDelMes = (fecha) => {
  if (!fecha) return false
  const d = new Date(fecha)
  const ahora = new Date()
  return d.getFullYear() === ahora.getFullYear() && d.getMonth() === ahora.getMonth()
}

const kpis = computed(() => ({
  abiertos: reclamos.value.filter((r) => r.estado === ESTADO_RECLAMO.ABIERTO).length,
  enRevision: reclamos.value.filter((r) => r.estado === ESTADO_RECLAMO.EN_REVISION).length,
  resueltosMes: reclamos.value.filter(
    (r) => r.estado === ESTADO_RECLAMO.RESUELTO && esDelMes(r.resuelto_en),
  ).length,
  rechazados: reclamos.value.filter((r) => r.estado === ESTADO_RECLAMO.RECHAZADO).length,
}))

async function cargar() {
  loading.value = true
  error.value = null
  try {
    reclamos.value = await listReclamos()
  } catch (e) {
    error.value = e.message
    reclamos.value = []
  } finally {
    loading.value = false
  }
}

async function abrirDetalle(reclamo) {
  detalle.value = { abierto: true, reclamo, pedido: reclamo.pedido ?? null, cargando: true }
  try {
    detalle.value.pedido = await getPedidoDetalle(reclamo.pedido_id)
  } catch {
    detalle.value.pedido = reclamo.pedido ?? null
  } finally {
    detalle.value.cargando = false
  }
}

function pedirCierre(reclamo, nuevoEstado) {
  confirmacion.value = { abierto: true, reclamo, nuevoEstado }
}

async function confirmarCierre() {
  const { reclamo, nuevoEstado } = confirmacion.value
  if (!reclamo) return
  guardando.value = true
  try {
    const actualizado = await resolverReclamo(reclamo.id, nuevoEstado)
    const indice = reclamos.value.findIndex((r) => r.id === reclamo.id)
    if (indice >= 0) reclamos.value[indice] = { ...reclamos.value[indice], ...actualizado }
    if (detalle.value.reclamo?.id === reclamo.id) {
      detalle.value = { ...detalle.value, reclamo: actualizado }
    }
    ui.success(
      nuevoEstado === ESTADO_RECLAMO.RESUELTO ? 'Reclamo resuelto' : 'Reclamo rechazado',
      `El caso quedó en estado ${LABELS.reclamo[nuevoEstado]}.`,
    )
    confirmacion.value = { abierto: false, reclamo: null, nuevoEstado: null }
  } catch (e) {
    ui.error('No se pudo cerrar el reclamo', e.message)
  } finally {
    guardando.value = false
  }
}

async function exportarReclamos() {
  if (!filtrados.value.length) {
    ui.warning('Sin datos para exportar', 'No hay reclamos con los filtros actuales.')
    return
  }
  const ok = await exportExcel(
    filtrados.value.map((r) => ({
      motivo: r.motivo,
      pedido: r.pedido?.codigo_pedido ?? r.pedido_id,
      descripcion: r.descripcion,
      respuesta: r.respuesta_productor ?? '',
      estado: LABELS.reclamo[r.estado] ?? r.estado,
      creado: r.creado_en,
      resuelto: r.resuelto_en ?? '',
    })),
    'cutuco-reclamos',
    [
      { key: 'motivo', label: 'Motivo' },
      { key: 'pedido', label: 'Pedido' },
      { key: 'descripcion', label: 'Descripción' },
      { key: 'respuesta', label: 'Respuesta del productor' },
      { key: 'estado', label: 'Estado' },
      { key: 'creado', label: 'Recibido' },
      { key: 'resuelto', label: 'Resuelto' },
    ],
  )
  if (ok) ui.success('Listado exportado', 'Se descargó el Excel de reclamos.')
  else ui.error('No se pudo exportar', 'No hay filas para exportar.')
}

onMounted(cargar)
</script>

<template>
  <div class="container page">
    <header class="page-head">
      <div class="page-head__text">
        <h1 class="page-head__title">Reclamos</h1>
        <p class="page-head__subtitle">
          Constancias registradas por clientes. CuTuCo no media ni resuelve: cliente y productor
          coordinan la solución directamente fuera de la plataforma.
        </p>
      </div>
      <div class="page-head__actions">
        <CtButton variant="secondary" :disabled="loading" @click="exportarReclamos">
          <template #icon><CtIcon name="download" :size="16" /></template>
          Exportar Excel
        </CtButton>
        <CtButton :loading="loading" @click="cargar">
          <template #icon><CtIcon name="refresh" :size="16" /></template>
          Actualizar
        </CtButton>
      </div>
    </header>

    <CtAlert v-if="error" tone="danger" title="No se pudieron cargar los reclamos">
      <p>{{ error }}</p>
      <CtButton size="sm" variant="secondary" @click="cargar">Reintentar</CtButton>
    </CtAlert>

    <CtSpinner v-if="loading && !reclamos.length" label="Cargando reclamos…" />

    <template v-else>
      <div class="grid-kpi">
        <CtStatCard
          label="Abiertos"
          :value="formatNumber(kpis.abiertos)"
          icon="alert"
          tone="danger"
          hint="Sin respuesta del productor"
        />
        <CtStatCard
          label="En revisión"
          :value="formatNumber(kpis.enRevision)"
          icon="clock"
          tone="warning"
          hint="El productor ya respondió"
        />
        <CtStatCard
          label="Resueltos (mes)"
          :value="formatNumber(kpis.resueltosMes)"
          icon="check"
          tone="success"
          hint="Cerrados en el mes en curso"
        />
        <CtStatCard
          label="Rechazados"
          :value="formatNumber(kpis.rechazados)"
          icon="ban"
          tone="neutral"
          hint="Sin respaldo para el cliente"
        />
      </div>

      <CtAlert tone="neutral" compact title="Alcance de este registro">
        <p>
          Al cerrar una constancia sólo se registra su estado, fecha y responsable administrativo.
          No es una mediación ni una decisión sobre el problema: la respuesta y la solución
          corresponden directamente al cliente y al productor.
        </p>
      </CtAlert>

      <CtCard padding="md">
        <div class="barra">
          <CtSelect v-model="estado" :options="tabs" label="Estado" />
          <CtSearchInput
            v-model="texto"
            class="barra__buscador"
            placeholder="Buscar por motivo, descripción o pedido…"
            aria-label="Buscar reclamos"
          />
        </div>

        <CtTable
          :columns="columnas"
          :rows="filtrados"
          :loading="loading"
          dense
          min-width="900px"
          empty-icon="alert"
          empty-title="Sin reclamos"
          empty-message="No hay reclamos que coincidan con los filtros seleccionados."
        >
          <template #cell-motivo="{ row }">
            <div class="motivo">
              <p class="motivo__titulo">{{ row.motivo }}</p>
              <p v-if="row.respuesta_productor" class="motivo__nota">El productor respondió</p>
            </div>
          </template>

          <template #cell-pedido="{ row }">
            <router-link
              v-if="row.pedido"
              class="mono text-xs"
              :to="`/cliente/pedidos/${row.pedido_id}`"
            >
              {{ row.pedido.codigo_pedido }}
            </router-link>
            <span v-else class="text-xs text-muted">{{ String(row.pedido_id).slice(0, 8) }}</span>
          </template>

          <template #cell-descripcion="{ row }">
            <span class="text-sm">{{ truncate(row.descripcion, 70) }}</span>
          </template>

          <template #cell-creado="{ row }">
            <span class="text-sm text-muted">{{ formatDate(row.creado_en) }}</span>
          </template>

          <template #cell-estado="{ row }">
            <StatusBadge type="reclamo" :value="row.estado" />
          </template>

          <template #cell-acciones="{ row }">
            <div class="acciones">
              <CtButton size="sm" variant="ghost" @click="abrirDetalle(row)">Revisar</CtButton>
              <CtButton
                v-if="
                  row.estado === ESTADO_RECLAMO.ABIERTO || row.estado === ESTADO_RECLAMO.EN_REVISION
                "
                size="sm"
                variant="ghost"
                @click="pedirCierre(row, ESTADO_RECLAMO.RESUELTO)"
              >
                Registrar cierre
              </CtButton>
            </div>
          </template>
        </CtTable>
      </CtCard>
    </template>

    <!-- ==================== Detalle del reclamo ==================== -->
    <CtModal
      v-model="detalle.abierto"
      :title="detalle.reclamo?.motivo ?? 'Reclamo'"
      :subtitle="`Recibido el ${formatDateTime(detalle.reclamo?.creado_en)}`"
      size="lg"
    >
      <CtSpinner v-if="detalle.cargando" inline label="Cargando pedido…" />

      <div v-if="detalle.reclamo" class="detalle">
        <div class="detalle__cabecera">
          <StatusBadge type="reclamo" :value="detalle.reclamo.estado" />
          <router-link
            v-if="detalle.pedido"
            class="mono text-sm"
            :to="`/cliente/pedidos/${detalle.reclamo.pedido_id}`"
          >
            {{ detalle.pedido.codigo_pedido }}
          </router-link>
        </div>

        <section class="bloque">
          <h3 class="eyebrow">Descripción del cliente</h3>
          <p class="bloque__texto">{{ detalle.reclamo.descripcion }}</p>
        </section>

        <section class="bloque">
          <h3 class="eyebrow">Respuesta del productor</h3>
          <p v-if="detalle.reclamo.respuesta_productor" class="bloque__texto">
            {{ detalle.reclamo.respuesta_productor }}
          </p>
          <p v-else class="bloque__vacio">
            El productor todavía no respondió. Mientras tanto el caso figura como
            {{ LABELS.reclamo[detalle.reclamo.estado] }}.
          </p>
        </section>

        <section v-if="detalle.pedido" class="bloque">
          <h3 class="eyebrow">Pedido relacionado</h3>
          <dl class="campos">
            <div class="campo">
              <dt>Estado</dt>
              <dd><StatusBadge type="pedido" :value="detalle.pedido.estado" /></dd>
            </div>
            <div class="campo">
              <dt>Total</dt>
              <dd>{{ formatCLP(detalle.pedido.total) }}</dd>
            </div>
            <div class="campo">
              <dt>Productor</dt>
              <dd>{{ detalle.pedido.productor?.nombre_comercial ?? '—' }}</dd>
            </div>
            <div class="campo">
              <dt>Entrega</dt>
              <dd>{{ detalle.pedido.direccion_entrega }}</dd>
            </div>
            <div class="campo">
              <dt>Referencia</dt>
              <dd>{{ detalle.pedido.referencia_entrega ?? '—' }}</dd>
            </div>
            <div class="campo">
              <dt>Pago</dt>
              <dd>
                <StatusBadge
                  v-if="detalle.pedido.pago"
                  type="pago"
                  :value="detalle.pedido.pago.estado"
                />
                <span v-else>Sin pago registrado</span>
              </dd>
            </div>
          </dl>
        </section>

        <section v-if="detalle.reclamo.resuelto_en" class="bloque">
          <h3 class="eyebrow">Cierre</h3>
          <p class="bloque__texto">
            Resuelto el {{ formatDateTime(detalle.reclamo.resuelto_en) }}. La tabla de reclamos no
            almacena una nota de resolución, sólo el estado, el responsable y la fecha.
          </p>
        </section>
      </div>

      <template #footer>
        <CtButton variant="secondary" @click="detalle.abierto = false">Cerrar</CtButton>
        <CtButton
          v-if="
            detalle.reclamo?.estado === ESTADO_RECLAMO.ABIERTO ||
            detalle.reclamo?.estado === ESTADO_RECLAMO.EN_REVISION
          "
          variant="secondary"
          @click="pedirCierre(detalle.reclamo, ESTADO_RECLAMO.RECHAZADO)"
        >
          Rechazar reclamo
        </CtButton>
        <CtButton
          v-if="
            detalle.reclamo?.estado === ESTADO_RECLAMO.ABIERTO ||
            detalle.reclamo?.estado === ESTADO_RECLAMO.EN_REVISION
          "
          @click="pedirCierre(detalle.reclamo, ESTADO_RECLAMO.RESUELTO)"
        >
          Marcar resuelto
        </CtButton>
      </template>
    </CtModal>

    <CtConfirmDialog
      v-model="confirmacion.abierto"
      :title="
        confirmacion.nuevoEstado === ESTADO_RECLAMO.RESUELTO
          ? 'Marcar reclamo resuelto'
          : 'Rechazar reclamo'
      "
      :confirm-label="
        confirmacion.nuevoEstado === ESTADO_RECLAMO.RESUELTO ? 'Marcar resuelto' : 'Rechazar'
      "
      :tone="confirmacion.nuevoEstado === ESTADO_RECLAMO.RESUELTO ? 'primary' : 'danger'"
      :loading="guardando"
      :message="
        confirmacion.nuevoEstado === ESTADO_RECLAMO.RESUELTO
          ? `El reclamo “${confirmacion.reclamo?.motivo ?? ''}” quedará resuelto con tu usuario como responsable y la fecha de hoy.`
          : `El reclamo “${confirmacion.reclamo?.motivo ?? ''}” quedará rechazado. El cliente verá el cambio de estado en su pedido.`
      "
      @confirm="confirmarCierre"
    />
  </div>
</template>

<style scoped>
.barra {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-4);
  margin-bottom: var(--ct-space-4);
}

.barra__buscador {
  max-width: 420px;
}

.motivo__titulo {
  font-weight: var(--ct-fw-semibold);
}

.motivo__nota {
  font-size: var(--ct-fs-xs);
  color: var(--ct-warning-ink);
}

.acciones {
  display: flex;
  justify-content: flex-end;
  gap: var(--ct-space-2);
}

.detalle {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-5);
}

.detalle__cabecera {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-4);
}

.bloque__texto {
  margin-top: var(--ct-space-2);
  color: var(--ct-text-soft);
  line-height: var(--ct-lh-relaxed);
  /* HAL-VEN-027: descripciones largas ajustan líneas dentro del detalle */
  overflow-wrap: anywhere;
  word-break: break-word;
}

.bloque__vacio {
  margin-top: var(--ct-space-2);
  color: var(--ct-text-muted);
  font-size: var(--ct-fs-md);
}

.campos {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-4);
  margin-top: var(--ct-space-2);
}

.campo dt {
  font-size: var(--ct-fs-2xs);
  text-transform: uppercase;
  letter-spacing: var(--ct-tracking-wide);
  color: var(--ct-text-muted);
  font-weight: var(--ct-fw-semibold);
}

.campo dd {
  margin-top: 2px;
  font-size: var(--ct-fs-md);
}

@media (max-width: 720px) {
  .campos {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
