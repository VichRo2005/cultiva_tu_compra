<script setup>
/**
 * CuTuCo — Badge de estado unificado.
 * Traduce los enums del esquema (pedido, pago, envío, postulación, reclamo,
 * sanción y apelación) a la etiqueta y el color correspondientes.
 *
 * `type="actual"` representa el estado actual único derivado del pedido y el
 * envío (`estadoActualPedido`), para no mostrar dos estados contradictorios
 * (HAL-VEN-020).
 */
import { computed } from 'vue'
import CtBadge from '@/components/base/CtBadge.vue'
import { LABELS, TONES } from '@/lib/constants'
import { ESTADO_ENVIO_CANCELADO, etiquetaEstadoActual, tonoEstadoActual } from '@/lib/orders'

const props = defineProps({
  type: {
    type: String,
    required: true,
    validator: (v) =>
      [
        'pedido',
        'pago',
        'envio',
        'postulacion',
        'reclamo',
        'sancion',
        'apelacion',
        'rol',
        'cobertura',
        'documento',
        'actual',
      ].includes(v),
  },
  value: { type: String, required: true },
  size: { type: String, default: 'md' },
  dot: { type: Boolean, default: true },
  variant: { type: String, default: 'soft' },
})

const label = computed(() => {
  if (props.type === 'actual') return etiquetaEstadoActual(props.value)
  if (props.type === 'envio' && props.value === ESTADO_ENVIO_CANCELADO) return 'Cancelado'
  return LABELS[props.type]?.[props.value] ?? props.value
})
const tone = computed(() => {
  if (props.type === 'actual') return tonoEstadoActual(props.value)
  if (props.type === 'envio' && props.value === ESTADO_ENVIO_CANCELADO) return 'neutral'
  return TONES[props.type]?.[props.value] ?? 'neutral'
})
</script>

<template>
  <CtBadge :tone="tone" :size="size" :dot="dot" :variant="variant">
    <slot>{{ label }}</slot>
  </CtBadge>
</template>
