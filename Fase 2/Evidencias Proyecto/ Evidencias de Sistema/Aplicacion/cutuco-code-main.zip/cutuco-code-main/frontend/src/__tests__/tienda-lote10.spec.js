/**
 * CuTuCo — Lote 10 (Tienda y productos), lado frontend.
 *
 * CK-0380/0382/0388: validación de nombre/precio/categoría en el formulario.
 * CK-0140 (RF-010): las alertas de stock no son obligación del MVP (aviso explícito).
 * CK-0143/0144: subida de foto sin referencia rota y borrado que limpia el objeto.
 * CK-0489 (HAL-VEN-001): perfil de vendedor dedicado; redirección desde rutas cliente.
 * CK-0490 (HAL-VEN-002): menú/topbar del vendedor sin flujo de compra.
 * CK-0493 (HAL-VEN-005): nombre comercial de símbolos -> mensaje útil, sin error de slug.
 * CK-0494 (HAL-VEN-006): categorías con jerarquía, sin duplicados ni "Sin categoría".
 * CK-0498 (HAL-VEN-010): direcciones con una fuente autorizada + depto_oficina definido.
 * CK-0499 (HAL-VEN-011): vendedor/admin sin métricas de gasto de cliente.
 * CK-0500 (HAL-VEN-012): pestañas sin barra residual innecesaria.
 * CK-0501 (HAL-VEN-013): detalle de producto en modo lectura.
 * CK-0503 (HAL-VEN-015): motivo de pausa/eliminación visible.
 * CK-0504 (HAL-VEN-016): error de autorización claro, sin "Cannot coerce...".
 * CK-0505 (HAL-VEN-017): métricas distinguen autorizado/entregado/fee/neto.
 * CK-0510 (HAL-VEN-022): método de pago y estado separados; sin atribuir DTE a CuTuCo.
 * CK-0511 (HAL-VEN-023): sin frases truncadas ni fotos de entrega descartadas.
 * CK-0512 (HAL-VEN-024): migas legibles en escritorio y móvil.
 * CK-0514 (HAL-VEN-026): límites visibles de precio/stock en formulario.
 */
import { describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'

const supabaseMock = vi.hoisted(() => ({
  getClient: vi.fn(),
  apiFetch: vi.fn(),
  storageUrl: vi.fn((p) => `/storage/${p}`),
}))
vi.mock('@/lib/supabase.js', () => supabaseMock)
const sessionMock = vi.hoisted(() => ({
  currentUserId: vi.fn(async () => 'u-1'),
  unwrap: (r, msg) => { if (r?.error) throw new Error(msg); return r?.data },
}))
vi.mock('@/services/session.js', () => sessionMock)

const src = (p) => readFileSync(`src/${p}`, 'utf8')

describe('CK-0380/0382/0388/0514 · validación del formulario de producto', () => {
  it('reglas del formulario: nombre, precio entero con topes, categoría obligatoria', () => {
    const form = src('views/seller/SellerProductFormView.vue')
    expect(form).toContain("nombre: { required: true, minLength: 3, maxLength: 180 }")
    expect(form).toContain("categoria_id: { required: true }")
    expect(form).toContain("unidad_medida: { required: true, oneOf: UNIDAD_MEDIDA }")
    expect(form).toContain('LIMITES_PRODUCTO.precioMax')
    expect(form).toContain('LIMITES_PRODUCTO.stockMax')
    expect(form).toContain(':min="LIMITES_PRODUCTO.precioMin"')
    expect(form).toContain(':max="LIMITES_PRODUCTO.precioMax"')
    expect(form).toContain(':max="LIMITES_PRODUCTO.stockMax"')
  })

  it('validarNumerosProducto rechaza negativos, precios no enteros y excedentes; BD tiene los mismos topes', async () => {
    const { LIMITES_PRODUCTO, updateProducto } = await import('@/services/seller.js')
    // HAL-VEN-026: tope de stock de negocio a escala campesina (no el técnico 999.999.999 de numeric(12,3))
    expect(LIMITES_PRODUCTO).toMatchObject({ precioMin: 1, precioMax: 999999, stockMin: 0, stockMax: 999999 })
    const q = { select: vi.fn(() => q), eq: vi.fn(() => q), maybeSingle: vi.fn(async () => ({ data: { id: 'p1' }, error: null })), update: vi.fn(() => q) }
    supabaseMock.getClient.mockReturnValue({ from: vi.fn(() => q) })
    await expect(updateProducto('p1', { precio: -5 })).rejects.toThrow(/entero entre 1 y/)
    await expect(updateProducto('p1', { precio: 10.5 })).rejects.toThrow(/entero/)
    await expect(updateProducto('p1', { precio: LIMITES_PRODUCTO.precioMax + 1 })).rejects.toThrow(/entero entre/)
    await expect(updateProducto('p1', { stock: LIMITES_PRODUCTO.stockMax + 1 })).rejects.toThrow(/entre 0 y/)
    expect(q.update).not.toHaveBeenCalled()
    // La migración histórica crea las columnas; la migración de precisión
    // comercial posterior las normaliza a una décima.
    const mig = readFileSync('../supabase/migrations/20261004021917_nuevo_alcance.sql', 'utf8')
    expect(mig).toContain('"precio" numeric(12,2) not null')
    expect(mig).toContain('"stock" numeric(12,3) not null default 0')
  })
})

describe('CK-0140 (RF-010) · alertas de stock no son obligación del MVP', () => {
  it('el formulario declara que no hay alertas de stock bajo en CuTuCo', () => {
    const form = src('views/seller/SellerProductFormView.vue')
    expect(form).toContain('no registra historial de precios ni alertas de stock bajo')
  })
})

describe('CK-0143/0144 · imágenes de producto sin referencias rotas', () => {
  it('si falla el registro de metadata se retira el archivo subido (sin huérfanos)', () => {
    const servicio = src('services/seller.js')
    expect(servicio).toContain('huérfanos')
    expect(servicio).toContain('.remove([ruta])')
  })

  it('el reemplazo/borrado elimina primero el objeto de Storage y luego la fila', () => {
    const servicio = src('services/seller.js')
    const eliminar = servicio.slice(servicio.indexOf('export async function eliminarImagenProducto'))
    expect(eliminar).toContain('.remove([imagen.ruta_storage])')
    expect(eliminar).toContain('No se pudo borrar el archivo de la imagen')
    expect(eliminar.indexOf('.remove(')).toBeLessThan(eliminar.indexOf('.delete()'))
  })
})

describe('CK-0489 (HAL-VEN-001) · perfil de vendedor dedicado', () => {
  it('existe ruta /vendedor/perfil con vista propia y se redirige desde rutas de cliente', () => {
    const router = src('router/index.js')
    expect(router).toContain('HAL-VEN-001')
    expect(router).toContain('SellerProfileView')
    expect(router).toMatch(/vendedor\/perfil/)
  })
})

describe('CK-0490 (HAL-VEN-002) · menú del vendedor sin checkout', () => {
  it('la navegación del vendedor excluye carrito, buscador global y direcciones de compra', () => {
    const nav = src('lib/navigation.js')
    expect(nav).toContain('HAL-VEN-002')
    const topbar = src('components/layout/AppTopbar.vue')
    expect(topbar).toContain('HAL-VEN-002')
  })
})

describe('CK-0493 (HAL-VEN-005) · nombre comercial de símbolos con mensaje útil', () => {
  it('slugTiendaBase devuelve vacío para símbolos y el servicio rechaza antes de PostgREST', async () => {
    const { slugTiendaBase } = await import('@/services/seller.js')
    expect(slugTiendaBase('!!!')).toBe('')
    expect(slugTiendaBase('Huerta Los Ñquis')).toBe('huerta-los-nquis')
    const servicio = src('services/seller.js')
    expect(servicio).toContain('HAL-VEN-005')
    expect(servicio).toMatch(/slug vac[ií]o|no tiene letras/i)
  })
})

describe('CK-0494 (HAL-VEN-006) · jerarquía de categorías sin duplicados', () => {
  it('el filtro arma árbol padre→hijos y excluye categorías de sistema', () => {
    const filtros = src('components/domain/CatalogFilters.vue')
    expect(filtros).toContain('HAL-VEN-006')
    const productos = src('views/seller/SellerProductsView.vue')
    expect(productos).toContain('Árbol de categorías')
    const catalogo = src('services/catalog.js')
    expect(catalogo).toContain('HAL-VEN-006')
  })
})

describe('CK-0498 (HAL-VEN-010) · una fuente autorizada de direcciones', () => {
  it('la vista compartida de direcciones es la única ruta y la tienda define depto_oficina', () => {
    const router = src('router/index.js')
    expect(router).toContain('AddressesView.vue')
    const tienda = src('views/seller/SellerStoreProfileView.vue')
    expect(tienda).toContain('depto_oficina')
    expect(tienda).toContain('deptoOficina')
  })
})

describe('CK-0499 (HAL-VEN-011) · sin métricas de cliente en vendedor/admin', () => {
  it('dashboard de vendedor y vistas admin no muestran "Total gastado"/"Pedidos totales" de cliente', () => {
    for (const v of ['views/seller/SellerDashboardView.vue', 'views/seller/SellerProfileView.vue', 'views/admin/AdminDashboardView.vue']) {
      const c = src(v)
      expect(c).not.toContain('Total gastado')
      expect(c).not.toContain('Pedidos totales')
      expect(c).not.toContain('Vendedores distintos')
    }
    // esas métricas existen sólo en el perfil del cliente
    expect(src('views/client/ClientProfileView.vue')).toContain('Total gastado')
  })
})

describe('CK-0500 (HAL-VEN-012) · pestañas sin barra residual innecesaria', () => {
  it('CtTabs sólo muestra barra cuando hace falta desplazar', () => {
    const tabs = src('components/base/CtTabs.vue')
    expect(tabs).toContain('HAL-VEN-012')
    expect(tabs).toContain('overflow-x')
  })
})

describe('CK-0501 (HAL-VEN-013) · detalle de producto en modo lectura', () => {
  it('la tabla ofrece "Ver detalle" con modal de sólo lectura', () => {
    const vista = src('views/seller/SellerProductsView.vue')
    expect(vista).toContain('Detalle de sólo lectura (HAL-VEN-013)')
    expect(vista).toContain('Ver detalle')
    expect(vista).toContain('detalleProducto')
  })
})

describe('CK-0503 (HAL-VEN-015) · motivo de pausa/eliminación visible', () => {
  it('la fila y el detalle muestran la justificación vigente', () => {
    const vista = src('views/seller/SellerProductsView.vue')
    expect(vista).toContain('justificacionProducto(row)')
    expect(vista).toContain('Justificación de pausa')
    expect(vista).toContain('motivo_pausa')
    expect(vista).toContain('motivo_eliminacion')
  })
})

describe('CK-0504 (HAL-VEN-016) · mensaje de autorización claro', () => {
  it('mensajeErrorProducto traduce PGRST116/coerce/RLS a mensajes claros', async () => {
    const { mensajeErrorProducto } = await import('@/services/seller.js')
    expect(mensajeErrorProducto('Cannot coerce the result to a single JSON object'))
      .toBe('El producto no existe, fue eliminado o no pertenece a tu tienda. No se guardaron cambios.')
    expect(mensajeErrorProducto('new row violates row-level security policy'))
      .toMatch(/permiso|tienda/)
    expect(mensajeErrorProducto('PGRST116')).toMatch(/no pertenece a tu tienda/)
  })
})

describe('CK-0505 (HAL-VEN-017) · métricas que distinguen autorizado/entregado/neto', () => {
  it('el dashboard separa ventas autorizadas, entregadas, fee y neto, con aviso explícito', () => {
    const vista = src('views/seller/SellerDashboardView.vue')
    expect(vista).toContain('netoEntregado')
    expect(vista).toContain('netoAutorizado')
    expect(vista).toContain('Neto al productor (entregado)')
    expect(vista).toContain('no es')
    expect(vista).toContain('sólo suma pedidos entregados')
  })
})

describe('CK-0510 (HAL-VEN-022) · método de pago separado del estado, sin DTE atribuido', () => {
  it('el detalle del pedido rotula "Método de pago" y el estado aparte', () => {
    const vista = src('views/seller/SellerOrderDetailView.vue')
    expect(vista).toContain('HAL-VEN-022')
    expect(vista).toContain('Método de pago')
  })
  it('ninguna vista del vendedor atribuye la emisión del DTE a CuTuCo', () => {
    for (const v of ['views/seller/SellerOrderDetailView.vue', 'views/client/ClientOrderDetailView.vue', 'views/client/PaymentResultView.vue']) {
      const c = src(v)
      expect(c.toLowerCase()).not.toContain('cutuco emitió')
      expect(c.toLowerCase()).not.toContain('cutuco emite el dte')
    }
  })
})

describe('CK-0511 (HAL-VEN-023) · mensajes completos, sin fotos de entrega descartadas', () => {
  it('las vistas de vendedor no mencionan fotografías de entrega descartadas', () => {
    for (const v of ['views/seller/SellerOrdersView.vue', 'views/seller/SellerOrderDetailView.vue', 'views/seller/SellerClaimsView.vue', 'views/client/ClientOrderDetailView.vue']) {
      const c = src(v).toLowerCase()
      expect(c).not.toContain('fotografías descartadas')
      expect(c).not.toContain('fotos descartadas')
    }
    // la ruta de evidencias fotográficas está retirada del router
    const router = src('router/index.js')
    expect(router).not.toContain('SellerEvidenceView')
  })
})

describe('CK-0512 (HAL-VEN-024) · migas legibles en escritorio y móvil', () => {
  it('la miga actual se lee completa en móvil y no se recorta en escritorio', () => {
    const topbar = src('components/layout/AppTopbar.vue')
    expect(topbar).toContain('ct-bar__crumbs')
    expect(topbar).toContain('text-overflow: ellipsis')
    expect(topbar).toContain('display: none') // en móvil sólo se ve la miga actual
  })
})
