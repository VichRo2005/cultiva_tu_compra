import { beforeEach, describe, expect, it, vi } from 'vitest'
import { consulta, admin } from './admin-test-utils'
const sdk = vi.hoisted(() => ({
  from: vi.fn(),
  rpc: vi.fn(),
  auth: { getSession: vi.fn(), getUser: vi.fn() },
}))
vi.mock('@/lib/supabase', () => ({ getClient: () => sdk, tryGetClient: () => sdk }))
beforeEach(() => vi.resetAllMocks())
import { resolverApelacion, filtrarApelaciones } from '@/services/adminApelaciones'
describe('Apelaciones administrativas', () => {
  it.each(['aprobada', 'rechazada'])(
    'resuelve %s conservando fundamento y dejando sincronizar al trigger',
    async (estado) => {
      admin(sdk)
      consulta(sdk, { data: { id: 'a', estado: 'pendiente', sancion_id: 's', productor_id: 'p' } })
      consulta(sdk, { data: { id: 's', accion: 'suspender', estado: 'apelada' } })
      consulta(sdk, { data: null, count: 2 })
      const update = consulta(sdk, { data: { id: 'a', estado } })
      const result = await resolverApelacion('a', estado, ' Fundamento ')
      expect(update.update).toHaveBeenCalledWith(
        expect.objectContaining({ estado, resolucion: 'Fundamento', resuelto_por: 'admin' }),
      )
      expect(result.otrasSancionesVigentes).toBe(estado === 'aprobada' ? 1 : 2)
      expect(sdk.rpc).not.toHaveBeenCalled()
    },
  )
  it('no admite ban por apelación', async () => {
    admin(sdk)
    consulta(sdk, { data: { estado: 'pendiente', sancion_id: 'b' } })
    consulta(sdk, { data: { accion: 'ban_permanente', estado: 'apelada' } })
    await expect(resolverApelacion('a', 'aprobada', 'Motivo')).rejects.toThrow('solo se levanta')
  })
  it('requiere resolución', async () => {
    admin(sdk)
    await expect(resolverApelacion('a', 'aprobada', ' ')).rejects.toThrow('fundamento')
  })
  it('busca usuario, fundamento e id junto con estado', () => {
    const row = {
      id: 'a1',
      estado: 'pendiente',
      fundamento: 'Mi caso',
      sancion: { perfil: { nombre: 'Ana' } },
    }
    for (const texto of ['Ana', 'caso', 'a1'])
      expect(filtrarApelaciones([row], { texto, estado: 'pendiente' })).toEqual([row])
    expect(filtrarApelaciones([row], { estado: 'rechazada' })).toEqual([])
  })
})
