<script setup>
/**
 * CuTuCo — Layout de autenticación (login, registro y recuperación).
 * Panel dividido del diseño: a la izquierda la marca institucional con las
 * métricas de la plataforma, a la derecha el formulario de la vista.
 */
import CtIcon from '@/components/base/CtIcon.vue'
import DevOverlay from '@/dev/DevOverlay.vue'

/*
 * NOTA DE MIGRACIÓN (alcance anterior, ya no se usa): el texto de marca
 * promocionaba "precios públicos con historial" (RF-008, fuera del ERS
 * vigente). Se reemplazó por "precios públicos", que es lo que cubre RF-022.
 */

defineProps({
  title: { type: String, required: true },
  subtitle: { type: String, default: null },
  showBrand: { type: Boolean, default: true },
  fullWidth: { type: Boolean, default: false },
})

const METRICAS = [
  { icon: 'users', value: 'Productores', label: 'Locales, con revisión de antecedentes' },
  { icon: 'shieldCheck', value: 'Webpay Mall', label: 'El pago se dispersa directo al productor' },
  { icon: 'truck', value: 'Despacho', label: 'Estados y código de entrega' },
  { icon: 'phone', value: 'Soporte', label: 'Escríbenos a cutucosoporte@gmail.com' },
]
</script>

<template>
  <div class="auth-layout-root">
    <DevOverlay />
    <div class="auth">
      <aside v-if="showBrand" class="auth__brand">
        <div class="auth__brand-inner">
          <router-link to="/" class="auth__logo" aria-label="CuTuCo, ir al inicio">
            <img class="auth__logo-mark" src="@/assets/logos/Imagotipo_bg.png" alt="CuTuCo" />
            <strong>CuTuCo</strong>
          </router-link>

          <div class="auth__pitch">
            <p class="eyebrow auth__eyebrow">Cultiva tu compra</p>
            <h2 class="auth__headline">Conectando el campo con el mercado.</h2>
            <p class="auth__text">
              Somos una plataforma B2B2C chilena: conectamos a productores locales verificados con
              mayoristas y minoristas, con pago seguro vía Webpay, logística trazable y precios
              públicos. Del predio a la mesa, sin intermediarios.
            </p>
          </div>

          <ul class="auth__metrics">
            <li v-for="metrica in METRICAS" :key="metrica.label" class="auth__metric">
              <span class="auth__metric-icon" aria-hidden="true">
                <CtIcon :name="metrica.icon" :size="18" />
              </span>
              <span class="auth__metric-text">
                <strong>{{ metrica.value }}</strong>
                <span>{{ metrica.label }}</span>
              </span>
            </li>
          </ul>
        </div>
      </aside>

      <main :class="['auth__panel', { 'auth__panel--full': fullWidth }]">
        <div class="auth__panel-inner">
          <router-link
            to="/"
            class="auth__logo auth__logo--inline"
            aria-label="CuTuCo, ir al inicio"
          >
            <img class="auth__logo-mark" src="@/assets/logos/Imagotipo.jpg" alt="CuTuCo" />
            <strong>CuTuCo</strong>
          </router-link>

          <header class="auth__head">
            <h1 class="auth__title">{{ title }}</h1>
            <p v-if="subtitle" class="auth__subtitle">{{ subtitle }}</p>
          </header>

          <slot />
        </div>
      </main>
    </div>
  </div>
</template>

<style scoped>
.auth-layout-root {
  display: contents;
}

.auth {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  min-height: 100vh;
  min-height: 100dvh;
  background: var(--ct-surface);
}

.auth:not(:has(.auth__brand)) {
  grid-template-columns: 1fr;
}

/* --------------------- Panel de marca --------------------- */

.auth__brand {
  background: var(--ct-gradient-auth);
  color: var(--ct-text-invert);
  display: flex;
  align-items: center;
  padding: var(--ct-space-12) clamp(var(--ct-space-8), 5vw, 76px);
}

.auth__brand-inner {
  width: 100%;
  max-width: 520px;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-10);
}

.auth__logo {
  display: inline-flex;
  align-items: center;
  gap: var(--ct-space-3);
  color: var(--ct-text-invert);
  font-size: calc(var(--ct-fs-2xl) * 1.5);
  line-height: 1;
  letter-spacing: -0.03em;
}

.auth__logo:hover {
  text-decoration: none;
  color: var(--ct-text-invert);
  opacity: 0.88;
}

.auth__logo-mark {
  width: 66px;
  height: 66px;
  border-radius: var(--ct-radius-md);
  object-fit: contain;
  background: var(--ct-white);
  padding: 4px;
  flex-shrink: 0;
  box-shadow: var(--ct-shadow-sm);
}

.auth__logo:hover .auth__logo-mark {
  transform: scale(1.06) rotate(-4deg);
}

.auth__eyebrow {
  color: var(--ct-accent);
}

.auth__headline {
  margin-top: var(--ct-space-3);
  font-size: var(--ct-fs-4xl);
  font-weight: var(--ct-fw-bold);
  line-height: 1.12;
  letter-spacing: -0.03em;
  text-wrap: balance;
  color: var(--ct-text-invert);
}

.auth__text {
  margin-top: var(--ct-space-4);
  font-size: var(--ct-fs-base);
  line-height: var(--ct-lh-relaxed);
  color: var(--ct-text-on-dark-soft);
  max-width: 46ch;
}

.auth__metrics {
  list-style: none;
  margin: 0;
  padding: var(--ct-space-6) 0 0;
  border-top: 1px solid rgba(255, 255, 255, 0.3);
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--ct-space-5);
}

.auth__metric {
  display: flex;
  align-items: flex-start;
  gap: var(--ct-space-3);
}

.auth__metric-icon {
  width: 36px;
  height: 36px;
  flex-shrink: 0;
  border-radius: var(--ct-radius-md);
  display: grid;
  place-items: center;
  background: var(--ct-accent);
  color: var(--ct-accent-ink);
}

.auth__metric-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.auth__metric-text strong {
  font-size: var(--ct-fs-lg);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.02em;
  color: var(--ct-text-invert);
}

.auth__metric-text span {
  font-size: var(--ct-fs-sm);
  line-height: 1.45;
  color: var(--ct-text-on-dark-soft);
}

/* --------------------- Panel del formulario --------------------- */

.auth__panel {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--ct-space-12) clamp(var(--ct-space-6), 5vw, 76px);
  background: var(--ct-body-bg);
}

.auth__panel-inner {
  width: 100%;
  max-width: 460px;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-6);
}

.auth__panel--full {
  justify-content: flex-start;
  align-items: flex-start;
  padding: var(--ct-space-6) clamp(var(--ct-space-6), 5vw, 76px) var(--ct-space-8);
}

.auth__panel--full .auth__panel-inner {
  max-width: none;
  width: 100%;
}

.auth__logo--inline {
  display: none;
  color: var(--ct-text);
  font-size: calc(var(--ct-fs-xl) * 1.5);
}

.auth__logo--inline .auth__logo-mark {
  width: 36px;
  height: 36px;
  padding: 3px;
}

.auth__logo--inline:hover {
  color: var(--ct-primary-strong);
}

.auth__head {
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-2);
}

.auth__title {
  font-size: var(--ct-fs-3xl);
  font-weight: var(--ct-fw-bold);
  letter-spacing: -0.03em;
  line-height: var(--ct-lh-tight);
}

.auth__subtitle {
  color: var(--ct-text-soft);
  font-size: var(--ct-fs-md);
  line-height: var(--ct-lh-relaxed);
}

@media (max-width: 900px) {
  .auth {
    grid-template-columns: minmax(0, 1fr);
  }

  .auth__brand {
    display: none;
  }

  .auth__logo--inline {
    display: inline-flex;
  }
}
</style>
