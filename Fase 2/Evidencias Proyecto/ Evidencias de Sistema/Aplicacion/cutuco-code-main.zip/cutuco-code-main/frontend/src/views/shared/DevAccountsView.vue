<script setup>
/**
 * CuTuCo — Cuentas de prueba (SOLO DESARROLLO).
 *
 * Página de apoyo de la galería de vistas (`VITE_DEV_GALLERY=true`): lista las
 * cuentas de `supabase/seed.sql` con su rol, la ventana de inicio y un botón
 * para entrar con esa cuenta sin escribir la contraseña. Sirve para recorrer y
 * gestionar todas las ventanas con los permisos correspondientes.
 *
 * No forma parte del alcance del ERS: se elimina junto con la carpeta `src/dev/`.
 */
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import AuthLayout from '@/layouts/AuthLayout.vue'
import CtAlert from '@/components/base/CtAlert.vue'
import CtBadge from '@/components/base/CtBadge.vue'
import CtButton from '@/components/base/CtButton.vue'
import CtCard from '@/components/base/CtCard.vue'
import CtIcon from '@/components/base/CtIcon.vue'
import { useAuthStore } from '@/stores/auth'
import { useUiStore } from '@/stores/ui'
import {
  autenticarComo,
  DEV_GALLERY_ENABLED,
  DEV_PASSWORD,
  DEV_SESSIONS,
  habilitarSesionAutomatica,
} from '@/dev/devGallery'

const router = useRouter()
const auth = useAuthStore()
const ui = useUiStore()

const entrando = ref(null)
const error = ref(null)

/**
 * Descripción de cada cuenta. Se prefiere la `nota` declarada en la galería para
 * no duplicar el texto cuando cambie.
 */
const DESCRIPCION = {
  admin: 'Permisos completos: usuarios, productos, aprobaciones, sanciones y pagos.',
  vendedor: 'Productor aprobado: inventario, pedidos, entrega con código y pago por Webpay Mall.',
  cliente: 'Compra, direcciones, seguimiento del pedido y calificación.',
  pendiente: 'Solicitud en revisión: sirve para revisar los bloqueos de RF-021.',
}

async function entrar(sesion) {
  entrando.value = sesion.key
  error.value = null
  try {
    habilitarSesionAutomatica()
    await autenticarComo(sesion)
    ui.success(`Sesión iniciada como ${sesion.label}`, sesion.email)
    await router.push(sesion.home ?? '/')
  } catch (e) {
    error.value = e?.message ?? 'No se pudo iniciar sesión con esa cuenta'
  } finally {
    entrando.value = null
  }
}

async function volverAlCatalogo() {
  if (auth.isAuthenticated) await auth.signOut()
  await router.push('/catalogo')
}
</script>

<template>
  <AuthLayout
    title="Cuentas de prueba"
    subtitle="Entra con cualquier cuenta del seed para revisar el sistema completo con sus permisos reales."
  >
    <CtAlert v-if="!DEV_GALLERY_ENABLED" tone="warning" title="Galería desactivada">
      <p>
        Activa <code class="mono">VITE_DEV_GALLERY=true</code> en
        <code class="mono">frontend/.env.local</code> y reinicia el servidor de desarrollo para usar
        esta página.
      </p>
    </CtAlert>

    <CtAlert v-else-if="error" tone="danger" title="No se pudo iniciar sesión">
      <p>{{ error }}</p>
    </CtAlert>

    <div class="cuentas">
      <CtCard v-for="sesion in DEV_SESSIONS" :key="sesion.key" padding="md" class="cuenta">
        <div class="cuenta__cabecera">
          <span class="cuenta__icono" aria-hidden="true">
            <CtIcon :name="sesion.icon" :size="18" />
          </span>
          <div class="cuenta__texto">
            <p class="cuenta__rol">{{ sesion.label }}</p>
            <p class="cuenta__correo mono">{{ sesion.email }}</p>
          </div>
          <CtBadge :tone="auth.user?.email === sesion.email ? 'success' : 'neutral'" size="sm" dot>
            {{ auth.user?.email === sesion.email ? 'En sesión' : 'Disponible' }}
          </CtBadge>
        </div>

        <p class="cuenta__desc">{{ sesion.nota ?? DESCRIPCION[sesion.key] ?? 'Cuenta de revisión.' }}</p>
        <p class="cuenta__inicio">
          Ventana de inicio:
          <router-link :to="sesion.home ?? '/'" class="mono">{{ sesion.home }}</router-link>
        </p>

        <CtButton
          block
          :variant="auth.user?.email === sesion.email ? 'secondary' : 'primary'"
          :loading="entrando === sesion.key"
          @click="entrar(sesion)"
        >
          <template #icon><CtIcon name="logout" :size="16" /></template>
          Entrar como {{ sesion.label }}
        </CtButton>
      </CtCard>
    </div>

    <CtAlert tone="neutral" compact title="Contraseña de todas las cuentas">
      <p>
        <code class="mono">{{ DEV_PASSWORD }}</code> · Estas cuentas sólo existen en el Supabase
        local (supabase/seed.sql).
      </p>
    </CtAlert>

    <div class="acciones">
      <CtButton variant="ghost" to="/catalogo">
        <template #icon><CtIcon name="catalog" :size="16" /></template>
        Ver el catálogo como visitante
      </CtButton>
      <CtButton variant="ghost" @click="volverAlCatalogo">
        <template #icon><CtIcon name="logout" :size="16" /></template>
        Cerrar la sesión actual
      </CtButton>
    </div>

    <p class="pie">
      <router-link to="/login">Ir al inicio de sesión normal</router-link>
    </p>
  </AuthLayout>
</template>

<style scoped>
.cuentas {
  display: grid;
  gap: var(--ct-space-3);
}

.cuenta__cabecera {
  display: flex;
  align-items: center;
  gap: var(--ct-space-3);
}

.cuenta__icono {
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  border-radius: var(--ct-radius);
  background: var(--ct-primary-soft);
  color: var(--ct-primary-strong);
}

.cuenta__texto {
  flex: 1;
  min-width: 0;
}

.cuenta__rol {
  font-weight: var(--ct-fw-semibold);
}

.cuenta__correo {
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
  word-break: break-all;
}

.cuenta__desc {
  margin-block: var(--ct-space-3) var(--ct-space-1);
  font-size: var(--ct-fs-sm);
  color: var(--ct-text-soft);
}

.cuenta__inicio {
  margin-bottom: var(--ct-space-3);
  font-size: var(--ct-fs-xs);
  color: var(--ct-text-muted);
}

.cuenta__inicio a {
  color: var(--ct-primary-strong);
}

.acciones {
  display: flex;
  flex-wrap: wrap;
  gap: var(--ct-space-2);
}

.pie {
  font-size: var(--ct-fs-md);
  color: var(--ct-text-soft);
  text-align: center;
}

.pie a {
  color: var(--ct-primary-strong);
  font-weight: var(--ct-fw-semibold);
}
</style>

