import { describe, expect, it } from 'vitest'
import { adminResult } from '@/services/adminErrores'
import {
  MAX_CARACTERES_PALABRA,
  normalizarPalabra,
  crearPalabraProhibida,
  listPalabrasProhibidas,
} from '@/services/adminModeracion'
import { getClient, prepararCliente, MISSING_ENV, SUPABASE_URL, SUPABASE_ANON_KEY } from '@/lib/supabase'

/**
 * Formulario de palabras prohibidas (RF-004, §11 del mapeo).
 *
 * El bug original: adminErrores mapeaba /prohibid|moderad/ antes de
 * /duplicate key/, y como el nombre de la tabla palabras_prohibidas aparece en
 * TODO error PostgreSQL de esa tabla, un duplicado (uq_palabra_prohibida_lower)
 * se mostraba como "El texto contiene palabras no permitidas". Ahora las reglas
 * específicas van primero y el trigger de moderación se detecta por su mensaje
 * exacto ("palabra prohibida por la moderacion").
 */
describe('mapeo de errores de la moderación', () => {
  it('duplicado de palabra: mensaje "ya está en la lista"', () => {
    expect(() =>
      adminResult({
        error: { message: 'duplicate key value violates unique constraint "uq_palabra_prohibida_lower"' },
      }),
    ).toThrow('Esa palabra ya está en la lista')
  })

  it('comodines: mensaje específico (la BD rechaza % y _)', () => {
    expect(() =>
      adminResult({
        error: {
          message:
            'new row for relation "palabras_prohibidas" violates check constraint "ck_palabra_sin_wildcards"',
        },
      }),
    ).toThrow('comodines % ni _')
  })

  it('trigger de moderación: mensaje de texto no permitido', () => {
    expect(() =>
      adminResult({ error: { message: 'El texto contiene una palabra prohibida por la moderacion' } }),
    ).toThrow('palabras no permitidas')
  })

  it('duplicado genérico de otra tabla sigue siendo genérico', () => {
    expect(() =>
      adminResult({ error: { message: 'duplicate key value violates unique constraint "otra_key"' } }),
    ).toThrow('Ya existe un registro con esos datos.')
  })
})

describe('normalización de palabras', () => {
  it('recorta espacios y unifica en minúsculas', () => {
    expect(normalizarPalabra('  Falsificado ')).toBe('falsificado')
  })

  it('rechaza comodines y longitudes fuera de rango', () => {
    expect(() => normalizarPalabra('con %')).toThrow('comodines')
    expect(() => normalizarPalabra('a')).toThrow('2 caracteres')
    expect(() => normalizarPalabra('x'.repeat(MAX_CARACTERES_PALABRA + 1))).toThrow(
      String(MAX_CARACTERES_PALABRA),
    )
  })
})

/** Batería contra Supabase local: se omite si el stack no responde. */
async function supabaseDisponible() {
  if (MISSING_ENV) return false
  try {
    const respuesta = await fetch(`${SUPABASE_URL}/rest/v1/regiones?select=codigo&limit=1`, {
      headers: { apikey: SUPABASE_ANON_KEY },
    })
    return respuesta.ok || respuesta.status === 401 || respuesta.status === 403
  } catch {
    return false
  }
}

const stackDisponible = await supabaseDisponible()

describe('formulario real contra Supabase local', () => {
  it.skipIf(!stackDisponible)('persiste, deduplica y limpia', async () => {
    await prepararCliente()
    const client = getClient()
    await client.auth.signInWithPassword({ email: 'admin@cutuco.dev', password: 'CutucoDev2026!' })
    const creada = await crearPalabraProhibida('  Prueba-Formulario-E2E ')
    expect(creada.palabra).toBe('prueba-formulario-e2e')
    const lista = await listPalabrasProhibidas()
    expect(lista.some((p) => p.palabra === 'prueba-formulario-e2e')).toBe(true)
    await expect(crearPalabraProhibida('PRUEBA-FORMULARIO-E2E')).rejects.toThrow('ya está en la lista')
    await client.from('palabras_prohibidas').delete().eq('id', creada.id)
  })
})
