import { afterEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import AdminDashboardView from '@/views/admin/AdminDashboardView.vue'

const api = vi.hoisted(() => ({ pendientes: vi.fn(), pagos: vi.fn(), servicios: vi.fn() }))
vi.mock('@/services/admin', () => ({ getPendientesAdmin: api.pendientes }))
vi.mock('@/services/payments', () => ({ listPagos: api.pagos }))
vi.mock('@/services/servicio', () => ({ listServiciosAdmin: api.servicios }))
let wrapper
afterEach(() => { wrapper?.unmount(); vi.resetAllMocks() })

describe('CK-0280: panel administrativo recupera errores', () => {
  it.each(['pendientes', 'servicios'])('informa fallo de %s y permite reintentar', async (origen) => {
    api.pendientes.mockResolvedValue({
      pendientes: { productores: 0, sanciones: 0 },
      postulaciones: [], sanciones: [], operacion: {},
    })
    api.servicios.mockResolvedValue([])
    api.pagos.mockResolvedValue([])
    api[origen].mockRejectedValueOnce(new Error('Consulta no disponible'))
    wrapper = mount(AdminDashboardView, { global: { stubs: { CtChart: true, RouterLink: true } } })
    await flushPromises()
    expect(wrapper.text()).toContain('No se pudo cargar el panel')
    expect(wrapper.text()).toContain('Consulta no disponible')
    expect(wrapper.text()).not.toContain('Postulaciones pendientes')
    const reintentar = wrapper.findAll('button').find((button) => button.text() === 'Reintentar')
    await reintentar.trigger('click')
    await flushPromises()
    expect(wrapper.text()).not.toContain('No se pudo cargar el panel')
    expect(wrapper.text()).toContain('Postulaciones pendientes')
  })

  it('desglosa la misma fuente de Webpay en el KPI y en Operación', async () => {
    api.pendientes.mockResolvedValue({
      pendientes: { productores: 0, sanciones: 0 },
      postulaciones: [],
      sanciones: [],
      operacion: { pedidos: 2, entregados: 1, enCurso: 1 },
    })
    api.servicios.mockResolvedValue([])
    api.pagos.mockResolvedValue([
      { monto: 9500, monto_fee_descontado: 500, creado_en: '2026-11-19T12:00:00Z' },
      { monto: 4750, monto_fee_descontado: 250, creado_en: '2026-11-19T14:00:00Z' },
    ])

    wrapper = mount(AdminDashboardView, { global: { stubs: { CtChart: true, RouterLink: true } } })
    await flushPromises()

    expect(wrapper.text()).toContain('$15.000')
    expect(wrapper.text()).toContain('$14.250')
    expect(wrapper.text()).toContain('$750')
    expect(wrapper.text()).toContain('Neto a comercios')
    expect(wrapper.text()).not.toContain('Accesos del panel')
    // Cada KPI conserva su tamaño: el detalle del monto se abre dentro de
    // la tarjeta y no usa <details>, mientras Operación mantiene sus 3 ayudas.
    expect(wrapper.findAll('.kpi').length).toBeGreaterThanOrEqual(5)
    expect(wrapper.findAll('details').length).toBe(3)
  })
})
