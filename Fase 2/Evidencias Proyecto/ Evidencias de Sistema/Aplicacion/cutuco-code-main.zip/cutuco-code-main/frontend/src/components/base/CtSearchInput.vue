<script setup>
/** CuTuCo — Buscador con iconos y limpieza rápida. */
import CtIcon from './CtIcon.vue'
import CtInput from './CtInput.vue'

defineProps({
  modelValue: { type: String, default: '' },
  placeholder: { type: String, default: 'Buscar…' },
  size: { type: String, default: 'md' },
  autofocus: { type: Boolean, default: false },
})
const emit = defineEmits(['update:modelValue', 'search'])
</script>

<template>
  <CtInput
    :model-value="modelValue"
    :placeholder="placeholder"
    :size="size"
    clearable
    class="ct-search"
    @update:model-value="emit('update:modelValue', $event)"
    @enter="emit('search', modelValue)"
  >
    <template #leading><CtIcon name="search" :size="16" /></template>
  </CtInput>
</template>

<style scoped>
.ct-search {
  width: 100%;
}
</style>
