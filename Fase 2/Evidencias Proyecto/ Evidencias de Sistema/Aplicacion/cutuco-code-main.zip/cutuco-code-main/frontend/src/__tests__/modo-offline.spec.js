/**
 * CuTuCo — Modo demostración solicitado explícitamente para pruebas.
 *
 * Una caída transitoria de Supabase no puede asignar una cuenta demo a quien
 * visita la plataforma. Estas pruebas solicitan el dataset offline de forma
 * explícita para probar las ventanas de desarrollo.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import { getClient, MODO_DEMO, prepararCliente, resetClient } from '@/lib/supabase'
import { DEMO_PASSWORD, OfflineSupabaseClient } from '@/lib/offlineClient'
import { useAuthStore } from '@/stores/auth'
import { ajustarIdsDeGaleria, DEV_IDS, normalizarSesion, sesionParaRuta } from '@/dev/devGallery'

/** Simula un Supabase que no responde (puerto cerrado). */
function sinBaseDeDatos() {
  vi.stubGlobal(
    'fetch',
    vi.fn(() => Promise.reject(new TypeError('Failed to fetch'))),
  )
}

const DEMO_ADMIN = { email: 'admin@cutuco.dev', password: DEMO_PASSWORD }
const prepararDemo = () => prepararCliente({ forzarDemo: true })

beforeEach(() => {
  localStorage.clear()
  sessionStorage.clear()
  setActivePinia(createPinia())
  resetClient()
  sinBaseDeDatos()
})

afterEach(() => {
  vi.unstubAllGlobals()
  resetClient()
})

describe('modo demostración · activación explícita', () => {
  it('mantiene el cliente real cuando la conexión inicial no está disponible', async () => {
    const client = await prepararCliente()
    expect(client).not.toBeInstanceOf(OfflineSupabaseClient)
    expect(getClient()).toBe(client)
    expect(MODO_DEMO.value).toBe(false)
  })

  it('activa el modo demo sólo cuando se solicita para pruebas', async () => {
    expect(MODO_DEMO.value).toBe(false)
    const client = await prepararDemo()
    expect(MODO_DEMO.value).toBe(true)
    expect(client).toBeInstanceOf(OfflineSupabaseClient)
    expect(getClient()).toBe(client)
  })

  it('entra con la cuenta de administración demo sin base de datos', async () => {
    await prepararDemo()
    const auth = useAuthStore()
    await auth.init()
    const perfil = await auth.signIn(DEMO_ADMIN)
    expect(perfil.rol).toBe('admin')
    expect(auth.isAuthenticated).toBe(true)
    expect(auth.isAdmin).toBe(true)
    expect(auth.nombreCompleto).toContain('Administrador')
  })

  it('las cuatro cuentas demo entran y reciben su rol', async () => {
    await prepararDemo()
    const auth = useAuthStore()
    await auth.init()

    const casos = [
      [DEMO_ADMIN, 'admin'],
      [{ email: 'vendedor@cutuco.dev', password: DEMO_ADMIN.password }, 'vendedor'],
      [{ email: 'cliente@cutuco.dev', password: DEMO_ADMIN.password }, 'cliente'],
      [{ email: 'pendiente@cutuco.dev', password: DEMO_ADMIN.password }, 'cliente'],
    ]
    for (const [cuenta, rol] of casos) {
      await auth.signOut()
      const perfil = await auth.signIn(cuenta)
      expect(`${cuenta.email}: ${perfil.rol}`).toBe(`${cuenta.email}: ${rol}`)
    }
  })

  it('el panel del vendedor demo encuentra su productor y catálogo', async () => {
    await prepararDemo()
    const auth = useAuthStore()
    await auth.init()
    await auth.signIn({ email: 'vendedor@cutuco.dev', password: DEMO_ADMIN.password })

    const { getProductorDeSesion, listProductosVendedor, getResumenVentas } = await import('@/services/seller')
    const productor = await getProductorDeSesion()
    expect(productor?.nombre_comercial).toBeTruthy()

    const productos = await listProductosVendedor({ productorId: productor.id })
    expect(productos.length).toBeGreaterThan(0)

    const resumen = await getResumenVentas(productor.id)
    expect(resumen.total).toBeGreaterThan(0)
  })

  it('el panel administrativo obtiene pendientes en modo demo', async () => {
    await prepararDemo()
    const auth = useAuthStore()
    await auth.init()
    await auth.signIn(DEMO_ADMIN)

    const { getPendientesAdmin } = await import('@/services/admin')
    const pendientes = await getPendientesAdmin()
    // Webpay Mall: ya no hay payouts ni custodia en los pendientes.
    expect(pendientes.pendientes.productores).toBeGreaterThan(0)
    expect(typeof pendientes.pendientes.sanciones).toBe('number')
    expect(Array.isArray(pendientes.postulaciones)).toBe(true)
    expect(Array.isArray(pendientes.sanciones)).toBe(true)
    expect(pendientes.operacion.pedidos).toBeGreaterThan(0)
  })

  it('el catálogo responde con productos e imágenes', async () => {
    await prepararDemo()
    const { listProductos, listCategorias } = await import('@/services/catalog')
    const { items, total } = await listProductos({ pageSize: 5 })
    expect(total).toBeGreaterThan(0)
    expect(items[0].productor?.nombre_comercial).toBeTruthy()
    expect(items[0].imagenPrincipal?.url).toBeTruthy()
    expect((await listCategorias()).length).toBeGreaterThan(0)
  })

  it('el cliente demo tiene pedidos con seguimiento', async () => {
    await prepararDemo()
    const auth = useAuthStore()
    await auth.init()
    await auth.signIn({ email: 'cliente@cutuco.dev', password: DEMO_ADMIN.password })

    const { listPedidos } = await import('@/services/orders')
    const { items, total } = await listPedidos({ rol: 'cliente' })
    expect(total).toBeGreaterThan(0)
    // El pedido pagado del dataset demo tiene envío para seguir el delivery.
    const conEnvio = items.find((p) => p.envio)
    expect(conEnvio?.envio?.estado).toBeTruthy()
    // Webpay Mall: el pago existe sólo si quedó autorizado (el dataset demo ya
    // no puede sostener el escrow; se acepta el estado heredado del mock).
    expect(['autorizado', 'retenido']).toContain(conEnvio.pago?.estado)
  })

  it('la galería resuelve cuentas e identificadores en modo demo', async () => {
    await prepararDemo()
    // Acepta clave de rol, correo u objeto; nunca devuelve undefined.
    expect(normalizarSesion('admin')?.email).toBe('admin@cutuco.dev')
    expect(normalizarSesion('cliente@cutuco.dev')?.key).toBe('cliente')
    expect(normalizarSesion({ key: 'vendedor' })?.email).toBe('vendedor@cutuco.dev')
    expect(normalizarSesion(undefined)).toBeNull()
    expect(normalizarSesion({})).toBeNull()

    expect(sesionParaRuta('cliente', { roles: ['admin'] }, '/admin/usuarios')?.key).toBe('admin')

    // Los identificadores de las rutas con parámetro apuntan al dataset demo.
    ajustarIdsDeGaleria()
    const client = getClient()
    expect(DEV_IDS.producto).toBe(client.db.tabla('productos')[0].id)
    expect(DEV_IDS.pedidoEnTransito).toBe(
      client.db.tabla('pedidos').find((p) => p.estado === 'completado')?.id,
    )
  })
})
