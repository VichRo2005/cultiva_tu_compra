import asyncio
import asyncpg

async def test():
    conn = await asyncpg.connect('postgresql://postgres:postgres@127.0.0.1:54322/postgres')
    row = await conn.fetchrow("SELECT id, email, is_sso_user FROM auth.users WHERE email = 'cutuco.admin.base@example.test'")
    print(f'Existing admin: {row}')
    row2 = await conn.fetchrow("SELECT id, email, is_sso_user FROM auth.users WHERE email = 'CUTUCO.ADMIN.BASE@EXAMPLE.TEST'")
    print(f'New user: {row2}')
    await conn.close()

asyncio.run(test())