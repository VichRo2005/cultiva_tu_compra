# CuTuCo — arranque reproducible en cualquier entorno y PC.
#
# Este script se encarga de TODO: descarga e instala (forzadamente, sin importar
# si ya estan descargadas pero con version incompatible) las herramientas y
# dependencias necesarias, y luego levanta todos los componentes de la pagina:
# Supabase (Docker), backend FastAPI, frontend Vite, APIs (Webpay/Transbank,
# Brevo, SRE, datos bancarios) y, opcionalmente, despliegue a GCP (Cloud Run).
#
# Uso:
#   .\dev.ps1 setup           # Instala/fuerza herramientas + dependencias (backend + frontend)
#   .\dev.ps1 up              # Levanta Supabase, migraciones, backend y frontend
#   .\dev.ps1 status          # Muestra el estado de todos los servicios
#   .\dev.ps1 down            # Detiene backend, frontend y Supabase
#   .\dev.ps1 reset-bd        # Recrea la base local y recarga semillas (borra datos)
#   .\dev.ps1 gcp-build       # Build de imagen Docker para Cloud Run (local)
#   .\dev.ps1 gcp-deploy      # Despliega backend a GCP Cloud Run (requiere gcloud autenticado)
#   .\dev.ps1 doctor          # Diagnostico completo del entorno (versiones, puertos, secretos)
#   .\dev.ps1 help            # Ayuda
#
# No necesita activar el venv a mano: el script invoca su python directamente.
# Funciona en Windows, Linux y macOS donde se ejecute el repositorio.

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('setup', 'up', 'down', 'status', 'reset-bd', 'gcp-build', 'gcp-deploy', 'doctor', 'help')]
    [string]$Comando = 'help'
)

$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# Rutas y constantes
# ---------------------------------------------------------------------------
$Raiz = $PSScriptRoot
$Backend = Join-Path $Raiz 'backend'
$Frontend = Join-Path $Raiz 'frontend'
$SupabaseDir = Join-Path $Raiz 'supabase'
$GcpDir = Join-Path $Raiz 'gcp'
$Venv = Join-Path $Backend '.venv'
$PyExe = Join-Path $Venv 'Scripts\python.exe'
$Logs = Join-Path $Raiz 'logs'
$PyVersion = '3.12'
$PyVersionFull = '3.12.*'
$NodeMinMajor = 22
$NodeLtsVersions = @('22.18.0', '24.12.0')
$PuertoBackend = 8000
$PuertoFrontend = 5173
$PuertoSupabaseApi = 54321
$PuertoSupabaseDb = 54322
$PuertoSupabaseStudio = 54323
$PuertoSupabaseInbucket = 54324
$PuertoSupabaseEdgeInspector = 8083
$MigracionPortadaTienda = Join-Path $SupabaseDir 'migrations\20261116000000_portada_tienda.sql'
$MigracionFotoPerfilVendedor = Join-Path $SupabaseDir 'migrations\20261117000000_foto_perfil_vendedor.sql'
$MigracionFotoPerfilCliente = Join-Path $SupabaseDir 'migrations\20261118000000_foto_perfil_cliente.sql'
$MigracionRutSolicitante = Join-Path $SupabaseDir 'migrations\20261119000000_rut_solicitante_disponible.sql'
$MigracionCodigoEntregaSeisDigitos = Join-Path $SupabaseDir 'migrations\20261120000000_codigo_entrega_6_digitos.sql'
$MigracionAvatarClienteEvaluaciones = Join-Path $SupabaseDir 'migrations\20261121000000_avatar_cliente_evaluaciones_publicas.sql'
$MigracionPaginacionEvaluaciones = Join-Path $SupabaseDir 'migrations\20261122000000_paginacion_filtro_evaluaciones_publicas.sql'
$MigracionReglasCantidadProducto = Join-Path $SupabaseDir 'migrations\20261123000000_reglas_cantidad_producto.sql'

# Detectar SO
$EsWindows = $IsWindows
$EsLinux = $IsLinux
$EsMacOS = $IsMacOS

# ---------------------------------------------------------------------------
# Funciones de utilidad
# ---------------------------------------------------------------------------
function Info([string]$mensaje) { Write-Host "[CuTuCo] $mensaje" -ForegroundColor Cyan }
function Ok([string]$mensaje) { Write-Host "   OK  $mensaje" -ForegroundColor Green }
function Aviso([string]$mensaje) { Write-Host "   !   $mensaje" -ForegroundColor Yellow }
function ErrorMsg([string]$mensaje) { Write-Host " ERROR $mensaje" -ForegroundColor Red }
function Fallar([string]$mensaje) {
    ErrorMsg $mensaje
    exit 1
}

function Tiene-Comando([string]$nombre) {
    return [bool](Get-Command $nombre -ErrorAction SilentlyContinue)
}

function Obtener-SO {
    if ($EsWindows) { return 'Windows' }
    if ($EsLinux) { return 'Linux' }
    if ($EsMacOS) { return 'macOS' }
    return 'Desconocido'
}

function Obtener-GestorPaquetes {
    $so = Obtener-SO
    if ($so -eq 'Windows') {
        if (Tiene-Comando 'winget') { return 'winget' }
        if (Tiene-Comando 'choco') { return 'choco' }
        if (Tiene-Comando 'scoop') { return 'scoop' }
        return 'manual'
    }
    if ($so -eq 'macOS') {
        if (Tiene-Comando 'brew') { return 'brew' }
        return 'manual'
    }
    if ($so -eq 'Linux') {
        if (Tiene-Comando 'apt') { return 'apt' }
        if (Tiene-Comando 'dnf') { return 'dnf' }
        if (Tiene-Comando 'pacman') { return 'pacman' }
        if (Tiene-Comando 'zypper') { return 'zypper' }
        return 'manual'
    }
    return 'manual'
}

function Obtener-Npm {
    $comando = Get-Command npm.cmd, npm.exe, npm -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $comando) { Fallar 'npm no esta en el PATH. Instala o activa Node.js 22.18+ o 24.12+.' }
    return $comando.Source
}

function Liberar-Puerto([int]$puerto, [string]$procesoExcluir = $null) {
    $maxIntentos = 5
    for ($i = 0; $i -lt $maxIntentos; $i++) {
        $conexiones = Get-NetTCPConnection -LocalPort $puerto -State Listen -ErrorAction SilentlyContinue
        if (-not $conexiones) { return $true }
        $liberado = $false
        foreach ($c in $conexiones) {
            $dueno = $c.OwningProcess
            if ($dueno -and $dueno -ne $PID -and $dueno -ne $procesoExcluir) {
                try {
                    $proc = Get-Process -Id $dueno -ErrorAction SilentlyContinue
                    if ($proc) {
                        Info "Liberando puerto $puerto (proceso: $($proc.ProcessName), PID: $dueno)"
                        Stop-Process -Id $dueno -Force -ErrorAction SilentlyContinue
                        $liberado = $true
                    }
                } catch { }
            }
        }
        if (-not $liberado) { return $true }
        Start-Sleep -Milliseconds 800
    }
    Aviso "No se pudo liberar el puerto $puerto despues de $maxIntentos intentos"
    return $false
}

function Esperar-Http([string]$url, [int]$segundos = 60, [string]$nombreServicio = 'servicio') {
    $limite = (Get-Date).AddSeconds($segundos)
    $intentos = 0
    while ((Get-Date) -lt $limite) {
        $intentos++
        try {
            $respuesta = Invoke-WebRequest -Uri $url -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
            if ($respuesta.StatusCode -ge 200 -and $respuesta.StatusCode -lt 500) {
                Ok "$nombreServicio respondio en $url (intento $intentos)"
                return $true
            }
        } catch {
            # Silencioso, reintenta
        }
        if ($intentos % 10 -eq 0) {
            Info "Esperando $nombreServicio en $url... (intento $intentos, ${segundos}s totales)"
        }
        Start-Sleep -Milliseconds 500
    }
    ErrorMsg "$nombreServicio NO respondio en $url despues de $segundos segundos ($intentos intentos)"
    return $false
}

function Verificar-CorsCheckout {
    # El frontend consume FastAPI desde otro origen local. Validar el preflight
    # evita que un backend antiguo o una variable FRONTEND_URL incorrecta deje
    # el pago fallando sólo en el navegador.
    # Vite y el usuario pueden abrir el mismo frontend bajo cualquiera de los
    # dos hosts. Ambos son orígenes distintos para el navegador y el retorno
    # Webpay no puede fallar sólo por haber usado 127.0.0.1.
    $origenes = @("http://localhost:$PuertoFrontend", "http://127.0.0.1:$PuertoFrontend")
    foreach ($origen in $origenes) {
        $headers = @{
            Origin = $origen
            'Access-Control-Request-Method' = 'POST'
            'Access-Control-Request-Headers' = 'content-type,authorization'
        }
        try {
            $respuesta = Invoke-WebRequest `
                -Uri "http://127.0.0.1:$PuertoBackend/api/webpay/confirmar" `
                -Method Options `
                -Headers $headers `
                -TimeoutSec 10 `
                -UseBasicParsing `
                -ErrorAction Stop
            $origenPermitido = [string]$respuesta.Headers['access-control-allow-origin']
            $metodos = [string]$respuesta.Headers['access-control-allow-methods']
            if ($respuesta.StatusCode -eq 200 -and $origenPermitido -eq $origen -and $metodos -match 'POST') {
                continue
            }
            ErrorMsg "CORS de checkout inválido para '$origen' (permitido: '$origenPermitido'; métodos: '$metodos')"
            return $false
        } catch {
            ErrorMsg "No se pudo verificar CORS de checkout para '$origen': $($_.Exception.Message)"
            return $false
        }
    }
    return $true
}

function Version-PythonVenv {
    if (-not (Test-Path $PyExe)) { return $null }
    try {
        $version = & $PyExe -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
    } catch {
        return $null
    }
    if ($LASTEXITCODE -ne 0 -or -not $version) { return $null }
    return "$version".Trim()
}

function Version-PythonSistema {
    # En Windows, verificar especificamente py -3.12
    if ($EsWindows -and (Tiene-Comando 'py')) {
        try {
            $version = & py -3.12 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            if ($LASTEXITCODE -eq 0 -and $version -eq '3.12') { return '3.12' }
        } catch { }
    }
    # Fallback: verificar python3/python/py default
    if (-not (Tiene-Comando 'py') -and -not (Tiene-Comando 'python3') -and -not (Tiene-Comando 'python')) { return $null }
    $cmds = @('py', 'python3', 'python')
    foreach ($cmd in $cmds) {
        if (Tiene-Comando $cmd) {
            try {
                $version = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
                if ($LASTEXITCODE -eq 0 -and $version) { return "$version".Trim() }
            } catch { }
        }
    }
    return $null
}

function Version-Node {
    if (-not (Tiene-Comando 'node')) { return $null }
    try {
        $v = & node -v 2>$null
        return $v -replace '^v', ''
    } catch { return $null }
}

function Version-Npm {
    if (-not (Tiene-Comando 'npm')) { return $null }
    try {
        return & npm -v 2>$null
    } catch { return $null }
}

function Version-Docker {
    if (-not (Tiene-Comando 'docker')) { return $null }
    try {
        return & docker version --format '{{.Server.Version}}' 2>$null
    } catch { return $null }
}

function Version-SupabaseCli {
    if (-not (Tiene-Comando 'supabase')) { return $null }
    try {
        return (& supabase --version 2>$null | Select-Object -First 1).Trim()
    } catch { return $null }
}

function Version-Gcloud {
    if (-not (Tiene-Comando 'gcloud')) { return $null }
    try {
        return (& gcloud --version 2>$null | Select-Object -First 1).Trim()
    } catch { return $null }
}

function Supabase-Activo {
    $api = Get-NetTCPConnection -LocalPort $PuertoSupabaseApi -State Listen -ErrorAction SilentlyContinue
    $db  = Get-NetTCPConnection -LocalPort $PuertoSupabaseDb  -State Listen -ErrorAction SilentlyContinue
    return [bool]($api -and $db)
}

function Backend-Activo {
    $conn = Get-NetTCPConnection -LocalPort $PuertoBackend -State Listen -ErrorAction SilentlyContinue
    return [bool]$conn
}

function Frontend-Activo {
    $conn = Get-NetTCPConnection -LocalPort $PuertoFrontend -State Listen -ErrorAction SilentlyContinue
    return [bool]$conn
}

function Docker-Corriendo {
    try {
        $ver = & docker version --format '{{.Server.Version}}' 2>$null
        return ($LASTEXITCODE -eq 0 -and $ver)
    } catch { return $false }
}

function Validar-ArchivoEnvBackend {
    $envPath = Join-Path $Backend '.env'
    if (-not (Test-Path $envPath)) { return @($false, 'backend/.env no existe') }
    $content = Get-Content $envPath -Raw
    $requeridas = @('SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'DATABASE_URL', 'BANK_ENCRYPTION_KEY')
    $faltantes = @()
    foreach ($k in $requeridas) {
        # Get-Content -Raw devuelve un único string: (?m) permite revisar cada
        # línea y \S exige un valor real, no sólo "CLAVE=".
        $patron = "(?m)^\s*$([regex]::Escape($k))\s*=\s*\S"
        if ($content -notmatch $patron) { $faltantes += $k }
    }
    if ($faltantes.Count -gt 0) { return @($false, "Faltan claves en backend/.env: $($faltantes -join ', ')") }
    return @($true, 'OK')
}

function Validar-ArchivoEnvFrontend {
    $envPath = Join-Path $Frontend '.env.local'
    if (-not (Test-Path $envPath)) { return @($false, 'frontend/.env.local no existe') }
    $content = Get-Content $envPath -Raw
    $requeridas = @('VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY', 'VITE_API_BASE_URL')
    $faltantes = @()
    foreach ($k in $requeridas) {
        $patron = "(?m)^\s*$([regex]::Escape($k))\s*=\s*\S"
        if ($content -notmatch $patron) { $faltantes += $k }
    }
    if ($faltantes.Count -gt 0) { return @($false, "Faltan claves en frontend/.env.local: $($faltantes -join ', ')") }
    return @($true, 'OK')
}

function Actualizar-ValoresEnv([string]$ruta, [hashtable]$valores) {
    $lineas = [System.Collections.Generic.List[string]]::new()
    foreach ($linea in Get-Content -LiteralPath $ruta) { [void]$lineas.Add($linea) }

    foreach ($entrada in $valores.GetEnumerator()) {
        $clave = [string]$entrada.Key
        $indice = -1
        $patron = "^\s*$([regex]::Escape($clave))\s*="
        for ($i = 0; $i -lt $lineas.Count; $i++) {
            if ($lineas[$i] -match $patron) {
                $indice = $i
                break
            }
        }

        $nuevaLinea = "$clave=$($entrada.Value)"
        if ($indice -ge 0) {
            $lineas[$indice] = $nuevaLinea
        } else {
            [void]$lineas.Add($nuevaLinea)
        }
    }

    Set-Content -LiteralPath $ruta -Value $lineas -Encoding UTF8
}

# ---------------------------------------------------------------------------
# Instalacion forzada de herramientas del sistema
# ---------------------------------------------------------------------------

function Instalar-Python312 {
    Info 'Verificando Python 3.12 y launcher py'
    $pythonValido = $false

    # En Windows, verificar especificamente py -3.12
    if ($EsWindows -and (Tiene-Comando 'py')) {
        try {
            $version = & py -3.12 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            if ($LASTEXITCODE -eq 0 -and $version -eq '3.12') {
                $pythonValido = $true
                Ok "Python 3.12 detectado via launcher py"
            }
        } catch { }
    }

    # Fallback: verificar version default
    if (-not $pythonValido) {
        $versionSistema = Version-PythonSistema
        if ($versionSistema -eq $PyVersion) {
            $pythonValido = $true
            Ok "Python $versionSistema detectado en el sistema"
        } else {
            Aviso "Python del sistema: $versionSistema (se requiere $PyVersion). Instalacion forzada..."
        }
    }

    $gestor = Obtener-GestorPaquetes
    $so = Obtener-SO

    if (-not $pythonValido) {
        switch ($so) {
            'Windows' {
                if ($gestor -eq 'winget') {
                    Info 'Instalando Python 3.12 via winget...'
                    & winget install Python.Python.3.12 --accept-package-agreements --accept-source-agreements --force 2>$null | Out-Null
                } elseif ($gestor -eq 'choco') {
                    Info 'Instalando Python 3.12 via chocolatey...'
                    & choco install python --version 3.12.* -y --force 2>$null | Out-Null
                } elseif ($gestor -eq 'scoop') {
                    Info 'Instalando Python 3.12 via scoop...'
                    & scoop install python@3.12 2>$null | Out-Null
                } else {
                    Fallar 'No hay gestor de paquetes disponible (winget/choco/scoop). Instala Python 3.12 manualmente desde https://www.python.org/downloads/ marcando la casilla "Add Python to PATH" y "Install launcher (py)", luego reejecuta.'
                }
            }
            'macOS' {
                if ($gestor -eq 'brew') {
                    Info 'Instalando Python 3.12 via Homebrew...'
                    & brew install python@3.12 2>$null | Out-Null
                    & brew link --force python@3.12 2>$null | Out-Null
                } else {
                    Fallar 'Homebrew no disponible. Instala Python 3.12 manualmente.'
                }
            }
            'Linux' {
                switch ($gestor) {
                    'apt' {
                        Info 'Instalando Python 3.12 via apt...'
                        & sudo apt update 2>$null | Out-Null
                        & sudo apt install -y python3.12 python3.12-venv python3.12-dev 2>$null | Out-Null
                    }
                    'dnf' {
                        Info 'Instalando Python 3.12 via dnf...'
                        & sudo dnf install -y python3.12 python3.12-devel 2>$null | Out-Null
                    }
                    'pacman' {
                        Info 'Instalando Python 3.12 via pacman...'
                        & sudo pacman -S --noconfirm python312 2>$null | Out-Null
                    }
                    default { Fallar "Gestor $gestor no soportado para Python. Instala manualmente." }
                }
            }
            default { Fallar "SO $so no soportado para instalacion automatica de Python." }
        }

        # Verificar instalacion
        Start-Sleep -Seconds 2
        $versionSistema = Version-PythonSistema
        if ($versionSistema -eq $PyVersion) {
            $pythonValido = $true
            Ok "Python $versionSistema instalado y verificado"
        } else {
            Fallar "No se pudo instalar Python 3.12 (version detectada: $versionSistema). Instalalo manualmente."
        }
    }

    # Verificar launcher py en Windows
    if ($EsWindows -and -not (Tiene-Comando 'py')) {
        Aviso 'Launcher py no disponible tras instalar Python. Reinstalando...'
        if ($gestor -eq 'winget') {
            & winget install Python.Python.3.12 --accept-package-agreements --accept-source-agreements --force 2>$null | Out-Null
        } elseif ($gestor -eq 'choco') {
            & choco install python --version 3.12.* -y --force 2>$null | Out-Null
        }
        if (-not (Tiene-Comando 'py')) {
            Fallar 'Launcher py sigue sin estar disponible. Reinstala Python 3.12 marcando la casilla del launcher.'
        }
        Ok 'Launcher py detectado'
    }

    return $pythonValido
}

function Instalar-NodeJs {
    Info 'Verificando Node.js y npm'
    $versionNode = Version-Node
    $versionNpm = Version-Npm
    $nodeValido = $false

    if ($versionNode) {
        $major = [int]($versionNode.Split('.')[0])
        if ($major -ge $NodeMinMajor) {
            $nodeValido = $true
            Ok "Node.js $versionNode y npm $versionNpm detectados"
        } else {
            Aviso "Node.js $versionNode es inferior al minimo requerido ($NodeMinMajor.x). Reinstalando..."
        }
    } else {
        Aviso 'Node.js no esta instalado. Instalando...'
    }

    if (-not $nodeValido) {
        $gestor = Obtener-GestorPaquetes
        $so = Obtener-SO

        switch ($so) {
            'Windows' {
                if ($gestor -eq 'winget') {
                    Info 'Instalando Node.js LTS via winget...'
                    & winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements --force 2>$null | Out-Null
                } elseif ($gestor -eq 'choco') {
                    Info 'Instalando Node.js LTS via chocolatey...'
                    & choco install nodejs-lts -y --force 2>$null | Out-Null
                } elseif ($gestor -eq 'scoop') {
                    Info 'Instalando Node.js LTS via scoop...'
                    & scoop install nodejs-lts 2>$null | Out-Null
                } else {
                    Fallar 'No hay gestor de paquetes disponible. Instala Node.js LTS desde https://nodejs.org/'
                }
            }
            'macOS' {
                if ($gestor -eq 'brew') {
                    Info 'Instalando Node.js LTS via Homebrew...'
                    & brew install node@22 2>$null | Out-Null
                    & brew link --force node@22 2>$null | Out-Null
                } else {
                    Fallar 'Homebrew no disponible. Instala Node.js manualmente.'
                }
            }
            'Linux' {
                switch ($gestor) {
                    'apt' {
                        Info 'Instalando Node.js LTS via NodeSource/apt...'
                        & curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - 2>$null | Out-Null
                        & sudo apt install -y nodejs 2>$null | Out-Null
                    }
                    'dnf' {
                        Info 'Instalando Node.js LTS via NodeSource/dnf...'
                        & curl -fsSL https://rpm.nodesource.com/setup_22.x | sudo bash - 2>$null | Out-Null
                        & sudo dnf install -y nodejs 2>$null | Out-Null
                    }
                    'pacman' {
                        Info 'Instalando Node.js LTS via pacman...'
                        & sudo pacman -S --noconfirm nodejs npm 2>$null | Out-Null
                    }
                    default { Fallar "Gestor $gestor no soportado para Node.js. Instala manualmente." }
                }
            }
            default { Fallar "SO $so no soportado para instalacion automatica de Node.js." }
        }

        # Verificar instalacion
        Start-Sleep -Seconds 2
        $versionNode = Version-Node
        $versionNpm = Version-Npm
        if ($versionNode) {
            $major = [int]($versionNode.Split('.')[0])
            if ($major -ge $NodeMinMajor) {
                $nodeValido = $true
                Ok "Node.js $versionNode y npm $versionNpm instalados y verificados"
            } else {
                Fallar "Node.js instalado ($versionNode) no cumple version minima $NodeMinMajor.x"
            }
        } else {
            Fallar 'Node.js no se detecta despues de la instalacion.'
        }
    }

    # Configurar npm para evitar problemas de permisos y cache
    if (Tiene-Comando 'npm') {
        & npm config set fund false 2>$null | Out-Null
        & npm config set audit false 2>$null | Out-Null
        & npm config set prefer-offline false 2>$null | Out-Null
    }

    return $nodeValido
}

function Instalar-Docker {
    Info 'Verificando Docker Desktop / Docker Engine'
    $dockerOk = $false

    if (-not (Tiene-Comando 'docker')) {
        Aviso 'Docker no esta instalado. Es obligatorio para Supabase local y build de imagenes.'
        $gestor = Obtener-GestorPaquetes
        $so = Obtener-SO

        switch ($so) {
            'Windows' {
                if ($gestor -eq 'winget') {
                    Info 'Instalando Docker Desktop via winget...'
                    & winget install Docker.DockerDesktop --accept-package-agreements --accept-source-agreements 2>$null | Out-Null
                } elseif ($gestor -eq 'choco') {
                    Info 'Instalando Docker Desktop via chocolatey...'
                    & choco install docker-desktop -y 2>$null | Out-Null
                } else {
                    Aviso 'Instala Docker Desktop manualmente desde https://www.docker.com/products/docker-desktop/'
                }
            }
            'macOS' {
                if ($gestor -eq 'brew') {
                    Info 'Instalando Docker Desktop via Homebrew...'
                    & brew install --cask docker 2>$null | Out-Null
                } else {
                    Aviso 'Instala Docker Desktop manualmente desde https://www.docker.com/products/docker-desktop/'
                }
            }
            'Linux' {
                switch ($gestor) {
                    'apt' {
                        Info 'Instalando Docker Engine via apt...'
                        & curl -fsSL https://get.docker.com | sudo sh 2>$null | Out-Null
                        & sudo usermod -aG docker $env:USER 2>$null | Out-Null
                        Aviso 'Docker instalado. CIERRE LA SESION y vuelva a entrar para que el grupo docker surta efecto, o ejecute: newgrp docker'
                    }
                    'dnf' {
                        Info 'Instalando Docker Engine via dnf...'
                        & sudo dnf install -y docker docker-compose 2>$null | Out-Null
                        & sudo systemctl enable --now docker 2>$null | Out-Null
                        & sudo usermod -aG docker $env:USER 2>$null | Out-Null
                    }
                    default { Aviso "Gestor $gestor no soportado para Docker. Instala manualmente." }
                }
            }
        }
    }

    # Verificar Docker corriendo
    if (Tiene-Comando 'docker') {
        for ($i = 0; $i -lt 30; $i++) {
            if (Docker-Corriendo) {
                $ver = Version-Docker
                Ok "Docker $ver corriendo"
                $dockerOk = $true
                break
            }
            if ($i -eq 0) { Info 'Esperando a que Docker Desktop/Engine inicie...' }
            Start-Sleep -Seconds 2
        }
    }

    if (-not $dockerOk) {
        if ($EsWindows -or $EsMacOS) {
            Aviso 'Docker Desktop no esta corriendo. Abrelo manualmente, espera a que este listo (icono estable) y vuelve a ejecutar.'
        } else {
            Aviso 'Docker Engine no esta corriendo. Intenta: sudo systemctl start docker'
        }
        return $false
    }
    return $true
}

function Instalar-SupabaseCli {
    Info 'Verificando Supabase CLI'
    $version = Version-SupabaseCli

    if ($version) {
        Ok "Supabase CLI detectado: $version"
        # La configuración vigente requiere Supabase CLI v2 o superior.
        if ($version -match '^(?:[2-9]|[1-9]\d)\.') {
            return $true
        } else {
            Aviso "Supabase CLI $version es anterior a v2. Reinstalando..."
        }
    } else {
        Aviso 'Supabase CLI no esta instalado. Instalando globalmente con npm...'
    }

    # Instalar/forzar una versión compatible via npm.
    if (Tiene-Comando 'npm') {
        & npm.cmd install -g supabase@latest --no-audit --no-fund 2>$null | Out-Null
    } else {
        Fallar 'npm no disponible. Ejecuta setup primero para instalar Node.js.'
    }

    $version = Version-SupabaseCli
    if ($version -and $version -match '^(?:[2-9]|[1-9]\d)\.') {
        Ok "Supabase CLI $version instalado y verificado"
        return $true
    } else {
        Fallar "Supabase CLI no se instalo correctamente (version: $version). Se requiere v2 o superior: npm i -g supabase@latest"
    }
}

function Instalar-Gcloud {
    Info 'Verificando gcloud CLI (opcional, solo para despliegue a GCP)'
    $version = Version-Gcloud

    if ($version) {
        Ok "gcloud CLI detectado: $version"
        return $true
    }

    Aviso 'gcloud CLI no esta instalado (solo requerido para gcp-deploy).'
    $gestor = Obtener-GestorPaquetes
    $so = Obtener-SO

    switch ($so) {
        'Windows' {
            if ($gestor -eq 'winget') {
                Info 'Instalando gcloud via winget...'
                & winget install Google.CloudSDK --accept-package-agreements --accept-source-agreements 2>$null | Out-Null
            } elseif ($gestor -eq 'choco') {
                Info 'Instalando gcloud via chocolatey...'
                & choco install gcloud -y 2>$null | Out-Null
            }
        }
        'macOS' {
            if ($gestor -eq 'brew') {
                Info 'Instalando gcloud via Homebrew...'
                & brew install --cask google-cloud-sdk 2>$null | Out-Null
            }
        }
        'Linux' {
            if ($gestor -eq 'apt') {
                Info 'Instalando gcloud via apt...'
                & echo "deb [signed-by=/usr/share/keyrings/cloud.google.gpg] https://packages.cloud.google.com/apt cloud-sdk main" | sudo tee /etc/apt/sources.list.d/google-cloud-sdk.list 2>$null | Out-Null
                & curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key --keyring /usr/share/keyrings/cloud.google.gpg add - 2>$null | Out-Null
                & sudo apt update 2>$null | Out-Null
                & sudo apt install -y google-cloud-cli 2>$null | Out-Null
            }
        }
    }

    $version = Version-Gcloud
    if ($version) {
        Ok "gcloud CLI $version instalado"
        return $true
    }
    Aviso 'gcloud no se pudo instalar automaticamente. Instalalo desde https://cloud.google.com/sdk/docs/install'
    return $false
}

# ---------------------------------------------------------------------------
# Setup: entorno completo (herramientas + dependencias)
# ---------------------------------------------------------------------------
function Invoke-Setup {
    Info 'Preparando el entorno completo (setup) - instalacion forzada de todo'
    Write-Host ''
    $so = Obtener-SO
    Info "Sistema operativo detectado: $so"

    # 1. Herramientas del sistema (forzadas, version incompatible se reinstala)
    [void](Instalar-Python312)
    [void](Instalar-NodeJs)
    $dockerOk = Instalar-Docker
    [void](Instalar-SupabaseCli)
    [void](Instalar-Gcloud)  # opcional, no falla si falta
    Write-Host ''

    # 2. Entorno virtual Python 3.12 (forzado si la version es incompatible)
    $versionVenv = Version-PythonVenv
    if ((Test-Path $PyExe) -and $versionVenv -ne $PyVersion) {
        Aviso "backend\.venv usa Python $versionVenv y se requiere ${PyVersion}: se recrea forzosamente"
        Remove-Item $Venv -Recurse -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path $PyExe)) {
        Info "Creando entorno virtual en backend\.venv con Python $PyVersion"
        if ($EsWindows) {
            & py "-$PyVersion" -m venv $Venv
        } else {
            & python3.12 -m venv $Venv
        }
        if ($LASTEXITCODE -ne 0) { Fallar 'No se pudo crear el entorno virtual.' }
    } else {
        Ok "Entorno virtual con Python $PyVersion"
    }

    $versionFinal = Version-PythonVenv
    if ($versionFinal -ne $PyVersion) {
        Fallar "El entorno virtual quedo con Python $versionFinal (se esperaba $PyVersion). Borra backend\.venv manualmente y reintenta."
    }

    # 3. Dependencias del backend (forzadas, sin cache, con reintentos)
    Info 'Actualizando pip e instalando dependencias del backend (forzado, sin cache)'
    $pipBaseArgs = @('-m', 'pip', '--no-cache-dir', '--timeout', '120', '--retries', '5')
    & $PyExe @pipBaseArgs install --upgrade pip setuptools wheel --quiet
    if ($LASTEXITCODE -ne 0) { Aviso 'No se pudo actualizar pip; se continua con la version del venv.' }
    Push-Location $Backend
    try {
        & $PyExe @pipBaseArgs install --force-reinstall -r requirements.txt -r requirements-dev.txt
        if ($LASTEXITCODE -ne 0) { Fallar 'Fallo la instalacion de dependencias del backend.' }
    } finally {
        Pop-Location
    }
    Ok 'Dependencias del backend instaladas (runtime + dev, forzado, sin cache)'

    # 4. Variables de entorno backend
    $envExample = Join-Path $Backend '.env.example'
    $envFile = Join-Path $Backend '.env'
    if (-not (Test-Path $envFile)) {
        if (Test-Path $envExample) {
            Copy-Item $envExample $envFile -Force
            Aviso 'Se creo backend\.env desde .env.example: REVISA Y COMPLETA LAS CREDENCIALES.'
        } else {
            Aviso 'No existe backend\.env ni .env.example.'
        }
    } else {
        Ok 'backend\.env presente'
        # Validar claves criticas
        $validacion = Validar-ArchivoEnvBackend
        if (-not $validacion[0]) { Aviso $validacion[1] }
    }

    # 5. Dependencias del frontend (forzadas, limpieza completa)
    if (-not (Tiene-Comando 'npm')) { Fallar 'npm no esta en el PATH. Instala Node.js 22.18+ o 24.12+.' }
    Info 'Instalando dependencias del frontend (forzado, limpieza completa)'
    Push-Location $Frontend
    try {
        # Limpieza forzada para evitar conflictos de version
        if (Test-Path (Join-Path $Frontend 'node_modules')) {
            # Vite puede mantener bloqueados binarios nativos de Tailwind en
            # Windows; se detiene antes de sustituir node_modules.
            [void](Liberar-Puerto $PuertoFrontend)
            Aviso 'Eliminando node_modules existente para reinstalacion forzada...'
            Remove-Item (Join-Path $Frontend 'node_modules') -Recurse -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path (Join-Path $Frontend 'package-lock.json')) {
            Remove-Item (Join-Path $Frontend 'package-lock.json') -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path (Join-Path $Frontend 'pnpm-lock.yaml')) {
            Remove-Item (Join-Path $Frontend 'pnpm-lock.yaml') -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path (Join-Path $Frontend 'yarn.lock')) {
            Remove-Item (Join-Path $Frontend 'yarn.lock') -Force -ErrorAction SilentlyContinue
        }

        # Instalar con npm install (no ci, para regenerar lockfile limpio)
        & npm.cmd install --no-audit --no-fund --force --legacy-peer-deps 2>&1 | Tee-Object -Variable npmOut
        if ($LASTEXITCODE -ne 0) {
            # Ultimo intento sin legacy-peer-deps
            Aviso 'Reintentando sin --legacy-peer-deps...'
            & npm.cmd install --no-audit --no-fund --force 2>&1 | Tee-Object -Variable npmOut
            if ($LASTEXITCODE -ne 0) { Fallar 'Fallo la instalacion de dependencias del frontend.' }
        }
    } finally {
        Pop-Location
    }
    Ok 'Dependencias del frontend instaladas (forzado, lockfile regenerado)'

    # 6. Variables de entorno frontend
    $envLocalExample = Join-Path $Frontend '.env.local.example'
    $envLocalFile = Join-Path $Frontend '.env.local'
    if (-not (Test-Path $envLocalFile)) {
        if (Test-Path $envLocalExample) {
            Copy-Item $envLocalExample $envLocalFile -Force
            Aviso 'Se creo frontend\.env.local desde el ejemplo: REVISA VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY y VITE_API_BASE_URL.'
        }
    } else {
        Ok 'frontend\.env.local presente'
        $validacion = Validar-ArchivoEnvFrontend
        if (-not $validacion[0]) { Aviso $validacion[1] }
    }

    # 7. Crear carpeta de logs
    if (-not (Test-Path $Logs)) { New-Item -ItemType Directory -Path $Logs | Out-Null }

    Write-Host ''
    Ok '========================================'
    Ok '  ENTORNO LISTO -- EJECUTA: .\dev.ps1 up'
    Ok '========================================'
    Write-Host ''
    Write-Host 'Proximos pasos:' -ForegroundColor Cyan
    Write-Host '  1. Revisa y completa backend/.env con tus credenciales (Transbank, Brevo, SRE, BANK_ENCRYPTION_KEY)'
    Write-Host '  2. Revisa y completa frontend/.env.local con VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY (usa `supabase status` tras up)'
    Write-Host '  3. Ejecuta .\dev.ps1 up para levantar todo el stack'
    Write-Host ''
}

# ---------------------------------------------------------------------------
# Up: levantar todos los componentes
# ---------------------------------------------------------------------------
function Invoke-Up {
    Info 'Iniciando levantamiento completo de CuTuCo'
    Write-Host ''

    # 1. Docker (obligatorio)
    $dockerOk = Instalar-Docker
    if (-not $dockerOk) {
        Fallar 'Docker no esta disponible. Es obligatorio para levantar Supabase local. Abre Docker Desktop y reintenta.'
    }

    # 2. Supabase CLI
    [void](Instalar-SupabaseCli)

    # 3. Entorno Python
    if (-not (Test-Path $PyExe)) {
        Fallar 'No existe backend\.venv. Ejecuta primero: .\dev.ps1 setup'
    }

    # 4. Los archivos existen antes de levantar Supabase; las claves se
    # sincronizan recién cuando el stack entrega sus credenciales locales.
    if (-not (Test-Path (Join-Path $Backend '.env'))) {
        Fallar 'No existe backend/.env. Ejecuta primero: .\dev.ps1 setup'
    }
    if (-not (Test-Path (Join-Path $Frontend '.env.local'))) {
        Fallar 'No existe frontend/.env.local. Ejecuta primero: .\dev.ps1 setup'
    }

    # 5. Levantar Supabase (base de datos, Auth, Storage, Realtime, Studio)
    if (Supabase-Activo) {
        Ok 'Supabase ya esta corriendo'
    } else {
        Info 'Levantando Supabase local (la primera vez tarda varios minutos)...'
        Push-Location $SupabaseDir
        try {
            & supabase start
            if ($LASTEXITCODE -ne 0) {
                # Studio puede superar el timeout inicial del health check aunque
                # el resto del stack esté arrancando correctamente. El segundo
                # intento conserva los contenedores y se valida abajo por HTTP.
                Aviso 'Supabase reportó un health check lento. Reintentando sin abortar los contenedores...'
                & supabase start --ignore-health-check
                if ($LASTEXITCODE -ne 0) {
                    Fallar 'No se pudo levantar Supabase. Revisa Docker Desktop y los puertos 54321-54324.'
                }
            }
        } finally {
            Pop-Location
        }

        if (-not (Esperar-Http "http://127.0.0.1:$PuertoSupabaseApi/rest/v1/" 90 'API de Supabase')) {
            Fallar 'La API local de Supabase no quedó disponible después del arranque.'
        }
        if (-not (Esperar-Http "http://127.0.0.1:$PuertoSupabaseStudio" 90 'Supabase Studio')) {
            Fallar 'Supabase Studio no quedó disponible después del arranque.'
        }
        Ok 'Supabase levantado correctamente'
    }

    # 6. Obtener credenciales de Supabase actualizadas y sincronizar .env
    Info 'Sincronizando credenciales de Supabase local con backend/.env y frontend/.env.local...'
    try {
        $supabaseStatus = & supabase status --output json 2>$null | ConvertFrom-Json
        if ($supabaseStatus) {
            $apiUrl = $supabaseStatus.API_URL
            $anonKey = $supabaseStatus.ANON_KEY
            $serviceKey = $supabaseStatus.SERVICE_ROLE_KEY
            $dbUrl = $supabaseStatus.DB_URL
            $jwtSecret = $supabaseStatus.JWT_SECRET

            # Actualizar backend/.env
            if (Test-Path (Join-Path $Backend '.env')) {
                Actualizar-ValoresEnv (Join-Path $Backend '.env') @{
                    SUPABASE_URL = $apiUrl
                    SUPABASE_ANON_KEY = $anonKey
                    SUPABASE_SERVICE_ROLE_KEY = $serviceKey
                    SUPABASE_JWT_SECRET = $jwtSecret
                    DATABASE_URL = $dbUrl
                }
                Ok 'backend/.env actualizado con credenciales de Supabase local'
            }

            # Actualizar frontend/.env.local
            if (Test-Path (Join-Path $Frontend '.env.local')) {
                Actualizar-ValoresEnv (Join-Path $Frontend '.env.local') @{
                    VITE_SUPABASE_URL = $apiUrl
                    VITE_SUPABASE_ANON_KEY = $anonKey
                }
                Ok 'frontend/.env.local actualizado con credenciales de Supabase local'
            }
        }
    } catch {
        Aviso 'No se pudo obtener estado de Supabase para sincronizar .env (continuando...)'
    }

    $validacionBackend = Validar-ArchivoEnvBackend
    if (-not $validacionBackend[0]) { Fallar "backend/.env incompleto: $($validacionBackend[1])" }
    $validacionFrontend = Validar-ArchivoEnvFrontend
    if (-not $validacionFrontend[0]) { Fallar "frontend/.env.local incompleto: $($validacionFrontend[1])" }

    # 7. Aplicar migraciones
    Info 'Aplicando migraciones pendientes de Supabase...'
    # Estas migraciones son contrato de los flujos actuales: perfiles con
    # imágenes, registro de vendedores por RPC, entrega con seis dígitos y
    # reglas comerciales de cantidad por producto.
    $migracionesObligatorias = @(
        $MigracionPortadaTienda,
        $MigracionFotoPerfilVendedor,
        $MigracionFotoPerfilCliente,
        $MigracionRutSolicitante,
        $MigracionCodigoEntregaSeisDigitos,
        $MigracionAvatarClienteEvaluaciones,
        $MigracionPaginacionEvaluaciones,
        $MigracionReglasCantidadProducto
    )
    $migracionFaltante = $migracionesObligatorias | Where-Object { -not (Test-Path $_) } | Select-Object -First 1
    if ($migracionFaltante) {
        Fallar "Falta la migración obligatoria '$([System.IO.Path]::GetFileName($migracionFaltante))'. Actualiza el repositorio antes de iniciar."
    }
    Push-Location $SupabaseDir
    try {
        & supabase migration up --include-all
        if ($LASTEXITCODE -ne 0) {
        Fallar 'No se pudieron aplicar las migraciones. El frontend requiere perfiles, disponibilidad de RUT, código de entrega y reglas de venta para iniciar.'
        }
        Ok 'Migraciones aplicadas: perfiles, reseñas, reglas de venta, disponibilidad de RUT y código de entrega incluidos'
    } finally {
        Pop-Location
    }

    # 7b. Cargar datos de prueba: datos bancarios, imágenes de productos y fotos de perfil
    Info 'Cargando datos de prueba (datos bancarios, imágenes de productos y fotos de perfil)...'
    if (-not (Test-Path $PyExe)) {
        Fallar 'No existe backend\.venv. Ejecuta primero: .\dev.ps1 setup'
    }
    Push-Location $Backend
    try {
        # Datos bancarios (semilla determinista de 6 perfiles)
        & $PyExe -m scripts.seed_datos_bancarios
        if ($LASTEXITCODE -ne 0) { Aviso 'Fallo al cargar datos bancarios; continúa sin ellos.' }
        else { Ok 'Datos bancarios cargados' }

        # Imágenes de productos (WebP conversión + upload a Storage; lee de backend/.env)
        & $PyExe scripts/upload_product_images.py --target local --env-file (Join-Path $Backend '.env')
        if ($LASTEXITCODE -ne 0) { Aviso 'Fallo al cargar imágenes de productos; continúa sin ellas.' }
        else { Ok 'Imágenes de productos cargadas' }
        # Nota: el bucket público store-covers (portadas de tienda) y la columna
        # productores.portada_storage_path los crea la migración
        # 20261116000000_portada_tienda.sql, ya aplicada en el paso anterior.
        # Nota: el bucket seller-avatars (fotos de perfil) y la columna
        # productores.foto_perfil_storage_path los crea la migración
        # 20261117000000_foto_perfil_vendedor.sql, ya aplicada en el paso anterior.
        # Nota: el bucket client-avatars (fotos de perfil) y la columna
        # perfiles.foto_perfil_storage_path los crea la migración
        # 20261118000000_foto_perfil_cliente.sql, ya aplicada en el paso anterior.
    } finally {
        Pop-Location
    }

    # 8. Crear carpeta de logs
    if (-not (Test-Path $Logs)) { New-Item -ItemType Directory -Path $Logs | Out-Null }

    # 9. Liberar puertos backend y frontend
    Info "Liberando puertos $PuertoBackend y $PuertoFrontend..."
    [void](Liberar-Puerto $PuertoBackend)
    [void](Liberar-Puerto $PuertoFrontend)

    # 10. Arrancar backend FastAPI (pagos Webpay, servicio mensual, datos bancarios, SRE, Brevo)
    Info 'Arrancando backend FastAPI...'
    # --reload evita que FastAPI conserve rutas o configuración CORS antiguas
    # después de modificar el backend durante el desarrollo local.
    $backendArgs = @('-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', "$PuertoBackend", '--log-level', 'info', '--reload')
    $backendStart = @{
        FilePath = $PyExe
        ArgumentList = $backendArgs
        WorkingDirectory = $Backend
        RedirectStandardOutput = (Join-Path $Logs 'backend.out.log')
        RedirectStandardError = (Join-Path $Logs 'backend.err.log')
        PassThru = $true
    }
    if ($EsWindows) { $backendStart.WindowStyle = 'Hidden' }
    $backendProc = Start-Process @backendStart

    if (-not (Esperar-Http "http://127.0.0.1:$PuertoBackend/health" 90 'Backend FastAPI')) {
        ErrorMsg "El backend no respondio a /health. Revisa logs\backend.err.log y logs\backend.out.log"
        $ultimasLineas = Get-Content (Join-Path $Logs 'backend.err.log') -Tail 30 -ErrorAction SilentlyContinue
        if ($ultimasLineas) { Write-Host "--- Ultimas lineas de backend.err.log ---" -ForegroundColor Red; $ultimasLineas | Write-Host }
        Fallar 'Backend no iniciado correctamente.'
    } else {
        Ok "Backend en http://127.0.0.1:$PuertoBackend (PID: $($backendProc.Id))"
    }
    if (-not (Verificar-CorsCheckout)) {
        Fallar 'El backend inició sin el CORS requerido por el checkout. Revisa FRONTEND_URL y logs\\backend.err.log.'
    }
    Ok 'CORS de checkout validado para localhost y 127.0.0.1'

    # 11. Arrancar frontend Vite (Vue 3 + SPA)
    Info 'Arrancando frontend Vite...'
    $npmExe = Obtener-Npm
    $frontendStart = @{
        FilePath = $npmExe
        ArgumentList = @('run', 'dev', '--', '--port', "$PuertoFrontend", '--strictPort', '--host', '0.0.0.0')
        WorkingDirectory = $Frontend
        RedirectStandardOutput = (Join-Path $Logs 'frontend.out.log')
        RedirectStandardError = (Join-Path $Logs 'frontend.err.log')
        PassThru = $true
    }
    if ($EsWindows) { $frontendStart.WindowStyle = 'Hidden' }
    $frontendProc = Start-Process @frontendStart

    if (-not (Esperar-Http "http://localhost:$PuertoFrontend" 120 'Frontend Vite')) {
        ErrorMsg "El frontend no respondio. Revisa logs\frontend.out.log y logs\frontend.err.log"
        $ultimasLineas = Get-Content (Join-Path $Logs 'frontend.err.log') -Tail 30 -ErrorAction SilentlyContinue
        if ($ultimasLineas) { Write-Host "--- Ultimas lineas de frontend.err.log ---" -ForegroundColor Red; $ultimasLineas | Write-Host }
        Fallar 'Frontend no iniciado correctamente.'
    } else {
        Ok "Frontend en http://localhost:$PuertoFrontend (PID: $($frontendProc.Id))"
    }

    # 12. Verificacion final de integracion
    Info 'Verificando integracion completa...'
    $integracionOk = $true

    # Verificar backend API docs
    if (-not (Esperar-Http "http://127.0.0.1:$PuertoBackend/docs" 10 'Backend /docs')) {
        Aviso 'Backend /docs no accesible (puede ser normal si no hay ruta)'
    }

    # Verificar Supabase Studio
    if (-not (Esperar-Http "http://127.0.0.1:$PuertoSupabaseStudio" 10 'Supabase Studio')) {
        Aviso 'Supabase Studio no accesible en puerto 54323'
    }

    # 13. Resumen de URLs
    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor Green
    Write-Host '  |  CuTuCo ACTIVO -- Todos los componentes levantados       |' -ForegroundColor Green
    Write-Host '  ============================================================' -ForegroundColor Green
    Write-Host ''
    Write-Host '  Accesos principales:' -ForegroundColor Cyan
    Write-Host "    Web (Frontend SPA)     http://localhost:$PuertoFrontend"
    Write-Host "    API (Backend FastAPI)  http://127.0.0.1:$PuertoBackend"
    Write-Host "    API Salud              http://127.0.0.1:$PuertoBackend/health"
    Write-Host "    API Docs (Swagger)     http://127.0.0.1:$PuertoBackend/docs"
    Write-Host ''
    Write-Host '  Supabase Local:' -ForegroundColor Cyan
    Write-Host "    API                    http://127.0.0.1:$PuertoSupabaseApi"
    Write-Host "    DB (PostgreSQL)        http://127.0.0.1:$PuertoSupabaseDb"
    Write-Host "    Studio                 http://127.0.0.1:$PuertoSupabaseStudio"
    Write-Host "    Inbucket (Email test)  http://127.0.0.1:$PuertoSupabaseInbucket"
    Write-Host ''
    Write-Host '  Componentes integrados y verificados:' -ForegroundColor Cyan
    Write-Host '    [OK] Supabase: PostgreSQL, Auth, Storage (product-images + store-covers + seller-avatars + client-avatars públicos, vendedor-documentos privado), Realtime, Studio, Edge Functions'
    Write-Host '    [OK] Backend FastAPI: Webpay Mall, Webpay Plus Servicio Mensual, Datos Bancarios, SRE, Brevo'
    Write-Host '    [OK] Frontend Vue 3 + Vite: SPA con proxy de retorno Webpay, HMR'
    Write-Host '    [OK] Docker: Contenedores Supabase (Kong, Postgres, Studio, Realtime, Storage, Edge Runtime, Inbucket)'
    Write-Host '    [OK] APIs Externas: Transbank (Webpay), Brevo (SMTP/API), SRE (Autocompletar tributario)'
    Write-Host ''
    Write-Host '  Logs:' -ForegroundColor DarkGray
    Write-Host "    Backend:  $Logs\backend.out.log / .err.log"
    Write-Host "    Frontend: $Logs\frontend.out.log / .err.log"
    Write-Host ''
    Write-Host '  Para detener todo: .\dev.ps1 down' -ForegroundColor DarkGray
    Write-Host '  Para ver estado:   .\dev.ps1 status' -ForegroundColor DarkGray
    Write-Host '  Para diagnostico:  .\dev.ps1 doctor' -ForegroundColor DarkGray
    Write-Host ''
}

# ---------------------------------------------------------------------------
# Down: detener todo
# ---------------------------------------------------------------------------
function Invoke-Down {
    Info 'Deteniendo backend, frontend y Supabase...'

    # Detener procesos por puerto (backend y frontend)
    [void](Liberar-Puerto $PuertoBackend)
    [void](Liberar-Puerto $PuertoFrontend)
    Ok "Puertos $PuertoBackend y $PuertoFrontend liberados"

    # Detener Supabase
    if (Tiene-Comando 'supabase') {
        Info 'Deteniendo Supabase...'
        Push-Location $SupabaseDir
        try {
            & supabase stop
            Ok 'Supabase detenido (los datos quedan en los volumenes de Docker)'
        } catch {
            Aviso 'Error deteniendo Supabase (puede que ya estuviera detenido)'
        } finally {
            Pop-Location
        }
    }

    # Limpiar procesos huerfanos de uvicorn/node/vite relacionados con el proyecto
    $procesos = @('uvicorn', 'vite', 'node')
    foreach ($procName in $procesos) {
        $procs = Get-Process -Name $procName -ErrorAction SilentlyContinue
        foreach ($p in $procs) {
            try {
                $cmdline = $p.StartInfo.Arguments + ' ' + $p.StartInfo.FileName
                if ($cmdline -match [regex]::Escape($Raiz)) {
                    Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
                    Info "Proceso huerfano detenido: $procName (PID: $($p.Id))"
                }
            } catch { }
        }
    }

    Write-Host ''
    Ok 'Todos los componentes detenidos correctamente.'
}

# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
function Invoke-Status {
    Info 'Estado de los servicios CuTuCo'
    Write-Host ''

    # Backend
    if (Backend-Activo) {
        try {
            $salud = (Invoke-WebRequest "http://127.0.0.1:$PuertoBackend/health" -TimeoutSec 3 -UseBasicParsing).Content
            Ok "Backend ($PuertoBackend) -> $salud"
        } catch {
            Aviso "Backend ($PuertoBackend) escucha pero no responde /health"
        }
    } else {
        Aviso "Backend ($PuertoBackend) detenido"
    }

    # Frontend
    if (Frontend-Activo) {
        try {
            $resp = Invoke-WebRequest "http://localhost:$PuertoFrontend" -TimeoutSec 3 -UseBasicParsing
            Ok "Frontend ($PuertoFrontend) -> HTTP $($resp.StatusCode)"
        } catch {
            Ok "Frontend ($PuertoFrontend) escuchando"
        }
    } else {
        Aviso "Frontend ($PuertoFrontend) detenido"
    }

    # Supabase
    if (Supabase-Activo) {
        Ok "Supabase local activo (API $PuertoSupabaseApi, DB $PuertoSupabaseDb, Studio $PuertoSupabaseStudio)"
        try {
            $status = & supabase status --output json 2>$null | ConvertFrom-Json
            if ($status) {
                Write-Host "    API URL: $($status.API_URL)" -ForegroundColor DarkGray
                Write-Host "    DB URL:  $($status.DB_URL)" -ForegroundColor DarkGray
            }
        } catch { }
    } else {
        Aviso 'Supabase detenido'
    }

    # Entorno
    Write-Host ''
    Write-Host 'Entorno:' -ForegroundColor Cyan
    if (Test-Path $PyExe) { Ok "backend\.venv: Python $(Version-PythonVenv)" } else { Aviso 'Falta backend\.venv (ejecuta setup)' }
    if (Tiene-Comando 'docker') { Ok "Docker: $(Version-Docker) $(if (Docker-Corriendo) { '(corriendo)' } else { '(detenido)' })" } else { Aviso 'Docker no disponible' }
    if (Tiene-Comando 'node') { Ok "Node.js: $(Version-Node) | npm: $(Version-Npm)" } else { Aviso 'Node.js no disponible' }
    if (Tiene-Comando 'supabase') { Ok "Supabase CLI: $(Version-SupabaseCli)" } else { Aviso 'Supabase CLI no disponible' }
    if (Tiene-Comando 'gcloud') { Ok "gcloud: $(Version-Gcloud)" } else { Aviso 'gcloud no disponible (opcional)' }

    # Archivos .env
    Write-Host ''
    Write-Host 'Configuracion:' -ForegroundColor Cyan
    $vBackend = Validar-ArchivoEnvBackend
    if ($vBackend[0]) { Ok 'backend/.env: completo' } else { Aviso "backend/.env: $($vBackend[1])" }
    $vFrontend = Validar-ArchivoEnvFrontend
    if ($vFrontend[0]) { Ok 'frontend/.env.local: completo' } else { Aviso "frontend/.env.local: $($vFrontend[1])" }
}

# ---------------------------------------------------------------------------
# Doctor: diagnostico completo
# ---------------------------------------------------------------------------
function Invoke-Doctor {
    Info 'DIAGNOSTICO COMPLETO DEL ENTORNO CuTuCo'
    Write-Host ''

    $script:errores = 0
    $script:avisos = 0

    function Check([string]$nombre, [bool]$condicion, [string]$okMsg, [string]$failMsg, [string]$warnMsg = $null) {
        if ($condicion) {
            Ok "${nombre}: $okMsg"
        } elseif ($warnMsg) {
            Aviso "${nombre}: $warnMsg"
            $script:avisos++
        } else {
            ErrorMsg "${nombre}: $failMsg"
            $script:errores++
        }
    }

    Write-Host '=== SISTEMA ===' -ForegroundColor Cyan
    Check 'SO' ($true) "Detectado: $(Obtener-SO)" 'Desconocido'
    Check 'Directorio del proyecto' (Test-Path $Raiz) "Encontrado: $Raiz" 'No encontrado'

    Write-Host ''
    Write-Host '=== HERRAMIENTAS DEL SISTEMA ===' -ForegroundColor Cyan
    $pySys = Version-PythonSistema
    Check 'Python 3.12 (sistema)' ($pySys -eq $PyVersion) "Version $pySys" "Version $pySys (requerido $PyVersion)" "No detectado"
    Check 'Launcher py (Windows)' ((-not $EsWindows) -or (Tiene-Comando 'py')) 'Disponible' 'No disponible (requerido en Windows)'
    Check 'Node.js' ((Version-Node) -and ([int](Version-Node).Split('.')[0] -ge $NodeMinMajor)) "Version $(Version-Node)" "Version $(Version-Node) (minimo $NodeMinMajor.x)" 'No instalado'
    Check 'npm' (Tiene-Comando 'npm') "Version $(Version-Npm)" 'No disponible' 'No instalado'
    Check 'Docker' (Docker-Corriendo) "Version $(Version-Docker) corriendo" 'No corriendo' 'Instalado pero no corriendo'
    Check 'Supabase CLI' ((Version-SupabaseCli) -and (Version-SupabaseCli -match '^2\.')) "Version $(Version-SupabaseCli)" "Version $(Version-SupabaseCli) (requerido v2.x)" 'No instalado'
    Check 'gcloud CLI' (Tiene-Comando 'gcloud') "Version $(Version-Gcloud) (opcional)" '' 'No instalado (opcional)'

    Write-Host ''
    Write-Host '=== ENTORNO VIRTUAL PYTHON ===' -ForegroundColor Cyan
    $venvVer = Version-PythonVenv
    Check 'backend/.venv existe' (Test-Path $PyExe) 'Encontrado' 'No encontrado (ejecuta setup)'
    Check 'Python en venv' ($venvVer -eq $PyVersion) "Version $venvVer" "Version $venvVer (requerido $PyVersion)" 'No detectado'

    Write-Host ''
    Write-Host '=== DEPENDENCIAS BACKEND ===' -ForegroundColor Cyan
    if (Test-Path $PyExe) {
        try {
            $reqs = Get-Content (Join-Path $Backend 'requirements.txt') | Where-Object { $_ -match '^\w' -and $_ -notmatch '^#' }
            $faltantes = @()
            # Mapa de nombres pip -> nombre de importacion en Python
            $importMap = @{
                'pydantic-settings' = 'pydantic_settings'
                'python-dotenv' = 'dotenv'
                'PyJWT' = 'jwt'
                'python-multipart' = 'multipart'
                'transbank-sdk' = 'transbank'
                'uvicorn' = 'uvicorn'
                'pydantic' = 'pydantic'
                'asyncpg' = 'asyncpg'
                'cryptography' = 'cryptography'
                'httpx' = 'httpx'
                'structlog' = 'structlog'
                'jinja2' = 'jinja2'
                'reportlab' = 'reportlab'
                'tzdata' = 'tzdata'
            }
            foreach ($r in $reqs) {
                $pkgPip = ($r -split '\[|==|>=|<=|>|<|~=')[0]
                $pkgImport = if ($importMap.ContainsKey($pkgPip)) { $importMap[$pkgPip] } else { $pkgPip -replace '-', '_' }
                $chk = & $PyExe -c "import importlib.util; print('OK' if importlib.util.find_spec('$pkgImport') else 'MISSING')" 2>$null
                if ($chk -ne 'OK') { $faltantes += $pkgPip }
            }
            Check 'Paquetes runtime' ($faltantes.Count -eq 0) 'Todos instalados' "Faltantes: $($faltantes -join ', ')"
        } catch {
            Check 'Paquetes runtime' $false '' 'Error verificando'
        }

        try {
            $reqsDev = Get-Content (Join-Path $Backend 'requirements-dev.txt') | Where-Object { $_ -match '^\w' -and $_ -notmatch '^#' }
            $faltantesDev = @()
            $importMapDev = @{
                'pytest-asyncio' = 'pytest_asyncio'
                'pytest-cov' = 'pytest_cov'
                'types-reportlab' = 'reportlab'
                'pytest' = 'pytest'
                'ruff' = 'ruff'
                'mypy' = 'mypy'
            }
            foreach ($r in $reqsDev) {
                $pkgPip = ($r -split '\[|==|>=|<=|>|<|~=')[0]
                $pkgImport = if ($importMapDev.ContainsKey($pkgPip)) { $importMapDev[$pkgPip] } else { $pkgPip -replace '-', '_' }
                $chk = & $PyExe -c "import importlib.util; print('OK' if importlib.util.find_spec('$pkgImport') else 'MISSING')" 2>$null
                if ($chk -ne 'OK') { $faltantesDev += $pkgPip }
            }
            Check 'Paquetes dev' ($faltantesDev.Count -eq 0) 'Todos instalados' "Faltantes: $($faltantesDev -join ', ')"
        } catch {
            Check 'Paquetes dev' $false '' 'Error verificando'
        }
    } else {
        Check 'Dependencias backend' $false '' 'venv no existe'
    }

    Write-Host ''
    Write-Host '=== DEPENDENCIAS FRONTEND ===' -ForegroundColor Cyan
    Check 'node_modules existe' (Test-Path (Join-Path $Frontend 'node_modules')) 'Encontrado' 'No encontrado (ejecuta setup)'
    Check 'package-lock.json existe' (Test-Path (Join-Path $Frontend 'package-lock.json')) 'Encontrado' 'No encontrado (se regenerara en setup)'

    Write-Host ''
    Write-Host '=== ARCHIVOS DE CONFIGURACION ===' -ForegroundColor Cyan
    $vB = Validar-ArchivoEnvBackend
    Check 'backend/.env' $vB[0] 'Completo' $vB[1]
    $vF = Validar-ArchivoEnvFrontend
    Check 'frontend/.env.local' $vF[0] 'Completo' $vF[1]
    Check 'supabase/config.toml' (Test-Path (Join-Path $SupabaseDir 'config.toml')) 'Encontrado' 'No encontrado'

    Write-Host ''
    Write-Host '=== PUERTOS ===' -ForegroundColor Cyan
    Check 'Puerto 8000 (Backend)' (-not (Backend-Activo)) 'Libre' 'OCUPADO' 'En uso por backend'
    Check 'Puerto 5173 (Frontend)' (-not (Frontend-Activo)) 'Libre' 'OCUPADO' 'En uso por frontend'
    Check 'Puerto 54321 (Supabase API)' (-not (Get-NetTCPConnection -LocalPort 54321 -State Listen -ErrorAction SilentlyContinue)) 'Libre' 'OCUPADO' 'En uso por Supabase'
    Check 'Puerto 54322 (Supabase DB)' (-not (Get-NetTCPConnection -LocalPort 54322 -State Listen -ErrorAction SilentlyContinue)) 'Libre' 'OCUPADO' 'En uso por Supabase'
    Check 'Puerto 54323 (Supabase Studio)' (-not (Get-NetTCPConnection -LocalPort 54323 -State Listen -ErrorAction SilentlyContinue)) 'Libre' 'OCUPADO' 'En uso por Supabase'

    Write-Host ''
    Write-Host '=== SUPABASE LOCAL ===' -ForegroundColor Cyan
    if (Supabase-Activo) {
        Check 'Supabase corriendo' $true 'Si' 'No'
        try {
            $status = & supabase status --output json 2>$null | ConvertFrom-Json
            if ($status) {
                Check 'API URL' ($true) $status.API_URL ''
                Check 'DB URL' ($true) $status.DB_URL ''
                Check 'Studio URL' ($true) "http://127.0.0.1:$PuertoSupabaseStudio" ''
            }
        } catch { }
    } else {
        Check 'Supabase corriendo' $false '' 'Detenido' 'Detenido (normal si no hiciste up)'
    }

    Write-Host ''
    Write-Host '=== RESUMEN ===' -ForegroundColor Cyan
    if ($script:errores -eq 0 -and $script:avisos -eq 0) {
        Ok "[OK] TODO OK -- Entorno listo para .\dev.ps1 up"
    } elseif ($script:errores -eq 0) {
        Aviso "[WARN]  $($script:avisos) advertencia(s) -- Funcionara pero revisa los avisos"
    } else {
        ErrorMsg "[ERROR] $($script:errores) error(es) y $($script:avisos) advertencia(s) -- Ejecuta .\dev.ps1 setup para corregir"
    }
    Write-Host ''
}

# ---------------------------------------------------------------------------
# Reset BD
# ---------------------------------------------------------------------------
function Invoke-ResetBd {
    $dockerOk = Instalar-Docker
    if (-not $dockerOk) { Fallar 'Docker no esta disponible para resetear la base.' }
    [void](Instalar-SupabaseCli)
    Aviso '[WARN]  ESTO BORRA LA BASE LOCAL Y RECARGA MIGRACIONES + SEMILLAS.'
    $confirmacion = Read-Host 'Escribe SI (mayusculas) para confirmar'
    if ($confirmacion -ne 'SI') { Aviso 'Cancelado'; return }
    Info 'Reseteando base de datos local...'
    Push-Location $SupabaseDir
    try {
        & supabase db reset
        if ($LASTEXITCODE -ne 0) { Fallar 'Fallo supabase db reset.' }
        Ok 'Base local recreada y semillas cargadas'
    } finally {
        Pop-Location
    }
}

# ---------------------------------------------------------------------------
# GCP build (local Docker build para Cloud Run)
# ---------------------------------------------------------------------------
function Invoke-GcpBuild {
    Info 'Construyendo imagen Docker del backend para Cloud Run'
    $dockerOk = Instalar-Docker
    if (-not $dockerOk) { Fallar 'Docker es obligatorio para gcp-build.' }

    # Verificar que backend/.env no tiene valores locales
    $envContent = Get-Content (Join-Path $Backend '.env') -Raw -ErrorAction SilentlyContinue
    if ($envContent -match 'localhost|127\.0\.0\.1') {
        Aviso 'backend/.env contiene referencias a localhost/127.0.0.1. Esto es normal para desarrollo local.'
        Aviso 'Para produccion, los secretos en GCP Secret Manager DEBEN tener valores de produccion (ver gcp/secrets-map.md).'
    }

    & docker build -f backend/Dockerfile -t cutuco-backend:local backend
    if ($LASTEXITCODE -ne 0) { Fallar 'Fallo el build de Docker.' }
    Ok 'Imagen cutuco-backend:local construida correctamente.'
    Write-Host ''
    Write-Host 'Para desplegar a GCP Cloud Run:' -ForegroundColor Cyan
    Write-Host '  1. Autentica gcloud: gcloud auth login && gcloud config set project cutuco-test'
    Write-Host '  2. Crea/actualiza secretos en Secret Manager (ver gcp/secrets-map.md)'
    Write-Host '  3. Ejecuta: .\dev.ps1 gcp-deploy'
    Write-Host '  O bien usa el script directo: bash gcp/deploy-backend.sh'
    Write-Host ''
}

# ---------------------------------------------------------------------------
# GCP deploy (requiere gcloud autenticado)
# ---------------------------------------------------------------------------
function Invoke-GcpDeploy {
    Info 'Desplegando backend a GCP Cloud Run'
    $gcloudOk = Instalar-Gcloud
    if (-not $gcloudOk) { Fallar 'gcloud CLI es obligatorio para gcp-deploy. Instalalo y autenticate: gcloud auth login' }
    if (-not (Tiene-Comando 'bash')) {
        Fallar 'gcp-deploy requiere Bash para ejecutar gcp/deploy-backend.sh. En Windows instala Git for Windows y abre una nueva terminal.'
    }

    # Verificar autenticacion
    $token = & gcloud auth print-identity-token 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $token) {
        Fallar 'gcloud no esta autenticado. Ejecuta: gcloud auth login && gcloud config set project cutuco-test'
    }

    # Verificar proyecto
    $proyecto = & gcloud config get-value project 2>$null
    if ($proyecto -ne 'cutuco-test') {
        Aviso "Proyecto gcloud actual: $proyecto (esperado: cutuco-test)"
        $cambiar = Read-Host "Cambiar a proyecto 'cutuco-test'? (S/N)"
        if ($cambiar -eq 'S' -or $cambiar -eq 's') {
            & gcloud config set project cutuco-test
        } else {
            Fallar 'Despliegue cancelado. Configura el proyecto correcto.'
        }
    }

    # Todos los secretos referenciados por Cloud Run deben existir antes de
    # construir la imagen. No se imprimen valores: pueden ser credenciales.
    Info 'Verificando secretos en Secret Manager...'
    $secretosCloudRun = @(
        'SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'DATABASE_URL',
        'TRANSBANK_COMMERCE_CODE', 'TRANSBANK_FEE_COMMERCE_CODE', 'TRANSBANK_MALL_SELLER_COMMERCE_CODE',
        'TRANSBANK_API_KEY', 'TRANSBANK_RETURN_URL',
        'TRANSBANK_SERVICIO_COMMERCE_CODE', 'TRANSBANK_SERVICIO_API_KEY', 'TRANSBANK_SERVICIO_RETURN_URL',
        'BREVO_API_KEY', 'BREVO_SMTP_LOGIN', 'BREVO_SMTP_KEY', 'FRONTEND_URL', 'BANK_ENCRYPTION_KEY',
        'SRE_TOKEN_PUBLICO'
    )
    $secretosOpcionales = @('BREVO_SMTP_LOGIN', 'BREVO_SMTP_KEY')
    $problemas = @()
    $valoresSecretos = @{}
    foreach ($s in $secretosCloudRun) {
        $valor = (& gcloud secrets versions access latest --secret=$s --project=cutuco-test 2>$null | Out-String).TrimEnd("`r", "`n")
        if ($LASTEXITCODE -ne 0) {
            $problemas += "$s no existe o no tiene una versión accesible"
            continue
        }
        if ([string]::IsNullOrWhiteSpace($valor) -and $s -notin $secretosOpcionales) {
            $problemas += "$s no tiene una versión con valor"
            continue
        }
        $valoresSecretos[$s] = $valor
        if ($valor -match 'localhost|127\.0\.0\.1|\[::1\]') {
            $problemas += "$s contiene una dirección local"
        }
    }
    if (
        $valoresSecretos.ContainsKey('TRANSBANK_COMMERCE_CODE') -and
        $valoresSecretos['TRANSBANK_MALL_SELLER_COMMERCE_CODE'] -eq $valoresSecretos['TRANSBANK_COMMERCE_CODE']
    ) {
        $problemas += 'TRANSBANK_MALL_SELLER_COMMERCE_CODE no puede ser igual al comercio padre'
    }
    if ($problemas.Count -gt 0) {
        ErrorMsg 'SECRETOS CON PROBLEMAS (corrige antes de desplegar):'
        $problemas | ForEach-Object { ErrorMsg "  - $_" }
        Fallar 'Despliegue abortado. Ver gcp/secrets-map.md para valores de produccion.'
    }
    Ok 'Secretos de Cloud Run verificados (presentes, sin valores locales y con comercio hijo válido)'

    Info 'Ejecutando gcp/deploy-backend.sh...'
    Push-Location $GcpDir
    try {
        & bash ./deploy-backend.sh
        if ($LASTEXITCODE -ne 0) { Fallar 'Fallo el despliegue a GCP Cloud Run.' }
    } finally {
        Pop-Location
    }
    Ok 'Despliegue a GCP Cloud Run completado exitosamente.'
}

# ---------------------------------------------------------------------------
# Help
# ---------------------------------------------------------------------------
function Invoke-Help {
    Write-Host 'CuTuCo -- comandos disponibles' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  .\dev.ps1 setup       Instala/fuerza herramientas (Python 3.12, Node.js LTS, Docker, Supabase CLI v2, gcloud)'
    Write-Host '                        e instala dependencias de backend y frontend (forzado, sin cache, lockfile limpio).'
    Write-Host '  .\dev.ps1 up          Levanta Supabase + migraciones + backend FastAPI + frontend Vite (verificacion de salud completa).'
    Write-Host '  .\dev.ps1 status      Estado detallado de todos los servicios, puertos, entorno y configuracion.'
    Write-Host '  .\dev.ps1 down        Detiene backend, frontend y Supabase (conserva volumenes Docker).'
    Write-Host '  .\dev.ps1 reset-bd    Recrea la base local y recarga semillas (BORRA DATOS, confirma con SI).'
    Write-Host '  .\dev.ps1 gcp-build   Construye imagen Docker local para Cloud Run (validacion).'
    Write-Host '  .\dev.ps1 gcp-deploy  Despliega backend a GCP Cloud Run (requiere gcloud autenticado y secretos en Secret Manager).'
    Write-Host '  .\dev.ps1 doctor      Diagnostico completo: versiones, puertos, dependencias, configs, Supabase, secretos.'
    Write-Host '  .\dev.ps1 help        Esta ayuda.'
    Write-Host ''
    Write-Host '  Caracteristicas clave:' -ForegroundColor Cyan
    Write-Host '    * Instalacion FORZADA: reinstala herramientas si la version es incompatible'
    Write-Host '    * Multi-SO: Windows (winget/choco/scoop), macOS (brew), Linux (apt/dnf/pacman)'
    Write-Host '    * Sincroniza automaticamente credenciales de Supabase local con .env files'
    Write-Host '    * Verificacion de salud completa (HTTP + timeouts generosos + logs)'
    Write-Host '    * Doctor integrado para diagnosticar cualquier problema'
    Write-Host '    * Limpieza completa de node_modules/lockfiles en setup'
    Write-Host '    * Validacion de secretos GCP antes de deploy (faltantes, localhost y comercio hijo Mall)'
    Write-Host ''
    Write-Host '  Documentacion completa: DEPLOY.md' -ForegroundColor DarkGray
    Write-Host ''
}

# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------
switch ($Comando) {
    'setup'      { Invoke-Setup }
    'up'         { Invoke-Up }
    'down'       { Invoke-Down }
    'status'     { Invoke-Status }
    'reset-bd'   { Invoke-ResetBd }
    'gcp-build'  { Invoke-GcpBuild }
    'gcp-deploy' { Invoke-GcpDeploy }
    'doctor'     { Invoke-Doctor }
    default      { Invoke-Help }
}
