# cutuco-code

CuTuCo (Cultiva Tu Compra) — Marketplace SaaS B2B2C de comercio de proximidad.
Reingeniería del MVP móvil (Ionic + Angular + SQLite) hacia una solución web
desacoplada: **Vue.js + Vite** en el frontend, **FastAPI** para las reglas de
negocio y **PostgreSQL/Supabase** (Auth, PostgREST, Storage y RLS) para datos y
autenticación.

```
cutuco-code/
├── frontend/     SPA Vue 3 + Vite (Vercel)          -> ver frontend/README.md
├── backend/      FastAPI + Docker (Cloud Run)       -> pagos, payouts y correos
├── supabase/     Migraciones y seed (PostgreSQL)    -> esquema y datos de prueba
└── DEPLOY.md     Guía paso a paso de despliegue local
```

## Estado del frontend

Alineado con los **22 requisitos funcionales vigentes** del ERS (RF-001 a
RF-007, RF-009, RF-011, RF-012, RF-014, RF-017 a RF-027). Fuera de alcance y no
implementados: RF-008 (historial de precios), RF-010 (alertas de stock bajo),
RF-013 (múltiples administradores), RF-015 (retención del carnet) y RF-016
(rate limiting propio).

El detalle de la alineación —por requisito, archivo y servicio— está en
[`frontend/GUIA-ALINEACION-ERS.md`](frontend/GUIA-ALINEACION-ERS.md) y el
contrato del flujo de pago en
[`frontend/src/views/client/CONTRATO-PAGO.md`](frontend/src/views/client/CONTRATO-PAGO.md).

## Puesta en marcha

Resumen; el detalle está en [`DEPLOY.md`](DEPLOY.md).

```bash
supabase start                                  # base de datos, auth y storage
cd backend && uvicorn app.main:app --port 8000  # API de pagos (RF-005)
cd frontend && npm install --legacy-peer-deps && npm run dev
```

---

## Preparación del entorno en Windows (WSL y Docker)

Importante para docker instalar archivos del Kernel de Linux
Abrir powershell en modo administrador y ejecutar lo siguiente(Desactivar VPN):

wsl --install

Crear cuenta respondiendo las siguientes preguntas:

Create a default Unix user account: "Inventa tu usuario"
Create New password: "Escribe tu contraseña"
Retype new password: "Escribe tu contraseña"

Responder con "y" o "n" a la siguiente pregunta:

Would you like to opt-in to platform metrics collection (Y/n)? To see an example of the data collected, enter 'e'.
[Y/n/e]: e
{
  "insightsVersion": "0.9.3ubuntu",
  "collectionTime": 1790816668,
  "systemInfo": {
    "hardware": {
      "cpu": {
        "name": "12th Gen Intel(R) Core(TM) i5-1235U",
        "vendor": "GenuineIntel",
        "architecture": "x86_64",
        "cpus": 12,
        "sockets": 1,
        "coresPerSocket": 6,
        "threadsPerCore": 2
      },
      "memory": {
        "size": 3769
      },
      "disks": [
        {
          "size": 722,
          "type": "disk"
        },
        {
          "size": 96,
          "type": "disk"
        },
        {
          "size": 1024,
          "type": "disk"
        },
        {
          "size": 1048576,
          "type": "disk"
        }
      ]
    },
    "software": {
      "os": {
        "family": "linux",
        "distribution": "Ubuntu",
        "version": "26.04"
      },
      "timezone": "-03",
      "language": "C"
    },
    "platform": {
      "wsl": {
        "subsystemVersion": 2,
        "systemd": "used",
        "interop": "enabled",
        "version": "3.0.1.0",
        "kernelVersion": "6.18.40.1-microsoft-standard-WSL2"
      }
    }
  }
}


Despues de esto se instalaron los archivos del Kernel de Linux 
Al final instalar la mejor version de docker para su pc en el siguiente enlace:

https://docs.docker.com/desktop/setup/install/windows-install/