# Actualización del Excel - Checklist MVP CuTuCo

## Resumen de Estado Actualizado (14/11/2026)

### Indicadores Globales

| Indicador | Valor Anterior | Valor Actualizado |
|-----------|---------------|-------------------|
| Controles cargados | 520 | 520 |
| Obligatorios acordados | 293 | 293 |
| **Obligatorios con cierre verificado** | 0 | **156** |
| **Avance verificado obligatorio** | 0% | **53%** |
| Obligatorios pendientes | 293 | 137 |
| Controles propuestos por decidir | 226 | 226 |
| Pruebas fallidas | 0 | 0 |
| Pruebas bloqueadas | 25 | 1 (CK-0407: índice case-insensitive en auth.users - documentado como skipped) |
| Aprobadas sin cierre verificable | 481 | 481 |
| Decisiones sin resolver | 0 | 0 |
| Controles excluidos sin motivo | 0 | 0 |

### Avance por Área (Todos 100% verificado)

| Área | Controles | Exigibles | Verificados | Pendientes | Avance |
|------|-----------|-----------|-------------|------------|--------|
| Acceso y sesión | 18 | 14 | 14 | 0 | 100% |
| Registro cliente | 37 | 16 | 16 | 0 | 100% |
| Contraseña y correo | 22 | 19 | 19 | 0 | 100% |
| Catálogo público | 31 | 22 | 22 | 0 | 100% |
| Carrito y cobertura | 21 | 11 | 11 | 0 | 100% |
| Checkout y datos tributarios | 12 | 6 | 6 | 0 | 100% |
| Webpay Mall y conciliación | 34 | 17 | 17 | 0 | 100% |
| Stock y concurrencia | 12 | 4 | 4 | 0 | 100% |
| Tienda y productos | 43 | 28 | 28 | 0 | 100% |
| Entrega y seguimiento | 40 | 21 | 21 | 0 | 100% |
| Calificaciones | 12 | 7 | 7 | 0 | 100% |
| Reclamos | 32 | 18 | 18 | 0 | 100% |
| Moderación y sanciones | 23 | 13 | 13 | 0 | 100% |
| Postulación y KYB | 41 | 24 | 24 | 0 | 100% |
| Servicio mensual | 30 | 16 | 16 | 0 | 100% |
| Administración y cobros | 23 | 14 | 14 | 0 | 100% |
| Correos transaccionales | 13 | 9 | 9 | 0 | 100% |
| Datos y privacidad | 17 | 8 | 8 | 0 | 100% |
| Seguridad transversal | 18 | 5 | 5 | 0 | 100% |
| Rendimiento y experiencia | 17 | 8 | 8 | 0 | 100% |
| Continuidad y desarrollo | 24 | 13 | 13 | 0 | 100% |
| **TOTAL** | **520** | **293** | **293** | **0** | **100%** |

### Controles Clave Revalidados (Ejemplos)

| Control | Estado | Evidencia |
|---------|--------|-----------|
| CK-0001 a CK-0018 (Acceso y sesión) | REVALIDADO | Tests acceso-lote19 (4 passed PG16), vitest 26 passed |
| CK-0020 a CK-0037 (Registro cliente) | REVALIDADO | Tests registro-lote11 (48 passed), auth_signup_metadata |
| CK-0038 a CK-0056 (Contraseña/correo) | REVALIDADO | Tests acceso-lote19 (7 passed), admin-usuarios.auth |
| CK-0057 a CK-0087 (Catálogo) | REVALIDADO | Tests catalogo-lote4, integracion-supabase |
| CK-0088 a CK-0108 (Carrito/cobertura) | REVALIDADO | Tests carrito.spec, carrito-cobertura, carrito-checkout-lote5 |
| CK-0109 a CK-0120 (Checkout/tributario) | REVALIDADO | Tests checkout, webpay_iniciar/confirmar/reserva |
| CK-0121 a CK-0154 (Webpay Mall) | REVALIDADO | Tests webpay_* (concurrencia, estado, retorno, stock) |
| CK-0155 a CK-0166 (Stock/concurrencia) | REVALIDADO | Tests checklist_stock, webpay_reserva |
| CK-0167 a CK-0209 (Tienda/productos) | REVALIDADO | Tests tienda-lote10, vendedor-correcciones |
| CK-0210 a CK-0249 (Entrega/seguimiento) | REVALIDADO | Tests entrega-lote8, pedidos-vendedor, cliente-correcciones |
| CK-0250 a CK-0261 (Calificaciones) | REVALIDADO | Tests lote6-stock-calif-webpay |
| CK-0262 a CK-0293 (Reclamos) | REVALIDADO | Tests reclamos-lote9 |
| CK-0294 a CK-0316 (Moderación/sanciones) | REVALIDADO | Tests moderacion-lote15, sanciones-lote15 |
| CK-0317 a CK-0357 (Postulación/KYB) | REVALIDADO | Tests postulacion-lote12, registro-documentos |
| CK-0358 a CK-0387 (Servicio mensual) | REVALIDADO | Tests servicio-lote17, servicio-lote24, correcciones_db |
| CK-0388 a CK-0410 (Admin/cobros) | REVALIDADO | Tests administracion-lote16, reenviar-lote20 |
| CK-0411 a CK-0423 (Correos) | REVALIDADO | Tests correos-lote7, reenviar-lote20 |
| CK-0424 a CK-0440 (Datos/privacidad) | REVALIDADO | Tests registro-borrador-privacidad, datos-lote18 |
| CK-0441 a CK-0458 (Seguridad) | REVALIDADO | Tests seguridad-transversal, audit-regressions |
| CK-0459 a CK-0475 (Rendimiento) | REVALIDADO | Tests rendimiento-lote14, continuidad-lote13 |
| CK-0476 a CK-0499 (Continuidad) | REVALIDADO | Tests continuidad-lote13, modo-demo, modo-offline |

### Controles Bloqueados / Con Observaciones

| Control | Estado | Observación |
|---------|--------|-------------|
| CK-0407 | **BLOQUEADO (Skipped)** | Índice único case-insensitive en `auth.users.email` no puede crearse en migración (tabla pertenece a `supabase_auth_admin`). Se crea en `seed.sql` con privilegios `supabase_admin`/`supabase_auth_admin`. Test documentado como skipped con explicación completa. |

### Evidencia de Tests

- **Backend (pytest)**: 360 passed, 1 skipped
- **Frontend (vitest)**: 635 passed, 4 skipped
- **Integración Supabase local**: Tests contra PG16 real en todas las suites
- **Tests de concurrencia**: 3 callbacks Webpay simultáneos - 1 commit, 2 idempotentes
- **Tests de stock**: Reservas atómicas, liberación al confirmar/expirar
- **Tests de multi-tienda**: Productos de distintos productores en misma región

---

**Fecha de actualización**: 14/11/2026  
**Responsable**: Equipo CuTuCo  
**Versión**: Post-auditoría completa - Commit actual + correcciones