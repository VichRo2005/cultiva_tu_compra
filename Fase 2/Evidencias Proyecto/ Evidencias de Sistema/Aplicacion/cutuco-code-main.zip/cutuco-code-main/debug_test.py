import asyncio
import asyncpg
import json
from uuid import UUID

ADMIN = UUID("a0000000-0000-0000-0000-000000000001")
PERFIL_P1 = UUID("a0000000-0000-0000-0000-000000000102")
PRODUCTOR_P1 = UUID("20000000-0000-0000-0000-000000000002")
PRODUCTO_P1 = UUID("30000000-0000-0000-0000-000000000101")

async def autenticar(conn, usuario):
    await conn.execute("RESET ROLE")
    await conn.execute(
        "SELECT set_config('request.jwt.claims',$1,true)",
        json.dumps({"sub": str(usuario), "role": "authenticated"}),
    )
    await conn.execute("SET LOCAL ROLE authenticated")

async def test():
    conn = await asyncpg.connect('postgresql://postgres:postgres@127.0.0.1:54322/postgres')
    
    # Check initial state
    producto = await conn.fetchrow("SELECT id, nombre, activo, productor_id FROM public.productos WHERE id=$1", PRODUCTO_P1)
    print(f"Initial product: {producto}")
    
    # Auth as admin and pause
    await autenticar(conn, ADMIN)
    await conn.execute(
        "UPDATE public.productos SET activo=false, motivo_pausa=$1 WHERE id=$2",
        "Pausa administrativa lote 16 con motivo valido.",
        PRODUCTO_P1,
    )
    
    # Check after admin pause
    producto = await conn.fetchrow("SELECT id, nombre, activo, productor_id FROM public.productos WHERE id=$1", PRODUCTO_P1)
    print(f"After admin pause: {producto}")
    
    # Auth as vendor
    await autenticar(conn, PERFIL_P1)
    
    # Check if vendor can see it
    producto = await conn.fetchrow("SELECT id, nombre, activo, productor_id FROM public.productos WHERE id=$1", PRODUCTO_P1)
    print(f"Vendor sees: {producto}")
    
    # Try update
    result = await conn.execute(
        "UPDATE public.productos SET nombre=$1 WHERE id=$2 AND productor_id=$3",
        "Tomates Roma de Paine (edicion vendedor)", PRODUCTO_P1, PRODUCTOR_P1,
    )
    print(f"Update result: {result}")
    
    # Check after update
    producto = await conn.fetchrow("SELECT id, nombre, activo, productor_id FROM public.productos WHERE id=$1", PRODUCTO_P1)
    print(f"After vendor update: {producto}")
    
    await conn.close()

asyncio.run(test())