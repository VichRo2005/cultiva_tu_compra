# CuTuCo — Despliegue y ejecución en cualquier entorno

Este documento describe cómo levantar, configurar y desplegar **CuTuCo** en cualquier máquina y entorno: desarrollo local, pruebas (QA/CI) y producción. Cubre **todos** los componentes del sistema: **Supabase (local vía Docker o Supabase alojado), Docker, Backend FastAPI, Frontend Vue + Vite, APIs (Webpay/Transbank, Brevo, SRE, datos bancarios), GCP (Cloud Run, Artifact Registry, Secret Manager, Cloud Build)** y cualquier otro servicio que la página necesite para funcionar sin fallos de compatibilidad ni de versión.

---

## Índice

1. [Arquitectura y componentes](#arquitectura-y-componentes)
2. [Requisitos mínimos por entorno](#requisitos-mínimos-por-entorno)
3. [Despliegue local de desarrollo (`dev.ps1`)](#despliegue-local-de-desarrollo-devps1)
4. [Comando `doctor`: diagnóstico completo](#comando-doctor-diagnóstico-completo)
5. [Despliegue en QA / CI](#despliegue-en-qa--ci)
6. [Despliegue a producción en GCP (Cloud Run)](#despliegue-a-producción-en-gcp-cloud-run)
7. [Variables de entorno y secretos](#variables-de-entorno-y-secretos)
8. [Comprobación de salud y rollback](#comprobación-de-salud-y-rollback)
9. [Solución de problemas](#solución-de-problemas)
10. [Notas importantes](#notas-importantes)

---

## Arquitectura y componentes

| Componente | Tecnología | Puerto local | Despliegue destino |
|------------|-----------|--------------|-------------------|
| Base de datos + Auth + Storage + Realtime | Supabase (local via Docker o Supabase Cloud) | API 54321, DB 54322, Studio 54323 | Local / Supabase Cloud |
| Backend API | FastAPI + Uvicorn (Python 3.12) | 8000 (local), 8080 (Cloud Run) | Local / GCP Cloud Run |
| Frontend SPA | Vue 3 + Vite | 5173 (local) | Vercel (producción) |
| Pagos Webpay Mall | Transbank SDK | API `/api/webpay/*` | Backend |
| Servicio mensual Webpay Plus | Transbank SDK | API `/api/servicio/*` | Backend |
| Correo transaccional | Brevo (API + SMTP) | — | Backend |
| Datos bancarios (cifrados) | Fernet + PostgreSQL | — | Backend / Supabase |
| Autocompletar tributario B2B | SRE API (sre.cl) | — | Backend |
| Imágenes Docker | Docker Desktop local / Artifact Registry | — | Local / GCP Artifact Registry |
| Build/CI | Cloud Build + GitHub Actions | — | GCP Cloud Build |

---

## Requisitos mínimos por entorno

### En cualquier PC (Windows, macOS, Linux)

| Herramienta | Versión mínima | ¿Opcional? | Nota |
|-------------|---------------|------------|------|
| Git | 2.40+ | No | Para clonar el repositorio |
| Docker Desktop / Docker Engine | 24+ | Sí (requerido para Supabase local y build de imágenes) | En Windows: WSL2 habilitado; en Linux: usuario en grupo `docker` |
| Node.js | 22.18.0 o >=24.12.0 | No | Frontend (versión LTS) |
| npm | 10+ | No | Viene con Node |
| Python | 3.12.x | No | Backend |
| `py` (Python launcher para Windows) | — | No (Windows) | Para crear el venv con Python 3.12 |
| Supabase CLI | 2.x | Sí | Para `supabase start/stop` local |
| gcloud CLI | 4.x | Sí | Solo para despliegue a GCP |

### En entornos sin las herramientas instaladas

El script `dev.ps1` **descarga e instala forzosamente** todo lo que falte o tenga una versión incompatible:

- **Python 3.12** y el launcher `py` (Windows) — se reinstala si la versión del venv no es 3.12.
- **Node.js 22.x/24.x (LTS)** — se reinstala si `npm` falta o la versión no cumple `engines` del frontend.
- **Docker Desktop / Engine** — se valida que esté corriendo; si no, el script avisa con instrucciones de instalación.
- **Supabase CLI v2.x** — se instala globalmente con `npm i -g supabase@latest` si falta o es versión antigua.
- **gcloud CLI** — se valida; solo requerido para despliegue a GCP (no para desarrollo local).

**Gestores de paquetes soportados por SO:**
- **Windows:** winget (preferido), Chocolatey, Scoop
- **macOS:** Homebrew
- **Linux:** apt (Debian/Ubuntu), dnf (Fedora/RHEL), pacman (Arch)

---

## Despliegue local de desarrollo (`dev.ps1`)

El script `dev.ps1` es el **punto de entrada único**. Levanta **todos** los componentes necesarios para que la página funcione correctamente:

```powershell
.\dev.ps1 setup       # Instala/fuerza herramientas y dependencias (backend + frontend)
.\dev.ps1 up          # Levanta Supabase, migraciones, backend, frontend y verifica salud
.\dev.ps1 status      # Estado de todos los servicios
.\dev.ps1 down        # Detiene todo (excepto volúmenes de Docker)
.\dev.ps1 reset-bd    # Recrea la base local y recarga semillas (borra datos)
.\dev.ps1 gcp-build   # Build de imagen Docker para Cloud Run (local)
.\dev.ps1 gcp-deploy  # Despliega backend a GCP Cloud Run (requiere autorización)
.\dev.ps1 doctor      # Diagnóstico completo del entorno
.\dev.ps1 help        # Ayuda
```

### Qué hace `setup` (instalación forzada completa)

1. **Detecta el SO** (Windows/macOS/Linux) y el gestor de paquetes disponible.
2. **Verifica/instala Python 3.12** y el launcher `py` (Windows) — **fuerza reinstalación** si la versión es incompatible.
3. **Crea (o recrea forzosamente)** `backend\.venv` con Python 3.12 si la versión es incompatible.
4. **Actualiza pip/setuptools/wheel** e instala `requirements.txt` + `requirements-dev.txt` con `--no-cache-dir`, `--force-reinstall`, timeouts y reintentos.
5. **Crea `backend\.env`** desde `.env.example` si falta; valida claves críticas.
6. **Verifica/instala Node.js LTS** (22.18+ o 24.12+) y `npm` — **fuerza reinstalación** si la versión no cumple.
7. **Limpieza total del frontend:** elimina `node_modules`, `package-lock.json`, `pnpm-lock.yaml`, `yarn.lock` para evitar conflictos de versión.
8. **Instala dependencias del frontend** con `npm install --force --legacy-peer-deps` (regenera lockfile limpio).
9. **Crea `frontend\.env.local`** desde el ejemplo si falta; valida claves críticas.
10. **Crea carpeta `logs/`** para salida de backend y frontend.

### Qué hace `up` (levantamiento completo con verificación)

1. **Valida Docker** corriendo (espera hasta 60s a que inicie).
2. **Valida Supabase CLI v2.x** instalado.
3. **Levanta Supabase local** con `supabase start` (API 54321, DB 54322, Studio 54323, Inbucket 54324, Edge Inspector 8083).
4. **Sincroniza automáticamente** credenciales de Supabase local (`API_URL`, `ANON_KEY`, `SERVICE_ROLE_KEY`, `JWT_SECRET`, `DB_URL`) en `backend/.env` y `frontend/.env.local`.
5. **Aplica migraciones** con `supabase migration up --include-all`. Es obligatorio que incluya `20261116000000_portada_tienda.sql` (portadas de tienda), `20261117000000_foto_perfil_vendedor.sql` (avatares de vendedor), `20261118000000_foto_perfil_cliente.sql` (columna `perfiles.foto_perfil_storage_path` y bucket público `client-avatars`), `20261119000000_rut_solicitante_disponible.sql` (RPC pública que sólo devuelve si un RUT está disponible), `20261120000000_codigo_entrega_6_digitos.sql` (código numérico de seis dígitos para confirmar entregas), `20261121000000_avatar_cliente_evaluaciones_publicas.sql` (avatar y nombre de pila en reseñas públicas), `20261122000000_paginacion_filtro_evaluaciones_publicas.sql` (paginación y filtro por estrellas de reseñas públicas) y `20261123000000_reglas_cantidad_producto.sql` (incremento de venta y compra mínima por producto). `dev.ps1 up` verifica que los ocho archivos existan antes de aplicar la migración y se detiene si alguno falta, para no iniciar contra un esquema incompleto.
6. **Carga datos de prueba:** ejecuta `backend/scripts/seed_datos_bancarios.py` (6 cuentas cifradas) y `backend/scripts/upload_product_images.py --target local` (20 imágenes WebP al bucket `product-images`).
7. **Libera puertos** 8000 (backend) y 5173 (frontend) matando procesos que los ocupen.
8. **Arranca backend FastAPI** (uvicorn `app.main:app --reload` en 127.0.0.1:8000) con logs en `logs/backend.out.log` / `.err.log`.
9. **Espera a `/health`** (hasta 90s) — muestra últimas líneas de error si falla.
10. **Arranca frontend Vite** en puerto 5173 con `--strictPort --host 0.0.0.0` y logs en `logs/frontend.out.log` / `.err.log`.
11. **Espera a que frontend responda** (hasta 120s) — muestra últimas líneas de error si falla.
12. **Verificación de integración:** comprueba `/docs` (backend), Studio (Supabase) y el preflight CORS de `POST /api/webpay/confirmar` desde `http://localhost:5173` y `http://127.0.0.1:5173`.
13. **Muestra resumen completo** con URLs, componentes verificados y logs.

### Componentes integrados en `up`

- **Supabase:** PostgreSQL 17, Auth (GoTrue), Storage (buckets `product-images` público para fotos de producto, `store-covers` público para la portada de tienda, `seller-avatars` público para la foto de perfil del vendedor y `client-avatars` público para la foto de perfil del cliente; escritura y listado protegidos por RLS de dueño; `vendedor-documentos` privado para KYB), Realtime, Studio, Edge Functions (Deno 2), Inbucket (email testing), Poolers.
- **Backend FastAPI:** API REST, Webpay Mall, Webpay Plus Servicio Mensual, Datos bancarios (Fernet), SRE (autocompletar tributario), Brevo (API + SMTP de respaldo) y health checks.
- **Frontend Vue 3 + Vite:** SPA con proxy `/cliente/pedidos` → `/api/webpay/retorno` para retorno Webpay, HMR, OneDrive file-watcher fixes.
- **APIs externas:** Transbank (Webpay Mall/Plus), Brevo (SMTP/API), SRE (datos tributarios).
- **Docker:** Contenedores Supabase (Kong, Postgres, Studio, Realtime, Storage, Edge Runtime, Inbucket, Vector, Analytics).

---

## Comando `doctor`: diagnóstico completo

Ejecuta `.\dev.ps1 doctor` para un **diagnóstico exhaustivo** del entorno:

```
=== SISTEMA ===
=== HERRAMIENTAS DEL SISTEMA ===     (Python, Node, npm, Docker, Supabase CLI, gcloud)
=== ENTORNO VIRTUAL PYTHON ===       (venv existe, versión correcta)
=== DEPENDENCIAS BACKEND ===         (paquetes runtime + dev instalados)
=== DEPENDENCIAS FRONTEND ===        (node_modules, package-lock.json)
=== ARCHIVOS DE CONFIGURACIÓN ===    (.env backend, .env.local frontend, supabase/config.toml)
=== PUERTOS ===                      (8000, 5173, 54321-54323 libres/ocupados)
=== SUPABASE LOCAL ===               (corriendo, URLs, credenciales)
=== RESUMEN ===                      (OK / avisos / errores con acción recomendada)
```

**Códigos de salida del resumen:**
- ✅ **TODO OK** — Entorno listo para `.\dev.ps1 up`
- ⚠️ **Solo avisos** — Funcionará pero revisa los avisos
- ❌ **Errores** — Ejecuta `.\dev.ps1 setup` para corregir

---

## Despliegue en QA / CI

El repositorio incluye `.github/workflows/ci.yml` que corre en cada push a `Desarrollo-frontend` o `main`:

1. **Backend:** Python 3.12, `pip install -r requirements.txt -r requirements-dev.txt`, `ruff check`, `mypy`, `pytest tests/unit`.
2. **Frontend:** Node 20, `npm ci`, `npx vitest run`.
3. **DB-SQL:** PostgreSQL 16 efímero con migraciones + seeds + tests SQL.
4. **Docker-build:** `docker build -f backend/Dockerfile backend` (valida compatibilidad con Cloud Run).

Para ejecutar localmente el equivalente de CI:

```powershell
.\dev.ps1 setup
cd backend && python -m pytest tests/unit -q
cd frontend && npm run test
```

---

## Despliegue a producción en GCP (Cloud Run)

El backend se despliega a **Google Cloud Run** en el proyecto `cutuco` (región `southamerica-west1`). El frontend sigue en **Vercel** (no se migra a GCP en esta etapa).

### Orden obligatorio para publicar cambios de base de datos, backend y perfil

Antes de publicar esta versión aplica primero las migraciones al proyecto de Supabase de producción desde una terminal autorizada. Esto crea la columna y el bucket `client-avatars` para los perfiles, expone el avatar ya público y el nombre de pila en reseñas, agrega paginación y filtro por estrellas a las reseñas, permite definir incrementos de venta y mínimos de compra por producto, crea la RPC `rut_solicitante_disponible(p_rut text)` necesaria para el registro público de vendedores y limita el código de entrega a seis dígitos:

```bash
supabase login
supabase link --project-ref <tu-project-ref>
supabase db push
```

Después confirma en Supabase Studio que existen `perfiles.foto_perfil_storage_path`, el bucket `client-avatars` y la función `rut_solicitante_disponible`. Antes del deploy de Cloud Run crea o actualiza el secreto `TRANSBANK_MALL_SELLER_COMMERCE_CODE`: debe ser el comercio hijo contratado para vendedores y no puede ser igual a `TRANSBANK_COMMERCE_CODE`. El backend lo usa al aprobar una postulación; el administrador nunca lo ingresa desde el navegador.

Por último despliega Cloud Run cuando cambie el backend y Vercel cuando cambie el frontend. El retorno de Webpay debe conservar `TRANSBANK_RETURN_URL=https://<frontend>/cliente/pedidos`; el rewrite del frontend redirige el POST de Transbank a FastAPI y la SPA confirma el resultado de forma idempotente.

### Prerrequisitos (una sola vez)

1. **Instalar gcloud CLI** y autenticarse:
   ```bash
   gcloud auth login
   gcloud config set project cutuco
   ```

2. **Habilitar APIs:**
   ```bash
   gcloud services enable run.googleapis.com cloudbuild.googleapis.com \
     artifactregistry.googleapis.com secretmanager.googleapis.com \
     iam.googleapis.com logging.googleapis.com monitoring.googleapis.com \
     --project cutuco
   ```

3. **Crear repositorio de imágenes (una vez):**
   ```bash
   gcloud artifacts repositories create cutuco-backend \
     --repository-format=docker --location=southamerica-west1 \
     --description="Imágenes del backend FastAPI de CuTuCo" --project cutuco
   ```

4. **Crear secretos en Secret Manager** (valores desde `backend/.env`, nunca por chat):
   Consulta `gcp/secrets-map.md` para la lista completa de 19 secretos, incluido `TRANSBANK_MALL_SELLER_COMMERCE_CODE`.

5. **Dar permisos a la cuenta de servicio de Cloud Run:**
   ```bash
   gcloud projects add-iam-policy-binding cutuco \
     --member="serviceAccount:PROJECT_NUMBER-compute@developer.gserviceaccount.com" \
     --role="roles/secretmanager.secretAccessor"
   ```

### Despliegue desde `dev.ps1`

```powershell
.\dev.ps1 gcp-build   # Construye la imagen localmente (validación opcional)
.\dev.ps1 gcp-deploy  # Despliega a GCP (requiere gcloud autenticado)
```

**Qué hace `gcp-deploy` automáticamente:**
1. Verifica `gcloud` autenticado y proyecto `cutuco`.
2. **Preflight de secretos:** comprueba los 19 secretos referenciados por Cloud Run, bloquea valores locales y verifica que el comercio hijo de vendedores exista y sea distinto al comercio padre. Nunca imprime sus valores.
3. Ejecuta `bash gcp/deploy-backend.sh` (Cloud Build → Artifact Registry → Cloud Run deploy).

### Despliegue manual alternativo

```bash
# Build en Cloud Build + push a Artifact Registry
gcloud builds submit --config gcp/cloudbuild.yaml \
  --substitutions _REGION=southamerica-west1 --project cutuco .

# Deploy a Cloud Run (usa gcp/service.backend.yaml como plantilla)
gcloud run deploy cutuco-backend \
  --image southamerica-west1-docker.pkg.dev/cutuco/cutuco-backend/cutuco-backend:latest \
  --region southamerica-west1 --project cutuco \
  --no-allow-unauthenticated \
  --min-instances 0 --max-instances 5 \
  --memory 512Mi --cpu 1 --concurrency 80 --timeout 60 \
  --set-secrets "SUPABASE_URL=SUPABASE_URL:latest,... (ver gcp/deploy-backend.sh)" \
  --set-env-vars "ENVIRONMENT=production,TRANSBANK_ENV=integration,RESERVA_STOCK_MINUTOS=15,..."
```

`ENVIRONMENT=production` activa la configuración de producción de FastAPI (incluido CORS estricto). `TRANSBANK_ENV=integration` sólo mantiene la actual fase sandbox de Transbank del script. Al habilitar pagos reales, cambia este último a `production` y reemplaza **todos** los secretos `TRANSBANK_*` por sus credenciales productivas en la misma publicación.

El repositorio no tiene un workflow de GitHub Actions para desplegar. Usa
`dev.ps1 gcp-deploy` o `gcp/deploy-backend.sh` desde una terminal autenticada;
ambos ejecutan el mismo preflight de secretos antes de publicar.

### Verificación post-deploy

```bash
URL="$(gcloud run services describe cutuco-backend --region southamerica-west1 --project cutuco --format='value(status.url)')"
TOKEN="$(gcloud auth print-identity-token)"
curl -fsS -H "Authorization: Bearer ${TOKEN}" "${URL}/health"  # debe responder 200
unset TOKEN
```

---

## Variables de entorno y secretos

### `backend/.env` (local, nunca se commitea)

Copia de `backend/.env.example`. Claves principales:

```
# Supabase local (se sincroniza automáticamente con `dev.ps1 up`)
SUPABASE_URL=http://127.0.0.1:54321
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
SUPABASE_JWT_SECRET=...
DATABASE_URL=postgresql://postgres:postgres@localhost:54322/postgres

# Webpay Mall (catálogo/pedidos) — sandbox integración
TRANSBANK_COMMERCE_CODE=597055555535
TRANSBANK_FEE_COMMERCE_CODE=597055555537
# Comercio hijo asignado por el backend al aprobar una cuenta vendedora.
# En producción debe ser distinto de TRANSBANK_COMMERCE_CODE.
TRANSBANK_MALL_SELLER_COMMERCE_CODE=597055555536
TRANSBANK_API_KEY=579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C
TRANSBANK_RETURN_URL=http://localhost:5173/cliente/pedidos
TRANSBANK_ENV=integration

# Webpay Plus del SERVICIO MENSUAL (HAL-VEN-025) — OBLIGATORIO en production/test
TRANSBANK_SERVICIO_COMMERCE_CODE=
TRANSBANK_SERVICIO_API_KEY=
TRANSBANK_SERVICIO_RETURN_URL=http://localhost:8000/api/servicio/retorno

# Correo transaccional (Brevo)
BREVO_API_KEY=...
BREVO_SMTP_HOST=smtp-relay.brevo.com
BREVO_SMTP_PORT=587
BREVO_SMTP_LOGIN=
BREVO_SMTP_KEY=
EMAIL_FROM=CuTuCo Soporte <cutucosoporte@gmail.com>

# Frontend
FRONTEND_URL=http://localhost:5173

# Entorno
ENVIRONMENT=development
AUTH_DEV_FALLBACK=false

# Stock reservation
RESERVA_STOCK_MINUTOS=15

# Clave Fernet para cifrar datos bancarios (generar: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
BANK_ENCRYPTION_KEY=

# API SRE para autocompletar datos tributarios B2B
SRE_BASE_URL=https://sre.cl
SRE_TOKEN_PUBLICO=token_publico
SRE_TIMEOUT_SEGUNDOS=4
```

### `frontend/.env.local` (local, ignorado por Git)

```
# Supabase (se sincroniza automáticamente con `dev.ps1 up`)
VITE_SUPABASE_URL=http://127.0.0.1:54321
VITE_SUPABASE_ANON_KEY=...

# FastAPI backend
VITE_API_BASE_URL=http://127.0.0.1:8000

# Herramientas de desarrollo (opcional)
VITE_DEV_GALLERY=false
VITE_DEV_PASSWORD=CutucoDev2026!

# Datos bancarios de CuTuCo para transferencias (obligatorio para ese flujo)
VITE_CUTUCO_BANCO=
VITE_CUTUCO_TIPO_CUENTA=
VITE_CUTUCO_NUMERO_CUENTA=
VITE_CUTUCO_TITULAR=
VITE_CUTUCO_RUT=
```

### Secretos de GCP (producción)

Consulta `gcp/secrets-map.md`. Los **19 secretos** referenciados por Cloud Run deben existir antes del deploy. `gcp/deploy-backend.sh` y `dev.ps1 gcp-deploy` incluyen un **preflight que aborta** si falta alguno, si contiene una dirección local o si `TRANSBANK_MALL_SELLER_COMMERCE_CODE` coincide con el comercio padre.

**Valores de producción obligatorios (resumen):**

| Secreto | Valor de producción esperado |
|---------|------------------------------|
| SUPABASE_URL | `https://<proyecto>.supabase.co` |
| SUPABASE_ANON_KEY / SERVICE_ROLE_KEY / JWT_SECRET | Llaves del proyecto Supabase de producción |
| DATABASE_URL | Pooler Supabase: `postgresql://postgres:<pass>@aws-0-<region>.pooler.supabase.com:6543/postgres` |
| FRONTEND_URL | Origen público Vercel: `https://cutuco.cl` o `https://<app>.vercel.app` |
| TRANSBANK_RETURN_URL | `https://cutuco.cl/cliente/pedidos` |
| TRANSBANK_MALL_SELLER_COMMERCE_CODE | Comercio hijo de Transbank para vendedores; distinto a `TRANSBANK_COMMERCE_CODE` |
| TRANSBANK_SERVICIO_RETURN_URL | `https://api.cutuco.cl/api/servicio/retorno` |
| TRANSBANK_* / TRANSBANK_SERVICIO_* | Credenciales Transbank producción (cuando habilitadas) |
| BREVO_API_KEY / SMTP_LOGIN / SMTP_KEY | Credenciales Brevo producción |
| BANK_ENCRYPTION_KEY | Clave Fernet nueva para producción |
| SRE_TOKEN_PUBLICO | Token sre.cl vigente |

**Actualizar un secreto (usa `printf`, NUNCA `echo` — `echo` agrega `\r\n` y rompe validaciones pydantic):**
```bash
printf '%s' "VALOR" | gcloud secrets versions add NOMBRE --data-file=- --project cutuco
```

---

## Comprobación de salud y rollback

### Salud local

```powershell
.\dev.ps1 status
```

Endpoints de salud:
- Backend: `http://127.0.0.1:8000/health` → `{"status":"ok"}`
- Frontend: `http://localhost:5173` → HTML SPA
- Supabase Studio: `http://127.0.0.1:54323`

### Rollback local

```powershell
.\dev.ps1 down
.\dev.ps1 up
```

### Rollback en GCP

```bash
gcloud run services rollout undo cutuco-backend --region southamerica-west1 --project cutuco
```

---

## Solución de problemas

| Problema | Solución |
|----------|----------|
| Docker no está corriendo | Abre Docker Desktop y espera a que esté listo (icono estable), luego reintenta `.\dev.ps1 up` |
| Python versión != 3.12 | `.\dev.ps1 setup` recrea el venv forzosamente con Python 3.12 |
| `npm` no encontrado / Node.js versión antigua | `.\dev.ps1 setup` instala Node.js LTS si falta o fuerza reinstalación |
| Puerto 8000/5173/54321-54323 ocupado | `up` libera los puertos automáticamente; si falla, cierra el proceso manualmente o usa `.\dev.ps1 doctor` para ver quién los usa |
| Supabase no levanta | Verifica Docker Desktop; `supabase stop` y luego `supabase start`; revisa puertos 54321-54324 |
| Backend no responde /health | Revisa `logs\backend.err.log` y `logs\backend.out.log`; ejecuta `.\dev.ps1 doctor` |
| El retorno de pago informa CORS o no puede confirmar | Ejecuta `.\dev.ps1 up` para reiniciar FastAPI con `--reload`; el script valida el preflight de `POST /api/webpay/confirmar`. Confirma que `FRONTEND_URL` sea el origen exacto del frontend sin ruta final. |
| Frontend no responde / pantalla en blanco | Revisa `logs\frontend.err.log` y `logs\frontend.out.log`; verifica `VITE_API_BASE_URL` en `.env.local` |
| `rut_solicitante_disponible` no aparece en schema cache | Aplica `supabase migration up --include-all` localmente o `supabase db push` en el proyecto correspondiente; no se corrige reiniciando sólo el frontend. |
| GCP deploy falla por secreto con `localhost` | Actualiza el secreto en Secret Manager con valor de producción (ver `gcp/secrets-map.md`) |
| GCP deploy rechaza el comercio Mall del vendedor | Crea `TRANSBANK_MALL_SELLER_COMMERCE_CODE` con el código hijo contratado y distinto de `TRANSBANK_COMMERCE_CODE`; no uses el código padre ni lo expongas al administrador. |
| Error de certificado/SSL en Transbank | Usa `TRANSBANK_ENV=integration` en desarrollo; producción requiere credenciales reales |
| OneDrive bloquea Vite (EBUSY) | `vite.config.js` ya ignora archivos `.tmpdir`, `~RF*`, `~$*` de OneDrive |
| `supabase start` falla con "port already allocated" | `.\dev.ps1 down` y reintenta; o `docker compose -f <supabase-dir>/docker-compose.yml down -v` |
| `npm install` falla con peer dependency errors | `.\dev.ps1 setup` usa `--legacy-peer-deps` y limpia `node_modules`/`lockfiles` antes |
| `gcloud auth print-identity-token` falla | `gcloud auth login` y verifica `gcloud config get-value project` |
| `gcp-deploy` indica que falta Bash | En Windows instala Git for Windows, cierra y abre PowerShell nuevamente; el despliegue ejecuta `gcp/deploy-backend.sh` con Bash. |
| Permisos Docker en Linux (no root) | `sudo usermod -aG docker $USER` y **cierra sesión y vuelve a entrar** (o `newgrp docker`) |

---

## Notas importantes

- **Nunca commitees** `backend/.env`, `frontend/.env.local`, `supabase/.env` ni secretos reales.
- El script `dev.ps1` **fuerza la reinstalación** de herramientas si la versión instalada es incompatible con lo que el repositorio exige.
- **Multi-SO nativo:** Windows (winget/choco/scoop), macOS (brew), Linux (apt/dnf/pacman).
- **Sincronización automática:** `up` actualiza credenciales de Supabase local en `.env` files.
- **Diagnóstico integrado:** `doctor` detecta cualquier problema de versiones, puertos, dependencias, configs.
- Para producción, el despliegue a GCP requiere **autorización expresa del propietario** (no se crea ningún recurso sin intervención manual).
- El frontend se despliega por separado en **Vercel** (consulta `vercel.json` si existe).
- **Preflight de secretos GCP:** tanto `deploy-backend.sh` como `dev.ps1 gcp-deploy` bloquean el deploy si falta un secreto de Cloud Run, hay valores locales o el comercio hijo Mall coincide con el padre.
- **Logs persistentes:** backend/frontend escriben a `logs/*.log` para diagnóstico post-mortem.
