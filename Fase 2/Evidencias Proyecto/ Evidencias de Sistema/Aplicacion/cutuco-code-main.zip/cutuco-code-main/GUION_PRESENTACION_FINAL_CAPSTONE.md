# Guion de presentación final - CuTuCo

**Duración estimada:** 10 minutos, sin considerar la demostración de la diapositiva 14.  
**Ritmo recomendado:** 120 a 125 palabras por minuto. Los títulos, tiempos y notas no se leen; sólo se narra el texto bajo cada diapositiva.

## Ignacio Fuenzalida - diapositivas 1 a 8 (aprox. 4 min 45 s)

### Diapositiva 1 - Proyecto CuTuCo (0:00-0:20)

Buenos días. Soy Ignacio Fuenzalida y, junto con Vicente Rivera, presentaré CuTuCo, abreviación de Cultiva Tu Compra. Desarrollamos este proyecto como una propuesta de marketplace de proximidad para acercar a los productores de la Agricultura Familiar Campesina a quienes compran sus productos, mediante una experiencia digital segura, trazable y orientada al comercio local.

### Diapositiva 2 - Integrantes del proyecto (0:20-0:50)

Nuestro equipo se organizó con responsabilidades complementarias. Vicente lideró el backend, el modelado de datos y la integración de pagos. Yo asumí la interfaz web con Vue y Vite, el consumo de APIs y el despliegue de los servicios en la nube. Trabajamos conjuntamente en pruebas, control de cambios y documentación; así mantuvimos consistencia entre el alcance, el código y las evidencias de cierre.

### Diapositiva 3 - Descripción del proyecto (0:50-1:25)

CuTuCo nace de una brecha concreta: los pequeños productores enfrentan costos tecnológicos, pierden margen frente a la intermediación y encuentran alternativas que no siempre visibilizan su origen ni permiten transacciones completas. Diseñamos un marketplace SaaS B2B2C: los productores publican y administran su oferta; los clientes descubren, compran y califican; y los administradores validan postulaciones y resguardan la operación. Así, los módulos reemplazan una vitrina aislada por una relación comercial directa, con pagos, despacho, reputación y trazabilidad.

### Diapositiva 4 - Objetivo general y específicos (1:25-2:00)

Nuestro objetivo fue desplegar un MVP funcional y transaccional sobre una arquitectura cloud desacoplada, con un ecosistema de confianza para la Agricultura Familiar Campesina. Separamos el frontend en Vue, los servicios sensibles en FastAPI y los datos en Supabase. Integramos Webpay Mall para la compra multivendedor y Webpay Plus para la cuota de servicio, incorporamos los módulos de cliente, vendedor y administración, y establecimos pruebas y documentación como criterios de calidad.

### Diapositiva 5 - Funcionalidades y limitaciones (2:00-2:40)

El resultado incluye carrito multivendedor, pagos en ambiente de integración, una comisión del cinco por ciento mediante Webpay Mall y una suscripción para los vendedores mediante Webpay Plus. Los clientes validan la entrega con un código y califican de uno a cinco; los administradores revisan indicadores, postulaciones, sanciones y reclamos. Delimitamos el alcance con transparencia: los reembolsos se gestionan por la pasarela o el banco, la facturación y las guías corresponden al productor, y no implementamos fiscalización sectorial ni GPS en tiempo real.

### Diapositiva 6 - Metodología de trabajo (2:40-3:05)

Para transformar este alcance en un producto verificable aplicamos una metodología en cascada con retroalimentación controlada. Primero planificamos riesgos; luego analizamos requerimientos, datos y pantallas; después construimos los módulos; y finalmente realizamos integración, pruebas, correcciones y cierre. La secuencia nos dio trazabilidad documental, mientras Git registró cada ajuste sin perder la relación entre decisión, cambio y evidencia.

### Diapositiva 7 - Cronograma y evolución del entorno (3:05-3:45)

El cronograma ordenó el avance en cuatro fases. En planificación definimos el acta, EDT, Gantt, RACI, riesgos y pruebas. En análisis y diseño actualizamos el ERS, el modelo entidad-relación, políticas de acceso y mockups. En construcción migramos el MVP inicial, basado en Ionic, Angular y SQLite, a un entorno web desacoplado. El entorno local se automatizó con `dev.ps1`: Docker levanta Supabase con PostgreSQL, autenticación, almacenamiento y RLS; FastAPI ejecuta la API y Vite sirve la SPA. Así, ambos reproducimos datos, servicios y pruebas antes de publicar.

### Diapositiva 8 - Arquitectura del software (3:45-4:45)

La arquitectura resultante distribuye responsabilidades. Los clientes, vendedores y administradores acceden a una sola aplicación Vue 3 con Vite; en el entorno final, el frontend se publica en Vercel bajo **cutuco.online**. Supabase concentra PostgreSQL, Auth, almacenamiento, PostgREST y reglas RLS, por lo que los datos y permisos se aplican junto a la persistencia. Los servicios FastAPI se encapsulan en Docker y se preparan para Cloud Run; allí procesan pagos, cifrado Fernet de datos bancarios, consultas tributarias y correos. Webpay devuelve el resultado a los servicios, SRE.cl completa antecedentes de empresa y Brevo envía notificaciones. De este modo, los componentes se comunican por APIs, los secretos no llegan al frontend y los módulos evolucionan sin acoplar toda la solución. Con esta base, cedo la presentación a Vicente.

## Vicente Rivera - diapositivas 9 a 13 y 15 a 17 (aprox. 5 min 15 s)

### Diapositiva 9 - Modelo de datos general (4:45-5:25)

Gracias, Ignacio. Estructuramos el modelo de datos en dominios conectados: identidad y ubicación, productores y catálogo, pedidos y pagos, y administración y reputación. Cada perfil conserva su rol y comuna, cada producto pertenece a un productor y una categoría, y cada operación mantiene sus detalles, pago y despacho. Esta separación permite que los módulos consulten sólo los datos necesarios y que las políticas RLS restrinjan la información según el rol de quienes acceden.

### Diapositiva 10 - Registro de productores (5:25-6:00)

El registro de productores refleja el primer control de confianza. Las personas solicitantes completan antecedentes, región, documentos y datos bancarios; las postulaciones pasan por revisión administrativa y sólo después se habilitan como productores. Los administradores registran decisiones y observaciones, mientras que los reintentos conservan historial. Asociamos el código de comercio de Webpay Mall al productor aprobado, para dirigir los pagos al comercio correspondiente. Así, los datos representan un proceso de validación y habilitación comercial, no sólo un formulario.

### Diapositiva 11 - Catálogo y productos (6:00-6:35)

Una vez habilitados, los productores gestionan un catálogo con categorías, productos e imágenes. Cada producto conserva nombre, precio en pesos chilenos enteros, stock, código comercial y estado de publicación; las imágenes se almacenan por ruta. Los clientes consultan sólo la oferta activa y autorizada, mientras los vendedores administran sus registros. Esta estructura facilitó filtros, búsqueda, control de inventario y trazabilidad desde la publicación hasta el detalle del pedido.

### Diapositiva 12 - Pedidos, pago y despacho (6:35-7:20)

El flujo transaccional se articula desde el carrito hasta la entrega. Al confirmar la compra, los módulos generan pedidos por productor, calculan despacho y reservan stock para evitar sobreventa. Webpay Mall procesa las ventas multivendedor y los servicios registran el pago de forma idempotente para no duplicar cobros ni pedidos. Luego, los vendedores preparan y despachan; los clientes reciben un código que los vendedores validan para cerrar la entrega. Así, pedidos, detalles, pagos y envíos conservan la evidencia del ciclo comercial.

### Diapositiva 13 - Tecnologías utilizadas (7:20-8:15)

Seleccionamos tecnologías coherentes con el MVP. Vue 3 y Vite entregan una interfaz mantenible; Python con FastAPI concentra reglas de negocio; y PostgreSQL en Supabase reúne persistencia, autenticación, almacenamiento y control de acceso. Docker hace reproducible el backend y Cloud Run permite ejecutarlo como servicio; Vercel entrega la SPA publicada. Los tokens JWT respaldan las sesiones, Supabase Auth gestiona credenciales y Fernet cifra datos bancarios. Webpay, SRE.cl y Brevo resuelven pagos, antecedentes tributarios y comunicación. Validamos con Pytest, Vitest y pruebas de flujo en navegador, apoyadas por Git y automatización de build.

### Diapositiva 14 - Demostración del resultado

**No se lee. Esta demostración se realiza fuera de los diez minutos asignados al guion.**

### Diapositiva 15 - Resultados obtenidos (8:15-8:50)

Como resultado, consolidamos un MVP web con flujos centrales integrados y una publicación accesible desde cutuco.online. La documentación de gestión, requisitos, arquitectura, pruebas, implantación, soporte y manuales se actualizó hasta la semana diez y quedó vinculada a los hitos de demo, Gantt y reporte de pruebas. Las evidencias de cierre registran 360 pruebas de backend y 635 de frontend satisfactorias; así validamos reglas de negocio, permisos, pagos simulados e integraciones, además de las pantallas.

### Diapositiva 16 - Obstáculos y decisiones (8:50-9:35)

Durante el desarrollo enfrentamos tres obstáculos. Primero, Webpay Plus y el código de verificación podían desalinear el alcance inicial; los gestionamos con Git, control de cambios y actualización de documentos y pruebas. Segundo, SRE.cl limitaba las consultas gratuitas; aseguramos continuidad con un plan mínimo y controlamos su uso. Tercero, la disponibilidad inicial era de hasta cuatro horas diarias por integrante debido a la práctica laboral; redistribuimos tareas y paralelizamos el trabajo al liberarse capacidad. Así, las restricciones se transformaron en criterios para priorizar y verificar el avance.

### Diapositiva 17 - Preguntas de la comisión (9:35-10:00)

En síntesis, desarrollamos CuTuCo como un MVP que conecta productores y clientes con arquitectura desacoplada, procesos de confianza y evidencias de calidad. Reconocemos sus límites y contamos con una base técnica y documental para evolucionarlos de forma controlada. Muchas gracias; quedamos atentos a sus preguntas.

